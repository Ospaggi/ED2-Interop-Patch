#!/usr/bin/env python3
"""ED2 MON battle-message spacing/linebreak presentation fixes."""
from __future__ import annotations
import argparse, os, stat, struct, tempfile
from dataclasses import dataclass
from pathlib import Path

VERSION="0.2.5"
class ToolError(RuntimeError): pass

@dataclass(frozen=True)
class Segment:
    index:int; file_offset:int; length:int; flags:int; min_alloc:int

def parse_segments(data:bytes)->list[Segment]:
    if len(data)<0x40 or data[:2]!=b"MZ": raise ToolError("MZ 파일이 아닙니다")
    ne=struct.unpack_from("<I",data,0x3c)[0]
    if ne+0x40>len(data) or data[ne:ne+2]!=b"NE": raise ToolError("NE 파일이 아닙니다")
    n=struct.unpack_from("<H",data,ne+0x1c)[0]
    tab=ne+struct.unpack_from("<H",data,ne+0x22)[0]
    shift=struct.unpack_from("<H",data,ne+0x32)[0]
    out=[]
    for i in range(n):
        sector,length,flags,alloc=struct.unpack_from("<HHHH",data,tab+i*8)
        out.append(Segment(i+1,sector<<shift,65536 if length==0 else length,flags,alloc))
    return out

def relocation_sources(data:bytes,seg:Segment)->set[int]:
    if not (seg.flags & 0x0100): return set()
    pos=seg.file_offset+seg.length
    if pos+2>len(data): raise ToolError("relocation count가 잘렸습니다")
    count=struct.unpack_from("<H",data,pos)[0]
    if pos+2+count*8>len(data): raise ToolError("relocation table이 잘렸습니다")
    return {struct.unpack_from("<H",data,pos+2+i*8+2)[0] for i in range(count)}

# These are segment-3 byte offsets after ED2_MONSTER_TEXTS_REVIEWED_v11.csv.
# Every edit replaces one ASCII inter-word space (20h) with the MON renderer's
# explicit line-break control (01h), so no pointer, slot, or segment length moves.
OPS=[
    ("M_113.DLL",0x0199,"^는 껍질에 숨었다.","방어력이 두 배 됐다."),
    ("M_118.DLL",0x01A3,"레밍스 플러스와","스플래셔가 나타났다"),
    ("M_202.DLL",0x01EE,"너희 따윈 이 정도","힘으로도 충분하다."),
    ("M_325.DLL",0x01A0,"는 주문이 사라져 달아날","기회를 노리고 있다."),
    ("M_502.DLL",0x0270,"앞으로 조금 남았으니","약한 소리 하지 말고"),
    ("M_509.DLL",0x029C,"^는 클럽아머의 무게로","몸을 움직일 수 없다."),
    ("M_510.DLL",0x0269,"의 해머액스가","작열하는 도끼가 됐다."),
]

# Generic dynamic battle-name preflight.
# ED2MAIN NE86:86B0 builds the current actor/monster name in DS:90F8 and
# calls the common string renderer at 87B0.  The stock renderer wraps only
# after each glyph, so a name can be split across a 34-cell line/page boundary
# (for example Red Slime at battle end).  Hook that one call and preflight the
# complete dynamic name width.  If it does not fit, advance to the next line
# before rendering the name.  This applies to all dynamic battle entity names.
ED2MAIN_NAME_SEGMENT = 86
ED2MAIN_HOOK_OFF = 0x86FD
ED2MAIN_HOOK_ORIGINAL = bytes.fromhex("E8 B0 00")
ED2MAIN_HOOK_PATCHED = bytes.fromhex("E8 00 7D")  # CALL NE86:0400 from 86FD
ED2MAIN_CAVE_OFF = 0x0400
ED2MAIN_HELPER = bytes.fromhex(
    "50535631DBBEF890AC3C06740C3C807205434346EBF243EBEF"
    "31C08AC503C33D2200760A5E5B580EE85488E982835E5B58E97C83"
)
ED2MAIN_STOCK_SEG86_LEN = 0xB844


# Dynamic-name message boundary spacing.
# Korean MON messages frequently concatenate a rendered actor/target name directly
# after a particle fragment (for example ``^는<02>``), which produces visible
# output such as ``요크슬라임B은아트라스를``.  These exact v11/v1.3.79
# stream states are shifted in-place into verified FF/00 slack.  Segment geometry
# and relocation tables stay unchanged; only explicit BE immediates that point
# inside a shifted stream move with the data.
DYNAMIC_MESSAGE_SPACING_SPECS = [
    {
        "dll":"M_001.DLL", "seg":3, "start":0x017D,
        "original":bytes.fromhex("02 B8 A6 20 C2 F7 B0 A9 B0 D4 20 B9 D9 B6 F3 BA B8 BE D2 B4 D9 2E FF"),
        "patched": bytes.fromhex("20 02 B8 A6 20 C2 F7 B0 A9 B0 D4 20 B9 D9 B6 F3 BA B8 BE D2 B4 D9 2E"),
        "pointers":[
        ],
    },
    {
        "dll":"M_106.DLL", "seg":3, "start":0x01D6,
        "original":bytes.fromhex("06 02 C0 C7 20 C6 C8 C0 BB 20 C7 AE BE FA B4 D9 0A 00"),
        "patched": bytes.fromhex("20 06 02 C0 C7 20 C6 C8 C0 BB 20 C7 AE BE FA B4 D9 0A"),
        "pointers":[
        ],
    },
    {
        "dll":"M_115.DLL", "seg":3, "start":0x01C6,
        "original":bytes.fromhex("06 02 BF A1 B0 D4 06 02 B4 C2 09 04 C0 C7 01 BE D5 BF A1 20 B3 AA C5 B8 B3 B5 B4 D9 0A 02 5E B4 C2 20 B8 D3 B8 AE B0 A1 20 BA D0 BF AD C7 DF B4 D9 0A 00 00 00 00 00 00 00 00"),
        "patched": bytes.fromhex("20 06 02 BF A1 B0 D4 20 06 02 B4 C2 20 09 04 C0 C7 01 BE D5 BF A1 20 B3 AA C5 B8 B3 B5 B4 D9 0A 02 5E B4 C2 20 B8 D3 B8 AE B0 A1 20 BA D0 BF AD C7 DF B4 D9 0A 00 00 00 00 00"),
        "pointers":[
            (0x02CE, bytes.fromhex("BE C7 01"), bytes.fromhex("BE C8 01")),
            (0x0315, bytes.fromhex("BE E3 01"), bytes.fromhex("BE E6 01")),
            (0x03AE, bytes.fromhex("BE CD 01"), bytes.fromhex("BE CF 01")),
        ],
    },
    {
        "dll":"M_120.DLL", "seg":3, "start":0x01C3,
        "original":bytes.fromhex("06 02 BF A1 B0 D4 20 B9 E6 C6 D0 B8 A6 20 B0 C7 B3 DE B4 D9 2E FF"),
        "patched": bytes.fromhex("20 06 02 BF A1 B0 D4 20 B9 E6 C6 D0 B8 A6 20 B0 C7 B3 DE B4 D9 2E"),
        "pointers":[
        ],
    },
    {
        "dll":"M_202.DLL", "seg":3, "start":0x0218,
        "original":bytes.fromhex("06 02 C0 C7 20 B0 A1 BD BF C0 BB 01 C1 B6 BF B4 B4 D9 0A 00"),
        "patched": bytes.fromhex("20 06 02 C0 C7 20 B0 A1 BD BF C0 BB 01 C1 B6 BF B4 B4 D9 0A"),
        "pointers":[
            (0x02C7, bytes.fromhex("BE 19 02"), bytes.fromhex("BE 1A 02")),
        ],
    },
    {
        "dll":"M_207.DLL", "seg":3, "start":0x01C0,
        "original":bytes.fromhex("06 02 5E B4 C2 20 C3 D6 C8 C4 C0 C7 20 C8 FB C0 BB 20 B8 F0 B5 CE 20 B8 F0 BE C6 07 02 BF A1 B0 D4 20 B7 B9 BD BA B8 A6 20 BF DC BF FC B4 D9 0A 5E B4 C2 20 B5 B5 B8 C1 C3 C6 B4 D9 0A 00"),
        "patched": bytes.fromhex("20 06 02 5E B4 C2 20 C3 D6 C8 C4 C0 C7 20 C8 FB C0 BB 20 B8 F0 B5 CE 20 B8 F0 BE C6 07 02 BF A1 B0 D4 20 B7 B9 BD BA B8 A6 20 BF DC BF FC B4 D9 0A 5E B4 C2 20 B5 B5 B8 C1 C3 C6 B4 D9 0A"),
        "pointers":[
            (0x02CF, bytes.fromhex("BE F0 01"), bytes.fromhex("BE F1 01")),
            (0x0303, bytes.fromhex("BE C1 01"), bytes.fromhex("BE C2 01")),
        ],
    },
    {
        "dll":"M_211.DLL", "seg":3, "start":0x0212,
        "original":bytes.fromhex("06 02 C0 BB 20 B3 EB B7 C8 B4 D9 2E FF"),
        "patched": bytes.fromhex("20 06 02 C0 BB 20 B3 EB B7 C8 B4 D9 2E"),
        "pointers":[
        ],
    },
    {
        "dll":"M_400.DLL", "seg":3, "start":0x0256,
        "original":bytes.fromhex("06 02 C0 C7 20 B8 F1 C0 BB FF"),
        "patched": bytes.fromhex("20 06 02 C0 C7 20 B8 F1 C0 BB"),
        "pointers":[
            (0x0491, bytes.fromhex("BE 57 02"), bytes.fromhex("BE 58 02")),
        ],
    },
    {
        "dll":"M_408.DLL", "seg":3, "start":0x01A8,
        "original":bytes.fromhex("09 04 B8 A6 20 C0 E7 C3 CB C7 DF B4 D9 2E 0A 09 05 BF A1 B0 D4 20 C0 E7 C3 CB B4 E7 C7 DF 0F 34 03 02 B4 C2 20 BF AC BC D3 20 B0 F8 B0 DD C0 BB 20 C7 DF B4 D9 21 21 07 5E B4 C2 20 B2 BF B8 AE B7 CE 20 B0 F8 B0 DD C7 DF B4 D9 2E 0A 00"),
        "patched": bytes.fromhex("20 09 04 B8 A6 20 C0 E7 C3 CB C7 DF B4 D9 2E 0A 09 05 BF A1 B0 D4 20 C0 E7 C3 CB B4 E7 C7 DF 0F 34 03 02 B4 C2 20 BF AC BC D3 20 B0 F8 B0 DD C0 BB 20 C7 DF B4 D9 21 21 07 5E B4 C2 20 B2 BF B8 AE B7 CE 20 B0 F8 B0 DD C7 DF B4 D9 2E 0A"),
        "pointers":[
            (0x027C, bytes.fromhex("BE B7 01"), bytes.fromhex("BE B8 01")),
            (0x02F9, bytes.fromhex("BE E0 01"), bytes.fromhex("BE E1 01")),
        ],
    },
]

DYNAMIC_MESSAGE_SPACING_APPLIED_ROWS = {
    ("M_001.DLL", 0x017E),
    ("M_120.DLL", 0x01C5),
    ("M_202.DLL", 0x0224),
    ("M_211.DLL", 0x0214),
    ("M_400.DLL", 0x0258),
    ("M_408.DLL", 0x01B9),
    ("M_408.DLL", 0x01CA),
}

def inspect_dynamic_message_spacing(path:Path, spec:dict)->dict:
    data=path.read_bytes(); segs=parse_segments(data); seg=segs[spec["seg"]-1]; base=seg.file_offset
    cur=data[base+spec["start"]:base+spec["start"]+len(spec["patched"])]
    rel=relocation_sources(data,seg); ptrs=[]; ok=(cur==spec["patched"])
    for off,_old,new in spec["pointers"]:
        val=data[base+off:base+off+len(new)]
        overlap=any(off<=r<off+len(new) for r in rel)
        ptrs.append({"offset":f"0x{off:04X}","bytes":val.hex(),"ok":val==new,"relocation_overlap":overlap})
        ok=ok and val==new and not overlap
    return {"ok":ok,"start":f"0x{spec['start']:04X}","stream":cur.hex(),"pointers":ptrs,
            "segment_length":seg.length,"segment_min_alloc":seg.min_alloc,"relocation_count":len(rel)}

def apply_dynamic_message_spacing(root:Path, check_only:bool=False)->tuple[int,int,dict]:
    mon=root/"MON"
    if not mon.is_dir(): mon=root/"mon"
    if not mon.is_dir(): raise ToolError("MON 폴더를 찾을 수 없습니다")
    changed=0; already=0; details={}
    for spec in DYNAMIC_MESSAGE_SPACING_SPECS:
        path=mon/spec["dll"]
        if not path.is_file(): raise ToolError(f"파일 없음: {path}")
        before=path.read_bytes(); segs=parse_segments(before); seg=segs[spec["seg"]-1]; base=seg.file_offset
        cur=before[base+spec["start"]:base+spec["start"]+len(spec["original"])]
        ptr_states=[before[base+off:base+off+len(old)] for off,old,_new in spec["pointers"]]
        rel=relocation_sources(before,seg)
        for off,old,_new in spec["pointers"]:
            if any(off<=r<off+len(old) for r in rel):
                raise ToolError(f"{spec['dll']} seg{spec['seg']}:{off:04X}: spacing pointer가 relocation source와 겹칩니다")
        if cur==spec["patched"] and all(v==new for v,(_off,_old,new) in zip(ptr_states,spec["pointers"])):
            already+=1; details[spec["dll"]]=inspect_dynamic_message_spacing(path,spec); continue
        if cur!=spec["original"]:
            raise ToolError(f"{spec['dll']} seg{spec['seg']}:{spec['start']:04X}: unknown dynamic-message spacing state: {cur.hex()}")
        for val,(off,old,_new) in zip(ptr_states,spec["pointers"]):
            if val!=old: raise ToolError(f"{spec['dll']} seg{spec['seg']}:{off:04X}: unknown spacing pointer state: {val.hex()}")
        if check_only: raise ToolError(f"{spec['dll']}: 동적 이름 사이 공백 보정이 미적용 상태입니다")
        old_reloc=relocation_blob(before,seg); after=bytearray(before)
        after[base+spec["start"]:base+spec["start"]+len(spec["patched"])]=spec["patched"]
        for off,_old,new in spec["pointers"]: after[base+off:base+off+len(new)]=new
        final=bytes(after); asegs=parse_segments(final); aseg=asegs[spec["seg"]-1]
        if len(final)!=len(before): raise ToolError(f"{spec['dll']}: spacing patch changed file size")
        if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in asegs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
            raise ToolError(f"{spec['dll']}: spacing patch changed NE geometry")
        if relocation_blob(final,aseg)!=old_reloc: raise ToolError(f"{spec['dll']}: spacing patch changed relocation table")
        atomic_preserve(path,final); changed+=1; details[spec["dll"]]=inspect_dynamic_message_spacing(path,spec)
        if not details[spec["dll"]]["ok"]: raise ToolError(f"{spec['dll']}: spacing postcondition failed")
    return changed,already,details

# M_002 Red Slime split-name restoration path.
# The source templates contain `붉은 슬라임Ａ/Ｂ`.  The stock code was written
# for the 10-byte Shift-JIS base name `赤スライム`; the Korean base name is
# 11 bytes.  v0.2.1 moved the split-time suffix copy/terminator by one byte.
# This is retained, but it was not the root cause of the *unsplit* damage/defeat
# corruption.  v0.2.2 fixes the separate initialization-time suffix-hiding
# terminator below.
RED_SLIME_DLL = "M_002.DLL"
RED_SLIME_SEGMENT = 3
RED_SLIME_CODE_OFF = 0x0364
RED_SLIME_CODE_ORIGINAL = bytes.fromhex("A1 3A 00 89 45 3A C6 45 3C 06")
RED_SLIME_CODE_PATCHED  = bytes.fromhex("A1 3B 00 89 45 3B C6 45 3D 06")
RED_SLIME_RELOC_SOURCE = 0x0365
RED_SLIME_RELOC_RECORD = bytes.fromhex("05 05 65 03 01 00 42 02")


# Initialization-time hidden-suffix terminators.
# These MONs ship templates ending in A/B labels, then overwrite the runtime
# actor-name buffer with 06h to hide the label before ordinary battle messages.
# The original offsets encode Japanese name byte lengths.  Korean CP949 names in
# these three cases are one byte longer, so the stock write lands on the final
# Hangul trail byte.  That leaves a dangling lead byte immediately before 06h;
# the ED2MAIN renderer then consumes 06h as the second byte of that Hangul glyph,
# breaking both the displayed name and its 34-cell/page accounting.
NAME_TERMINATOR_FIXES = [
    {
        "dll":"M_002.DLL", "seg":3, "off":0x0517,
        "original":bytes.fromhex("C6 06 3A 00 06"),
        "patched": bytes.fromhex("C6 06 3B 00 06"),
        "reloc_source":0x0519, "target_ordinal":0x02AA,
        "template_off":0x0030, "template":"붉은 슬라임Ａ",
        "visible":"붉은 슬라임", "expected_disp":0x003B,
    },
    {
        "dll":"M_109.DLL", "seg":3, "off":0x032F,
        "original":bytes.fromhex("C6 06 38 00 06"),
        "patched": bytes.fromhex("C6 06 39 00 06"),
        "reloc_source":0x0331, "target_ordinal":0x02AB,
        "template_off":0x0070, "template":"파워 앵글A",
        "visible":"파워 앵글", "expected_disp":0x0039,
    },
    {
        "dll":"M_206.DLL", "seg":3, "off":0x02B0,
        "original":bytes.fromhex("C6 06 38 00 06"),
        "patched": bytes.fromhex("C6 06 39 00 06"),
        "reloc_source":0x02B2, "target_ordinal":0x02AB,
        "template_off":0x0070, "template":"독 카즈라A",
        "visible":"독 카즈라", "expected_disp":0x0039,
    },
]




# M_002 split-result message composition.
# The three calls are stock-separated as:
#   <02>은 ...<06> / <02>와<06> / <02>로 되었다<0A>
# Korean needs visible spaces between the dynamically rendered A/B names, and
# the final particle must be `가` with a sentence-final period.  v11 already
# gives the first fragment a trailing space; this operation rebuilds the two
# small untracked streams in-place and moves only the two SI immediates that
# point at the third stream.  The data area has verified zero padding through
# 0x027F, so no segment growth is required.
RED_SLIME_SPLIT_STREAM_OFF = 0x026B
RED_SLIME_SPLIT_STREAM_ORIGINAL = bytes.fromhex(
    "02 BF CD 06 02 B7 CE 20 B5 C7 BE FA B4 D9 0A 00 00"
)
RED_SLIME_SPLIT_STREAM_PATCHED = bytes.fromhex(
    "02 BF CD 20 06 02 B0 A1 20 B5 C7 BE FA B4 D9 2E 0A"
)
RED_SLIME_SPLIT_PTR_PATCHES = [
    (0x0378, bytes.fromhex("BE 6F 02"), bytes.fromhex("BE 70 02")),
    (0x0461, bytes.fromhex("BE 6F 02"), bytes.fromhex("BE 70 02")),
]

def inspect_red_slime_split_message(path:Path)->dict:
    data=path.read_bytes(); segs=parse_segments(data); seg=segs[2]; base=seg.file_offset
    stream=data[base+RED_SLIME_SPLIT_STREAM_OFF:base+RED_SLIME_SPLIT_STREAM_OFF+len(RED_SLIME_SPLIT_STREAM_PATCHED)]
    ptrs=[]; rel=relocation_sources(data,seg)
    ok=(stream==RED_SLIME_SPLIT_STREAM_PATCHED)
    for off,_old,new in RED_SLIME_SPLIT_PTR_PATCHES:
        cur=data[base+off:base+off+len(new)]
        ptrs.append({"offset":f"0x{off:04X}","bytes":cur.hex(),"ok":cur==new,"relocation_overlap":any(off<=r<off+len(new) for r in rel)})
        ok=ok and cur==new and not ptrs[-1]["relocation_overlap"]
    return {"ok":ok,"stream_offset":f"0x{RED_SLIME_SPLIT_STREAM_OFF:04X}","stream":stream.hex(),"pointers":ptrs,
            "segment_length":seg.length,"segment_min_alloc":seg.min_alloc,"relocation_count":len(rel)}

def apply_red_slime_split_message(root:Path,check_only:bool=False)->tuple[int,int,dict]:
    mon=root/"MON"
    if not mon.is_dir(): mon=root/"mon"
    path=mon/RED_SLIME_DLL
    if not path.is_file(): raise ToolError(f"파일 없음: {path}")
    before=path.read_bytes(); segs=parse_segments(before); seg=segs[2]; base=seg.file_offset
    rel=relocation_sources(before,seg)
    stream=before[base+RED_SLIME_SPLIT_STREAM_OFF:base+RED_SLIME_SPLIT_STREAM_OFF+len(RED_SLIME_SPLIT_STREAM_ORIGINAL)]
    ptr_states=[]
    for off,old,new in RED_SLIME_SPLIT_PTR_PATCHES:
        if any(off<=r<off+len(old) for r in rel): raise ToolError(f"M_002 seg3:{off:04X}: split-message pointer가 relocation source와 겹칩니다")
        ptr_states.append(before[base+off:base+off+len(old)])
    if stream==RED_SLIME_SPLIT_STREAM_PATCHED and all(cur==new for cur,(_off,_old,new) in zip(ptr_states,RED_SLIME_SPLIT_PTR_PATCHES)):
        return 0,1,inspect_red_slime_split_message(path)
    if stream!=RED_SLIME_SPLIT_STREAM_ORIGINAL:
        raise ToolError(f"M_002 seg3:{RED_SLIME_SPLIT_STREAM_OFF:04X}: unknown split-message stream state: {stream.hex()}")
    for cur,(off,old,new) in zip(ptr_states,RED_SLIME_SPLIT_PTR_PATCHES):
        if cur!=old: raise ToolError(f"M_002 seg3:{off:04X}: unknown split-message pointer state: {cur.hex()}")
    if check_only: raise ToolError("M_002 붉은 슬라임 분열 결과 문구 공백/온점 보정이 미적용 상태입니다")
    old_reloc=relocation_blob(before,seg)
    after=bytearray(before)
    after[base+RED_SLIME_SPLIT_STREAM_OFF:base+RED_SLIME_SPLIT_STREAM_OFF+len(RED_SLIME_SPLIT_STREAM_PATCHED)]=RED_SLIME_SPLIT_STREAM_PATCHED
    for off,_old,new in RED_SLIME_SPLIT_PTR_PATCHES:
        after[base+off:base+off+len(new)]=new
    final=bytes(after); asegs=parse_segments(final); aseg=asegs[2]
    if len(final)!=len(before): raise ToolError("M_002 split-message patch changed file size")
    if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in asegs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
        raise ToolError("M_002 split-message patch changed NE geometry")
    if relocation_blob(final,aseg)!=old_reloc: raise ToolError("M_002 split-message patch changed relocation table")
    atomic_preserve(path,final)
    detail=inspect_red_slime_split_message(path)
    if not detail["ok"]: raise ToolError("M_002 split-message postcondition failed")
    return 1,0,detail

def inspect_hidden_suffix_terminator(path:Path, spec:dict)->dict:
    data=path.read_bytes(); segs=parse_segments(data)
    seg=segs[spec["seg"]-1]; base=seg.file_offset
    code=data[base+spec["off"]:base+spec["off"]+len(spec["patched"])]
    records=relocation_records(data,seg)
    recs=[r for r in records if struct.unpack_from("<H",r,2)[0]==spec["reloc_source"]]
    target_ok=(len(recs)==1 and recs[0][0]==0x05 and recs[0][1]==0x05
               and struct.unpack_from("<H",recs[0],6)[0]==spec["target_ordinal"])
    templ=spec["template"].encode("cp949")+b"\x06"
    tcur=data[base+spec["template_off"]:base+spec["template_off"]+len(templ)]
    visible_len=len(spec["visible"].encode("cp949"))
    # Runtime monster names begin at +30h relative to the exported slot base.
    derived_disp=0x30+visible_len
    return {
        "ok": code==spec["patched"] and target_ok and tcur==templ and derived_disp==spec["expected_disp"],
        "offset":f"seg{spec['seg']}:{spec['off']:04X}",
        "code":code.hex(), "relocation_source":f"0x{spec['reloc_source']:04X}",
        "target_ordinal":f"0x{spec['target_ordinal']:04X}", "target_ok":target_ok,
        "template":spec["template"], "visible_name":spec["visible"],
        "visible_cp949_bytes":visible_len, "derived_displacement":f"0x{derived_disp:04X}",
        "expected_displacement":f"0x{spec['expected_disp']:04X}",
        "template_ok":tcur==templ, "segment_length":seg.length,
        "segment_min_alloc":seg.min_alloc, "relocation_count":len(records),
    }


def apply_hidden_suffix_terminators(root:Path, check_only:bool=False)->tuple[int,int,dict]:
    mon=root/"MON"
    if not mon.is_dir(): mon=root/"mon"
    if not mon.is_dir(): raise ToolError("MON 폴더를 찾을 수 없습니다")
    changed=already=0; details={}
    for spec in NAME_TERMINATOR_FIXES:
        path=mon/spec["dll"]
        if not path.is_file(): raise ToolError(f"파일 없음: {path}")
        before=path.read_bytes(); segs=parse_segments(before); seg=segs[spec["seg"]-1]; base=seg.file_offset
        cur=before[base+spec["off"]:base+spec["off"]+len(spec["original"])]
        records=relocation_records(before,seg)
        recs=[r for r in records if struct.unpack_from("<H",r,2)[0]==spec["reloc_source"]]
        if len(recs)!=1 or recs[0][0]!=0x05 or recs[0][1]!=0x05 or struct.unpack_from("<H",recs[0],6)[0]!=spec["target_ordinal"]:
            raise ToolError(f"{spec['dll']} seg{spec['seg']}:{spec['reloc_source']:04X} relocation target가 예상과 다릅니다")
        templ=spec["template"].encode("cp949")+b"\x06"
        actual_t=before[base+spec["template_off"]:base+spec["template_off"]+len(templ)]
        if actual_t!=templ:
            raise ToolError(f"{spec['dll']} seg{spec['seg']}:{spec['template_off']:04X} 이름 template가 예상과 다릅니다")
        derived=0x30+len(spec["visible"].encode("cp949"))
        if derived!=spec["expected_disp"]:
            raise ToolError(f"{spec['dll']} 계산된 terminator displacement가 예상과 다릅니다")
        if cur==spec["patched"]:
            already+=1
        elif cur==spec["original"]:
            if check_only:
                raise ToolError(f"{spec['dll']} seg{spec['seg']}:{spec['off']:04X}: 이름 terminator 보정 미적용")
            old_reloc=relocation_blob(before,seg)
            after=bytearray(before)
            after[base+spec["off"]:base+spec["off"]+len(spec["patched"])]=spec["patched"]
            final=bytes(after); asegs=parse_segments(final); aseg=asegs[spec["seg"]-1]
            if len(final)!=len(before): raise ToolError(f"{spec['dll']}: file size changed")
            if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in asegs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
                raise ToolError(f"{spec['dll']}: NE geometry changed")
            if relocation_blob(final,aseg)!=old_reloc: raise ToolError(f"{spec['dll']}: relocation table changed")
            atomic_preserve(path,final); changed+=1
        else:
            raise ToolError(f"{spec['dll']} seg{spec['seg']}:{spec['off']:04X} unknown terminator state: {cur.hex()}")
        detail=inspect_hidden_suffix_terminator(path,spec)
        if not detail["ok"]: raise ToolError(f"{spec['dll']} hidden-suffix terminator postcondition failed")
        details[spec["dll"]]=detail
    return changed,already,details


def relocation_records(data:bytes,seg:Segment)->list[bytes]:
    if not (seg.flags & 0x0100): return []
    pos=seg.file_offset+seg.length
    if pos+2>len(data): raise ToolError("relocation count가 잘렸습니다")
    count=struct.unpack_from("<H",data,pos)[0]
    end=pos+2+count*8
    if end>len(data): raise ToolError("relocation table이 잘렸습니다")
    return [data[pos+2+i*8:pos+10+i*8] for i in range(count)]


def inspect_red_slime_name_layout(path:Path)->dict:
    data=path.read_bytes(); segs=parse_segments(data)
    if len(segs)<RED_SLIME_SEGMENT: raise ToolError("M_002 segment 3이 없습니다")
    seg=segs[RED_SLIME_SEGMENT-1]; base=seg.file_offset
    code=data[base+RED_SLIME_CODE_OFF:base+RED_SLIME_CODE_OFF+len(RED_SLIME_CODE_PATCHED)]
    records=relocation_records(data,seg)
    recs=[r for r in records if struct.unpack_from("<H",r,2)[0]==RED_SLIME_RELOC_SOURCE]
    return {
        "ok": code==RED_SLIME_CODE_PATCHED and recs==[RED_SLIME_RELOC_RECORD],
        "offset":"seg3:0364","code":code.hex(),
        "segment_length":seg.length,"segment_min_alloc":seg.min_alloc,
        "relocation_count":len(records),
        "relocation_record":recs[0].hex() if len(recs)==1 else None,
    }


def apply_red_slime_name_layout(root:Path,check_only:bool=False)->tuple[int,int,dict]:
    mon=root/"MON"
    if not mon.is_dir(): mon=root/"mon"
    if not mon.is_dir(): raise ToolError("MON 폴더를 찾을 수 없습니다")
    path=mon/RED_SLIME_DLL
    if not path.is_file(): raise ToolError(f"파일 없음: {path}")
    before=path.read_bytes(); segs=parse_segments(before); seg=segs[RED_SLIME_SEGMENT-1]
    base=seg.file_offset
    current=before[base+RED_SLIME_CODE_OFF:base+RED_SLIME_CODE_OFF+len(RED_SLIME_CODE_ORIGINAL)]
    records=relocation_records(before,seg)
    recs=[r for r in records if struct.unpack_from("<H",r,2)[0]==RED_SLIME_RELOC_SOURCE]
    if recs != [RED_SLIME_RELOC_RECORD]:
        raise ToolError(f"M_002 seg3:{RED_SLIME_RELOC_SOURCE:04X} relocation record가 예상과 다릅니다")
    if current==RED_SLIME_CODE_PATCHED:
        return 0,1,inspect_red_slime_name_layout(path)
    if current!=RED_SLIME_CODE_ORIGINAL:
        raise ToolError(f"M_002 seg3:{RED_SLIME_CODE_OFF:04X} unknown Red Slime name-layout state: {current.hex()}")
    if check_only:
        raise ToolError("M_002 붉은 슬라임 split-time suffix 위치 보정이 미적용 상태입니다")
    old_reloc=relocation_blob(before,seg)
    after=bytearray(before)
    after[base+RED_SLIME_CODE_OFF:base+RED_SLIME_CODE_OFF+len(RED_SLIME_CODE_PATCHED)]=RED_SLIME_CODE_PATCHED
    final=bytes(after); asegs=parse_segments(final); aseg=asegs[RED_SLIME_SEGMENT-1]
    if len(final)!=len(before): raise ToolError("M_002 file size changed")
    if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in asegs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
        raise ToolError("M_002 NE geometry changed")
    if relocation_blob(final,aseg)!=old_reloc: raise ToolError("M_002 segment 3 relocation table changed")
    atomic_preserve(path,final)
    detail=inspect_red_slime_name_layout(path)
    if not detail["ok"]: raise ToolError("M_002 Red Slime name-layout postcondition failed")
    return 1,0,detail


def relocation_blob(data:bytes,seg:Segment)->bytes:
    if not (seg.flags & 0x0100): return b""
    pos=seg.file_offset+seg.length
    if pos+2>len(data): raise ToolError("relocation count가 잘렸습니다")
    count=struct.unpack_from("<H",data,pos)[0]
    end=pos+2+count*8
    if end>len(data): raise ToolError("relocation table이 잘렸습니다")
    return data[pos:end]


def inspect_dynamic_name_guard(path:Path)->dict:
    data=path.read_bytes(); segs=parse_segments(data)
    if len(segs)<ED2MAIN_NAME_SEGMENT: raise ToolError("ED2MAIN NE86이 없습니다")
    seg=segs[ED2MAIN_NAME_SEGMENT-1]
    base=seg.file_offset
    hook=data[base+ED2MAIN_HOOK_OFF:base+ED2MAIN_HOOK_OFF+3]
    helper=data[base+ED2MAIN_CAVE_OFF:base+ED2MAIN_CAVE_OFF+len(ED2MAIN_HELPER)]
    relsrc=relocation_sources(data,seg)
    return {
        "ok": hook==ED2MAIN_HOOK_PATCHED and helper==ED2MAIN_HELPER,
        "segment_length":seg.length,"segment_min_alloc":seg.min_alloc,
        "hook":hook.hex(),"helper":helper.hex(),
        "hook_relocation_overlap": any(ED2MAIN_HOOK_OFF <= x < ED2MAIN_HOOK_OFF+3 for x in relsrc),
        "cave_relocation_overlap": any(ED2MAIN_CAVE_OFF <= x < ED2MAIN_CAVE_OFF+len(ED2MAIN_HELPER) for x in relsrc),
    }


def apply_dynamic_name_guard(root:Path,check_only:bool=False)->tuple[int,int,dict]:
    path=root/"ED2MAIN.EXE"
    if not path.is_file(): raise ToolError(f"파일 없음: {path}")
    before=path.read_bytes(); segs=parse_segments(before)
    if len(segs)<ED2MAIN_NAME_SEGMENT: raise ToolError("ED2MAIN NE86이 없습니다")
    seg=segs[ED2MAIN_NAME_SEGMENT-1]; base=seg.file_offset
    if seg.length != ED2MAIN_STOCK_SEG86_LEN or seg.min_alloc != ED2MAIN_STOCK_SEG86_LEN:
        raise ToolError(f"ED2MAIN NE86 geometry가 예상과 다릅니다: {seg.length:04X}/{seg.min_alloc:04X}")
    relsrc=relocation_sources(before,seg)
    if any(ED2MAIN_HOOK_OFF <= x < ED2MAIN_HOOK_OFF+3 for x in relsrc):
        raise ToolError("ED2MAIN dynamic-name hook가 relocation source와 겹칩니다")
    if any(ED2MAIN_CAVE_OFF <= x < ED2MAIN_CAVE_OFF+len(ED2MAIN_HELPER) for x in relsrc):
        raise ToolError("ED2MAIN dynamic-name helper cave가 relocation source와 겹칩니다")
    hook=before[base+ED2MAIN_HOOK_OFF:base+ED2MAIN_HOOK_OFF+3]
    cave=before[base+ED2MAIN_CAVE_OFF:base+ED2MAIN_CAVE_OFF+len(ED2MAIN_HELPER)]
    if hook==ED2MAIN_HOOK_PATCHED and cave==ED2MAIN_HELPER:
        return 0,1,inspect_dynamic_name_guard(path)
    if hook!=ED2MAIN_HOOK_ORIGINAL:
        raise ToolError(f"ED2MAIN NE86:{ED2MAIN_HOOK_OFF:04X} unknown hook state: {hook.hex()}")
    if cave != b"\x00"*len(ED2MAIN_HELPER):
        raise ToolError(f"ED2MAIN NE86:{ED2MAIN_CAVE_OFF:04X} helper cave가 비어 있지 않습니다")
    if check_only:
        raise ToolError("ED2MAIN dynamic battle-name preflight가 미적용 상태입니다")
    old_reloc=relocation_blob(before,seg)
    after=bytearray(before)
    after[base+ED2MAIN_HOOK_OFF:base+ED2MAIN_HOOK_OFF+3]=ED2MAIN_HOOK_PATCHED
    after[base+ED2MAIN_CAVE_OFF:base+ED2MAIN_CAVE_OFF+len(ED2MAIN_HELPER)]=ED2MAIN_HELPER
    final=bytes(after); asegs=parse_segments(final); aseg=asegs[ED2MAIN_NAME_SEGMENT-1]
    if len(final)!=len(before): raise ToolError("ED2MAIN file size changed")
    if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in asegs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
        raise ToolError("ED2MAIN NE geometry changed")
    if relocation_blob(final,aseg)!=old_reloc: raise ToolError("ED2MAIN NE86 relocation table changed")
    atomic_preserve(path,final)
    detail=inspect_dynamic_name_guard(path)
    if not detail["ok"]: raise ToolError("ED2MAIN dynamic-name guard postcondition failed")
    return 1,0,detail

# Domi B special attack is a complete attack sentence but uniquely used the
# connective 06h terminator, so the common target/damage message continued on
# the same line. Other complete attack announcements use 07h. Switch only this
# verified terminator to 07h; file/segment geometry and relocations stay intact.
DOMI_DLL="M_516.DLL"
DOMI_SEGMENT=3
DOMI_TAIL_OFF=0x018E
DOMI_ORIGINAL=bytes.fromhex("06")
DOMI_PATCHED=bytes.fromhex("07")

def inspect_domi_damage_boundary(path:Path)->dict:
    data=path.read_bytes(); segs=parse_segments(data); seg=segs[DOMI_SEGMENT-1]; base=seg.file_offset
    cur=data[base+DOMI_TAIL_OFF:base+DOMI_TAIL_OFF+len(DOMI_PATCHED)]
    rel=relocation_sources(data,seg)
    overlap=any(DOMI_TAIL_OFF <= r < DOMI_TAIL_OFF+len(DOMI_PATCHED) for r in rel)
    return {
        "ok":cur==DOMI_PATCHED and not overlap,
        "offset":f"0x{DOMI_TAIL_OFF:04X}","byte":cur.hex(),
        "segment_length":seg.length,"segment_min_alloc":seg.min_alloc,
        "relocation_overlap":overlap,"relocation_count":len(rel),
    }

def apply_domi_damage_boundary(root:Path,check_only:bool=False)->tuple[int,int,dict]:
    mon=root/"MON"
    if not mon.is_dir(): mon=root/"mon"
    if not mon.is_dir(): raise ToolError("MON 폴더를 찾을 수 없습니다")
    path=mon/DOMI_DLL
    if not path.is_file(): raise ToolError(f"파일 없음: {path}")
    before=path.read_bytes(); segs=parse_segments(before); seg=segs[DOMI_SEGMENT-1]; base=seg.file_offset
    rel=relocation_sources(before,seg)
    if any(DOMI_TAIL_OFF <= r < DOMI_TAIL_OFF+len(DOMI_PATCHED) for r in rel):
        raise ToolError(f"{DOMI_DLL} seg3:{DOMI_TAIL_OFF:04X}: relocation source와 충돌")
    cur=before[base+DOMI_TAIL_OFF:base+DOMI_TAIL_OFF+len(DOMI_ORIGINAL)]
    if cur==DOMI_PATCHED:
        return 0,1,inspect_domi_damage_boundary(path)
    if cur!=DOMI_ORIGINAL:
        raise ToolError(f"{DOMI_DLL} seg3:{DOMI_TAIL_OFF:04X}: unknown Domi message-boundary state: {cur.hex()}")
    if check_only:
        raise ToolError(f"{DOMI_DLL} 도미 특수공격/피해 문장 개행이 미적용 상태입니다")
    old_reloc=relocation_blob(before,seg)
    after=bytearray(before)
    after[base+DOMI_TAIL_OFF:base+DOMI_TAIL_OFF+len(DOMI_PATCHED)]=DOMI_PATCHED
    final=bytes(after); asegs=parse_segments(final); aseg=asegs[DOMI_SEGMENT-1]
    if len(final)!=len(before): raise ToolError(f"{DOMI_DLL}: file size changed")
    if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in asegs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
        raise ToolError(f"{DOMI_DLL}: NE geometry changed")
    if relocation_blob(final,aseg)!=old_reloc: raise ToolError(f"{DOMI_DLL}: relocation table changed")
    atomic_preserve(path,final)
    detail=inspect_domi_damage_boundary(path)
    if not detail["ok"]: raise ToolError(f"{DOMI_DLL}: Domi message-boundary postcondition failed")
    return 1,0,detail

def ctx(text:str,n:int=6)->bytes:
    b=text.encode("cp949")
    return b[-n:] if len(b)>=n else b

def ctx_after(text:str,n:int=6)->bytes:
    b=text.encode("cp949")
    return b[:n]

def atomic_preserve(path:Path,data:bytes)->None:
    mode=stat.S_IMODE(path.stat().st_mode)
    made_write=False
    if not (mode & stat.S_IWUSR):
        try:
            os.chmod(path, mode | stat.S_IWUSR)
            made_write=True
        except OSError:
            pass
    fd,tmp=tempfile.mkstemp(prefix=path.name+".monpresent.",dir=str(path.parent))
    try:
        with os.fdopen(fd,"wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        try: os.chmod(tmp, mode | stat.S_IWUSR)
        except OSError: pass
        os.replace(tmp,path)
        try: os.chmod(path,mode)
        except OSError: pass
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        if made_write:
            try: os.chmod(path,mode)
            except OSError: pass
        raise

def inspect_one(path:Path,off:int,before_text:str,after_text:str)->dict:
    d=path.read_bytes(); segs=parse_segments(d)
    if len(segs)<3: raise ToolError(f"{path.name}: segment 3 없음")
    s=segs[2]; p=s.file_offset+off
    bctx=ctx(before_text); act_before=d[p-len(bctx):p]
    act_after=d[p+1:p+1+len(ctx_after(after_text))]
    val=d[p:p+1]
    rel=relocation_sources(d,s)
    return {
        "ok": val==b"\x01" and act_before==bctx and act_after==ctx_after(after_text) and off not in rel,
        "offset":f"0x{off:04X}","byte":val.hex(),
        "before_ok":act_before==bctx,"after_ok":act_after==ctx_after(after_text),
        "relocation_source":off in rel,
        "segment_length":s.length,"segment_min_alloc":s.min_alloc,
    }

def apply(root:Path,check_only:bool=False)->dict:
    domi_changed,domi_already,domi_detail=apply_domi_damage_boundary(root,check_only=check_only)
    ed_changed,ed_already,ed_detail=apply_dynamic_name_guard(root,check_only=check_only)
    red_changed,red_already,red_detail=apply_red_slime_name_layout(root,check_only=check_only)
    term_changed,term_already,term_details=apply_hidden_suffix_terminators(root,check_only=check_only)
    split_changed,split_already,split_detail=apply_red_slime_split_message(root,check_only=check_only)
    spacing_changed,spacing_already,spacing_details=apply_dynamic_message_spacing(root,check_only=check_only)
    mon=root/"MON"
    if not mon.is_dir(): mon=root/"mon"
    if not mon.is_dir(): raise ToolError("MON 폴더를 찾을 수 없습니다")
    changed=0; already=0; details={}
    for dll,off,left,right in OPS:
        path=mon/dll
        if not path.is_file(): raise ToolError(f"파일 없음: {path}")
        before=path.read_bytes(); segs=parse_segments(before); s=segs[2]
        p=s.file_offset+off
        bctx=ctx(left); act_before=before[p-len(bctx):p]
        rctx=ctx_after(right); act_after=before[p+1:p+1+len(rctx)]
        if act_before!=bctx or act_after!=rctx:
            raise ToolError(f"{dll} seg3:{off:04X}: 주변 문자열 불일치")
        if off in relocation_sources(before,s):
            raise ToolError(f"{dll} seg3:{off:04X}: relocation source와 충돌")
        cur=before[p]
        if cur==0x01:
            already+=1
        elif cur==0x20:
            if check_only:
                raise ToolError(f"{dll} seg3:{off:04X}: linebreak 미적용")
            after=bytearray(before); after[p]=0x01
            if len(after)!=len(before): raise ToolError("파일 크기 변경")
            a_segs=parse_segments(bytes(after))
            if [(x.file_offset,x.length,x.flags,x.min_alloc) for x in a_segs] != [(x.file_offset,x.length,x.flags,x.min_alloc) for x in segs]:
                raise ToolError(f"{dll}: NE geometry 변경")
            atomic_preserve(path,bytes(after)); changed+=1
        else:
            raise ToolError(f"{dll} seg3:{off:04X}: expected 20/01, actual {cur:02X}")
        details[dll]=inspect_one(path,off,left,right)
    ok=(all(x["ok"] for x in details.values()) and domi_detail["ok"] and ed_detail["ok"] and red_detail["ok"]
        and all(x["ok"] for x in term_details.values()) and split_detail["ok"]
        and all(x["ok"] for x in spacing_details.values()))
    return {"version":VERSION,"ok":ok,"operations":len(OPS)+4+len(NAME_TERMINATOR_FIXES)+len(DYNAMIC_MESSAGE_SPACING_SPECS),
            "changed":changed+domi_changed+ed_changed+red_changed+term_changed+split_changed+spacing_changed,
            "already":already+domi_already+ed_already+red_already+term_already+split_already+spacing_already,
            "domi_damage_boundary":domi_detail,
            "dynamic_battle_name_preflight":ed_detail,
            "dynamic_message_spacing":spacing_details,
            "red_slime_split_name_layout":red_detail,
            "red_slime_split_message":split_detail,
            "hidden_suffix_terminators":term_details,"details":details}

def main()->int:
    ap=argparse.ArgumentParser(description=f"ED2 Monster Text Presentation Fix v{VERSION}")
    ap.add_argument("game",type=Path)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--apply",action="store_true"); g.add_argument("--check",action="store_true")
    a=ap.parse_args()
    try:
        r=apply(a.game.resolve(),check_only=a.check)
        print(r)
        return 0 if r["ok"] else 1
    except Exception as e:
        print(f"ERROR: {e}")
        return 1
if __name__=="__main__": raise SystemExit(main())
