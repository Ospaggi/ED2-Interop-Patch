#!/usr/bin/env python3
"""ED2 MON DLL battle-message CSV exporter/importer.

The Korean DOS MON DLLs keep display names and battle/action message strings in
NE segment 3.  Fixed-layout rows remain the default.  Audited message rows may
opt into ``message_0f`` expansion: the original slot becomes an ED2 0F redirect
and the longer payload is appended to verified NE segment-tail alignment
padding.  File size and existing offsets remain stable.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import os
import shutil
import struct
import tempfile
from dataclasses import dataclass
from pathlib import Path
from ed2_ne_slot import patch_message_slot_0f, message_redirect_matches, SlotExpansionError

VERSION = "0.2.12"
BACKUP_SUFFIX = ".bak.monster_text_v0_2_8"
DEFAULT_CSV = "ED2_MONSTER_TEXTS_REVIEWED_v14.csv"
CODE_MARKERS = (
    bytes.fromhex("B8 FF FF CB"),
    bytes.fromhex("CB 9A FF FF 00 00"),
    bytes.fromhex("9A FF FF 00 00 EA"),
    bytes.fromhex("9A FF FF 00 00 CB"),
)
GARBLED = set("뻚뼎뺽릱릦먮릨먻흫딊듗듓픲먇듑줸빷힑뗉곲롔렳쓿컋쒼쵈큅떾쥡윕픱핅햱뗻곀겿")
ALLOWED_EXTRA = set("^0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz .,!?.…~_-+%()[]/'\"：:;!?")


class ToolError(RuntimeError):
    pass


@dataclass(frozen=True)
class Segment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


@dataclass(frozen=True)
class MessageEntry:
    dll: str
    segment: int
    offset: int
    file_offset: int
    capacity: int
    source_text: str
    payload: bytes
    terminator: int | None
    code_start: int


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_segments(data: bytes) -> list[Segment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise ToolError("MZ 실행 파일이 아닙니다")
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise ToolError("16비트 NE DLL이 아닙니다")
    count = struct.unpack_from("<H", data, ne + 0x1C)[0]
    table = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne + 0x32)[0]
    out = []
    for i in range(count):
        sector, length, flags, alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        out.append(Segment(i + 1, sector << shift, 65536 if length == 0 else length, flags, alloc))
    return out


def valid_cp949_pair(a: int, b: int) -> bool:
    try:
        bytes((a, b)).decode("cp949")
        return a >= 0x80
    except UnicodeDecodeError:
        return False


def code_start(block: bytes) -> int:
    hits = [block.find(marker, 0x100) for marker in CODE_MARKERS]
    hits = [hit for hit in hits if hit >= 0]
    if not hits:
        raise ToolError("MON segment 3 코드 시작 마커를 찾지 못했습니다")
    return min(hits)


def _trim_leading_binary(raw: bytes) -> tuple[int, bytes]:
    """Trim compiler/data bytes accidentally adjacent to the first Korean text.

    Legitimate ED2 message fragments can start with '^' but none of the reviewed
    MON messages start with arbitrary Latin/data noise.  Only trim when a Korean
    syllable exists after a non-Hangul prefix.
    """
    try:
        text = raw.decode("cp949")
    except UnicodeDecodeError:
        return 0, raw
    if text.startswith("^") or (text and "가" <= text[0] <= "힣"):
        return 0, raw
    byte_pos = 0
    for ch in text:
        enc = ch.encode("cp949")
        if "가" <= ch <= "힣":
            return byte_pos, raw[byte_pos:]
        byte_pos += len(enc)
    return 0, raw


def probable_text(text: str) -> bool:
    value = text.rstrip(" ")
    hangul = [ch for ch in value if "가" <= ch <= "힣"]
    if len(hangul) < 2:
        return False
    if any(ch in GARBLED for ch in value):
        return False
    for ch in value:
        if "가" <= ch <= "힣" or ch in ALLOWED_EXTRA:
            continue
        if ch in "　！？（）［］「」『』・":
            continue
        return False
    ascii_letters = sum(ch.isascii() and ch.isalpha() for ch in value)
    if ascii_letters > len(hangul) and "HP" not in value:
        return False
    return True


def extract_messages(path: Path) -> list[MessageEntry]:
    data = path.read_bytes()
    segs = parse_segments(data)
    if len(segs) < 3:
        raise ToolError(f"{path.name}: segment 3이 없습니다")
    seg = segs[2]
    block = data[seg.file_offset:seg.file_offset + seg.length]
    stop = code_start(block)
    out: list[MessageEntry] = []
    pos = 0x110
    while pos < stop:
        start = pos
        raw = bytearray()
        while pos < stop:
            value = block[pos]
            if 0x20 <= value <= 0x7E:
                raw.append(value)
                pos += 1
                continue
            if pos + 1 < stop and valid_cp949_pair(value, block[pos + 1]):
                raw.extend(block[pos:pos + 2])
                pos += 2
                continue
            break
        if len(raw) >= 3:
            trim, payload = _trim_leading_binary(bytes(raw))
            real_start = start + trim
            if payload:
                try:
                    decoded = payload.decode("cp949")
                except UnicodeDecodeError:
                    decoded = ""
                if decoded and probable_text(decoded):
                    visible = decoded.rstrip(" ")
                    capacity = len(payload)
                    term_pos = real_start + capacity
                    terminator = block[term_pos] if term_pos < len(block) else None
                    out.append(MessageEntry(
                        dll=path.name,
                        segment=3,
                        offset=real_start,
                        file_offset=seg.file_offset + real_start,
                        capacity=capacity,
                        source_text=visible,
                        payload=payload,
                        terminator=terminator,
                        code_start=stop,
                    ))
        pos = max(pos + 1, start + 1)
    return out


def classify(text: str) -> str:
    if "나타났다" in text or "날아왔다" in text or "전투다" in text:
        return "등장"
    if len(text) <= 10 and not any(mark in text for mark in ".!?"):
        return "조각/명칭"
    if text.startswith("^") or text.startswith("는 ") or text.startswith("의 ") or text.startswith("에게"):
        return "특수행동"
    return "전투문구"


def export_csv(root: Path, out_csv: Path) -> int:
    mon = root / "MON"
    if not mon.is_dir():
        mon = root / "mon"
    if not mon.is_dir():
        raise ToolError("MON 폴더를 찾을 수 없습니다")
    rows: list[MessageEntry] = []
    for path in sorted(mon.glob("M_*.DLL")):
        rows.extend(extract_messages(path))
    fields = [
        "dll", "kind", "segment", "offset_hex", "file_offset_hex", "capacity_bytes",
        "code_start_hex", "terminator_hex", "source_payload_hex", "source_text",
        "replacement_text", "previous_replacement_text", "apply",
        "expansion_mode", "expansion_note", "status", "note",
    ]
    with out_csv.open("w", encoding="utf-8-sig", newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        for e in rows:
            w.writerow({
                "dll": e.dll,
                "kind": classify(e.source_text),
                "segment": e.segment,
                "offset_hex": f"0x{e.offset:04X}",
                "file_offset_hex": f"0x{e.file_offset:06X}",
                "capacity_bytes": e.capacity,
                "code_start_hex": f"0x{e.code_start:04X}",
                "terminator_hex": "" if e.terminator is None else f"{e.terminator:02X}",
                "source_payload_hex": e.payload.hex().upper(),
                "source_text": e.source_text,
                "replacement_text": e.source_text,
                "previous_replacement_text": "",
                "apply": "0",
                "expansion_mode": "fixed",
                "expansion_note": "고정 레이아웃. 0F 메시지 소비자임을 감사한 행만 message_0f 지정",
                "status": "미검수",
                "note": "",
            })
    return len(rows)



# M_000 has no room for the one-byte period in its fixed appearance slot and
# only two bytes of alignment padding after seg3's relocation table.  Rather
# than shorten the Korean sentence or move seg4, v0.2.9 relocates the complete
# seg3 image to a new file-end aligned sector, appends a full message block,
# and changes only seg3's NE table sector/length/min_alloc plus the local
# ``MOV SI,0158h`` immediate.  Segment ordinal 3 and all relocation records stay
# identical, so every logical segment reference is preserved.
M000_DLL = "M_000.DLL"
M000_SEGMENT = 3
M000_OLD_BASE = 0x3400
M000_OLD_LENGTH = 0x019C
M000_MESSAGE_BLOCK_OFF = 0x0158
M000_MESSAGE_TEXT_OFF = 0x015E
M000_APPEARANCE_PTR_OFF = 0x0108
M000_APPEARANCE_PTR_OLD = M000_MESSAGE_TEXT_OFF
M000_CODE_MOV_SI_OFF = 0x0174
M000_CODE_MOV_SI_OLD = bytes.fromhex("BE 58 01")
M000_CODE_MOV_SI_V028_BAD = bytes.fromhex("BE 9C 01")
M000_OLD_TEXT = "슬라임이 나타났다".encode("cp949")
M000_NEW_TEXT = "슬라임이 나타났다.".encode("cp949")
M000_PREFIX = bytes.fromhex("01 02 01 02 00 FF")
M000_TERM = b"\x07"
M000_NEW_BLOCK = M000_PREFIX + M000_NEW_TEXT + M000_TERM
M000_NEW_MESSAGE_OFF = M000_OLD_LENGTH
M000_NEW_TEXT_OFF = M000_NEW_MESSAGE_OFF + len(M000_PREFIX)
M000_NEW_LENGTH = M000_OLD_LENGTH + len(M000_NEW_BLOCK)


def _ne_segment_table_info(data: bytes) -> tuple[int, int, int, int]:
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if ne + 0x40 > len(data) or data[ne:ne+2] != b"NE":
        raise ToolError("16비트 NE DLL이 아닙니다")
    count = struct.unpack_from("<H", data, ne + 0x1C)[0]
    table = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne + 0x32)[0]
    return ne, table, shift, count


def _reloc_blob_at(data: bytes, base: int, length: int, flags: int) -> bytes:
    if not (flags & 0x0100):
        return b""
    pos = base + length
    if pos + 2 > len(data):
        raise ToolError("M_000 relocation count가 잘렸습니다")
    count = struct.unpack_from("<H", data, pos)[0]
    end = pos + 2 + count * 8
    if end > len(data):
        raise ToolError("M_000 relocation table이 잘렸습니다")
    return data[pos:end]


def inspect_m000_appearance_bytes(data: bytes) -> dict:
    ne, table, shift, count = _ne_segment_table_info(data)
    if count < M000_SEGMENT:
        raise ToolError("M_000 segment 3이 없습니다")
    pos = table + (M000_SEGMENT - 1) * 8
    sector, raw_len, flags, alloc = struct.unpack_from("<HHHH", data, pos)
    base = sector << shift
    length = 0x10000 if raw_len == 0 else raw_len
    old_block = M000_PREFIX + M000_OLD_TEXT + M000_TERM
    ptr = struct.unpack_from("<H", data, base + M000_APPEARANCE_PTR_OFF)[0] if base + M000_APPEARANCE_PTR_OFF + 2 <= len(data) else None
    code_si = data[base + M000_CODE_MOV_SI_OFF:base + M000_CODE_MOV_SI_OFF + 3]
    has_new_block = (
        base + M000_NEW_MESSAGE_OFF + len(M000_NEW_BLOCK) <= len(data)
        and data[base + M000_NEW_MESSAGE_OFF:base + M000_NEW_MESSAGE_OFF + len(M000_NEW_BLOCK)] == M000_NEW_BLOCK
    )
    relocated_geometry = (
        length == M000_NEW_LENGTH
        and base % (1 << shift) == 0
        and base >= M000_OLD_BASE
        and base + length <= len(data)
        and alloc in {0, M000_NEW_LENGTH}
    )
    applied = (
        relocated_geometry
        and has_new_block
        and ptr == M000_NEW_TEXT_OFF
        and code_si == M000_CODE_MOV_SI_OLD
    )
    v028_bad = (
        relocated_geometry
        and has_new_block
        and ptr == M000_APPEARANCE_PTR_OLD
        and code_si == M000_CODE_MOV_SI_V028_BAD
    )
    original = (
        base == M000_OLD_BASE and length == M000_OLD_LENGTH
        and ptr == M000_APPEARANCE_PTR_OLD
        and code_si == M000_CODE_MOV_SI_OLD
        and data[base + M000_MESSAGE_BLOCK_OFF:base + M000_MESSAGE_BLOCK_OFF + len(old_block)] == old_block
    )
    state = "applied" if applied else ("v0.2.8_bad" if v028_bad else ("original" if original else "unknown"))
    reloc = _reloc_blob_at(data, base, length, flags) if state != "unknown" else b""
    return {
        "ok": applied,
        "state": state,
        "file_size": len(data),
        "segment3_file_offset": base,
        "segment3_length": length,
        "segment3_min_alloc": alloc,
        "relocation_size": len(reloc),
        "appearance_pointer": ptr,
        "appearance_pointer_expected": M000_NEW_TEXT_OFF,
        "message": "슬라임이 나타났다." if applied else ("슬라임이 나타났다 (문자열만 추가되고 실제 포인터는 구 문자열)" if v028_bad else ("슬라임이 나타났다" if original else None)),
    }

def inspect_m000_appearance(path: Path) -> dict:
    return inspect_m000_appearance_bytes(path.read_bytes())


def build_m000_appearance_bytes(before: bytes) -> bytes:
    state = inspect_m000_appearance_bytes(before)
    if state["state"] == "applied":
        return before

    # v0.2.8 regression repair: the new text block was present, but the real
    # appearance-text pointer at seg3:0108 still pointed at 015Eh.  Worse,
    # seg3:0174 MOV SI (which belongs to the monster action/display routine)
    # had been redirected by mistake.  Repair only those two words/bytes.
    if state["state"] == "v0.2.8_bad":
        ne, table, shift, count = _ne_segment_table_info(before)
        pos = table + (M000_SEGMENT - 1) * 8
        sector, raw_len, flags, alloc = struct.unpack_from("<HHHH", before, pos)
        base = sector << shift
        after = bytearray(before)
        struct.pack_into("<H", after, base + M000_APPEARANCE_PTR_OFF, M000_NEW_TEXT_OFF)
        after[base + M000_CODE_MOV_SI_OFF:base + M000_CODE_MOV_SI_OFF + 3] = M000_CODE_MOV_SI_OLD
        final = bytes(after)
        post = inspect_m000_appearance_bytes(final)
        if not post["ok"]:
            raise ToolError(f"M_000 v0.2.8 regression repair postcondition 실패: {post}")
        return final

    if state["state"] != "original":
        raise ToolError(f"M_000 appearance segment state가 지원 범위와 다릅니다: {state}")

    ne, table, shift, count = _ne_segment_table_info(before)
    pos = table + (M000_SEGMENT - 1) * 8
    sector, raw_len, flags, alloc = struct.unpack_from("<HHHH", before, pos)
    base = sector << shift
    length = 0x10000 if raw_len == 0 else raw_len
    if base != M000_OLD_BASE or length != M000_OLD_LENGTH:
        raise ToolError("M_000 seg3 original geometry가 예상과 다릅니다")
    reloc = _reloc_blob_at(before, base, length, flags)
    body = bytearray(before[base:base + length])
    if body[M000_CODE_MOV_SI_OFF:M000_CODE_MOV_SI_OFF + 3] != M000_CODE_MOV_SI_OLD:
        raise ToolError("M_000 action/display MOV SI signature가 예상과 다릅니다")
    if struct.unpack_from("<H", body, M000_APPEARANCE_PTR_OFF)[0] != M000_APPEARANCE_PTR_OLD:
        raise ToolError("M_000 appearance text pointer signature가 예상과 다릅니다")
    old_block = M000_PREFIX + M000_OLD_TEXT + M000_TERM
    if body[M000_MESSAGE_BLOCK_OFF:M000_MESSAGE_BLOCK_OFF + len(old_block)] != old_block:
        raise ToolError("M_000 original appearance message signature가 예상과 다릅니다")

    # Keep all existing code/action data byte-identical. Append the complete new
    # message block, then redirect only the real appearance text pointer.
    body.extend(M000_NEW_BLOCK)
    struct.pack_into("<H", body, M000_APPEARANCE_PTR_OFF, M000_NEW_TEXT_OFF)
    if len(body) != M000_NEW_LENGTH:
        raise AssertionError("M_000 new seg3 length mismatch")

    align = 1 << shift
    new_base = (len(before) + align - 1) & ~(align - 1)
    if new_base >> shift > 0xFFFF:
        raise ToolError("M_000 relocated seg3 sector가 NE 16비트 범위를 넘습니다")
    after = bytearray(before)
    if new_base > len(after):
        after.extend(b"\x00" * (new_base - len(after)))
    after.extend(body)
    after.extend(reloc)
    struct.pack_into("<H", after, pos, new_base >> shift)
    struct.pack_into("<H", after, pos + 2, M000_NEW_LENGTH)
    if alloc and alloc < M000_NEW_LENGTH:
        struct.pack_into("<H", after, pos + 6, M000_NEW_LENGTH)

    # Only seg3 table geometry may change. Other segment entries/data stay exact.
    for idx in range(1, count + 1):
        if idx == M000_SEGMENT:
            continue
        q = table + (idx - 1) * 8
        if after[q:q + 8] != before[q:q + 8]:
            raise ToolError(f"M_000 segment {idx} table entry가 변경되었습니다")
    for idx in (1, 2, 4):
        if idx > count:
            continue
        q = table + (idx - 1) * 8
        sec, rl, fl, al = struct.unpack_from("<HHHH", before, q)
        ob = sec << shift
        ln = 0x10000 if rl == 0 else rl
        if after[ob:ob + ln] != before[ob:ob + ln]:
            raise ToolError(f"M_000 segment {idx} data가 변경되었습니다")
    new_reloc = bytes(after[new_base + M000_NEW_LENGTH:new_base + M000_NEW_LENGTH + len(reloc)])
    if new_reloc != reloc:
        raise ToolError("M_000 relocation table 복제 검증 실패")
    final = bytes(after)
    post = inspect_m000_appearance_bytes(final)
    if not post["ok"]:
        raise ToolError(f"M_000 appearance relocation postcondition 실패: {post}")
    return final

def apply_m000_appearance(root: Path, *, check_only: bool, make_backup: bool) -> tuple[int, int, dict]:
    mon = root / "MON"
    if not mon.is_dir():
        mon = root / "mon"
    path = mon / M000_DLL
    if not path.is_file():
        raise ToolError(f"MON DLL을 찾을 수 없습니다: {M000_DLL}")
    before = path.read_bytes()
    state = inspect_m000_appearance_bytes(before)
    if state["state"] == "applied":
        return 0, 1, state
    if state["state"] not in {"original", "v0.2.8_bad"}:
        raise ToolError(f"M_000 appearance segment state가 지원 범위와 다릅니다: {state}")
    if check_only:
        return 1, 0, state
    after = build_m000_appearance_bytes(before)
    if make_backup:
        backup = path.with_name(path.name + BACKUP_SUFFIX)
        if not backup.exists():
            shutil.copy2(path, backup)
    _atomic_write(path, after)
    final = inspect_m000_appearance(path)
    if not final["ok"]:
        raise ToolError(f"M_000 appearance relocation postcondition 실패: {final}")
    return 1, 0, final


PRESENTATION_BREAKS = {
    ("M_113.DLL", 0x0187): 18,
    ("M_118.DLL", 0x0194): 15,
    ("M_202.DLL", 0x01DD): 17,
    ("M_325.DLL", 0x0189): 24,
    ("M_401.DLL", 0x0218): 20,
    ("M_502.DLL", 0x025C): 20,
    ("M_509.DLL", 0x0287): 21,
    ("M_510.DLL", 0x025C): 13,
}


def encoded_replacement_for(dll: str, off: int, replacement_text: str) -> bytes:
    encoded = bytearray(replacement_text.encode("cp949"))
    idx = PRESENTATION_BREAKS.get((dll.upper(), off))
    if idx is not None:
        # M_325 reviewed v11 has no leading ^ selector (break byte 23); v12
        # adds ^ and therefore moves the same semantic boundary to byte 24.
        # v0.2.9 supports the reviewed generations and the v0.2.8 regression state so a
        # fresh AIO can establish v11 before Presentation base, while current
        # installs converge to v12 idempotently.
        if (dll.upper(), off) == ("M_325.DLL", 0x0189):
            if replacement_text.startswith("^는 쓸 주문이 없어져"):
                idx = 27
            elif idx >= len(encoded) or encoded[idx] != 0x20:
                idx = 23
        if idx >= len(encoded) or encoded[idx] != 0x20:
            raise ToolError(f"{dll} 3:{off:04X}: 명시 개행 대상 공백 위치가 예상과 다릅니다")
        encoded[idx] = 0x01
    return bytes(encoded)

def replacement_payload_for(dll: str, off: int, cap: int, replacement_text: str) -> bytes:
    """Encode one reviewed replacement while preserving known shared substrings.

    M_401.DLL:3:0x028E is unusual: another battle script jumps directly
    to offset 0x0295 to reuse ``쓰러지지 않는다.``.  A normal left-aligned
    replacement moves that substring two bytes earlier and makes the group
    line read ``우리들은러지지 않는다.``.  Keep ``쓰`` at 0x0295 by
    reserving the original two-byte prefix as FF + ASCII space.
    """
    encoded = encoded_replacement_for(dll, off, replacement_text)
    if dll.upper() == "M_401.DLL" and off == 0x028E and replacement_text == "나는 쓰러지지 않는다.":
        payload = b"\x01\xFF" + encoded
        if len(payload) != cap:
            raise ToolError(f"{dll} 3:{off:04X}: 카자즘 공유 문구 슬롯 길이 불일치")
        return payload
    if len(encoded) > cap:
        raise ToolError(f"{dll} 3:{off:04X}: 수정문 {len(encoded)}바이트 > 원래 슬롯 {cap}바이트")
    return encoded + b"\xFF" * (cap - len(encoded))


def is_known_pc98_reaudit_r1_owned_row(dll: str, off: int, data: bytes, seg) -> bool:
    """Recognize exact R1 structural ownership that intentionally supersedes
    a few v14 fixed rows.  Keep this narrow so unrelated reviewed rows are still
    validated normally.
    """
    base=seg.file_offset; key=(dll.upper(),off); cp=lambda t:t.encode('cp949')
    if key in {('M_400.DLL',0x01F5),('M_400.DLL',0x021C)}:
        # R1 redirects the following suffix slots, but preserves the literal
        # 디겐스 field in the shifted presentation stream.
        try:
            return (message_redirect_matches(data,3,0x01FD,25,cp('의 앞에 나서 주문을 받았다.')) and
                    message_redirect_matches(data,3,0x0224,23,cp('의 앞에 나서 검을 맞았다.')))
        except Exception:
            return False
    if key == ('M_401.DLL',0x02C5):
        return (data[base+0x0278:base+0x0278+15] == cp('너희 따위가 이 ') and
                data[base+0x028E:base+0x028E+23] == b'\x01'+cp('몸을 쓰러뜨릴 순 없다.') and
                data[base+0x02C5:base+0x02C5+8] == cp('우리를 ')+b'\xFF' and
                data[base+0x02CD:base+0x02CD+3] == bytes.fromhex('10 94 02'))
    return False


def expansion_mode_for(row: dict[str, str]) -> str:
    mode = (row.get("expansion_mode") or "fixed").strip().lower()
    aliases = {"": "fixed", "none": "fixed", "0": "fixed", "message": "message_0f", "0f": "message_0f"}
    mode = aliases.get(mode, mode)
    if mode not in {"fixed", "message_0f"}:
        raise ToolError(f"지원하지 않는 expansion_mode: {mode}")
    return mode


def previous_payloads_for(dll: str, off: int, cap: int, row: dict[str, str]) -> list[bytes]:
    out: list[bytes] = []
    previous_text = (row.get("previous_replacement_text") or "").strip()
    if previous_text:
        prev = previous_text.encode("cp949")
        if len(prev) > cap:
            raise ToolError(f"{dll} 3:{off:04X}: 이전 수정문 {len(prev)}바이트 > 슬롯 {cap}바이트")
        out.append(prev + b"\xFF" * (cap - len(prev)))
    # Accept the v0.1.2 Kajasum payload so an existing v1.0.42 installation
    # upgrades in place instead of requiring a clean retail base.
    if dll.upper() == "M_401.DLL" and off == 0x028E:
        old = "나는 쓰러지지 않는다.".encode("cp949")
        out.append(old + b"\xFF" * (cap - len(old)))
        out.append(b"\xFF " + old)

    # v1.3.60 Presentation Fix v0.2.2 changed the stock M_202:01DD
    # source row's byte-20 ASCII space to an explicit 01h line break even
    # though reviewed v10 itself left this row unmanaged.  v11 rewrites the
    # sentence and moves the break to byte 17, so recognize only that exact
    # official presentation payload as a known previous state.
    if dll.upper() == "M_202.DLL" and off == 0x01DD:
        try:
            old_presented = bytearray(bytes.fromhex((row.get("source_payload_hex") or "").strip()))
        except ValueError:
            old_presented = bytearray()
        if len(old_presented) == cap and cap > 20 and old_presented[20] == 0x20:
            old_presented[20] = 0x01
            out.append(bytes(old_presented))
    # v1.4.25 Presentation v0.2.5 already changed the word-boundary space in
    # M_325:0189 to 01h at byte 23. v12 prepends '^', so the final break moves
    # to byte 24. Recognize the exact old presented payload for in-place upgrade.
    if dll.upper() == "M_325.DLL" and off == 0x0189:
        old_text = (row.get("previous_replacement_text") or "").rstrip()
        if old_text:
            raw = bytearray(old_text.encode("cp949"))
            if len(raw) <= cap and len(raw) > 23 and raw[23] == 0x20:
                raw[23] = 0x01
                out.append(bytes(raw) + b"\xFF" * (cap - len(raw)))
    return out


def _load_prior_reviewed_payloads(csv_path: Path) -> dict[tuple[str, int], list[bytes]]:
    """Load exact fixed-slot payloads produced by bundled older reviewed CSVs.

    v11 can be applied directly over a v10/v9/v8 installation.  Older reviewed
    rows may contain presentation 01h breaks that are not representable by
    simply CP949-encoding ``previous_replacement_text``.  Reading the bundled
    older CSVs lets us recognize those exact, known-good states without
    weakening the signature check for unknown/custom bytes.
    """
    out: dict[tuple[str, int], list[bytes]] = {}
    current = csv_path.resolve()
    candidates = [
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v13.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v12.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v11.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v10.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v9.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v8_COMPAT.csv"),
    ]
    for old_csv in candidates:
        if not old_csv.is_file() or old_csv.resolve() == current:
            continue
        try:
            with old_csv.open("r", encoding="utf-8-sig", newline="") as fp:
                old_rows = list(csv.DictReader(fp))
        except (OSError, csv.Error):
            continue
        for old in old_rows:
            if (old.get("apply") or "").strip().lower() not in {"1", "y", "yes", "true"}:
                continue
            dll = (old.get("dll") or "").strip()
            try:
                off = int(old.get("offset_hex") or "", 0)
                cap = int(old.get("capacity_bytes") or "", 0)
            except ValueError:
                continue
            text = old.get("replacement_text", "")
            try:
                encoded = encoded_replacement_for(dll, off, text)
            except (UnicodeEncodeError, ToolError):
                continue
            # Redirected/expanded states begin with 0F in the actual DLL and
            # are already handled by the audited message_0f compatibility path.
            if len(encoded) > cap:
                continue
            try:
                payload = replacement_payload_for(dll, off, cap, text)
            except ToolError:
                continue
            key = (dll.upper(), off)
            bucket = out.setdefault(key, [])
            if payload not in bucket:
                bucket.append(payload)
    return out



def _load_prior_reviewed_redirects(csv_path: Path) -> dict[tuple[str, int], list[bytes]]:
    """Load exact prior message_0f replacement texts as encoded byte streams.

    A message_0f slot may keep a literal prefix in the original fixed slot and
    place only a 0F redirect near the end, so checking ``current[:1]`` is not
    sufficient to recognize a known prior expansion.  Keep compatibility
    strict by accepting only redirects that exactly reconstruct a bundled
    v10/v9/v8 reviewed replacement.
    """
    out: dict[tuple[str, int], list[bytes]] = {}
    current = csv_path.resolve()
    candidates = [
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v13.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v12.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v11.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v10.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v9.csv"),
        csv_path.with_name("ED2_MONSTER_TEXTS_REVIEWED_v8_COMPAT.csv"),
    ]
    for old_csv in candidates:
        if not old_csv.is_file() or old_csv.resolve() == current:
            continue
        try:
            with old_csv.open("r", encoding="utf-8-sig", newline="") as fp:
                old_rows = list(csv.DictReader(fp))
        except (OSError, csv.Error):
            continue
        for old in old_rows:
            if (old.get("apply") or "").strip().lower() not in {"1", "y", "yes", "true"}:
                continue
            if expansion_mode_for(old) != "message_0f":
                continue
            dll = (old.get("dll") or "").strip()
            try:
                off = int(old.get("offset_hex") or "", 0)
                cap = int(old.get("capacity_bytes") or "", 0)
                encoded = encoded_replacement_for(dll, off, old.get("replacement_text", ""))
            except (ValueError, UnicodeEncodeError, ToolError):
                continue
            if len(encoded) <= cap:
                continue
            key = (dll.upper(), off)
            bucket = out.setdefault(key, [])
            if encoded not in bucket:
                bucket.append(encoded)
    return out

def _atomic_write(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise



# Presentation Fix v0.2.4 inserts an ASCII word boundary before selected
# dynamic-name controls by shifting a verified MON message stream in-place.
# Reviewed v11 still owns the semantic text in a few of those streams, so a
# later v11 --check/reapply must recognize the exact post-presentation layout
# rather than treating the shifted row offset as an unknown custom mutation.
POST_PRESENTATION_SHIFTED = {
    "M_001.DLL": {"start":0x017D, "patched":bytes.fromhex("20 02 B8 A6 20 C2 F7 B0 A9 B0 D4 20 B9 D9 B6 F3 BA B8 BE D2 B4 D9 2E"), "pointers":[]},
    "M_120.DLL": {"start":0x01C3, "patched":bytes.fromhex("20 06 02 BF A1 B0 D4 20 B9 E6 C6 D0 B8 A6 20 B0 C7 B3 DE B4 D9 2E"), "pointers":[]},
    "M_202.DLL": {"start":0x0218, "patched":bytes.fromhex("20 06 02 C0 C7 20 B0 A1 BD BF C0 BB 01 C1 B6 BF B4 B4 D9 0A"), "pointers":[(0x02C7,bytes.fromhex("BE 1A 02"))]},
    "M_211.DLL": {"start":0x0212, "patched":bytes.fromhex("20 06 02 C0 BB 20 B3 EB B7 C8 B4 D9 2E"), "pointers":[]},
    "M_400.DLL": {"start":0x0256, "patched":bytes.fromhex("20 06 02 C0 C7 20 B8 F1 C0 BB"), "pointers":[(0x0491,bytes.fromhex("BE 58 02"))]},
    "M_408.DLL": {"start":0x01A8, "patched":bytes.fromhex("20 09 04 B8 A6 20 C0 E7 C3 CB C7 DF B4 D9 2E 0A 09 05 BF A1 B0 D4 20 C0 E7 C3 CB B4 E7 C7 DF 0F 34 03 02 B4 C2 20 BF AC BC D3 20 B0 F8 B0 DD C0 BB 20 C7 DF B4 D9 21 21 07 5E B4 C2 20 B2 BF B8 AE B7 CE 20 B0 F8 B0 DD C7 DF B4 D9 2E 0A"), "pointers":[(0x027C,bytes.fromhex("BE B8 01")),(0x02F9,bytes.fromhex("BE E1 01"))]},
}
POST_PRESENTATION_SHIFTED_ROWS = {
    ("M_001.DLL",0x017E), ("M_120.DLL",0x01C5), ("M_202.DLL",0x0224),
    ("M_211.DLL",0x0214), ("M_400.DLL",0x0258),
    ("M_408.DLL",0x01B9), ("M_408.DLL",0x01CA),
}


# Presentation Fix v0.2.7 consumes existing FF padding to insert one visible
# ASCII boundary after a dynamic particle and before an 1Eh literal-name field.
# The reviewed semantic rows inside these compact streams therefore shift by
# one byte even though the message entry/terminator and NE geometry stay fixed.
POST_PRESENTATION_V027 = {
    "M_127.DLL": {"start":0x0191, "patched":bytes.fromhex("02 5E B4 C2 20 1E B9 F8 B0 B3 C0 C7 20 C1 F6 C6 CE C0 CC 04 B8 A6 20 BB E7 BF EB C7 DF B4 D9 2E 20 C0 CC B1 D7 B3 AA 20 C8 BF B0 FA B0 A1 20 C0 D6 B4 D9 2E"), "pointers":[]},
    "M_400.DLL#1": {"dll":"M_400.DLL", "start":0x01F0, "patched":bytes.fromhex("02 5E B4 C2 20 1E B5 F0 B0 D5 BD BA 04 C0 C7 20 BE D5 BF A1 BC AD 20 C1 D6 B9 AE C0 BB 20 B9 DE BE D2 B4 D9 2E FF"), "pointers":[]},
    "M_400.DLL#2": {"dll":"M_400.DLL", "start":0x0217, "patched":bytes.fromhex("02 5E B4 C2 20 1E B5 F0 B0 D5 BD BA 04 C0 C7 20 BE D5 BF A1 BC AD 20 B0 CB C0 BB 20 B8 C2 BE D2 B4 D9 2E FF"), "pointers":[]},
}
POST_PRESENTATION_V027_ROWS = {
    ("M_127.DLL",0x0196): "M_127.DLL",
    ("M_127.DLL",0x01A4): "M_127.DLL",
    ("M_400.DLL",0x01F5): "M_400.DLL#1",
    ("M_400.DLL",0x01FC): "M_400.DLL#1",
    ("M_400.DLL",0x021C): "M_400.DLL#2",
    ("M_400.DLL",0x0223): "M_400.DLL#2",
}

def is_known_post_presentation_v027_state(dll: str, off: int, data: bytes, seg: Segment) -> bool:
    key=POST_PRESENTATION_V027_ROWS.get((dll.upper(),off))
    if not key: return False
    spec=POST_PRESENTATION_V027[key]
    base=seg.file_offset; start=spec["start"]; patched=spec["patched"]
    if data[base+start:base+start+len(patched)] != patched: return False
    return all(data[base+p:base+p+len(expected)] == expected for p,expected in spec.get("pointers",[]))

# Presentation Fix v0.2.6 owns a few final post-v12 streams after inserting
# dynamic-particle selectors / sentence periods into already-shifted messages.
# The semantic v12 rows remain selected in the CSV for fresh application, but a
# later v12 --check/reapply must recognize the exact v0.2.6 ownership state.
POST_PRESENTATION_V026 = {
    "M_202.DLL": {"start":0x0218, "patched":bytes.fromhex("200602C0C720B0A1BDBFC0BB01C1B6BFB4B4D92E0A000000"), "pointers":[(0x02C7,bytes.fromhex("BE1A02"))]},
    "M_210.DLL": {"start":0x01B0, "patched":bytes.fromhex("200F6E03FF025EB0A101B4DEB7C10F8E03FF0A025EB4C220B5B6C0BB20C1DFC8AD0F9603FF0A025EB4C220B5B6C0BB20C1DFC8ADC7CFC1F620B8F80F9E03FF0A"), "pointers":[(0x0347,bytes.fromhex("BEC301")),(0x0350,bytes.fromhex("BED601"))]},
    "M_211.DLL": {"start":0x0212, "patched":bytes.fromhex("2006025EC0BB20B3EBB7C8B4D92EFFFFFFFFFFFFFFFFFFFFFF"), "pointers":[]},
    "M_408.DLL": {"start":0x01A8, "patched":bytes.fromhex("200904B8A620C0E7C3CBC7DFB4D92E0A0905BFA1B0D420C0E7C3CBB4E7C7DF0F3403025EB4C220BFACBCD320B0F8B0DDC0BB20C7DFB4D92121075EB4C220B2BFB8AEB7CE20B0F8B0DDC7DFB4D92E0A00"), "pointers":[(0x027C,bytes.fromhex("BEB801")),(0x02F9,bytes.fromhex("BEE201"))]},
}
POST_PRESENTATION_V026_ROWS = {
    ("M_202.DLL",0x0224),
    ("M_210.DLL",0x01B9), ("M_210.DLL",0x01C3), ("M_210.DLL",0x01D6),
    ("M_211.DLL",0x0214),
    ("M_408.DLL",0x01B9), ("M_408.DLL",0x01CA),
}

def is_known_post_presentation_v026_state(dll: str, data: bytes, seg: Segment) -> bool:
    spec=POST_PRESENTATION_V026.get(dll.upper())
    if not spec: return False
    base=seg.file_offset; start=spec["start"]; patched=spec["patched"]
    if data[base+start:base+start+len(patched)] != patched: return False
    return all(data[base+off:base+off+len(expected)] == expected for off,expected in spec["pointers"])

def is_known_post_presentation_state(dll: str, data: bytes, seg: Segment) -> bool:
    spec=POST_PRESENTATION_SHIFTED.get(dll.upper())
    if not spec: return False
    base=seg.file_offset; start=spec["start"]; patched=spec["patched"]
    if data[base+start:base+start+len(patched)] != patched: return False
    return all(data[base+off:base+off+len(expected)] == expected for off,expected in spec["pointers"])

def apply_csv(root: Path, csv_path: Path, *, check_only: bool = False, make_backup: bool = True) -> dict[str, int]:
    mon = root / "MON"
    if not mon.is_dir():
        mon = root / "mon"
    if not mon.is_dir():
        raise ToolError("MON 폴더를 찾을 수 없습니다")
    with csv_path.open("r", encoding="utf-8-sig", newline="") as fp:
        rows = list(csv.DictReader(fp))
    m000_row = next((r for r in rows if (r.get("dll") or "").upper() == M000_DLL
                     and int(r.get("offset_hex") or "0", 0) == M000_MESSAGE_TEXT_OFF), None)
    m000_changed = m000_already = 0
    m000_detail = None
    m000_plan: tuple[Path, bytes, bytes] | None = None
    if m000_row and (m000_row.get("replacement_text") or "").strip() == "슬라임이 나타났다.":
        m000_path = mon / M000_DLL
        if not m000_path.is_file():
            raise ToolError(f"MON DLL을 찾을 수 없습니다: {M000_DLL}")
        m000_before = m000_path.read_bytes()
        m000_detail = inspect_m000_appearance_bytes(m000_before)
        if m000_detail["state"] == "applied":
            m000_already = 1
        elif m000_detail["state"] in {"original", "v0.2.8_bad"}:
            m000_changed = 1
            if not check_only:
                # Build in memory now, but DO NOT write M_000 until every normal
                # CSV row below has passed validation and all plans are complete.
                m000_after = build_m000_appearance_bytes(m000_before)
                m000_plan = (m000_path, m000_before, m000_after)
        else:
            raise ToolError(f"M_000 appearance segment state가 지원 범위와 다릅니다: {m000_detail}")
    grouped: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        if (row.get("apply") or "").strip().lower() not in {"1", "y", "yes", "true"}:
            continue
        dll = (row.get("dll") or "").strip()
        if dll:
            grouped.setdefault(dll, []).append(row)

    prior_reviewed_payloads = _load_prior_reviewed_payloads(csv_path)
    prior_reviewed_redirects = _load_prior_reviewed_redirects(csv_path)

    plans: list[tuple[Path, bytes, bytes]] = []
    changed_rows = 0
    already_rows = 0
    for dll, items in grouped.items():
        path = mon / dll
        if not path.is_file():
            raise ToolError(f"MON DLL을 찾을 수 없습니다: {dll}")
        before = path.read_bytes()
        segs = parse_segments(before)
        if len(segs) < 3:
            raise ToolError(f"{dll}: segment 3이 없습니다")
        seg = segs[2]
        after = bytearray(before)
        ranges: list[tuple[int, int]] = []
        for row in items:
            segment = int(row.get("segment") or "3", 0)
            if segment != 3:
                raise ToolError(f"{dll}: 지원하지 않는 segment {segment}")
            off = int(row["offset_hex"], 0)
            file_off = seg.file_offset + off
            declared_file = int(row["file_offset_hex"], 0)
            # M_115 reviewed-v14 final state relocates segment 3 to a new aligned
            # file location so its two PC-98-faithful messages can be stored in
            # full.  CSV offsets are segment-relative and remain valid; only the
            # historical absolute file_offset_hex naturally becomes stale after
            # that relocation.  Accept that one audited geometry and keep the
            # strict absolute-offset check for every other DLL/state.
            m115_relocated = (
                dll.upper() == "M_115.DLL"
                and seg.length == 0x040C
                and bytes(before[seg.file_offset + 0x03AE:seg.file_offset + 0x03B1]) == bytes.fromhex("BE D4 03")
                and bytes(before[seg.file_offset + 0x0315:seg.file_offset + 0x0318]) == bytes.fromhex("BE F1 03")
            )
            if file_off != declared_file and not m115_relocated:
                raise ToolError(f"{dll} 3:{off:04X}: 파일 오프셋이 현재 DLL과 다릅니다")
            cap = int(row["capacity_bytes"], 0)
            if off < 0x110 or off + cap > code_start(before[seg.file_offset:seg.file_offset + seg.length]):
                raise ToolError(f"{dll} 3:{off:04X}: 텍스트 범위가 안전한 pre-code 영역 밖입니다")
            begin, end = file_off, file_off + cap
            if any(begin < e and b < end for b, e in ranges):
                raise ToolError(f"{dll} 3:{off:04X}: CSV 범위가 중복됩니다")
            ranges.append((begin, end))
            try:
                original_payload = bytes.fromhex((row.get("source_payload_hex") or "").strip())
            except ValueError as exc:
                raise ToolError(f"{dll} 3:{off:04X}: source_payload_hex 오류") from exc
            if len(original_payload) != cap:
                raise ToolError(f"{dll} 3:{off:04X}: source payload 길이가 capacity와 다릅니다")
            replacement_text = row.get("replacement_text", "")
            try:
                encoded = encoded_replacement_for(dll, off, replacement_text)
            except UnicodeEncodeError as exc:
                raise ToolError(f"{dll} 3:{off:04X}: CP949 인코딩 불가") from exc
            mode = expansion_mode_for(row)
            current = bytes(after[begin:end])

            # Reviewed-v14 R1 structurally supersedes three otherwise-selected
            # fixed rows after the broad CSV pass has completed.
            if is_known_pc98_reaudit_r1_owned_row(dll, off, before, seg):
                already_rows += 1
                continue

            # Presentation v0.2.7 owns three compact literal-name boundary streams.
            if (dll.upper(), off) in POST_PRESENTATION_V027_ROWS and is_known_post_presentation_v027_state(dll, off, before, seg):
                already_rows += 1
                continue

            # Presentation v0.2.6 owns a handful of final post-v12 streams.
            if (dll.upper(), off) in POST_PRESENTATION_V026_ROWS and is_known_post_presentation_v026_state(dll, before, seg):
                already_rows += 1
                continue

            # Presentation v0.2.4/v0.2.5 shifts these exact message streams by one or
            # more bytes while preserving the reviewed text. Recognize the complete
            # structural signature, not merely a shifted text prefix.
            if (dll.upper(), off) in POST_PRESENTATION_SHIFTED_ROWS and is_known_post_presentation_state(dll, before, seg):
                already_rows += 1
                continue

            if len(encoded) <= cap:
                replacement_payload = replacement_payload_for(dll, off, cap, replacement_text)
                if current == replacement_payload:
                    already_rows += 1
                    continue
                accepted_sources = [original_payload]
                accepted_sources.extend(previous_payloads_for(dll, off, cap, row))
                accepted_sources.extend(prior_reviewed_payloads.get((dll.upper(), off), []))
                if current[:1] != b"\x0F" and current not in accepted_sources:
                    raise ToolError(
                        f"{dll} 3:{off:04X}: 원문/이전 수정/기적용 상태와 다른 바이트입니다 "
                        f"(current={current.hex().upper()})"
                    )
                after[begin:end] = replacement_payload
                changed_rows += 1
                continue

            if mode != "message_0f":
                raise ToolError(
                    f"{dll} 3:{off:04X}: 수정문 {len(encoded)}바이트 > 원래 슬롯 {cap}바이트. "
                    "감사된 메시지 슬롯이면 CSV expansion_mode=message_0f를 명시하십시오"
                )
            if message_redirect_matches(bytes(after), 3, off, cap, encoded):
                already_rows += 1
                continue

            # Exact upgrade path for an already-expanded official reviewed
            # state.  message_0f redirects are not guaranteed to start at the
            # first byte of the fixed slot, so recognize them by reconstructing
            # the complete redirect target, never by a loose 0F byte test.
            prior_redirect_match = any(
                message_redirect_matches(bytes(after), 3, off, cap, old_encoded)
                for old_encoded in prior_reviewed_redirects.get((dll.upper(), off), [])
            )
            prev_text = (row.get("previous_replacement_text") or "").strip()
            if prev_text and not prior_redirect_match:
                try:
                    prev_encoded = encoded_replacement_for(dll, off, prev_text)
                except (UnicodeEncodeError, ToolError):
                    prev_encoded = b""
                if len(prev_encoded) > cap:
                    prior_redirect_match = message_redirect_matches(bytes(after), 3, off, cap, prev_encoded)

            if not prior_redirect_match:
                accepted_sources = [original_payload]
                accepted_sources.extend(previous_payloads_for(dll, off, cap, row))
                accepted_sources.extend(prior_reviewed_payloads.get((dll.upper(), off), []))
                if current not in accepted_sources:
                    raise ToolError(
                        f"{dll} 3:{off:04X}: message_0f 확장 전 원문/이전 수정/기적용 서명이 다릅니다 "
                        f"(current={current.hex().upper()})"
                    )
            try:
                patched = patch_message_slot_0f(bytes(after), 3, off, cap, encoded)
            except SlotExpansionError as exc:
                raise ToolError(f"{dll} 3:{off:04X}: {exc}") from exc
            after = bytearray(patched.data)
            changed_rows += 1
        if bytes(after) != before:
            if len(after) != len(before):
                raise AssertionError(f"{dll}: 크기 변경 감지")
            # File offsets/flags stay ABI-stable. Only segment 3 length/min_alloc
            # may grow for an explicitly audited message_0f expansion.
            after_segs = parse_segments(bytes(after))
            if len(after_segs) != len(segs):
                raise ToolError(f"{dll}: NE segment 개수가 변경되었습니다")
            for bseg, aseg in zip(segs, after_segs):
                if (bseg.file_offset, bseg.flags) != (aseg.file_offset, aseg.flags):
                    raise ToolError(f"{dll}: NE segment 위치/flags가 변경되었습니다")
                if bseg.index != 3 and (bseg.length, bseg.min_alloc) != (aseg.length, aseg.min_alloc):
                    raise ToolError(f"{dll}: segment {bseg.index} 구조가 변경되었습니다")
                if bseg.index == 3 and aseg.length < bseg.length:
                    raise ToolError(f"{dll}: segment 3 길이가 감소했습니다")
            plans.append((path, before, bytes(after)))

    # Transaction rule for the relocated M_000 seg3: only enqueue it after
    # every one of the 407 CSV rows / all normal file plans has been validated.
    # A later-row failure therefore leaves M_000 completely untouched.
    if m000_plan is not None:
        plans.append(m000_plan)

    if not check_only:
        for path, before, after in plans:
            if make_backup:
                backup = path.with_name(path.name + BACKUP_SUFFIX)
                if not backup.exists():
                    shutil.copy2(path, backup)
            _atomic_write(path, after)
            if path.read_bytes() != after:
                raise ToolError(f"{path.name}: 저장 후 검증 실패")
    return {
        "csv_rows": len(rows),
        "selected_rows": sum(len(v) for v in grouped.values()),
        "changed_rows": changed_rows,
        "already_rows": already_rows,
        "changed_files": len(plans),
        "m000_changed": m000_changed,
        "m000_already": m000_already,
        "m000_appearance": m000_detail,
    }


def restore(root: Path) -> int:
    mon = root / "MON"
    if not mon.is_dir():
        mon = root / "mon"
    restored = 0
    for backup in sorted(mon.glob("M_*.DLL" + BACKUP_SUFFIX)):
        target = backup.with_name(backup.name[:-len(BACKUP_SUFFIX)])
        shutil.copy2(backup, target)
        restored += 1
    return restored


def main() -> int:
    ap = argparse.ArgumentParser(description="ED2 MON 전투/특수행동 문자열 CSV 도구")
    ap.add_argument("game", type=Path, help="영웅전설 II 게임 폴더")
    ap.add_argument("--no-backup", action="store_true", help="개별 DLL 백업을 만들지 않음 (올인원 트랜잭션용)")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--export", type=Path, metavar="CSV", help="MON 전투 문자열을 CSV로 추출")
    mode.add_argument("--apply", type=Path, metavar="CSV", help="검수 CSV를 안전하게 적용")
    mode.add_argument("--check", type=Path, metavar="CSV", help="CSV 적용 가능 여부만 검사")
    mode.add_argument("--restore", action="store_true", help="이 도구가 만든 개별 DLL 백업 복원")
    args = ap.parse_args()
    root = args.game.expanduser().resolve()
    if args.export:
        n = export_csv(root, args.export.resolve())
        print(f"exported_rows={n}")
    elif args.apply:
        print(apply_csv(root, args.apply.resolve(), check_only=False, make_backup=not args.no_backup))
    elif args.check:
        print(apply_csv(root, args.check.resolve(), check_only=True))
    else:
        print(f"restored_files={restore(root)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
