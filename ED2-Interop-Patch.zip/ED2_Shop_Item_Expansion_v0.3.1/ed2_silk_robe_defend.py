#!/usr/bin/env python3
"""Silk Robe (restored item 73) defend-only Ripark behavior for ED2.

Owned by the first-game item restoration component.  This deliberately does
NOT live in the generic ED2MAIN bug-fix component.
"""
from __future__ import annotations

import argparse
import json
import struct
import sys
from dataclasses import dataclass
from pathlib import Path

from ed2_patch_journal import record_patch, atomic_replace

VERSION = "0.3.0"
COMPONENT = "ed2_shop_item_expansion_v1"
TARGET = "ED2MAIN.EXE"
SEGMENT = 86

SILK_ITEM_ID = 73
RIPHARK_EFFECT_ID = 20
STATE_OFF = 0x24
SCRATCH_OFF = 0x2E
SCRATCH_OWNED_BIT = 0x01
DEFEND_BIT = 0x20
REFLECT_BIT = 0x40

# DEFEND: after GET_ITEM_PRM, original checks ITEM_MAGIC 15 and then the HP-full
# gate (CALC_DMG_PST).  Replace only the 8-byte ITEM_MAGIC dispatch head with a
# local helper.  The original CALC_DMG_PST far call at 3A8F remains untouched,
# including its relocation record.
DEFEND_GATE_SITE = 0x3A87
DEFEND_GATE_ORIGINAL = bytes.fromhex("A0 6D 96 3C 0F 75 01 CB")
DEFEND_GATE_HELPER = 0x1E50

# MG_RET_MG's actual status write.  Normal spell context (DS:203D == 0)
# supersedes Silk Robe temporary ownership; item context leaves ownership as-is.
RIPHARK_SET_SITE = 0x7F2D
RIPHARK_SET_ORIGINAL = bytes.fromhex("80 4D 24 40")
RIPHARK_SET_HELPER = 0x1E90

# Turn/status cleanup: replaces TEST/JZ/AND that clears only DEFEND 0x20.
# The helper additionally clears reflection iff Silk Robe itself introduced it.
DEFEND_CLEAR_SITE = 0x3CDF
DEFEND_CLEAR_ORIGINAL = bytes.fromhex("F6 45 24 20 74 13 80 65 24 DF")
DEFEND_CLEAR_HELPER = 0x1EB0

# Obsolete experiment created outside the first-game item component.  Accept
# and migrate only this exact signature so it cannot conflict with the new cave.
OLD_V102_CONTEXT_SITE = 0x3A97
OLD_V102_CONTEXT_ORIGINAL = bytes.fromhex("C6 06 3D 20 01")
OLD_V102_CONTEXT_HELPER = bytes.fromhex(
    "80 3E 6D 96 14 75 06 C6 06 3D 20 00 CB C6 06 3D 20 01 CB"
)


class SilkPatchError(RuntimeError):
    pass


@dataclass(frozen=True)
class Segment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


def parse_segments(data: bytes) -> list[Segment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise SilkPatchError("MZ 실행 파일이 아닙니다")
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if ne + 0x40 > len(data) or data[ne:ne+2] != b"NE":
        raise SilkPatchError("16비트 NE 실행 파일이 아닙니다")
    count = struct.unpack_from("<H", data, ne + 0x1C)[0]
    table = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne + 0x32)[0]
    out=[]
    for i in range(count):
        sector, raw_len, flags, min_alloc = struct.unpack_from("<HHHH", data, table+i*8)
        length = 0x10000 if raw_len == 0 else raw_len
        base = sector << shift
        if base + length > len(data):
            raise SilkPatchError(f"NE segment {i+1}이 파일 범위를 벗어납니다")
        out.append(Segment(i+1,base,length,flags,min_alloc))
    return out


def seg86(data: bytes) -> Segment:
    segs=parse_segments(data)
    if len(segs) < SEGMENT:
        raise SilkPatchError("ED2MAIN segment 86이 없습니다")
    seg=segs[SEGMENT-1]
    if seg.length <= 0x7F40:
        raise SilkPatchError("ED2MAIN segment 86이 예상보다 짧습니다")
    return seg


def near_far_call(site: int, target: int) -> bytes:
    # push cs ; call near target. Helper returns with RETF.
    rel=(target-(site+4)) & 0xFFFF
    return bytes((0x0E,0xE8,rel&0xFF,(rel>>8)&0xFF))


def _assemble_defend_gate() -> bytes:
    code=bytearray(); labels={}; fix=[]
    def emit(*x): code.extend(x)
    def label(n): labels[n]=len(code)
    def jcc(op,n): emit(op,0); fix.append((len(code)-1,n))
    emit(0x55,0x8B,0xEC)                    # push bp / mov bp,sp
    emit(0xA0,0x6D,0x96)                    # mov al,[966D] ITEM_MAGIC
    emit(0x3C,0x0F); jcc(0x74,"noeffect")  # no magic
    emit(0x3C,0x14); jcc(0x75,"normal")    # effect 20?
    emit(0x80,0x7D,0x1A,SILK_ITEM_ID); jcc(0x75,"normal") # armor id 73?
    emit(0xF6,0x45,STATE_OFF,REFLECT_BIT); jcc(0x75,"skip_mark")
    emit(0x80,0x4D,SCRATCH_OFF,SCRATCH_OWNED_BIT) # mark only if reflection absent
    label("skip_mark")
    emit(0xC7,0x46,0x02,0x97,0x3A,0x5D,0xCB)     # return to 3A97, skip HP-full gate
    label("normal")
    emit(0x80,0x65,SCRATCH_OFF,0xFE)               # clear stale ownership
    emit(0xC7,0x46,0x02,0x8F,0x3A,0x5D,0xCB)     # run original CALC_DMG_PST
    label("noeffect")
    emit(0x80,0x65,SCRATCH_OFF,0xFE)
    emit(0xC7,0x46,0x02,0x96,0x3A,0x5D,0xCB)     # original immediate RETF
    for pos,name in fix:
        rel=labels[name]-(pos+1)
        if not -128 <= rel <= 127: raise AssertionError("short branch range")
        code[pos]=rel & 0xFF
    return bytes(code)


def _assemble_riphark_set() -> bytes:
    return bytes.fromhex(
        "80 3E 3D 20 00 "  # cmp byte ptr [203D],0 ; normal spell?
        "75 04 "           # jne item context
        "80 65 2E FE "     # normal Ripark: clear Silk temporary ownership
        "80 4D 24 40 "     # original: OR reflect bit
        "CB"
    )


def _assemble_defend_clear() -> bytes:
    code=bytearray(); labels={}; fix=[]
    def emit(*x): code.extend(x)
    def label(n): labels[n]=len(code)
    def jcc(op,n): emit(op,0); fix.append((len(code)-1,n))
    emit(0x55,0x8B,0xEC)
    emit(0xF6,0x45,STATE_OFF,DEFEND_BIT); jcc(0x74,"nodef")
    emit(0x80,0x65,STATE_OFF,0xDF)                  # clear defend
    emit(0xF6,0x45,SCRATCH_OFF,SCRATCH_OWNED_BIT); jcc(0x74,"done")
    emit(0x80,0x65,STATE_OFF,0xBF)                  # clear only Silk-owned reflect
    emit(0x80,0x65,SCRATCH_OFF,0xFE)                # clear ownership marker
    label("done")
    emit(0xC7,0x46,0x02,0xE9,0x3C,0x5D,0xCB)      # continue original refresh calls
    label("nodef")
    emit(0xC7,0x46,0x02,0xF8,0x3C,0x5D,0xCB)      # original no-defend branch
    for pos,name in fix:
        rel=labels[name]-(pos+1)
        if not -128 <= rel <= 127: raise AssertionError("short branch range")
        code[pos]=rel & 0xFF
    return bytes(code)


DEFEND_GATE_CODE=_assemble_defend_gate()
RIPHARK_SET_CODE=_assemble_riphark_set()
DEFEND_CLEAR_CODE=_assemble_defend_clear()
DEFEND_GATE_PATCH=near_far_call(DEFEND_GATE_SITE,DEFEND_GATE_HELPER)+b"\x90"*4
RIPHARK_SET_PATCH=near_far_call(RIPHARK_SET_SITE,RIPHARK_SET_HELPER)
DEFEND_CLEAR_PATCH=near_far_call(DEFEND_CLEAR_SITE,DEFEND_CLEAR_HELPER)+b"\x90"*6
OLD_V102_CONTEXT_PATCH=near_far_call(OLD_V102_CONTEXT_SITE,DEFEND_GATE_HELPER)+b"\x90"

SPECS=(
    ("defend_gate",DEFEND_GATE_SITE,DEFEND_GATE_ORIGINAL,DEFEND_GATE_PATCH,DEFEND_GATE_HELPER,DEFEND_GATE_CODE),
    ("riphark_set",RIPHARK_SET_SITE,RIPHARK_SET_ORIGINAL,RIPHARK_SET_PATCH,RIPHARK_SET_HELPER,RIPHARK_SET_CODE),
    ("defend_clear",DEFEND_CLEAR_SITE,DEFEND_CLEAR_ORIGINAL,DEFEND_CLEAR_PATCH,DEFEND_CLEAR_HELPER,DEFEND_CLEAR_CODE),
)


def _slice(data: bytes|bytearray, seg: Segment, off: int, n: int) -> bytes:
    return bytes(data[seg.file_offset+off:seg.file_offset+off+n])


def _put(data: bytearray, seg: Segment, off: int, value: bytes) -> None:
    data[seg.file_offset+off:seg.file_offset+off+len(value)] = value


def _old_v102_state(data: bytes, seg: Segment) -> str:
    site=_slice(data,seg,OLD_V102_CONTEXT_SITE,len(OLD_V102_CONTEXT_ORIGINAL))
    helper=_slice(data,seg,DEFEND_GATE_HELPER,len(OLD_V102_CONTEXT_HELPER))
    if site==OLD_V102_CONTEXT_ORIGINAL and helper==b"\x00"*len(helper): return "absent"
    if site==OLD_V102_CONTEXT_PATCH and helper==OLD_V102_CONTEXT_HELPER: return "obsolete_v102"
    # Once v0.3.0 owns 1E50 the helper is intentionally nonzero, while 3A97 is original.
    if site==OLD_V102_CONTEXT_ORIGINAL and helper==DEFEND_GATE_CODE[:len(helper)]: return "superseded_v030"
    return "other"


def inspect_bytes(data: bytes) -> dict:
    seg=seg86(data); rows={}; ok=True
    for key,site,orig,patch,helper_off,helper in SPECS:
        sb=_slice(data,seg,site,len(orig)); hb=_slice(data,seg,helper_off,len(helper))
        if sb==patch and hb==helper: state="patched"
        elif sb==orig and hb==b"\x00"*len(helper): state="original"
        else: state="conflict"; ok=False
        rows[key]={"state":state,"site":f"86:{site:04X}","site_bytes":sb.hex(" "),"helper":f"86:{helper_off:04X}","helper_bytes":hb.hex(" ")}
    old=_old_v102_state(data,seg)
    if old=="other" and rows["defend_gate"]["state"]!="patched": ok=False
    # The scratch byte is deliberately chosen because the stock/current ED2MAIN
    # code contains no direct DI/BX/SI + 0x2E access before this patch.
    return {"ok":ok,"segment_file_offset":seg.file_offset,"segment_length":seg.length,"features":rows,"obsolete_v102_context":old,"scratch":"player battle record +0x2E bit0"}


def build_target(data: bytes) -> tuple[bytes,list[dict]]:
    seg=seg86(data); before=data; out=bytearray(data); changes=[]
    report=inspect_bytes(data)
    # Exact migration of the withdrawn v1.0.2 armor_riphark experiment.
    old=_old_v102_state(data,seg)
    if old=="obsolete_v102":
        _put(out,seg,OLD_V102_CONTEXT_SITE,OLD_V102_CONTEXT_ORIGINAL)
        _put(out,seg,DEFEND_GATE_HELPER,b"\x00"*len(OLD_V102_CONTEXT_HELPER))
        changes.append({"feature":"remove_obsolete_v102_context","site":"86:3A97"})
        data=bytes(out); report=inspect_bytes(data)
    elif old=="other" and report["features"]["defend_gate"]["state"]!="patched":
        raise SilkPatchError("86:3A97/1E50이 알려진 원본·v1.0.2·v0.3.0 상태가 아닙니다")

    for key,site,orig,patch,helper_off,helper in SPECS:
        sb=_slice(out,seg,site,len(orig)); hb=_slice(out,seg,helper_off,len(helper))
        if sb==patch and hb==helper: continue
        if sb!=orig:
            raise SilkPatchError(f"{key}: site 86:{site:04X} 상태 충돌: {sb.hex(' ')}")
        if hb!=b"\x00"*len(helper):
            raise SilkPatchError(f"{key}: helper cave 86:{helper_off:04X}이 비어 있지 않습니다")
        _put(out,seg,helper_off,helper); _put(out,seg,site,patch)
        changes.append({"feature":key,"site":f"86:{site:04X}","helper":f"86:{helper_off:04X}"})
    final=bytes(out)
    post=inspect_bytes(final)
    if not post["ok"] or any(r["state"]!="patched" for r in post["features"].values()):
        raise SilkPatchError("비단 옷 방어 효과 적용 후 정적 검증 실패")
    if len(final)!=len(before) or parse_segments(final)!=parse_segments(before):
        raise SilkPatchError("비단 옷 패치가 파일 크기/NE segment geometry를 변경했습니다")
    return final,changes


def apply(exe: Path) -> dict:
    before=exe.read_bytes(); after,changes=build_target(before)
    changed=0
    if after!=before:
        changed=record_patch(exe,before,after,COMPONENT)
        atomic_replace(exe,after)
    return {"version":VERSION,"changed_bytes":changed,"changes":changes,"check":inspect_bytes(exe.read_bytes())}


def check(exe: Path) -> dict:
    r=inspect_bytes(exe.read_bytes())
    r["ok"]=r["ok"] and all(x["state"]=="patched" for x in r["features"].values())
    return r


def resolve(path: str|Path) -> Path:
    p=Path(path).expanduser().resolve(); exe=p/TARGET if p.is_dir() else p
    if not exe.is_file() or exe.name.upper()!=TARGET: raise SilkPatchError(f"{TARGET}을 찾을 수 없습니다: {exe}")
    return exe


def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description=f"ED2 Silk Robe defend behavior v{VERSION}")
    ap.add_argument("path"); g=ap.add_mutually_exclusive_group(required=True); g.add_argument("--apply",action="store_true"); g.add_argument("--check",action="store_true")
    args=ap.parse_args(argv)
    try:
        exe=resolve(args.path); result=apply(exe) if args.apply else check(exe)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if (args.apply or result.get("ok")) else 1
    except Exception as e:
        print(f"오류: {e}",file=sys.stderr); return 1

if __name__=="__main__": raise SystemExit(main())
