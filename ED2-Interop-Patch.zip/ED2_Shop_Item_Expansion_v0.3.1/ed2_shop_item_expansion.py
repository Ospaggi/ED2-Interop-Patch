#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, struct, sys
from collections import defaultdict
from pathlib import Path
from ed2_ne_slot import allocate_tail, parse_segments, SlotExpansionError
from ed2_patch_journal import record_patch, atomic_replace, selective_restore, journal_path
from ed2_silk_robe_defend import apply as apply_silk_robe_defend, check as check_silk_robe_defend

APP_NAME='ED2 Shop Item Expansion'
VERSION='0.3.1'
COMPONENT='ed2_shop_item_expansion_v1'
MANIFEST=Path(__file__).with_name('shop_inventory_manifest.json')

# v1.3.86 temporarily sold the two restored staves in Yuysis.  v1.3.87 moves
# them to the persistent Cubera shop.  These descriptors are kept outside the
# current manifest because their only purpose is to recognize and safely undo
# that exact legacy tail allocation without touching unrelated SCENA bytes.
LEGACY_V1386_STAFF_SHOPS={
    'T_530.DLL': dict(segment=3, pointer_instruction_offset=0x09F6,
                      structure_offset=0x07DE, original_list_offset=0x00C8,
                      expected_items=[6,20], legacy_items=[6,20,74,75]),
    'T_532.DLL': dict(segment=3, pointer_instruction_offset=0x0C27,
                      structure_offset=0x09EE, original_list_offset=0x0113,
                      expected_items=[6,20], legacy_items=[6,20,74,75]),
}

# v1.3.87~v1.4.10 sold the two restored staves in the persistent Cubera
# weapon shop. v0.2.0 removes them from shops entirely; recognize and safely
# collapse the exact historical tail allocation back to the original list.
LEGACY_V1387_CUBERA_STAFF_SHOPS={
    'T_540.DLL': dict(segment=3, pointer_instruction_offset=0x0A22,
                      structure_offset=0x0946, original_list_offset=0x0088,
                      expected_items=[8,7,21,29], legacy_items=[8,7,21,29,74,75]),
    'T_542.DLL': dict(segment=3, pointer_instruction_offset=0x06F1,
                      structure_offset=0x0590, original_list_offset=0x006F,
                      expected_items=[8,7,21,29], legacy_items=[8,7,21,29,74,75]),
    'T_544.DLL': dict(segment=3, pointer_instruction_offset=0x032F,
                      structure_offset=0x028A, original_list_offset=0x0082,
                      expected_items=[8,7,21,29], legacy_items=[8,7,21,29,74,75]),
}

class ShopPatchError(RuntimeError): pass

def u16(data: bytes|bytearray, off:int)->int:
    return struct.unpack_from('<H',data,off)[0]

def p16(data: bytearray, off:int, value:int)->None:
    struct.pack_into('<H',data,off,value)

def load_manifest():
    raw=json.loads(MANIFEST.read_text(encoding='utf-8'))
    if raw.get('format')!='ED2 shop item expansion manifest' or int(raw.get('version',0))!=1:
        raise ShopPatchError('지원하지 않는 상점 매니페스트입니다.')
    return raw

def resolve_root(path: str|Path)->Path:
    root=Path(path).expanduser().resolve()
    if not (root/'SCENA').is_dir(): raise ShopPatchError('SCENA 폴더를 찾지 못했습니다.')
    return root

def seg_slice(raw: bytes|bytearray, seg_index:int):
    segs=parse_segments(raw)
    if not 1<=seg_index<=len(segs): raise ShopPatchError(f'세그먼트 {seg_index}가 없습니다.')
    seg=segs[seg_index-1]
    return seg, bytes(raw[seg.file_offset:seg.file_offset+seg.length])

def list_items(segdata: bytes, ptr:int)->list[int]|None:
    if not 0<=ptr<len(segdata): return None
    count=segdata[ptr]
    if not 1<=count<=32 or ptr+1+count>len(segdata): return None
    vals=list(segdata[ptr+1:ptr+1+count])
    if any(not (0<=v<=75 or 0x80<=v<=0xCB) for v in vals): return None
    return vals

def inspect_entry(raw: bytes, e:dict)->dict:
    seg, data=seg_slice(raw,int(e['segment']))
    ins=int(e['pointer_instruction_offset'])
    struct_off=int(e['structure_offset'])
    if ins+6>len(data): raise ShopPatchError(f"{e['dll']}: 포인터 명령이 세그먼트를 벗어났습니다.")
    expected_target=(struct_off+6)&0xFFFF
    if data[ins:ins+2] != b'\xC7\x06' or u16(data,ins+2)!=expected_target:
        raise ShopPatchError(f"{e['dll']}: 상점 포인터 명령 서명이 다릅니다 (0x{ins:04X}).")
    ptr=u16(data,ins+4)
    items=list_items(data,ptr)
    desired=[int(x) for x in e['desired_items']]
    original=[int(x) for x in e['expected_items']]
    legacy=[int(x) for x in e.get('legacy_items',[])]
    state='patched' if items==desired else 'stock' if ptr==int(e['original_list_offset']) and items==original else 'legacy' if legacy and items==legacy else 'unknown'
    return {'state':state,'pointer':ptr,'items':items,'segment_length':seg.length}

def apply_one_file(path:Path, entries:list[dict])->dict:
    before=path.read_bytes()
    states=[inspect_entry(before,e) for e in entries]
    if all(s['state']=='patched' for s in states):
        return {'dll':path.name,'status':'already','entries':states,'changed_bytes':0}
    bad=[(e,s) for e,s in zip(entries,states) if s['state']=='unknown']
    if bad:
        e,s=bad[0]
        raise ShopPatchError(f"{path.name}: 알려지지 않은 상점 상태입니다: call=0x{int(e['call_offset']):04X}, ptr=0x{s['pointer']:04X}, items={s['items']}")

    current=before
    # Most expanded inventories move to verified segment-tail padding.  A single
    # tightly packed stock layout (T_304 weapon list immediately before its tool
    # list) can safely grow by one byte in place once the adjacent tool list is
    # relocated.  The manifest marks and verifies that borrowed byte explicitly.
    by_seg=defaultdict(list)
    inplace=[]
    for e,st in zip(entries,states):
        if st['state']=='legacy':
            # Previous v0.2/v0.3 policy already points at a relocated list.
            # The v0.3.1 policy only removes items from those lists, so rewrite
            # the count/payload in place and leave the old trailing byte unused.
            if len(e['desired_items']) > len(st['items']):
                by_seg[int(e['segment'])].append(e)
            else:
                inplace.append(e)
            continue
        if st['state']!='stock': continue
        if e.get('inplace_expand'):
            inplace.append(e)
        else:
            by_seg[int(e['segment'])].append(e)
    allocations={}
    for seg_index, group in sorted(by_seg.items()):
        payloads=[bytes([len(e['desired_items'])]+[int(v) for v in e['desired_items']]) for e in group]
        try:
            alloc=allocate_tail(current,seg_index,payloads)
        except SlotExpansionError as exc:
            raise ShopPatchError(f'{path.name}: 상점 목록 확장 공간을 확보하지 못했습니다: {exc}') from exc
        current=alloc.data
        for e,newptr in zip(group,alloc.segment_offsets): allocations[id(e)]=newptr

    out=bytearray(current)
    segs=parse_segments(out)
    for e,st in zip(entries,states):
        if st['state'] not in {'stock','legacy'}: continue
        seg=segs[int(e['segment'])-1]
        ins_file=seg.file_offset+int(e['pointer_instruction_offset'])
        if st['state']=='legacy' and len(e['desired_items']) <= len(st['items']):
            ptr=int(st['pointer'])
            payload=bytes([len(e['desired_items'])]+[int(v) for v in e['desired_items']])
            base=seg.file_offset+ptr
            out[base:base+len(payload)]=payload
            continue
        if e.get('inplace_expand'):
            ptr=int(e['original_list_offset'])
            old_len=1+len(e['expected_items']); payload=bytes([len(e['desired_items'])]+[int(v) for v in e['desired_items']])
            extra=len(payload)-old_len
            if extra < 0: raise ShopPatchError(f"{path.name}: inplace 확장 길이 계산 오류")
            expect=bytes.fromhex(str(e.get('inplace_extra_expected_hex','')))
            if len(expect)!=extra: raise ShopPatchError(f"{path.name}: inplace 추가 바이트 서명이 잘못되었습니다.")
            base=seg.file_offset+ptr
            if bytes(out[base+old_len:base+old_len+extra])!=expect:
                raise ShopPatchError(f"{path.name}: inplace 확장 인접 바이트가 예상과 다릅니다.")
            out[base:base+len(payload)]=payload
            continue
        # Existing offsets are stable because tail allocation never inserts in-segment bytes.
        if out[ins_file:ins_file+2] != b'\xC7\x06': raise ShopPatchError(f"{path.name}: 포인터 명령이 확장 후 달라졌습니다.")
        p16(out,ins_file+4,int(allocations[id(e)]))

    after=bytes(out)
    # Validate before committing.
    for e in entries:
        s=inspect_entry(after,e)
        if s['state']!='patched':
            raise ShopPatchError(f"{path.name}: 적용 후 상점 검증 실패: {e['location']} {e['shop_type']}")
    changed=record_patch(path,before,after,COMPONENT)
    atomic_replace(path,after)
    return {'dll':path.name,'status':'patched','changed_bytes':changed,'entries':[inspect_entry(after,e) for e in entries]}

def _mod_studio_dir()->Path:
    # Full-pack layout: discover the current sibling version instead of hardcoding
    # one revision number. This avoids the import regression seen in older QoL tools.
    parent=Path(__file__).resolve().parent.parent
    hits=sorted(parent.glob('ED2-MOD-Studio-v*'))
    if not hits: raise ShopPatchError('ED2-MOD-Studio 구성요소를 찾지 못했습니다.')
    return hits[-1]

def apply_restored_item_definitions(root:Path)->dict:
    import importlib.util
    moddir=_mod_studio_dir(); modfile=moddir/'ed2_mod_studio.py'
    spec=importlib.util.spec_from_file_location('ed2_mod_studio_shop_v013',modfile)
    if spec is None or spec.loader is None: raise ShopPatchError('ED2-MOD-Studio를 불러올 수 없습니다.')
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
    csv_path=Path(__file__).with_name('ED2_RESTORED_ITEMS.csv')
    exe=root/'ED2MAIN.EXE'; before=exe.read_bytes()
    p=mod.Project(root); changed=p.import_items_csv(csv_path); p.reload()
    after=exe.read_bytes()
    if before!=after: record_patch(exe,before,after,COMPONENT)
    expected={int(r['item_id']):r for r in csv.DictReader(csv_path.open(encoding='utf-8-sig',newline=''))}
    current={x.item_id:x for x in p.items}; bad=[]
    for iid,r in expected.items():
        x=current[iid]
        checks={'name':(x.name,r['name'].strip()),'price':(x.price,int(r['price'],0)),'stat_group':(x.stat_group,int(r['stat_group'],0)),'effect_id':(x.effect_id,int(r['effect_id'],0)),'power_raw':(x.power_raw,int(r['power_raw'],0)),'secondary_raw':(x.secondary_raw,int(r['secondary_raw'],0)),'type_mask':(x.type_mask,int(r['type_mask_hex'],0)),'magic_mode':(x.magic_mode,r['magic_mode'].strip().lower())}
        mm={k:{'actual':a,'expected':e} for k,(a,e) in checks.items() if a!=e}
        if mm: bad.append({'item_id':iid,'mismatch':mm})
    if bad: raise ShopPatchError('1편 복원 아이템 정의 검증 실패: '+json.dumps(bad,ensure_ascii=False))
    return {'rows':len(expected),'rows_imported':changed,'mismatches':bad}

def check_restored_item_definitions(root:Path)->dict:
    import importlib.util
    moddir=_mod_studio_dir(); modfile=moddir/'ed2_mod_studio.py'
    spec=importlib.util.spec_from_file_location('ed2_mod_studio_shop_check_v013',modfile)
    if spec is None or spec.loader is None: raise ShopPatchError('ED2-MOD-Studio를 불러올 수 없습니다.')
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
    csv_path=Path(__file__).with_name('ED2_RESTORED_ITEMS.csv')
    expected={int(r['item_id']):r for r in csv.DictReader(csv_path.open(encoding='utf-8-sig',newline=''))}
    p=mod.Project(root); p.reload(); current={x.item_id:x for x in p.items}; bad=[]
    for iid,r in expected.items():
        x=current[iid]
        checks={'name':(x.name,r['name'].strip()),'price':(x.price,int(r['price'],0)),'stat_group':(x.stat_group,int(r['stat_group'],0)),'effect_id':(x.effect_id,int(r['effect_id'],0)),'power_raw':(x.power_raw,int(r['power_raw'],0)),'secondary_raw':(x.secondary_raw,int(r['secondary_raw'],0)),'type_mask':(x.type_mask,int(r['type_mask_hex'],0)),'magic_mode':(x.magic_mode,r['magic_mode'].strip().lower())}
        mm={k:{'actual':a,'expected':e} for k,(a,e) in checks.items() if a!=e}
        if mm: bad.append({'item_id':iid,'mismatch':mm})
    return {'ok':not bad,'rows':len(expected),'mismatches':bad}

def inspect_legacy_v1386_staff_shop(raw:bytes, e:dict)->dict:
    seg,data=seg_slice(raw,int(e['segment']))
    ins=int(e['pointer_instruction_offset']); struct_off=int(e['structure_offset'])
    if ins+6>len(data): raise ShopPatchError('legacy shop pointer instruction is out of range')
    expected_target=(struct_off+6)&0xFFFF
    if data[ins:ins+2] != b'\xC7\x06' or u16(data,ins+2)!=expected_target:
        raise ShopPatchError('legacy shop pointer instruction signature differs')
    ptr=u16(data,ins+4); items=list_items(data,ptr)
    original=[int(x) for x in e['expected_items']]; legacy=[int(x) for x in e['legacy_items']]
    if ptr==int(e['original_list_offset']) and items==original:
        return {'state':'clean','pointer':ptr,'items':items,'segment_length':seg.length}
    payload=bytes([len(legacy),*legacy])
    if items==legacy and ptr+len(payload)==seg.length and data[ptr:ptr+len(payload)]==payload:
        return {'state':'legacy_v1386','pointer':ptr,'items':items,'segment_length':seg.length,'payload_len':len(payload)}
    return {'state':'unknown','pointer':ptr,'items':items,'segment_length':seg.length}


def collapse_legacy_v1386_staff_shop(path:Path, e:dict)->dict:
    before=path.read_bytes(); state=inspect_legacy_v1386_staff_shop(before,e)
    if state['state']=='clean':
        return {'dll':path.name,'status':'already_clean','changed_bytes':0,'state':state}
    if state['state']!='legacy_v1386':
        raise ShopPatchError(f"{path.name}: v1.3.86 유이시스 상점 상태를 안전하게 식별하지 못했습니다: {state}")
    segs=parse_segments(before); seg=segs[int(e['segment'])-1]
    payload=bytes([len(e['legacy_items']),*[int(x) for x in e['legacy_items']]])
    total=len(payload); old_len=int(state['pointer']); new_len=seg.length
    if new_len != old_len+total:
        raise ShopPatchError(f'{path.name}: legacy segment length mismatch')
    current_end=seg.file_offset+new_len
    reloc_size=0; reloc=b''
    if seg.flags & 0x0100:
        if current_end+2>len(before): raise ShopPatchError(f'{path.name}: relocation count is truncated')
        reloc_count=u16(before,current_end); reloc_size=2+reloc_count*8
        if current_end+reloc_size+total>len(before): raise ShopPatchError(f'{path.name}: relocation block is truncated')
        reloc=before[current_end:current_end+reloc_size]
    # The exact v1.3.86 migration consumed zero alignment padding.  Reject a
    # modified tail instead of guessing and overwriting a user's custom bytes.
    pad_after=current_end+reloc_size
    if bytes(before[pad_after:pad_after+total]) != b'\x00'*total:
        raise ShopPatchError(f'{path.name}: legacy tail padding was modified; automatic cleanup refused')
    out=bytearray(before); old_end=seg.file_offset+old_len
    if reloc_size:
        out[old_end:old_end+reloc_size]=reloc
    out[old_end+reloc_size:old_end+reloc_size+total]=b'\x00'*total
    # Restore the pre-v1.3.86 segment size/minimum allocation and original list pointer.
    struct.pack_into('<H',out,seg.table_offset+2,old_len)
    if seg.min_alloc==new_len:
        struct.pack_into('<H',out,seg.table_offset+6,old_len)
    ins_file=seg.file_offset+int(e['pointer_instruction_offset'])
    p16(out,ins_file+4,int(e['original_list_offset']))
    after=bytes(out); final=inspect_legacy_v1386_staff_shop(after,e)
    if final['state']!='clean':
        raise ShopPatchError(f'{path.name}: legacy Yuysis shop cleanup verification failed: {final}')
    changed=record_patch(path,before,after,COMPONENT); atomic_replace(path,after)
    return {'dll':path.name,'status':'cleaned','changed_bytes':changed,'state':final}


def cleanup_legacy_v1386_staff_shops(root:Path)->dict:
    rows=[]
    for dll,e in LEGACY_V1386_STAFF_SHOPS.items():
        path=root/'SCENA'/dll
        if not path.is_file(): raise ShopPatchError(f'상점 DLL을 찾지 못했습니다: {dll}')
        rows.append(collapse_legacy_v1386_staff_shop(path,e))
    return {'ok':True,'rows':rows}


def check_legacy_v1386_staff_shops(root:Path)->dict:
    rows=[]; ok=True
    for dll,e in LEGACY_V1386_STAFF_SHOPS.items():
        path=root/'SCENA'/dll
        try: state=inspect_legacy_v1386_staff_shop(path.read_bytes(),e) if path.is_file() else {'state':'missing'}
        except Exception as exc: state={'state':'error','error':str(exc)}
        good=state.get('state')=='clean'; ok=ok and good
        rows.append({'dll':dll,'state':state})
    return {'ok':ok,'rows':rows}


def cleanup_legacy_v1387_cubera_staff_shops(root:Path)->dict:
    rows=[]
    for dll,e in LEGACY_V1387_CUBERA_STAFF_SHOPS.items():
        path=root/'SCENA'/dll
        if not path.is_file(): raise ShopPatchError(f'상점 DLL을 찾지 못했습니다: {dll}')
        rows.append(collapse_legacy_v1386_staff_shop(path,e))
    return {'ok':True,'rows':rows}


def check_legacy_v1387_cubera_staff_shops(root:Path)->dict:
    rows=[]; ok=True
    for dll,e in LEGACY_V1387_CUBERA_STAFF_SHOPS.items():
        path=root/'SCENA'/dll
        try: state=inspect_legacy_v1386_staff_shop(path.read_bytes(),e) if path.is_file() else {'state':'missing'}
        except Exception as exc: state={'state':'error','error':str(exc)}
        good=state.get('state')=='clean'; ok=ok and good
        rows.append({'dll':dll,'state':state})
    return {'ok':ok,'rows':rows}


def apply_v1387_delta(root:Path)->dict:
    """Current policy migration: remove restored staves from all shops."""
    yuysis=cleanup_legacy_v1386_staff_shops(root)
    cubera=cleanup_legacy_v1387_cubera_staff_shops(root)
    yc=check_legacy_v1386_staff_shops(root); cc=check_legacy_v1387_cubera_staff_shops(root)
    if not yc.get('ok') or not cc.get('ok'):
        raise ShopPatchError('지팡이 상점 제거 검증 실패: '+json.dumps({'yuysis':yc,'cubera':cc},ensure_ascii=False))
    return {'tool':f'{APP_NAME} {VERSION}','legacy_yuysis_cleanup':yuysis,'legacy_cubera_cleanup':cubera,'ok':True}

def apply_v1386_delta(root:Path)->dict:
    """Apply only the v1.3.86 restored-staff definition/shop delta.

    This path is used for managed/custom-compatible updates from v1.3.85 and
    intentionally does not replay unrelated historical shop inventories.
    """
    import importlib.util
    moddir=_mod_studio_dir(); modfile=moddir/'ed2_mod_studio.py'
    spec=importlib.util.spec_from_file_location('ed2_mod_studio_shop_v1386',modfile)
    if spec is None or spec.loader is None: raise ShopPatchError('ED2-MOD-Studio를 불러올 수 없습니다.')
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
    exe=root/'ED2MAIN.EXE'; mod.install_item_magic_mode_patch(exe,None,False); p=mod.Project(root); current={x.item_id:x for x in p.items}
    expected_old={
        74:{'stat_group':1,'power_raw':6,'effective':90,'magic_mode':'proportional'},
        75:{'stat_group':1,'power_raw':6,'effective':50,'magic_mode':'proportional'},
    }
    expected_new={
        74:{'stat_group':3,'power_raw':6,'effective':80,'magic_mode':'proportional'},
        75:{'stat_group':3,'power_raw':6,'effective':40,'magic_mode':'proportional'},
    }
    changed_items=[]
    for iid in (74,75):
        x=current[iid]
        def snap(z): return {'stat_group':z.stat_group,'power_raw':z.power_raw,'effective':z.secondary_effective,'magic_mode':z.magic_mode}
        now=snap(x)
        if now==expected_new[iid]: continue
        if now!=expected_old[iid]:
            raise ShopPatchError(f'아이템 {iid}가 v1.3.85/현재 정본과 다른 사용자 수정 상태입니다: {now}')
        raw = 16 if iid==74 else 8
        mod.patch_item(exe,iid,{'stat_group':3,'power_raw':6,'secondary_raw':raw,'magic_mode':'proportional'},False); changed_items.append(iid)
        p=mod.Project(root); current={z.item_id:z for z in p.items}
    man=load_manifest(); selected=[e for e in man['entries'] if e.get('migration_tag')=='v1.3.86']
    grouped=defaultdict(list)
    for e in selected: grouped[e['dll'].upper()].append(e)
    results=[]
    for dll,entries in grouped.items():
        path=root/'SCENA'/dll
        if not path.is_file(): raise ShopPatchError(f'상점 DLL을 찾지 못했습니다: {dll}')
        results.append(apply_one_file(path,entries))
    final=mod.Project(root); final_items={x.item_id:x for x in final.items}; bad=[]
    for iid,want in expected_new.items():
        x=final_items[iid]; got={'stat_group':x.stat_group,'power_raw':x.power_raw,'effective':x.secondary_effective,'magic_mode':x.magic_mode}
        if got!=want: bad.append({'item_id':iid,'actual':got,'expected':want})
    shop_bad=[]
    for e in selected:
        st=inspect_entry((root/'SCENA'/e['dll']).read_bytes(),e)
        if st.get('state')!='patched': shop_bad.append({'dll':e['dll'],'state':st})
    if bad or shop_bad: raise ShopPatchError('v1.3.86 지팡이 업데이트 검증 실패: '+json.dumps({'items':bad,'shops':shop_bad},ensure_ascii=False))
    return {'tool':f'{APP_NAME} {VERSION}','changed_items':changed_items,'changed_shop_files':sum(r['status']=='patched' for r in results),'results':results,'ok':True}

def apply(root:Path)->dict:
    item_result=apply_restored_item_definitions(root)
    silk_result=apply_silk_robe_defend(root/'ED2MAIN.EXE')
    legacy_cleanup=cleanup_legacy_v1386_staff_shops(root)
    cubera_cleanup=cleanup_legacy_v1387_cubera_staff_shops(root)
    man=load_manifest(); grouped=defaultdict(list)
    for e in man['entries']: grouped[e['dll'].upper()].append(e)
    results=[]
    for dll,entries in grouped.items():
        path=root/'SCENA'/dll
        if not path.is_file(): raise ShopPatchError(f'상점 DLL을 찾지 못했습니다: {dll}')
        states=[inspect_entry(path.read_bytes(),e) for e in entries]
        bad=next((st for st in states if st['state']=='unknown'),None)
        if bad is not None:
            raise ShopPatchError(f"{dll}: stock/current 이외의 상점 상태입니다: {bad}")
        results.append(apply_one_file(path,entries))
    check_result=check(root)
    if not check_result['ok']: raise ShopPatchError('최종 상점 검증에 실패했습니다.')
    return {'tool':f'{APP_NAME} {VERSION}','restored_items':item_result,'silk_robe_defend':silk_result,'legacy_yuysis_cleanup':legacy_cleanup,'legacy_cubera_cleanup':cubera_cleanup,'changed_files':sum(r['status']=='patched' for r in results),'results':results,'check':check_result}

def check(root:Path)->dict:
    item_check=check_restored_item_definitions(root)
    silk_check=check_silk_robe_defend(root/'ED2MAIN.EXE')
    legacy_check=check_legacy_v1386_staff_shops(root)
    cubera_check=check_legacy_v1387_cubera_staff_shops(root)
    man=load_manifest(); rows=[]; ok=bool(item_check.get('ok')) and bool(silk_check.get('ok')) and bool(legacy_check.get('ok')) and bool(cubera_check.get('ok'))
    for e in man['entries']:
        path=root/'SCENA'/e['dll']
        try:
            s=inspect_entry(path.read_bytes(),e) if path.is_file() else {'state':'missing'}
        except Exception as exc:
            s={'state':'error','error':str(exc)}
        good=s.get('state')=='patched'; ok=ok and good
        rows.append({'dll':e['dll'],'location':e['location'],'shop_type':e['shop_type'],'call_offset':f"0x{int(e['call_offset']):04X}",'desired_items':e['desired_items'],'state':s.get('state'),'pointer':None if 'pointer' not in s else f"0x{int(s['pointer']):04X}",'items':s.get('items')})
    return {'ok':ok,'restored_items':item_check,'silk_robe_defend':silk_check,'legacy_yuysis_cleanup':legacy_check,'legacy_cubera_cleanup':cubera_check,'entry_count':len(rows),'rows':rows}

def restore(root:Path)->dict:
    man=load_manifest(); names=sorted({e['dll'].upper() for e in man['entries']}); out=[]
    exe=root/'ED2MAIN.EXE'; ej=journal_path(exe,COMPONENT)
    item_restore=selective_restore(exe,COMPONENT) if ej.is_file() else 0
    for dll in names:
        path=root/'SCENA'/dll; jp=journal_path(path,COMPONENT)
        if not jp.is_file():
            out.append({'dll':dll,'status':'no_journal','restored_bytes':0}); continue
        n=selective_restore(path,COMPONENT)
        out.append({'dll':dll,'status':'restored','restored_bytes':n})
    return {'tool':f'{APP_NAME} {VERSION}','restored_item_bytes':item_restore,'results':out}

def main(argv=None)->int:
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}')
    ap.add_argument('path')
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--apply',action='store_true'); g.add_argument('--apply-v1386-delta',action='store_true'); g.add_argument('--apply-v1387-delta',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--restore',action='store_true')
    ap.add_argument('--no-gui',action='store_true')
    args=ap.parse_args(argv)
    try:
        root=resolve_root(args.path)
        result=apply(root) if args.apply else apply_v1386_delta(root) if args.apply_v1386_delta else apply_v1387_delta(root) if args.apply_v1387_delta else restore(root) if args.restore else check(root)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if (not args.check or result.get('ok')) else 1
    except Exception as exc:
        print(f'오류: {exc}',file=sys.stderr); return 1

if __name__=='__main__': raise SystemExit(main())
