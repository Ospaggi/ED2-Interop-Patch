#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, struct, tempfile
from pathlib import Path

VERSION='v14-integrated-m115'
DLL='M_115.DLL'; SEG=3
OLD_BASE=0x3400; OLD_LEN=0x03D4
PTR1_SITE=0x03AE; PTR1_OLD=0x01CF
PTR2_SITE=0x0315; PTR2_OLD=0x01E8
OLD1_START=0x01CF; OLD1_END=0x01E8
OLD2_START=0x01E8; OLD2_END=0x01FE
TEXT1_BASE='앞에 나타났다.'; TEXT1_R1='앞으로 나섰다.'; TEXT1_FINAL='앞으로 뛰어나왔다.'
TEXT2_BASE='머리가 분열했다.'; TEXT2_R1='머리가 갈라졌다.'; TEXT2_FINAL='머리가 둘로 갈라졌다.'

def cp(s:str)->bytes:return s.encode('cp949')
def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def u16(b,off):return struct.unpack_from('<H',b,off)[0]
def u32(b,off):return struct.unpack_from('<I',b,off)[0]
def ne_info(data:bytes):
    if data[:2]!=b'MZ':raise RuntimeError('MZ 헤더가 아닙니다')
    ne=u32(data,0x3c)
    if data[ne:ne+2]!=b'NE':raise RuntimeError('NE DLL이 아닙니다')
    count=u16(data,ne+0x1c);table=ne+u16(data,ne+0x22);shift=u16(data,ne+0x32);segs=[]
    for i in range(count):
        p=table+i*8;sec,rl,fl,al=struct.unpack_from('<HHHH',data,p);ln=0x10000 if rl==0 else rl
        segs.append({'i':i+1,'p':p,'base':sec<<shift,'len':ln,'flags':fl,'alloc':al})
    return ne,table,shift,segs

def reloc_blob(data:bytes,seg:dict)->bytes:
    end=seg['base']+seg['len']
    if not(seg['flags']&0x0100):return b''
    n=u16(data,end);size=2+n*8
    if end+size>len(data):raise RuntimeError('relocation table이 잘렸습니다')
    return data[end:end+size]

def prefix1():return bytes.fromhex('02 5E B4 C2 20 09 04 C0 C7 01')
def stream1(text:str):return prefix1()+cp(text)+b'\x0A'
def stream2(text:str):return b'\x02'+cp('^는 '+text)+b'\x0A'
def finals():return stream1(TEXT1_FINAL),stream2(TEXT2_FINAL)

def compact_state(data:bytes,base:int):
    a=data[base+OLD1_START:base+OLD1_END];b=data[base+OLD2_START:base+OLD2_END]
    if a==stream1(TEXT1_BASE) and b==stream2(TEXT2_BASE):return 'base'
    if a==stream1(TEXT1_R1) and b==stream2(TEXT2_R1):return 'r1'
    return None

def inspect(data:bytes)->dict:
    _,_,shift,segs=ne_info(data)
    if len(segs)<3:return {'ok':False,'state':'unknown','reason':'segment 3 없음'}
    s=segs[2];base=s['base'];ln=s['len'];s1,s2=finals();new_len=OLD_LEN+len(s1)+len(s2)
    detail={'ok':False,'state':'unknown','sha256':sha(data),'size':len(data),'segment3_base':base,'segment3_length':ln,'segment3_alloc':s['alloc'],'shift':shift}
    if ln==new_len:
        p1=OLD_LEN;p2=OLD_LEN+len(s1)
        if (data[base+p1:base+p1+len(s1)]==s1 and data[base+p2:base+p2+len(s2)]==s2 and
            data[base+PTR1_SITE:base+PTR1_SITE+3]==b'\xBE'+struct.pack('<H',p1) and data[base+PTR2_SITE:base+PTR2_SITE+3]==b'\xBE'+struct.pack('<H',p2)):
            return detail|{'ok':True,'state':'applied','stream1_offset':p1,'stream2_offset':p2,'text1':TEXT1_FINAL,'text2':'^는 '+TEXT2_FINAL}
    if base==OLD_BASE and ln==OLD_LEN and data[base+PTR1_SITE:base+PTR1_SITE+3]==b'\xBE'+struct.pack('<H',PTR1_OLD) and data[base+PTR2_SITE:base+PTR2_SITE+3]==b'\xBE'+struct.pack('<H',PTR2_OLD):
        st=compact_state(data,base)
        if st:return detail|{'state':st}
    return detail

def build(before:bytes)->bytes:
    st=inspect(before)
    if st['state']=='applied':return before
    if st['state'] not in {'base','r1'}:raise RuntimeError(f'지원하지 않는 M_115 상태: {st}')
    _,_,shift,segs=ne_info(before);s=segs[2];old_reloc=reloc_blob(before,s);body=bytearray(before[s['base']:s['base']+s['len']])
    # Canonical old copy: both v1.4.40 and R1 paths must converge exactly.
    body[OLD1_START:OLD1_END]=stream1(TEXT1_R1);body[OLD2_START:OLD2_END]=stream2(TEXT2_R1)
    s1,s2=finals();p1=len(body);body.extend(s1);p2=len(body);body.extend(s2)
    body[PTR1_SITE:PTR1_SITE+3]=b'\xBE'+struct.pack('<H',p1);body[PTR2_SITE:PTR2_SITE+3]=b'\xBE'+struct.pack('<H',p2)
    new_len=len(body);align=1<<shift;new_base=(len(before)+align-1)&~(align-1)
    if new_base>>shift>0xffff:raise RuntimeError('새 seg3 sector가 NE 16비트 범위를 넘습니다')
    out=bytearray(before)
    # Canonicalize orphaned original seg3 bytes too; after table update they are no longer loaded.
    out[s['base']+OLD1_START:s['base']+OLD1_END]=stream1(TEXT1_R1);out[s['base']+OLD2_START:s['base']+OLD2_END]=stream2(TEXT2_R1)
    if new_base>len(out):out.extend(b'\x00'*(new_base-len(out)))
    out.extend(body);out.extend(old_reloc)
    p=s['p'];struct.pack_into('<H',out,p,new_base>>shift);struct.pack_into('<H',out,p+2,new_len)
    if s['alloc'] and s['alloc']<new_len:struct.pack_into('<H',out,p+6,new_len)
    # Only seg3 geometry + canonical orphan bytes may differ inside the original file.
    allowed=set(range(s['p'],s['p']+8))|set(range(s['base']+OLD1_START,s['base']+OLD1_END))|set(range(s['base']+OLD2_START,s['base']+OLD2_END))
    for i,(x,y) in enumerate(zip(before,out[:len(before)])):
        if x!=y and i not in allowed:raise RuntimeError(f'비허용 원본 바이트 변경 @0x{i:X}')
    _,_,_,newsegs=ne_info(bytes(out))
    for i,(a,b) in enumerate(zip(segs,newsegs),1):
        if i==SEG:continue
        if before[a['p']:a['p']+8]!=out[b['p']:b['p']+8]:raise RuntimeError(f'segment {i} table 변경')
        if before[a['base']:a['base']+a['len']]!=out[b['base']:b['base']+b['len']]:raise RuntimeError(f'segment {i} data 변경')
    if bytes(out[new_base+new_len:new_base+new_len+len(old_reloc)])!=old_reloc:raise RuntimeError('seg3 relocation 복제 실패')
    final=bytes(out);post=inspect(final)
    if not post['ok']:raise RuntimeError(f'postcondition 실패: {post}')
    return final

def atomic_write(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try:os.unlink(tmp)
        except FileNotFoundError:pass
        raise

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument('game',type=Path);ap.add_argument('--check',action='store_true');a=ap.parse_args()
    mon=a.game/'MON'
    if not mon.is_dir():mon=a.game/'mon'
    p=mon/DLL
    if not p.is_file():raise SystemExit(f'파일 없음: {p}')
    before=p.read_bytes();after=build(before);detail=inspect(after);changed=after!=before
    if not detail['ok']:raise SystemExit('M_115 postcondition 실패')
    if changed and not a.check:atomic_write(p,after)
    print(json.dumps({'version':VERSION,'check_only':a.check,'changed':changed,**detail},ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
