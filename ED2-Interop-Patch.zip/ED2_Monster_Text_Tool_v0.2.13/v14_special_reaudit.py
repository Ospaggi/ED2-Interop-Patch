#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, tempfile
from pathlib import Path
from ed2_ne_slot import parse_segments, patch_message_slot_0f, message_redirect_matches

VERSION='v14-integrated-specials'

def cp(s:str)->bytes: return s.encode('cp949')

def atomic_write(path:Path,data:bytes)->None:
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except FileNotFoundError: pass
        raise

def seg3(data:bytes):
    segs=parse_segments(data)
    if len(segs)<3: raise RuntimeError('segment 3 없음')
    return segs[2]

def slice3(data:bytes,off:int,n:int)->bytes:
    s=seg3(data); return data[s.file_offset+off:s.file_offset+off+n]

def replace_exact3(data:bytes,off:int,old:bytes,new:bytes)->bytes:
    if len(old)!=len(new): raise RuntimeError(f'길이 불일치 {len(old)} != {len(new)}')
    s=seg3(data); a=s.file_offset+off; cur=data[a:a+len(old)]
    if cur==new: return data
    if cur!=old: raise RuntimeError(f'seg3:{off:04X} 예상과 다른 바이트: {cur.hex().upper()}')
    out=bytearray(data); out[a:a+len(old)]=new; return bytes(out)

def patch_m001(data:bytes)->bytes:
    desired=cp('^를 차가운 시선으로 바라보았다.')
    # Presentation v0.2.7 shifted the semantic payload by +1.  Keep the
    # dynamic-name control and spacing prefix intact; redirect only the text.
    if message_redirect_matches(data,3,0x017F,27,desired): return data
    if slice3(data,0x017A,5) != bytes.fromhex('5E B4 C2 20 02'):
        raise RuntimeError('M_001 dynamic-name prefix state 불일치')
    old=cp('를 차갑게 바라보았다.') + b'\xFF'*6
    if slice3(data,0x017F,27)!=old or slice3(data,0x019A,1)!=b'\x0A':
        raise RuntimeError('M_001 v1.4.40 presentation state 불일치')
    return patch_message_slot_0f(data,3,0x017F,27,desired).data

def patch_m115(data:bytes)->bytes:
    data=replace_exact3(data,0x01D9,cp('앞에 나타났다.'),cp('앞으로 나섰다.'))
    data=replace_exact3(data,0x01ED,cp('머리가 분열했다.'),cp('머리가 갈라졌다.'))
    return data

def patch_m400(data:bytes)->bytes:
    d1=cp('의 앞에 나서 주문을 받았다.')
    d2=cp('의 앞에 나서 검을 맞았다.')
    if not message_redirect_matches(data,3,0x01FD,25,d1):
        if slice3(data,0x01F0,13)!=bytes.fromhex('02 5E B4 C2 20 1E B5 F0 B0 D5 BD BA 04'):
            raise RuntimeError('M_400 주문 방어 prefix state 불일치')
        old=cp('의 앞에서 주문을 받았다.')+b'\xFF'
        if slice3(data,0x01FD,25)!=old or slice3(data,0x0216,1)!=b'\x07':
            raise RuntimeError('M_400 주문 방어 v1.4.40 state 불일치')
        data=patch_message_slot_0f(data,3,0x01FD,25,d1).data
    if not message_redirect_matches(data,3,0x0224,23,d2):
        if slice3(data,0x0217,13)!=bytes.fromhex('02 5E B4 C2 20 1E B5 F0 B0 D5 BD BA 04'):
            raise RuntimeError('M_400 검 방어 prefix state 불일치')
        old=cp('의 앞에서 검을 맞았다.')+b'\xFF'
        if slice3(data,0x0224,23)!=old or slice3(data,0x023B,1)!=b'\x07':
            raise RuntimeError('M_400 검 방어 v1.4.40 state 불일치')
        data=patch_message_slot_0f(data,3,0x0224,23,d2).data
    return data

def patch_m401(data:bytes)->bytes:
    old1=cp('너희 따위에겐 ')+b'\xFF'
    new1=cp('너희 따위가 이 ')
    old2=b'\x01\xFF'+cp('나는 쓰러지지 않는다.')
    new2=b'\x01'+cp('몸을 쓰러뜨릴 순 없다.')
    old3=cp('우리는 ')+b'\xFF'
    new3=cp('우리를 ')+b'\xFF'
    data=replace_exact3(data,0x0278,old1,new1)
    data=replace_exact3(data,0x028E,old2,new2)
    data=replace_exact3(data,0x02C5,old3,new3)
    data=replace_exact3(data,0x02CD,bytes.fromhex('10 95 02'),bytes.fromhex('10 94 02'))
    return data

PATCHERS={'M_001.DLL':patch_m001,'M_115.DLL':patch_m115,'M_400.DLL':patch_m400,'M_401.DLL':patch_m401}

def inspect_one(name:str,data:bytes)->dict:
    if name=='M_001.DLL':
        ok=message_redirect_matches(data,3,0x017F,27,cp('^를 차가운 시선으로 바라보았다.'))
    elif name=='M_115.DLL':
        ok=slice3(data,0x01D9,len(cp('앞으로 나섰다.')))==cp('앞으로 나섰다.') and slice3(data,0x01ED,len(cp('머리가 갈라졌다.')))==cp('머리가 갈라졌다.')
    elif name=='M_400.DLL':
        ok=message_redirect_matches(data,3,0x01FD,25,cp('의 앞에 나서 주문을 받았다.')) and message_redirect_matches(data,3,0x0224,23,cp('의 앞에 나서 검을 맞았다.'))
    elif name=='M_401.DLL':
        ok=(slice3(data,0x0278,15)==cp('너희 따위가 이 ') and slice3(data,0x028E,23)==b'\x01'+cp('몸을 쓰러뜨릴 순 없다.') and slice3(data,0x02C5,8)==cp('우리를 ')+b'\xFF' and slice3(data,0x02CD,3)==bytes.fromhex('10 94 02') and slice3(data,0x0294,len(cp('쓰러뜨릴 순 없다.')))==cp('쓰러뜨릴 순 없다.'))
    else: ok=False
    return {'ok':ok,'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)}

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('game',type=Path)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    mon=args.game/'MON'
    if not mon.is_dir(): mon=args.game/'mon'
    report={'version':VERSION,'check_only':args.check,'files':{},'changed_files':0}
    plans=[]
    for name,fn in PATCHERS.items():
        p=mon/name
        if not p.is_file(): raise SystemExit(f'파일 없음: {p}')
        before=p.read_bytes()
        try: after=fn(before)
        except Exception as e: raise SystemExit(f'{name}: {e}')
        changed=after!=before
        if changed: report['changed_files']+=1
        detail=inspect_one(name,after)
        detail['changed']=changed
        if not detail['ok']: raise SystemExit(f'{name}: postcondition 실패')
        report['files'][name]=detail
        if changed: plans.append((p,after))
    if not args.check:
        for p,data in plans: atomic_write(p,data)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
