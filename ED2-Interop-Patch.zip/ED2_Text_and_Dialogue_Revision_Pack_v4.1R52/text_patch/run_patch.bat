@echo off
setlocal
python "%~dp0patch_ed2_text.py" "%~1"
pause
