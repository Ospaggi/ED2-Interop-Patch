#!/usr/bin/env python3
"""영웅전설 II 한국판 통합 텍스트 패치 v1.7.15R50.

한 번의 실행으로 다음을 처리한다.
- ED2MAIN.EXE UI 문구, 능력치 용어, 고유명사
- SCENA/*.DLL 및 ENDING.DLL의 직접 고유명사 문자열
- ENDING.DLL 엔딩 대사의 맞춤법·띄어쓰기·문장 자연화
- OPENING.EXE 오프닝 내레이션과 디스크 안내 문구

모든 수정은 고정 길이 슬롯, 같은 바이트 길이 치환 또는 검증된 세그먼트 내부 미사용 영역 재배치만 사용한다.
대상 파일과 NE 세그먼트의 크기는 바뀌지 않는다.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

import _ed2main_ui_core as ui
from ed2_patch_journal import record_patch, selective_restore, journal_path

VERSION = "1.7.15R50"
REPORT_NAME = "ED2_TEXT_PATCH_REPORT.json"
OPENING_SUPPORTED_SIZE = 737_404
OPENING_BACKUP_SUFFIX = ".opening_text_patch.bak"
DIRECT_BACKUP_SUFFIX = ".bak.proper_noun_v2_3"


def cp(text: str) -> bytes:
    return text.encode("cp949")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


TEXT_PATCH_JOURNAL_COMPONENT = "ed2_text_patch"

# R40: battle UI grammar correction.  This stays inside the UI/text component
# rather than becoming a separate patch.  The shared `들` string is never
# modified.  The escape-only routine selects 은/는 at runtime before the
# existing escape suffix is rendered.
ESCAPE_SEG = 86
ESCAPE_HOOK_SEG = 0x8720
ESCAPE_HOOK_ORIGINAL = bytes.fromhex("3C 02 72 07 BE 3B 39 0E E8 70 00")
ESCAPE_CAVE_SEG = 0x0800
ESCAPE_HELPER = bytes.fromhex(
    "3C 02 72 0F C7 06 00 27 C0 BA BE 3B 39 0E E8 8A 7F "
    "EB 06 C7 06 00 27 B4 C2 C3"
)
ESCAPE_HOOK_PATCHED = b"\xE8" + struct.pack(
    "<H", (ESCAPE_CAVE_SEG - (ESCAPE_HOOK_SEG + 3)) & 0xFFFF
) + b"\x90" * 8
ESCAPE_PARTICLE_DATA_SEG = 0x2700
ESCAPE_PARTICLE_EUN = bytes.fromhex("C0 BA")   # 은
ESCAPE_PARTICLE_NEUN = bytes.fromhex("B4 C2")  # 는; runtime-only write
ESCAPE_PLURAL_SEG = 0x393B
ESCAPE_PLURAL = "들".encode("cp949")


def _ne_segments(data: bytes) -> list[tuple[int, int, int, int]]:
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if data[ne:ne + 2] != b"NE":
        raise RuntimeError("ED2MAIN NE header not found")
    count = struct.unpack_from("<H", data, ne + 0x1C)[0]
    table = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne + 0x32)[0]
    rows = []
    for i in range(count):
        sec, length, flags, min_alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        rows.append((sec << shift, length or 0x10000, flags, min_alloc or 0x10000))
    return rows


def _reloc_sources(data: bytes, seg_index: int) -> set[int]:
    base, length, flags, _ = _ne_segments(data)[seg_index - 1]
    if not (flags & 0x0100):
        return set()
    end = base + length
    count = struct.unpack_from("<H", data, end)[0]
    return {
        struct.unpack_from("<H", data, end + 2 + i * 8 + 2)[0]
        for i in range(count)
    }


def inspect_escape_battle_ui(data: bytes) -> dict[str, object]:
    segs = _ne_segments(data)
    base86, length86, _flags86, min86 = segs[ESCAPE_SEG - 1]
    base85, _length85, _flags85, _min85 = segs[84]
    hook = data[base86 + ESCAPE_HOOK_SEG:base86 + ESCAPE_HOOK_SEG + len(ESCAPE_HOOK_ORIGINAL)]
    cave = data[base86 + ESCAPE_CAVE_SEG:base86 + ESCAPE_CAVE_SEG + len(ESCAPE_HELPER)]
    particle = data[base85 + ESCAPE_PARTICLE_DATA_SEG:base85 + ESCAPE_PARTICLE_DATA_SEG + 2]
    plural = data[base85 + ESCAPE_PLURAL_SEG:base85 + ESCAPE_PLURAL_SEG + 2]
    if hook == ESCAPE_HOOK_PATCHED and cave == ESCAPE_HELPER:
        state = "applied"
    elif hook == ESCAPE_HOOK_ORIGINAL and cave == b"\0" * len(ESCAPE_HELPER):
        state = "original"
    else:
        state = "unknown"
    if plural != ESCAPE_PLURAL:
        raise RuntimeError("공용 `들` 문자열이 예상 상태와 다릅니다. 전역 치환은 허용하지 않습니다.")
    if particle != ESCAPE_PARTICLE_EUN:
        raise RuntimeError("도주 공통 조사 원본이 `은`이 아닙니다.")
    if length86 != 0xB844 or min86 != 0xB844:
        raise RuntimeError(f"ED2MAIN NE86 geometry mismatch: {length86:04X}/{min86:04X}")
    return {
        "state": state,
        "hook_hex": hook.hex(),
        "helper_hex": cave.hex(),
        "particle_disk_hex": particle.hex(),
        "shared_plural_hex": plural.hex(),
        "shared_plural_unchanged": True,
        "seg86_length": length86,
        "seg86_min_alloc": min86,
    }


def build_escape_battle_ui_target(data: bytes) -> tuple[bytes, list[dict[str, object]]]:
    state = inspect_escape_battle_ui(data)
    if state["state"] == "applied":
        return data, []
    if state["state"] != "original":
        raise RuntimeError("도주 조사 UI hook/helper가 지원하지 않는 상태입니다.")
    segs = _ne_segments(data)
    base86 = segs[ESCAPE_SEG - 1][0]
    sources = _reloc_sources(data, ESCAPE_SEG)
    if any(ESCAPE_HOOK_SEG <= x < ESCAPE_HOOK_SEG + len(ESCAPE_HOOK_ORIGINAL) for x in sources):
        raise RuntimeError("도주 조사 hook가 NE relocation source와 겹칩니다.")
    if any(ESCAPE_CAVE_SEG <= x < ESCAPE_CAVE_SEG + len(ESCAPE_HELPER) for x in sources):
        raise RuntimeError("도주 조사 helper cave가 NE relocation source와 겹칩니다.")
    out = bytearray(data)
    hook_off = base86 + ESCAPE_HOOK_SEG
    cave_off = base86 + ESCAPE_CAVE_SEG
    out[cave_off:cave_off + len(ESCAPE_HELPER)] = ESCAPE_HELPER
    out[hook_off:hook_off + len(ESCAPE_HOOK_PATCHED)] = ESCAPE_HOOK_PATCHED
    after = bytes(out)
    post = inspect_escape_battle_ui(after)
    if post["state"] != "applied" or not post["shared_plural_unchanged"]:
        raise RuntimeError("도주 조사 UI patch postcondition 실패")
    return after, [
        {
            "offset": cave_off, "group": "battle_ui",
            "purpose": "도주 인원별 조사 helper: 1인=는, 복수=기존 들+은 (공용 들 비수정)",
            "before": (b"\0" * len(ESCAPE_HELPER)).hex(" "),
            "after": ESCAPE_HELPER.hex(" "),
            "byte_length": len(ESCAPE_HELPER),
        },
        {
            "offset": hook_off, "group": "battle_ui",
            "purpose": "도주 전용 인원 분기 hook NE86:8720 -> 0800",
            "before": ESCAPE_HOOK_ORIGINAL.hex(" "),
            "after": ESCAPE_HOOK_PATCHED.hex(" "),
            "byte_length": len(ESCAPE_HOOK_PATCHED),
        },
    ]


def atomic_write(path: Path, data: bytes, *, journal: bool = True) -> None:
    before = path.read_bytes() if path.exists() else b""
    if before == data:
        return
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
        if journal and before:
            try:
                record_patch(path, before, data, TEXT_PATCH_JOURNAL_COMPONENT)
            except Exception:
                # Do not leave a mutation that cannot later be restored without
                # overwriting other ED2 patches.
                fd2, tmp2 = tempfile.mkstemp(prefix=path.name + ".", suffix=".journal_rollback.tmp", dir=path.parent)
                try:
                    with os.fdopen(fd2, "wb") as fp:
                        fp.write(before); fp.flush(); os.fsync(fp.fileno())
                    os.replace(tmp2, path)
                finally:
                    try: os.unlink(tmp2)
                    except OSError: pass
                raise
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


def resolve_root(path: Path) -> Path:
    path = path.expanduser().resolve()
    if path.is_file():
        if path.name.upper() != "ED2MAIN.EXE":
            raise FileNotFoundError("ED2MAIN.EXE 또는 게임 폴더를 지정하십시오.")
        root = path.parent
    else:
        root = path
    if not (root / "ED2MAIN.EXE").is_file():
        raise FileNotFoundError(f"ED2MAIN.EXE를 찾을 수 없습니다: {root}")
    return root


# SCENA/ENDING의 문자열은 기존 직접 패처와 같은 범위다. 모든 치환은
# CP949 바이트 길이가 같아서 포인터와 파일 크기를 건드리지 않는다.
DIRECT_NOUN_RULES = (
    # Exact scope of ED2_PROPER_NOUN_DIRECT_PATCH_v2.3.
    ("프아조", "푸아조"),
    ("후레이아", "프레이아"),
    # 원판 한국어 표기와 전 대사에서 쓰이는 정식 표기. 이미 프래드인
    # 원본은 변하지 않으며, 프레드 변형이 섞인 적용본만 프래드로 통일한다.
    ("프레드", "프래드"),
    ("베른", "베룬"),
    ("챨리", "찰리"),
    ("제랄트", "제랄드"),
    ("사이레스", "사일레스"),
    ("길모아", "길모어"),
    # v1.0.22 재검수에서 확인된 동일 길이 고유명사 잔존.
    ("챨즈", "찰스"),
    ("엘아스터", "엘아스타"),
    # F_000/F_200의 지역 선택표에 있는 10바이트 고정 항목.
    # v1.0.16~v1.0.21의 "왕가의묘  " 상태를 원래 표시인 "왕가의무덤"으로 복원한다.
    ("왕가의묘  ", "왕가의무덤"),
    # v1.7.10R9까지 통일했던 용어를 원판의 주문 계열로 복원한다.
    ("마법상", "주문상"),
    ("마법점", "주문점"),
)


# 화자명은 CSV 대사 슬롯과 별개인 ``1E <이름> 04`` 메타데이터다.
# Scene Editor v0.3.10을 그대로 유지하기 위해 이 고정 길이 화자명만
# 통합 텍스트 패치에서 직접 수정하고, 대사 본문의 용어는 CSV가 담당한다.
SPEAKER_LABEL_RULES = (
    ("마법상", "주문상"),
)


EndingPart = str | bytes


def _ending_join(parts: tuple[EndingPart, ...]) -> bytes:
    out = bytearray()
    for part in parts:
        out.extend(part if isinstance(part, bytes) else cp(part))
    return bytes(out)


@dataclass(frozen=True)
class EndingTextSlot:
    file_offset: int
    capacity: int
    current_parts: tuple[EndingPart, ...]
    desired_parts: tuple[EndingPart, ...]
    category: str
    before_text: str
    after_text: str
    purpose: str
    legacy_parts: tuple[tuple[EndingPart, ...], ...] = ()

    def payload(self, parts: tuple[EndingPart, ...]) -> bytes:
        raw = _ending_join(parts)
        if len(raw) > self.capacity:
            raise ValueError(
                f"ENDING.DLL 0x{self.file_offset:X}: "
                f"문구가 슬롯보다 깁니다 ({len(raw)}>{self.capacity})"
            )
        # ENDING.DLL의 해당 문자열은 NUL 종료형이며 원문도 끝에 ASCII
        # 공백을 포함한다. 남는 영역은 NUL 위치를 옮기지 않고 화면에
        # 보이지 않는 후행 ASCII 공백으로 채운다.
        return raw + b" " * (self.capacity - len(raw))

    @property
    def current(self) -> bytes:
        return self.payload(self.current_parts)

    @property
    def desired(self) -> bytes:
        return self.payload(self.desired_parts)

    @property
    def accepted(self) -> tuple[bytes, ...]:
        payloads = [self.current]
        payloads.extend(self.payload(parts) for parts in self.legacy_parts)
        payloads.append(self.desired)
        return tuple(dict.fromkeys(payloads))


# ENDING.DLL 3번 세그먼트의 NUL 종료형 엔딩 대사. 제어 바이트와
# 화자명 필드는 그대로 보존하고 표시 문구만 교정한다. 사용자가 확인한
# PC-98 원문을 재대조해 의미와 호칭까지 교정한다. 원문의 皇太子殿下는 "황태자 전하"로 옮긴다.
ENDING_TEXT_SLOTS = (
    EndingTextSlot(
        0x03EC36, 49,
        (b"\x0A\x05\x0F\x01\x03", "세리오스", "싸움은 항상 작은 다툼에서 시작된다. "),
        (b"\x0A\x05\x0F\x01\x03", "세리오스", "싸움은 늘 작은 엇갈림에서 시작된다."),
        "PC-98 원문 의미 복원", "싸움은 항상 작은 다툼에서 시작된다.",
        "싸움은 늘 작은 엇갈림에서 시작된다.", "PC-98 '小さなすれ違い'를 '작은 다툼'이 아닌 '작은 엇갈림'으로 교정",
        legacy_parts=((b"\x0A\x05\x0F\x01\x03", "세리오스", "싸움은 늘 작은 오해에서 시작된다."),),
    ),
    EndingTextSlot(
        0x03EC68, 37,
        (b"\x05\x01", "아트라스, ", b"\x05", "마음속에 잘 새겨두거라. "),
        (b"\x05\x01", "아트라스, ", b"\x05", "마음속에 잘 새겨 두거라."),
        "띄어쓰기", "마음속에 잘 새겨두거라.", "마음속에 잘 새겨 두거라.",
        "보조 용언 띄어쓰기",
    ),
    EndingTextSlot(
        0x03EC8E, 22,
        (b"\x09", "감사합니다 아트라스. "),
        (b"\x09", "감사합니다, 아트라스."),
        "문장부호", "감사합니다 아트라스.", "감사합니다, 아트라스.",
        "호칭 앞 쉼표 추가",
    ),
    EndingTextSlot(
        0x03ECA5, 31,
        (b"\x04", "이것으로 정의를 지켜내셨군요. "),
        (b"\x04", "이것으로 정의가 지켜졌습니다."),
        "PC-98 원문 태·의미 복원", "이것으로 정의를 지켜내셨군요.",
        "이것으로 정의가 지켜졌습니다.", "PC-98 수동형 '正義が守られました'를 주어 추가 없이 복원",
    ),
    EndingTextSlot(
        0x03ECC5, 35,
        (b"\x04", "여러분들께 이 기계는 재앙의 상자. "),
        (b"\x04", "여러분에게 이 기계는 재앙의 상자. "),
        "프레이아 말투", "여러분들께 이 기계는 재앙의 상자.",
        "여러분에게 이 기계는 재앙의 상자.",
        "프레이아의 장중하고 격식 있는 어조를 유지",
        legacy_parts=((b"\x04", "여러분께 이건 재앙의 상자입니다."),),
    ),
    EndingTextSlot(
        0x03ED11, 35,
        (b"\x04", "이젠 절대 열리는 일따윈 없겠지요. "),
        (b"\x04", "이젠 절대 열릴 일은 없겠지요."),
        "맞춤법·자연화", "이젠 절대 열리는 일따윈 없겠지요.",
        "이젠 절대 열릴 일은 없겠지요.", "관형형과 군더더기 표현 교정",
        legacy_parts=((b"\x04", "이젠 절대 열릴 일 따위는 없겠지요."),),
    ),
    EndingTextSlot(
        0x03ED4B, 48,
        (b"\x05\x04", "저는 모든 기능을 정지하고 깊은 잠에 빠집니다. "),
        (b"\x05\x04", "저는 모든 기능을 정지하고 잠들겠습니다."),
        "PC-98 원문 의미 간결화", "저는 모든 기능을 정지하고 깊은 잠에 빠집니다.",
        "저는 모든 기능을 정지하고 잠들겠습니다.", "원문에 없는 '깊은'을 제거하고 '眠りにつきます'를 자연스럽게 복원",
    ),
    EndingTextSlot(
        0x03EDB4, 32,
        (b"\x05\x01", "언제나 당신의 곁에 있겠습니다."),
        (b"\x05\x01", "언제나 당신 곁에 있습니다."),
        "PC-98 원문 시제 복원", "언제나 당신의 곁에 있겠습니다.",
        "언제나 당신 곁에 있습니다.", "PC-98 'そばにいます'의 현재 존재 표현을 복원",
    ),
    EndingTextSlot(
        0x03EDD5, 34,
        (b"\x05\x01", "번영을 빌며 대지에 씨를 뿌릴 때 "),
        (b"\x05\x01", "기도를 담아 대지에 씨를 뿌릴 때"),
        "PC-98 원문 의미 복원", "번영을 빌며 대지에 씨를 뿌릴 때",
        "기도를 담아 대지에 씨를 뿌릴 때", "PC-98 '祈りをこめて'를 원문에 없는 '번영' 대신 '기도를 담아'로 교정",
    ),
    EndingTextSlot(
        0x03EDF8, 57,
        ("미지의 세계를 두려워하지 않으며 망망대해에 배를 띄울 때  ",),
        ("미지를 두려워하지 않고 대해로 배를 띄울 때",),
        "PC-98 원문 의미 간결화", "미지의 세계를 두려워하지 않으며 망망대해에 배를 띄울 때",
        "미지를 두려워하지 않고 대해로 배를 띄울 때", "PC-98 '未知を恐れず、大海に船をこぎ出す'의 과잉 수식을 줄이고 직접 복원",
    ),
    EndingTextSlot(
        0x03EE5E, 35,
        (b"\x06\x05", "언제라도 당신과 함께 하겠습니다. "),
        (b"\x06\x05", "언제나 당신과 함께 있습니다."),
        "PC-98 원문 시제·의미 복원", "언제라도 당신과 함께 하겠습니다.",
        "언제나 당신과 함께 있습니다.", "PC-98 'いつでも、あなたと共にあります'의 현재 시제와 의미를 복원",
        legacy_parts=((b"\x06\x05", "언제라도 당신과 함께하겠습니다."),),
    ),
    EndingTextSlot(
        0x03EE82, 53,
        (b"\x05\x01", "당신이 저를 원하는 한. ", b"\x09\x03", "플로라  ", "저... 아트라스님. "),
        # Segment 10의 22BDh는 이 슬롯 내부 029Ch(화자 제어 03h)를
        # 하드코딩해 호출한다. R25처럼 앞 문장을 2바이트 줄이면 03h가
        # 029Ah로 이동해 코드가 '플로라' 이름 중간에서 시작한다.
        # 보이지 않는 후행 공백 두 칸으로 화자 제어를 반드시 rel 26에 고정한다.
        (b"\x05\x01", "당신이 저를 찾는 한.   ", b"\x09\x03", "플로라  ", "저기요, 아트라스님"),
        "PC-98 원문 의미·말투 + 화자 앵커 보존", "당신이 저를 원하는 한. / 저... 아트라스님.",
        "당신이 저를 찾는 한. / 저기요, 아트라스님", "PC-98 의미를 살리면서 하드코딩된 플로라 화자명 시작 0x029C를 보존",
        legacy_parts=((b"\x05\x01", "당신이 저를 찾는 한. ", b"\x09\x03", "플로라  ", "저기요, 아트라스님."),),
    ),
    EndingTextSlot(
        0x03EEB8, 46,
        (b"\x01", "드레이크씨도 프래드씨도 사실은 좋은 분들인데 "),
        (b"\x01", "드레이크 씨와 프래드 씨는 사실 좋은 분들인데"),
        "고유명사 띄어쓰기", "드레이크씨도 프래드씨도 사실은 좋은 분들인데",
        "드레이크 씨와 프래드 씨는 사실 좋은 분들인데", "인명 뒤 의존 명사 '씨' 띄어쓰기",
    ),
    EndingTextSlot(
        0x03EF11, 43,
        (b"\x02\x03", "아트라스", "아마 아무도 나쁜 사람은 아닐거야."),
        (b"\x02\x03", "아트라스", "아마 아무도 나쁜 사람은 아니야."),
        "PC-98 원문 의미·띄어쓰기", "아마 아무도 나쁜 사람은 아닐거야.",
        "아마 아무도 나쁜 사람은 아니야.", "PC-98 'だれも悪くはない'의 전칭 부정을 복원하고 띄어쓰기 교정",
        legacy_parts=(
            (b"\x02\x03", "아트라스", "아마 아무도 나쁜 이는 아닐 거야."),
            (b"\x02\x03", "아트라스", "아마 모두가 나쁜 사람은 아닐거야."),
            (b"\x02\x03", "아트라스", "아마 모두 나쁜 사람은 아닐 거야."),
        ),
    ),
    EndingTextSlot(
        0x03EF3D, 45,
        (b"\x01", "어쩌면 나도 똑같은 짓을 저질렀을지도 모르지 "),
        (b"\x01", "어쩌면 나도 똑같이 했을지도 모르지."),
        "PC-98 원문 의미 복원", "어쩌면 나도 똑같은 짓을 저질렀을지도 모르지",
        "어쩌면 나도 똑같이 했을지도 모르지.", "PC-98 '同じことをした'에 없는 범죄적 뉘앙스의 '짓을 저지르다'를 제거",
        legacy_parts=((b"\x01", "어쩌면 나도 똑같은 짓을 저질렀을지도 모르지."),),
    ),
    EndingTextSlot(
        0x03EF6B, 50,
        ("다만 모두가 조금씩 오해하고 있었을 뿐이였던 거야. ",),
        ("다만 모두가 조금씩 서로 오해했을 뿐이야.",),
        "PC-98 원문 상호 의미 복원", "다만 모두가 조금씩 오해하고 있었을 뿐이였던 거야.",
        "다만 모두가 조금씩 서로 오해했을 뿐이야.", "PC-98 '誤解しあっていた'의 상호성을 '서로 오해했다'로 복원",
        legacy_parts=(("다만 모두가 조금씩 오해하고 있었을 뿐이었던 거야.",),),
    ),
    EndingTextSlot(
        0x03EF9E, 41,
        (b"\x01", "알고보면 처음엔 큰 문제도 아니었던거지. "),
        (b"\x01", "그저 그뿐이었던 거야."),
        "PC-98 원문 의미 복원", "알고보면 처음엔 큰 문제도 아니었던거지.",
        "그저 그뿐이었던 거야.", "PC-98 'それだけのことだったんだよ'의 의미를 직접 복원",
        legacy_parts=((b"\x01", "알고 보면 처음엔 큰일도 아니었던 거지."),),
    ),
    EndingTextSlot(
        0x03EFC8, 41,
        (b"\x05\x02\x09\x03", "란도    ", "뭘 둘이서 중얼대고 있는거야? "),
        (b"\x05\x02\x09\x03", "란도    ", "뭘 둘이서 결론 내는 거야!"),
        "PC-98 원문 의미 복원", "뭘 둘이서 중얼대고 있는거야?",
        "뭘 둘이서 결론 내는 거야!", "PC-98 'まとめちゃってんだよ'를 '중얼대다'가 아닌 '결론 내다'로 교정",
        legacy_parts=((b"\x05\x02\x09\x03", "란도    ", "뭘 둘이서 중얼대고 있는 거야?"),),
    ),
    EndingTextSlot(
        0x03F01D, 33,
        ("세계 평화를 잘 부탁해 ", b"\x05", "아트라스. "),
        ("세상 일을 잘 부탁해, ", b"\x05", "아트라스!"),
        "PC-98 원문 의미·문장부호", "세계 평화를 잘 부탁해 아트라스.",
        "세상 일을 잘 부탁해, 아트라스!", "PC-98 '世界のことを'의 의미를 복원하고 감탄 부호를 반영",
        legacy_parts=(("세계 평화를 잘 부탁해, ", b"\x05", "아트라스."),),
    ),
    EndingTextSlot(
        0x03F03F, 24,
        (b"\x05\x02\x03", "플로라  ", "어머 란도씨, "),
        (b"\x05\x02\x03", "플로라  ", "어머 란도 씨,"),
        "고유명사 띄어쓰기", "어머 란도씨,", "어머 란도 씨,",
        "인명 뒤 의존 명사 '씨' 띄어쓰기",
    ),
    EndingTextSlot(
        0x03F058, 29,
        ("아트라스 황태자 폐하", b"\x05", "라구요. "),
        ("아트라스 황태자 전하", b"\x05", "라고요."),
        "PC-98 원문 호칭·맞춤법", "아트라스 황태자 폐하라구요.",
        "아트라스 황태자 전하라고요.", "PC-98 '皇太子殿下'의 殿下를 '전하'로 교정하고 어미를 표준화",
        legacy_parts=(("아트라스 황태자 폐하", b"\x05", "라고요."),),
    ),
    EndingTextSlot(
        0x03F097, 36,
        (b"\x05", "지금까지 처럼 ", b"\x05", "난 그냥 아트라스야. "),
        (b"\x05", "지금까지처럼 ", b"\x05", "난 그냥 아트라스야."),
        "띄어쓰기", "지금까지 처럼 난 그냥 아트라스야.",
        "지금까지처럼 난 그냥 아트라스야.",
        "'처럼'은 붙이고 제어 코드 앞 단어 간격은 보존",
        legacy_parts=((b"\x05", "지금까지처럼", b"\x05", "난 그냥 아트라스야."),),
    ),
    EndingTextSlot(
        0x03F0BC, 40,
        (b"\x05\x05\x02\x09\x03", "아트라스", "앞으로도 힘이 되어 줄거지? "),
        (b"\x05\x05\x02\x09\x03", "아트라스", "앞으로도 힘이 되어 줄 거지?"),
        "띄어쓰기", "앞으로도 힘이 되어 줄거지?",
        "앞으로도 힘이 되어 줄 거지?", "의존 명사 '거' 띄어쓰기",
    ),
    EndingTextSlot(
        0x03F108, 29,
        (b"\x05\x02\x03", "플로라  ", "제 힘이 된다면.   "),
        (b"\x05\x02\x03", "플로라  ", "도와드리겠습니다."),
        "PC-98 원문 의미 복원", "제 힘이 된다면.", "도와드리겠습니다.", "PC-98 'お手伝い、いたしますわ'의 직접적인 도움 의사를 복원",
        legacy_parts=((b"\x05\x02\x03", "플로라  ", "제가 힘이 된다면."),),
    ),
    EndingTextSlot(
        0x03F13C, 26,
        (b"\x05\x05\x01", "부디 힘을 빌려 주소서. "),
        (b"\x05\x05\x01", "부디 힘을 주소서."),
        "PC-98 원문 의미 복원", "부디 힘을 빌려 주소서.", "부디 힘을 주소서.",
        "PC-98 'どうか、力を与えてください'의 '주다' 의미를 원문에 없는 '빌려주다'가 아닌 직접 표현으로 복원",
    ),
    EndingTextSlot(
        0x03F178, 38,
        (b"\x05", "지금부터 더욱 더 행복해질 수 있도록. "),
        (b"\x05", "지금보다 더 행복해질 수 있도록."),
        "PC-98 원문 의미 복원", "지금부터 더욱 더 행복해질 수 있도록.",
        "지금보다 더 행복해질 수 있도록.", "PC-98 '今よりもっと'의 비교 기준을 '지금부터'가 아닌 '지금보다'로 교정",
        legacy_parts=((b"\x05", "지금부터 더욱더 행복해질 수 있도록."),),
    ),
    EndingTextSlot(
        0x03F19F, 27,
        (b"\x05\x01", "부디 지켜 보아 주십시오. "),
        (b"\x05\x01", "부디 지켜보아 주십시오."),
        "띄어쓰기", "부디 지켜 보아 주십시오.",
        "부디 지켜보아 주십시오.", "합성 동사 '지켜보다' 붙여쓰기",
    ),
    EndingTextSlot(
        0x03F1BB, 27,
        (b"\x09\x03", "레이시아", "기대하고 있겠어. "),
        (b"\x09\x03", "레이시아", "기대하고 있어."),
        "PC-98 원문 시제 복원", "기대하고 있겠어.", "기대하고 있어.",
        "PC-98 '期待しているわ'의 현재 시제를 복원",
        legacy_parts=((b"\x09\x03", "레이시아", "기대하고 있을게."),),
    ),
    EndingTextSlot(
        0x03F206, 28,
        (b"\x02\x03", "아트라스", "고마와 ", b"\x05", "레이시아. "),
        (b"\x02\x03", "아트라스", "고마워, ", b"\x05", "레이시아."),
        "맞춤법·띄어쓰기", "고마와, 레이시아.", "고마워, 레이시아.",
        "표준어·호칭 쉼표와 제어 코드 앞 간격 보존",
        legacy_parts=((b"\x02\x03", "아트라스", "고마워", b"\x05", "레이시아."),),
    ),
    EndingTextSlot(
        0x03F273, 97,
        (b"\x02\x09", "자그마한 태양은 곧 아버지를 뛰어넘어, 커다란 태양으로써 빛날 것이다. Ｄｒａｇｏｎ Ｓｌａｙｅｒ "),
        (b"\x02\x09", "자그마한 태양은 이윽고 아버지를 넘어, 커다란 태양으로서 빛날 것이다. Ｄｒａｇｏｎ Ｓｌａｙｅｒ "),
        "PC-98 원문 의미·맞춤법", "커다란 태양으로써 빛날 것이다.",
        "자그마한 태양은 이윽고 아버지를 넘어, 커다란 태양으로서 빛날 것이다.", "PC-98 'やがて父を越え'를 '이윽고 아버지를 넘어'로 복원하고 '으로서' 교정",
        legacy_parts=((b"\x02\x09", "자그마한 태양은 곧 아버지를 뛰어넘어, 커다란 태양으로서 빛날 것이다. Ｄｒａｇｏｎ Ｓｌａｙｅｒ "),),
    ),
)


# R37: PC-98 원문의 정보와 인물 관계는 유지하면서, 이미 원문 대조가 끝난
# 엔딩 한국어 중 번역투/부자연스러운 화법만 추가 자연화한다. 기존 R36
# 목표 바이트는 legacy input으로 자동 승격해 v1.3.81에서 바로 이행된다.
_ENDING_R37_OVERRIDES: dict[int, tuple[tuple[EndingPart, ...], str, str]] = {
    0x03ECC5: ((b"\x04", "여러분에겐 이 기계가 재앙의 상자."), "여러분에겐 이 기계가 재앙의 상자.", "조사 호응을 자연스럽게 정리"),
    0x03ED11: ((b"\x04", "이제 다시 열릴 일은 없겠지요."), "이제 다시 열릴 일은 없겠지요.", "한국어에서 자연스러운 '다시는 열리지 않다' 계열 표현으로 정리"),
    0x03EDF8: (("미지를 두려워하지 않고 드넓은 바다로 배를 띄울 때",), "미지를 두려워하지 않고 드넓은 바다로 배를 띄울 때", "PC-98 '大海'를 딱딱한 '대해' 대신 자연스러운 서술로 표현"),
    0x03EEB8: ((b"\x01", "드레이크 씨도 프래드 씨도 사실 좋은 분들인데"), "드레이크 씨도 프래드 씨도 사실 좋은 분들인데", "PC-98 'さんも…さんも'의 병렬 강조와 한국어 호흡 복원"),
    0x03EF6B: (("다만 다들 서로 조금씩 오해했을 뿐이야.",), "다만 다들 서로 조금씩 오해했을 뿐이야.", "상호 오해 의미를 유지하면서 아트라스의 구어체로 자연화"),
    0x03F01D: (("세상을 잘 부탁해, ", b"\x05", "아트라스!"), "세상을 잘 부탁해, 아트라스!", "PC-98 '世界のことを、よろしく頼むぜ'를 자연스러운 한국어로 정리"),
}

def _ending_r37_upgrade(slot: EndingTextSlot) -> EndingTextSlot:
    override = _ENDING_R37_OVERRIDES.get(slot.file_offset)
    if override is None:
        return slot
    desired_parts, after_text, purpose = override
    return EndingTextSlot(slot.file_offset, slot.capacity, slot.current_parts, desired_parts,
        "자연화", slot.after_text, after_text, purpose,
        legacy_parts=slot.legacy_parts + (slot.desired_parts,))

ENDING_TEXT_SLOTS = tuple(_ending_r37_upgrade(slot) for slot in ENDING_TEXT_SLOTS) + (
    EndingTextSlot(0x03EE32, 43,
        (b"\x01", "사랑하는 사람과 저 하늘에 꿈을 그려갈 때"),
        (b"\x01", "사랑하는 이와 드넓은 하늘에 꿈을 그릴 때"),
        "자연화", "사랑하는 사람과 저 하늘에 꿈을 그려갈 때", "사랑하는 이와 드넓은 하늘에 꿈을 그릴 때",
        "PC-98 '愛するひとと、大空に夢を描くとき'의 서정성을 자연스러운 한국어로 정리"),
    EndingTextSlot(0x03EFF2, 42,
        (b"\x01", "지나간 일보다도 지금부터가 큰일이라니까."),
        (b"\x01", "지나간 일보다 앞으로가 더 힘들다니까."),
        "란도 말투 자연화", "지나간 일보다도 지금부터가 큰일이라니까.", "지나간 일보다 앞으로가 더 힘들다니까.",
        "PC-98 'これからがたいへんなんだぜ'를 란도의 자연스러운 구어체로 정리"),
    EndingTextSlot(0x03F076, 32,
        (b"\x05\x05\x02\x03", "아트라스", "됐네, 됐어. ", b"\x05", "플로라."),
        (b"\x05\x05\x02\x03", "아트라스", "괜찮아, ", b"\x05", "플로라."),
        "아트라스 말투 자연화", "됐네, 됐어. 플로라.", "괜찮아, 플로라.",
        "PC-98 'いいんだよ、フローラ'와 젊은 아트라스의 말투에 맞게 교정"),
    EndingTextSlot(0x03F0E5, 34,
        (b"\x05\x02\x03", "란도    ", "그러엄 ", b"\x05", "맡겨 두시라고."),
        (b"\x05\x02\x03", "란도    ", "그래. ", b"\x05", "맡겨 둬!"),
        "란도 말투 자연화", "그러엄 맡겨 두시라고.", "그래. 맡겨 둬!",
        "PC-98 'おう。まかせとけ！'의 거친 친근감을 복원하고 어색한 존대를 제거"),
    EndingTextSlot(0x03F223, 49,
        (b"\x04", "이제부터는 지상의 인간과 지저의 인간이 교류하는"),
        (b"\x04", "이제부터 지상 사람들과 지저 사람들이 교류하는"),
        "자연화", "이제부터는 지상의 인간과 지저의 인간이 교류하는", "이제부터 지상 사람들과 지저 사람들이 교류하는",
        "반복되는 '인간'을 자연스러운 한국어 명사구로 정리"),
)


# The ending narration add-on changes three control bytes inside the final
# fixed-capacity text slot.  Text correction owns only the visible CP949 text;
# the ending patch owns these bytecode controls.  Matching and rewriting this
# one slot therefore ignores/preserves the control positions.
ENDING_NARRATION_SLOT_OFFSET = 0x03F273
ENDING_NARRATION_CONTROL_VALUES: dict[int, tuple[int, ...]] = {
    1: (0x09, 0x05, 0x06),   # original / older bridge / timed bridge
    39: (0x20, 0x00),        # space / line break
    70: (0x20, 0x09, 0x07),  # space / old end / timed end
}


def _ending_slot_matches(slot: EndingTextSlot, current: bytes) -> bool:
    if slot.file_offset != ENDING_NARRATION_SLOT_OFFSET:
        return current in slot.accepted
    for candidate in slot.accepted:
        if len(candidate) != len(current):
            continue
        if all(
            current[index] == candidate[index]
            for index in range(len(current))
            if index not in ENDING_NARRATION_CONTROL_VALUES
        ):
            return all(
                current[index] in allowed
                for index, allowed in ENDING_NARRATION_CONTROL_VALUES.items()
            )
    return False


def _ending_slot_target(slot: EndingTextSlot, current: bytes) -> bytes:
    target = bytearray(slot.desired)
    if slot.file_offset == ENDING_NARRATION_SLOT_OFFSET:
        for index, allowed in ENDING_NARRATION_CONTROL_VALUES.items():
            value = current[index]
            if value not in allowed:
                raise ValueError(
                    f"ENDING.DLL 0x{slot.file_offset + index:X}: "
                    f"나레이션 제어 바이트가 알려진 상태와 다릅니다: 0x{value:02X}"
                )
            target[index] = value
    return bytes(target)


@dataclass(frozen=True)
class SceneTextSlot:
    file_name: str
    file_offset: int
    capacity: int
    accepted_texts: tuple[str, ...]
    desired_text: str
    purpose: str
    accepted_payloads: tuple[bytes, ...] = ()

    def payload(self, text: str) -> bytes:
        raw = cp(text)
        if len(raw) > self.capacity:
            raise ValueError(
                f"{self.file_name} 0x{self.file_offset:X}: "
                f"문구가 슬롯보다 깁니다 ({len(raw)}>{self.capacity}): {text!r}"
            )
        # ED2MAIN DISP_MESS에서 FF는 피연산자 없는 무출력 RETF 명령이다.
        # Scene Editor v0.3.8과 같은 방식으로 남는 바이트를 FF로 채운다.
        return raw + b"\xFF" * (self.capacity - len(raw))

    @property
    def desired(self) -> bytes:
        return self.payload(self.desired_text)

    @property
    def accepted(self) -> tuple[bytes, ...]:
        values = [self.payload(text) for text in self.accepted_texts]
        values.append(self.desired)
        values.extend(self.accepted_payloads)
        return tuple(dict.fromkeys(values))


# UI와 SCENA가 서로 다른 이름을 사용하던 고정 슬롯.
# 같은 용어를 CSV와 통합 패치 양쪽에서 사용해 어느 적용 순서에서도
# 결과가 되돌아가지 않도록 한다.
SCENE_TERMINOLOGY_SLOTS = (
    SceneTextSlot(
        "D_410.DLL", 0x003695, 69,
        (
            "아, 요전의 녀석들보다도 약한 것 같으니 잠드는 버섯 따위도 필요없겠군.",
            "아, 요전 녀석들보다도 약한 것 같으니 잠버섯 따위는 필요 없겠군.",
        ),
        "아, 요전 녀석들보다 약해 보이니 수면 버섯 따윈 필요 없겠군.",
        "아이템명 통일: 잠드는 버섯/잠버섯 → 수면 버섯",
    ),
    SceneTextSlot(
        "T_240.DLL", 0x003885, 35,
        (
            "예, 그 잠버섯으로 그 녀석을 한번에!",
            "예, 그 잠버섯으로 그 녀석을 단번에!",
        ),
        "예, 수면 버섯이면 그 녀석도 단번에!",
        "아이템명 통일: 잠버섯 → 수면 버섯",
    ),
    SceneTextSlot(
        "V_000.DLL", 0x003412, 30,
        (
            "     제1장   열려진 나락      ",
            "     제1장 열린 나락      ",
            "     제1장 열려버린 나락      ",
            # Chapter Title Refresh v0.3.x may run after Text Patch and keep
            # the same 30-byte title slot with its later half-width-space
            # alignment.  Accept that downstream state without rewriting it.
            "       제1장  열린 나락       ",
        ),
        "       제1장 열린 나락        ",
        "1장 제목: 제1장 열린 나락",
    ),
    SceneTextSlot(
        "V_100.DLL", 0x003401, 19,
        (
            "제1장   열려진 나락",
            "제1장 열린 나락",
            "제1장 열려버린 나락",
        ),
        "제1장 열린 나락",
        "1장 제목: 제1장 열린 나락",
        # Chapter Title Refresh v0.3.2 may replace the tail of this fixed
        # slot with a local 0F message redirect.  This is the exact known
        # downstream state and must be accepted without rewriting it.
        accepted_payloads=(bytes.fromhex("20 20 20 20 20 20 20 C1 A6 31 C0 E5 20 BF AD 0F 24 08 FF"), bytes.fromhex("20 20 20 20 20 20 20 20 20 C1 A6 31 C0 E5 20 0F 24 08 FF"), bytes.fromhex("C1 A6 31 C0 E5 20 20 BF AD B8 B0 20 B3 AA B6 F4 FF FF FF")),
    ),
    SceneTextSlot(
        "C_201.DLL", 0x0035BC, 40,
        (
            "이 다음엔 솔디스와 모렌에 가려고 합니다.",
            "다음엔 솔디스와 모레스톤에 가려 합니다.",
        ),
        "다음엔 솔디스와 모레스톤에 가려 합니다.",
        "국가명 통일: 모렌 → 모레스톤",
    ),
)


def direct_files(root: Path) -> list[Path]:
    result: list[Path] = []
    ending = root / "ENDING.DLL"
    if ending.is_file():
        result.append(ending)
    if os.environ.get("ED2_TEXT_SKIP_SCENA") != "1":
        scena = root / "SCENA"
        if not scena.is_dir():
            scena = root / "scena"
        if scena.is_dir():
            result.extend(sorted(scena.glob("*.DLL")))
    return result


@dataclass(frozen=True)
class OpeningSlot:
    offset: int
    original: bytes
    desired: bytes
    purpose: str

    def __post_init__(self) -> None:
        if len(self.original) != len(self.desired):
            raise ValueError(f"오프닝 슬롯 길이 불일치: {self.purpose}")


def opening_line(original: str, text: str) -> bytes:
    """오프닝의 2바이트 글자 셀을 보존하며 문장을 가운데 배치한다.

    이 렌더러는 한글 한 글자를 CP949 2바이트 단위로 읽고, 전각 공백도
    반드시 ``__`` 두 바이트 한 쌍으로 읽는다. 밑줄을 홀수 개 넣으면 그
    뒤의 CP949 경계가 한 바이트 밀려 한글이 깨진다. 따라서 남는 영역은
    바이트가 아니라 2바이트 셀 수로 계산하고 좌우에 완전한 ``__`` 쌍만
    배치한다. 문자열 끝의 원래 ``__`` 셀과 NUL 위치도 유지한다.
    """
    original_raw = cp(original)
    body = cp(text.replace(" ", "__") + "__")
    if len(body) > len(original_raw):
        raise ValueError(f"오프닝 문구가 슬롯보다 깁니다: {text!r}")

    original_lead = len(original) - len(original.lstrip(" "))
    original_center = (original_lead + len(original_raw)) / 2.0
    total_pad = len(original_raw) - len(body)
    lead = round(original_center - len(body) / 2.0)
    lead = max(0, min(total_pad, lead))
    lead = min(lead, original_lead)

    # v1.7.2의 바이트 기준 중앙값은 유지하되, 좌우 밑줄 패딩이
    # 홀수 바이트가 되면 오른쪽 1바이트를 왼쪽으로 옮겨 두 쪽 모두
    # 완전한 2바이트 셀이 되게 한다. 이렇게 하면 기존 정상 22줄은
    # 바이트가 그대로이고, 실제로 깨진 두 줄만 교정된다.
    trail = total_pad - lead
    if trail < 0 or trail & 1:
        raise ValueError(f"오프닝 2바이트 셀 정렬 실패: {text!r}")
    left_blank = trail // 2
    right_blank = trail - left_blank
    if left_blank & 1:
        if right_blank < 1:
            raise ValueError(f"오프닝 패딩 쌍 구성 실패: {text!r}")
        left_blank += 1
        right_blank -= 1
    if (left_blank | right_blank) & 1:
        raise AssertionError("오프닝 밑줄 패딩이 2바이트 셀에 맞지 않습니다")
    result = b" " * lead + b"_" * left_blank + body + b"_" * right_blank
    if len(result) != len(original_raw):
        raise AssertionError("오프닝 슬롯 길이 보존 실패")
    return result


def fixed(text: str, byte_length: int) -> bytes:
    raw = cp(text)
    if len(raw) > byte_length:
        raise ValueError(f"문구가 슬롯보다 깁니다: {text!r}")
    return raw + b" " * (byte_length - len(raw))


OPENING_SLOTS = (
    OpeningSlot(0x099102, cp("   악신__아그니쟈가__쓰러져__이셀하사에__평화가__찾아왔다__"),
                opening_line("   악신__아그니쟈가__쓰러져__이셀하사에__평화가__찾아왔다__", "악신 아그니쟈가 쓰러지고 이셀하사에 평화가 찾아왔다"),
                "오프닝 1: 연결 어미 자연화"),
    OpeningSlot(0x09913E, cp("세리오스는__디나__공주와__결혼하여__파렌__왕국의__왕이__되었다__"),
                opening_line("세리오스는__디나__공주와__결혼하여__파렌__왕국의__왕이__되었다__", "세리오스는 디나 공주와 결혼하여 파렌 왕국의 왕이 되었다"),
                "오프닝 2"),
    OpeningSlot(0x09917F, cp("    같이__싸워온__동료들도__이젠__무기를__잡을__일이__없이__"),
                opening_line("    같이__싸워온__동료들도__이젠__무기를__잡을__일이__없이__", "함께 싸워 온 동료들도 이제는 무기를 잡을 일이 없어"),
                "오프닝 3: 띄어쓰기·문맥 자연화"),
    OpeningSlot(0x0991BC, cp("               각자의__고향으로__돌아갔다__"),
                opening_line("               각자의__고향으로__돌아갔다__", "각자의 고향으로 돌아갔다"),
                "오프닝 4"),
    OpeningSlot(0x0991EB, cp("          이윽고__세리오스와__디나의__사이에서__"),
                opening_line("          이윽고__세리오스와__디나의__사이에서__", "이윽고 세리오스와 디나 사이에"),
                "오프닝 5: 조사 자연화"),
    OpeningSlot(0x09921C, cp("                   왕자가__탄생했다__"),
                opening_line("                   왕자가__탄생했다__", "왕자가 태어났다"),
                "오프닝 6: 표현 자연화"),
    OpeningSlot(0x099242, cp("         모든__사람들이__바라던__파렌의__황태자__"),
                opening_line("         모든__사람들이__바라던__파렌의__황태자__", "모든 사람이 바라던 파렌의 황태자"),
                "오프닝 7: 복수 표현 정리"),
    OpeningSlot(0x099274, cp("            왕자는__아트라스라고__이름__지어져__"),
                opening_line("            왕자는__아트라스라고__이름__지어져__", "왕자는 아트라스라는 이름을 받고"),
                "오프닝 8: 직역투 개선"),
    OpeningSlot(0x0992A5, cp("       넘치는__애정으로__길러져__십오세가__되었다__"),
                opening_line("       넘치는__애정으로__길러져__십오세가__되었다__", "넘치는 사랑 속에서 자라 열다섯 살이 되었다"),
                "오프닝 9: 문장 의미 유지 + 2바이트 셀 기준 중앙 정렬"),
    OpeningSlot(0x0992DA, cp("               빛나는__금발과__총명한__눈동자__"),
                opening_line("               빛나는__금발과__총명한__눈동자__", "빛나는 금발과 총명한 눈동자"),
                "오프닝 10A: PC-98 '輝く金の髪と、利発な瞳・・・' 복원; 한국판 폰트에서 깨지는 특수 말줄임표 제거"),
    OpeningSlot(0x09930A, cp("    그리고__무엇보다도__아버지에게서__물려받은__곧은__마음씨__"),
                opening_line("    그리고__무엇보다도__아버지에게서__물려받은__곧은__마음씨__", "그리고 무엇보다 아버지를 닮은 곧은 마음"),
                "오프닝 10B: 금발·눈동자 중복을 제거하고 PC-98의 '무엇보다 아버지를 닮은 곧은 마음'만 표시"),
    OpeningSlot(0x099349, cp("         악을__모르는__눈은__언제나__백성들을__바라보며__"),
                opening_line("         악을__모르는__눈은__언제나__백성들을__바라보며__", "악을 모르는 그 눈길은 늘 백성을 바라보며"),
                "오프닝 11: PC-98 '悪を知らないまなざし'의 눈길 표현 복원"),
    OpeningSlot(0x099383, cp("               왕이__되는__사명에__불타고__있다__"),
                opening_line("               왕이__되는__사명에__불타고__있다__", "왕이 될 사명감에 불타고 있다"),
                "오프닝 12: PC-98 원문의 현재형 복원"),
    OpeningSlot(0x0993B6, cp("             사람들은__아트라스__왕자를__사랑하고__"),
                opening_line("             사람들은__아트라스__왕자를__사랑하고__", "사람들은 아트라스 왕자를 사랑하고"),
                "오프닝 13: PC-98 원문의 현재형 복원"),
    OpeningSlot(0x0993EA, cp("                 왕자는__사람들을__사랑했다__"),
                opening_line("                 왕자는__사람들을__사랑했다__", "왕자도 사람들을 사랑한다"),
                "오프닝 14: PC-98 원문의 현재형 복원"),
    OpeningSlot(0x099418, cp("       파렌__왕국은__세리오스__왕이라는__커다란__태양과__"),
                opening_line("       파렌__왕국은__세리오스__왕이라는__커다란__태양과__", "파렌 왕국은 세리오스 왕이라는 커다란 태양과"),
                "오프닝 15"),
    OpeningSlot(0x099452, cp("   아트라스__왕자라는__작은__태양에__지켜져__더욱더__번영했다__"),
                opening_line("   아트라스__왕자라는__작은__태양에__지켜져__더욱더__번영했다__", "아트라스 왕자라는 작은 태양의 보살핌으로 더욱 번영했다"),
                "오프닝 16: 피동·중복 표현 개선"),
    # 한국 DOS판에는 이 문자열이 별도 슬롯으로 존재한다. R26까지는 이
    # 숨은 슬롯을 관리하지 않아 다음 슬롯에도 '어느 날'을 넣으면서 화면에서
    # 같은 뜻이 두 번 연속 출력됐다. PC-98 원문도 そんなある日 / 대지진의
    # 두 문장 구조이므로 이 슬롯 하나만 '그러던 어느 날'을 담당한다.
    OpeningSlot(0x099493, cp("                        그러던__어느__날__"),
                opening_line("                        그러던__어느__날__", "그러던 어느 날"),
                "오프닝 16B: 숨은 '그러던 어느 날' 슬롯을 명시적으로 관리"),
    OpeningSlot(0x0994BE, cp("             이셀하사__전체를__대지진이__덥쳤다__"),
                opening_line("             이셀하사__전체를__대지진이__덥쳤다__", "대지진이 이셀하사 전역을 덮쳤다"),
                "오프닝 17: 앞 슬롯과 중복된 '어느 날' 제거 + 중앙 정렬"),
    OpeningSlot(0x0994F0, cp("    낡은__건축물들이__쓰러지고__각지에__심각한__피해를__끼쳤다__"),
                opening_line("    낡은__건축물들이__쓰러지고__각지에__심각한__피해를__끼쳤다__", "낡은 건물들이 무너지고 각지에 심각한 피해가 발생했다"),
                "오프닝 18: 주술 호응 개선"),
    OpeningSlot(0x099532, cp("          갑작스런__재앙에__처음에는__혼란이__있었으나__"),
                opening_line("          갑작스런__재앙에__처음에는__혼란이__있었으나__", "갑작스러운 재앙에 처음에는 혼란이 있었으나"),
                "오프닝 19: 표준어 교정"),
    OpeningSlot(0x09956B, cp("                사람들은__힘을__합쳐__복구하여__"),
                opening_line("                사람들은__힘을__합쳐__복구하여__", "사람들은 힘을 합쳐 복구에 나섰고"),
                "오프닝 20: 연결 어미 자연화"),
    OpeningSlot(0x09959C, cp("           이셀하사는__얼마__안있어__전과__같이__되었다__"),
                opening_line("           이셀하사는__얼마__안있어__전과__같이__되었다__", "이셀하사는 얼마 안 있어 예전 모습을 되찾았다"),
                "오프닝 21: 안 있어 띄어쓰기·표현 개선"),
    OpeningSlot(0x0995D7, cp("                                   그런__것처럼__보였다__"),
                opening_line("                                   그런__것처럼__보였다__", "그런 것처럼 보였다"),
                "오프닝 22: 요청 문구로 복원"),
    OpeningSlot(0x099615, cp("   그렇다__아무도__알지__못한__것이었다__"),
                opening_line("   그렇다__아무도__알지__못한__것이었다__", "그렇다 아무도 알지 못했다"),
                "오프닝 23: 접속 표현 변경"),
    OpeningSlot(0x099640, cp("         새로운__재앙이__다가오려고__하고__있다는__것을__"),
                opening_line("         새로운__재앙이__다가오려고__하고__있다는__것을__", "새로운 재앙이 다가오고 있다는 것을"),
                "오프닝 24: 중복 진행 표현 제거"),
    OpeningSlot(0x099A2E, cp("드라이브 A: 에 프로그램 DISK를 넣어 주십시오 "),
                fixed("드라이브 A:에 프로그램 DISK를 넣어 주십시오", 45),
                "오프닝 디스크 안내 1: 조사 앞 띄어쓰기"),
    OpeningSlot(0x099A5C, cp("드라이브 A: 에 시나리오 DISK1을 넣어 주십시오 "),
                fixed("드라이브 A:에 시나리오 DISK 1을 넣어 주십시오", 46),
                "오프닝 디스크 안내 2: 띄어쓰기"),
)


# R37: 오프닝 내레이션의 정보·순서는 그대로 두고, 한국어 번역투만
# 자연화한다. R36 목표 바이트를 별도 허용해 v1.3.81 적용본도 직접 이행한다.
_OPENING_R37_TEXT = {
    0x09913E: ("세리오스는 디나 공주와 결혼해 파렌 왕국의 왕이 되었다", "오프닝: 문어적인 '결혼하여' 자연화"),
    0x0991EB: ("얼마 뒤 세리오스와 디나 사이에", "오프닝: PC-98 'ほどなく'를 자연스러운 시간 연결로 표현"),
    0x099274: ("왕자는 아트라스라는 이름을 얻었고", "오프닝: '이름을 받고' 번역투 자연화"),
    0x09930A: ("그리고 무엇보다 아버지를 닮은 올곧은 마음", "오프닝: 성품 묘사를 자연스러운 한국어로 정리"),
    0x099383: ("훗날 왕이 될 사명에 불타고 있다", "오프닝: PC-98 'やがて'와 사명 표현 복원"),
    0x099452: ("아트라스 왕자라는 작은 태양이 지켜 더욱 번영했다", "오프닝: '보살핌으로'의 어색한 조사 호응 자연화"),
    0x09959C: ("이셀하사는 곧 예전 모습을 되찾았다", "오프닝: '얼마 안 있어'를 간결한 서술로 자연화"),
    0x0995D7: ("그렇게 보였다", "오프닝: '그런 것처럼 보였다' 번역투 자연화"),
    0x099640: ("새로운 재앙이 닥쳐오고 있다는 것을", "오프닝: 위협의 강도를 살리면서 자연스러운 서술로 정리"),
}
OPENING_R36_VARIANTS = {slot.offset: slot.desired for slot in OPENING_SLOTS if slot.offset in _OPENING_R37_TEXT}
OPENING_SLOTS = tuple(
    OpeningSlot(slot.offset, slot.original,
        opening_line(slot.original.decode("cp949"), _OPENING_R37_TEXT[slot.offset][0]),
        _OPENING_R37_TEXT[slot.offset][1])
    if slot.offset in _OPENING_R37_TEXT else slot
    for slot in OPENING_SLOTS
)


# v1.7.0에서 짧아진 문장을 다시 중앙 정렬하면서 원문보다 선두
# 공백을 늘린 다섯 슬롯. 실제 재생 시 첫 단어가 잘릴 수 있으므로
# v1.7.1은 이 바이트열을 이행 입력으로 받아 원문 시작 위치로 되돌린다.
OPENING_V170_VARIANTS = {
    0x0991EB: cp("            이윽고__세리오스와__디나__사이에__  "),
    0x099242: cp("          모든__사람이__바라던__파렌의__황태자__ "),
    0x0995D7: cp("                                      그렇게__보였다__   "),
    0x099615: cp("       하지만__아무도__알지__못했다__    "),
    0x099640: cp("             새로운__재앙이__다가오고__있다는__것을__    "),
}


# v1.7.1 kept the original ASCII lead but used ASCII spaces at the end.  The
# renderer ignores those for its body span, so the shortened amount was cut
# from the beginning.  Accept these bytes for in-place migration.
OPENING_V171_VARIANTS = {
    0x0991EB: cp("          이윽고__세리오스와__디나__사이에__    "),
    0x099242: cp("         모든__사람이__바라던__파렌의__황태자__  "),
    0x0995D7: cp("                                   그렇게__보였다__      "),
    0x099615: cp("   하지만__아무도__알지__못했다__        "),
    0x099640: cp("         새로운__재앙이__다가오고__있다는__것을__        "),
}


# v1.7.2는 후행 공백 문제를 해결했지만, 남는 밑줄 바이트를 낱개로
# 나누면서 두 슬롯에 홀수 길이 밑줄이 생겼다. 그 뒤의 CP949 경계가
# 밀려 화면에서 깨진 글자가 나타난다. 이 두 바이트열을 이행 입력으로
# 허용하고 v1.7.3의 완전한 2바이트 셀 배열로 교체한다.
OPENING_V172_VARIANTS = {
    0x099242: cp("         _모든__사람이__바라던__파렌의__황태자___"),
    0x0995D7: cp("                                   ___그렇게__보였다_____"),
}


# v1.7.3의 오프닝 9번째 줄. 화면 확인 결과 마지막 줄만 약간 왼쪽으로
# 치우쳐 보여, v1.7.4에서는 끝의 전각 공백 셀 하나를 문장 앞으로
# 이동한다. 본문과 슬롯 길이, CP949 2바이트 셀 경계는 그대로다.
OPENING_V173_VARIANTS = {
    0x0992A5: cp(" 넘치는__사랑__속에서__자라__열다섯__살이__되었다__"),
}


# v1.7.4의 마지막 줄은 문구를 그대로 유지하면서 한 셀 오른쪽으로
# 보정한 상태다. v1.7.6은 이 상태를 최종 목표로 사용한다.
OPENING_V174_VARIANTS = {
    0x0992A5: cp(" __넘치는__사랑__속에서__자라__열다섯__살이__되었다"),
}


# v1.7.5에서는 더 오른쪽으로 옮기기 위해 '속에서'를 '속에'로
# 줄였지만 사용자의 요청으로 롤백한다. 이미 v1.7.5가 적용된 파일도
# 인식해서 v1.7.4 문구·정렬 상태로 되돌린다.
OPENING_V175_VARIANTS = {
    0x0992A5: cp(" ____넘치는__사랑__속에__자라__열다섯__살이__되었다"),
}


# v1.7.10의 마지막 부분 두 줄. v1.7.10R1은 요청한 문구만
# 바꾸므로 기존 v1.7.10 적용본을 바로 갱신할 수 있게 허용한다.
OPENING_V1710_VARIANTS = {
    0x09930A: opening_line("    그리고__무엇보다도__아버지에게서__물려받은__곧은__마음씨__", "그리고 무엇보다도 아버지에게서 물려받은 곧은 마음씨"),
    0x0994BE: opening_line("             이셀하사__전체를__대지진이__덥쳤다__", "대지진이 이셀하사 전역을 덮쳤다"),
    0x0995D7: cp("                                   ____그렇게__보였다____"),
    0x099615: cp("   ____하지만__아무도__알지__못했다______"),
}


# v1.7.10R24에서 원문 현재형을 과거형으로 정리했던 네 슬롯.
# R25는 PC-98의 수사적 현재형과 빠졌던 '무엇보다'를 복원하며
# 기존 R24 적용본을 그대로 갱신할 수 있도록 이 상태를 허용한다.
# v1.7.10R25에서 숨은 금발 문장을 인식하지 못하고 다음 슬롯에
# 같은 의미를 다시 합쳐 넣었던 상태. R26은 이 바이트열을 받아
# 숨은 문장과 '아버지를 닮은 곧은 마음'을 다시 분리한다.
OPENING_R25_VARIANTS = {
    0x09930A: cp("빛나는__금발,__총명한__눈,__무엇보다__부친을__닮은__곧은__마음"),
    0x099349: opening_line("         악을__모르는__눈은__언제나__백성들을__바라보며__", "악을 모르는 눈으로 언제나 백성들을 바라보며"),
}


# v1.7.10R26에서 실제로 배포된 두 문제 상태. R27은 이 바이트열을
# 안전한 이행 입력으로 받아 특수 말줄임표와 중복 '어느 날'을 제거한다.
OPENING_R26_VARIANTS = {
    0x0992DA: opening_line("               빛나는__금발과__총명한__눈동자__", "빛나는 금발과 총명한 눈동자…"),
    0x0994BE: cp("   어느__날__대지진이__이셀하사__전역을__덮쳤다__"),
}


OPENING_R24_VARIANTS = {
    0x09930A: opening_line("    그리고__무엇보다도__아버지에게서__물려받은__곧은__마음씨__", "빛나는 금발과 총명한 눈, 아버지를 닮은 곧은 마음씨"),
    0x099383: opening_line("               왕이__되는__사명에__불타고__있다__", "왕이 될 사명감에 불타고 있었다"),
    0x0993B6: opening_line("             사람들은__아트라스__왕자를__사랑하고__", "사람들은 아트라스 왕자를 사랑했고"),
    0x0993EA: opening_line("                 왕자는__사람들을__사랑했다__", "왕자도 사람들을 사랑했다"),
    0x0994BE: opening_line("             이셀하사__전체를__대지진이__덥쳤다__", "어느 날, 대지진이 이셀하사 전역을 덮쳤다"),
}


def validate_opening_header(data: bytes) -> None:
    if len(data) != OPENING_SUPPORTED_SIZE:
        raise ValueError(f"지원하지 않는 OPENING.EXE 크기: {len(data)}")
    if data[:2] != b"MZ":
        raise ValueError("OPENING.EXE의 MZ 헤더가 없습니다.")
    ne = int.from_bytes(data[0x3C:0x40], "little")
    if ne + 2 > len(data) or data[ne:ne + 2] != b"NE":
        raise ValueError("OPENING.EXE의 NE 헤더가 없습니다.")


def _validate_opening_render_cells(raw: bytes, *, offset: int) -> None:
    """Validate the PC-98-style opening renderer's 2-byte display-cell stream.

    Leading ASCII spaces are positioning bytes. Inside the rendered body, every
    visible cell must consume exactly two bytes: CP949 double-byte text, '__' or
    another paired padding cell. This catches the R25 bug where two 1-byte commas
    kept the total length even while shifting the renderer by one byte twice.
    """
    i = 0
    while i < len(raw) and raw[i] == 0x20:
        i += 1
    # trailing paired '_' padding is part of the cell stream; ASCII spaces are
    # permitted only as the leading coordinate field.
    if (len(raw) - i) & 1:
        raise ValueError(f"OPENING.EXE 0x{offset:X}: 표시 셀 본문 길이가 홀수입니다")
    while i < len(raw):
        pair = raw[i:i+2]
        if len(pair) != 2:
            raise ValueError(f"OPENING.EXE 0x{offset:X}: 불완전 표시 셀")
        if pair == b"__":
            i += 2; continue
        if pair[0] < 0x80 or pair[1] < 0x80:
            raise ValueError(f"OPENING.EXE 0x{offset:X}: 1바이트 문자가 표시 셀 내부에 있습니다: {pair.hex()}")
        try:
            glyph = pair.decode("cp949")
        except UnicodeDecodeError as exc:
            raise ValueError(f"OPENING.EXE 0x{offset:X}: 잘못된 CP949 표시 셀 {pair.hex()}") from exc
        # OPENING.EXE의 한국어 폰트 테이블은 CP949에 존재하는 모든 기호를
        # 갖고 있지 않다. 특히 R26의 U+2026(…)는 인코딩은 성공하지만 실제
        # 게임에서는 엉뚱한 한글처럼 표시됐다. 내레이션은 안전한 한글/셀만 쓴다.
        if glyph in {"…", "，", "。"}:
            raise ValueError(f"OPENING.EXE 0x{offset:X}: 한국판 폰트 비지원 기호 {glyph!r}")
        i += 2


def inspect_opening(data: bytes) -> list[dict[str, object]]:
    validate_opening_header(data)
    rows = []
    for slot in OPENING_SLOTS:
        current = data[slot.offset:slot.offset + len(slot.original)]
        if slot.offset < 0x099A00:
            _validate_opening_render_cells(slot.desired, offset=slot.offset)
            # Once a slot is already at the R26 target, validate the actual bytes
            # too; this catches later components accidentally reintroducing a
            # one-byte punctuation/cell shift after the text patch has run.
            if current == slot.desired:
                _validate_opening_render_cells(current, offset=slot.offset)
        accepted = (slot.original, slot.desired)
        legacy = OPENING_V170_VARIANTS.get(slot.offset)
        if legacy is not None:
            accepted += (legacy,)
        legacy171 = OPENING_V171_VARIANTS.get(slot.offset)
        if legacy171 is not None:
            accepted += (legacy171,)
        legacy172 = OPENING_V172_VARIANTS.get(slot.offset)
        if legacy172 is not None:
            accepted += (legacy172,)
        legacy173 = OPENING_V173_VARIANTS.get(slot.offset)
        if legacy173 is not None:
            accepted += (legacy173,)
        legacy174 = OPENING_V174_VARIANTS.get(slot.offset)
        if legacy174 is not None:
            accepted += (legacy174,)
        legacy175 = OPENING_V175_VARIANTS.get(slot.offset)
        if legacy175 is not None:
            accepted += (legacy175,)
        legacy1710 = OPENING_V1710_VARIANTS.get(slot.offset)
        if legacy1710 is not None:
            accepted += (legacy1710,)
        legacy_r24 = OPENING_R24_VARIANTS.get(slot.offset)
        if legacy_r24 is not None:
            accepted += (legacy_r24,)
        legacy_r25 = OPENING_R25_VARIANTS.get(slot.offset)
        if legacy_r25 is not None:
            accepted += (legacy_r25,)
        legacy_r26 = OPENING_R26_VARIANTS.get(slot.offset)
        if legacy_r26 is not None:
            accepted += (legacy_r26,)
        legacy_r36 = OPENING_R36_VARIANTS.get(slot.offset)
        if legacy_r36 is not None:
            accepted += (legacy_r36,)
        if current not in accepted:
            raise ValueError(
                f"OPENING.EXE 0x{slot.offset:X} 문구가 예상과 다릅니다: "
                f"{current.hex(' ')} ({slot.purpose})"
            )
        rows.append({
            "offset": slot.offset,
            "purpose": slot.purpose,
            "current": current.decode("cp949"),
            "original": slot.original.decode("cp949"),
            "desired": slot.desired.decode("cp949"),
            "length": len(slot.original),
        })
    return rows


def build_opening_target(data: bytes) -> tuple[bytes, list[dict[str, object]]]:
    inspect_opening(data)
    buf = bytearray(data)
    changes: list[dict[str, object]] = []
    for slot in OPENING_SLOTS:
        current = bytes(buf[slot.offset:slot.offset + len(slot.original)])
        if current != slot.desired:
            buf[slot.offset:slot.offset + len(slot.desired)] = slot.desired
            changes.append({
                "offset": slot.offset,
                "group": "opening",
                "purpose": slot.purpose,
                "before": current.decode("cp949"),
                "after": slot.desired.decode("cp949"),
                "byte_length": len(slot.desired),
            })
    target = bytes(buf)
    inspect_opening(target)
    return target, changes


def _visible_scene_payload(payload: bytes) -> str:
    return payload.split(b"\xFF", 1)[0].decode("cp949")


# v1.0.23 고유명사 재검수에서 발견된 길이 변화 항목.  일반 전역 치환과
# 분리하여 파일/컨테이너/오프셋을 정확히 검증한 뒤 처리한다.
PULDAM_OLD_PATTERN = b"\x1E" + cp("플다암") + b"\x04"
PULDAM_NEW_PATTERN = b"\x1E" + cp("풀담") + b"\x04" + b"\xFF\xFF"

F200_SEG3_FILE = 0x3400
F200_BERGA_RECORD_PTR_FILE = F200_SEG3_FILE + 0x0032
F200_BERGA_OLD_SEG = 0x04D9
F200_BERGA_NEW_SEG = 0x06E5
F200_BERGA_OLD_FILE = F200_SEG3_FILE + F200_BERGA_OLD_SEG
F200_BERGA_NEW_FILE = F200_SEG3_FILE + F200_BERGA_NEW_SEG
F200_BERGA_OLD_PAYLOAD = cp("벨가광산") + b"\x07"
F200_BERGA_NEW_PAYLOAD = cp("베르가광산") + b"\x07"


def _patch_special_proper_nouns(
    path: Path, before: bytes, after: bytearray, allowed: set[int],
    changes: list[dict[str, object]], totals: dict[str, int],
) -> None:
    name = path.name.upper()

    # D_201 화자명은 플다암(6바이트) -> 풀담(4바이트)으로 짧아진다.
    # 1E <name> 04 제어 순서를 유지하고 종료 코드 뒤의 FF 두 바이트를
    # 패딩으로 사용한다. DLL 크기와 이후 대사 오프셋은 그대로다.
    if name == "D_201.DLL":
        old = PULDAM_OLD_PATTERN
        new = PULDAM_NEW_PATTERN
        old_hits = []
        pos = 0
        snapshot = bytes(after)
        while True:
            hit = snapshot.find(old, pos)
            if hit < 0:
                break
            old_hits.append(hit)
            pos = hit + len(old)
        if old_hits:
            for hit in old_hits:
                after[hit:hit + len(old)] = new
                allowed.update(range(hit, hit + len(old)))
            totals["플다암 → 풀담"] = totals.get("플다암 → 풀담", 0) + len(old_hits)
            changes.append({
                "group": "direct_proper_noun",
                "purpose": "보스 화자명 풀담 통일",
                "before": "플다암",
                "after": "풀담",
                "count": len(old_hits),
                "offsets": [x + 1 for x in old_hits],
                "byte_length_each": len(old) - 2,
                "padding": "04h 종료 뒤 FF 2바이트; 1E <name> 04 컨테이너 의미 유지",
            })

    # F_200의 활성 워프/지명 테이블은 '벨가광산' 슬롯(8바이트)이
    # '베르가광산'(10바이트)을 담을 수 없다. 세그먼트 3 코드 시작 직전의
    # 검증된 11바이트 00 패딩으로 새 문자열+07 terminator를 옮기고, 해당
    # 레코드의 문자열 포인터 한 개만 04D9 -> 06E5로 바꾼다.
    if name == "F_200.DLL":
        if len(after) <= F200_BERGA_NEW_FILE + len(F200_BERGA_NEW_PAYLOAD):
            raise ValueError("F_200.DLL이 예상보다 짧아 베르가광산 슬롯을 검증할 수 없습니다")
        ptr = int.from_bytes(after[F200_BERGA_RECORD_PTR_FILE:F200_BERGA_RECORD_PTR_FILE + 2], "little")
        old_payload = bytes(after[F200_BERGA_OLD_FILE:F200_BERGA_OLD_FILE + len(F200_BERGA_OLD_PAYLOAD)])
        new_payload = bytes(after[F200_BERGA_NEW_FILE:F200_BERGA_NEW_FILE + len(F200_BERGA_NEW_PAYLOAD)])
        if ptr == F200_BERGA_NEW_SEG:
            if new_payload != F200_BERGA_NEW_PAYLOAD:
                raise ValueError("F_200.DLL 베르가광산 이행 포인터는 있으나 새 문자열 슬롯이 예상과 다릅니다")
        elif ptr == F200_BERGA_OLD_SEG:
            if old_payload != F200_BERGA_OLD_PAYLOAD:
                raise ValueError("F_200.DLL 벨가광산 원본 문자열이 예상과 다릅니다")
            if any(new_payload):
                raise ValueError("F_200.DLL 3:06E5 베르가광산용 패딩 영역이 비어 있지 않습니다")
            after[F200_BERGA_NEW_FILE:F200_BERGA_NEW_FILE + len(F200_BERGA_NEW_PAYLOAD)] = F200_BERGA_NEW_PAYLOAD
            after[F200_BERGA_RECORD_PTR_FILE:F200_BERGA_RECORD_PTR_FILE + 2] = F200_BERGA_NEW_SEG.to_bytes(2, "little")
            allowed.update(range(F200_BERGA_NEW_FILE, F200_BERGA_NEW_FILE + len(F200_BERGA_NEW_PAYLOAD)))
            allowed.update(range(F200_BERGA_RECORD_PTR_FILE, F200_BERGA_RECORD_PTR_FILE + 2))
            totals["벨가광산 → 베르가광산"] = totals.get("벨가광산 → 베르가광산", 0) + 1
            changes.append({
                "group": "location_table_relocation",
                "purpose": "F_200 활성 지명표 베르가광산 통일",
                "before": "벨가광산",
                "after": "베르가광산",
                "count": 1,
                "offsets": [F200_BERGA_RECORD_PTR_FILE, F200_BERGA_NEW_FILE],
                "byte_length_each": len(F200_BERGA_NEW_PAYLOAD),
                "relocation": "segment3 pointer 04D9 -> 06E5; 11-byte zero padding reused",
            })
        else:
            raise ValueError(f"F_200.DLL 베르가광산 레코드 포인터가 예상과 다릅니다: 0x{ptr:04X}")


ENDING_FLORA_SPEAKER_FILE_OFFSET = 0x03EE82 + 26
ENDING_FLORA_SPEAKER_CODE_FILE_OFFSET = 0x03D2BD

def _validate_ending_flora_anchor(data: bytes) -> None:
    """Keep the Freya->Flora speaker restart aligned with ENDING's hardcoded SI=029Ch.

    Segment 10 code at file offset 0x3D2BD executes MOV SI,029Ch before the
    first Flora line after Freya.  The corresponding segment-11 byte must be
    control 03h followed by the fixed 8-byte speaker field '플로라  '.
    """
    code = data[ENDING_FLORA_SPEAKER_CODE_FILE_OFFSET:ENDING_FLORA_SPEAKER_CODE_FILE_OFFSET + 3]
    if code != b"\xBE\x9C\x02":
        raise ValueError(
            "ENDING.DLL 플로라 화자 시작 코드가 예상과 다릅니다: " + code.hex(" ")
        )
    off = ENDING_FLORA_SPEAKER_FILE_OFFSET
    expected = b"\x03" + cp("플로라  ")
    actual = data[off:off + len(expected)]
    if actual != expected:
        raise ValueError(
            f"ENDING.DLL 0x{off:X}: 프레이아 이후 플로라 화자 앵커가 어긋났습니다: "
            f"{actual.hex(' ')} != {expected.hex(' ')}"
        )


def build_direct_targets(
    root: Path, *, apply_proper_nouns: bool, apply_ending_text: bool,
) -> tuple[list[tuple[Path, bytes, bytes, list[dict[str, object]]]], dict[str, int]]:
    encoded = []
    for old, new in (DIRECT_NOUN_RULES if apply_proper_nouns else ()):
        ob, nb = cp(old), cp(new)
        if len(ob) != len(nb):
            raise ValueError(f"직접 치환 길이 불일치: {old}→{new}")
        encoded.append((old, new, ob, nb))

    slots_by_file: dict[str, list[SceneTextSlot]] = {}
    for slot in (SCENE_TERMINOLOGY_SLOTS if apply_proper_nouns else ()):
        slots_by_file.setdefault(slot.file_name.upper(), []).append(slot)

    results = []
    totals: dict[str, int] = {}
    for path in direct_files(root):
        before = path.read_bytes()
        after = bytearray(before)
        changes: list[dict[str, object]] = []
        allowed: set[int] = set()

        # Same-length global proper-noun replacements.
        for old, new, ob, nb in encoded:
            offsets = []
            pos = 0
            while True:
                hit = bytes(after).find(ob, pos)
                if hit < 0:
                    break
                offsets.append(hit)
                pos = hit + len(ob)
            if offsets:
                for hit in offsets:
                    after[hit:hit + len(ob)] = nb
                    allowed.update(range(hit, hit + len(ob)))
                key = f"{old} → {new}"
                totals[key] = totals.get(key, 0) + len(offsets)
                changes.append({
                    "group": "direct_proper_noun",
                    "purpose": "SCENA/ENDING 고유명사 통일",
                    "before": old,
                    "after": new,
                    "count": len(offsets),
                    "offsets": offsets,
                    "byte_length_each": len(ob),
                })

        # Same-length speaker/title labels: 1E <name> 04.  Only the
        # metadata field is changed here; dialogue-body terminology is handled
        # by the v3.10 CSV so Scene Editor v0.3.10 needs no compatibility code.
        for old, new in (SPEAKER_LABEL_RULES if apply_proper_nouns else ()):
            ob, nb = cp(old), cp(new)
            pattern = b"\x1E" + ob + b"\x04"
            offsets = []
            pos = 0
            snapshot = bytes(after)
            while True:
                hit = snapshot.find(pattern, pos)
                if hit < 0:
                    break
                text_offset = hit + 1
                offsets.append(text_offset)
                pos = hit + len(pattern)
            if offsets:
                for hit in offsets:
                    after[hit:hit + len(ob)] = nb
                    allowed.update(range(hit, hit + len(ob)))
                key = f"화자명 {old} → {new}"
                totals[key] = totals.get(key, 0) + len(offsets)
                changes.append({
                    "group": "speaker_label_terminology",
                    "purpose": "SCENA 화자명 통일",
                    "before": old,
                    "after": new,
                    "count": len(offsets),
                    "offsets": offsets,
                    "byte_length_each": len(ob),
                    "container": "1E <name> 04",
                })

        if apply_proper_nouns:
            _patch_special_proper_nouns(path, before, after, allowed, changes, totals)

        # NUL 종료형 ENDING.DLL 대사 슬롯. 제어 바이트와 NUL 위치는
        # 보존하고 남는 영역만 기존과 동일한 후행 ASCII 공백으로 채운다.
        if apply_ending_text and path.name.upper() == "ENDING.DLL":
            for slot in ENDING_TEXT_SLOTS:
                begin = slot.file_offset
                finish = begin + slot.capacity
                if finish >= len(after) or after[finish] != 0:
                    raise ValueError(
                        f"ENDING.DLL 0x{begin:X}: 문자열 경계 또는 NUL 종료가 예상과 다릅니다"
                    )
                current = bytes(after[begin:finish])
                if not _ending_slot_matches(slot, current):
                    raise ValueError(
                        f"ENDING.DLL 0x{begin:X} 문구가 예상과 다릅니다: "
                        f"{current.hex(' ')} ({slot.purpose})"
                    )
                desired = _ending_slot_target(slot, current)
                if current != desired:
                    after[begin:finish] = desired
                    allowed.update(range(begin, finish))
                    changes.append({
                        "group": "ending_text",
                        "category": slot.category,
                        "purpose": slot.purpose,
                        "before": slot.before_text,
                        "after": slot.after_text,
                        "count": 1,
                        "offsets": [begin],
                        "byte_length_each": slot.capacity,
                        "padding": "trailing ASCII spaces before preserved NUL",
                    })
                    key = f"엔딩 {slot.category}"
                    totals[key] = totals.get(key, 0) + 1
            _validate_ending_flora_anchor(bytes(after))

        # Variable-length terminology slots use ED2MAIN's verified FF no-op
        # padding, exactly as Scene Editor v0.3.8 does.
        for slot in slots_by_file.get(path.name.upper(), []):
            begin = slot.file_offset
            finish = begin + slot.capacity
            if finish > len(after):
                raise ValueError(
                    f"{path.name} 0x{begin:X}: 문자열 슬롯이 파일 범위를 벗어납니다"
                )
            current = bytes(after[begin:finish])
            # Dialogue Linebreak Tool may replace an ASCII word-separating space
            # with inline 01h while keeping the same visible sentence.  Treat a
            # line-broken *desired* sentence as already current instead of
            # rejecting it or erasing the presentation control.  This keeps the
            # standalone Text Patch safe even when it is run after linebreak.
            presentation_desired = False
            if current not in slot.accepted:
                visible = current.rstrip(b"\xFF").replace(b"\x01", b" ")
                try:
                    presentation_desired = visible.decode("cp949") == slot.desired_text
                except UnicodeDecodeError:
                    presentation_desired = False
                if not presentation_desired:
                    raise ValueError(
                        f"{path.name} 0x{begin:X} 문구가 예상과 다릅니다: "
                        f"{current.hex(' ')} ({slot.purpose})"
                    )
            if current != slot.desired and not presentation_desired:
                after[begin:finish] = slot.desired
                allowed.update(range(begin, finish))
                before_text = _visible_scene_payload(current)
                changes.append({
                    "group": "scene_terminology",
                    "purpose": slot.purpose,
                    "before": before_text,
                    "after": slot.desired_text,
                    "count": 1,
                    "offsets": [begin],
                    "byte_length_each": slot.capacity,
                    "padding": "FF no-op",
                })
                key = slot.purpose
                totals[key] = totals.get(key, 0) + 1

        if changes:
            after_bytes = bytes(after)
            if len(after_bytes) != len(before):
                raise RuntimeError(f"직접 문자열 패치로 파일 크기가 변했습니다: {path}")
            actual = {i for i, (a, b) in enumerate(zip(before, after_bytes)) if a != b}
            if not actual.issubset(allowed):
                raise RuntimeError(f"직접 문자열 선언 범위 밖이 변경됐습니다: {path}")
            results.append((path, before, after_bytes, changes))
    return results, totals


def verify_shared_terminology(root: Path, ed2main_data: bytes) -> dict[str, object]:
    ui_terms = {
        "수면 버섯": ed2main_data.count(cp("수면 버섯")),
        "사일레스": ed2main_data.count(cp("사일레스")),
    }
    if ui_terms["수면 버섯"] < 1 or ui_terms["사일레스"] < 1:
        raise RuntimeError(f"ED2MAIN 기준 용어를 찾지 못했습니다: {ui_terms}")

    scene_rows = []
    if os.environ.get("ED2_TEXT_SKIP_SCENA") == "1":
        return {"ed2main": ui_terms, "scene_slots": scene_rows, "scena_owner": "PC98 dialogue CSV v4.0R2"}
    for slot in SCENE_TERMINOLOGY_SLOTS:
        path = root / "SCENA" / slot.file_name
        if not path.is_file():
            path = root / "scena" / slot.file_name
        if not path.is_file():
            raise FileNotFoundError(f"씬 DLL을 찾을 수 없습니다: {slot.file_name}")
        data = path.read_bytes()
        current = data[slot.file_offset:slot.file_offset + slot.capacity]
        state = "canonical" if current == slot.desired else "other"
        scene_rows.append({
            "file": slot.file_name,
            "offset": slot.file_offset,
            "purpose": slot.purpose,
            "state": state,
            "visible_text": _visible_scene_payload(current),
        })
        if current != slot.desired:
            raise RuntimeError(
                f"{slot.file_name} 0x{slot.file_offset:X}: 통일 문구 적용 검증 실패"
            )
    return {"ed2main": ui_terms, "scene_slots": scene_rows}


def ensure_backup(path: Path, suffix: str) -> Path:
    backup = path.with_name(path.name + suffix)
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        return backup
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


def patch_project(
    root: Path, *, check_only: bool, labels_only: bool,
    no_wording: bool, no_proper_nouns: bool, no_opening: bool, no_ending: bool,
) -> int:
    ed2main = root / "ED2MAIN.EXE"
    ed_before = ed2main.read_bytes()
    ui.inspect(ed_before)
    ed_target, ed_changes = ui.build_target(
        ed_before, labels_only, no_wording, no_proper_nouns
    )
    # Battle UI grammar belongs to this UI/text patch.  Do not split it into a
    # separate AIO component: it shares ED2MAIN display ownership and journal.
    ed_target, escape_changes = build_escape_battle_ui_target(ed_target)
    ed_changes.extend(escape_changes)

    direct_targets = []
    direct_totals: dict[str, int] = {}
    if not no_proper_nouns or not no_ending:
        direct_targets, direct_totals = build_direct_targets(
            root,
            apply_proper_nouns=not no_proper_nouns,
            apply_ending_text=not no_ending,
        )

    opening = root / "OPENING.EXE"
    opening_before = opening_target = None
    opening_changes: list[dict[str, object]] = []
    if not no_opening:
        if not opening.is_file():
            raise FileNotFoundError(f"OPENING.EXE를 찾을 수 없습니다: {opening}")
        opening_before = opening.read_bytes()
        opening_target, opening_changes = build_opening_target(opening_before)

    total_changes = len(ed_changes) + sum(len(x[3]) for x in direct_targets) + len(opening_changes)
    print(f"대상 게임 폴더: {root}")
    print(f"ED2MAIN 변경 항목: {len(ed_changes)}")
    print(f"SCENA/ENDING 변경 파일: {len(direct_targets)}")
    print(f"OPENING 변경 항목: {len(opening_changes)}")

    if check_only:
        for row in ed_changes:
            print(f"  ED2MAIN 0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
        for path, _before, _after, rows in direct_targets:
            for row in rows:
                print(f"  {path.relative_to(root)}: {row['before']} -> {row['after']} {row['count']}건")
        for row in opening_changes:
            print(f"  OPENING 0x{row['offset']:X}: {row['purpose']}")
        return 0

    if total_changes == 0:
        print("이미 요청한 통합 패치 상태입니다.")
        return 0

    # 모든 대상을 먼저 완성·검증한 뒤 백업과 저장을 시작한다.
    if len(ed_target) != len(ed_before):
        raise RuntimeError("ED2MAIN.EXE 크기가 변경됐습니다.")
    ed_allowed: set[int] = set()
    for row in ed_changes:
        off = int(row["offset"])
        ed_allowed.update(range(off, off + int(row["byte_length"])))
    ed_actual = {i for i, (a, b) in enumerate(zip(ed_before, ed_target)) if a != b}
    if not ed_actual.issubset(ed_allowed):
        raise RuntimeError("ED2MAIN 선언 영역 밖이 변경됐습니다.")
    ui.inspect(ed_target)

    opening_allowed: set[int] = set()
    opening_actual: set[int] = set()
    if opening_before is not None and opening_target is not None:
        if len(opening_target) != len(opening_before):
            raise RuntimeError("OPENING.EXE 크기가 변경됐습니다.")
        for row in opening_changes:
            off = int(row["offset"])
            opening_allowed.update(range(off, off + int(row["byte_length"])))
        opening_actual = {
            i for i, (a, b) in enumerate(zip(opening_before, opening_target)) if a != b
        }
        if not opening_actual.issubset(opening_allowed):
            raise RuntimeError("OPENING 선언 영역 밖이 변경됐습니다.")
        inspect_opening(opening_target)

    backups = []
    if ed_changes:
        backups.append(str(ensure_backup(ed2main, ui.BACKUP_SUFFIX)))
    for path, _before, _after, _rows in direct_targets:
        backups.append(str(ensure_backup(path, DIRECT_BACKUP_SUFFIX)))
    if opening_changes:
        backups.append(str(ensure_backup(opening, OPENING_BACKUP_SUFFIX)))

    written: list[tuple[Path, bytes]] = []
    try:
        if ed_changes:
            atomic_write(ed2main, ed_target)
            written.append((ed2main, ed_target))
        for path, _before, after, _rows in direct_targets:
            atomic_write(path, after)
            written.append((path, after))
        if opening_changes and opening_target is not None:
            atomic_write(opening, opening_target)
            written.append((opening, opening_target))
        for path, expected in written:
            if path.read_bytes() != expected:
                raise RuntimeError(f"저장 후 바이트 검증 실패: {path}")
    except Exception:
        # 쓰기 중 실패하면 이번 패치가 만든/사용한 백업으로 가능한 범위에서 복구한다.
        for path, _expected in reversed(written):
            if path == ed2main:
                backup = path.with_name(path.name + ui.BACKUP_SUFFIX)
            elif path == opening:
                backup = path.with_name(path.name + OPENING_BACKUP_SUFFIX)
            else:
                backup = path.with_name(path.name + DIRECT_BACKUP_SUFFIX)
            if backup.is_file():
                atomic_write(path, backup.read_bytes(), journal=False)
        raise

    remaining: dict[str, int] = {}
    if not no_proper_nouns:
        files = direct_files(root)
        for old, _new in DIRECT_NOUN_RULES:
            count = sum(path.read_bytes().count(cp(old)) for path in files)
            if count:
                remaining[old] = count
        if remaining:
            raise RuntimeError(f"SCENA/ENDING 구표기가 남았습니다: {remaining}")
        old_labels = {}
        files = direct_files(root)
        for old, _new in SPEAKER_LABEL_RULES:
            pattern = b"\x1E" + cp(old) + b"\x04"
            count = sum(path.read_bytes().count(pattern) for path in files)
            if count:
                old_labels[old] = count
        if old_labels:
            raise RuntimeError(f"SCENA 구 화자명이 남았습니다: {old_labels}")

    shared_terminology = None
    if not no_proper_nouns:
        shared_terminology = verify_shared_terminology(root, ed_target)

    report = {
        "patch_version": VERSION,
        "root": str(root),
        "options": {
            "labels_only": labels_only,
            "no_wording": no_wording,
            "no_proper_nouns": no_proper_nouns,
            "no_opening": no_opening,
            "no_ending": no_ending,
        },
        "ed2main": {
            "file": str(ed2main),
            "size_before": len(ed_before),
            "size_after": len(ed_target),
            "sha256_before": sha256(ed_before),
            "sha256_after": sha256(ed_target),
            "changes": ed_changes,
            "changes_limited_to_declared_slots": ed_actual.issubset(ed_allowed),
        },
        "escape_battle_ui": inspect_escape_battle_ui(ed_target),
        "direct_proper_nouns": {
            "files_scanned": len(direct_files(root)),
            "changed_files": [
                {
                    "file": str(path.relative_to(root)),
                    "size": len(before),
                    "sha256_before": sha256(before),
                    "sha256_after": sha256(after),
                    "changes": rows,
                }
                for path, before, after, rows in direct_targets
            ],
            "replacement_totals": direct_totals,
            "remaining_old_names": remaining,
        },
        "shared_terminology": shared_terminology,
        "opening": None if no_opening else {
            "file": str(opening),
            "size_before": len(opening_before or b""),
            "size_after": len(opening_target or b""),
            "sha256_before": sha256(opening_before or b""),
            "sha256_after": sha256(opening_target or b""),
            "changes": opening_changes,
            "changes_limited_to_declared_slots": opening_actual.issubset(opening_allowed),
        },
        "backups": backups,
        "validation": {
            "all_file_sizes_unchanged": True,
            "saved_bytes_match": True,
            "ed2main_ne_valid": True,
            "opening_ne_valid": no_opening or True,
        },
    }
    report_path = root / REPORT_NAME
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"통합 패치 완료: 총 {total_changes}개 항목")
    for key, value in direct_totals.items():
        print(f"  {key}: {value}건")
    print(f"보고서: {report_path.name}")
    return 0


def restore_project(root: Path) -> int:
    """Restore only text-patch-owned bytes.

    Emergency whole-file backups are still kept, but automatic restore never
    copies them over files that may contain later ending, opening, shop, or
    dialogue changes.
    """
    restored: list[tuple[Path, int]] = []
    candidates = [root / "ED2MAIN.EXE", root / "OPENING.EXE", *direct_files(root)]
    for path in candidates:
        if not path.is_file():
            continue
        try:
            count = selective_restore(path, TEXT_PATCH_JOURNAL_COMPONENT)
        except FileNotFoundError:
            continue
        restored.append((path, count))

    if not restored:
        print(
            "선택적 텍스트 패치 복원 기록을 찾을 수 없습니다. "
            "기존 전체 백업은 다른 패치를 지울 수 있어 자동 복원하지 않습니다.",
            file=sys.stderr,
        )
        return 2
    print(f"선택적 복원 완료: {len(restored)}개 파일")
    for path, count in restored:
        print(f"  {path.relative_to(root)}: {count}바이트")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=f"영웅전설 II 한국판 통합 텍스트 패치 v{VERSION}")
    ap.add_argument("path", nargs="?", default=".", help="게임 폴더 또는 ED2MAIN.EXE")
    ap.add_argument(
        "--labels-only", action="store_true",
        help="구버전 호환 옵션. 현재 버전은 관련 UI와 용어를 주문으로 복원",
    )
    ap.add_argument("--no-wording", action="store_true", help="ED2MAIN 추가 문장 교정을 제외")
    ap.add_argument("--no-proper-nouns", action="store_true", help="ED2MAIN·SCENA·ENDING 직접 용어·고유명사 교정을 제외")
    ap.add_argument("--no-opening", action="store_true", help="OPENING.EXE 문구 교정을 제외")
    ap.add_argument("--no-ending", action="store_true", help="ENDING.DLL 엔딩 대사 교정을 제외")
    action = ap.add_mutually_exclusive_group()
    action.add_argument("--check", action="store_true", help="검사만 수행")
    action.add_argument("--restore", action="store_true", help="각 파일을 이 패치 적용 전 백업으로 복원")
    args = ap.parse_args()
    try:
        root = resolve_root(Path(args.path))
        if args.restore:
            return restore_project(root)
        return patch_project(
            root,
            check_only=args.check,
            labels_only=args.labels_only,
            no_wording=args.no_wording,
            no_proper_nouns=args.no_proper_nouns,
            no_opening=args.no_opening,
            no_ending=args.no_ending,
        )
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
