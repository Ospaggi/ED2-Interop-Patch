#!/usr/bin/env python3
"""Dragon Slayer: The Legend of Heroes II Korean UI text core v1.7.15R50.

Patches exact, reviewed string slots in ED2MAIN.EXE only.  No SCENA DLL is
modified.  The EXE file is never resized. R42 also performs one explicitly validated NE
segment-85 data/relocation move inside existing alignment padding; no runtime
hook is added.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from ed2_patch_journal import record_patch, selective_restore
from ed2_ne_slot import patch_message_slot_0f, message_redirect_matches, parse_segments as ne_slot_segments

VERSION = "1.7.15R50"
SUPPORTED_SIZE = 1_848_336
BACKUP_SUFFIX = ".ui_text_patch.bak"
REPORT_NAME = "ED2_UI_TEXT_PATCH_REPORT.json"
JOURNAL_COMPONENT = "ed2_text_patch"


def cp(text: str) -> bytes:
    return text.encode("cp949")


def fixed(text: str, byte_length: int, *, newline: bool = False) -> bytes:
    """Encode and space-pad to an exact byte length.

    For strings ending in LF, padding is inserted before LF so the line control
    stays at the original final byte.
    """
    raw = cp(text)
    if len(raw) > byte_length:
        raise ValueError(f"문구가 슬롯보다 깁니다: {text!r} ({len(raw)}>{byte_length})")
    if newline:
        if not raw.endswith(b"\n"):
            raise ValueError("newline=True인데 LF로 끝나지 않습니다.")
        return raw[:-1] + b" " * (byte_length - len(raw)) + b"\n"
    return raw + b" " * (byte_length - len(raw))


@dataclass(frozen=True)
class Slot:
    offset: int
    original: bytes
    desired: bytes
    purpose: str
    group: str

    def __post_init__(self) -> None:
        if len(self.original) != len(self.desired):
            raise ValueError(f"슬롯 길이 불일치: {self.purpose}")



# Chapter title data in ED2MAIN segment 85.  Keep the 30-byte runtime
# TITLE_DATA row fixed-width; the chapter-refresh component copies this row
# back after loading a save.  ASCII spaces are half-width relative to Korean
# glyphs, so reducing the old 6/7 padding to 5/6 preserves the center while
# the title grows from `평화로운 날` to `평화로운 나날`.
CHAPTER_TITLE_SLOTS = (
    Slot(
        0x149480,
        cp("      서장  평화로운 날       "),
        cp("     서장  평화로운 나날      "),
        "서장 제목: 평화로운 날 → 평화로운 나날",
        "chapter_title",
    ),
)

# Core requested labels.
CORE_SLOTS = (
    Slot(0x149D52, cp("남다  "), cp("남음  "), "설정 화면 EP 표시", "core"),
    Slot(0x14B0FC, cp("남다 "), cp("남음 "), "상태 화면 다음 레벨 경험치", "core"),
    Slot(0x14B2FE, cp(" 버린다"), cp(" 버리기"), "필드 메뉴 명령", "core"),
    Slot(0x14B30D, cp("그외"), cp("기타"), "필드 메뉴 분류: 그외 → 기타", "core"),
    Slot(0x149AC9, cp("강함"), cp("상태"), "전투 메뉴 명령: 강함 → 상태", "core"),
)

# These 12 slots were changed from 주문 to 마법 by older patch revisions.
# R10 restores the original Korean terminology 주문. Story dialogue in SCENA
# is normalized separately by the integrated text patch.
MAGIC_LABEL_SLOTS = (
    Slot(0x149AA5, cp("주문"), cp("주문"), "전투 명령 메뉴", "magic_label"),
    Slot(0x149DB7, cp("주문"), cp("주문"), "자동 전투 설정: 공격 마법", "magic_label"),
    Slot(0x149DC1, cp("주문"), cp("주문"), "자동 회복 설정: 회복 마법", "magic_label"),
    Slot(0x14B0B9, cp("주문"), cp("주문"), "상태 화면: 마법능력", "magic_label"),
    Slot(0x14B2ED, cp("주문"), cp("주문"), "필드 메뉴 명령", "magic_label"),
)

MAGIC_SYSTEM_SLOTS = (
    Slot(0x14A9E1, cp("주문"), cp("주문"), "레벨업 능력 상승 메시지", "magic_system"),
    Slot(0x14AC3D, cp("주문"), cp("주문"), "전체 마법 봉인 메시지", "magic_system"),
    Slot(0x14AC7B, cp("주문"), cp("주문"), "개별 마법 봉인 메시지", "magic_system"),
    Slot(0x14ACBA, cp("주문"), cp("주문"), "마법 반사 메시지", "magic_system"),
    Slot(0x14B170, cp("주문"), cp("주문"), "마법 학습 대상 선택", "magic_system"),
    Slot(0x14B1A7, cp("주문"), cp("주문"), "마법 습득 메시지", "magic_system"),
    Slot(0x14B1FC, cp("주문"), cp("주문"), "마법 봉인 상태 메시지", "magic_system"),
)

# Reviewed UI wording.  Only unambiguous typos, spacing errors, and inconsistent
# command-label forms are included.  Every replacement fits the original slot.
WORDING_SLOTS = (
    Slot(0x14A904, cp("어느 힘을 높이겠습니까?"), fixed("어느 능력을 높일까요?", 23), "수동 레벨업 능력 선택", "wording"),
    Slot(0x14A935, cp("그 힘은 이 이상 올릴 수 없습니다"), fixed("그 능력은 더 올릴 수 없습니다", 32), "수동 레벨업 상한 안내", "wording"),
    Slot(0x14A9ED, cp("포인트 힘을 강하게 합니다 "), fixed("포인트로 능력을 높입니다.", 26), "레벨업 능력 상승 안내: PC-98 '力を 高められます。' 의미 복원", "wording"),
    Slot(0x14AA08, cp("강함이 "), cp("힘이 ") + b"\xFF\xFF", "자동 레벨업 능력명: 힘", "wording"),
    Slot(0x14AA10, cp("현명함이 "), cp("지혜가 ") + b"\xFF\xFF", "자동 레벨업 능력명: 지혜", "wording"),
    Slot(0x1499C4, cp("전투의 직전으로"), fixed("전투 직전으로", 15), "패배 후 선택지", "wording"),
    Slot(0x1499D4, cp("모험을 계속한다"), fixed("모험을 계속하기", 15), "패배 후 선택지: PC-98 '冒険の続きをする' 복원", "wording"),
    Slot(0x14998E, cp("얻었다 "), cp("얻었다."), "전투 아이템 획득 메시지 문장부호", "wording"),
    Slot(0x1499E5, cp("하지만 이이상은 가질수가 없습니다  "), cp("하지만 더 이상 가질 수 없습니다.") + b"\xFF" * 3, "소지 한도 안내 문장부호 + 자동 줄바꿈 방지", "wording"),
    Slot(0x149A09, cp("어떤것을 버리겠습니까? "), fixed("무엇을 버리겠습니까?", 23), "버릴 물건 선택", "wording"),
    Slot(0x149A3A, cp("습니다  "), cp("습니다. "), "아이템 보유 확정 메시지 문장부호", "wording"),
    Slot(0x149B42, cp("도망친다"), cp("도망가기"), "전투 설정 명령", "wording"),
    Slot(0x149CA8, cp("세이브를 중지 하겠습니다  "), fixed("세이브를 중지하겠습니다", 26), "저장 오류 안내", "wording"),
    Slot(0x149D23, cp("메세지"), cp("메시지"), "설정 메뉴 맞춤법", "wording"),
    Slot(0x149D34, cp("펑션표시"), cp("기능표시"), "설정 메뉴 용어", "wording"),
    Slot(0x149DD1, cp("전원의 설정을"), cp("모두의 설정을"), "자동 전투 일괄 설정", "wording"),
    Slot(0x149DED, cp("쓴다  "), cp("사용함"), "자동 전투 설정", "wording"),
    Slot(0x149DF4, cp("안쓴다"), cp("미사용"), "자동 전투 설정", "wording"),
    Slot(0x149E09, cp("세이브 데이타를 삭제해도 좋습니까?"), fixed("세이브 데이터를 삭제하시겠습니까?", 34), "저장 데이터 삭제 확인 자연화", "wording"),
    Slot(0x14A0A9, cp("주십시요"), cp("주십시오"), "디스크 삽입 안내", "wording"),
    Slot(0x14ABDA, cp("빼았았다.\n"), cp("빼앗았다.\n"), "HP 흡수 메시지", "wording"),
    Slot(0x14ACFA, cp("최근에 하던 곳 부터 시작하기"), fixed("최근에 하던 곳부터 시작하기", 28), "시작 메뉴 띄어쓰기", "wording"),
    # R35: ED2MAIN 메뉴/전투 메시지 PC-98 전수 재대조. 제어 바이트나
    # NUL 위치는 옮기지 않고 기존 payload 길이 안에서만 교정한다.
    Slot(0x14992B, cp("의 피해 !!"), fixed("의 피해!!", 10), "전투 피해 메시지 느낌표 앞 불필요한 공백 제거", "wording"),
    Slot(0x14994C, cp("^는 기절해 버렸다 "), cp("^는 기절해 버렸다."), "전투 기절 메시지 문장부호", "wording"),
    Slot(0x149960, cp("^을 해치웠다 "), cp("^을 해치웠다."), "격파 메시지 문장부호", "wording"),
    Slot(0x14996F, cp("전투에서 승리하였습니다 "), fixed("전투에서 승리했습니다.", 24), "전투 승리 메시지 자연화/문장부호", "wording"),
    Slot(0x149998, cp("^는 전투에 졌습니다 "), cp("^는 전투에서 패했다."), "전투 패배 메시지: PC-98 '戦いに敗れました。' 의미 복원", "wording"),
    Slot(0x149AE7, cp("^는 방어의 태세를 취했다"), fixed("^는 방어 태세를 취했다.", 24), "방어 행동 메시지 자연화/문장부호", "wording"),
    Slot(0x149B00, cp("은 도망을 쳤다"), fixed("은 도망쳤다.", 14), "도주 메시지 띄어쓰기/문장부호", "wording"),
    Slot(0x149B4C, cp("^는 독이 퍼지기 시작했다!!"), fixed("^는 독이 퍼지기 시작했다.", 26), "독 상태 메시지: PC-98 종결부 복원", "wording"),
    Slot(0x149B68, cp("^는 마비되어 버렸다!!"), cp("^는 마비되고 말았다!!"), "마비 상태 메시지 자연화", "wording"),
    Slot(0x149B7F, cp("^는 전신에 독이 퍼졌다!!"), cp("^는 온몸에 독이 퍼졌다!!"), "전신 독 상태 메시지 자연화", "wording"),
    Slot(0x149B99, cp("^는 잠들어있다 "), cp("^는 잠들어 있다"), "수면 상태 메시지 띄어쓰기", "wording"),
    Slot(0x149BAA, cp("^는 잠에서 깨어났다 "), cp("^는 잠에서 깨어났다."), "수면 회복 메시지 문장부호", "wording"),
    Slot(0x149BC0, cp("^는 혼란해하고 있다!!"), cp("^는 혼란스러워한다!!") + b"\xFF", "혼란 지속 메시지 자연화 + LF 직전 가시 패딩 제거", "wording"),
    Slot(0x149BD7, cp("^는 정신을 차렸다 "), cp("^는 정신을 차렸다."), "혼란 회복 메시지 문장부호", "wording"),
    Slot(0x149C20, cp("ＲＡＭ DATA를 로드"), fixed("RAM 데이터 로드", 18), "RAM 데이터 로드 표기 통일", "wording"),
    Slot(0x149CE4, cp(" 실행하여도 좋습니까?"), cp(" 실행해도 괜찮습니까?"), "로드/세이브 확인 문구 자연화", "wording"),
    Slot(0x149E2C, cp("게임을 종료하여도 괜찮겠습니까?"), fixed("게임을 종료하시겠습니까?", 31), "게임 종료 확인 문구 자연화", "wording"),
    Slot(0x14A027, cp("는 쓰기금지 되어 있습니다쓸 수 있는 상태로 해 주십시오"), fixed("는 쓰기 금지되어 있습니다. 쓸 수 있게 해 주십시오.", 54), "디스크 쓰기 금지 메시지 띄어쓰기/문장 경계 복원", "wording"),
    Slot(0x14A05E, cp("디스크를 확인해 주십시오좋습니까?"), fixed("디스크를 확인했습니까?", 33), "디스크 확인 메시지 깨진 문장 경계 자연화", "wording"),
    Slot(0x14A91C, cp("이것으로 좋겠습니까?"), fixed("이대로 괜찮습니까?", 20), "레벨업 확인 문구 자연화", "wording"),
    Slot(0x14A9AD, cp("^는 레벨업했다 "), cp("^는 레벨업했다."), "레벨업 메시지 문장부호", "wording"),
    Slot(0x14A9C8, cp("포인트 올랐다 "), cp("포인트 올랐다."), "최대 HP 상승 메시지 문장부호", "wording"),
    Slot(0x14A9E1, cp("주문능력이 "), cp("주문능력이 "), "레벨업 주문능력이 숫자 앞 공백 1칸", "wording"),
    Slot(0x14AC26, cp("늘었다 "), cp("늘었다."), "능력 상승 메시지 문장부호", "wording"),
    Slot(0x14AC2E, cp("내려갔다 "), cp("내려갔다."), "능력 하락 메시지 문장부호", "wording"),
    Slot(0x14AC38, cp("모든 주문은 봉인당했다 "), cp("모든 주문은 봉인되었다."), "전체 주문 봉인: PC-98 수동형 의미 복원", "wording"),
    Slot(0x14AC51, cp("는 빛에 싸였다 "), cp("는 빛에 싸였다."), "빛 효과 메시지 문장부호", "wording"),
    Slot(0x14AC62, cp("는 독에 중독되었다!!"), fixed("는 독에 중독됐다!!", 20), "독 효과 메시지 자연화", "wording"),
    Slot(0x14AC78, cp("는 주문을 봉인당했다 !!"), fixed("는 주문을 봉인당했다!!", 23), "주문 봉인 느낌표 앞 불필요한 공백 제거", "wording"),
    Slot(0x14ACA1, cp("더욱더잠들어버렸다!!"), cp("더욱 깊이 잠들었다!!"), "수면 심화 메시지 띄어쓰기/자연화", "wording"),
    Slot(0x14ACB7, cp("는 주문을 되돌려보냈다!!"), fixed("는 주문을 반사했다!!", 24), "주문 반사: PC-98 '跳ね返した' 간결화", "wording"),
    Slot(0x14ACD1, cp("는 정신이 들었다 "), cp("는 정신을 차렸다."), "상태 회복 메시지 자연화/문장부호", "wording"),
    Slot(0x14B1DF, cp("^을 썼다 "), cp("^을 썼다."), "아이템 사용 메시지 문장부호", "wording"),
    Slot(0x14B1E9, cp("의 효과가 있다 "), cp("의 효과가 있다."), "효과 메시지 문장부호", "wording"),
    # R42: 마법 무기 문장 경계 공백은 이 정적 Slot 표에서 처리하지 않는다.
    # R38의 DS:9679 gap/주문명 포인터 우회와 R41 후보의 런타임 helper는
    # 아래 item-effect 전용 데이터 정규화에서 모두 제거한다.
    # R36: 회피 문장은 `운 좋게 <대상>에게는 맞지` 뒤의 0F redirect가
    # 공유 종결부 ` 않았다`를 이어 붙이는 구조다. R35가 0x14B261의
    # 효과 없음 문장을 짧게 자연화하면서 기존 target 85:3E6C를 덮어썼다.
    # 이미 존재하는 ` 않았다.\n`(85:3E95) suffix로 redirect만 옮겨
    # `그러나 운 좋게 <대상>에게는 맞지 않았다.`를 복원한다.
    Slot(0x14B25E, b"\x6C\x3E", b"\x95\x3E", "회피 메시지 공유 종결부 redirect 복구", "wording"),
    Slot(0x14B275, cp("^는 잘 피했다 "), cp("^는 잘 피했다."), "회피 메시지 문장부호", "wording"),
    Slot(0x14B285, cp("의 HP는 회복되지 않았다 "), cp("의 HP는 회복되지 않았다."), "HP 회복 실패 메시지 문장부호", "wording"),
    Slot(0x14B29E, cp("^를 외웠다 "), cp("^를 외웠다."), "주문 시전 메시지 문장부호", "wording"),
    Slot(0x14B2B6, cp("회복되었다 "), cp("회복되었다."), "HP 회복 메시지 문장부호", "wording"),
    # R32: 사용자의 요청으로 HP 표시 수정 계열을 첫 문제 보고 전의
    # v1.3.18 / R27 상태로 되돌린다. R27은 `기절` 뒤 조기 NUL을 두어
    # 원래 상태/HP/EXP 렌더 경계를 그대로 사용했다.
    Slot(0x14B103, cp("기절해있다 "), cp("기절") + b"\x00" + b" " * 6, "기절 표시 R27 조기 NUL 상태로 롤백", "wording"),
    # DS:3CD2부터의 9개 상태표 마지막 두 0x80 엔트리는 두 상태칸을
    # 비우는 정상 패딩이다. R28의 00 상태만 이행 입력으로 받아 80 유지.
    Slot(0x14B0F2, b"\x80", b"\x80", "플레이어 상태표 두 번째 0x80 패딩 엔트리 원형 유지", "wording"),
    # 1Ah는 X 좌표가 아니라 DISPLAY_STR(86:8CBE)의 색상 제어값이다.
    # R29의 19h는 기절 글씨를 파란색 계열로 바꾸므로 반드시 1Ah 유지.
    Slot(0x14B102, b"\x1A", b"\x1A", "기절 색상 제어 1Ah(빨강) 원형 복구/유지", "wording"),
    # R30 이행 입력. R31에서는 SET_EXP의 기절 전용 EXP-overwrite 분기를
    # 우회하므로 이 copy count는 실행되지 않는다. 원본 7 words로 복구한다.
    Slot(0x15E35A, b"\x07", b"\x07", "SET_EXP 구형 기절 copy count 원형 복구", "wording"),
    # R30이 기절 뒤 잔여 EXP 두 자리를 숨기려고 공백으로 바꿨던 정적
    # template을 원본 `00`으로 복구한다. R31은 실제 EXP 8자리를 항상 갱신한다.
    Slot(0x1505C9, b"00", b"00", "상태창 EXP base template 마지막 2칸 원형 복구", "wording"),
    Slot(0x14B216, cp("아무 것도 일어나지 않았다 \n"), fixed("아무것도 일어나지 않았다.\n", 27, newline=True), "효과 없음 메시지 문장부호", "wording"),
    Slot(0x14B261, cp("에게는 듣지않았다 \n"), fixed("에게는 안 통했다.\n", 19, newline=True), "효과 없음 메시지: PC-98 '効かなかった' 자연화", "wording"),
)

# Actual fixed-width place-name table in the supplied Korean ED2MAIN.EXE.
# Only spelling inconsistencies are corrected.  Location-type suffixes such as
# 마을/항/광산 are not added, and no new spacing is introduced.
# All 27 slots remain declared so v1.5.0-applied files can be normalized back
# to the compact original UI labels while retaining the four spelling fixes.
LOCATION_SLOTS = (
    Slot(0x1506AB, fixed("크루즈", 12), fixed("크루즈", 12), "지명 유지: 크루즈", "location"),
    Slot(0x1506B7, fixed("베르가", 12), fixed("베르가", 12), "지명 유지: 베르가", "location"),
    Slot(0x1506C3, fixed("네리아", 13), fixed("네리아", 13), "지명 유지: 네리아", "location"),
    Slot(0x1506D0, fixed("론도", 12), fixed("론도", 12), "지명 유지: 론도", "location"),
    Slot(0x1506DC, fixed("랄파", 11), fixed("랄파", 11), "지명 유지: 랄파", "location"),
    Slot(0x1506E7, fixed("시리카", 12), fixed("시리카", 12), "지명 유지: 시리카", "location"),
    Slot(0x15070B, fixed("요르도", 12), fixed("요르도", 12), "지명 유지: 요르도", "location"),
    Slot(0x150730, fixed("세레", 12), fixed("세레", 12), "지명 유지: 세레", "location"),
    Slot(0x15073C, fixed("스엘", 12), fixed("스엘", 12), "지명 유지: 스엘", "location"),
    Slot(0x150748, fixed("암다", 12), fixed("암다", 12), "지명 유지: 암다", "location"),
    Slot(0x15076B, fixed("루드라", 13), fixed("루드라", 13), "지명 유지: 루드라", "location"),
    Slot(0x150778, fixed("가울", 11), fixed("카울", 11), "지명 철자: 가울 → 카울", "location"),
    Slot(0x150790, fixed("리셀", 12), fixed("리셀", 12), "지명 유지: 리셀", "location"),
    Slot(0x1507A7, fixed("파에트", 12), fixed("파에토", 12), "지명 철자: 파에트 → 파에토", "location"),
    Slot(0x1507CB, fixed("팡가스", 12), fixed("판가스", 12), "지명 철자: 팡가스 → 판가스", "location"),
    # 이 구간은 12바이트 고정 레코드를 통째로 선언한다. 예전 텍스트 시작
    # 오프셋 방식은 이웃 레코드의 패딩까지 슬롯에 포함해 왕가의무덤처럼
    # 글자 수가 바뀌는 경우 다음 지명을 침범할 수 있었다.
    Slot(0x150834, b"  " + cp("곶의동굴") + b"  ", b"  " + cp("곶의동굴") + b"  ", "지명 레코드 유지: 곶의동굴", "location"),
    Slot(0x150840, b" " + cp("시련의동굴") + b" ", b" " + cp("시련의동굴") + b" ", "지명 레코드 유지: 시련의동굴", "location"),
    Slot(0x15084C, b"  " + cp("왕가의묘") + b"  ", b" " + cp("왕가의무덤") + b" ", "지명 표기/정렬: 왕가의묘 → 왕가의무덤(12바이트 레코드 좌우 1칸)", "location"),
    Slot(0x150858, b"  " + cp("늑대의입") + b"  ", b"  " + cp("늑대의입") + b"  ", "지명 레코드 복구/유지: 늑대의입", "location"),
    Slot(0x150864, b"  " + cp("나락의입") + b"  ", b"  " + cp("나락의입") + b"  ", "지명 레코드 유지: 나락의입", "location"),
    Slot(0x150871, fixed("아네스의탑", 11), fixed("아네스의탑", 11), "지명 유지: 아네스의탑", "location"),
    Slot(0x15087C, fixed("사피아의호수", 14), fixed("사피아의호수", 14), "지명 유지: 사피아의호수", "location"),
    Slot(0x150888, b"  " + cp("모간의집") + b"  ", b"  " + cp("모건의집") + b"  ", "지명 레코드 경계/철자: 모간의집 → 모건의집", "location"),
    Slot(0x150894, b" " + cp("네사의면토") + b" ", cp("네사의변두리"), "지명 레코드 경계 수정/교정: 네사의면토/변토/변경/네사변두리 → 네사의변두리(12바이트 레코드)", "location"),
    Slot(0x1508A0, fixed("그로스토스성", 14), fixed("그로스토스성", 14), "지명 유지: 그로스토스성", "location"),
    Slot(0x1508AE, fixed("중앙정원", 12), fixed("중앙정원", 12), "지명 유지: 중앙정원", "location"),
    Slot(0x1508D2, fixed("옥좌의방", 11), fixed("옥좌의방", 11), "지명 유지: 옥좌의방", "location"),
)

# Values produced by v1.5.0.  They are accepted only as migration inputs and
# are normalized to the compact v1.5.1 labels above.
LEGACY_LOCATION_V150 = {
    0x1506AB: fixed("크루즈 마을", 12),
    0x1506B7: fixed("베르가 광산", 12),
    0x1506C3: fixed("네리아 항", 13),
    0x1506D0: fixed("론도 항", 12),
    0x1506DC: fixed("랄파 항", 11),
    0x1506E7: fixed("시리카 마을", 12),
    0x15070B: fixed("요르도 항", 12),
    0x150730: fixed("세레 마을", 12),
    0x15073C: fixed("스엘 마을", 12),
    0x150748: fixed("암다 마을", 12),
    0x15076B: fixed("루드라 항", 13),
    0x150778: fixed("카울 마을", 11),
    0x150790: fixed("리셀 항", 12),
    0x1507A7: fixed("파에토 마을", 12),
    0x1507CB: fixed("판가스", 12),
    0x150836: fixed("곶의 동굴", 11),
    0x150841: fixed("시련의 동굴", 13),
    0x15084E: fixed("왕가의 무덤", 12),
    0x15085A: fixed("늑대의 입", 12),
    0x150866: fixed("나락의 입", 11),
    0x150871: fixed("아네스의 탑", 11),
    0x15087C: fixed("사피아의 호수", 14),
    0x150888: b"  " + cp("모간의 집") + b" ",
    0x150894: b" " + cp("네사의 변토"),
    0x1508A0: fixed("그로스토스 성", 14),
    0x1508AE: fixed("중앙 정원", 12),
    0x1508D2: fixed("옥좌의 방", 11),
}

# Additional fixed-width proper nouns outside the 27-entry location table.
# These were absent from the v1.5.4 branch and are carried over from the later
# audit. They are optional under --no-proper-nouns.
EXTRA_PROPER_NOUN_SLOTS = (
    Slot(0x150820, cp("베른"), cp("베룬"), "지역명 표기 통일", "proper_noun"),
    Slot(0x15094A, cp("베른"), cp("베룬"), "이동 경로명 표기 통일", "proper_noun"),
)

# Migration input written by the discarded v1.6.0 branch. The canonical UI
# table remains the compact v1.5.4 spelling without newly inserted spaces.
V160_LOCATION_VARIANTS = {
    0x150894: b" " + cp("네사의 변토"),
}

# 왕가의무덤 과거 버전 이행 입력.
# 실제 고정폭 레코드는 0x15084C부터 12바이트다. v1.0.22~v1.0.28은
# 문자열 시작으로 오인한 0x15084E를 기준으로 수정하여 정렬 실패 또는
# 다음 ``늑대의입`` 레코드 침범을 만들었다. R16은 알려진 상태를 입력으로
# 허용하고 두 레코드를 각각 정확한 12바이트 경계로 정규화한다.
ROYAL_TOMB_RECORD_OFFSET = 0x15084C
ROYAL_TOMB_RECORD_DESIRED = b" " + cp("왕가의무덤") + b" "
ROYAL_TOMB_RECORD_VARIANTS = {
    0x15084C: (
        b"  " + cp("왕가의무덤"),                    # v1.0.22~v1.0.25
        b"   " + cp("왕가의무덤")[:9],              # v1.0.26~v1.0.27
        b"  \x01" + cp("왕가의무덤")[:9],          # v1.0.28
    ),
    0x150858: (
        cp("왕가의무덤")[-1:] + b" " + cp("늑대의입") + b"  ",  # v1.0.26~v1.0.28
    ),
}

# 네사의 변두리 레코드 과거 버전 이행 입력.
# 실제 지명 레코드는 0x150894부터 12바이트다. 과거 버전은 문자열 시작
# 0x150895를 11바이트 슬롯으로 보아 앞의 정렬 공백을 레코드 밖으로 오인했다.
# R21은 왕가의무덤과 같은 방식으로 정확한 레코드 경계를 사용하고
# 12바이트 전체에 `네사의변두리`를 기록한다.
R6_LOCATION_VARIANTS = {
    0x150894: b" " + cp("네사의변토") + b" ",
}

R19_LOCATION_VARIANTS = {
    0x150894: b" " + cp("네사의 변경"),
}

R20_LOCATION_VARIANTS = {
    0x150894: b" " + cp("네사변두리") + b" ",
}

# R42 magic-weapon sentence boundary.  No runtime hook/helper is used.
# The existing runtime message composition uses two 10h pointers to the hidden
# 06h-terminated item-use target at DS:3DDE.  R42 appends a replacement target
# with a literal ASCII 20h after the period to the end of NE segment 85, grows
# that logical segment by 12 bytes inside its existing sector-alignment gap,
# and repoints only those two data pointers.  Segment 86 and the EXE file size
# remain unchanged.
ITEM_EFFECT_SEG_INDEX = 85
ITEM_EFFECT_SEG_BASE = 0x147400
ITEM_EFFECT_SEG_OLD_LEN = 0xC332
ITEM_EFFECT_SEG_NEW_LEN = 0xC33E
ITEM_EFFECT_OLD_TARGET_SEG = 0x3DDE
ITEM_EFFECT_NEW_TARGET_SEG = ITEM_EFFECT_SEG_OLD_LEN
ITEM_EFFECT_PTR_SEGS = (0x3DD7, 0x3DDB)
ITEM_EFFECT_OLD_TARGET = b"\x0E" + cp("^을 썼다.") + b"\x06"
ITEM_EFFECT_OLD_TARGET_STOCK = b"\x0E" + cp("^을 썼다 ") + b"\x06"
ITEM_EFFECT_NEW_TARGET = b"\x0E" + cp("^을 썼다. ") + b"\x06"
ITEM_EFFECT_R40_GAP_FILE = 0x150A79
ITEM_EFFECT_R40_GAP_STOCK = b"\x00"
ITEM_EFFECT_R40_GAP_PATCHED = b" "
ITEM_EFFECT_CODE_SITE_FILE = 0x15EE34
ITEM_EFFECT_CODE_VANILLA = b"\xBE\x7A\x96"
ITEM_EFFECT_CODE_R40 = b"\xBE\x79\x96"
ITEM_EFFECT_CODE_R41 = b"\xE8\xC9\x5F"
ITEM_EFFECT_R41_CAVE_FILE = 0x154E00
ITEM_EFFECT_R41_CAVE = bytes.fromhex("BE 0D 3D 0E E8 B7 76 BE 7A 96 C3")
ITEM_EFFECT_R41_CAVE_CLEAR = bytes(len(ITEM_EFFECT_R41_CAVE))


# R44: sleep-message shared substring entry correction.
# Stock uses one full string and two entry points:
#   DS:38A1 = full repeated-sleep wording
#   DS:38A7 = initial-sleep substring start (stock layout only)
# R35 rewrote the full Korean string to `더욱 깊이 잠들었다!!`, which moves the
# actual `잠들었다!!` substring to DS:38AB.  Leaving the original 38A7 immediate
# starts decoding at the second byte of CP949 `깊` and corrupts the rendered
# target/status spacing.  R44 changes only that existing immediate; no hook or
# renderer change is added.
SLEEP_MESSAGE_SEG_INDEX = 85
SLEEP_MESSAGE_FULL_SEG = 0x38A1
SLEEP_MESSAGE_SHORT_STOCK_SEG = 0x38A7
SLEEP_MESSAGE_SHORT_FINAL_SEG = 0x38AB
SLEEP_MESSAGE_CODE_SEG_INDEX = 86
SLEEP_MESSAGE_CODE_SEG_OFF = 0x7D11
SLEEP_MESSAGE_PTR_STOCK = bytes.fromhex("BE A7 38")
SLEEP_MESSAGE_PTR_FINAL = bytes.fromhex("BE AB 38")
SLEEP_MESSAGE_FULL_STOCK = cp("더욱더잠들어버렸다!!")
SLEEP_MESSAGE_FULL_FINAL = cp("더욱 깊이 잠들었다!!")
SLEEP_MESSAGE_SHORT_FINAL = cp("잠들었다!!")


# R46: level-up wording/spacing + automatic-luck duplicate-wait correction.
#
# Final labels are `힘이 N`, `지혜가 N`, `민첩이 N`, `행운이 N`,
# `주문능력이 N`.  Strength/wisdom keep their fixed slots with FF no-op
# padding.  The agility/luck strings are adjacent: the legacy 16-byte block
# `민첩성이 <06>운이 <06>` becomes `민첩이 <06>행운이 <06>`.  The first
# label shrinks by exactly two bytes while the second grows by two, so the block
# length and the following DS:362A = 05h,06h transition remain unchanged.
# The luck pointer used by 86:7874 therefore changes from DS:3624 to DS:3622.
#
# The automatic-stat loop already contains its own DS:362A message transition.
# v1.4.33 added a second explicit render of DS:362A after luck, producing an
# extra wait and an empty dialogue box after the final character.  R46 clears
# that private helper and keeps only the native transition path.  The shared
# renderer and manual allocation branch remain untouched.
LEVELUP_TERM_SEG_INDEX = 85
LEVELUP_TERM_SLOT_SEG = 0x35E1
LEVELUP_TERM_SLOT_STOCK = cp("주문능력이 ")
LEVELUP_TERM_SLOT_V1433 = cp("주문") + b"\xFF" + cp("능력이")
LEVELUP_TERM_SLOT_FINAL = LEVELUP_TERM_SLOT_STOCK
LEVELUP_STRENGTH_SEG = 0x3608
LEVELUP_STRENGTH_STOCK = cp("강함이 ")
LEVELUP_STRENGTH_LEGACY = cp("힘이   ")
LEVELUP_STRENGTH_FINAL = cp("힘이 ") + b"\xFF\xFF"
LEVELUP_WISDOM_SEG = 0x3610
LEVELUP_WISDOM_STOCK = cp("현명함이 ")
LEVELUP_WISDOM_LEGACY = cp("지혜가   ")
LEVELUP_WISDOM_FINAL = cp("지혜가 ") + b"\xFF\xFF"
LEVELUP_AGILITY_LUCK_SEG = 0x361A
LEVELUP_AGILITY_LUCK_LEGACY = cp("민첩성이 ") + b"\x06" + cp("운이 ") + b"\x06"
LEVELUP_AGILITY_LUCK_FINAL = cp("민첩이 ") + b"\x06" + cp("행운이 ") + b"\x06"
LEVELUP_LUCK_FINAL_SEG = 0x3622
LEVELUP_CODE_SEG_INDEX = 86
LEVELUP_AUTO_TAIL_OFF = 0x7874
LEVELUP_AUTO_TAIL_STOCK = bytes.fromhex("BE 24 36")
LEVELUP_AUTO_TAIL_R46 = bytes.fromhex("BE 22 36")
# R50/v1.4.40 integration: after the final Luck line, wait only when another
# real level-up event remains.  The helper lives in the independently verified
# zero cave at 86:1B9A and preserves the original registers/flags.
LEVELUP_CONDITIONAL_CAVE_OFF = 0x1B9A
LEVELUP_CONDITIONAL_HELPER = bytes.fromhex(
    "BE22368A0784C07449F6C601750B56BE2A360EE8EB6B5EB6010EE8E46BBE"
    "C8350EE8716B43570EE8DB5D384503721883C74081FF002473180EE8DF31"
    "72F10EE8C35D38450373E85FBE2A360EE8B26BCB5FCB43CB"
)
LEVELUP_AUTO_TAIL_FINAL = b"\xE9" + struct.pack(
    "<H", (LEVELUP_CONDITIONAL_CAVE_OFF - (LEVELUP_AUTO_TAIL_OFF + 3)) & 0xFFFF
)
# Legacy private helper location used by R45/v1.4.33 only.  It must be clear in
# the integrated final state but remains recognized as an upgrade input.
LEVELUP_LEGACY_CAVE_OFF = 0x1CC0
LEVELUP_AUTO_TAIL_LEGACY = b"\xE9" + struct.pack(
    "<H", (LEVELUP_LEGACY_CAVE_OFF - (LEVELUP_AUTO_TAIL_OFF + 3)) & 0xFFFF
)
LEVELUP_NATIVE_TRANSITION_DS = 0x362A
LEVELUP_NATIVE_TRANSITION_BYTES = bytes.fromhex("05 06")
LEVELUP_RENDER_DISPATCH_DS = 0x393E
LEVELUP_OPCODE05_HANDLER = 0x89C5
LEVELUP_OPCODE05_HANDLER_BYTES = bytes.fromhex("BA 68 2A 0E E8 45 02")
LEVELUP_RENDERER_ENTRY = 0x879B
LEVELUP_RENDERER_ENTRY_BYTES = bytes.fromhex("9C 60 BF 07 4B")
_LEVELUP_HELPER_R45 = bytes.fromhex(
    "BE 24 36 0E E8 B0 5B C6 06 43 3F 40 80 3E 43 3F 00 75 F9 CB"
)
_LEVELUP_HELPER_V1433 = bytes.fromhex(
    "BE 24 36 0E E8 B0 5B BE 2A 36 0E E8 CD 6A CB 00 00 00 00 00"
)
LEVELUP_LEGACY_CAVE_SIZE = len(_LEVELUP_HELPER_R45)
LEVELUP_AUTO_CAVE_R45 = _LEVELUP_HELPER_R45
LEVELUP_AUTO_CAVE_V1433 = _LEVELUP_HELPER_V1433
LEVELUP_LEGACY_CAVE_CLEAR = bytes(LEVELUP_LEGACY_CAVE_SIZE)
LEVELUP_CONDITIONAL_CAVE_SIZE = len(LEVELUP_CONDITIONAL_HELPER)
LEVELUP_CONDITIONAL_CAVE_CLEAR = bytes(LEVELUP_CONDITIONAL_CAVE_SIZE)

# R50/v1.4.40 integration: battle reward suffix layout.
# The original 32-byte block contains two control-07 terminated messages.
# Reclaim one trailing POINT padding byte so the Gold suffix keeps its leading
# space and gains a final period without moving the block or resizing ED2MAIN.
REWARD_BLOCK_OFF = 0x149A49
REWARD_BLOCK_STOCK = cp(" POINT획득  ") + b"\x07" + cp(" Gold 얻었습니다  ") + b"\x07"
REWARD_BLOCK_R49 = cp(" POINT 획득 ") + b"\x07" + cp(" Gold를 얻었습니다") + b"\x07"
REWARD_BLOCK_V140_BAD = cp(" POINT 획득 ") + b"\x07" + cp("Gold를 얻었습니다.") + b"\x07"
REWARD_BLOCK_FINAL = cp(" POINT 획득") + b"\x07" + cp(" Gold를 얻었습니다.") + b"\x07"
REWARD_CODE_SEG_INDEX = 86
REWARD_GOLD_PTR_SEG = 0x3796
REWARD_GOLD_PTR_STOCK = bytes.fromhex("BE 56 26")
REWARD_GOLD_PTR_FINAL = bytes.fromhex("BE 55 26")
assert len(REWARD_BLOCK_STOCK) == len(REWARD_BLOCK_R49) == len(REWARD_BLOCK_V140_BAD) == len(REWARD_BLOCK_FINAL) == 32


def inspect_reward_suffix_layout(data: bytes) -> dict[str, object]:
    validate_ne(data)
    seg86 = _ne_segment_row(data, REWARD_CODE_SEG_INDEX)
    ptr_off = seg86["file_off"] + REWARD_GOLD_PTR_SEG
    block = data[REWARD_BLOCK_OFF:REWARD_BLOCK_OFF + 32]
    ptr = data[ptr_off:ptr_off + 3]
    if block == REWARD_BLOCK_FINAL and ptr == REWARD_GOLD_PTR_FINAL:
        state = "final"
    elif block == REWARD_BLOCK_STOCK and ptr == REWARD_GOLD_PTR_STOCK:
        state = "stock"
    elif block == REWARD_BLOCK_R49 and ptr == REWARD_GOLD_PTR_STOCK:
        state = "r49"
    elif block == REWARD_BLOCK_V140_BAD and ptr == REWARD_GOLD_PTR_STOCK:
        state = "v140_bad_no_gold_leading_space"
    else:
        raise ValueError(
            "v1.7.15R50: 전투 보상 문자열/Gold 포인터 상태가 예상과 다릅니다: "
            f"block={block.hex(' ')} ptr={ptr.hex(' ')}"
        )
    return {
        "state": state,
        "block_file_offset": REWARD_BLOCK_OFF,
        "gold_pointer_file_offset": ptr_off,
        "gold_pointer": ptr.hex(" "),
        "final": state == "final",
    }


def apply_reward_suffix_layout(buf: bytearray, changes: list[dict[str, object]]) -> None:
    info = inspect_reward_suffix_layout(bytes(buf))
    if info["final"]:
        return
    seg86 = _ne_segment_row(bytes(buf), REWARD_CODE_SEG_INDEX)
    ptr_off = seg86["file_off"] + REWARD_GOLD_PTR_SEG
    old_block = bytes(buf[REWARD_BLOCK_OFF:REWARD_BLOCK_OFF + 32])
    old_ptr = bytes(buf[ptr_off:ptr_off + 3])
    buf[REWARD_BLOCK_OFF:REWARD_BLOCK_OFF + 32] = REWARD_BLOCK_FINAL
    buf[ptr_off:ptr_off + 3] = REWARD_GOLD_PTR_FINAL
    changes.append({
        "offset": REWARD_BLOCK_OFF, "group": "wording",
        "purpose": "POINT 후행 패딩 1바이트 회수 + ` Gold를 얻었습니다.` 문장부호 복원",
        "before": old_block.hex(" "), "after": REWARD_BLOCK_FINAL.hex(" "), "byte_length": 32,
    })
    changes.append({
        "offset": ptr_off, "group": "wording",
        "purpose": "Gold 보상 문자열 시작점 DS:2656→2655",
        "before": old_ptr.hex(" "), "after": REWARD_GOLD_PTR_FINAL.hex(" "), "byte_length": 3,
    })
    if not inspect_reward_suffix_layout(bytes(buf))["final"]:
        raise ValueError("v1.7.15R50: 전투 보상 레이아웃 후검증 실패")


# R43: dynamic monster-name battle status particles.
# Six ED2MAIN data messages begin with opcode 02 (dynamic actor/monster name)
# followed by a fixed Korean `는`.  The Korean message engine already supports
# `^는` / `^이` / `^을` particle selectors, so restore that data syntax instead
# of adding any renderer/runtime hook.  Three messages fit by consuming their
# existing padding; the other three use the established same-segment 0F message
# redirect allocator in NE segment 85.  File size and segment 86 offset stay fixed.
BATTLE_PARTICLE_SEG_FINAL_LEN = 0xC355
BATTLE_PARTICLE_SPECS = (
    # (suffix offset after opcode 02, editable bytes before 0Ah, stock suffix, R42 suffix, final suffix)
    (0x3851, 15, "는 빛에 싸였다 ", "는 빛에 싸였다.", "^는 빛에 싸였다."),
    (0x3862, 20, "는 독에 중독되었다!!", "는 독에 중독됐다!!", "^는 독에 중독됐다!!"),
    (0x3878, 23, "는 주문을 봉인당했다 !!", "는 주문을 봉인당했다!!", "^는 주문을 봉인당했다!!"),
    (0x3891, 15, "는 혼란해졌다!!", "는 혼란해졌다!!", "^는 혼란해졌다!!"),
    (0x38B7, 24, "는 주문을 되돌려보냈다!!", "는 주문을 반사했다!!", "^는 주문을 반사했다!!"),
    (0x38D1, 17, "는 정신이 들었다 ", "는 정신을 차렸다.", "^는 정신을 차렸다."),
)
BATTLE_PARTICLE_STATIC_SLOT_OFFSETS = frozenset({0x14AC51,0x14AC62,0x14AC78,0x14AC7B,0x14AC91,0x14ACB7,0x14ACBA,0x14ACD1})

ALL_SLOTS = (
    CHAPTER_TITLE_SLOTS + CORE_SLOTS + MAGIC_LABEL_SLOTS + MAGIC_SYSTEM_SLOTS + WORDING_SLOTS
    + LOCATION_SLOTS + EXTRA_PROPER_NOUN_SLOTS
)




# 왕가의무덤 UI 정렬 마이그레이션 정보.
#
# 실제 지명표는 12바이트 고정 레코드이며 왕가의묘 레코드는 0x15084C에서
# 시작한다. v1.0.22~v1.0.28은 텍스트 시작 오프셋 0x15084E를 레코드
# 시작으로 오인해 정렬 실패 또는 다음 레코드 침범을 만들었다. v1.0.29는
# 정확한 레코드 경계에 `` 왕가의무덤 ``을 기록하고 코드 훅은 사용하지 않는다.
SEG86_FILE_OFFSET = 0x153800

# R31 stun/EXP split-render patch. NE86:0300 is inside the verified stock
# 0000..17FF zero cave; 0100 and 0200 remain reserved for VGM battle/flute.
# The status routine hook is a same-segment near JMP, so no NE relocation is added.
STUN_STATUS_ROUTINE_SEG = 0xAADE
STUN_STATUS_ROUTINE_OFFSET = SEG86_FILE_OFFSET + STUN_STATUS_ROUTINE_SEG
STUN_STATUS_ROUTINE_ORIGINAL = bytes.fromhex("56 51 50")
STUN_STATUS_ROUTINE_PATCHED = bytes.fromhex("E9 1F 58")  # JMP 86:0300
STUN_SET_EXP_SEG = 0xAB4E
STUN_SET_EXP_OFFSET = SEG86_FILE_OFFSET + STUN_SET_EXP_SEG
STUN_SET_EXP_ORIGINAL = bytes.fromhex("F6 45 24 80 74 0D")
STUN_SET_EXP_PATCHED = bytes.fromhex("E9 10 00 90 90 90")  # JMP 86:AB61
STUN_UI_CAVE_SEG = 0x0300
STUN_UI_CAVE_OFFSET = SEG86_FILE_OFFSET + STUN_UI_CAVE_SEG
STUN_UI_CAVE_CODE = bytes.fromhex(
    "56 51 50 F6 45 24 80 75 03 E9 D5 A7 "
    "BE 02 3D B9 03 00 87 FA F3 A5 87 FA 58 59 5E CB"
)
STUN_UI_CAVE_ORIGINAL = b"\x00" * len(STUN_UI_CAVE_CODE)

# R33: keep the R27 data/SET_EXP behavior, but make the second DISPLAY_STR
# start from the canonical second-line buffer DS:91CD regardless of where the
# first DISPLAY_STR stopped.  Hook the 4-byte `add di,06E0h` at 86:A9AA with
# a no-growth near jump into the verified 86:0300 cave.  The helper replays
# the displaced ADD, reloads SI, then jumps back to the untouched far call at
# 86:A9AE.
STUN_SECOND_RENDER_HOOK_SEG = 0xA9AA
STUN_SECOND_RENDER_HOOK_OFFSET = SEG86_FILE_OFFSET + STUN_SECOND_RENDER_HOOK_SEG
STUN_SECOND_RENDER_HOOK_ORIGINAL = bytes.fromhex("81 C7 E0 06")
STUN_SECOND_RENDER_HOOK_PATCHED = bytes.fromhex("E9 53 59 90")  # JMP 86:0300 + NOP
STUN_SECOND_RENDER_HELPER = bytes.fromhex(
    "81 C7 E0 06 BE CD 91 E9 A4 A6"
)
STUN_UI_CAVE_R33 = STUN_SECOND_RENDER_HELPER + b"\x00" * (len(STUN_UI_CAVE_CODE) - len(STUN_SECOND_RENDER_HELPER))
ROYAL_TOMB_TEXT = cp("왕가의무덤")
TOWN_NAME_BUFFER = 0x9DAC

# v1.0.23~v1.0.24 잘못된 전역 DS_KST 훅. 마이그레이션 입력으로만 인정하고
# 최종 상태에서는 반드시 원복한다.
LEGACY_ROYAL_TOMB_ENTRY_SEG = 0x8CBE
LEGACY_ROYAL_TOMB_RETURN_SEG = 0x8CC1
LEGACY_ROYAL_TOMB_ENTRY_OFFSET = SEG86_FILE_OFFSET + LEGACY_ROYAL_TOMB_ENTRY_SEG
LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL = bytes.fromhex("57 52 51")  # push di; push dx; push cx

# 새 국소 훅. 원래 3바이트 MOV를 동일 길이 near CALL로 교체한다.
ROYAL_TOMB_CAVE_SEG = 0x1700
ROYAL_TOMB_CAVE_OFFSET = SEG86_FILE_OFFSET + ROYAL_TOMB_CAVE_SEG
ROYAL_TOMB_CAVE_SIZE = 0x100
ROYAL_TOMB_WARP_SITE_SEG = 0x8618
ROYAL_TOMB_WARP_SITE_OFFSET = SEG86_FILE_OFFSET + ROYAL_TOMB_WARP_SITE_SEG
ROYAL_TOMB_WARP_SITE_ORIGINAL = bytes.fromhex("BE AC 9D")  # mov si,TOWN_NAME$
ROYAL_TOMB_HUD_SITE_SEG = 0xA8E7
ROYAL_TOMB_HUD_SITE_OFFSET = SEG86_FILE_OFFSET + ROYAL_TOMB_HUD_SITE_SEG
ROYAL_TOMB_HUD_SITE_ORIGINAL = bytes.fromhex("BF A2 68")   # mov di,68A2
ROYAL_TOMB_WARP_HELPER_SEG = ROYAL_TOMB_CAVE_SEG
ROYAL_TOMB_HUD_HELPER_SEG = ROYAL_TOMB_CAVE_SEG + 0x40


def _near_jmp(src: int, dst: int) -> bytes:
    disp = (dst - (src + 3)) & 0xFFFF
    return b"\xE9" + struct.pack("<H", disp)


def _near_call(src: int, dst: int) -> bytes:
    disp = (dst - (src + 3)) & 0xFFFF
    return b"\xE8" + struct.pack("<H", disp)


def _build_legacy_royal_tomb_helper() -> bytes:
    # Historical v1.0.23/v1.0.24 helper. Only used to recognize and safely
    # migrate old installations; it is never emitted by the new patch.
    code = bytearray(b"\x57\x52\x51\x50\x9C")
    jne_positions: list[int] = []
    for index in range(0, len(ROYAL_TOMB_TEXT), 2):
        word = struct.unpack_from("<H", ROYAL_TOMB_TEXT, index)[0]
        if index == 0:
            code.extend(b"\x81\x3C" + struct.pack("<H", word))
        else:
            code.extend(b"\x81\x7C" + bytes((index,)) + struct.pack("<H", word))
        code.extend(b"\x75\x00")
        jne_positions.append(len(code) - 1)
    code.append(0x4F)
    done = len(code)
    code.append(0x9D)
    code.append(0x58)
    src_seg = ROYAL_TOMB_CAVE_SEG + len(code)
    code.extend(_near_jmp(src_seg, LEGACY_ROYAL_TOMB_RETURN_SEG))
    for pos in jne_positions:
        rel = done - (pos + 1)
        if not -128 <= rel <= 127:
            raise AssertionError("legacy royal-tomb helper short branch overflow")
        code[pos] = rel & 0xFF
    return bytes(code)


def _build_targeted_royal_tomb_helper(*, mode: str) -> bytes:
    if mode == "warp":
        # Reproduce overwritten `mov si,TOWN_NAME$`.
        code = bytearray(b"\xBE" + struct.pack("<H", TOWN_NAME_BUFFER))
    elif mode == "hud":
        # Reproduce overwritten `mov di,68A2` from DISP_TOWN_NAME.
        code = bytearray(b"\xBF\xA2\x68")
    else:
        raise ValueError(mode)

    # MOV does not alter FLAGS, so preserve caller FLAGS across the comparisons
    # and the conditional DEC DI as well.
    code.append(0x9C)  # pushf
    jne_positions: list[int] = []
    for index in range(0, len(ROYAL_TOMB_TEXT), 2):
        word = struct.unpack_from("<H", ROYAL_TOMB_TEXT, index)[0]
        addr = TOWN_NAME_BUFFER + index
        code.extend(b"\x81\x3E" + struct.pack("<H", addr) + struct.pack("<H", word))
        code.extend(b"\x75\x00")
        jne_positions.append(len(code) - 1)
    code.append(0x4F)  # dec di: exact royal-tomb label -> half-width cell left
    done = len(code)
    code.extend(b"\x9D\xC3")  # popf; ret
    for pos in jne_positions:
        rel = done - (pos + 1)
        if not -128 <= rel <= 127:
            raise AssertionError("targeted royal-tomb helper short branch overflow")
        code[pos] = rel & 0xFF
    return bytes(code)


LEGACY_ROYAL_TOMB_HELPER = _build_legacy_royal_tomb_helper()
LEGACY_ROYAL_TOMB_ENTRY_PATCHED = _near_jmp(
    LEGACY_ROYAL_TOMB_ENTRY_SEG, ROYAL_TOMB_CAVE_SEG
)
ROYAL_TOMB_WARP_HELPER = _build_targeted_royal_tomb_helper(mode="warp")
ROYAL_TOMB_HUD_HELPER = _build_targeted_royal_tomb_helper(mode="hud")
ROYAL_TOMB_WARP_SITE_PATCHED = _near_call(
    ROYAL_TOMB_WARP_SITE_SEG, ROYAL_TOMB_WARP_HELPER_SEG
)
ROYAL_TOMB_HUD_SITE_PATCHED = _near_call(
    ROYAL_TOMB_HUD_SITE_SEG, ROYAL_TOMB_HUD_HELPER_SEG
)


def _targeted_royal_tomb_cave() -> bytes:
    out = bytearray(ROYAL_TOMB_CAVE_SIZE)
    w = ROYAL_TOMB_WARP_HELPER_SEG - ROYAL_TOMB_CAVE_SEG
    h = ROYAL_TOMB_HUD_HELPER_SEG - ROYAL_TOMB_CAVE_SEG
    if w + len(ROYAL_TOMB_WARP_HELPER) > h:
        raise AssertionError("royal-tomb warp/hud helpers overlap")
    if h + len(ROYAL_TOMB_HUD_HELPER) > len(out):
        raise AssertionError("royal-tomb helpers exceed 86:1700~17FF")
    out[w:w + len(ROYAL_TOMB_WARP_HELPER)] = ROYAL_TOMB_WARP_HELPER
    out[h:h + len(ROYAL_TOMB_HUD_HELPER)] = ROYAL_TOMB_HUD_HELPER
    return bytes(out)


ROYAL_TOMB_TARGETED_CAVE = _targeted_royal_tomb_cave()


# 전투 상태 표시는 원본의 한 글자 약어 방식을 그대로 사용한다.
#
# 이전 v1.5.0~v1.5.3 및 v1.5.2-fix1은 두 글자 상태명을 출력하기 위해
# 원본 wrapper/helper를 점프로 바꾸고 같은 세그먼트의 0 영역에 확장 코드를
# 기록했다. v1.5.4는 이 변경을 모두 제거하여 다음 원본 표시로 복구한다.
#   독 / 묵 / 잠 / 혼 / 수 / 반
#
# 지명과 기타 UI 문구 수정은 그대로 유지한다.
STATUS_WRAPPER_OFFSET = 0x15E2DE
STATUS_WRAPPER_ORIGINAL = bytes.fromhex("56 51 50")
# v1.5.2-fix1에서 사용한 wrapper->cave near jump.
STATUS_WRAPPER_FIX1_PATCHED = bytes.fromhex("E9 1F 74")

STATUS_HELPER_OFFSET = 0x15E306
STATUS_HELPER_ORIGINAL = bytes.fromhex(
    "AC 84 C4 75 06 83 C6 03 E2 F6 CB 87 FA A4 A5 87 FA CB"
)
# v1.5.0~v1.5.3에서 사용한 helper->cave near jump.
STATUS_HELPER_LEGACY_PATCHED = bytes.fromhex(
    "E9 F7 73 90 90 90 90 90 90 90 90 90 90 90 90 90 90 90"
)

STATUS_CAVE_OFFSET = 0x155700
STATUS_CAVE_CODE_V151 = bytes.fromhex(
    "AC 84 E0 75 06 83 C6 03 E2 F6 CB "
    "3C 40 74 0B 3C 20 74 17 87 D7 A4 A5 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 DD AB B8 BB E7 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 E6 AB B8 BE EE AB 87 D7 CB"
)
STATUS_CAVE_CODE_V152 = bytes.fromhex(
    "AC 84 E0 75 06 83 C6 03 E2 F6 CB "
    "3C 40 74 17 3C 20 74 23 3C 08 74 2F 3C 10 74 3B 3C 02 74 47 "
    "87 D7 A4 A5 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 DD AB B8 BB E7 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 E6 AB B8 BE EE AB 87 D7 CB "
    "87 D7 8A 04 AA B8 BC F6 AB B8 B8 E9 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 C8 A5 AB B8 B6 F5 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 C4 A7 AB B8 B9 AC AB 87 D7 CB"
)
STATUS_CAVE_CODE_V153 = bytes.fromhex(
    "AC 84 C4 75 06 83 C6 03 E2 F6 CB 3C 40 74 17 3C 20 74 28 3C 08 74 39 3C "
    "10 74 4A 3C 02 74 5B 87 FA A4 A5 87 FA CB 83 EA 02 87 FA AC AA B8 B9 DD "
    "AB B8 BB E7 AB 83 C6 02 87 FA CB 83 EA 02 87 FA AC AA B8 BC F6 AB B8 BE "
    "EE AB 83 C6 02 87 FA CB 83 EA 02 87 FA AC AA B8 BC F6 AB B8 B8 E9 AB 83 "
    "C6 02 87 FA CB 83 EA 02 87 FA AC AA B8 C8 A5 AB B8 B6 F5 AB 83 C6 02 87 "
    "FA CB 83 EA 02 87 FA AC AA B8 C4 A7 AB B8 B9 AC AB 83 C6 02 87 FA CB"
)
STATUS_CAVE_CODE_FIX1 = bytes.fromhex(
    "56 51 50 8A 65 24 8A 05 24 04 75 02 B0 80 08 C4 88 E0 24 7F 3C 08 74 38"
    "3C 10 74 48 3C 02 74 58 3C 40 74 68 3C 20 74 78 BE D2 3C B9 09 00 E8 0D"
    "00 F6 C4 04 75 04 49 E8 04 00 58 59 5E CB AC 84 C4 75 06 83 C6 03 E2 F6"
    "C3 87 D7 A4 A5 87 D7 C3 87 D7 B0 1A AA B8 BC F6 AB B8 B8 E9 AB B0 1D AA"
    "87 D7 EB D6 87 D7 B0 1A AA B8 C8 A5 AB B8 B6 F5 AB B0 1D AA 87 D7 EB C2"
    "87 D7 B0 1A AA B8 C4 A7 AB B8 B9 AC AB B0 1D AA 87 D7 EB AE 87 D7 B0 1E"
    "AA B8 B9 DD AB B8 BB E7 AB B0 1D AA 87 D7 EB 9A 87 D7 B0 1E AA B8 B9 E6"
    "AB B8 BE EE AB B0 1D AA 87 D7 EB 86"
)
STATUS_CAVE_SIZE = len(STATUS_CAVE_CODE_FIX1)
STATUS_CAVE_ORIGINAL = b"\x00" * STATUS_CAVE_SIZE
STATUS_CAVE_V151_PADDED = STATUS_CAVE_CODE_V151 + b"\x00" * (
    STATUS_CAVE_SIZE - len(STATUS_CAVE_CODE_V151)
)
STATUS_CAVE_V152_PADDED = STATUS_CAVE_CODE_V152 + b"\x00" * (
    STATUS_CAVE_SIZE - len(STATUS_CAVE_CODE_V152)
)
STATUS_CAVE_V153_PADDED = STATUS_CAVE_CODE_V153 + b"\x00" * (
    STATUS_CAVE_SIZE - len(STATUS_CAVE_CODE_V153)
)

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def resolve_exe(path: Path) -> Path:
    path = path.expanduser().resolve()
    exe = path / "ED2MAIN.EXE" if path.is_dir() else path
    if not exe.is_file() or exe.name.upper() != "ED2MAIN.EXE":
        raise FileNotFoundError(f"ED2MAIN.EXE를 찾을 수 없습니다: {exe}")
    return exe


def validate_ne(data: bytes) -> None:
    if len(data) != SUPPORTED_SIZE:
        raise ValueError(f"지원하지 않는 파일 크기입니다: {len(data):,} bytes")
    if data[:2] != b"MZ":
        raise ValueError("MZ 실행 파일이 아닙니다.")
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    if ne_off + 2 > len(data) or data[ne_off:ne_off + 2] != b"NE":
        raise ValueError("NE 헤더를 찾을 수 없습니다.")


def selected_slots(
    labels_only: bool, no_wording: bool, no_proper_nouns: bool
) -> tuple[Slot, ...]:
    # The v1.5.4 compact 27-entry location table is always restored. This also
    # removes suffix/spacing changes made by earlier experimental branches.
    slots = CHAPTER_TITLE_SLOTS + CORE_SLOTS + MAGIC_LABEL_SLOTS + LOCATION_SLOTS
    if not labels_only:
        slots += MAGIC_SYSTEM_SLOTS
    if not no_wording:
        slots += WORDING_SLOTS
    if not no_proper_nouns:
        slots += EXTRA_PROPER_NOUN_SLOTS
    return slots


def accepted_values(slot: Slot) -> tuple[bytes, ...]:
    # Original and desired are both valid input states, making reapplication and
    # migration from older patch versions safe.
    values = [slot.original, slot.desired]
    if slot.group in {"magic_label", "magic_system"}:
        values.append(cp("마법"))  # v1.7.10R9 legacy terminology
    if slot.offset == 0x1499D4:
        # v1.0.43의 짧은 표현과 v1.7.10R34의 잘못된 의미 변경을 모두 이행한다.
        values.append(fixed("모험 계속하기", 15))
        values.append(fixed("저장 불러오기", 15))
    if slot.offset == 0x1499E5:
        values.append(fixed("하지만 더 이상 가질 수 없습니다", 35))  # R49 visible padding
    if slot.offset == 0x149BC0:
        values.append(fixed("^는 혼란스러워한다!!", 21))  # R49 visible LF-adjacent padding
    if slot.offset == 0x14A9E1:
        values.append(cp("주문 능력이"))  # R35~R44 internal-space wording
        values.append(cp("주문") + b"\xFF" + cp("능력이"))  # v1.4.33 joined/no-number-space wording
    if slot.offset == 0x14AA08:
        values.append(cp("힘이   "))  # v1.4.33 visible three-space wording
    if slot.offset == 0x14AA10:
        values.append(cp("지혜가   "))  # v1.4.33 visible three-space wording
    if slot.offset == 0x14A9ED:
        values.append(fixed("포인트 능력이 올랐습니다", 26))  # R34
    if slot.offset == 0x149E09:
        values.append(cp("세이브 데이터를 삭제해도 좋습니까?"))  # R34
    if slot.offset == 0x14A027:
        values.append(cp("는 쓰기금지 되어 있습니다쓸 수 있는 상태로 해 주십시요"))
    if slot.offset == 0x14A05E:
        values.append(cp("디스크를 확인해 주십시요좋습니까?"))
    if slot.offset == 0x14B216:
        values.append(fixed("아무것도 일어나지 않았다\n", 27, newline=True))  # R34
    if slot.offset == 0x14B261:
        values.append(cp("에게는 듣지 않았다\n"))  # R34
    if slot.offset == 0x14B0F2:
        # v1.7.10R28/v1.3.19의 잘못된 상태표 비활성화 상태.
        values.append(b"\x00")
    if slot.offset == 0x14B102:
        # v1.7.10R29/v1.3.20에서 좌표로 오인해 쓴 색상 제어 19h.
        values.append(b"\x19")
    if slot.offset == 0x14B103:
        # R18~R29의 조기 NUL 상태와 과거 띄어쓰기 변형을 모두 이행한다.
        values.append(cp("기절") + b"\x00" + b" " * 6)
        values.append(fixed("기절", 11))
        values.append(cp("기절해 있다"))
        values.append(cp("기절 해있다"))
    if slot.offset == 0x15E35A:
        # R30의 6-word EXP-overwrite workaround 이행 입력.
        values.append(b"\x06")
    if slot.offset == 0x1505C9:
        # R30의 잔여 EXP 두 자리 공백 workaround 이행 입력.
        values.append(b"  ")
    if slot.group == "location" and slot.offset in LEGACY_LOCATION_V150:
        values.append(LEGACY_LOCATION_V150[slot.offset])
    if slot.group == "location" and slot.offset in V160_LOCATION_VARIANTS:
        values.append(V160_LOCATION_VARIANTS[slot.offset])
    if slot.group == "location" and slot.offset in ROYAL_TOMB_RECORD_VARIANTS:
        values.extend(ROYAL_TOMB_RECORD_VARIANTS[slot.offset])
    if slot.group == "location" and slot.offset in R6_LOCATION_VARIANTS:
        values.append(R6_LOCATION_VARIANTS[slot.offset])
    if slot.group == "location" and slot.offset in R19_LOCATION_VARIANTS:
        values.append(R19_LOCATION_VARIANTS[slot.offset])
    if slot.group == "location" and slot.offset in R20_LOCATION_VARIANTS:
        values.append(R20_LOCATION_VARIANTS[slot.offset])
    return tuple(dict.fromkeys(values))


def inspect_stun_exp_patch(data: bytes) -> dict[str, object]:
    routine = data[STUN_STATUS_ROUTINE_OFFSET:STUN_STATUS_ROUTINE_OFFSET + 3]
    set_exp = data[STUN_SET_EXP_OFFSET:STUN_SET_EXP_OFFSET + 6]
    cave = data[STUN_UI_CAVE_OFFSET:STUN_UI_CAVE_OFFSET + len(STUN_UI_CAVE_CODE)]
    second_hook = data[STUN_SECOND_RENDER_HOOK_OFFSET:STUN_SECOND_RENDER_HOOK_OFFSET + 4]
    legacy = (
        routine in (STUN_STATUS_ROUTINE_ORIGINAL, STATUS_WRAPPER_FIX1_PATCHED)
        and set_exp == STUN_SET_EXP_ORIGINAL
        and cave == STUN_UI_CAVE_ORIGINAL
        and second_hook == STUN_SECOND_RENDER_HOOK_ORIGINAL
    )
    r31 = (
        routine == STUN_STATUS_ROUTINE_PATCHED
        and set_exp == STUN_SET_EXP_PATCHED
        and cave == STUN_UI_CAVE_CODE
        and second_hook == STUN_SECOND_RENDER_HOOK_ORIGINAL
    )
    r33 = (
        routine == STUN_STATUS_ROUTINE_ORIGINAL
        and set_exp == STUN_SET_EXP_ORIGINAL
        and cave == STUN_UI_CAVE_R33
        and second_hook == STUN_SECOND_RENDER_HOOK_PATCHED
    )
    if not (legacy or r31 or r33):
        raise ValueError(
            "기절/HP 렌더 코드가 예상과 다릅니다: "
            f"status={routine.hex(' ')}, set_exp={set_exp.hex(' ')}, "
            f"second_hook={second_hook.hex(' ')}, cave_sha256={sha256(cave)}"
        )
    state = "r33_second_render_si_reload" if r33 else ("r31_exp_preserved_stun_status" if r31 else "r27_legacy")
    return {
        "state": state,
        "status_hook": routine.hex(" "),
        "set_exp_entry": set_exp.hex(" "),
        "second_render_hook": second_hook.hex(" "),
        "cave_sha256": sha256(cave),
    }


def inspect_status_patch(data: bytes) -> dict[str, str]:
    wrapper = data[STATUS_WRAPPER_OFFSET:STATUS_WRAPPER_OFFSET + len(STATUS_WRAPPER_ORIGINAL)]
    helper = data[STATUS_HELPER_OFFSET:STATUS_HELPER_OFFSET + len(STATUS_HELPER_ORIGINAL)]
    cave = data[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + STATUS_CAVE_SIZE]

    # The padding formerly used by the obsolete two-character status patch is
    # also a verified code cave used by the Mod Studio item-magic dispatcher.
    # Once wrapper/helper are original, the status feature no longer owns the
    # cave and must not validate or erase unrelated compatible code there.
    original_state = (
        wrapper == STATUS_WRAPPER_ORIGINAL
        and helper == STATUS_HELPER_ORIGINAL
    )
    legacy_state = (
        wrapper == STATUS_WRAPPER_ORIGINAL
        and helper == STATUS_HELPER_LEGACY_PATCHED
        and cave in (STATUS_CAVE_V151_PADDED, STATUS_CAVE_V152_PADDED, STATUS_CAVE_V153_PADDED)
    )
    fix1_state = (
        wrapper == STATUS_WRAPPER_FIX1_PATCHED
        and helper == STATUS_HELPER_ORIGINAL
        and cave == STATUS_CAVE_CODE_FIX1
    )
    r31_state = (
        wrapper == STUN_STATUS_ROUTINE_PATCHED
        and helper == STATUS_HELPER_ORIGINAL
        and data[STUN_UI_CAVE_OFFSET:STUN_UI_CAVE_OFFSET + len(STUN_UI_CAVE_CODE)] == STUN_UI_CAVE_CODE
    )
    if not (original_state or legacy_state or fix1_state or r31_state):
        raise ValueError(
            "상태 출력 코드 조합이 예상과 다릅니다: "
            f"wrapper={wrapper.hex(' ')}, helper={helper.hex(' ')}, "
            f"cave_sha256={sha256(cave)}"
        )

    if r31_state:
        state = "r31_stun_two_slot_exp_preserved"
    elif original_state:
        state = "original_one_character"
    elif fix1_state:
        state = "v1.5.2-fix1_two_character"
    elif cave == STATUS_CAVE_V153_PADDED:
        state = "v1.5.3_two_character"
    elif cave == STATUS_CAVE_V152_PADDED:
        state = "v1.5.2_two_character"
    else:
        state = "v1.5.0_or_v1.5.1_two_character"
    return {
        "state": state,
        "wrapper": wrapper.hex(" "),
        "helper": helper.hex(" "),
        "cave_sha256": sha256(cave),
    }

def inspect_royal_tomb_center(data: bytes) -> dict[str, object]:
    global_entry = data[
        LEGACY_ROYAL_TOMB_ENTRY_OFFSET:
        LEGACY_ROYAL_TOMB_ENTRY_OFFSET + len(LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL)
    ]
    warp_site = data[
        ROYAL_TOMB_WARP_SITE_OFFSET:
        ROYAL_TOMB_WARP_SITE_OFFSET + len(ROYAL_TOMB_WARP_SITE_ORIGINAL)
    ]
    hud_site = data[
        ROYAL_TOMB_HUD_SITE_OFFSET:
        ROYAL_TOMB_HUD_SITE_OFFSET + len(ROYAL_TOMB_HUD_SITE_ORIGINAL)
    ]
    cave = data[ROYAL_TOMB_CAVE_OFFSET:ROYAL_TOMB_CAVE_OFFSET + ROYAL_TOMB_CAVE_SIZE]

    original = (
        global_entry == LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL
        and warp_site == ROYAL_TOMB_WARP_SITE_ORIGINAL
        and hud_site == ROYAL_TOMB_HUD_SITE_ORIGINAL
        and set(cave) <= {0}
    )
    legacy = (
        global_entry == LEGACY_ROYAL_TOMB_ENTRY_PATCHED
        and warp_site == ROYAL_TOMB_WARP_SITE_ORIGINAL
        and hud_site == ROYAL_TOMB_HUD_SITE_ORIGINAL
        and cave[:len(LEGACY_ROYAL_TOMB_HELPER)] == LEGACY_ROYAL_TOMB_HELPER
        and set(cave[len(LEGACY_ROYAL_TOMB_HELPER):]) <= {0}
    )
    targeted = (
        global_entry == LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL
        and warp_site == ROYAL_TOMB_WARP_SITE_PATCHED
        and hud_site == ROYAL_TOMB_HUD_SITE_PATCHED
        and cave == ROYAL_TOMB_TARGETED_CAVE
    )
    if not (original or legacy or targeted):
        raise ValueError(
            "왕가의무덤 UI 정렬 훅 영역이 예상과 다릅니다: "
            f"global={global_entry.hex(' ')}, warp={warp_site.hex(' ')}, "
            f"hud={hud_site.hex(' ')}, cave_sha256={sha256(cave)}"
        )
    record = data[ROYAL_TOMB_RECORD_OFFSET:ROYAL_TOMB_RECORD_OFFSET + 12]
    next_record = data[0x150858:0x150858 + 12]
    expected_next = b"  " + cp("늑대의입") + b"  "
    centered_slot = record == ROYAL_TOMB_RECORD_DESIRED and next_record == expected_next
    if targeted:
        state = "targeted_ui_legacy"
    elif legacy:
        state = "legacy_global"
    elif centered_slot:
        state = "fixed_record_centered"
    elif record in ROYAL_TOMB_RECORD_VARIANTS[ROYAL_TOMB_RECORD_OFFSET]:
        state = "legacy_bad_record_offset"
    else:
        state = "original_or_other_accepted"
    return {
        "state": state,
        "global_dskst_restored": targeted or original,
        "warp_menu_centered": targeted or centered_slot,
        "bottom_right_centered": targeted or centered_slot,
        "entry_display_centered": legacy,
        "record_offset": ROYAL_TOMB_RECORD_OFFSET,
        "record_hex": record.hex(" "),
        "record_centered": centered_slot,
        "next_record_hex": next_record.hex(" "),
        "code_hooks_present": legacy or targeted,
        "warp_helper_size": len(ROYAL_TOMB_WARP_HELPER),
        "hud_helper_size": len(ROYAL_TOMB_HUD_HELPER),
    }


def _ne_segment_row(data: bytes, index: int) -> dict[str, int]:
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    seg_count = struct.unpack_from("<H", data, ne_off + 0x1C)[0]
    if not 1 <= index <= seg_count:
        raise ValueError(f"NE segment index out of range: {index}")
    seg_table = ne_off + struct.unpack_from("<H", data, ne_off + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne_off + 0x32)[0]
    row_off = seg_table + (index - 1) * 8
    sector, length, flags, min_alloc = struct.unpack_from("<HHHH", data, row_off)
    file_off = sector << shift
    real_len = length or 0x10000
    return {
        "row_off": row_off, "sector": sector, "length": real_len,
        "length_word": length, "flags": flags, "min_alloc": min_alloc,
        "file_off": file_off, "shift": shift,
    }


def _segment_reloc_blob(data: bytes, row: dict[str, int]) -> bytes:
    if not (row["flags"] & 0x0100):
        raise ValueError("NE segment 85에 relocation flag가 없습니다")
    start = row["file_off"] + row["length"]
    if start + 2 > len(data):
        raise ValueError("NE relocation table 시작이 파일 밖입니다")
    count = struct.unpack_from("<H", data, start)[0]
    end = start + 2 + count * 8
    if end > len(data):
        raise ValueError("NE relocation table이 파일 밖입니다")
    return data[start:end]


def inspect_item_effect_boundary(data: bytes) -> dict[str, object]:
    """Recognize stock/R40/R41-candidate/R42 static-data states exactly."""
    validate_ne(data)
    seg85 = _ne_segment_row(data, ITEM_EFFECT_SEG_INDEX)
    seg86 = _ne_segment_row(data, ITEM_EFFECT_SEG_INDEX + 1)
    if seg85["file_off"] != ITEM_EFFECT_SEG_BASE:
        raise ValueError("R42: NE segment 85 file offset이 예상과 다릅니다")
    if seg86["file_off"] != 0x153800:
        raise ValueError("R42: NE segment 86 file offset이 예상과 다릅니다")
    if seg85["length"] not in (ITEM_EFFECT_SEG_OLD_LEN, ITEM_EFFECT_SEG_NEW_LEN, BATTLE_PARTICLE_SEG_FINAL_LEN):
        raise ValueError(f"R42/R43: NE segment 85 length가 예상과 다릅니다: 0x{seg85['length']:X}")
    if seg85["min_alloc"] != seg85["length"]:
        raise ValueError("R42: NE segment 85 min_alloc/length 불일치")

    ptrs = tuple(struct.unpack_from("<H", data, ITEM_EFFECT_SEG_BASE + off)[0]
                 for off in ITEM_EFFECT_PTR_SEGS)
    gap = data[ITEM_EFFECT_R40_GAP_FILE:ITEM_EFFECT_R40_GAP_FILE + 1]
    code = data[ITEM_EFFECT_CODE_SITE_FILE:ITEM_EFFECT_CODE_SITE_FILE + 3]
    cave = data[ITEM_EFFECT_R41_CAVE_FILE:ITEM_EFFECT_R41_CAVE_FILE + len(ITEM_EFFECT_R41_CAVE)]
    old_target = data[
        ITEM_EFFECT_SEG_BASE + ITEM_EFFECT_OLD_TARGET_SEG:
        ITEM_EFFECT_SEG_BASE + ITEM_EFFECT_OLD_TARGET_SEG + len(ITEM_EFFECT_OLD_TARGET)
    ]
    if old_target not in (ITEM_EFFECT_OLD_TARGET, ITEM_EFFECT_OLD_TARGET_STOCK):
        raise ValueError("R42: 기존 ^을 썼다 06h target이 예상과 다릅니다")

    reloc = _segment_reloc_blob(data, seg85)
    reloc_count = struct.unpack_from("<H", reloc, 0)[0]
    if reloc_count != 16:
        raise ValueError(f"R42: segment 85 relocation count가 예상과 다릅니다: {reloc_count}")

    if seg85["length"] in (ITEM_EFFECT_SEG_NEW_LEN, BATTLE_PARTICLE_SEG_FINAL_LEN):
        target = data[
            ITEM_EFFECT_SEG_BASE + ITEM_EFFECT_NEW_TARGET_SEG:
            ITEM_EFFECT_SEG_BASE + ITEM_EFFECT_NEW_TARGET_SEG + len(ITEM_EFFECT_NEW_TARGET)
        ]
        if not (
            ptrs == (ITEM_EFFECT_NEW_TARGET_SEG, ITEM_EFFECT_NEW_TARGET_SEG)
            and target == ITEM_EFFECT_NEW_TARGET
            and gap == ITEM_EFFECT_R40_GAP_STOCK
            and code == ITEM_EFFECT_CODE_VANILLA
            and cave == ITEM_EFFECT_R41_CAVE_CLEAR
        ):
            raise ValueError("R42: 적용된 static item-effect 상태가 일관되지 않습니다")
        state = "applied_static_r42"
    else:
        if ptrs != (ITEM_EFFECT_OLD_TARGET_SEG, ITEM_EFFECT_OLD_TARGET_SEG):
            raise ValueError(f"R42: 기존 item-use pointer가 예상과 다릅니다: {ptrs}")
        if gap == ITEM_EFFECT_R40_GAP_STOCK and code == ITEM_EFFECT_CODE_VANILLA and cave == ITEM_EFFECT_R41_CAVE_CLEAR:
            state = "stock_or_pre_r38"
        elif gap == ITEM_EFFECT_R40_GAP_PATCHED and code == ITEM_EFFECT_CODE_R40 and cave == ITEM_EFFECT_R41_CAVE_CLEAR:
            state = "r40_gap_pointer"
        elif gap == ITEM_EFFECT_R40_GAP_STOCK and code == ITEM_EFFECT_CODE_R41 and cave == ITEM_EFFECT_R41_CAVE:
            state = "r41_runtime_helper_candidate"
        else:
            raise ValueError(
                "R42: item-effect 경계의 gap/code/helper 조합이 알려진 상태가 아닙니다: "
                f"gap={gap.hex()} code={code.hex()} cave={cave.hex()}"
            )

    return {
        "state": state,
        "segment85_length": seg85["length"],
        "segment85_min_alloc": seg85["min_alloc"],
        "segment85_relocation_count": reloc_count,
        "segment85_relocation_blob": reloc,
        "segment86_file_offset": seg86["file_off"],
        "pointers": ptrs,
        "gap_hex": gap.hex(),
        "code_hex": code.hex(" "),
        "helper_hex": cave.hex(" "),
    }


def apply_item_effect_boundary_static(buf: bytearray, changes: list[dict[str, object]]) -> None:
    before = bytes(buf)
    info = inspect_item_effect_boundary(before)
    if info["state"] == "applied_static_r42":
        return

    seg85 = _ne_segment_row(before, ITEM_EFFECT_SEG_INDEX)
    seg86 = _ne_segment_row(before, ITEM_EFFECT_SEG_INDEX + 1)
    old_end = seg85["file_off"] + ITEM_EFFECT_SEG_OLD_LEN
    new_end = seg85["file_off"] + ITEM_EFFECT_SEG_NEW_LEN
    reloc = bytes(info["segment85_relocation_blob"])
    old_reloc_end = old_end + len(reloc)
    new_reloc_end = new_end + len(reloc)
    if new_reloc_end > seg86["file_off"]:
        raise ValueError("R42: segment 85 alignment gap에 새 target/relocation이 들어가지 않습니다")
    # The bytes after the old relocation table up to segment 86 are alignment padding.
    if set(before[old_reloc_end:seg86["file_off"]]) - {0}:
        raise ValueError("R42: segment 85 뒤 alignment padding이 00이 아닙니다")

    # Move the relocation table to follow the logically grown segment, then put
    # the literal-space message target at the old data end.  File size/seg86 do
    # not move.
    region_before = bytes(buf[old_end:seg86["file_off"]])
    buf[old_end:seg86["file_off"]] = bytes(seg86["file_off"] - old_end)
    buf[old_end:old_end + len(ITEM_EFFECT_NEW_TARGET)] = ITEM_EFFECT_NEW_TARGET
    buf[new_end:new_end + len(reloc)] = reloc
    region_after = bytes(buf[old_end:seg86["file_off"]])
    if region_before != region_after:
        changes.append({
            "offset": old_end, "group": "wording",
            "purpose": "마법 무기 문장 경계: 실제 반각 공백을 가진 06h 문자열 추가 및 relocation table 이동",
            "before": region_before.hex(" "), "after": region_after.hex(" "),
            "byte_length": seg86["file_off"] - old_end,
        })

    row_off = seg85["row_off"]
    old_words = bytes(buf[row_off + 2:row_off + 8])
    struct.pack_into("<H", buf, row_off + 2, ITEM_EFFECT_SEG_NEW_LEN)
    struct.pack_into("<H", buf, row_off + 6, ITEM_EFFECT_SEG_NEW_LEN)
    new_words = bytes(buf[row_off + 2:row_off + 8])
    if old_words != new_words:
        changes.append({
            "offset": row_off + 2, "group": "wording",
            "purpose": "NE segment 85 length/min_alloc +12 (segment 86 위치 불변)",
            "before": old_words.hex(" "), "after": new_words.hex(" "),
            "byte_length": 6,
        })

    for seg_off in ITEM_EFFECT_PTR_SEGS:
        file_off = ITEM_EFFECT_SEG_BASE + seg_off
        old = bytes(buf[file_off:file_off + 2])
        new = struct.pack("<H", ITEM_EFFECT_NEW_TARGET_SEG)
        if old != new:
            buf[file_off:file_off + 2] = new
            changes.append({
                "offset": file_off, "group": "wording",
                "purpose": "아이템 사용 10h pointer를 literal-space target으로 변경",
                "before": old.hex(" "), "after": new.hex(" "), "byte_length": 2,
            })

    gap = bytes(buf[ITEM_EFFECT_R40_GAP_FILE:ITEM_EFFECT_R40_GAP_FILE + 1])
    if gap != ITEM_EFFECT_R40_GAP_STOCK:
        if gap != ITEM_EFFECT_R40_GAP_PATCHED:
            raise ValueError("R42: R40 gap byte가 예상과 다릅니다")
        buf[ITEM_EFFECT_R40_GAP_FILE:ITEM_EFFECT_R40_GAP_FILE + 1] = ITEM_EFFECT_R40_GAP_STOCK
        changes.append({
            "offset": ITEM_EFFECT_R40_GAP_FILE, "group": "wording",
            "purpose": "R38/R40 DS:9679 임시 공백 철회",
            "before": gap.hex(" "), "after": "00", "byte_length": 1,
        })

    code = bytes(buf[ITEM_EFFECT_CODE_SITE_FILE:ITEM_EFFECT_CODE_SITE_FILE + 3])
    if code != ITEM_EFFECT_CODE_VANILLA:
        if code not in (ITEM_EFFECT_CODE_R40, ITEM_EFFECT_CODE_R41):
            raise ValueError("R42: item-effect 주문명 출력 코드가 예상과 다릅니다")
        buf[ITEM_EFFECT_CODE_SITE_FILE:ITEM_EFFECT_CODE_SITE_FILE + 3] = ITEM_EFFECT_CODE_VANILLA
        changes.append({
            "offset": ITEM_EFFECT_CODE_SITE_FILE, "group": "wording",
            "purpose": "아이템 발동 주문명 경로를 원래 mov si,967A로 복원",
            "before": code.hex(" "), "after": ITEM_EFFECT_CODE_VANILLA.hex(" "), "byte_length": 3,
        })

    cave = bytes(buf[ITEM_EFFECT_R41_CAVE_FILE:ITEM_EFFECT_R41_CAVE_FILE + len(ITEM_EFFECT_R41_CAVE)])
    if cave != ITEM_EFFECT_R41_CAVE_CLEAR:
        if cave != ITEM_EFFECT_R41_CAVE:
            raise ValueError("R42: R41 후보 helper 영역이 예상과 다릅니다")
        buf[ITEM_EFFECT_R41_CAVE_FILE:ITEM_EFFECT_R41_CAVE_FILE + len(ITEM_EFFECT_R41_CAVE)] = ITEM_EFFECT_R41_CAVE_CLEAR
        changes.append({
            "offset": ITEM_EFFECT_R41_CAVE_FILE, "group": "wording",
            "purpose": "R41 runtime 공백 helper 완전 철회",
            "before": cave.hex(" "), "after": ITEM_EFFECT_R41_CAVE_CLEAR.hex(" "),
            "byte_length": len(ITEM_EFFECT_R41_CAVE),
        })

    final = inspect_item_effect_boundary(bytes(buf))
    if final["state"] != "applied_static_r42":
        raise ValueError("R42: static item-effect 후검증 실패")
    if final["segment85_relocation_blob"] != reloc:
        raise ValueError("R42: segment 85 relocation blob 내용이 바뀌었습니다")
    if final["segment86_file_offset"] != seg86["file_off"]:
        raise ValueError("R42: segment 86 file offset이 이동했습니다")




def _segment_reloc_sources_from_row(data: bytes, row: dict[str, int]) -> set[int]:
    blob = _segment_reloc_blob(data, row)
    count = struct.unpack_from("<H", blob, 0)[0]
    return {struct.unpack_from("<H", blob, 2 + i * 8 + 2)[0] for i in range(count)}


def inspect_levelup_presentation(data: bytes) -> dict[str, object]:
    validate_ne(data)
    seg85 = _ne_segment_row(data, LEVELUP_TERM_SEG_INDEX)
    seg86 = _ne_segment_row(data, LEVELUP_CODE_SEG_INDEX)
    b85 = seg85["file_off"]
    b86 = seg86["file_off"]

    term = data[b85 + LEVELUP_TERM_SLOT_SEG:b85 + LEVELUP_TERM_SLOT_SEG + len(LEVELUP_TERM_SLOT_FINAL)]
    strength = data[b85 + LEVELUP_STRENGTH_SEG:b85 + LEVELUP_STRENGTH_SEG + len(LEVELUP_STRENGTH_FINAL)]
    wisdom = data[b85 + LEVELUP_WISDOM_SEG:b85 + LEVELUP_WISDOM_SEG + len(LEVELUP_WISDOM_FINAL)]
    agility_luck = data[b85 + LEVELUP_AGILITY_LUCK_SEG:b85 + LEVELUP_AGILITY_LUCK_SEG + len(LEVELUP_AGILITY_LUCK_FINAL)]
    hook_off = b86 + LEVELUP_AUTO_TAIL_OFF
    legacy_cave_off = b86 + LEVELUP_LEGACY_CAVE_OFF
    conditional_cave_off = b86 + LEVELUP_CONDITIONAL_CAVE_OFF
    hook = data[hook_off:hook_off + 3]
    legacy_cave = data[legacy_cave_off:legacy_cave_off + LEVELUP_LEGACY_CAVE_SIZE]
    conditional_cave = data[conditional_cave_off:conditional_cave_off + LEVELUP_CONDITIONAL_CAVE_SIZE]

    if term == LEVELUP_TERM_SLOT_STOCK:
        term_state = "joined_trailing_space"
    elif term == LEVELUP_TERM_SLOT_V1433:
        term_state = "v1433_joined_no_trailing_space"
    else:
        raise ValueError(f"v1.7.15R50: 레벨업 주문능력 슬롯이 예상과 다릅니다: {term.hex(' ')}")

    if strength == LEVELUP_STRENGTH_STOCK:
        strength_state = "stock"
    elif strength == LEVELUP_STRENGTH_LEGACY:
        strength_state = "legacy_visible_padding"
    elif strength == LEVELUP_STRENGTH_FINAL:
        strength_state = "final_single_space"
    else:
        raise ValueError(f"v1.7.15R50: 힘 슬롯이 예상과 다릅니다: {strength.hex(' ')}")

    if wisdom == LEVELUP_WISDOM_STOCK:
        wisdom_state = "stock"
    elif wisdom == LEVELUP_WISDOM_LEGACY:
        wisdom_state = "legacy_visible_padding"
    elif wisdom == LEVELUP_WISDOM_FINAL:
        wisdom_state = "final_single_space"
    else:
        raise ValueError(f"v1.7.15R50: 지혜 슬롯이 예상과 다릅니다: {wisdom.hex(' ')}")

    if agility_luck == LEVELUP_AGILITY_LUCK_LEGACY:
        agility_luck_state = "legacy_labels"
    elif agility_luck == LEVELUP_AGILITY_LUCK_FINAL:
        agility_luck_state = "final_labels"
    else:
        raise ValueError(f"v1.7.15R50: 민첩/행운 블록이 예상과 다릅니다: {agility_luck.hex(' ')}")

    transition_off = b85 + LEVELUP_NATIVE_TRANSITION_DS
    transition = data[transition_off:transition_off + len(LEVELUP_NATIVE_TRANSITION_BYTES)]
    if transition != LEVELUP_NATIVE_TRANSITION_BYTES:
        raise ValueError(f"v1.7.15R50: DS:362A가 예상과 다릅니다: {transition.hex(' ')}")
    dispatch_off = b85 + LEVELUP_RENDER_DISPATCH_DS + 5 * 2
    opcode05_handler = struct.unpack_from("<H", data, dispatch_off)[0]
    if opcode05_handler != LEVELUP_OPCODE05_HANDLER:
        raise ValueError(f"v1.7.15R50: opcode 05 dispatch가 예상과 다릅니다: {opcode05_handler:04X}")
    handler_off = b86 + LEVELUP_OPCODE05_HANDLER
    if data[handler_off:handler_off + len(LEVELUP_OPCODE05_HANDLER_BYTES)] != LEVELUP_OPCODE05_HANDLER_BYTES:
        raise ValueError("v1.7.15R50: opcode 05 handler가 예상과 다릅니다")
    renderer_off = b86 + LEVELUP_RENDERER_ENTRY
    if data[renderer_off:renderer_off + len(LEVELUP_RENDERER_ENTRY_BYTES)] != LEVELUP_RENDERER_ENTRY_BYTES:
        raise ValueError("v1.7.15R50: stock renderer entry가 예상과 다릅니다")

    if hook == LEVELUP_AUTO_TAIL_FINAL and conditional_cave == LEVELUP_CONDITIONAL_HELPER and legacy_cave == LEVELUP_LEGACY_CAVE_CLEAR:
        tail_state = "conditional_next_level_wait"
    elif hook == LEVELUP_AUTO_TAIL_R46 and conditional_cave == LEVELUP_CONDITIONAL_CAVE_CLEAR and legacy_cave == LEVELUP_LEGACY_CAVE_CLEAR:
        tail_state = "r46_final_luck_pointer"
    elif hook == LEVELUP_AUTO_TAIL_STOCK and conditional_cave == LEVELUP_CONDITIONAL_CAVE_CLEAR and legacy_cave == LEVELUP_LEGACY_CAVE_CLEAR:
        tail_state = "retail_tail"
    elif hook == LEVELUP_AUTO_TAIL_LEGACY and conditional_cave == LEVELUP_CONDITIONAL_CAVE_CLEAR and legacy_cave == LEVELUP_AUTO_CAVE_R45:
        tail_state = "legacy_64tick"
    elif hook == LEVELUP_AUTO_TAIL_LEGACY and conditional_cave == LEVELUP_CONDITIONAL_CAVE_CLEAR and legacy_cave == LEVELUP_AUTO_CAVE_V1433:
        tail_state = "v1433_duplicate_native_wait"
    else:
        raise ValueError(
            "v1.7.15R50: 자동 레벨업 tail/helper가 알려진 상태가 아닙니다: "
            f"hook={hook.hex(' ')} conditional={conditional_cave.hex(' ')} legacy={legacy_cave.hex(' ')}"
        )

    final = (
        term == LEVELUP_TERM_SLOT_FINAL
        and strength == LEVELUP_STRENGTH_FINAL
        and wisdom == LEVELUP_WISDOM_FINAL
        and agility_luck == LEVELUP_AGILITY_LUCK_FINAL
        and tail_state == "conditional_next_level_wait"
    )
    return {
        "term_state": term_state,
        "strength_state": strength_state,
        "wisdom_state": wisdom_state,
        "agility_luck_state": agility_luck_state,
        "agility_label": "민첩이" if agility_luck == LEVELUP_AGILITY_LUCK_FINAL else "민첩성이",
        "luck_label": "행운이" if agility_luck == LEVELUP_AGILITY_LUCK_FINAL else "운이",
        "agility_space": 1,
        "luck_space": 1,
        "luck_string_ds": LEVELUP_LUCK_FINAL_SEG if agility_luck == LEVELUP_AGILITY_LUCK_FINAL else 0x3624,
        "tail_state": tail_state,
        "transition_state": "conditional_native_transition" if tail_state == "conditional_next_level_wait" else tail_state,
        "term_file_offset": b85 + LEVELUP_TERM_SLOT_SEG,
        "strength_file_offset": b85 + LEVELUP_STRENGTH_SEG,
        "wisdom_file_offset": b85 + LEVELUP_WISDOM_SEG,
        "hook_file_offset": hook_off,
        "conditional_cave_file_offset": conditional_cave_off,
        "legacy_cave_file_offset": legacy_cave_off,
        "native_transition_ds": LEVELUP_NATIVE_TRANSITION_DS,
        "native_transition_hex": transition.hex(" "),
        "native_transition_handler": f"86:{LEVELUP_OPCODE05_HANDLER:04X}",
        "duplicate_luck_wait": tail_state == "v1433_duplicate_native_wait",
        "fixed_timer_hold": tail_state == "legacy_64tick",
        "conditional_wait_enabled": tail_state == "conditional_next_level_wait",
        "final": final,
    }


def apply_levelup_presentation(buf: bytearray, changes: list[dict[str, object]]) -> None:
    inspect_levelup_presentation(bytes(buf))
    seg85 = _ne_segment_row(bytes(buf), LEVELUP_TERM_SEG_INDEX)
    seg86 = _ne_segment_row(bytes(buf), LEVELUP_CODE_SEG_INDEX)
    b85 = seg85["file_off"]
    b86 = seg86["file_off"]

    def put(off: int, new: bytes, purpose: str) -> None:
        old = bytes(buf[off:off + len(new)])
        if old == new:
            return
        buf[off:off + len(new)] = new
        changes.append({
            "offset": off, "group": "levelup_ui", "purpose": purpose,
            "before": old.hex(" "), "after": new.hex(" "), "byte_length": len(new),
        })

    put(b85 + LEVELUP_TERM_SLOT_SEG, LEVELUP_TERM_SLOT_FINAL, "레벨업 주문능력이 숫자 앞 공백 1칸 복원")
    put(b85 + LEVELUP_STRENGTH_SEG, LEVELUP_STRENGTH_FINAL, "레벨업 힘 숫자 앞 공백 1칸; 남는 2바이트 FF no-op")
    put(b85 + LEVELUP_WISDOM_SEG, LEVELUP_WISDOM_FINAL, "레벨업 지혜 숫자 앞 공백 1칸; 남는 2바이트 FF no-op")
    put(b85 + LEVELUP_AGILITY_LUCK_SEG, LEVELUP_AGILITY_LUCK_FINAL, "레벨업 표기 민첩성이→민첩이, 운이→행운이; 연속 블록 길이 유지")

    sources = _segment_reloc_sources_from_row(bytes(buf), seg86)
    for off, size, label in (
        (LEVELUP_AUTO_TAIL_OFF, 3, "tail"),
        (LEVELUP_CONDITIONAL_CAVE_OFF, LEVELUP_CONDITIONAL_CAVE_SIZE, "conditional cave"),
        (LEVELUP_LEGACY_CAVE_OFF, LEVELUP_LEGACY_CAVE_SIZE, "legacy cave"),
    ):
        if any(off <= x < off + size for x in sources):
            raise ValueError(f"v1.7.15R50: 자동 레벨업 {label}가 relocation source와 겹칩니다")

    put(b86 + LEVELUP_LEGACY_CAVE_OFF, LEVELUP_LEGACY_CAVE_CLEAR, "구 자동 운 후처리 private helper 제거")
    put(b86 + LEVELUP_CONDITIONAL_CAVE_OFF, LEVELUP_CONDITIONAL_HELPER, "다음 실제 레벨업 이벤트가 있을 때만 페이지 대기하는 조건부 helper")
    put(b86 + LEVELUP_AUTO_TAIL_OFF, LEVELUP_AUTO_TAIL_FINAL, "행운 표시 후 조건부 다음 레벨업 대기 helper로 연결")

    post = inspect_levelup_presentation(bytes(buf))
    if not post["final"]:
        raise ValueError("v1.7.15R50: 조건부 레벨업 대기 후검증 실패")


def inspect_sleep_message_entry(data: bytes) -> dict[str, object]:
    """Recognize stock, R35/R43 broken, and R44 corrected sleep entry states."""
    validate_ne(data)
    seg85 = _ne_segment_row(data, SLEEP_MESSAGE_SEG_INDEX)
    seg86 = _ne_segment_row(data, SLEEP_MESSAGE_CODE_SEG_INDEX)
    full_off = seg85["file_off"] + SLEEP_MESSAGE_FULL_SEG
    code_off = seg86["file_off"] + SLEEP_MESSAGE_CODE_SEG_OFF
    ptr = data[code_off:code_off + 3]
    full_stock = data[full_off:full_off + len(SLEEP_MESSAGE_FULL_STOCK)] == SLEEP_MESSAGE_FULL_STOCK
    full_final = data[full_off:full_off + len(SLEEP_MESSAGE_FULL_FINAL)] == SLEEP_MESSAGE_FULL_FINAL

    if full_stock and ptr == SLEEP_MESSAGE_PTR_STOCK:
        state = "stock"
    elif full_final and ptr == SLEEP_MESSAGE_PTR_STOCK:
        state = "r35_r43_broken_entry"
    elif full_final and ptr == SLEEP_MESSAGE_PTR_FINAL:
        state = "applied_r44"
    else:
        raise ValueError(
            "R44: 수면 메시지 문자열/진입 포인터가 알려진 상태가 아닙니다: "
            f"ptr={ptr.hex(' ')} full_stock={full_stock} full_final={full_final}"
        )

    short_off = seg85["file_off"] + SLEEP_MESSAGE_SHORT_FINAL_SEG
    short_matches = data[short_off:short_off + len(SLEEP_MESSAGE_SHORT_FINAL)] == SLEEP_MESSAGE_SHORT_FINAL
    if state == "applied_r44" and not short_matches:
        raise ValueError("R44: DS:38AB가 `잠들었다!!` 시작점이 아닙니다")

    return {
        "state": state,
        "code_file_offset": code_off,
        "pointer_hex": ptr.hex(" "),
        "full_message_seg": f"0x{SLEEP_MESSAGE_FULL_SEG:04X}",
        "short_message_seg": f"0x{SLEEP_MESSAGE_SHORT_FINAL_SEG:04X}",
        "short_message_matches": short_matches,
    }


def apply_sleep_message_entry(buf: bytearray, changes: list[dict[str, object]]) -> None:
    before = bytes(buf)
    info = inspect_sleep_message_entry(before)
    if info["state"] == "applied_r44":
        return
    if info["state"] != "r35_r43_broken_entry":
        # Stock is accepted by inspect() because the fixed wording slot is applied
        # earlier in build_target().  Reaching stock here means the caller skipped
        # the wording normalization and should not silently change only code.
        raise ValueError("R44: 수면 진입 포인터 수정 전에 R35 수면 문구가 적용되어야 합니다")

    code_off = int(info["code_file_offset"])
    old = bytes(buf[code_off:code_off + 3])
    if old != SLEEP_MESSAGE_PTR_STOCK:
        raise ValueError("R44: 수면 진입 포인터 원본 바이트가 예상과 다릅니다")
    buf[code_off:code_off + 3] = SLEEP_MESSAGE_PTR_FINAL
    changes.append({
        "offset": code_off,
        "group": "wording",
        "purpose": "수면 최초 적용 메시지 진입점: DS:38A7(CP949 중간 바이트) → DS:38AB(`잠들었다!!`)",
        "before": old.hex(" "),
        "after": SLEEP_MESSAGE_PTR_FINAL.hex(" "),
        "byte_length": 3,
    })
    post = inspect_sleep_message_entry(bytes(buf))
    if post["state"] != "applied_r44" or not post["short_message_matches"]:
        raise ValueError("R44: 수면 메시지 진입 포인터 후검증 실패")

def _particle_slot_state(data: bytes, off: int, cap: int, stock: str, r42: str, final: str) -> str:
    seg = ne_slot_segments(data)[ITEM_EFFECT_SEG_INDEX - 1]
    base = seg.file_offset
    # opcode 02 must remain immediately before the particle suffix.
    if data[base + off - 1:base + off] != b"\x02":
        return "unknown"
    final_b = final.encode("cp949")
    if len(final_b) <= cap:
        expected = final_b + b"\xFF" * (cap - len(final_b)) + b"\x0A"
        if data[base + off:base + off + cap + 1] == expected:
            return "final"
    else:
        if message_redirect_matches(data, ITEM_EFFECT_SEG_INDEX, off, cap, final_b, b"\x0A"):
            return "final"
    raw = data[base + off:base + off + cap]
    for label, text in (("r42", r42), ("stock", stock)):
        enc = text.encode("cp949")
        if len(enc) <= cap and raw == enc + b" " * (cap - len(enc)):
            return label
        # Some R42 fixed() entries already carry their own trailing padding.
        if len(enc) == cap and raw == enc:
            return label
    return "unknown"


def inspect_dynamic_battle_particles(data: bytes) -> dict[str, object]:
    validate_ne(data)
    seg85 = _ne_segment_row(data, ITEM_EFFECT_SEG_INDEX)
    seg86 = _ne_segment_row(data, ITEM_EFFECT_SEG_INDEX + 1)
    rows=[]
    for off,cap,stock,r42,final in BATTLE_PARTICLE_SPECS:
        st=_particle_slot_state(data,off,cap,stock,r42,final)
        rows.append({"offset":f"0x{off:04X}","capacity":cap,"state":st,"final":final})
    states={r["state"] for r in rows}
    if states == {"final"}:
        state="applied_r43"
    elif states <= {"stock","r42"} and "unknown" not in states:
        state="pre_r43"
    else:
        state="mixed_or_unknown"
    ok = state == "applied_r43" and seg85["length"] == BATTLE_PARTICLE_SEG_FINAL_LEN and seg86["file_off"] == SEG86_FILE_OFFSET
    return {"state":state,"ok":ok,"rows":rows,"segment85_length":seg85["length"],"segment86_file_offset":seg86["file_off"]}


def apply_dynamic_battle_particles(buf: bytearray, changes: list[dict[str, object]]) -> None:
    before=bytes(buf)
    info=inspect_dynamic_battle_particles(before)
    if info["state"] == "applied_r43":
        return
    if info["state"] != "pre_r43":
        raise ValueError(f"R43: 동적 몬스터 조사 메시지 상태가 예상과 다릅니다: {info}")
    # R42 item-effect static data must already own its target before allocating
    # more segment-85 tail bytes.
    item=inspect_item_effect_boundary(before)
    if item["state"] != "applied_static_r42":
        raise ValueError("R43: item-effect R42 정적 데이터가 먼저 적용되어야 합니다")
    old86=_ne_segment_row(before,ITEM_EFFECT_SEG_INDEX+1)["file_off"]
    old_size=len(before)
    out=before
    for off,cap,_stock,_r42,final in BATTLE_PARTICLE_SPECS:
        result=patch_message_slot_0f(out,ITEM_EFFECT_SEG_INDEX,off,cap,final.encode("cp949"),b"\x0A")
        out=result.data
    if len(out)!=old_size:
        raise ValueError("R43: ED2MAIN 파일 크기가 변경되었습니다")
    if _ne_segment_row(out,ITEM_EFFECT_SEG_INDEX+1)["file_off"] != old86:
        raise ValueError("R43: segment 86 위치가 이동했습니다")
    post=inspect_dynamic_battle_particles(out)
    if not post["ok"]:
        raise ValueError(f"R43: 동적 조사 후검증 실패: {post}")
    # Declare every actually changed byte range, including the NE segment-85
    # length/min_alloc words and moved relocation/tail payload.  The outer
    # patcher uses these ranges to prove no undeclared ED2MAIN bytes changed.
    diff=[i for i,(a,b) in enumerate(zip(before,out)) if a!=b]
    ranges=[]
    if diff:
        st=pr=diff[0]
        for x in diff[1:]:
            if x==pr+1:
                pr=x; continue
            ranges.append((st,pr+1)); st=pr=x
        ranges.append((st,pr+1))
    buf[:] = out
    for st,en in ranges:
        changes.append({
            "offset":st,"group":"wording",
            "purpose":"R43 동적 몬스터명 조사 자동선택 데이터/로컬 0F redirect",
            "before":before[st:en].hex(" "),"after":out[st:en].hex(" "),
            "byte_length":en-st,
        })

def inspect(data: bytes) -> list[dict[str, object]]:
    validate_ne(data)
    inspect_stun_exp_patch(data)
    inspect_status_patch(data)
    inspect_royal_tomb_center(data)
    inspect_item_effect_boundary(data)
    inspect_dynamic_battle_particles(data)
    inspect_sleep_message_entry(data)
    inspect_reward_suffix_layout(data)
    inspect_levelup_presentation(data)
    rows: list[dict[str, object]] = []
    for slot in ALL_SLOTS:
        if slot.offset in BATTLE_PARTICLE_STATIC_SLOT_OFFSETS:
            continue
        current = data[slot.offset:slot.offset + len(slot.original)]
        if current not in accepted_values(slot):
            raise ValueError(
                f"0x{slot.offset:X} 문구가 예상과 다릅니다: "
                f"{current.hex(' ')} ({slot.purpose})"
            )
        rows.append({
            "offset": slot.offset,
            "group": slot.group,
            "purpose": slot.purpose,
            "current": current.decode("cp949", errors="replace"),
            "original": slot.original.decode("cp949", errors="replace"),
            "desired": slot.desired.decode("cp949", errors="replace"),
            "length": len(slot.original),
        })
    return rows


def atomic_write(path: Path, data: bytes, *, journal: bool = True) -> None:
    before = path.read_bytes() if path.exists() else b""
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
        if journal and before != data:
            try:
                record_patch(path, before, data, JOURNAL_COMPONENT)
            except Exception:
                # A journal is required for non-destructive Restore. Roll back
                # the file rather than leave an untracked partial patch.
                atomic_write(path, before, journal=False)
                raise
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


def build_target(
    data: bytes, labels_only: bool, no_wording: bool, no_proper_nouns: bool
) -> tuple[bytes, list[dict[str, object]]]:
    selected = {
        slot.offset: slot
        for slot in selected_slots(labels_only, no_wording, no_proper_nouns)
        if slot.offset not in BATTLE_PARTICLE_STATIC_SLOT_OFFSETS
    }
    buf = bytearray(data)
    changes: list[dict[str, object]] = []

    # Selected slots go to desired state. All spell-related slots now normalize
    # to 주문; legacy 마법 bytes remain accepted only as migration input.
    for slot in ALL_SLOTS:
        if slot.offset in BATTLE_PARTICLE_STATIC_SLOT_OFFSETS:
            continue
        if slot.offset in selected:
            wanted = slot.desired
        elif slot.group == "magic_system":
            wanted = slot.original
        else:
            continue
        current = bytes(buf[slot.offset:slot.offset + len(slot.original)])
        if current != wanted:
            buf[slot.offset:slot.offset + len(wanted)] = wanted
            changes.append({
                "offset": slot.offset,
                "group": slot.group,
                "purpose": slot.purpose,
                "before": current.decode("cp949", errors="replace"),
                "after": wanted.decode("cp949", errors="replace"),
                "byte_length": len(wanted),
            })

    if not no_wording:
        apply_sleep_message_entry(buf, changes)
        apply_item_effect_boundary_static(buf, changes)
        apply_dynamic_battle_particles(buf, changes)
        apply_reward_suffix_layout(buf, changes)
        apply_levelup_presentation(buf, changes)

    # 모든 두 글자 상태 확장을 제거하고 원본 한 글자 상태 출력을 복구한다.
    wrapper = bytes(buf[STATUS_WRAPPER_OFFSET:STATUS_WRAPPER_OFFSET + len(STATUS_WRAPPER_ORIGINAL)])
    helper = bytes(buf[STATUS_HELPER_OFFSET:STATUS_HELPER_OFFSET + len(STATUS_HELPER_ORIGINAL)])
    cave = bytes(buf[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + STATUS_CAVE_SIZE])

    if wrapper not in (STATUS_WRAPPER_ORIGINAL, STUN_STATUS_ROUTINE_PATCHED):
        buf[STATUS_WRAPPER_OFFSET:STATUS_WRAPPER_OFFSET + len(STATUS_WRAPPER_ORIGINAL)] = STATUS_WRAPPER_ORIGINAL
        changes.append({
            "offset": STATUS_WRAPPER_OFFSET, "group": "battle_status",
            "purpose": "전투 상태 wrapper를 원본 한 글자 출력으로 복구",
            "before": "두 글자 상태 확장 루틴으로 점프",
            "after": "원본 wrapper",
            "byte_length": len(STATUS_WRAPPER_ORIGINAL),
        })

    if helper != STATUS_HELPER_ORIGINAL:
        buf[STATUS_HELPER_OFFSET:STATUS_HELPER_OFFSET + len(STATUS_HELPER_ORIGINAL)] = STATUS_HELPER_ORIGINAL
        changes.append({
            "offset": STATUS_HELPER_OFFSET, "group": "battle_status",
            "purpose": "전투 상태 helper를 원본 한 글자 출력으로 복구",
            "before": "두 글자 상태 확장 영역으로 점프",
            "after": "원본 상태 테이블 스캔 helper",
            "byte_length": len(STATUS_HELPER_ORIGINAL),
        })

    # Clear the cave only when the wrapper/helper prove that it still belongs
    # to an old two-character status patch.  With original wrapper/helper the
    # cave may contain Mod Studio's item-magic code and is deliberately left
    # byte-for-byte untouched.
    status_owns_cave = (
        wrapper == STATUS_WRAPPER_FIX1_PATCHED
        or helper == STATUS_HELPER_LEGACY_PATCHED
    )
    if status_owns_cave and cave != STATUS_CAVE_ORIGINAL:
        buf[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + STATUS_CAVE_SIZE] = STATUS_CAVE_ORIGINAL
        changes.append({
            "offset": STATUS_CAVE_OFFSET, "group": "battle_status",
            "purpose": "두 글자 전투 상태 확장 코드 제거",
            "before": "이전 버전 상태 출력 확장 코드",
            "after": "원본 미사용 00 영역",
            "byte_length": STATUS_CAVE_SIZE,
        })

    # v1.0.29: 왕가의무덤은 실제 12바이트 지명 레코드(0x15084C)를
    # `` 왕가의무덤 ``으로 기록한다. 과거 코드 훅은 모두 순정으로 복원하며
    # 별도 제어 바이트를 사용하지 않는다.
    align_state = inspect_royal_tomb_center(bytes(buf))

    global_entry = bytes(buf[
        LEGACY_ROYAL_TOMB_ENTRY_OFFSET:
        LEGACY_ROYAL_TOMB_ENTRY_OFFSET + len(LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL)
    ])
    if global_entry != LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL:
        if global_entry != LEGACY_ROYAL_TOMB_ENTRY_PATCHED:
            raise ValueError("DS_KST 왕가의무덤 구버전 훅 진입점이 예상과 다릅니다")
        buf[
            LEGACY_ROYAL_TOMB_ENTRY_OFFSET:
            LEGACY_ROYAL_TOMB_ENTRY_OFFSET + len(LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL)
        ] = LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL
        changes.append({
            "offset": LEGACY_ROYAL_TOMB_ENTRY_OFFSET,
            "group": "location_alignment",
            "purpose": "왕가의무덤 전역 DS_KST 정렬 훅 제거",
            "before": "v1.0.23~v1.0.24 전역 훅",
            "after": "순정 DS_KST prologue",
            "byte_length": len(LEGACY_ROYAL_TOMB_ENTRY_ORIGINAL),
        })

    warp_site = bytes(buf[
        ROYAL_TOMB_WARP_SITE_OFFSET:
        ROYAL_TOMB_WARP_SITE_OFFSET + len(ROYAL_TOMB_WARP_SITE_ORIGINAL)
    ])
    if warp_site != ROYAL_TOMB_WARP_SITE_ORIGINAL:
        if warp_site != ROYAL_TOMB_WARP_SITE_PATCHED:
            raise ValueError("DISP_TOWN_MENU 왕가의무덤 구버전 훅 진입점이 예상과 다릅니다")
        buf[
            ROYAL_TOMB_WARP_SITE_OFFSET:
            ROYAL_TOMB_WARP_SITE_OFFSET + len(ROYAL_TOMB_WARP_SITE_ORIGINAL)
        ] = ROYAL_TOMB_WARP_SITE_ORIGINAL
        changes.append({
            "offset": ROYAL_TOMB_WARP_SITE_OFFSET,
            "group": "location_alignment",
            "purpose": "워프의 날개 왕가의무덤 코드 훅 제거",
            "before": "v1.0.25 conditional-center helper call",
            "after": "순정 mov si,TOWN_NAME$",
            "byte_length": len(ROYAL_TOMB_WARP_SITE_ORIGINAL),
        })

    hud_site = bytes(buf[
        ROYAL_TOMB_HUD_SITE_OFFSET:
        ROYAL_TOMB_HUD_SITE_OFFSET + len(ROYAL_TOMB_HUD_SITE_ORIGINAL)
    ])
    if hud_site != ROYAL_TOMB_HUD_SITE_ORIGINAL:
        if hud_site != ROYAL_TOMB_HUD_SITE_PATCHED:
            raise ValueError("DISP_TOWN_NAME 왕가의무덤 구버전 훅 진입점이 예상과 다릅니다")
        buf[
            ROYAL_TOMB_HUD_SITE_OFFSET:
            ROYAL_TOMB_HUD_SITE_OFFSET + len(ROYAL_TOMB_HUD_SITE_ORIGINAL)
        ] = ROYAL_TOMB_HUD_SITE_ORIGINAL
        changes.append({
            "offset": ROYAL_TOMB_HUD_SITE_OFFSET,
            "group": "location_alignment",
            "purpose": "우측 하단 왕가의무덤 코드 훅 제거",
            "before": "v1.0.25 conditional-center helper call",
            "after": "순정 mov di,68A2",
            "byte_length": len(ROYAL_TOMB_HUD_SITE_ORIGINAL),
        })

    cave = bytes(buf[ROYAL_TOMB_CAVE_OFFSET:ROYAL_TOMB_CAVE_OFFSET + ROYAL_TOMB_CAVE_SIZE])
    if set(cave) - {0}:
        legacy_cave = (
            cave[:len(LEGACY_ROYAL_TOMB_HELPER)] == LEGACY_ROYAL_TOMB_HELPER
            and set(cave[len(LEGACY_ROYAL_TOMB_HELPER):]) <= {0}
        )
        if not (legacy_cave or cave == ROYAL_TOMB_TARGETED_CAVE):
            raise ValueError("86:1700~17FF 왕가의무덤 구버전 코드 케이브가 예상과 다릅니다")
        buf[ROYAL_TOMB_CAVE_OFFSET:ROYAL_TOMB_CAVE_OFFSET + ROYAL_TOMB_CAVE_SIZE] = bytes(ROYAL_TOMB_CAVE_SIZE)
        changes.append({
            "offset": ROYAL_TOMB_CAVE_OFFSET,
            "group": "location_alignment",
            "purpose": "왕가의무덤 정렬 helper 제거",
            "before": "v1.0.23~v1.0.25 정렬 helper",
            "after": "순정 미사용 00 영역",
            "byte_length": ROYAL_TOMB_CAVE_SIZE,
        })

    # R33: R27의 데이터/SET_EXP 동작은 그대로 유지하되, 첫 DISPLAY_STR의
    # 조기 NUL이 SI를 앞에서 멈추게 해도 두 번째 렌더는 반드시 DS:91CD에서
    # 시작하도록 고정한다.  R31의 훅/도우미가 남아 있으면 먼저 R27 상태로
    # 정규화한 뒤 86:A9AA -> 86:0300의 no-growth helper를 설치한다.
    inspect_stun_exp_patch(bytes(buf))
    routine = bytes(buf[STUN_STATUS_ROUTINE_OFFSET:STUN_STATUS_ROUTINE_OFFSET + 3])
    set_exp = bytes(buf[STUN_SET_EXP_OFFSET:STUN_SET_EXP_OFFSET + 6])
    cave = bytes(buf[STUN_UI_CAVE_OFFSET:STUN_UI_CAVE_OFFSET + len(STUN_UI_CAVE_CODE)])
    second_hook = bytes(buf[STUN_SECOND_RENDER_HOOK_OFFSET:STUN_SECOND_RENDER_HOOK_OFFSET + 4])

    if routine != STUN_STATUS_ROUTINE_ORIGINAL:
        if routine not in (STUN_STATUS_ROUTINE_PATCHED, STATUS_WRAPPER_FIX1_PATCHED):
            raise ValueError("R33: 기절 상태 wrapper가 예상과 다릅니다")
        buf[STUN_STATUS_ROUTINE_OFFSET:STUN_STATUS_ROUTINE_OFFSET + 3] = STUN_STATUS_ROUTINE_ORIGINAL
        changes.append({
            "offset": STUN_STATUS_ROUTINE_OFFSET, "group": "stun_hp_ui",
            "purpose": "R31 기절 상태 훅 제거/R27 원형 유지",
            "before": routine.hex(" "), "after": STUN_STATUS_ROUTINE_ORIGINAL.hex(" "),
            "byte_length": 3,
        })
    if set_exp != STUN_SET_EXP_ORIGINAL:
        if set_exp != STUN_SET_EXP_PATCHED:
            raise ValueError("R33: SET_EXP 진입부가 예상과 다릅니다")
        buf[STUN_SET_EXP_OFFSET:STUN_SET_EXP_OFFSET + 6] = STUN_SET_EXP_ORIGINAL
        changes.append({
            "offset": STUN_SET_EXP_OFFSET, "group": "stun_hp_ui",
            "purpose": "R31 EXP 우회 훅 제거/R27 SET_EXP 유지",
            "before": set_exp.hex(" "), "after": STUN_SET_EXP_ORIGINAL.hex(" "),
            "byte_length": 6,
        })

    if cave not in (STUN_UI_CAVE_ORIGINAL, STUN_UI_CAVE_CODE, STUN_UI_CAVE_R33):
        raise ValueError("R33: 86:0300 helper 영역이 예상과 다릅니다")
    if cave != STUN_UI_CAVE_R33:
        buf[STUN_UI_CAVE_OFFSET:STUN_UI_CAVE_OFFSET + len(STUN_UI_CAVE_CODE)] = STUN_UI_CAVE_R33
        changes.append({
            "offset": STUN_UI_CAVE_OFFSET, "group": "stun_hp_ui",
            "purpose": "두 번째 DISPLAY_STR SI=91CD 고정 helper 설치",
            "before": cave.hex(" "), "after": STUN_UI_CAVE_R33.hex(" "),
            "byte_length": len(STUN_UI_CAVE_CODE),
        })
    if second_hook != STUN_SECOND_RENDER_HOOK_PATCHED:
        if second_hook != STUN_SECOND_RENDER_HOOK_ORIGINAL:
            raise ValueError("R33: 두 번째 DISPLAY_STR hook 위치가 예상과 다릅니다")
        buf[STUN_SECOND_RENDER_HOOK_OFFSET:STUN_SECOND_RENDER_HOOK_OFFSET + 4] = STUN_SECOND_RENDER_HOOK_PATCHED
        changes.append({
            "offset": STUN_SECOND_RENDER_HOOK_OFFSET, "group": "stun_hp_ui",
            "purpose": "두 번째 DISPLAY_STR 전에 SI=91CD 재설정",
            "before": second_hook.hex(" "), "after": STUN_SECOND_RENDER_HOOK_PATCHED.hex(" "),
            "byte_length": 4,
        })


    return bytes(buf), changes


def patch(
    exe: Path, *, check_only: bool, labels_only: bool, no_wording: bool,
    no_proper_nouns: bool,
) -> int:
    before = exe.read_bytes()
    inspect(before)
    target, changes = build_target(
        before, labels_only, no_wording, no_proper_nouns
    )

    mode = "주문 UI 정규화"
    wording = "제외" if no_wording else f"포함({len(WORDING_SLOTS)}곳)"
    proper = "제외" if no_proper_nouns else f"포함({len(EXTRA_PROPER_NOUN_SLOTS)}곳)"
    print(f"대상: {exe}")
    print(
        f"모드: {mode}, UI 문장 교정 {wording}, "
        f"지명 슬롯 27곳 복구·철자 통일, 추가 고유명사 {proper}"
    )
    print(f"변경 필요: {len(changes)}곳")

    if check_only:
        for row in changes:
            print(f"  0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
        return 0
    if not changes:
        print("이미 요청한 패치 상태입니다.")
        return 0

    backup = exe.with_name(exe.name + BACKUP_SUFFIX)
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") != "1" and not backup.exists():
        shutil.copy2(exe, backup)
        print(f"백업 생성: {backup.name}")

    if len(target) != len(before):
        raise RuntimeError("패치 후 파일 크기가 달라졌습니다.")

    allowed: set[int] = set()
    for row in changes:
        off = int(row["offset"])
        allowed.update(range(off, off + int(row["byte_length"])))
    actual = {i for i, (a, b) in enumerate(zip(before, target)) if a != b}
    if not actual.issubset(allowed):
        raise RuntimeError("선언된 문구 슬롯 밖의 바이트가 변경되었습니다.")

    # Reparse all slots before committing.
    inspect(target)
    atomic_write(exe, target)
    reread = exe.read_bytes()
    if reread != target:
        raise RuntimeError("저장 후 바이트 재검증에 실패했습니다.")

    report = {
        "patch_version": VERSION,
        "target": str(exe),
        "backup": str(backup),
        "mode": {
            "labels_only": labels_only,
            "magic_scope": 5 if labels_only else 12,
            "wording_fixes": 0 if no_wording else len(WORDING_SLOTS) + 1,
            "extra_proper_noun_fixes": (
                0 if no_proper_nouns else len(EXTRA_PROPER_NOUN_SLOTS)
            ),
            "battle_status_labels": {
                "0x01": "독", "0x02": "묵", "0x08": "잠",
                "0x10": "혼", "0x20": "수", "0x40": "반",
            },
            "battle_status_layout": {
                "mode": "original_one_character_abbreviations",
                "expanded_status_code_removed": True,
                "following_mp_position": "original",
            },
            "location_labels": [slot.desired.decode("cp949").rstrip() for slot in LOCATION_SLOTS],
        },
        "size_before": len(before),
        "size_after": len(target),
        "sha256_before": sha256(before),
        "sha256_after": sha256(target),
        "changes": changes,
        "validation": {
            "mz_ne_valid": True,
            "file_size_unchanged": len(before) == len(target),
            "changes_limited_to_declared_slots": actual.issubset(allowed),
            "saved_bytes_match": reread == target,
        },
    }
    report_path = exe.parent / REPORT_NAME
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("패치 완료:")
    for row in changes:
        print(f"  0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
    print(f"보고서: {report_path.name}")
    return 0


def restore(exe: Path) -> int:
    try:
        restored = selective_restore(exe, JOURNAL_COMPONENT)
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        print("기존 전체 백업은 다른 패치를 지울 수 있어 자동 복원에 사용하지 않습니다.", file=sys.stderr)
        return 2
    inspect(exe.read_bytes())
    print(f"선택적 복원 완료: {exe} ({restored}바이트)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="영웅전설 2 한국판 UI 문구 정밀 패치")
    ap.add_argument("path", nargs="?", default=".", help="게임 폴더 또는 ED2MAIN.EXE")
    ap.add_argument(
        "--labels-only", action="store_true",
        help="구버전 호환 옵션. 현재 버전은 관련 UI 12곳을 모두 주문으로 복원",
    )
    ap.add_argument("--no-wording", action="store_true", help="추가 UI 문장 교정을 적용하지 않음")
    ap.add_argument(
        "--no-proper-nouns", action="store_true",
        help="베른→베룬 추가 고유명사 교정을 적용하지 않음",
    )
    action = ap.add_mutually_exclusive_group()
    action.add_argument("--check", action="store_true", help="검사만 수행")
    action.add_argument("--restore", action="store_true", help="이 패치 적용 전 파일로 복원")
    args = ap.parse_args()
    try:
        exe = resolve_exe(Path(args.path))
        if args.restore:
            return restore(exe)
        return patch(
            exe,
            check_only=args.check,
            labels_only=args.labels_only,
            no_wording=args.no_wording,
            no_proper_nouns=args.no_proper_nouns,
        )
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
