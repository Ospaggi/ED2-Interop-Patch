#!/usr/bin/env python3
from __future__ import annotations
import csv
from pathlib import Path
HERE=Path(__file__).resolve().parent.parent
CANONICAL=HERE/'data'/'dialogue_probe_rows.csv'
class ProbeError(RuntimeError): pass
def u16(b,o): return int.from_bytes(b[o:o+2],'little')
def u32(b,o): return int.from_bytes(b[o:o+4],'little')
def parse_segments(data: bytes):
    ne=u32(data,0x3c); table=ne+u16(data,ne+0x22); shift=u16(data,ne+0x32); count=u16(data,ne+0x1c); out={}
    for i in range(count):
        e=table+i*8; sector=u16(data,e); ln=u16(data,e+2); out[i+1]=(sector<<shift,65536 if ln==0 else ln,u16(data,e+4))
    return out
def effective_positions(data: bytes, seg_index: int, offset: int, editable: int):
    base,length,_=parse_segments(data)[seg_index]; block=data[base:base+length]; raw=block[offset:offset+editable]
    for p in range(max(0,len(raw)-2)):
        if raw[p]!=0x0F or p+2>=len(raw) or not all(x==0xFF for x in raw[p+3:]): continue
        ptr=raw[p+1] | (raw[p+2]<<8)
        if ptr>=len(block): continue
        ret=offset+editable; out=[(raw[i],base+offset+i) for i in range(p)]; pos=ptr
        for _ in range(32768):
            if pos+2<len(block) and block[pos]==0x0F and (block[pos+1] | (block[pos+2]<<8))==ret: return out
            if pos>=len(block): break
            out.append((block[pos],base+pos)); pos+=1
        raise ProbeError(f'seg{seg_index}:{offset:04X} 0F redirect return not found')
    return [(raw[i],base+offset+i) for i in range(len(raw))]
def visible_text(stream) -> str:
    buf=bytearray()
    for b,_ in stream:
        if b in (0x01,0x05): buf.append(0x20)
        elif b==0xFF: continue
        else: buf.append(b)
    try: s=buf.decode('cp949')
    except UnicodeDecodeError: return ''
    return ' '.join(s.split())
def load_rows():
    with CANONICAL.open(encoding='utf-8-sig',newline='') as f:
        return {(r['dll'],r['offset']):r for r in csv.DictReader(f)}
