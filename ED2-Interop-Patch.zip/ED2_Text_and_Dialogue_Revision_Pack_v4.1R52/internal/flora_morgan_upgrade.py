#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, stat
from pathlib import Path

VERSION = 'v4.1R51'
DLL = 'H_500.DLL'
SEGMENT = 3
SLOT_OFFSET = 0x021E
EDITABLE = 25
PREV_CONTROL_OFFSET = 0x0209
PREV_SENTENCE_BREAK = 0x021D
OLD_TEXT = '하지만 당신밖에는 없어요.'
LINE1 = '모건 씨 기분은 잘 알겠어요.'
LINE2 = '하지만 모건 씨만이 할 수 있는'
LINE3 = '일이에요.'
NEW_BYTES = LINE2.encode('cp949') + b'\x01' + LINE3.encode('cp949')
OLD_SHA256 = 'ebddff57c5366a4c42059eef99ea15b38a4f0e91338c40b86e170d816e3a49e6'
NEW_SHA256 = '56d5cf49917813f1311ee8d46f323b181a36e10443052e693a0fc3a63dca98a4'
EXPECTED_SIZE = 33296

class R51Error(RuntimeError): pass

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()

def load_helpers():
    here = Path(__file__).resolve().parent.parent
    scene = here / 'scene_editor'
    if not scene.is_dir(): raise R51Error('scene_editor를 찾지 못했습니다.')
    import sys
    sys.path.insert(0, str(scene))
    from ed2_ne_slot import patch_message_slot_0f, message_redirect_matches, parse_segments, tail_layout
    return patch_message_slot_0f, message_redirect_matches, parse_segments, tail_layout

def reloc_blob(data: bytes, seg_index: int, parse_segments) -> bytes:
    seg = parse_segments(data)[seg_index-1]
    if not (seg.flags & 0x0100): return b''
    end = seg.file_offset + seg.length
    count = int.from_bytes(data[end:end+2], 'little')
    return data[end:end+2+count*8]

def safe_write(path: Path, data: bytes) -> None:
    mode = path.stat().st_mode
    tmp = path.with_name(path.name + '.r51.tmp')
    try:
        tmp.write_bytes(data)
        try: path.chmod(mode | stat.S_IWRITE)
        except OSError: pass
        os.replace(tmp, path)
        try: path.chmod(mode)
        except OSError: pass
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass

def inspect(data: bytes):
    patch_message_slot_0f, redirect_matches, parse_segments, tail_layout = load_helpers()
    if len(data) != EXPECTED_SIZE: raise R51Error(f'{DLL} 크기가 예상과 다릅니다: {len(data)}')
    seg = parse_segments(data)[SEGMENT-1]
    base = seg.file_offset
    if data[base + PREV_CONTROL_OFFSET] != 0x20:
        raise R51Error('R50의 모건 씨 호칭 결합 제어(20h)가 없습니다.')
    if data[base + PREV_SENTENCE_BREAK] != 0x01:
        raise R51Error('첫 문장 뒤 01h 경계가 없습니다.')
    h = sha(data)
    final_match = redirect_matches(data, SEGMENT, SLOT_OFFSET, EDITABLE, NEW_BYTES, b'')
    old_raw = data[base+SLOT_OFFSET:base+SLOT_OFFSET+EDITABLE]
    old_match = old_raw == OLD_TEXT.encode('cp949')
    state = 'final' if final_match and h == NEW_SHA256 else 'old' if old_match and h == OLD_SHA256 else 'unsupported'
    return state, h, seg, tail_layout(data, SEGMENT), parse_segments, patch_message_slot_0f, redirect_matches

def process(root: Path, check: bool, no_backup: bool):
    root = root.resolve(); path = root / 'SCENA' / DLL
    if not (root / 'ED2MAIN.EXE').is_file() or not path.is_file(): raise R51Error('영웅전설 II 게임 폴더를 찾지 못했습니다.')
    before = path.read_bytes()
    state, before_hash, old_seg, old_layout, parse_segments, patch_message_slot_0f, redirect_matches = inspect(before)
    if state == 'unsupported': raise R51Error(f'{DLL}이 지원하지 않는 상태입니다: {before_hash}')
    if check:
        report = {'version':VERSION,'mode':'check','ok':state=='final','state':state,'sha256':before_hash,'expected_sha256':NEW_SHA256,
                  'display_lines':[LINE1,LINE2,LINE3],'display_bytes':[len(x.encode('cp949')) for x in (LINE1,LINE2,LINE3)]}
        print(json.dumps(report, ensure_ascii=False, indent=2)); return 0 if state=='final' else 2
    if state == 'final':
        report = {'version':VERSION,'changed_files':0,'state':'already_current','sha256':before_hash,'display_lines':[LINE1,LINE2,LINE3]}
        print(json.dumps(report,ensure_ascii=False,indent=2)); return 0
    old_reloc = reloc_blob(before, SEGMENT, parse_segments)
    res = patch_message_slot_0f(before, SEGMENT, SLOT_OFFSET, EDITABLE, NEW_BYTES, b'')
    after = res.data
    after_hash = sha(after)
    if after_hash != NEW_SHA256: raise R51Error(f'결과 SHA-256 불일치: {after_hash}')
    if len(after) != len(before): raise R51Error('파일 크기가 변경되었습니다.')
    new_seg = parse_segments(after)[SEGMENT-1]
    if reloc_blob(after, SEGMENT, parse_segments) != old_reloc: raise R51Error('segment 3 relocation blob이 변경되었습니다.')
    if not redirect_matches(after, SEGMENT, SLOT_OFFSET, EDITABLE, NEW_BYTES, b''): raise R51Error('0F redirect 사후 검증 실패')
    for line in (LINE1,LINE2,LINE3):
        if len(line.encode('cp949')) > 34: raise R51Error(f'34셀 초과: {line}')
    if not no_backup:
        bak = path.with_name(path.name + '.r51.bak')
        if not bak.exists(): bak.write_bytes(before)
    safe_write(path, after)
    new_layout = load_helpers()[3](after, SEGMENT)
    report = {
        'version': VERSION, 'changed_files':1, 'dll':DLL,
        'before_sha256':before_hash, 'after_sha256':after_hash,
        'file_size':len(after), 'redirected':res.redirected,
        'redirect_pointer':f'0x{res.pointer:04X}' if res.pointer is not None else None,
        'consumed_padding':res.consumed_padding,
        'segment3_length_before':old_seg.length,'segment3_length_after':new_seg.length,
        'tail_padding_before':old_layout.available_padding,'tail_padding_after':new_layout.available_padding,
        'relocation_blob_preserved':True,
        'display_lines':[LINE1,LINE2,LINE3],
        'display_bytes':[len(x.encode('cp949')) for x in (LINE1,LINE2,LINE3)],
        'pc98':'モーガンさん。 / 気持ちは よくわかりますわ。 / でも あなたしか いないのです。',
    }
    print(json.dumps(report,ensure_ascii=False,indent=2)); return 0

def main():
    ap=argparse.ArgumentParser(description='ED2 Flora/Morgan dialogue tone update v4.1R51')
    ap.add_argument('game_root'); ap.add_argument('--check',action='store_true'); ap.add_argument('--no-backup',action='store_true')
    a=ap.parse_args()
    try:return process(Path(a.game_root),a.check,a.no_backup)
    except Exception as e:
        print('ERROR:',e, file=__import__('sys').stderr); return 1
if __name__=='__main__': raise SystemExit(main())
