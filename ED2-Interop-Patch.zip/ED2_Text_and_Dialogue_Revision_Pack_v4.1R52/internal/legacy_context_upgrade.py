#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
SCENE = HERE / 'scene_editor'
import sys
sys.path.insert(0, str(SCENE))
from ed2_ne_slot import (
    patch_message_slot_0f,
    message_redirect_matches,
    parse_segments,
    tail_layout,
)

APP = 'ED2 Dialogue Context Re-audit R50'
VERSION = 'v4.1R50'

# Control-only layout fixes.  All offsets are segment-relative.
# The Rando exact-34 case is deliberately NOT present here.
CONTROL_PATCHES = (
    # Short vocative / continuation joins (01h -> ASCII space).
    ('C_00A.DLL', 3, 0x0457, 0x01, 0x20, '왕자님, + 그 드래곤에는 타 보셨나요?'),
    ('C_00E.DLL', 3, 0x057F, 0x01, 0x20, '왕자님, + 되도록 무리하지 마십시오.'),
    ('D_530.DLL', 3, 0x0151, 0x01, 0x20, '선생님, + 역시 조금 앞까진 가는데'),
    ('H_500.DLL', 3, 0x0209, 0x01, 0x20, '모건 씨 + 기분은 잘 알겠어요.'),
    ('T_013.DLL', 3, 0x05E6, 0x01, 0x20, '왕자님, + 루디아는 염려 마세요.'),
    ('T_205.DLL', 3, 0x0109, 0x01, 0x20, '왕자님, + 세리오스님은요?'),
    ('T_206.DLL', 3, 0x049B, 0x01, 0x20, '왕자님, + 이것을 가지고 가시지요.'),

    # False exact-34 cleanup: an earlier explicit break means the sentence does
    # not actually reach column 34 at this boundary. Restore sentence boundary.
    ('T_114.DLL', 3, 0x02D9, 0xFF, 0x01, '모르나? / 라누라의 아가씨거든.'),
    ('T_234.DLL', 3, 0x08F8, 0xFF, 0x01, '않으셨는지. / 그것만이 걱정이었어요.'),
    ('T_511.DLL', 3, 0x05FF, 0xFF, 0x01, '돌아다니고 있거든. / 대체 무슨 일이 생긴 거지?'),
    ('T_551.DLL', 3, 0x0100, 0xFF, 0x01, '걱정해야 하지? / 녀석들이 무슨 짓을 했는지 알잖아.'),
    # Move the old break after '녀석들이' back to a normal space, so Pross is
    # exactly three natural lines instead of four.
    ('T_551.DLL', 3, 0x0109, 0x01, 0x20, '녀석들이 + 무슨 짓을 했는지 알잖아.'),
)

SONIA_DLL = 'V_300.DLL'
SONIA_SEG = 3
SONIA_OFF = 0x00F1
SONIA_EDITABLE = 25
SONIA_OLD = '고맙소. 아트라스 왕자.'
SONIA_OLD_ALT = '고맙소, 아트라스 왕자.'
SONIA_NEW = '감사합니다. 아트라스 왕자.'

# Rando reference case: exact 34-byte/cell second line, intentionally no explicit
# break at '?'. This probe ensures R50 never regresses it.
RANDO_DLL = 'T_140.DLL'
RANDO_SEG = 3
RANDO_START = 0x0491
RANDO_QUESTION_END = 0x04B4  # byte immediately after '?'
RANDO_LINE = '또 이상한 녀석들 만나면 어쩔 거야?'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def segment(data: bytes, segno: int):
    segs = parse_segments(data)
    if not 1 <= segno <= len(segs):
        raise RuntimeError(f'segment {segno} 없음')
    return segs[segno - 1]


def atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_name(path.name + '.r50.tmp')
    tmp.write_bytes(data)
    os.replace(tmp, path)


def direct_slot_matches(data: bytes, text: str) -> bool:
    seg = segment(data, SONIA_SEG)
    enc = text.encode('cp949')
    if len(enc) > SONIA_EDITABLE:
        return False
    raw = data[seg.file_offset + SONIA_OFF:seg.file_offset + SONIA_OFF + SONIA_EDITABLE]
    return raw == enc + b'\xFF' * (SONIA_EDITABLE - len(enc))


def sonia_state(data: bytes) -> str:
    enc_new = SONIA_NEW.encode('cp949')
    if message_redirect_matches(data, SONIA_SEG, SONIA_OFF, SONIA_EDITABLE, enc_new, b''):
        return 'final'
    if direct_slot_matches(data, SONIA_OLD):
        return 'old_period'
    if direct_slot_matches(data, SONIA_OLD_ALT):
        return 'old_comma'
    return 'unknown'


def ensure_sonia_tail_room(data: bytes, needed: int) -> tuple[bytes, int]:
    """Reserve one local NE sector before V_300 segment 4 when R50 needs it.

    Fresh/R30-derived V_300 has segment-3 relocation data ending exactly at
    segment 4, so the normal tail allocator has zero alignment padding. Older
    official installs already contain the 512-byte local sector created by the
    chapter-title patch. Recreate the same verified geometry here *before* the
    Sonia redirect so fresh installs and direct upgrades converge.
    """
    layout = tail_layout(data, SONIA_SEG)
    if layout.available_padding >= needed:
        return data, 0
    segs = parse_segments(data)
    if len(segs) != 4 or segs[2].index != 3 or segs[3].index != 4:
        raise RuntimeError('V_300.DLL: segment 3 확장 구조가 예상과 다릅니다.')
    ne = struct.unpack_from('<I', data, 0x3C)[0]
    shift = struct.unpack_from('<H', data, ne + 0x32)[0]
    if shift != 9:
        raise RuntimeError(f'V_300.DLL: NE alignment shift가 예상과 다릅니다: {shift}')
    # Only the known unexpanded fresh/R30 layout may be grown here. Unknown
    # zero-padding layouts are rejected instead of being guessed.
    if len(data) != 32784 or segs[3].file_offset != 0x4000:
        raise RuntimeError(
            f'V_300.DLL: Sonia 확장 여유가 없고 알려진 fresh 구조도 아닙니다 '
            f'(size={len(data)}, seg4=0x{segs[3].file_offset:04X}, padding={layout.available_padding}).'
        )
    table = ne + struct.unpack_from('<H', data, ne + 0x22)[0]
    seg4_entry = table + 3 * 8
    old_sector = struct.unpack_from('<H', data, seg4_entry)[0]
    old_off = old_sector << shift
    if old_off != segs[3].file_offset:
        raise RuntimeError('V_300.DLL: segment 4 file offset 검증 실패')
    old4 = data[old_off:old_off + segs[3].length]
    out = bytearray(data)
    out[old_off:old_off] = b'\0' * (1 << shift)
    struct.pack_into('<H', out, seg4_entry, old_sector + 1)
    result = bytes(out)
    check = parse_segments(result)
    if check[3].file_offset != old_off + (1 << shift):
        raise RuntimeError('V_300.DLL: segment 4 이동 검증 실패')
    new4 = result[check[3].file_offset:check[3].file_offset + check[3].length]
    if new4 != old4:
        raise RuntimeError('V_300.DLL: segment 4 이동 중 내용이 변경되었습니다.')
    if tail_layout(result, SONIA_SEG).available_padding < needed:
        raise RuntimeError('V_300.DLL: segment 3 정렬 패딩 확보 실패')
    return result, 1 << shift


def rando_probe(root: Path) -> dict:
    p = root / 'SCENA' / RANDO_DLL
    if not p.is_file():
        return {'ok': False, 'reason': 'file_missing'}
    data = p.read_bytes(); seg = segment(data, RANDO_SEG)
    expected = RANDO_LINE.encode('cp949')
    start = seg.file_offset + RANDO_START
    # 0x0491 starts immediately after the existing explicit line break.
    raw = data[start:start + len(expected)]
    boundary = data[seg.file_offset + RANDO_QUESTION_END]
    return {
        'ok': raw == expected and len(expected) == 34 and boundary != 0x01,
        'line': RANDO_LINE,
        'encoded_cells': len(expected),
        'question_end_next_byte': f'{boundary:02X}',
        'explicit_break_after_question': boundary == 0x01,
    }


def inspect(root: Path) -> dict:
    scene = root / 'SCENA'
    if not scene.is_dir():
        raise RuntimeError('SCENA 폴더가 없습니다.')
    sites = []
    all_final = True
    for dll, segno, rel, old, new, note in CONTROL_PATCHES:
        p = scene / dll
        if not p.is_file():
            raise RuntimeError(f'{dll}: 파일 없음')
        data = p.read_bytes(); seg = segment(data, segno); pos = seg.file_offset + rel
        cur = data[pos]
        state = 'final' if cur == new else 'old' if cur == old else 'unknown'
        if state != 'final': all_final = False
        sites.append({'dll': dll, 'segment': segno, 'offset': f'0x{rel:04X}',
                      'state': state, 'current': f'{cur:02X}', 'old': f'{old:02X}',
                      'new': f'{new:02X}', 'note': note})
    vp = scene / SONIA_DLL
    if not vp.is_file(): raise RuntimeError(f'{SONIA_DLL}: 파일 없음')
    vs = sonia_state(vp.read_bytes())
    if vs != 'final': all_final = False
    rp = rando_probe(root)
    return {
        'version': VERSION,
        'control_sites': sites,
        'sonia': {'state': vs, 'text': SONIA_NEW, 'encoded_bytes': len(SONIA_NEW.encode('cp949')),
                  'original_slot_bytes': SONIA_EDITABLE},
        'rando_exact34_reference': rp,
        'ok': all_final and rp.get('ok', False),
    }


def apply(root: Path, backup: bool = True) -> dict:
    root = root.resolve(); scene = root / 'SCENA'
    if not scene.is_dir(): raise RuntimeError('SCENA 폴더가 없습니다.')
    changed_files = set(); changed_sites = []

    grouped = {}
    for item in CONTROL_PATCHES:
        grouped.setdefault(item[0], []).append(item)
    for dll, items in sorted(grouped.items()):
        p = scene / dll
        if not p.is_file(): raise RuntimeError(f'{dll}: 파일 없음')
        before = p.read_bytes(); data = bytearray(before)
        segs_before = tuple((s.index, s.file_offset, s.length, s.flags, s.min_alloc) for s in parse_segments(before))
        for _dll, segno, rel, old, new, note in items:
            seg = segment(bytes(data), segno); pos = seg.file_offset + rel; cur = data[pos]
            if cur == new:
                continue
            if cur != old:
                raise RuntimeError(f'{dll} seg{segno}:0x{rel:04X}: 예상 {old:02X}/{new:02X}, 현재 {cur:02X}')
            data[pos] = new
            changed_sites.append(f'{dll}:seg{segno}:0x{rel:04X}')
        after = bytes(data)
        if after != before:
            segs_after = tuple((s.index, s.file_offset, s.length, s.flags, s.min_alloc) for s in parse_segments(after))
            if len(after) != len(before) or segs_after != segs_before:
                raise RuntimeError(f'{dll}: 제어코드 패치가 파일 크기/NE geometry를 변경했습니다.')
            if backup:
                bak = p.with_suffix(p.suffix + '.r50.bak')
                if not bak.exists(): shutil.copy2(p, bak)
            atomic_write(p, after); changed_files.add(dll)

    # Sonia: exact PC-98 tone requires 26 bytes in a 25-byte legacy slot.
    # Use the established 0F split redirect allocator; no global offsets move.
    p = scene / SONIA_DLL
    before = p.read_bytes(); state = sonia_state(before)
    sonia_redirected = False; sonia_padding = 0; sonia_sector_growth = 0
    if state != 'final':
        if state not in {'old_period', 'old_comma'}:
            raise RuntimeError(f'{SONIA_DLL}: Sonia R49/R50 exact state가 아닙니다 ({state}).')
        original_before = before
        before, sonia_sector_growth = ensure_sonia_tail_room(before, 8)
        old_size = len(before)
        # relocation bytes are indirectly protected by patch_message_slot_0f;
        # the optional 512-byte sector growth moves segment 4 byte-identically.
        res = patch_message_slot_0f(before, SONIA_SEG, SONIA_OFF, SONIA_EDITABLE,
                                    SONIA_NEW.encode('cp949'), b'')
        after = res.data
        if len(after) != old_size or not message_redirect_matches(after, SONIA_SEG, SONIA_OFF,
                SONIA_EDITABLE, SONIA_NEW.encode('cp949'), b''):
            raise RuntimeError(f'{SONIA_DLL}: Sonia redirect 후검증 실패')
        if backup:
            bak = p.with_suffix(p.suffix + '.r50.bak')
            if not bak.exists(): shutil.copy2(p, bak)
        atomic_write(p, after); changed_files.add(SONIA_DLL)
        sonia_redirected = res.redirected; sonia_padding = res.consumed_padding
        changed_sites.append(f'{SONIA_DLL}:seg3:0x{SONIA_OFF:04X}')

    post = inspect(root)
    if not post['ok']:
        raise RuntimeError(f'R50 postcondition 실패: {post}')
    return {
        'version': VERSION,
        'changed_files': len(changed_files),
        'changed_file_names': sorted(changed_files),
        'changed_sites': len(changed_sites),
        'site_names': changed_sites,
        'sonia_redirected': sonia_redirected,
        'sonia_padding_consumed': sonia_padding,
        'sonia_alignment_sector_added': sonia_sector_growth,
        'rando_untouched_exact34': post['rando_exact34_reference'],
        'post': post,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=f'{APP} {VERSION}')
    ap.add_argument('root', type=Path)
    g = ap.add_mutually_exclusive_group(); g.add_argument('--check', action='store_true')
    ap.add_argument('--no-backup', action='store_true')
    args = ap.parse_args()
    try:
        if args.check:
            out = inspect(args.root.resolve()); print(json.dumps(out, ensure_ascii=False, indent=2)); return 0 if out['ok'] else 2
        out = apply(args.root.resolve(), backup=not args.no_backup)
        print(json.dumps(out, ensure_ascii=False, indent=2)); return 0
    except Exception as e:
        print(f'ERROR: {e}', file=sys.stderr); return 1

if __name__ == '__main__':
    raise SystemExit(main())
