.code16
.intel_syntax noprefix
.section .text

# Vertical wrap exceptions are limited to menus where wrap is undesirable:
# 4773 = inventory top menu
# 9AED = equipment-slot selector
# 9B46 = inventory item selector
# 9F00 = warp-wing town selector (SELECT_TOWN)
.global menu_wrap_helper
menu_wrap_helper:
    push bx
    mov bx, sp
    mov bx, word ptr ss:[bx+2]
    cmp bx, 0x4773
    je menu_vanilla
    cmp bx, 0x9aed
    je menu_vanilla
    cmp bx, 0x9b46
    je menu_vanilla
    cmp bx, 0x9f00
    je menu_vanilla
    pop bx

    # Guard empty lists: never manufacture index 0xFF when CL == 0.
    test cl, cl
    jz menu_no_direction
    test ah, 0x01
    jnz menu_wrap_up
    test ah, 0x02
    jz menu_no_direction
menu_wrap_down:
    inc al
    cmp al, cl
    jb menu_changed
    xor al, al
    jmp menu_changed
menu_wrap_up:
    dec al
    jns menu_changed
    mov al, cl
    dec al
menu_changed:
    jmp MENU_CHANGED
menu_no_direction:
    jmp MENU_NO_DIRECTION

menu_vanilla:
    pop bx
    # Original top/bottom stop behavior.
    test ah, 0x01
    jnz menu_vanilla_up
    test ah, 0x02
    jz menu_no_direction
    inc al
    cmp al, cl
    jb menu_changed
    jmp menu_no_direction
menu_vanilla_up:
    dec al
    js menu_no_direction
    jmp menu_changed

.org 0x60
.global menu_key_detect_helper
menu_key_detect_helper:
    # Menu-only repeat acceleration (20/4 ticks). INKEY$ itself remains vanilla 20/8, so
    # message waits and unrelated input users are untouched.
    # INKEY$ is a near routine (RET), so do not push CS here.
    call KEY_DETECT
    # Accelerate only while a direction key is held.  Confirm/cancel keep
    # vanilla repeat behavior, avoiding accidental carry-over into submenus.
    test byte ptr [0x40a7], 0x0f
    jz menu_key_done
    # Keep the vanilla first-repeat delay (20 ticks). The assignment is a
    # deliberate no-op so the helper layout stays migration-compatible.
    cmp byte ptr [0x3f40], 0x14
    jne menu_key_repeat_check
    mov byte ptr [0x3f40], 0x14
    jmp menu_key_done
menu_key_repeat_check:
    cmp byte ptr [0x3f40], 0x08
    jne menu_key_done
    mov byte ptr [0x3f40], 0x04
menu_key_done:
    ret

.org 0xc0
# v1.0.10: reserved message-indent extension used by chapter-end centering.
# Opcode 09 operands F0..FE set the horizontal message column to 0..14.
# FF and values below F0 fall through to the vanilla 09 handler.
.global message_indent_helper
message_indent_helper:
    lodsb
    cmp al, 0xf0
    jb message_indent_vanilla
    cmp al, 0xff
    je message_indent_vanilla
    and al, 0x0f
    mov ch, al
    mov word ptr [0x96de], cx
    retf
message_indent_vanilla:
    push cs
    call 0x86b0
    mov cx, word ptr [0x96de]
    retf

.org 0x100
# 0x0100..0x015F remains unused.

.org 0x160
.global battle_horizontal_mask_helper
battle_horizontal_mask_helper:
    cmp al, 0x02
    jae battle_mask_count_done
    inc cl
battle_mask_count_done:
    mov ch, 0x0c
    ret

.org 0x180
.global battle_horizontal_wrap_helper
battle_horizontal_wrap_helper:
    mov ah, al
    mov al, byte ptr [si+1]
    test ah, 0x04
    jnz battle_left
    test ah, 0x08
    jnz battle_right
    ret
battle_left:
    test al, al
    jnz battle_left_dec
    cmp byte ptr [si], 0x02
    jne battle_left_three
    mov al, 0x01
    ret
battle_left_three:
    mov al, 0x02
    ret
battle_left_dec:
    dec al
    ret
battle_right:
    cmp byte ptr [si], 0x02
    jne battle_right_three
    cmp al, 0x01
    jae battle_wrap_zero
    inc al
    ret
battle_right_three:
    cmp al, 0x02
    jae battle_wrap_zero
    inc al
    ret
battle_wrap_zero:
    xor al, al
    ret

.org 0x1c0
.global turbo_move_speed
turbo_move_speed:
    push ax
    mov ah, 0x02
    int 0x16
    test al, 0x03
    pop ax
    jz turbo_normal
    mov al, 1
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf
turbo_normal:
    mov al, byte ptr [0x2048]
    inc al
    add al, al
    add al, al
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf

.org 0x200
# v1.0.9: 0x0200..0x02FF intentionally unused.
# The old dialogue delay implementation is no longer installed.

.org 0x300
