.code16
.intel_syntax noprefix
.section .text

# Inventory selectors that must keep vanilla boundaries and key-repeat timing:
# 4773 = inventory top menu SELECT_MENU return
# 9AED = equipment-slot selector return
# 9B46 = inventory item selector return

.global menu_wrap_helper
menu_wrap_helper:
    push bx
    mov bx, sp
    mov bx, word ptr ss:[bx+2]
    cmp bx, 0x4773
    je menu_inventory
    cmp bx, 0x9aed
    je menu_inventory
    cmp bx, 0x9b46
    je menu_inventory
    pop bx

    # QoL behavior: wrap at the top/bottom boundary.
    test ah, 0x01
    jnz menu_wrap_up
    test ah, 0x02
    jz menu_no_direction
menu_wrap_down:
    inc al
    cmp al, cl
    jb menu_changed
    xor al, al
    jmp menu_changed
menu_wrap_up:
    dec al
    jns menu_changed
    mov al, cl
    dec al
menu_changed:
    jmp MENU_CHANGED
menu_no_direction:
    jmp MENU_NO_DIRECTION

menu_inventory:
    pop bx
    # Vanilla boundary behavior for inventory/equipment menus.
    test ah, 0x01
    jnz menu_inventory_up
    test ah, 0x02
    jz menu_no_direction
    inc al
    cmp al, cl
    jb menu_changed
    jmp menu_no_direction
menu_inventory_up:
    dec al
    js menu_no_direction
    jmp menu_changed

.org 0x60
.global menu_key_detect_helper
menu_key_detect_helper:
    # Called instead of SELECT_MENU's direct KEY_DETECT call.  The selector's
    # caller return IP is below our own return IP on the stack.
    push bx
    push dx
    mov bx, sp
    mov dx, word ptr ss:[bx+6]
    xor bx, bx
    cmp dx, 0x4773
    je menu_key_inventory
    cmp dx, 0x9aed
    je menu_key_inventory
    cmp dx, 0x9b46
    je menu_key_inventory
    jmp menu_key_call
menu_key_inventory:
    mov bl, 1
menu_key_call:
    push cs
    call KEY_DETECT
    test bl, bl
    jnz menu_key_done
    test al, al
    jz menu_key_done
    cmp byte ptr [0x3f40], 0x14
    jne menu_key_repeat_check
    mov byte ptr [0x3f40], 0x0f
    jmp menu_key_done
menu_key_repeat_check:
    cmp byte ptr [0x3f40], 0x08
    jne menu_key_done
    mov byte ptr [0x3f40], 0x04
menu_key_done:
    pop dx
    pop bx
    ret

.org 0xc0
.global dialogue_begin_helper
dialogue_begin_helper:
    mov byte ptr cs:[dialogue_skip_flag], 0
    xor ax, ax
    xchg word ptr [0x91a6], ax
    ret

.org 0xe0
.global dialogue_delay_check
dialogue_delay_check:
    # Preserve the renderer's AX. If delay is already zero, avoid polling.
    cmp byte ptr [0x3f42], 0
    je dialogue_delay_return
    push ax
    push cs
    call KEY_IN
    test al, 0x20
    jz dialogue_delay_no_skip
    mov byte ptr cs:[dialogue_skip_flag], 1
    mov byte ptr [0x3f42], 0
dialogue_delay_no_skip:
    pop ax
dialogue_delay_return:
    # Return the same ZF contract as the original CMP [3F42],0 instruction.
    cmp byte ptr [0x3f42], 0
    ret

.org 0x120
.global dialogue_end_helper
dialogue_end_helper:
    cmp byte ptr cs:[dialogue_skip_flag], 0
    je dialogue_end_restore
    # Do not let the same confirm press advance the next dialogue. Wait only
    # for the confirm bit to be released after the current text is complete.
dialogue_release_wait:
    push cs
    call KEY_IN
    test al, 0x20
    jnz dialogue_release_wait
    mov byte ptr cs:[dialogue_skip_flag], 0
dialogue_end_restore:
    mov ax, word ptr [bp-2]
    mov word ptr [0x91a6], ax
    ret

dialogue_skip_flag:
    .byte 0

.org 0x1c0
.global turbo_move_speed
turbo_move_speed:
    push ax
    mov ah, 0x02
    int 0x16
    test al, 0x03
    pop ax
    jz turbo_normal
    mov al, 1
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf
turbo_normal:
    mov al, byte ptr [0x2048]
    inc al
    add al, al
    add al, al
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf

.org 0x300
