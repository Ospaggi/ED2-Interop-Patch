.code16
.intel_syntax noprefix
.section .text

# Vertical wrap exceptions are limited to menus where wrap is undesirable:
# 4773 = inventory top menu
# 9AED = equipment-slot selector
# 9B46 = inventory item selector
# 9F00 = warp-wing town selector (SELECT_TOWN)
.global menu_wrap_helper
menu_wrap_helper:
    push bx
    mov bx, sp
    mov bx, word ptr ss:[bx+2]
    cmp bx, 0x4773
    je menu_vanilla
    cmp bx, 0x9aed
    je menu_vanilla
    cmp bx, 0x9b46
    je menu_vanilla
    cmp bx, 0x9f00
    je menu_vanilla
    pop bx

    # Guard empty lists: never manufacture index 0xFF when CL == 0.
    test cl, cl
    jz menu_no_direction
    test ah, 0x01
    jnz menu_wrap_up
    test ah, 0x02
    jz menu_no_direction
menu_wrap_down:
    inc al
    cmp al, cl
    jb menu_changed
    xor al, al
    jmp menu_changed
menu_wrap_up:
    dec al
    jns menu_changed
    mov al, cl
    dec al
menu_changed:
    jmp MENU_CHANGED
menu_no_direction:
    jmp MENU_NO_DIRECTION

menu_vanilla:
    pop bx
    # Original top/bottom stop behavior.
    test ah, 0x01
    jnz menu_vanilla_up
    test ah, 0x02
    jz menu_no_direction
    inc al
    cmp al, cl
    jb menu_changed
    jmp menu_no_direction
menu_vanilla_up:
    dec al
    js menu_no_direction
    jmp menu_changed

.org 0x60
.global menu_key_detect_helper
menu_key_detect_helper:
    # Menu-only repeat acceleration (20/4 ticks). INKEY$ itself remains vanilla 20/8, so
    # message waits and unrelated input users are untouched.
    # INKEY$ is a near routine (RET), so do not push CS here.
    call KEY_DETECT
    # Accelerate only while a direction key is held.  Confirm/cancel keep
    # vanilla repeat behavior, avoiding accidental carry-over into submenus.
    test byte ptr [0x40a7], 0x0f
    jz menu_key_done
    # Keep the vanilla first-repeat delay (20 ticks). The assignment is a
    # deliberate no-op so the helper layout stays migration-compatible.
    cmp byte ptr [0x3f40], 0x14
    jne menu_key_repeat_check
    mov byte ptr [0x3f40], 0x14
    jmp menu_key_done
menu_key_repeat_check:
    cmp byte ptr [0x3f40], 0x08
    jne menu_key_done
    mov byte ptr [0x3f40], 0x04
menu_key_done:
    ret

.org 0xc0
.global dialogue_begin_helper
dialogue_begin_helper:
    # State: 0 = armed, 1 = skip current message, 2 = confirm was already
    # held when this message started.  State 2 must see a release before a
    # fresh confirm can request instant completion.
    xor ax, ax
    xchg word ptr [0x91a6], ax
    push ax
    push cs
    call KEY_IN
    and al, 0x20
    shr al, 4                  # 0x20 -> 2, 0 -> 0
    mov byte ptr cs:[dialogue_skip_flag], al
    pop ax
    ret

.org 0xe0
.global dialogue_delay_check
dialogue_delay_check:
    # Keep the original hook address stable for v1.0.20 migration, and put
    # the expanded edge-trigger implementation in free cave space below.
    jmp dialogue_delay_impl

.org 0x120
.global dialogue_end_helper
dialogue_end_helper:
    # Only state 1 was a fresh skip press and needs a release guard.
    cmp byte ptr cs:[dialogue_skip_flag], 1
    jne dialogue_end_restore
 dialogue_release_wait:
    push cs
    call KEY_IN
    test al, 0x20
    jnz dialogue_release_wait
    mov byte ptr cs:[dialogue_skip_flag], 0
 dialogue_end_restore:
    mov ax, word ptr [bp-2]
    mov word ptr [0x91a6], ax
    ret

dialogue_skip_flag:
    .byte 0

# Battle command menu is the remaining common non-inventory 2-D menu whose
# horizontal edge keys are normally suppressed.  These two helpers expose
# both left/right edge keys and wrap inside the current row.  The bottom row
# has two valid columns, matching the original special-case layout.
.org 0x160
.global battle_horizontal_mask_helper
battle_horizontal_mask_helper:
    cmp al, 0x02
    jae battle_mask_count_done
    inc cl
battle_mask_count_done:
    mov ch, 0x0c
    ret

.org 0x180
.global battle_horizontal_wrap_helper
battle_horizontal_wrap_helper:
    mov ah, al
    mov al, byte ptr [si+1]
    test ah, 0x04
    jnz battle_left
    test ah, 0x08
    jnz battle_right
    ret
battle_left:
    test al, al
    jnz battle_left_dec
    cmp byte ptr [si], 0x02
    jne battle_left_three
    mov al, 0x01
    ret
battle_left_three:
    mov al, 0x02
    ret
battle_left_dec:
    dec al
    ret
battle_right:
    cmp byte ptr [si], 0x02
    jne battle_right_three
    cmp al, 0x01
    jae battle_wrap_zero
    inc al
    ret
battle_right_three:
    cmp al, 0x02
    jae battle_wrap_zero
    inc al
    ret
battle_wrap_zero:
    xor al, al
    ret

.org 0x1c0
.global turbo_move_speed
turbo_move_speed:
    push ax
    mov ah, 0x02
    int 0x16
    test al, 0x03
    pop ax
    jz turbo_normal
    mov al, 1
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf
turbo_normal:
    mov al, byte ptr [0x2048]
    inc al
    add al, al
    add al, al
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf

.org 0x200
.global dialogue_delay_impl
dialogue_delay_impl:
    cmp byte ptr cs:[dialogue_skip_flag], 1
    je dialogue_delay_skip
    cmp byte ptr cs:[dialogue_skip_flag], 2
    jne dialogue_delay_armed

    # Confirm was already held at renderer entry.  It cannot trigger skip
    # until it has been released once.
    push ax
    push cs
    call KEY_IN
    test al, 0x20
    jnz dialogue_delay_blocked_still_held
    mov byte ptr cs:[dialogue_skip_flag], 0
 dialogue_delay_blocked_still_held:
    pop ax
    cmp byte ptr [0x3f42], 0
    ret

 dialogue_delay_armed:
    cmp byte ptr [0x3f42], 0
    je dialogue_delay_real_zero
    push ax
    push cs
    call KEY_IN
    test al, 0x20
    jz dialogue_delay_no_skip
    mov byte ptr cs:[dialogue_skip_flag], 1
    pop ax
 dialogue_delay_skip:
    cmp byte ptr cs:[dialogue_skip_flag], 1  # ZF=1
    ret
 dialogue_delay_no_skip:
    pop ax
 dialogue_delay_real_zero:
    cmp byte ptr [0x3f42], 0
    ret

.org 0x300
