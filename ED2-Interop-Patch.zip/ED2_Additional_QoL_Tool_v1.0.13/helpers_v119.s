.code16
.intel_syntax noprefix
.section .text

.global menu_wrap_helper
menu_wrap_helper:
    test ah, 0x01
    jnz menu_up
    test ah, 0x02
    jz menu_no_direction
menu_down:
    inc al
    cmp al, cl
    jb menu_changed
    xor al, al
    jmp menu_changed
menu_up:
    dec al
    jns menu_changed
    mov al, cl
    dec al
menu_changed:
    jmp MENU_CHANGED
menu_no_direction:
    jmp MENU_NO_DIRECTION

.org 0x1c0
.global turbo_move_speed
turbo_move_speed:
    push ax
    mov ah, 0x02
    int 0x16
    test al, 0x03
    pop ax
    jz turbo_normal
    mov al, 1
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf
turbo_normal:
    mov al, byte ptr [0x2048]
    inc al
    add al, al
    add al, al
    mov byte ptr [0x3f41], al
    inc byte ptr [0x207c]
    retf

.org 0x300
