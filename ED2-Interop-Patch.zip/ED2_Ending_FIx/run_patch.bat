@echo off
cd /d "%~dp0"
py -3 ed2_combined_patch.py
if errorlevel 1 pause
