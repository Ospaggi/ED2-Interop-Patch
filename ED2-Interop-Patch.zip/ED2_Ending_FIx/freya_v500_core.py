#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile

APP = "ED2 Freya 4-Split Patch Only"
VERSION = "5.0.0"
TARGET = "ENDING.DLL"
BACKUP_SUFFIX = ".before_freya_v500.bak"
REPORT_NAME = "FREYA_4SPLIT_V500.json"

SEGMENT_NUMBER = 10
EXPECTED_SEGMENT_BASE = 0x3B000
EXPECTED_NEXT_SEGMENT_BASE = 0x3EC00
ORIGINAL_LENGTH = 0x3275
EXPECTED_RELOCATION_COUNT = 257
EXPECTED_RELOCATION_SHA256 = "ef739fdf0629d343e25c0c4b33510e031c57319baf5f682e27b9c3b2cd2e34d4"
RETAIL_SHA256 = "7410d98722380a66e2fc1251d4c5906df66096209d9dd1a1d84537f0d33e5b39"

# Helper linked at 0A:3275. It calls retail DISP_GRP4 first and then crops only
# the current, freshly rebuilt VGA access page. It never switches VGA pages,
# never calls INT 41h, and never runs from a timer/V-sync callback.
HELPER = base64.b64decode(
    "6PTSnGAeBjHA6BsABx9hncPo49KcYB4GNqG8NoPgA+gFAAcfYZ3Dg+ADicLR4NHgAdDR4NHgLqMMM7sCADaLBx6O2I7AugAPvQABidYuAzYMM4nXg8ceLoM+DDMUdQ+DxhODxxO5FAD986T86wa5FAD886QwwInXuR4A86qJ14PHMrkeAPOqg8JQTXW+H4PDAoP7CnWnwwAA"
)
HELPER_SHA256 = "a6b126883b4ce4659a448bf6c86c94555ff3ecb5e6e92aa81b545c59a22b5dde"
NEW_LENGTH = ORIGINAL_LENGTH + len(HELPER)

PANEL0_WRAPPER = 0x3275
CURRENT_WRAPPER = 0x3286

# Earlier Freya-only experiments are recognized only by exact helper hash.
# They are completely removed before the new helper is installed.
KNOWN_LAYOUTS: dict[int, tuple[str, str | None]] = {
    ORIGINAL_LENGTH: ("retail-layout", None),
    0x32EF: ("v4.0.x", "891358b549ffb6e6373debc6842871774133abe97ec8bb3fc4a9f841b7c9ba9a"),
    0x3301: ("v2.0.0", "d29b920d63732d9d190cb3cbbf880f5fac5edc7c24f164bb6791d12ccbb0dd22"),
    0x33B2: ("v4.1.0", "f4b3b715e2d989cd589da5bcc70339dd2fae51e8b9572c1e7cea5ebe4828e114"),
    0x3375: ("v4.1.1", "0629c5ca3835adc4cb47d1fce2be7daf1220d16e8a06159905604e0db5a0ef59"),
    NEW_LENGTH: ("v5.0.0", HELPER_SHA256),
}

# Restore all code sites touched by earlier Freya-only patches. The first item
# is the retail byte sequence; the tuple contains accepted previous forms.
RESTORE_SITES: dict[int, tuple[bytes, tuple[bytes, ...]]] = {
    0x154F: (bytes.fromhex("FF 16 08 0E"), (bytes.fromhex("E8 40 1D 90"),)),
    0x1E06: (bytes.fromhex("E8 14 F4"), (bytes.fromhex("E8 6C 14"),)),
    0x1F69: (bytes.fromhex("E8 B1 F2"), (bytes.fromhex("E8 09 13"),)),
    0x1F7B: (bytes.fromhex("27 13"), (bytes.fromhex("92 32"),)),
    0x1F8C: (bytes.fromhex("E8 DD E5"), (bytes.fromhex("E8 EF 12"),)),
    0x1FCD: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 A5 12 90"),)),
    0x1FD9: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 99 12 90"),)),
    0x1FDD: (
        bytes.fromhex("FA CD 41 FB"),
        (bytes.fromhex("E8 A5 12 90"), bytes.fromhex("E8 AA 12 90")),
    ),
    0x1FF5: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 98 12 90"),)),
    0x200D: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 80 12 90"),)),
    0x203E: (bytes.fromhex("E8 2B E5"), (bytes.fromhex("E8 3D 12"),)),
    0x205C: (bytes.fromhex("52 13"), (bytes.fromhex("92 32"),)),
    0x2073: (bytes.fromhex("E8 F6 E4"), (bytes.fromhex("E8 08 12"),)),
    0x208D: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 00 12 90"),)),
    0x20AC: (bytes.fromhex("7D 13"), (bytes.fromhex("A0 32"),)),
    0x20C9: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 C4 11 90"),)),
    0x2110: (bytes.fromhex("FA CD 41 FB"), (bytes.fromhex("E8 62 11 90"),)),
    0x2118: (
        bytes.fromhex("FA CD 41 FB"),
        (
            bytes.fromhex("E8 85 0F 90"),
            bytes.fromhex("E8 6A 11 90"),
            bytes.fromhex("E8 6F 11 90"),
        ),
    ),
}

# The only four calls modified by v5. All call retail DISP_GRP4 through the
# helper. The first machine/laboratory composition must display panel 0; the
# remaining three use the retail current panel in DS:36BC.
PATCH_SITES: dict[int, tuple[bytes, int, str]] = {
    0x1D3B: (bytes.fromhex("E8 2E E8"), PANEL0_WRAPPER, "center_initial_machine_panel_0"),
    0x1F8C: (bytes.fromhex("E8 DD E5"), CURRENT_WRAPPER, "center_freya_stage_current_panel"),
    0x203E: (bytes.fromhex("E8 2B E5"), CURRENT_WRAPPER, "center_freya_stage_current_panel"),
    0x2073: (bytes.fromhex("E8 F6 E4"), CURRENT_WRAPPER, "center_freya_stage_current_panel"),
}


class PatchError(Exception):
    pass


def u16(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write(path: Path, data: bytes) -> None:
    fd, temp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    except Exception:
        try:
            os.unlink(temp)
        except OSError:
            pass
        raise


def resolve(path: Path) -> Path:
    path = path.expanduser().resolve()
    if path.is_dir():
        path = path / TARGET
    if not path.is_file() or path.name.upper() != TARGET:
        raise PatchError("ENDING.DLL 또는 ENDING.DLL이 있는 게임 폴더를 선택하십시오.")
    return path


def parse_ne(data: bytes | bytearray) -> list[dict[str, int]]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("MZ 실행 파일이 아닙니다.")
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise PatchError("NE DLL이 아닙니다.")
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    segments: list[dict[str, int]] = []
    for index in range(count):
        entry = table + index * 8
        sector, raw_length, flags, raw_minimum = struct.unpack_from("<HHHH", data, entry)
        segments.append({
            "entry": entry,
            "base": sector << shift,
            "length": raw_length or 0x10000,
            "minimum": raw_minimum or 0x10000,
            "flags": flags,
        })
    return segments


def relocation_blob(data: bytes | bytearray, segment: dict[str, int]) -> bytes:
    if not (segment["flags"] & 0x0100):
        raise PatchError("세그먼트 10의 재배치 테이블을 찾지 못했습니다.")
    start = segment["base"] + segment["length"]
    if start + 2 > len(data):
        raise PatchError("재배치 테이블이 잘렸습니다.")
    count = u16(data, start)
    end = start + 2 + count * 8
    if end > len(data):
        raise PatchError("재배치 테이블이 파일 범위를 벗어납니다.")
    blob = bytes(data[start:end])
    if count != EXPECTED_RELOCATION_COUNT:
        raise PatchError(f"예상하지 못한 재배치 레코드 수입니다: {count}")
    if sha256(blob) != EXPECTED_RELOCATION_SHA256:
        raise PatchError("세그먼트 10 재배치 테이블이 알려진 한국어판과 다릅니다.")
    return blob


def identify_layout(data: bytes | bytearray, segment: dict[str, int]) -> str:
    length = segment["length"]
    spec = KNOWN_LAYOUTS.get(length)
    if spec is None:
        raise PatchError(f"지원되지 않는 세그먼트 10 길이입니다: 0x{length:X}")
    name, expected_hash = spec
    if expected_hash is None:
        return name
    helper = bytes(data[segment["base"] + ORIGINAL_LENGTH:segment["base"] + length])
    actual_hash = sha256(helper)
    if actual_hash != expected_hash:
        raise PatchError(
            f"세그먼트 10의 0x{length:X} 추가 코드가 알려진 패치와 다릅니다."
        )
    return name


def normalize_old_sites(data: bytearray, base: int) -> list[dict[str, str]]:
    changed: list[dict[str, str]] = []
    for offset, (retail, old_forms) in RESTORE_SITES.items():
        pos = base + offset
        current = bytes(data[pos:pos + len(retail)])
        if current == retail:
            continue
        if current not in old_forms:
            raise PatchError(
                f"0A:{offset:04X}의 명령 패턴이 지원 범위와 다릅니다: "
                f"{current.hex(' ').upper()}"
            )
        data[pos:pos + len(retail)] = retail
        changed.append({"segment_offset": f"0x{offset:04X}", "action": "restore_retail_site"})
    return changed


def rebuild_segment_with_helper(data: bytearray, segments: list[dict[str, int]]) -> None:
    segment = segments[SEGMENT_NUMBER - 1]
    next_segment = segments[SEGMENT_NUMBER]["base"]
    if segment["base"] != EXPECTED_SEGMENT_BASE:
        raise PatchError("ENDING.DLL 세그먼트 10의 위치가 예상과 다릅니다.")
    if next_segment != EXPECTED_NEXT_SEGMENT_BASE:
        raise PatchError("ENDING.DLL 세그먼트 11의 위치가 예상과 다릅니다.")

    blob = relocation_blob(data, segment)
    new_reloc = segment["base"] + NEW_LENGTH
    if new_reloc + len(blob) > next_segment:
        raise PatchError("새 도우미와 재배치 테이블이 다음 세그먼트와 겹칩니다.")

    start = segment["base"] + ORIGINAL_LENGTH
    data[start:next_segment] = b"\0" * (next_segment - start)
    data[start:start + len(HELPER)] = HELPER
    data[new_reloc:new_reloc + len(blob)] = blob
    struct.pack_into("<H", data, segment["entry"] + 2, NEW_LENGTH)
    struct.pack_into("<H", data, segment["entry"] + 6, NEW_LENGTH)


def near_call(site: int, target: int) -> bytes:
    relative = (target - (site + 3)) & 0xFFFF
    return b"\xE8" + struct.pack("<H", relative)


def apply_new_sites(data: bytearray, base: int) -> list[dict[str, str]]:
    changed: list[dict[str, str]] = []
    for offset, (retail, target, action) in PATCH_SITES.items():
        desired = near_call(offset, target)
        pos = base + offset
        current = bytes(data[pos:pos + 3])
        if current == desired:
            continue
        if current != retail:
            raise PatchError(
                f"0A:{offset:04X}의 DISP_GRP4 호출이 예상과 다릅니다: "
                f"{current.hex(' ').upper()}"
            )
        data[pos:pos + 3] = desired
        changed.append({"segment_offset": f"0x{offset:04X}", "action": action})
    return changed


def synthetic_crop(panel: int) -> bool:
    # Unique bytes per panel let this test detect overlap corruption and verify
    # that exactly one 20-byte panel remains at bytes 30..49.
    row = bytearray()
    for index in range(4):
        row.extend(bytes([0x20 + index]) * 20)
    source = bytes(row[panel * 20:panel * 20 + 20])
    row[30:50] = source
    row[0:30] = b"\0" * 30
    row[50:80] = b"\0" * 30
    return (
        row[:30] == b"\0" * 30
        and row[30:50] == bytes([0x20 + panel]) * 20
        and row[50:] == b"\0" * 30
    )


def validate_result(data: bytes, reference_tail: bytes | None = None) -> None:
    segments = parse_ne(data)
    if len(segments) <= SEGMENT_NUMBER:
        raise PatchError("패치 후 NE 세그먼트 수가 부족합니다.")
    segment = segments[SEGMENT_NUMBER - 1]
    base = segment["base"]
    if base != EXPECTED_SEGMENT_BASE:
        raise PatchError("패치 후 세그먼트 10 위치 검증에 실패했습니다.")
    if segment["length"] != NEW_LENGTH or segment["minimum"] != NEW_LENGTH:
        raise PatchError("패치 후 세그먼트 10 길이 검증에 실패했습니다.")
    installed = data[base + ORIGINAL_LENGTH:base + NEW_LENGTH]
    if installed != HELPER or sha256(installed) != HELPER_SHA256:
        raise PatchError("v5 fresh-page 도우미 검증에 실패했습니다.")
    relocation_blob(data, segment)

    for offset, (_, target, _) in PATCH_SITES.items():
        expected = near_call(offset, target)
        if data[base + offset:base + offset + 3] != expected:
            raise PatchError(f"0A:{offset:04X} 저장 검증에 실패했습니다.")

    # No previous INT 41h hooks, timer-dispatch hook, or callback replacement
    # may remain. These guards are deliberately independent of the helper.
    retail_guards = {
        0x154F: bytes.fromhex("FF 16 08 0E"),
        0x1327: bytes.fromhex("FE 0E 0D 0E"),
        0x1352: bytes.fromhex("FE 0E 0D 0E"),
        0x137D: bytes.fromhex("FE 0E 0D 0E"),
        0x1E06: bytes.fromhex("E8 14 F4"),
        0x1F69: bytes.fromhex("E8 B1 F2"),
        0x1F7B: bytes.fromhex("27 13"),
        0x1FCD: bytes.fromhex("FA CD 41 FB"),
        0x1FD9: bytes.fromhex("FA CD 41 FB"),
        0x1FDD: bytes.fromhex("FA CD 41 FB"),
        0x1FF5: bytes.fromhex("FA CD 41 FB"),
        0x200D: bytes.fromhex("FA CD 41 FB"),
        0x205C: bytes.fromhex("52 13"),
        0x208D: bytes.fromhex("FA CD 41 FB"),
        0x20AC: bytes.fromhex("7D 13"),
        0x20C9: bytes.fromhex("FA CD 41 FB"),
        0x2110: bytes.fromhex("FA CD 41 FB"),
        0x2118: bytes.fromhex("FA CD 41 FB"),
    }
    for offset, expected in retail_guards.items():
        if data[base + offset:base + offset + len(expected)] != expected:
            raise PatchError(f"순정 흐름 보존 검증 실패: 0A:{offset:04X}")

    if b"\xCD\x41" in HELPER:
        raise PatchError("도우미 안에 금지된 INT 41h 호출이 있습니다.")
    if not all(synthetic_crop(panel) for panel in range(4)):
        raise PatchError("4개 패널 중앙 배치 에뮬레이션에 실패했습니다.")
    if reference_tail is not None and data[EXPECTED_NEXT_SEGMENT_BASE:] != reference_tail:
        raise PatchError("세그먼트 11 이후 보존 검증에 실패했습니다.")


def apply_patch(path: Path) -> dict[str, object]:
    target = resolve(path)
    original = target.read_bytes()
    data = bytearray(original)
    segments = parse_ne(data)
    if len(segments) <= SEGMENT_NUMBER:
        raise PatchError("ENDING.DLL의 NE 세그먼트 수가 부족합니다.")
    segment = segments[SEGMENT_NUMBER - 1]
    if segment["base"] != EXPECTED_SEGMENT_BASE:
        raise PatchError("지원되는 한국어판 ENDING.DLL 레이아웃이 아닙니다.")

    state_before = identify_layout(data, segment)
    reference_tail = original[EXPECTED_NEXT_SEGMENT_BASE:]

    if state_before == "v5.0.0":
        validate_result(original, reference_tail)
        report = {
            "tool": APP,
            "version": VERSION,
            "status": "already_patched",
            "target": str(target),
            "backup": None,
            "state_before": state_before,
            "changed": [],
            "scope": {
                "initial_machine": "panel 0 centered after fresh DISP_GRP4 copy",
                "freya_stages": "current panel centered after each fresh DISP_GRP4 copy",
                "timer_dispatcher": "retail",
                "timer_callbacks": "retail",
                "int41_sites": "retail",
                "vga_page_switching_added": False,
                "other_files_modified": False,
            },
        }
        (target.parent / REPORT_NAME).write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return report

    changed = normalize_old_sites(data, segment["base"])
    segments = parse_ne(data)
    rebuild_segment_with_helper(data, segments)
    changed.append({
        "segment_offset": f"0x{ORIGINAL_LENGTH:04X}-0x{NEW_LENGTH - 1:04X}",
        "action": "install_fresh_current_page_only_helper",
    })

    segments = parse_ne(data)
    changed.extend(apply_new_sites(data, segments[SEGMENT_NUMBER - 1]["base"]))

    patched = bytes(data)
    validate_result(patched, reference_tail)

    if patched == original:
        status = "already_patched"
        backup = None
    else:
        backup_path = target.with_name(target.name + BACKUP_SUFFIX)
        if not backup_path.exists():
            shutil.copy2(target, backup_path)
        atomic_write(target, patched)
        if target.read_bytes() != patched:
            atomic_write(target, original)
            raise PatchError("저장 후 검증에 실패해 원래 파일로 되돌렸습니다.")
        status = "patched"
        backup = str(backup_path)

    report = {
        "tool": APP,
        "version": VERSION,
        "status": status,
        "target": str(target),
        "backup": backup,
        "state_before": state_before,
        "input_sha256": sha256(original),
        "output_sha256": sha256(patched),
        "retail_sha256_reference": RETAIL_SHA256,
        "changed": changed,
        "scope": {
            "initial_machine": "panel 0 centered after fresh DISP_GRP4 copy",
            "freya_stages": "current panel centered after each fresh DISP_GRP4 copy",
            "timer_dispatcher": "retail",
            "timer_callbacks": "retail",
            "int41_sites": "retail",
            "vga_page_switching_added": False,
            "source_buffers_modified": False,
            "other_files_modified": False,
        },
    }
    (target.parent / REPORT_NAME).write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return report


def gui() -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox

    root = tk.Tk()
    root.withdraw()
    try:
        folder = filedialog.askdirectory(title="ED2 게임 폴더 선택")
        if not folder:
            return 0
        if not messagebox.askyesno(
            APP + " v" + VERSION,
            "프레이아 장면의 4분할 화면만 수정할까요?\n\n"
            "처음 기계가 나타날 때부터 한 장만 가운데 표시합니다.\n"
            "이전 패치의 INT 41h/타이머 후크는 제거하고 순정 흐름으로 복구합니다.\n"
            "ENDING.DLL 이외의 파일은 수정하지 않습니다.",
        ):
            return 0
        report = apply_patch(Path(folder))
        if report["status"] == "already_patched":
            messagebox.showinfo(APP, "이미 v5.0.0 fresh-page 수정이 적용되어 있습니다.")
        else:
            messagebox.showinfo(
                APP,
                "패치를 적용했습니다.\n\n"
                "기계 최초 등장: 가운데 한 장\n"
                "프레이아 등장 단계: 가운데 한 장\n"
                "타이머/INT 41h/화면 페이지 전환: 순정 유지\n\n"
                f"백업: {report['backup']}",
            )
        return 0
    except Exception as exc:
        messagebox.showerror(APP, str(exc))
        return 1
    finally:
        root.destroy()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=APP)
    parser.add_argument("path", nargs="?", help="게임 폴더 또는 ENDING.DLL")
    args = parser.parse_args(argv)
    if args.path is None:
        return gui()
    try:
        print(json.dumps(apply_patch(Path(args.path)), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
