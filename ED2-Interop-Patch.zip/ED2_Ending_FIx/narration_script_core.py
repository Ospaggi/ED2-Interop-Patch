#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile

APP = "ED2 Narration Script Add-on"
VERSION = "1.0.17"
TARGET = "ENDING.DLL"
BACKUP_SUFFIX = ".before_narration_script_v117.bak"
REPORT_NAME = "ENDING_NARRATION_SCRIPT_V117.json"

SEG10_NUMBER = 10
SEG11_NUMBER = 11
SEG10_BASE = 0x3B000
SEG11_BASE = 0x3EC00
RETAIL_SEG10_LENGTH = 0x3275
V500_SEG10_LENGTH = 0x330E
TIMED_SEG10_LENGTH = 0x332E
BROKEN_NARRATION_SEG10_LENGTH = 0x3321
NEXT_SEGMENT_BASE = 0x42400
RELOCATION_COUNT = 257
RETAIL_RELOCATION_SHA256 = "ef739fdf0629d343e25c0c4b33510e031c57319baf5f682e27b9c3b2cd2e34d4"
RETAIL_ENDING_SHA256 = "7410d98722380a66e2fc1251d4c5906df66096209d9dd1a1d84537f0d33e5b39"
V500_ENDING_SHA256 = "8584e8fc27eef923dcffec4d1d357424a54cd4722c04e1e9b9aead7f273973ce"
TARGET_CLEAN_SHA256 = "e13003b026c5f64d674a4d3a83d1be29976ab631d842c415a8eb347060af413a"

# Exact failed narration experiments that may be safely normalized back to v5.0.0.
KNOWN_BROKEN_SHA256 = {
    "b8883bfbc4bbb0bef0008f5f41681a6bd37941bb35b68c0a123d903632d261b1": "v5.0.1 PC-98 flow experiment",
    "586694bd562b6af36608a040d43585c04638cbc1daa19e3945a0edec23fab303": "v5.0.2 DOS-safe experiment",
    "42c06960e7a90c41810d142c26576a45dd4f79f82e94811fc2eb52cc9f81fbf7": "v5.0.3 direct-render experiment",
}

# Stable v5.0.0 helper; retained byte-for-byte.
FREYA_HELPER = base64.b64decode(
    "6PTSnGAeBjHA6BsABx9hncPo49KcYB4GNqG8NoPgA+gFAAcfYZ3Dg+ADicLR4NHgAdDR4NHgLqMMM7sCADaLBx6O2I7AugAPvQABidYuAzYMM4nXg8ceLoM+DDMUdQ+DxhODxxO5FAD986T86wa5FAD886QwwInXuR4A86qJ14PHMrkeAPOqg8JQTXW+H4PDAoP7CnWnwwAA"
)
FREYA_HELPER_SHA256 = "a6b126883b4ce4659a448bf6c86c94555ff3ecb5e6e92aa81b545c59a22b5dde"
assert len(FREYA_HELPER) == V500_SEG10_LENGTH - RETAIL_SEG10_LENGTH

# Final-scene message timing extension.  The wait primitive at 0A:155D
# writes AL to SS:0E0C; the timer ISR at 0A:151C decrements that byte once
# per RTC periodic interrupt.  ENDING.DLL initializes the RTC in segment 04:
# 04:135E passes rate selector 0Ah to 04:16CA, which writes register A with
# low nibble 0Ah.  RS=0Ah is 64 Hz (32768 / 2^(10-1)).
ENDING_TICK_HZ = 64
JOSHUA_EXTRA_TICKS = 16       # 0.250 s: Joshua screen -> color-transition gap
NARRATION_HOLD_TICKS = 64     # 1.000 s: final narration hold; v1.6.5 transfer reversed
LEGACY_JOSHUA_EXTRA_TICKS = 192
LEGACY_NARRATION_HOLD_TICKS = 255
OLD_V155_JOSHUA_TICKS = 45
OLD_V155_NARRATION_TICKS = 60
OLD_V156_JOSHUA_TICKS = 48
OLD_V156_NARRATION_TICKS = 64
OLD_V157_JOSHUA_TICKS = 48
OLD_V157_NARRATION_TICKS = 32
OLD_V158_JOSHUA_TICKS = 32
OLD_V158_NARRATION_TICKS = 64
OLD_V159_JOSHUA_TICKS = 16
OLD_V159_NARRATION_TICKS = 64
OLD_V164_JOSHUA_TICKS = 16
OLD_V164_NARRATION_TICKS = 192
TIMING_DISPATCH_SITE = 0x0604
TIMING_DISPATCH_ORIGINAL = bytes.fromhex("3C 09 74 6E 90 90 90")
TIMING_HELPER_OFFSET = V500_SEG10_LENGTH


def _near_jump(site: int, target: int) -> bytes:
    return b"\xE9" + struct.pack("<H", (target - (site + 3)) & 0xFFFF)


def _near_call(site: int, target: int) -> bytes:
    return b"\xE8" + struct.pack("<H", (target - (site + 3)) & 0xFFFF)


def build_timing_helper(joshua_ticks: int, narration_ticks: int) -> bytes:
    # 330E: dispatch controls 06/07/09, then return to retail handling at 060B.
    helper = bytearray()
    helper += bytes.fromhex("3C 06 74 0B")
    helper += bytes.fromhex("3C 07 74 0F")
    helper += bytes.fromhex("3C 09 74 11")
    helper += _near_jump(TIMING_HELPER_OFFSET + len(helper), 0x060B)
    # control 06: extra hold, then continue parsing at 05D9.
    helper += bytes((0xB0, joshua_ticks))
    helper += _near_call(TIMING_HELPER_OFFSET + len(helper), 0x155D)
    helper += _near_jump(TIMING_HELPER_OFFSET + len(helper), 0x05D9)
    # control 07: hold final narration, then return exactly like control 09.
    helper += bytes((0xB0, narration_ticks))
    helper += _near_call(TIMING_HELPER_OFFSET + len(helper), 0x155D)
    helper += b"\xC3"
    # original control 09.
    helper += _near_jump(TIMING_HELPER_OFFSET + len(helper), 0x0676)
    if len(helper) != TIMED_SEG10_LENGTH - V500_SEG10_LENGTH:
        raise RuntimeError(f"timing helper length mismatch: {len(helper)}")
    return bytes(helper)


# v1.5.2/v1.5.3/v1.5.4 used the same helper layout but were built under the
# incorrect 256-Hz assumption.  Keep the exact legacy bytes so those versions
# can be upgraded in-place without guessing.
LEGACY_TIMING_HELPER = build_timing_helper(LEGACY_JOSHUA_EXTRA_TICKS, LEGACY_NARRATION_HOLD_TICKS)
LEGACY_TIMING_HELPER_SHA256 = hashlib.sha256(LEGACY_TIMING_HELPER).hexdigest()
OLD_V155_TIMING_HELPER = build_timing_helper(OLD_V155_JOSHUA_TICKS, OLD_V155_NARRATION_TICKS)
OLD_V155_TIMING_HELPER_SHA256 = hashlib.sha256(OLD_V155_TIMING_HELPER).hexdigest()
OLD_V156_TIMING_HELPER = build_timing_helper(OLD_V156_JOSHUA_TICKS, OLD_V156_NARRATION_TICKS)
OLD_V156_TIMING_HELPER_SHA256 = hashlib.sha256(OLD_V156_TIMING_HELPER).hexdigest()
OLD_V157_TIMING_HELPER = build_timing_helper(OLD_V157_JOSHUA_TICKS, OLD_V157_NARRATION_TICKS)
OLD_V157_TIMING_HELPER_SHA256 = hashlib.sha256(OLD_V157_TIMING_HELPER).hexdigest()
OLD_V158_TIMING_HELPER = build_timing_helper(OLD_V158_JOSHUA_TICKS, OLD_V158_NARRATION_TICKS)
OLD_V158_TIMING_HELPER_SHA256 = hashlib.sha256(OLD_V158_TIMING_HELPER).hexdigest()
OLD_V159_TIMING_HELPER = build_timing_helper(OLD_V159_JOSHUA_TICKS, OLD_V159_NARRATION_TICKS)
OLD_V159_TIMING_HELPER_SHA256 = hashlib.sha256(OLD_V159_TIMING_HELPER).hexdigest()
OLD_V164_TIMING_HELPER = build_timing_helper(OLD_V164_JOSHUA_TICKS, OLD_V164_NARRATION_TICKS)
OLD_V164_TIMING_HELPER_SHA256 = hashlib.sha256(OLD_V164_TIMING_HELPER).hexdigest()
TIMING_HELPER = build_timing_helper(JOSHUA_EXTRA_TICKS, NARRATION_HOLD_TICKS)
TIMING_HELPER_SHA256 = hashlib.sha256(TIMING_HELPER).hexdigest()
TIMING_DISPATCH_PATCH = _near_jump(TIMING_DISPATCH_SITE, TIMING_HELPER_OFFSET) + b"\x90" * 4

PANEL0_WRAPPER = 0x3275
CURRENT_WRAPPER = 0x3286
FREYA_PATCH_SITES: dict[int, tuple[bytes, int]] = {
    0x1D3B: (bytes.fromhex("E8 2E E8"), PANEL0_WRAPPER),
    0x1F8C: (bytes.fromhex("E8 DD E5"), CURRENT_WRAPPER),
    0x203E: (bytes.fromhex("E8 2B E5"), CURRENT_WRAPPER),
    0x2073: (bytes.fromhex("E8 F6 E4"), CURRENT_WRAPPER),
}

# v1.6.0 scene polish.
#
# The retail palette interpolation remains 3 ticks per level.  The narration
# ending wait (private control 07) is 192 ticks = 3.000 s.  v1.6.3 used
# 64 ticks = 1.000 s. v1.6.5 reverses v1.6.4's 128-tick transfer from the
# post-prayer montage into this final narration hold.  The Joshua-screen
# pause immediately before the palette transition (private control 06) remains
# 16 ticks = 0.250 s.
# The fully-colored Joshua/Iserhasa frame still holds for 192 ticks = 3.000 s.
#
# Freya: do not stop the animation callback for the whole final beat.  Instead,
# temporarily replace DS:0E08 with the proven idle callback 0A:1589 only while
# each fresh four-panel page is loaded and cropped.  Restore the original
# callback immediately afterward.  This closes the tiny raw-four-panel exposure
# window while preserving the intended blinking animation between rebuilds.
# The final 0A:2118 CLI/INT41/STI stays retail; retail itself shuts the callback
# down later at 0A:213E.
#
# Finally, the helper at 0A:2938 explicitly calls the native palette fade-out
# routine 0A:02C9 after the 3-second full-color hold and before reproducing the
# original CLI / AX=SS return prefix.

# Exact v1.5.4 layout, recognized only so it can be normalized.
OLD_V154_SEG10_LENGTH = 0x3353
OLD_V154_FREYA_SAFE_WRAPPER_OFFSET = 0x332E
OLD_V154_FINAL_HOLD_HELPER_OFFSET = 0x3340
OLD_V154_FREYA_SAFE_WRAPPER = bytes.fromhex(
    "FF 36 08 0E C7 06 08 0E 89 15 E8 4B FF 8F 06 08 0E C3"
)
OLD_V154_FINAL_HOLD_HELPER = bytes.fromhex(
    "B0 FF E8 18 E2 B0 FF E8 13 E2 B0 FF E8 0E E2 FA 8C D0 C3"
)
OLD_V154_FREYA_SITE = 0x1F8C
OLD_V154_PALETTE_FAST = bytes.fromhex("C6 06 0C 0E 01")

# Exact broken v1.5.5 layout, accepted so an already patched folder can be
# repaired directly.
OLD_V155_SEG10_LENGTH = 0x334E
OLD_V155_RECROP_OFFSET = 0x332E
OLD_V155_HOLD_OFFSET = 0x3345
OLD_V155_RECROP = bytes.fromhex(
    "FA CD 41 9C 60 1E 06 36 A1 BC 36 83 E0 03 E8 5D FF 07 1F 61 9D FB C3"
)
OLD_V155_HOLD = bytes.fromhex("B0 B4 E8 13 E2 FA 8C D0 C3")
OLD_V155_END_CALL = bytes.fromhex("E8 13 12 90")
OLD_V155_HOLD_CALL = bytes.fromhex("E8 0A 0A")

# Exact v1.5.6 layout, recognized so it can be normalized and upgraded.
OLD_V156_SEG10_LENGTH = 0x3342
OLD_V156_END_GUARD_OFFSET = 0x332E
OLD_V156_FINAL_HOLD_OFFSET = 0x3339
OLD_V156_END_GUARD = bytes.fromhex("C7 06 08 0E 89 15 FA CD 41 FB C3")
OLD_V156_FINAL_HOLD = bytes.fromhex("B0 C0 E8 1F E2 FA 8C D0 C3")
OLD_V156_END_CALL = _near_call(0x2118, OLD_V156_END_GUARD_OFFSET) + b"\x90"
OLD_V156_HOLD_CALL = _near_call(0x2938, OLD_V156_FINAL_HOLD_OFFSET)

FREYA_END_TRANSIENT_SITE = 0x2118
FREYA_END_TRANSIENT_ORIGINAL = bytes.fromhex("FA CD 41 FB")

# Guard all three *fresh* Freya current-panel rebuilds.  The initial panel-0
# composition at 0A:1D3B stays the v5.0.0 direct wrapper.
FREYA_CURRENT_SITES = (0x1F8C, 0x203E, 0x2073)
FREYA_SAFE_WRAPPER_OFFSET = TIMED_SEG10_LENGTH

def build_freya_safe_wrapper() -> bytes:
    helper = bytearray()
    helper += bytes.fromhex("FF 36 08 0E")             # push word ptr [0E08]
    helper += bytes.fromhex("C7 06 08 0E 89 15")       # mov  word ptr [0E08],1589h
    helper += _near_call(FREYA_SAFE_WRAPPER_OFFSET + len(helper), CURRENT_WRAPPER)
    helper += bytes.fromhex("8F 06 08 0E")             # pop  word ptr [0E08]
    helper += b"\xC3"
    return bytes(helper)

FREYA_SAFE_WRAPPER = build_freya_safe_wrapper()
FREYA_SAFE_WRAPPER_SHA256 = hashlib.sha256(FREYA_SAFE_WRAPPER).hexdigest()

# Post-prayer montage retime (v1.6.5, built from the v1.6.0 scene code).
#
# The absolute wait routine at 0A:0108 compares AX against 0000:0B88.  That
# counter is incremented by the RTC periodic ISR at 04:1677.  ENDING.DLL's RTC
# init path 04:135E pushes rate selector 0Ah and its relocated far call targets
# 04:16CA; 04:16CA writes low nibble 0Ah to RTC register A through 04:1499.
# RS=0Ah is 64 Hz.
#
# v1.6.3 added 525 ticks = 8.203125 s across five intervals after the prayer.
# v1.6.5 keeps the combined added time unchanged but transfers exactly
# 128 ticks = 2.000 s from those montage intervals to the final narration hold.
# The five montage additions therefore become 79,79,79,80,80 ticks, totaling
# 397 ticks = 8.203125 s.  The final narration hold grows from 64 to 192 ticks
# (1.000 -> 3.000 s).  397 + 192 = 589 ticks, exactly equal to the old
# 525 + 64 = 589 ticks, so this redistribution adds no net ending duration.
ENDING_ABS_TIMELINE_HZ = 64
OLD_V163_POST_PRAYER_EXTRA_TICKS = 525
POST_PRAYER_TRANSFER_TO_NARRATION_TICKS = 0
POST_PRAYER_EXTRA_TICKS = OLD_V163_POST_PRAYER_EXTRA_TICKS
POST_PRAYER_EXTRA_SECONDS = POST_PRAYER_EXTRA_TICKS / ENDING_ABS_TIMELINE_HZ
POST_PRAYER_INTERVAL_ADDITIONS = (105, 105, 105, 105, 105)
assert sum(POST_PRAYER_INTERVAL_ADDITIONS) == POST_PRAYER_EXTRA_TICKS
assert POST_PRAYER_TRANSFER_TO_NARRATION_TICKS == 0

# Stable retail/v1.5.9 absolute targets.
POST_PRAYER_ORIGINAL_TARGETS = (
    0x2BE0, 0x38F0, 0x45A0, 0x4C20, 0x4E90, 0x5790,
    0x59A0, 0x5BA0, 0x5D60, 0x5FA0, 0x6790, 0x69B0,
)

# Exact v1.6.0/v1.6.1 values made under the incorrect 256-Hz assumption.
OLD_V160_TIMELINE_TARGETS = (
    0x2C55, 0x3B78, 0x4A2C, 0x51B4, 0x5424, 0x5E92,
    0x60A2, 0x62A2, 0x6462, 0x66A2, 0x6FD5, 0x71F5,
)

# Exact v1.6.2 values: correct boundary, but still the incorrect 256-Hz unit.
OLD_V162_TIMELINE_TARGETS = (
    0x2BE0, 0x38F0, 0x45A0, 0x4C20, 0x4E90, 0x5934,
    0x5CE8, 0x608C, 0x63F0, 0x67D3, 0x6FC3, 0x71E3,
)

# v1.6.3 corrected 64-Hz values: +525 ticks total across the five intervals.
OLD_V163_TIMELINE_TARGETS = (
    0x2BE0, 0x38F0, 0x45A0, 0x4C20, 0x4E90, 0x57F9,
    0x5A72, 0x5CDB, 0x5F04, 0x61AD, 0x699D, 0x6BBD,
)

# v1.6.5: remove 26,26,26,25,25 ticks from those five intervals
# v1.6.4 targets are retained only as a recognized upgrade input; v1.6.5 restores the 128 ticks.
# Remaining montage additions are 79,79,79,80,80 ticks = 525/64 s.
OLD_V164_TIMELINE_TARGETS = (
    0x2BE0, 0x38F0, 0x45A0, 0x4C20, 0x4E90, 0x57DF,
    0x5A3E, 0x5C8D, 0x5E9D, 0x612D, 0x691D, 0x6B3D,
)
POST_PRAYER_CORRECT_TARGETS = OLD_V163_TIMELINE_TARGETS

POST_PRAYER_TIMELINE_SITES = (
    0x228E, 0x2337, 0x23E0, 0x2489, 0x2519, 0x25C2,
    0x2668, 0x26F8, 0x278B, 0x281B, 0x28D4, 0x28F3,
)
assert len(POST_PRAYER_TIMELINE_SITES) == len(POST_PRAYER_CORRECT_TARGETS)

# Byte-level proof of the absolute counter clock in this exact ENDING.DLL family.
SEG4_BASE = 0x8800
RTC_INIT_RATE_PUSH = 0x1377
RTC_REG_A_WRITE = 0x1499
ABS_COUNTER_INCREMENT = 0x1677

def verify_absolute_timeline_clock(data: bytes | bytearray) -> None:
    if bytes(data[SEG4_BASE + RTC_INIT_RATE_PUSH:SEG4_BASE + RTC_INIT_RATE_PUSH + 2]) != bytes.fromhex('6A 0A'):
        raise PatchError('04:1377 RTC rate selector가 0Ah가 아닙니다.')
    # 04:1499 selects RTC register A (70h <- 0Ah), then writes AL to 71h.
    if bytes(data[SEG4_BASE + RTC_REG_A_WRITE + 0x0A:SEG4_BASE + RTC_REG_A_WRITE + 0x17]) != bytes.fromhex('BA 70 00 B0 0A EE BA 71 00 8A 46 06 EE'):
        raise PatchError('04:1499 RTC register A 쓰기 루틴이 예상과 다릅니다.')
    if bytes(data[SEG4_BASE + ABS_COUNTER_INCREMENT:SEG4_BASE + ABS_COUNTER_INCREMENT + 10]) != bytes.fromhex('83 06 88 0B 01 83 16 8A 0B 00'):
        raise PatchError('04:1677 절대 타임라인 카운터 증가 루틴이 예상과 다릅니다.')


def _read_timeline_targets(data: bytes | bytearray) -> tuple[int, ...]:
    values: list[int] = []
    for site in POST_PRAYER_TIMELINE_SITES:
        pos = SEG10_BASE + site
        if data[pos] != 0xB8:
            raise PatchError(f'0A:{site:04X}가 MOV AX,imm16 형식이 아닙니다.')
        values.append(struct.unpack_from('<H', data, pos + 1)[0])
    return tuple(values)


def install_post_prayer_timeline_retime(data: bytearray) -> str:
    verify_absolute_timeline_clock(data)
    current = _read_timeline_targets(data)
    known = {
        POST_PRAYER_ORIGINAL_TARGETS: 'retimed_from_v1.5.9_or_older',
        OLD_V160_TIMELINE_TARGETS: 'repaired_wrong_v1.6.0_v1.6.1_256hz_retime',
        OLD_V162_TIMELINE_TARGETS: 'repaired_wrong_v1.6.2_256hz_retime',
        OLD_V164_TIMELINE_TARGETS: 'retimed_from_v1.6.4_reverse_2s_transfer',
        POST_PRAYER_CORRECT_TARGETS: 'already_retimed_v1.6.5_64hz',
    }
    if current not in known:
        raise PatchError('절대 타임라인 값이 알려진 v1.5.9/v1.6.0/v1.6.2/v1.6.3/v1.6.5 상태와 다릅니다.')
    state = known[current]
    if current != POST_PRAYER_CORRECT_TARGETS:
        for site, new_target in zip(POST_PRAYER_TIMELINE_SITES, POST_PRAYER_CORRECT_TARGETS):
            struct.pack_into('<H', data, SEG10_BASE + site + 1, new_target)
    return state


def verify_post_prayer_timeline_retime(data: bytes | bytearray) -> None:
    verify_absolute_timeline_clock(data)
    if _read_timeline_targets(data) != POST_PRAYER_CORRECT_TARGETS:
        raise PatchError('기도문 이후 v1.6.5 64-Hz 절대 타임라인 재조정 검증에 실패했습니다.')

# Live DOS final scene palette interpolation.  Keep retail 3 ticks/step.
PALETTE_STEP_DELAY_SITE = 0x2905
PALETTE_STEP_DELAY_ORIGINAL = bytes.fromhex("C6 06 0C 0E 03")
PALETTE_STEP_TICKS = 3
PALETTE_STEP_COUNT = 15

# Exact 3.000 s full-color hold at 64 Hz, then native palette fade-out.
FINAL_COLOR_HOLD_PATCH_SITE = 0x2938
FINAL_COLOR_HOLD_ORIGINAL_PREFIX = bytes.fromhex("FA 8C D0")
FINAL_COLOR_HOLD_TICK_CHUNKS = (192,)
FINAL_COLOR_HOLD_TICKS = sum(FINAL_COLOR_HOLD_TICK_CHUNKS)
NATIVE_FADE_OUT_OFFSET = 0x02C9
FINAL_HOLD_HELPER_OFFSET = FREYA_SAFE_WRAPPER_OFFSET + len(FREYA_SAFE_WRAPPER)

def build_final_hold_helper() -> bytes:
    helper = bytearray()
    for ticks in FINAL_COLOR_HOLD_TICK_CHUNKS:
        helper += bytes((0xB0, ticks))
        helper += _near_call(FINAL_HOLD_HELPER_OFFSET + len(helper), 0x155D)
    helper += _near_call(FINAL_HOLD_HELPER_OFFSET + len(helper), NATIVE_FADE_OUT_OFFSET)
    helper += FINAL_COLOR_HOLD_ORIGINAL_PREFIX
    helper += b"\xC3"
    return bytes(helper)

FINAL_HOLD_HELPER = build_final_hold_helper()
FINAL_HOLD_HELPER_SHA256 = hashlib.sha256(FINAL_HOLD_HELPER).hexdigest()
FINAL_SEG10_LENGTH = FINAL_HOLD_HELPER_OFFSET + len(FINAL_HOLD_HELPER)

# Exact newer helpers accepted only so they can be reverted to the v1.6.0
# scene path.  v1.6.1 reused the dialogue renderer after Joshua; v1.6.2 added
# a direct PC-98-derived renderer.  Neither path is retained by v1.6.5.
OLD_V161_FINAL_SEG10_LENGTH = 0x3352
OLD_V161_FINAL_HOLD_HELPER = bytes.fromhex(
    "B0 C0 E8 18 E2 BE 75 06 E8 81 D2 E8 7B CF FA 8C D0 C3"
)
OLD_V161_FINAL_HOLD_HELPER_SHA256 = hashlib.sha256(OLD_V161_FINAL_HOLD_HELPER).hexdigest()

OLD_V162_FINAL_SEG10_LENGTH = 0x33BA
OLD_V162_FINAL_HOLD_HELPER = bytes.fromhex(
    "B0 C0 E8 18 E2 E8 81 CF E8 04 00 FA 8C D0 C3 "
    "E8 4F D5 E8 08 F9 BA 68 00 B8 0B 00 EF B0 01 B2 00 B4 09 FA CD 41 FB "
    "BE 75 06 BF 33 35 E8 15 00 BE 9B 06 BF D8 3F E8 0C 00 E8 32 D0 B0 84 "
    "E8 DD E1 E8 46 CF C3 AC 0A C0 74 30 3C 0F 72 2C 3C 20 74 19 3C 2C 74 1A "
    "3C 2E 74 1B 8A F0 AC 8A D0 B8 00 0B FA CD 41 FB 83 C7 02 EB DA 83 C7 02 "
    "EB D5 BA AC A3 EB EA BA AE A3 EB E5 C3"
)
OLD_V162_FINAL_HOLD_HELPER_SHA256 = hashlib.sha256(OLD_V162_FINAL_HOLD_HELPER).hexdigest()

# Live and already proven DOS message path.  The original v1.5.0 add-on
# incorrectly copied the whole final message into 11:0E70.  That address is
# runtime state: 0A:0009 stores SS at 0E73, 0A:000D stores SP at 0E75, and
# 0A:189A stores AX at 0E71.  Those writes land directly inside the copied
# speaker name "레이시아".  v1.0.2 keeps the live stream at 11:05BC
# and extends it in place using the already-present dormant narration bytes.
LIVE_SCRIPT_CALL_SITE = 0x2847
RETAIL_SCRIPT_LOAD = bytes.fromhex("BE BC 05")  # mov si,05BCh
OLD_V150_SCRIPT_OFFSET = 0x0E70
OLD_V150_SCRIPT_LOAD = bytes.fromhex("BE 70 0E")  # broken v1.5.0 relocation
OLD_V150_RESERVED_SIZE = 0x0200
ORIGINAL_SCRIPT_OFFSET = 0x05BC
ORIGINAL_SCRIPT_TERMINATOR = 0x0674
NARRATION_TEXT_OFFSET = 0x0675
LINE_SEPARATOR_OFFSET = 0x069A
FINAL_SEPARATOR_OFFSET = 0x06B9

NARRATION_LINE1 = "자그마한 태양은 곧 아버지를 뛰어넘어,"
NARRATION_LINE1_REVISED = "자그마한 태양은 이윽고 아버지를 넘어,"
NARRATION_LINE2 = "커다란 태양으로써 빛날 것이다."
NARRATION_LINE2_REVISED = "커다란 태양으로서 빛날 것이다."
NARRATION_LINE1_BYTES = NARRATION_LINE1.encode("cp949")
NARRATION_LINE1_REVISED_BYTES = NARRATION_LINE1_REVISED.encode("cp949")
NARRATION_LINE1_VARIANTS = (NARRATION_LINE1_BYTES, NARRATION_LINE1_REVISED_BYTES)
NARRATION_LINE2_BYTES = NARRATION_LINE2.encode("cp949")
NARRATION_LINE2_REVISED_BYTES = NARRATION_LINE2_REVISED.encode("cp949")
NARRATION_LINE2_VARIANTS = (NARRATION_LINE2_BYTES, NARRATION_LINE2_REVISED_BYTES)
ORIGINAL_FINAL_STREAM = bytes.fromhex("00 02 09")
V151_FINAL_BRIDGE = bytes.fromhex("00 02 05")
PATCHED_FINAL_BRIDGE = bytes.fromhex("00 02 06")
ORIGINAL_LINE_SEPARATOR = b" "
PATCHED_LINE_SEPARATOR = b"\x00"
ORIGINAL_FINAL_SEPARATOR = b" "
V151_FINAL_SEPARATOR = b"\x09"
PATCHED_FINAL_SEPARATOR = b"\x07"
REISIA_BYTES = "레이시아".encode("cp949")
# The integrated text patch can insert punctuation before the second name,
# moving it two bytes inside the same fixed-capacity message slot.  Search
# narrow, disjoint windows instead of requiring one absolute byte address.
REISIA_NAME_WINDOWS = ((0x05BB, 0x05C8), (0x0616, 0x0628))

# Retail return path and dormant PC-98-derived path must remain untouched.
RETAIL_S016_TAIL_OFFSET = 0x2938
RETAIL_S016_TAIL = bytes.fromhex(
    "FA 8C D0 8E D8 8E 16 73 0E 8B 26 75 0E FB B8 FF FF 8E D8 CB B4 0D"
)
RETAIL_PRE_NARRATION_CALL = bytes.fromhex("E8 A4 DE")  # 29FA CALL 08A1
RETAIL_DIRECT_NARRATION = {
    0x2A2A: bytes.fromhex("BE 75 06"),
    0x2A2D: bytes.fromhex("BF 3B 35"),
    0x2A30: bytes.fromhex("B9 0D 00"),
    0x2A45: bytes.fromhex("BF DE 3F"),
    0x2A48: bytes.fromhex("B9 0B 00"),
    0x2A7F: bytes.fromhex("E8 C2 D6"),
}

class PatchError(RuntimeError):
    pass


def verify_reisia_names(segment11: bytes | bytearray) -> list[int]:
    """Return the two verified 레이시아 offsets, tolerating text-only shifts."""
    raw = bytes(segment11)
    offsets: list[int] = []
    for start, end in REISIA_NAME_WINDOWS:
        hits: list[int] = []
        pos = start
        while True:
            hit = raw.find(REISIA_BYTES, pos, min(end, len(raw)))
            if hit < 0:
                break
            hits.append(hit)
            pos = hit + 1
        if len(hits) != 1:
            raise PatchError(
                f"11:{start:04X}-11:{end - 1:04X}에서 레이시아 문자열을 "
                f"정확히 한 번 찾지 못했습니다: {hits}"
            )
        offsets.append(hits[0])
    return offsets


def current_narration_line1(segment11: bytes | bytearray) -> tuple[bytes, str]:
    start = NARRATION_TEXT_OFFSET
    for raw, text in (
        (NARRATION_LINE1_BYTES, NARRATION_LINE1),
        (NARRATION_LINE1_REVISED_BYTES, NARRATION_LINE1_REVISED),
    ):
        if bytes(segment11[start:start + len(raw)]) == raw:
            return raw, text
    actual = bytes(segment11[start:start + len(NARRATION_LINE1_BYTES)])
    raise PatchError(
        "11:0675의 나레이션 첫째 줄이 알려진 원문/교정문과 다릅니다: "
        + actual.hex(" ")
    )


def current_narration_line2(segment11: bytes | bytearray) -> tuple[bytes, str]:
    start = LINE_SEPARATOR_OFFSET + 1
    for raw, text in (
        (NARRATION_LINE2_BYTES, NARRATION_LINE2),
        (NARRATION_LINE2_REVISED_BYTES, NARRATION_LINE2_REVISED),
    ):
        if bytes(segment11[start:start + len(raw)]) == raw:
            return raw, text
    actual = bytes(segment11[start:start + len(NARRATION_LINE2_BYTES)])
    raise PatchError(
        "11:069B의 나레이션 둘째 줄이 알려진 원문/교정문과 다릅니다: "
        + actual.hex(" ")
    )


def sha256(data: bytes | bytearray) -> str:
    return hashlib.sha256(data).hexdigest()


def u16(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def atomic_write(path: Path, data: bytes) -> None:
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def resolve(path: Path) -> Path:
    path = path.expanduser().resolve()
    if path.is_dir():
        path = path / TARGET
    if not path.is_file() or path.name.upper() != TARGET:
        raise PatchError("ENDING.DLL 또는 ENDING.DLL이 있는 게임 폴더를 선택하십시오.")
    return path


def parse_ne(data: bytes | bytearray) -> list[dict[str, int]]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("MZ 실행 파일이 아닙니다.")
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise PatchError("NE DLL이 아닙니다.")
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    segments: list[dict[str, int]] = []
    for index in range(count):
        entry = table + index * 8
        sector, raw_length, flags, raw_minimum = struct.unpack_from("<HHHH", data, entry)
        segments.append({
            "entry": entry,
            "base": sector << shift,
            "length": raw_length or 0x10000,
            "minimum": raw_minimum or 0x10000,
            "flags": flags,
        })
    return segments


def near_call(site: int, target: int) -> bytes:
    return b"\xE8" + struct.pack("<H", (target - (site + 3)) & 0xFFFF)


def read_relocation_blob(data: bytes | bytearray, segment: dict[str, int]) -> bytes:
    if not (segment["flags"] & 0x0100):
        raise PatchError("세그먼트 10 재배치 표를 찾지 못했습니다.")
    start = segment["base"] + segment["length"]
    if start + 2 > len(data):
        raise PatchError("세그먼트 10 재배치 표가 잘렸습니다.")
    count = u16(data, start)
    if count != RELOCATION_COUNT:
        raise PatchError(f"예상하지 못한 재배치 레코드 수입니다: {count}")
    end = start + 2 + count * 8
    if end > len(data):
        raise PatchError("세그먼트 10 재배치 표가 파일 범위를 벗어납니다.")
    return bytes(data[start:end])


def normalize_2947_relocation(blob: bytes) -> bytes:
    normalized = bytearray(blob)
    found = 0
    count = u16(normalized, 0)
    for index in range(count):
        pos = 2 + index * 8
        source_type, reloc_type, source, target_segment, target_offset = struct.unpack_from(
            "<BBHHH", normalized, pos
        )
        if source == 0x2947:
            if (source_type, reloc_type, target_offset) != (2, 0, 0x0872):
                raise PatchError("0A:2947 재배치 레코드 형식이 예상과 다릅니다.")
            if target_segment not in (9, 11):
                raise PatchError("0A:2947 재배치 대상이 지원 범위와 다릅니다.")
            struct.pack_into("<H", normalized, pos + 4, 9)
            found += 1
    if found != 1:
        raise PatchError("0A:2947 재배치 레코드를 정확히 하나 찾지 못했습니다.")
    return bytes(normalized)


def validate_relocation(blob: bytes) -> bytes:
    normalized = normalize_2947_relocation(blob)
    if sha256(normalized) != RETAIL_RELOCATION_SHA256:
        raise PatchError("세그먼트 10 재배치 표가 알려진 한국어판과 다릅니다.")
    return normalized


def verify_ne_layout(segments: list[dict[str, int]]) -> tuple[dict[str, int], dict[str, int]]:
    if len(segments) < 12:
        raise PatchError("ENDING.DLL 세그먼트 수가 예상보다 적습니다.")
    seg10 = segments[SEG10_NUMBER - 1]
    seg11 = segments[SEG11_NUMBER - 1]
    seg12 = segments[SEG11_NUMBER]
    if seg10["base"] != SEG10_BASE or seg11["base"] != SEG11_BASE:
        raise PatchError("ENDING.DLL 세그먼트 10/11 위치가 예상과 다릅니다.")
    if seg12["base"] != NEXT_SEGMENT_BASE:
        raise PatchError("ENDING.DLL 세그먼트 12 위치가 예상과 다릅니다.")
    return seg10, seg11


def normalize_known_broken(data: bytearray, segments: list[dict[str, int]], input_hash: str) -> str | None:
    label = KNOWN_BROKEN_SHA256.get(input_hash)
    if label is None:
        return None
    seg10, seg11 = verify_ne_layout(segments)
    if seg10["length"] != BROKEN_NARRATION_SEG10_LENGTH:
        raise PatchError("알려진 실패 버전의 세그먼트 길이가 예상과 다릅니다.")
    blob = validate_relocation(read_relocation_blob(data, seg10))

    # Rebuild segment 10 exactly as stable v5.0.0.
    start = SEG10_BASE + RETAIL_SEG10_LENGTH
    data[start:SEG11_BASE] = b"\0" * (SEG11_BASE - start)
    data[start:start + len(FREYA_HELPER)] = FREYA_HELPER
    reloc_start = SEG10_BASE + V500_SEG10_LENGTH
    data[reloc_start:reloc_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, V500_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, V500_SEG10_LENGTH)

    # Restore every flow site touched by v5.0.1-v5.0.3.
    data[SEG10_BASE + RETAIL_S016_TAIL_OFFSET:SEG10_BASE + RETAIL_S016_TAIL_OFFSET + len(RETAIL_S016_TAIL)] = RETAIL_S016_TAIL
    data[SEG10_BASE + 0x29FA:SEG10_BASE + 0x29FD] = RETAIL_PRE_NARRATION_CALL
    for offset, raw in RETAIL_DIRECT_NARRATION.items():
        data[SEG10_BASE + offset:SEG10_BASE + offset + len(raw)] = raw

    # Their temporary narration copy occupied this otherwise-zero region.
    data[SEG11_BASE + OLD_V150_SCRIPT_OFFSET:SEG11_BASE + OLD_V150_SCRIPT_OFFSET + 0x0200] = b"\0" * 0x0200

    # Re-parse because the segment length field changed.
    return label


def install_v500_from_retail(data: bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != RETAIL_SEG10_LENGTH:
        raise PatchError("순정 세그먼트 10 길이가 예상과 다릅니다.")
    blob = validate_relocation(read_relocation_blob(data, seg10))
    reloc_start = SEG10_BASE + V500_SEG10_LENGTH
    if reloc_start + len(blob) > SEG11_BASE:
        raise PatchError("v5.0.0 도우미와 재배치 표가 세그먼트 11과 겹칩니다.")
    start = SEG10_BASE + RETAIL_SEG10_LENGTH
    data[start:SEG11_BASE] = b"\0" * (SEG11_BASE - start)
    data[start:start + len(FREYA_HELPER)] = FREYA_HELPER
    data[reloc_start:reloc_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, V500_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, V500_SEG10_LENGTH)
    for offset, (retail, target) in FREYA_PATCH_SITES.items():
        pos = SEG10_BASE + offset
        current = bytes(data[pos:pos + 3])
        desired = near_call(offset, target)
        if current not in (retail, desired):
            raise PatchError(f"0A:{offset:04X}의 프레이아 호출 패턴이 예상과 다릅니다.")
        data[pos:pos + 3] = desired


def _verify_common_ending_flow(data: bytes | bytearray) -> None:
    for offset, (_, target) in FREYA_PATCH_SITES.items():
        expected = near_call(offset, target)
        if bytes(data[SEG10_BASE + offset:SEG10_BASE + offset + 3]) != expected:
            raise PatchError(f"0A:{offset:04X}가 안정판 v5.0.0 호출과 다릅니다.")
    if bytes(data[SEG10_BASE + RETAIL_S016_TAIL_OFFSET:SEG10_BASE + RETAIL_S016_TAIL_OFFSET + len(RETAIL_S016_TAIL)]) != RETAIL_S016_TAIL:
        raise PatchError("0A:2938의 정상 반환 경로가 변경되어 있습니다.")
    if bytes(data[SEG10_BASE + 0x29FA:SEG10_BASE + 0x29FD]) != RETAIL_PRE_NARRATION_CALL:
        raise PatchError("0A:29FA의 휴면 코드가 변경되어 있습니다.")
    for offset, raw in RETAIL_DIRECT_NARRATION.items():
        if bytes(data[SEG10_BASE + offset:SEG10_BASE + offset + len(raw)]) != raw:
            raise PatchError(f"0A:{offset:04X}의 휴면 코드가 변경되어 있습니다.")


def verify_v500_base(data: bytes | bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != V500_SEG10_LENGTH:
        raise PatchError(
            f"세그먼트 10 길이가 안정판 v5.0.0과 다릅니다: 0x{seg10['length']:X}"
        )
    helper = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(helper) != FREYA_HELPER_SHA256:
        raise PatchError("프레이아 도우미가 안정판 v5.0.0과 다릅니다.")
    blob = read_relocation_blob(data, seg10)
    if sha256(blob) != RETAIL_RELOCATION_SHA256:
        raise PatchError("안정판 v5.0.0 재배치 표와 다릅니다.")
    if bytes(data[SEG10_BASE + TIMING_DISPATCH_SITE:SEG10_BASE + TIMING_DISPATCH_SITE + len(TIMING_DISPATCH_ORIGINAL)]) != TIMING_DISPATCH_ORIGINAL:
        raise PatchError("0A:0604 메시지 제어 분기가 안정판 v5.0.0과 다릅니다.")
    _verify_common_ending_flow(data)


def install_timing_extension(data: bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != V500_SEG10_LENGTH:
        raise PatchError("타이밍 도우미 설치 전 세그먼트 10이 v5.0.0 상태가 아닙니다.")
    verify_v500_base(data, segments)
    blob = read_relocation_blob(data, seg10)
    helper_start = SEG10_BASE + TIMING_HELPER_OFFSET
    reloc_start = SEG10_BASE + TIMED_SEG10_LENGTH
    if reloc_start + len(blob) > SEG11_BASE:
        raise PatchError("타이밍 도우미와 재배치 표가 세그먼트 11과 겹칩니다.")
    data[helper_start:SEG11_BASE] = b"\0" * (SEG11_BASE - helper_start)
    data[helper_start:helper_start + len(TIMING_HELPER)] = TIMING_HELPER
    data[reloc_start:reloc_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, TIMED_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, TIMED_SEG10_LENGTH)
    site = SEG10_BASE + TIMING_DISPATCH_SITE
    data[site:site + len(TIMING_DISPATCH_PATCH)] = TIMING_DISPATCH_PATCH


def verify_timed_base(data: bytes | bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != TIMED_SEG10_LENGTH:
        raise PatchError(f"세그먼트 10 길이가 v1.5.2와 다릅니다: 0x{seg10['length']:X}")
    freya = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(freya) != FREYA_HELPER_SHA256:
        raise PatchError("프레이아 v5.0.0 도우미가 보존되지 않았습니다.")
    timing = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
    if timing != TIMING_HELPER or sha256(timing) != TIMING_HELPER_SHA256:
        raise PatchError("마지막 장면 타이밍 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + TIMING_DISPATCH_SITE:SEG10_BASE + TIMING_DISPATCH_SITE + len(TIMING_DISPATCH_PATCH)]) != TIMING_DISPATCH_PATCH:
        raise PatchError("0A:0604 타이밍 분기 패치가 예상과 다릅니다.")
    blob = read_relocation_blob(data, seg10)
    if sha256(blob) != RETAIL_RELOCATION_SHA256:
        raise PatchError("v1.5.2 재배치 표가 안정판 v5.0.0과 다릅니다.")
    _verify_common_ending_flow(data)


def verify_legacy_timed_base(data: bytes | bytearray, segments: list[dict[str, int]]) -> None:
    """Verify exact v1.5.2/v1.5.3 timing bytes made with the old 256-Hz assumption."""
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != TIMED_SEG10_LENGTH:
        raise PatchError(f"세그먼트 10 길이가 구형 타이밍판과 다릅니다: 0x{seg10['length']:X}")
    freya = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(freya) != FREYA_HELPER_SHA256:
        raise PatchError("구형 타이밍판의 프레이아 v5.0.0 도우미가 예상과 다릅니다.")
    timing = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
    if timing != LEGACY_TIMING_HELPER or sha256(timing) != LEGACY_TIMING_HELPER_SHA256:
        raise PatchError("구형 192/255틱 타이밍 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + TIMING_DISPATCH_SITE:SEG10_BASE + TIMING_DISPATCH_SITE + len(TIMING_DISPATCH_PATCH)]) != TIMING_DISPATCH_PATCH:
        raise PatchError("구형 타이밍판의 0A:0604 분기 패치가 예상과 다릅니다.")
    blob = read_relocation_blob(data, seg10)
    if sha256(blob) != RETAIL_RELOCATION_SHA256:
        raise PatchError("구형 타이밍판 재배치 표가 안정판 v5.0.0과 다릅니다.")
    _verify_common_ending_flow(data)


def upgrade_legacy_timing_in_place(data: bytearray, segments: list[dict[str, int]]) -> None:
    verify_legacy_timed_base(data, segments)
    start = SEG10_BASE + TIMING_HELPER_OFFSET
    data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
    verify_timed_base(data, parse_ne(data))


def verify_old_v154_base(data: bytes | bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != OLD_V154_SEG10_LENGTH:
        raise PatchError(f"세그먼트 10 길이가 v1.5.4와 다릅니다: 0x{seg10['length']:X}")
    freya = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(freya) != FREYA_HELPER_SHA256:
        raise PatchError("v1.5.4 입력의 프레이아 v5.0.0 도우미가 예상과 다릅니다.")
    timing = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
    if timing != LEGACY_TIMING_HELPER:
        raise PatchError("v1.5.4 입력의 구형 타이밍 도우미가 예상과 다릅니다.")
    old_safe = bytes(data[SEG10_BASE + OLD_V154_FREYA_SAFE_WRAPPER_OFFSET:SEG10_BASE + OLD_V154_FREYA_SAFE_WRAPPER_OFFSET + len(OLD_V154_FREYA_SAFE_WRAPPER)])
    old_hold = bytes(data[SEG10_BASE + OLD_V154_FINAL_HOLD_HELPER_OFFSET:SEG10_BASE + OLD_V154_SEG10_LENGTH])
    if old_safe != OLD_V154_FREYA_SAFE_WRAPPER or old_hold != OLD_V154_FINAL_HOLD_HELPER:
        raise PatchError("v1.5.4 입력의 추가 도우미 바이트가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + OLD_V154_FREYA_SITE:SEG10_BASE + OLD_V154_FREYA_SITE + 3]) != near_call(OLD_V154_FREYA_SITE, OLD_V154_FREYA_SAFE_WRAPPER_OFFSET):
        raise PatchError("v1.5.4 입력의 0A:1F8C 패턴이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + PALETTE_STEP_DELAY_SITE:SEG10_BASE + PALETTE_STEP_DELAY_SITE + 5]) != OLD_V154_PALETTE_FAST:
        raise PatchError("v1.5.4 입력의 0A:2905 1틱 패턴이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3]) != near_call(FINAL_COLOR_HOLD_PATCH_SITE, OLD_V154_FINAL_HOLD_HELPER_OFFSET):
        raise PatchError("v1.5.4 입력의 0A:2938 유지 호출이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + FREYA_END_TRANSIENT_SITE:SEG10_BASE + FREYA_END_TRANSIENT_SITE + 4]) != FREYA_END_TRANSIENT_ORIGINAL:
        raise PatchError("v1.5.4 입력의 0A:2118이 원본과 다릅니다.")
    if sha256(read_relocation_blob(data, seg10)) != RETAIL_RELOCATION_SHA256:
        raise PatchError("v1.5.4 입력의 재배치 표가 안정판 v5.0.0과 다릅니다.")

def normalize_old_v154_to_timed(data: bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    verify_old_v154_base(data, segments)
    blob = read_relocation_blob(data, seg10)
    ext_start = SEG10_BASE + TIMED_SEG10_LENGTH
    data[ext_start:SEG11_BASE] = b"\0" * (SEG11_BASE - ext_start)
    data[ext_start:ext_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, TIMED_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, TIMED_SEG10_LENGTH)
    data[SEG10_BASE + OLD_V154_FREYA_SITE:SEG10_BASE + OLD_V154_FREYA_SITE + 3] = near_call(OLD_V154_FREYA_SITE, CURRENT_WRAPPER)
    data[SEG10_BASE + PALETTE_STEP_DELAY_SITE:SEG10_BASE + PALETTE_STEP_DELAY_SITE + 5] = PALETTE_STEP_DELAY_ORIGINAL
    data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3] = FINAL_COLOR_HOLD_ORIGINAL_PREFIX
    check = parse_ne(data)
    verify_legacy_timed_base(data, check)
    upgrade_legacy_timing_in_place(data, check)

def verify_old_v155_base(data: bytes | bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != OLD_V155_SEG10_LENGTH:
        raise PatchError(f"세그먼트 10 길이가 v1.5.5와 다릅니다: 0x{seg10['length']:X}")
    freya = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(freya) != FREYA_HELPER_SHA256:
        raise PatchError("v1.5.5 입력의 프레이아 v5.0.0 도우미가 예상과 다릅니다.")
    timing = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
    if timing != OLD_V155_TIMING_HELPER:
        raise PatchError("v1.5.5 입력의 잘못된 60Hz 가정 타이밍 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + OLD_V155_RECROP_OFFSET:SEG10_BASE + OLD_V155_HOLD_OFFSET]) != OLD_V155_RECROP:
        raise PatchError("v1.5.5 재크롭 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + OLD_V155_HOLD_OFFSET:SEG10_BASE + OLD_V155_SEG10_LENGTH]) != OLD_V155_HOLD:
        raise PatchError("v1.5.5 컬러 유지 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + FREYA_END_TRANSIENT_SITE:SEG10_BASE + FREYA_END_TRANSIENT_SITE + 4]) != OLD_V155_END_CALL:
        raise PatchError("v1.5.5 0A:2118 재크롭 호출이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3]) != OLD_V155_HOLD_CALL:
        raise PatchError("v1.5.5 0A:2938 유지 호출이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + PALETTE_STEP_DELAY_SITE:SEG10_BASE + PALETTE_STEP_DELAY_SITE + 5]) != PALETTE_STEP_DELAY_ORIGINAL:
        raise PatchError("v1.5.5 팔레트 3틱 코드가 예상과 다릅니다.")
    if sha256(read_relocation_blob(data, seg10)) != RETAIL_RELOCATION_SHA256:
        raise PatchError("v1.5.5 재배치 표가 안정판과 다릅니다.")

def normalize_old_v155_to_timed(data: bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    verify_old_v155_base(data, segments)
    blob = read_relocation_blob(data, seg10)
    ext_start = SEG10_BASE + TIMED_SEG10_LENGTH
    data[ext_start:SEG11_BASE] = b"\0" * (SEG11_BASE - ext_start)
    # Replace old 45/60 timing helper with the current exact 16/64 helper.
    data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH] = TIMING_HELPER
    data[ext_start:ext_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, TIMED_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, TIMED_SEG10_LENGTH)
    # Undo the destructive second crop and restore the retail final INT 41h.
    data[SEG10_BASE + FREYA_END_TRANSIENT_SITE:SEG10_BASE + FREYA_END_TRANSIENT_SITE + 4] = FREYA_END_TRANSIENT_ORIGINAL
    data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3] = FINAL_COLOR_HOLD_ORIGINAL_PREFIX
    verify_timed_base(data, parse_ne(data))

def verify_old_v156_base(data: bytes | bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != OLD_V156_SEG10_LENGTH:
        raise PatchError(f"세그먼트 10 길이가 v1.5.6과 다릅니다: 0x{seg10['length']:X}")
    freya = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(freya) != FREYA_HELPER_SHA256:
        raise PatchError("v1.5.6 입력의 프레이아 v5.0.0 도우미가 예상과 다릅니다.")
    timing = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
    if timing != OLD_V156_TIMING_HELPER or sha256(timing) != OLD_V156_TIMING_HELPER_SHA256:
        raise PatchError("v1.5.6 입력의 48/64 타이밍 도우미가 예상과 다릅니다.")
    guard = bytes(data[SEG10_BASE + OLD_V156_END_GUARD_OFFSET:SEG10_BASE + OLD_V156_FINAL_HOLD_OFFSET])
    hold = bytes(data[SEG10_BASE + OLD_V156_FINAL_HOLD_OFFSET:SEG10_BASE + OLD_V156_SEG10_LENGTH])
    if guard != OLD_V156_END_GUARD or hold != OLD_V156_FINAL_HOLD:
        raise PatchError("v1.5.6 입력의 종료 가드/컬러 유지 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + FREYA_END_TRANSIENT_SITE:SEG10_BASE + FREYA_END_TRANSIENT_SITE + 4]) != OLD_V156_END_CALL:
        raise PatchError("v1.5.6 입력의 0A:2118 종료 가드 호출이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3]) != OLD_V156_HOLD_CALL:
        raise PatchError("v1.5.6 입력의 0A:2938 유지 호출이 예상과 다릅니다.")
    for offset, (_, target) in FREYA_PATCH_SITES.items():
        if bytes(data[SEG10_BASE + offset:SEG10_BASE + offset + 3]) != near_call(offset, target):
            raise PatchError(f"v1.5.6 입력의 0A:{offset:04X} 프레이아 호출이 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + PALETTE_STEP_DELAY_SITE:SEG10_BASE + PALETTE_STEP_DELAY_SITE + 5]) != PALETTE_STEP_DELAY_ORIGINAL:
        raise PatchError("v1.5.6 입력의 팔레트 3틱 코드가 예상과 다릅니다.")
    if sha256(read_relocation_blob(data, seg10)) != RETAIL_RELOCATION_SHA256:
        raise PatchError("v1.5.6 입력의 재배치 표가 안정판과 다릅니다.")


def normalize_old_v156_to_timed(data: bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    verify_old_v156_base(data, segments)
    blob = read_relocation_blob(data, seg10)
    ext_start = SEG10_BASE + TIMED_SEG10_LENGTH
    data[ext_start:SEG11_BASE] = b"\0" * (SEG11_BASE - ext_start)
    data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH] = TIMING_HELPER
    data[ext_start:ext_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, TIMED_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, TIMED_SEG10_LENGTH)
    # Restore the v5.0.0 direct current-panel calls.  v1.5.9 will then guard
    # all three rebuilds consistently with its new temporary wrapper.
    for offset in FREYA_CURRENT_SITES:
        data[SEG10_BASE + offset:SEG10_BASE + offset + 3] = near_call(offset, CURRENT_WRAPPER)
    # Undo v1.5.6's early permanent callback shutdown.
    data[SEG10_BASE + FREYA_END_TRANSIENT_SITE:SEG10_BASE + FREYA_END_TRANSIENT_SITE + 4] = FREYA_END_TRANSIENT_ORIGINAL
    data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3] = FINAL_COLOR_HOLD_ORIGINAL_PREFIX
    verify_timed_base(data, parse_ne(data))


def install_scene_polish_extension(data: bytearray, segments: list[dict[str, int]]) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != TIMED_SEG10_LENGTH:
        raise PatchError("장면 보정 설치 전 세그먼트 10이 타이밍 기본 상태가 아닙니다.")
    verify_timed_base(data, segments)
    blob = read_relocation_blob(data, seg10)
    helper_start = SEG10_BASE + FREYA_SAFE_WRAPPER_OFFSET
    reloc_start = SEG10_BASE + FINAL_SEG10_LENGTH
    if reloc_start + len(blob) > SEG11_BASE:
        raise PatchError("장면 보정 도우미와 재배치 표가 세그먼트 11과 겹칩니다.")
    data[helper_start:SEG11_BASE] = b"\0" * (SEG11_BASE - helper_start)
    data[SEG10_BASE + FREYA_SAFE_WRAPPER_OFFSET:SEG10_BASE + FREYA_SAFE_WRAPPER_OFFSET + len(FREYA_SAFE_WRAPPER)] = FREYA_SAFE_WRAPPER
    data[SEG10_BASE + FINAL_HOLD_HELPER_OFFSET:SEG10_BASE + FINAL_HOLD_HELPER_OFFSET + len(FINAL_HOLD_HELPER)] = FINAL_HOLD_HELPER
    data[reloc_start:reloc_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, FINAL_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, FINAL_SEG10_LENGTH)

    # Panel 0 remains direct.  Every fresh current-panel rebuild gets a narrow
    # save-idle-crop-restore guard so the timer can never expose the raw four
    # panels, but animation resumes immediately after each crop.
    panel0_site = 0x1D3B
    if bytes(data[SEG10_BASE + panel0_site:SEG10_BASE + panel0_site + 3]) != near_call(panel0_site, PANEL0_WRAPPER):
        raise PatchError("0A:1D3B 프레이아 panel-0 호출이 v5.0.0과 다릅니다.")
    for offset in FREYA_CURRENT_SITES:
        direct = near_call(offset, CURRENT_WRAPPER)
        guarded = near_call(offset, FREYA_SAFE_WRAPPER_OFFSET)
        current = bytes(data[SEG10_BASE + offset:SEG10_BASE + offset + 3])
        if current not in (direct, guarded):
            raise PatchError(f"0A:{offset:04X} 프레이아 current-panel 호출이 예상과 다릅니다.")
        data[SEG10_BASE + offset:SEG10_BASE + offset + 3] = guarded

    palette_site = SEG10_BASE + PALETTE_STEP_DELAY_SITE
    current_palette = bytes(data[palette_site:palette_site + len(PALETTE_STEP_DELAY_ORIGINAL)])
    if current_palette not in (PALETTE_STEP_DELAY_ORIGINAL, OLD_V154_PALETTE_FAST):
        raise PatchError("0A:2905 팔레트 전환 대기 코드가 예상과 다릅니다.")
    data[palette_site:palette_site + len(PALETTE_STEP_DELAY_ORIGINAL)] = PALETTE_STEP_DELAY_ORIGINAL

    # Keep the final Freya output path retail so the blink callback remains live
    # through the intended animation; retail shuts it down at 0A:213E.
    end_site = SEG10_BASE + FREYA_END_TRANSIENT_SITE
    if bytes(data[end_site:end_site + 4]) != FREYA_END_TRANSIENT_ORIGINAL:
        raise PatchError("0A:2118 프레이아 종료 패턴이 원본과 다릅니다.")

    hold_site = SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE
    expected_hold_call = near_call(FINAL_COLOR_HOLD_PATCH_SITE, FINAL_HOLD_HELPER_OFFSET)
    current_hold = bytes(data[hold_site:hold_site + 3])
    if current_hold not in (FINAL_COLOR_HOLD_ORIGINAL_PREFIX, expected_hold_call):
        raise PatchError("0A:2938 마지막 컬러 화면 유지 지점이 예상과 다릅니다.")
    data[hold_site:hold_site + 3] = expected_hold_call


def verify_scene_polished_base(
    data: bytes | bytearray,
    segments: list[dict[str, int]],
    *,
    expected_timing: bytes = TIMING_HELPER,
    expected_timing_sha256: str = TIMING_HELPER_SHA256,
    expected_seg10_length: int = FINAL_SEG10_LENGTH,
    expected_hold_helper: bytes = FINAL_HOLD_HELPER,
    expected_hold_sha256: str = FINAL_HOLD_HELPER_SHA256,
    version_label: str = "v1.6.0-compatible base",
) -> None:
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] != expected_seg10_length:
        raise PatchError(f"세그먼트 10 길이가 {version_label}과 다릅니다: 0x{seg10['length']:X}")
    freya = bytes(data[SEG10_BASE + RETAIL_SEG10_LENGTH:SEG10_BASE + V500_SEG10_LENGTH])
    if sha256(freya) != FREYA_HELPER_SHA256:
        raise PatchError("프레이아 v5.0.0 도우미가 보존되지 않았습니다.")
    timing = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
    if timing != expected_timing or sha256(timing) != expected_timing_sha256:
        raise PatchError(f"{version_label} 64Hz 타이밍 도우미가 예상과 다릅니다.")
    guard = bytes(data[SEG10_BASE + FREYA_SAFE_WRAPPER_OFFSET:SEG10_BASE + FREYA_SAFE_WRAPPER_OFFSET + len(FREYA_SAFE_WRAPPER)])
    hold = bytes(data[SEG10_BASE + FINAL_HOLD_HELPER_OFFSET:SEG10_BASE + expected_seg10_length])
    if guard != FREYA_SAFE_WRAPPER or sha256(guard) != FREYA_SAFE_WRAPPER_SHA256:
        raise PatchError("프레이아 임시 콜백 가드 도우미가 예상과 다릅니다.")
    if hold != expected_hold_helper or sha256(hold) != expected_hold_sha256:
        raise PatchError(f"{version_label} 마지막 장면 도우미가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + TIMING_DISPATCH_SITE:SEG10_BASE + TIMING_DISPATCH_SITE + len(TIMING_DISPATCH_PATCH)]) != TIMING_DISPATCH_PATCH:
        raise PatchError("0A:0604 나레이션 타이밍 분기가 예상과 다릅니다.")
    if bytes(data[SEG10_BASE + 0x1D3B:SEG10_BASE + 0x1D3E]) != near_call(0x1D3B, PANEL0_WRAPPER):
        raise PatchError("0A:1D3B panel-0 호출 검증에 실패했습니다.")
    for offset in FREYA_CURRENT_SITES:
        if bytes(data[SEG10_BASE + offset:SEG10_BASE + offset + 3]) != near_call(offset, FREYA_SAFE_WRAPPER_OFFSET):
            raise PatchError(f"0A:{offset:04X} 프레이아 임시 가드 호출 검증에 실패했습니다.")
    if bytes(data[SEG10_BASE + PALETTE_STEP_DELAY_SITE:SEG10_BASE + PALETTE_STEP_DELAY_SITE + 5]) != PALETTE_STEP_DELAY_ORIGINAL:
        raise PatchError("0A:2905의 원래 3틱 팔레트 대기가 보존되지 않았습니다.")
    if bytes(data[SEG10_BASE + FREYA_END_TRANSIENT_SITE:SEG10_BASE + FREYA_END_TRANSIENT_SITE + 4]) != FREYA_END_TRANSIENT_ORIGINAL:
        raise PatchError("0A:2118 원래 프레이아 종료 출력이 보존되지 않았습니다.")
    if bytes(data[SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE:SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE + 3]) != near_call(FINAL_COLOR_HOLD_PATCH_SITE, FINAL_HOLD_HELPER_OFFSET):
        raise PatchError("0A:2938 마지막 컬러 화면 유지/페이드 호출 검증에 실패했습니다.")
    tail_rest = RETAIL_S016_TAIL[3:]
    hold_site = SEG10_BASE + FINAL_COLOR_HOLD_PATCH_SITE
    if bytes(data[hold_site + 3:hold_site + len(RETAIL_S016_TAIL)]) != tail_rest:
        raise PatchError("0A:293B 이후 원래 스택 복구/RETF 경로가 변경되었습니다.")
    if bytes(data[SEG10_BASE + 0x29FA:SEG10_BASE + 0x29FD]) != RETAIL_PRE_NARRATION_CALL:
        raise PatchError("0A:29FA의 휴면 PC-98 경로가 변경되었습니다.")
    for offset, raw in RETAIL_DIRECT_NARRATION.items():
        if bytes(data[SEG10_BASE + offset:SEG10_BASE + offset + len(raw)]) != raw:
            raise PatchError(f"0A:{offset:04X}의 휴면 코드가 변경되었습니다.")
    if sha256(read_relocation_blob(data, seg10)) != RETAIL_RELOCATION_SHA256:
        raise PatchError(f"{version_label} 재배치 표가 안정판 v5.0.0과 다릅니다.")


def normalize_newer_scene_to_v160(
    data: bytearray,
    segments: list[dict[str, int]],
    *,
    old_length: int,
    old_helper: bytes,
    old_helper_sha256: str,
    version_label: str,
) -> None:
    """Revert v1.6.1/v1.6.2 final-scene helper back to v1.6.0."""
    seg10, _ = verify_ne_layout(segments)
    verify_scene_polished_base(
        data, segments,
        expected_seg10_length=old_length,
        expected_hold_helper=old_helper,
        expected_hold_sha256=old_helper_sha256,
        version_label=version_label,
    )
    blob = read_relocation_blob(data, seg10)
    helper_start = SEG10_BASE + FINAL_HOLD_HELPER_OFFSET
    reloc_start = SEG10_BASE + FINAL_SEG10_LENGTH
    data[helper_start:SEG11_BASE] = b"\0" * (SEG11_BASE - helper_start)
    data[helper_start:helper_start + len(FINAL_HOLD_HELPER)] = FINAL_HOLD_HELPER
    data[reloc_start:reloc_start + len(blob)] = blob
    struct.pack_into("<H", data, seg10["entry"] + 2, FINAL_SEG10_LENGTH)
    struct.pack_into("<H", data, seg10["entry"] + 6, FINAL_SEG10_LENGTH)
    verify_scene_polished_base(data, parse_ne(data), version_label="v1.6.0-restored")


def original_script_bytes(segment11: bytes | bytearray) -> bytes:
    start = ORIGINAL_SCRIPT_OFFSET
    end = ORIGINAL_SCRIPT_TERMINATOR + 1
    original = bytes(segment11[start:end])
    if len(original) < 3 or original[-3:] != ORIGINAL_FINAL_STREAM:
        raise PatchError("11:05BC 마지막 메시지의 원본 종료 형식이 예상과 다릅니다.")
    verify_reisia_names(segment11)
    return original


def build_old_v150_combined(segment11: bytes | bytearray) -> bytes:
    original = original_script_bytes(segment11)
    line1_bytes, _line1_text = current_narration_line1(segment11)
    line2_bytes, _line2_text = current_narration_line2(segment11)
    suffix = (
        line1_bytes
        + b"\x00"
        + line2_bytes
        + b"\x00\x02\x09"
    )
    combined = original[:-1] + suffix
    if len(combined) > OLD_V150_RESERVED_SIZE:
        raise PatchError("기존 v1.5.0 결합 메시지가 예약 영역을 초과합니다.")
    return combined


def validate_stream(script: bytes) -> dict[str, object]:
    """Validate the live bytecode, including control 03's four-character name."""
    pos = 0
    controls: list[int] = []
    speaker_names: list[str] = []
    while pos < len(script):
        value = script[pos]
        if value == 3:
            controls.append(value)
            if pos + 9 > len(script):
                raise PatchError("화자 이름 제어 코드 뒤의 8바이트가 잘렸습니다.")
            raw_name = script[pos + 1:pos + 9]
            speaker_names.append(raw_name.decode("cp949"))
            pos += 9
        elif value in (0, 1, 2, 4, 5, 6):
            controls.append(value)
            pos += 1
        elif value in (7, 9):
            controls.append(value)
            pos += 1
            if pos != len(script):
                raise PatchError("메시지 종료 코드 뒤에 데이터가 남아 있습니다.")
            break
        elif value in (0x20, 0x2E, 0x2C, 0x3F, 0x21):
            pos += 1
        else:
            if pos + 1 >= len(script):
                raise PatchError("메시지 끝에서 2바이트 문자가 잘렸습니다.")
            bytes(script[pos:pos + 2]).decode("cp949")
            pos += 2
    if not controls or controls[-1] not in (7, 9):
        raise PatchError("메시지 종료 코드가 없습니다.")
    if not speaker_names or speaker_names[0] != "레이시아":
        raise PatchError("첫 화자 이름 레이시아가 정상적으로 보존되지 않았습니다.")
    matched_line1: str | None = None
    matched_line2: str | None = None
    for line1_bytes, line1_text in (
        (NARRATION_LINE1_BYTES, NARRATION_LINE1),
        (NARRATION_LINE1_REVISED_BYTES, NARRATION_LINE1_REVISED),
    ):
        for line2_bytes, line2_text in (
            (NARRATION_LINE2_BYTES, NARRATION_LINE2),
            (NARRATION_LINE2_REVISED_BYTES, NARRATION_LINE2_REVISED),
        ):
            marker = (
                b"\x00\x02\x06"
                + line1_bytes
                + b"\x00"
                + line2_bytes
                + b"\x07"
            )
            if marker in script:
                matched_line1 = line1_text
                matched_line2 = line2_text
                break
        if matched_line1 is not None:
            break
    if matched_line1 is None or matched_line2 is None:
        raise PatchError("인플레이스 나레이션 페이지를 찾지 못했습니다.")
    return {
        "bytes": len(script),
        "controls": controls,
        "speaker_names": speaker_names,
        "line1": matched_line1,
        "line2": matched_line2,
    }


def validate_in_place_layout(segment11: bytes | bytearray) -> dict[str, object]:
    if bytes(segment11[ORIGINAL_SCRIPT_TERMINATOR - 2:ORIGINAL_SCRIPT_TERMINATOR + 1]) != PATCHED_FINAL_BRIDGE:
        raise PatchError("11:0672의 나레이션 연결 제어 코드가 예상과 다릅니다.")
    current_narration_line1(segment11)
    if bytes(segment11[LINE_SEPARATOR_OFFSET:LINE_SEPARATOR_OFFSET + 1]) != PATCHED_LINE_SEPARATOR:
        raise PatchError("나레이션 줄바꿈 제어 코드가 설치되지 않았습니다.")
    _line2_bytes, _line2_text = current_narration_line2(segment11)
    if bytes(segment11[FINAL_SEPARATOR_OFFSET:FINAL_SEPARATOR_OFFSET + 1]) != PATCHED_FINAL_SEPARATOR:
        raise PatchError("나레이션 종료 코드가 설치되지 않았습니다.")
    end = FINAL_SEPARATOR_OFFSET + 1
    return validate_stream(bytes(segment11[ORIGINAL_SCRIPT_OFFSET:end]))

def apply_patch(raw: bytes) -> tuple[bytes, dict[str, object]]:
    input_hash = sha256(raw)
    data = bytearray(raw)
    segments = parse_ne(data)
    seg10, seg11 = verify_ne_layout(segments)
    state_before: str

    if input_hash in KNOWN_BROKEN_SHA256:
        label = normalize_known_broken(data, segments, input_hash)
        state_before = f"normalized_from_{label}"
        segments = parse_ne(data)
        verify_v500_base(data, segments)
        install_timing_extension(data, segments)
        segments = parse_ne(data)
        verify_timed_base(data, segments)
    elif seg10["length"] == RETAIL_SEG10_LENGTH:
        install_v500_from_retail(data, segments)
        state_before = "retail_to_stable_v5.0.0"
        segments = parse_ne(data)
        verify_v500_base(data, segments)
        install_timing_extension(data, segments)
        segments = parse_ne(data)
        verify_timed_base(data, segments)
    elif seg10["length"] == V500_SEG10_LENGTH:
        verify_v500_base(data, segments)
        state_before = "stable_v5.0.0_or_v1.5.1"
        install_timing_extension(data, segments)
        segments = parse_ne(data)
        verify_timed_base(data, segments)
    elif seg10["length"] == TIMED_SEG10_LENGTH:
        timing_now = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
        if timing_now == TIMING_HELPER:
            verify_timed_base(data, segments)
            state_before = "timed_v1.6.5_64hz_16_192"
        elif timing_now == OLD_V159_TIMING_HELPER:
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_timed_base(data, segments)
            state_before = "timed_v1.5.9_v1.6.3_16_64_to_v1.6.5_16_192"
        elif timing_now == OLD_V158_TIMING_HELPER:
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_timed_base(data, segments)
            state_before = "timed_v1.5.8_32_64_to_v1.5.9_16_64"
        elif timing_now == OLD_V157_TIMING_HELPER:
            # v1.5.7 shortened the wrong control: it reduced the narration-end
            # wait. Restore control 07 to 64 ticks and shorten only control 06,
            # the Joshua-screen pause before palette transition, to the current value.
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_timed_base(data, segments)
            state_before = "timed_v1.5.7_48_32_to_v1.5.9_16_64"
        elif timing_now == OLD_V156_TIMING_HELPER:
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_timed_base(data, segments)
            state_before = "timed_v1.5.6_48_64_to_v1.5.9_16_64"
        elif timing_now == LEGACY_TIMING_HELPER:
            verify_legacy_timed_base(data, segments)
            state_before = "timed_v1.5.2_v1.5.3_old_tick_assumption_to_64hz"
            upgrade_legacy_timing_in_place(data, segments)
            segments = parse_ne(data)
            verify_timed_base(data, segments)
        else:
            raise PatchError("세그먼트 10의 타이밍 도우미가 알려진 신/구 버전과 다릅니다.")
    elif seg10["length"] == OLD_V154_SEG10_LENGTH:
        verify_old_v154_base(data, segments)
        state_before = "scene_polished_v1.5.4_to_v1.5.9"
        normalize_old_v154_to_timed(data, segments)
        segments = parse_ne(data)
        verify_timed_base(data, segments)
    elif seg10["length"] == OLD_V155_SEG10_LENGTH:
        verify_old_v155_base(data, segments)
        state_before = "broken_scene_polished_v1.5.5_to_v1.5.9"
        normalize_old_v155_to_timed(data, segments)
        segments = parse_ne(data)
        verify_timed_base(data, segments)
    elif seg10["length"] == OLD_V156_SEG10_LENGTH:
        verify_old_v156_base(data, segments)
        state_before = "scene_polished_v1.5.6_to_v1.5.9"
        normalize_old_v156_to_timed(data, segments)
        segments = parse_ne(data)
        verify_timed_base(data, segments)
    elif seg10["length"] == OLD_V161_FINAL_SEG10_LENGTH:
        timing_now = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
        if timing_now != OLD_V159_TIMING_HELPER:
            raise PatchError("v1.6.1 입력의 타이밍 도우미가 예상과 다릅니다.")
        start = SEG10_BASE + TIMING_HELPER_OFFSET
        data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
        normalize_newer_scene_to_v160(
            data, segments,
            old_length=OLD_V161_FINAL_SEG10_LENGTH,
            old_helper=OLD_V161_FINAL_HOLD_HELPER,
            old_helper_sha256=OLD_V161_FINAL_HOLD_HELPER_SHA256,
            version_label="v1.6.1",
        )
        segments = parse_ne(data)
        state_before = "scene_polished_v1.6.1_restored_to_v1.6.0"
    elif seg10["length"] == OLD_V162_FINAL_SEG10_LENGTH:
        timing_now = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
        if timing_now != OLD_V159_TIMING_HELPER:
            raise PatchError("v1.6.2 입력의 타이밍 도우미가 예상과 다릅니다.")
        start = SEG10_BASE + TIMING_HELPER_OFFSET
        data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
        normalize_newer_scene_to_v160(
            data, segments,
            old_length=OLD_V162_FINAL_SEG10_LENGTH,
            old_helper=OLD_V162_FINAL_HOLD_HELPER,
            old_helper_sha256=OLD_V162_FINAL_HOLD_HELPER_SHA256,
            version_label="v1.6.2 direct-render",
        )
        segments = parse_ne(data)
        state_before = "scene_polished_v1.6.2_direct_renderer_removed_to_v1.6.0"
    elif seg10["length"] == FINAL_SEG10_LENGTH:
        timing_now = bytes(data[SEG10_BASE + TIMING_HELPER_OFFSET:SEG10_BASE + TIMED_SEG10_LENGTH])
        if timing_now == TIMING_HELPER:
            verify_scene_polished_base(data, segments)
            state_before = "scene_polished_timing_16_64"
        elif timing_now == OLD_V164_TIMING_HELPER:
            verify_scene_polished_base(
                data, segments,
                expected_timing=OLD_V164_TIMING_HELPER,
                expected_timing_sha256=OLD_V164_TIMING_HELPER_SHA256,
                version_label="v1.6.4",
            )
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_scene_polished_base(data, segments)
            state_before = "scene_polished_v1.6.4_to_v1.6.5"
        elif timing_now == OLD_V159_TIMING_HELPER:
            verify_scene_polished_base(
                data, segments,
                expected_timing=OLD_V159_TIMING_HELPER,
                expected_timing_sha256=OLD_V159_TIMING_HELPER_SHA256,
                version_label="v1.5.9-v1.6.3",
            )
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_scene_polished_base(data, segments)
            state_before = "scene_polished_v1.5.9_v1.6.3_to_v1.6.5"
        elif timing_now == OLD_V158_TIMING_HELPER:
            verify_scene_polished_base(
                data, segments,
                expected_timing=OLD_V158_TIMING_HELPER,
                expected_timing_sha256=OLD_V158_TIMING_HELPER_SHA256,
                version_label="v1.5.8",
            )
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_scene_polished_base(data, segments)
            state_before = "scene_polished_v1.5.8_to_v1.5.9"
        elif timing_now == OLD_V157_TIMING_HELPER:
            verify_scene_polished_base(
                data, segments,
                expected_timing=OLD_V157_TIMING_HELPER,
                expected_timing_sha256=OLD_V157_TIMING_HELPER_SHA256,
                version_label="v1.5.7",
            )
            start = SEG10_BASE + TIMING_HELPER_OFFSET
            data[start:start + len(TIMING_HELPER)] = TIMING_HELPER
            segments = parse_ne(data)
            verify_scene_polished_base(data, segments)
            state_before = "scene_polished_v1.5.7_to_v1.5.9"
        else:
            raise PatchError("완성형 엔딩의 타이밍 도우미가 알려진 v1.5.7/v1.5.8/v1.5.9-v1.6.5와 다릅니다.")
    else:
        raise PatchError(
            "지원되지 않는 ENDING.DLL입니다. 순정, 안정판 v5.0.0, 통합 v1.5.0/v1.5.1, "
            "정확한 v5.0.1-v5.0.3 실패 버전, v1.5.2/v1.5.3, v1.5.4, v1.5.5, v1.5.6, v1.5.7-v1.6.5 계열을 사용하십시오."
        )

    # 모든 입력을 v1.6.0 장면 코드로 정규화한 뒤, 타임라인만 64-Hz 기준으로 교정한다.
    segments = parse_ne(data)
    seg10, _ = verify_ne_layout(segments)
    if seg10["length"] == TIMED_SEG10_LENGTH:
        install_scene_polish_extension(data, segments)
        segments = parse_ne(data)
        verify_scene_polished_base(data, segments)
    elif seg10["length"] == FINAL_SEG10_LENGTH:
        verify_scene_polished_base(data, segments)
    else:
        raise PatchError("장면 보정 후 세그먼트 10 상태가 예상과 다릅니다.")

    # "부디 지켜보아 주십시오."(11:0529 stream) 이전의 절대 목표는 그대로 둔다.
    # 그 메시지가 끝난 뒤 레이시아 대사 전까지의 다섯 구간에 525/64 = 8.203125초를 배분하고, 마지막 나레이션 홀드는 64/64 = 1.000초로 되돌린다. v1.6.5 대비 총 예산 589틱은 그대로다.
    timeline_state = install_post_prayer_timeline_retime(data)
    verify_post_prayer_timeline_retime(data)

    seg10, seg11 = verify_ne_layout(segments)
    call_pos = SEG10_BASE + LIVE_SCRIPT_CALL_SITE
    current_load = bytes(data[call_pos:call_pos + 3])
    storage_pos = SEG11_BASE + OLD_V150_SCRIPT_OFFSET
    migrated_from_v150 = False

    # Migrate the broken v1.5.0 layout.  It put the first speaker name across
    # runtime save variables 0E71/0E73/0E75, so those bytes were overwritten
    # before the message was rendered.
    if current_load == OLD_V150_SCRIPT_LOAD:
        segment11_now = data[SEG11_BASE:SEG11_BASE + seg11["length"]]
        old_combined = build_old_v150_combined(segment11_now)
        reserved = bytes(data[storage_pos:storage_pos + OLD_V150_RESERVED_SIZE])
        expected_reserved = old_combined + b"\0" * (OLD_V150_RESERVED_SIZE - len(old_combined))
        if reserved != expected_reserved:
            raise PatchError("11:0E70의 기존 v1.5.0 결합 메시지가 예상과 다릅니다.")
        data[call_pos:call_pos + 3] = RETAIL_SCRIPT_LOAD
        data[storage_pos:storage_pos + OLD_V150_RESERVED_SIZE] = b"\0" * OLD_V150_RESERVED_SIZE
        migrated_from_v150 = True
        state_before += "+migrated_v1.5.0_name_corruption"
    elif current_load != RETAIL_SCRIPT_LOAD:
        raise PatchError("0A:2847의 마지막 메시지 포인터가 예상과 다릅니다.")

    segment11_now = data[SEG11_BASE:SEG11_BASE + seg11["length"]]
    # Verify the live names while tolerating same-slot punctuation changes made
    # by the integrated text patch.
    reisia_offsets_before = verify_reisia_names(segment11_now)
    line1_bytes_before, line1_text_before = current_narration_line1(segment11_now)
    line2_bytes_before, line2_text_before = current_narration_line2(segment11_now)

    bridge_now = bytes(segment11_now[ORIGINAL_SCRIPT_TERMINATOR - 2:ORIGINAL_SCRIPT_TERMINATOR + 1])
    line_sep_now = bytes(segment11_now[LINE_SEPARATOR_OFFSET:LINE_SEPARATOR_OFFSET + 1])
    final_sep_now = bytes(segment11_now[FINAL_SEPARATOR_OFFSET:FINAL_SEPARATOR_OFFSET + 1])
    allowed_bridges = (ORIGINAL_FINAL_STREAM, V151_FINAL_BRIDGE, PATCHED_FINAL_BRIDGE)
    if bridge_now not in allowed_bridges:
        raise PatchError("11:0672의 마지막 메시지 종료 형식이 예상과 다릅니다.")
    if line_sep_now not in (ORIGINAL_LINE_SEPARATOR, PATCHED_LINE_SEPARATOR):
        raise PatchError("11:069A의 나레이션 줄 구분 바이트가 예상과 다릅니다.")
    if final_sep_now not in (ORIGINAL_FINAL_SEPARATOR, V151_FINAL_SEPARATOR, PATCHED_FINAL_SEPARATOR):
        raise PatchError("11:06B9의 나레이션 종료 바이트가 예상과 다릅니다.")

    already = (
        not migrated_from_v150
        and state_before in ("scene_polished_timing_16_64", "scene_polished_v1.6.4_to_v1.6.5")
        and timeline_state == "already_retimed_v1.6.5_64hz"
        and bridge_now == PATCHED_FINAL_BRIDGE
        and line_sep_now == PATCHED_LINE_SEPARATOR
        and final_sep_now == PATCHED_FINAL_SEPARATOR
        and bytes(data[storage_pos:storage_pos + OLD_V150_RESERVED_SIZE]) == b"\0" * OLD_V150_RESERVED_SIZE
    )

    # 00 02 09 -> 00 02 06: preserve the original page transition, then use
    # the new private control 06 for a slightly longer Joshua-screen hold.
    # The narration ends with private control 07, which waits before returning
    # to the original fade path.  Both 레이시아 strings remain in place.
    data[SEG11_BASE + ORIGINAL_SCRIPT_TERMINATOR] = 0x06
    data[SEG11_BASE + LINE_SEPARATOR_OFFSET] = 0x00
    data[SEG11_BASE + FINAL_SEPARATOR_OFFSET] = 0x07

    final_segments = parse_ne(data)
    verify_scene_polished_base(data, final_segments)
    verify_post_prayer_timeline_retime(data)
    final_seg10 = final_segments[SEG10_NUMBER - 1]
    if sha256(read_relocation_blob(data, final_seg10)) != RETAIL_RELOCATION_SHA256:
        raise PatchError("최종 재배치 표가 안정판 v5.0.0과 다릅니다.")
    if bytes(data[call_pos:call_pos + 3]) != RETAIL_SCRIPT_LOAD:
        raise PatchError("0A:2847이 원래 11:05BC 메시지를 가리키지 않습니다.")
    if bytes(data[storage_pos:storage_pos + OLD_V150_RESERVED_SIZE]) != b"\0" * OLD_V150_RESERVED_SIZE:
        raise PatchError("잘못 사용된 11:0E70 런타임 영역이 복구되지 않았습니다.")
    final_segment11 = data[SEG11_BASE:SEG11_BASE + seg11["length"]]
    script_info = validate_in_place_layout(final_segment11)
    reisia_offsets_after = verify_reisia_names(final_segment11)

    output = bytes(data)
    report = {
        "tool": APP,
        "version": VERSION,
        "status": "already_patched" if already else "patched",
        "state_before": state_before,
        "input_sha256": input_hash,
        "output_sha256": sha256(output),
        "patch_scope": {
            "live_call_site": "0A:2847 remains MOV SI,05BCh",
            "script_storage": "original live stream 11:05BC extended in place",
            "changed_stream_bytes": ["11:0674 09/05->06", "11:069A 20->00", "11:06B9 20/09->07"],
            "timing_dispatch": "0A:0604 -> 0A:330E extended controls",
            "joshua_extra_hold": f"{JOSHUA_EXTRA_TICKS} ticks ({JOSHUA_EXTRA_TICKS / ENDING_TICK_HZ:.3f} s)",
            "post_prayer_montage_retime": {
                "state": timeline_state,
                "boundary": "after 0A:2548 -> 11:0529 prayer stream returns; all earlier targets unchanged",
                "timeline_rate_hz": ENDING_ABS_TIMELINE_HZ,
                "clock_proof": "04:1377 PUSH 0Ah -> relocated CALL 04:16CA; 04:1499 writes RTC register A; 04:1677 increments 0000:0B88 once per periodic IRQ",
                "added_ticks": POST_PRAYER_EXTRA_TICKS,
                "added_seconds": POST_PRAYER_EXTRA_SECONDS,
                "interval_additions_ticks": list(POST_PRAYER_INTERVAL_ADDITIONS),
                "interval_additions_seconds": [value / ENDING_ABS_TIMELINE_HZ for value in POST_PRAYER_INTERVAL_ADDITIONS],
                "targets": [
                    {"site": f"0A:{site:04X}", "old": f"0x{old:04X}", "new": f"0x{new:04X}"}
                    for site, old, new in zip(POST_PRAYER_TIMELINE_SITES, POST_PRAYER_ORIGINAL_TARGETS, POST_PRAYER_CORRECT_TARGETS)
                ],
                "policy": "five post-prayer intervals use 105 ticks each (525 total); v1.6.4's 128-tick transfer to the final narration hold is reversed; final hold is 64 ticks and combined budget remains 589 ticks",
            },
            "narration_final_hold": f"{NARRATION_HOLD_TICKS} ticks ({NARRATION_HOLD_TICKS / ENDING_TICK_HZ:.3f} s)",
            "old_v1.5.0_storage": "11:0E70 restored to zero when recognized",
            "runtime_state_conflict": ["11:0E71 AX", "11:0E73 SS", "11:0E75 SP"],
            "reisia_name": {
                "before_offsets": [f"11:{value:04X}" for value in reisia_offsets_before],
                "after_offsets": [f"11:{value:04X}" for value in reisia_offsets_after],
                "policy": "text-patch punctuation shifts inside the same message slot are preserved",
            },
            "narration_line2_input": line2_text_before,
            "freya_v5.0.0_helper": "preserved byte-for-byte",
            "timing_helper": f"0A:{TIMING_HELPER_OFFSET:04X}-0A:{TIMED_SEG10_LENGTH - 1:04X}",
            "palette_transition": {
                "site": "0A:2905",
                "steps": PALETTE_STEP_COUNT,
                "wait_per_step": f"{PALETTE_STEP_TICKS} ticks (original)",
                "policy": "original three-tick wait preserved",
            },
            "final_full_color_hold": {
                "site": "0A:2938",
                "ticks": FINAL_COLOR_HOLD_TICKS,
                "seconds": FINAL_COLOR_HOLD_TICKS / ENDING_TICK_HZ,
                "helper": f"0A:{FINAL_HOLD_HELPER_OFFSET:04X}-0A:{FINAL_SEG10_LENGTH - 1:04X}",
                "after_hold": "native palette fade-out 0A:02C9, then original CLI / AX=SS / stack restore / RETF semantics",
            },
            "freya_transient_fix": {
                "sites": [f"0A:{value:04X}" for value in FREYA_CURRENT_SITES],
                "helper": f"0A:{FREYA_SAFE_WRAPPER_OFFSET:04X}-0A:{FREYA_SAFE_WRAPPER_OFFSET + len(FREYA_SAFE_WRAPPER) - 1:04X}",
                "policy": "save animation callback, switch to idle 0A:1589 only during fresh 4-panel load+crop, then restore callback immediately",
                "final_output": "0A:2118 remains retail CLI / INT 41h / STI; retail callback shutdown at 0A:213E remains in charge",
            },
            "s016_return_path": "first 3 bytes redirected to exact 192-tick (3.000 s at 64 Hz) hold helper; helper then calls native palette fade-out 0A:02C9 before the original stack-restore/RETF path",
            "timer_callback_code": "v5.0.0 animation callback code unchanged; only the three fresh Freya page rebuilds are guarded temporarily",
            "stack_switching": "unchanged",
            "INT_18h": "not entered or modified",
            "staff_dll": "not modified",
        },
        "narration": script_info,
    }
    return output, report

def main() -> int:
    parser = argparse.ArgumentParser(description="안정판 v5.0.0의 원래 메시지 위치를 유지하며 마지막 나레이션을 추가합니다.")
    parser.add_argument("path", nargs="?", default=".", help="ENDING.DLL 또는 게임 폴더")
    parser.add_argument("--no-backup", action="store_true", help="백업 생성을 생략")
    args = parser.parse_args()
    try:
        target = resolve(Path(args.path))
        original = target.read_bytes()
        output, report = apply_patch(original)
        backup: Path | None = None
        if output != original:
            if not args.no_backup:
                backup = target.with_name(target.name + BACKUP_SUFFIX)
                if not backup.exists():
                    shutil.copy2(target, backup)
            atomic_write(target, output)
        report["target"] = str(target)
        report["backup"] = str(backup) if backup else None
        report_path = target.parent / REPORT_NAME
        atomic_write(report_path, json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8"))
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (PatchError, OSError, UnicodeError, struct.error) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
