#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

import freya_v500_core as freya

APP = "ED2 Freya v5.0.0 + G_ED1900 Staff Final 3-Plane Fix"
VERSION = "1.3.0"
ENDING_NAME = "ENDING.DLL"
STAFF_NAME = "STAFF.DLL"
SOURCE_NAME = "G_ED1900.BZP"
OUTPUT_NAME = "ED19.STF"
REPORT_NAME = "ED2_FREYA_STAFF_FINAL_G_ED1900_V130.json"
STAFF_BACKUP_SUFFIX = ".before_staff_final_g_ed1900_v130.bak"
OUTPUT_BACKUP_SUFFIX = ".before_staff_final_g_ed1900_v130.bak"

STAFF_EXPECTED_SIZE = 1_661_006
STAFF_RETAIL_SHA256 = "82ebad54b713926911dde9d45fd7abdb0896b51fad36d4cae4e250c09e3f36ed"

# STAFF.DLL has two unrelated graphic tables:
#   20:035E -> es01 ... os11 : 3-plane/8-color staff-roll backgrounds
#   20:04B4 -> OP06 ... OP06 : 4-plane/16-color advertisement sequence
# The actual final copyright background is _GRP[12] = "os11" at 20:0768.
FINAL_STAFF_NAME_OFFSET = 0x182F68
FINAL_STAFF_NAME_RETAIL = b"os11"
FINAL_STAFF_NAME_OLD_ES02 = b"es02"
FINAL_STAFF_NAME_NEW = b"ed19"

# Restore the unrelated advertisement table if an older incorrect patch touched it.
AD_FINAL_PATH_OFFSET = 0x182FBB
AD_FINAL_PATH_RETAIL = b"grp\\op06.STF"
AD_FINAL_PATH_OLD_OP32 = b"grp\\op32.STF"
AD_FINAL_PATH_OLD_ED19 = b"grp\\ED19.STF"

SOURCE_EXPECTED_SIZE = 50_574
SOURCE_EXPECTED_SHA256 = "82e03fd586d638625c586172ae991e05f40f0f4e451326218935977060e5dd9f"
DECOMPRESSED_EXPECTED_SIZE = 68_737
DECOMPRESSED_EXPECTED_SHA256 = "457751225090b8015edb416048af680bb1a74245410dfc8c6ae332119a3c05b7"

WIDTH = 640
SOURCE_HEIGHT = 240
STAFF_HEIGHT = 400
CENTER_Y = (STAFF_HEIGHT - SOURCE_HEIGHT) // 2  # 80
ROW_BYTES = WIDTH // 8
STAFF_PLANE_BYTES = ROW_BYTES * STAFF_HEIGHT  # 0x7D00
STAFF_PALETTE_BYTES = 8 * 4
OUTPUT_EXPECTED_SIZE = STAFF_PLANE_BYTES * 3 + STAFF_PALETTE_BYTES  # 96032
OUTPUT_EXPECTED_SHA256 = "86036215953997194654ee27c10f0c153a0e0f7dfb37209931b03a4f83bfdb2c"

# The staff-roll background loader uses a 3-plane/8-color surface. Staff lettering
# is drawn separately in white, so all eight background palette entries are free for
# the G_ED1900 scene. Each stored color is copied exactly from the original palette;
# omitted source colors are remapped to the nearest retained color.
SELECTED_SOURCE_COLORS = (0, 1, 3, 6, 7, 8, 12, 14)


class PatchError(Exception):
    pass


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    except Exception:
        try:
            os.unlink(temp)
        except OSError:
            pass
        raise


def find_child_case_insensitive(folder: Path, name: str) -> Path | None:
    exact = folder / name
    if exact.exists():
        return exact
    wanted = name.casefold()
    try:
        for child in folder.iterdir():
            if child.name.casefold() == wanted:
                return child
    except OSError:
        return None
    return None


def is_game_folder(folder: Path) -> bool:
    ending = find_child_case_insensitive(folder, ENDING_NAME)
    staff = find_child_case_insensitive(folder, STAFF_NAME)
    grp = find_child_case_insensitive(folder, "GRP")
    if not (ending and ending.is_file() and staff and staff.is_file() and grp and grp.is_dir()):
        return False
    source = find_child_case_insensitive(grp, SOURCE_NAME)
    return bool(source and source.is_file())


def resolve_game_folder(path: Path) -> Path:
    path = path.expanduser().resolve()
    if path.is_file():
        if path.name.casefold() not in (ENDING_NAME.casefold(), STAFF_NAME.casefold()):
            raise PatchError("영웅전설 II 게임 폴더, ENDING.DLL 또는 STAFF.DLL을 선택하십시오.")
        path = path.parent
    if not path.is_dir():
        raise PatchError("선택한 폴더를 찾을 수 없습니다.")
    if is_game_folder(path):
        return path

    # Keep folder selection convenient when the selected directory contains one
    # game subfolder (for example GAME4). Do not guess when several candidates exist.
    candidates: list[Path] = []
    for child in path.iterdir():
        if child.is_dir() and is_game_folder(child):
            candidates.append(child)
        if child.is_dir():
            try:
                for grandchild in child.iterdir():
                    if grandchild.is_dir() and is_game_folder(grandchild):
                        candidates.append(grandchild)
            except OSError:
                pass
    unique = sorted(set(candidates), key=lambda p: str(p).casefold())
    if len(unique) == 1:
        return unique[0]
    if not unique:
        raise PatchError("선택한 폴더에서 ENDING.DLL, STAFF.DLL, GRP\\G_ED1900.BZP를 찾지 못했습니다.")
    raise PatchError("게임 폴더 후보가 여러 개입니다. ENDING.DLL과 STAFF.DLL이 있는 정확한 폴더를 선택하십시오.")


def resolve_game_files(folder: Path) -> tuple[Path, Path, Path, Path]:
    ending = find_child_case_insensitive(folder, ENDING_NAME)
    staff = find_child_case_insensitive(folder, STAFF_NAME)
    grp = find_child_case_insensitive(folder, "GRP")
    assert ending is not None and staff is not None and grp is not None
    source = find_child_case_insensitive(grp, SOURCE_NAME)
    assert source is not None
    existing_output = find_child_case_insensitive(grp, OUTPUT_NAME)
    output = existing_output if existing_output is not None else grp / OUTPUT_NAME
    return ending, staff, source, output


def decompress_mode1(src: bytes) -> bytes:
    ip = 0
    out = bytearray()
    while True:
        if ip + 2 > len(src):
            raise PatchError("G_ED1900.BZP 외부 압축 헤더가 잘렸습니다.")
        start = ip
        block_len = src[ip] | (src[ip + 1] << 8)
        ip += 2
        end = start + block_len
        if not (start < end <= len(src)):
            raise PatchError("G_ED1900.BZP 외부 압축 블록 길이가 잘못되었습니다.")
        while ip != end:
            if ip > end:
                raise PatchError("G_ED1900.BZP 외부 압축 블록을 초과했습니다.")
            command = src[ip]
            ip += 1
            if not (command & 0x80):
                if not (command & 0x40):
                    if not (command & 0x20):
                        count = command
                    else:
                        if ip >= end:
                            raise PatchError("G_ED1900.BZP literal 길이가 잘렸습니다.")
                        count = ((command & 0x1F) << 8) | src[ip]
                        ip += 1
                    if ip + count > end:
                        raise PatchError("G_ED1900.BZP literal 데이터가 블록을 벗어납니다.")
                    out.extend(src[ip:ip + count])
                    ip += count
                else:
                    if not (command & 0x10):
                        count = (command & 0x0F) + 4
                    else:
                        if ip >= end:
                            raise PatchError("G_ED1900.BZP RLE 길이가 잘렸습니다.")
                        count = (((command & 0x0F) << 8) | src[ip]) + 4
                        ip += 1
                    if ip >= end:
                        raise PatchError("G_ED1900.BZP RLE 값이 잘렸습니다.")
                    value = src[ip]
                    ip += 1
                    out.extend(bytes([value]) * count)
            else:
                if ip >= end:
                    raise PatchError("G_ED1900.BZP LZ 거리가 잘렸습니다.")
                count = ((command & 0x60) >> 5) + 4
                distance = ((command & 0x1F) << 8) | src[ip]
                ip += 1
                if distance <= 0 or distance > len(out):
                    raise PatchError("G_ED1900.BZP LZ 거리가 잘못되었습니다.")
                source_pos = len(out) - distance
                for _ in range(count):
                    out.append(out[source_pos])
                    source_pos += 1
                while ip < end and (src[ip] & 0xE0) == 0x60:
                    extension = src[ip] & 0x1F
                    ip += 1
                    for _ in range(extension):
                        out.append(out[source_pos])
                        source_pos += 1
        if ip >= len(src):
            raise PatchError("G_ED1900.BZP 블록 종료 표지가 없습니다.")
        marker = src[ip]
        ip += 1
        if marker == 0:
            break
    if ip != len(src):
        raise PatchError("G_ED1900.BZP 뒤에 예상하지 못한 데이터가 있습니다.")
    return bytes(out)


def decode_mode1_into(data: bytes, pos: int, initial: bytearray, di: int) -> tuple[bytearray, int, int]:
    out = bytearray(initial)
    while True:
        if pos + 2 > len(data):
            raise PatchError("G_ED1900 첫 평면 압축 헤더가 잘렸습니다.")
        start = pos
        block_len = int.from_bytes(data[pos:pos + 2], "little")
        pos += 2
        end = start + block_len
        if not (start < end <= len(data)):
            raise PatchError("G_ED1900 첫 평면 블록 길이가 잘못되었습니다.")
        while pos != end:
            if pos > end:
                raise PatchError("G_ED1900 첫 평면 블록을 초과했습니다.")
            command = data[pos]
            pos += 1
            if not (command & 0x80):
                if not (command & 0x40):
                    if not (command & 0x20):
                        count = command
                    else:
                        count = ((command & 0x1F) << 8) | data[pos]
                        pos += 1
                    if di + count > len(out) or pos + count > end:
                        raise PatchError("G_ED1900 첫 평면 literal 범위를 벗어났습니다.")
                    out[di:di + count] = data[pos:pos + count]
                    di += count
                    pos += count
                else:
                    if not (command & 0x10):
                        count = (command & 0x0F) + 4
                    else:
                        count = (((command & 0x0F) << 8) | data[pos]) + 4
                        pos += 1
                    value = data[pos]
                    pos += 1
                    if di + count > len(out):
                        raise PatchError("G_ED1900 첫 평면 RLE 범위를 벗어났습니다.")
                    out[di:di + count] = bytes([value]) * count
                    di += count
            else:
                count = ((command & 0x60) >> 5) + 4
                distance = ((command & 0x1F) << 8) | data[pos]
                pos += 1
                source_pos = di - distance
                if source_pos < 0 or di + count > len(out):
                    raise PatchError("G_ED1900 첫 평면 LZ 범위를 벗어났습니다.")
                for _ in range(count):
                    out[di] = out[source_pos]
                    di += 1
                    source_pos += 1
                while pos < end and (data[pos] & 0xE0) == 0x60:
                    extension = data[pos] & 0x1F
                    pos += 1
                    if di + extension > len(out):
                        raise PatchError("G_ED1900 첫 평면 LZ 확장 범위를 벗어났습니다.")
                    for _ in range(extension):
                        out[di] = out[source_pos]
                        di += 1
                        source_pos += 1
        if pos >= len(data):
            raise PatchError("G_ED1900 첫 평면 종료 표지가 없습니다.")
        marker = data[pos]
        pos += 1
        if marker == 0:
            return out, pos, di


def decode_sparse_into(data: bytes, pos: int, initial: bytearray, di: int) -> tuple[bytearray, int, int]:
    if pos + 2 > len(data):
        raise PatchError("G_ED1900 차분 평면 헤더가 잘렸습니다.")
    start = pos
    length = int.from_bytes(data[pos:pos + 2], "little")
    end = start + length
    pos += 2
    if not (start < end <= len(data)):
        raise PatchError("G_ED1900 차분 평면 길이가 잘못되었습니다.")
    out = bytearray(initial)
    while pos < end:
        command = data[pos]
        pos += 1
        if command & 0x80:
            count = command & 0x7F
            if pos + count > end or di + count > len(out):
                raise PatchError("G_ED1900 차분 평면 literal 범위를 벗어났습니다.")
            out[di:di + count] = data[pos:pos + count]
            pos += count
            di += count
        else:
            di += command
            if di > len(out):
                raise PatchError("G_ED1900 차분 평면 skip 범위를 벗어났습니다.")
    if pos != end:
        raise PatchError("G_ED1900 차분 평면 종료 위치가 맞지 않습니다.")
    return out, pos, di


def decode_g_ed1900(source: bytes) -> tuple[list[bytes], list[tuple[int, int, int]]]:
    if len(source) != SOURCE_EXPECTED_SIZE or sha256(source) != SOURCE_EXPECTED_SHA256:
        raise PatchError("GRP\\G_ED1900.BZP가 확인된 한국어판 리소스와 다릅니다.")
    decoded = decompress_mode1(source)
    if len(decoded) != DECOMPRESSED_EXPECTED_SIZE or sha256(decoded) != DECOMPRESSED_EXPECTED_SHA256:
        raise PatchError("G_ED1900.BZP 해제 결과가 예상과 다릅니다.")

    raw_palette = decoded[:48]
    if any(value > 0x0F for value in raw_palette):
        raise PatchError("G_ED1900 팔레트 형식이 예상과 다릅니다.")
    # Source order is B,R,G. Keep integer 4-bit components.
    palette = [
        (raw_palette[i * 3 + 1], raw_palette[i * 3 + 2], raw_palette[i * 3 + 0])
        for i in range(16)
    ]

    base = bytearray(0x10000)
    first, pos, di = decode_mode1_into(decoded, 0x30, base, 0)
    if pos != 0x38E8 or di != 0x4B00:
        raise PatchError("G_ED1900 첫 평면 해제 위치가 예상과 다릅니다.")
    buffer_a = bytearray(first)
    buffer_a[0x4B00:0x9600] = buffer_a[0:0x4B00]
    buffer_b = bytearray(0x10000)
    buffer_b[0:0x9600] = buffer_a[0:0x9600]
    stage1, pos1, di1 = decode_sparse_into(decoded, pos, buffer_a, 0x4B00)
    stage2, pos2, di2 = decode_sparse_into(decoded, pos1, buffer_b, 0)
    stage3, pos3, di3 = decode_sparse_into(decoded, pos2, stage2, 0x4B00)
    if (pos1, di1, pos2, di2, pos3, di3) != (
        0x7E12, 0x9600, 0xC2C8, 0x4B00, len(decoded), 0x9600
    ):
        raise PatchError("G_ED1900 차분 평면 해제 위치가 예상과 다릅니다.")
    planes = [
        bytes(stage1[0x0000:0x4B00]),
        bytes(stage1[0x4B00:0x9600]),
        bytes(stage3[0x0000:0x4B00]),
        bytes(stage3[0x4B00:0x9600]),
    ]
    return planes, palette


def nearest_color_map(palette: list[tuple[int, int, int]]) -> list[int]:
    selected = [palette[index] for index in SELECTED_SOURCE_COLORS]
    result: list[int] = []
    for color in palette:
        distances = [
            (color[0] - candidate[0]) ** 2
            + (color[1] - candidate[1]) ** 2
            + (color[2] - candidate[2]) ** 2
            for candidate in selected
        ]
        result.append(min(range(8), key=lambda i: (distances[i], i)))
    return result


def build_centered_staff_stf(source: bytes) -> tuple[bytes, dict[str, object]]:
    planes4, palette16 = decode_g_ed1900(source)
    mapping = nearest_color_map(palette16)

    # Decode source color indices, remap to the staff renderer's 8 colors, and
    # center the 640x240 scene in its 640x400 background surface (Y = 80).
    indexed = bytearray(WIDTH * STAFF_HEIGHT)
    source_counts = [0] * 16
    output_counts = [0] * 8
    for y in range(SOURCE_HEIGHT):
        source_row = y * ROW_BYTES
        target_row = (y + CENTER_Y) * WIDTH
        for byte_x in range(ROW_BYTES):
            values = [planes4[p][source_row + byte_x] for p in range(4)]
            for bit_x in range(8):
                mask = 0x80 >> bit_x
                source_index = 0
                for plane_index in range(4):
                    if values[plane_index] & mask:
                        source_index |= 1 << plane_index
                output_index = mapping[source_index]
                indexed[target_row + byte_x * 8 + bit_x] = output_index
                source_counts[source_index] += 1
                output_counts[output_index] += 1

    output_planes = [bytearray(STAFF_PLANE_BYTES) for _ in range(3)]
    for y in range(STAFF_HEIGHT):
        row_pixel = y * WIDTH
        row_byte = y * ROW_BYTES
        for byte_x in range(ROW_BYTES):
            packed = [0, 0, 0]
            for bit_x in range(8):
                color = indexed[row_pixel + byte_x * 8 + bit_x]
                mask = 0x80 >> bit_x
                for plane_index in range(3):
                    if color & (1 << plane_index):
                        packed[plane_index] |= mask
            for plane_index in range(3):
                output_planes[plane_index][row_byte + byte_x] = packed[plane_index]

    result = bytearray()
    for plane in output_planes:
        result.extend(plane)
    for source_index in SELECTED_SOURCE_COLORS:
        red, green, blue = palette16[source_index]
        # STAFF.DLL's 8-color loader stores ready-to-output VGA DAC values.
        result.extend((red << 2, green << 2, blue << 2, 0))
    stf = bytes(result)
    if len(stf) != OUTPUT_EXPECTED_SIZE:
        raise PatchError("ED19.STF 생성 크기가 예상과 다릅니다.")
    if sha256(stf) != OUTPUT_EXPECTED_SHA256:
        raise PatchError("ED19.STF 생성 결과 해시가 예상과 다릅니다.")

    info = {
        "source_file": SOURCE_NAME,
        "source_size": len(source),
        "source_sha256": sha256(source),
        "output_file": OUTPUT_NAME,
        "output_size": len(stf),
        "output_sha256": sha256(stf),
        "staff_format": "640x400, 3 planes, 8-color palette",
        "source_scene": "640x240, 4 planes, 16 colors",
        "placement": {"x": 0, "y": CENTER_Y, "width": WIDTH, "height": SOURCE_HEIGHT},
        "palette_source_indices": list(SELECTED_SOURCE_COLORS),
        "palette_policy": "exact original G_ED1900 colors; optimized 8-color subset; staff lettering is drawn separately in white",
        "source_color_counts": source_counts,
        "output_color_counts": output_counts,
        "source_to_output_map": mapping,
    }
    return stf, info


def validate_staff(staff: Path) -> tuple[bytes, bytes, bytes]:
    data = staff.read_bytes()
    if len(data) != STAFF_EXPECTED_SIZE:
        raise PatchError(f"STAFF.DLL 크기가 지원되는 한국어판과 다릅니다: {len(data)} bytes")
    if data[:2] != b"MZ":
        raise PatchError("STAFF.DLL이 MZ/NE 모듈이 아닙니다.")
    final_name = data[FINAL_STAFF_NAME_OFFSET:FINAL_STAFF_NAME_OFFSET + 4]
    if final_name not in (FINAL_STAFF_NAME_RETAIL, FINAL_STAFF_NAME_OLD_ES02, FINAL_STAFF_NAME_NEW):
        raise PatchError("STAFF.DLL의 실제 마지막 배경 항목(_GRP[12])이 예상과 다릅니다: " + repr(final_name))
    ad_path = data[AD_FINAL_PATH_OFFSET:AD_FINAL_PATH_OFFSET + len(AD_FINAL_PATH_RETAIL)]
    if ad_path not in (AD_FINAL_PATH_RETAIL, AD_FINAL_PATH_OLD_OP32, AD_FINAL_PATH_OLD_ED19):
        raise PatchError("STAFF.DLL의 광고 화면 표가 예상과 다릅니다: " + repr(ad_path))
    return data, final_name, ad_path


def write_generated_asset(output: Path, stf: bytes) -> dict[str, object]:
    existing = output.read_bytes() if output.exists() else None
    if existing == stf:
        return {"status": "already_generated", "target": str(output), "backup": None, "output_sha256": sha256(stf)}
    backup: Path | None = None
    if existing is not None:
        backup = output.with_name(output.name + OUTPUT_BACKUP_SUFFIX)
        if not backup.exists():
            shutil.copy2(output, backup)
    atomic_write(output, stf)
    if output.read_bytes() != stf:
        if existing is None:
            try:
                output.unlink()
            except OSError:
                pass
        else:
            atomic_write(output, existing)
        raise PatchError("ED19.STF 저장 후 검증에 실패해 이전 상태로 되돌렸습니다.")
    return {"status": "generated", "target": str(output), "backup": str(backup) if backup else None, "output_sha256": sha256(stf)}


def patch_staff(staff: Path, original: bytes, final_name: bytes, ad_path: bytes) -> dict[str, object]:
    data = bytearray(original)
    data[FINAL_STAFF_NAME_OFFSET:FINAL_STAFF_NAME_OFFSET + 4] = FINAL_STAFF_NAME_NEW
    data[AD_FINAL_PATH_OFFSET:AD_FINAL_PATH_OFFSET + len(AD_FINAL_PATH_RETAIL)] = AD_FINAL_PATH_RETAIL
    patched = bytes(data)
    if patched == original:
        return {
            "status": "already_patched",
            "target": str(staff),
            "backup": None,
            "input_sha256": sha256(original),
            "output_sha256": sha256(original),
            "staff_final_background": "grp\\ed19.stf",
            "advertisement_final_restored": "grp\\op06.STF",
            "changed_offsets": [],
        }
    changed = [index for index, (before, after) in enumerate(zip(original, patched)) if before != after]
    allowed = set(range(FINAL_STAFF_NAME_OFFSET, FINAL_STAFF_NAME_OFFSET + 4)) | set(
        range(AD_FINAL_PATH_OFFSET, AD_FINAL_PATH_OFFSET + len(AD_FINAL_PATH_RETAIL))
    )
    if any(index not in allowed for index in changed):
        raise PatchError("STAFF.DLL 변경 범위 검증에 실패했습니다.")
    backup = staff.with_name(staff.name + STAFF_BACKUP_SUFFIX)
    if not backup.exists():
        shutil.copy2(staff, backup)
    atomic_write(staff, patched)
    if staff.read_bytes() != patched:
        atomic_write(staff, original)
        raise PatchError("STAFF.DLL 저장 후 검증에 실패해 이전 상태로 되돌렸습니다.")
    return {
        "status": "patched",
        "target": str(staff),
        "backup": str(backup),
        "input_sha256": sha256(original),
        "output_sha256": sha256(patched),
        "input_staff_final_name": final_name.decode("ascii"),
        "staff_final_background": "grp\\ed19.stf",
        "input_advertisement_final": ad_path.decode("ascii"),
        "advertisement_final_restored": "grp\\op06.STF",
        "changed_offsets": [f"0x{offset:08X}" for offset in changed],
    }


def apply_patch(path: Path) -> dict[str, object]:
    folder = resolve_game_folder(path)
    ending, staff, source, output = resolve_game_files(folder)
    stf, conversion_info = build_centered_staff_stf(source.read_bytes())
    staff_original, final_name, ad_path = validate_staff(staff)

    ending_report = freya.apply_patch(ending)
    asset_report = write_generated_asset(output, stf)
    staff_report = patch_staff(staff, staff_original, final_name, ad_path)

    status = "already_patched"
    if ending_report["status"] != "already_patched" or asset_report["status"] != "already_generated" or staff_report["status"] != "already_patched":
        status = "patched"
    report = {
        "tool": APP,
        "version": VERSION,
        "status": status,
        "selected_folder": str(path.expanduser().resolve()),
        "resolved_game_folder": str(folder),
        "basis": "Freya v5.0.0 Fresh Page Only",
        "ending": ending_report,
        "staff": staff_report,
        "generated_asset": asset_report,
        "conversion": conversion_info,
        "scope": {
            "freya": "v5.0.0 unchanged",
            "actual_staff_final_table": "_GRP[12] os11 -> ed19",
            "unrelated_advertisement_table": "restored/kept as grp\\op06.STF",
            "scene_centered": "G_ED1900 rows 0..239 -> staff rows 80..319",
            "narration_modified": False,
            "ending_flow_modified": False,
            "staff_timing_modified": False,
        },
    }
    (folder / REPORT_NAME).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def gui() -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox
    root = tk.Tk()
    root.withdraw()
    try:
        folder = filedialog.askdirectory(title="영웅전설 II 한국어판 게임 폴더 선택")
        if not folder:
            return 0
        if not messagebox.askyesno(
            APP + " v" + VERSION,
            "다음 항목만 수정합니다.\n\n"
            "1. 프레이아: 검증된 v5.0.0 방식 유지\n"
            "2. 실제 스태프롤 마지막 배경: OS11 -> G_ED1900\n"
            "3. G_ED1900 화면을 640x400 중앙(Y=80)에 배치\n"
            "4. 마지막 배경 팔레트를 G_ED1900 원본 색으로 변경\n\n"
            "나레이션과 엔딩 흐름은 수정하지 않습니다.\n계속할까요?",
        ):
            return 0
        report = apply_patch(Path(folder))
        if report["status"] == "already_patched":
            messagebox.showinfo(APP, "이미 같은 수정이 적용되어 있습니다.")
        else:
            messagebox.showinfo(APP, "패치를 적용했습니다.\n\n프레이아: v5.0.0 유지\n마지막 배경: 중앙 정렬 G_ED1900\n나레이션: 변경 없음")
        return 0
    except Exception as exc:
        messagebox.showerror(APP, str(exc))
        return 1
    finally:
        root.destroy()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=APP)
    parser.add_argument("path", nargs="?", help="ED2 게임 폴더, ENDING.DLL 또는 STAFF.DLL")
    args = parser.parse_args(argv)
    if args.path is None:
        return gui()
    try:
        print(json.dumps(apply_patch(Path(args.path)), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
