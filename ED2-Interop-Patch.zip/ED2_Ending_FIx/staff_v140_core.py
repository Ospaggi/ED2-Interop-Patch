#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from pathlib import Path
import struct

import staff_v130_core as legacy

APP = "ED2 Persistent ED19 4-Plane Staff Roll"
VERSION = "1.4.0"
STAFF_EXPECTED_SIZE = legacy.STAFF_EXPECTED_SIZE
STAFF_RETAIL_SHA256 = legacy.STAFF_RETAIL_SHA256
SOURCE_NAME = legacy.SOURCE_NAME
OUTPUT_NAME = legacy.OUTPUT_NAME
HELPER_NAME = "E419.STF"
WIDTH = legacy.WIDTH
SOURCE_HEIGHT = legacy.SOURCE_HEIGHT
STAFF_HEIGHT = legacy.STAFF_HEIGHT
CENTER_Y = legacy.CENTER_Y
ROW_BYTES = legacy.ROW_BYTES
STAFF_PLANE_BYTES = legacy.STAFF_PLANE_BYTES

ED19_EXPECTED_SIZE = STAFF_PLANE_BYTES * 4 + 16 * 4
ED19_EXPECTED_SHA256 = "a296265fb1dc3a874007fa52f5fdad22a7c9e38f0e0acbff292c777cfd75884c"
E419_EXPECTED_SIZE = STAFF_PLANE_BYTES * 3 + 8 * 4
E419_EXPECTED_SHA256 = "f4dad333b68b680907ba634a39fa2b7a0d624e20222d78f7a347d8f45adda995"
OLD_ED19_3PLANE_SHA256 = legacy.OUTPUT_EXPECTED_SHA256

SEG3 = 3
SEG5 = 5
SEG3_RETAIL_LENGTH = 0x10A6
SEG3_NEW_LENGTH = 0x11E9
SEG5_RETAIL_LENGTH = 0x118C
SEG5_NEW_LENGTH = 0x1207
SEG3_RELOC_COUNT = 66
SEG5_RELOC_COUNT = 118
SEG3_RELOC_SHA256 = "21069b354069597391d7aa99d5484a9b246362a7fdd5b6df2b313079b231d55d"
SEG5_RELOC_SHA256 = "826cd4c911dabc39ce2eef4610358f42a32c3983f4ed7c840c77500d4662d49c"
SEG3_HELPER_OFFSET = SEG3_RETAIL_LENGTH
SEG5_HELPER_OFFSET = SEG5_RETAIL_LENGTH
SEG3_HELPER_SHA256 = "bf59b0f9d17df4257e898e930ba328bc26b7c68da23cfa89f478076f850ce5ac"
SEG5_HELPER_SHA256 = "f6c44b116d5ffa54ce9f939810fabb5451dbf15eb98a185dd5f9664a47f9b099"

# Retail -> 4-plane patches, segment-relative.
SEG3_BLITTER_SITE = 0x0655
SEG3_BLITTER_RETAIL = bytes.fromhex("83 EC 16 56 57")
SEG5_FADE_SITE = 0x0281
SEG5_FADE_RETAIL_PREFIX = bytes.fromhex("B8 FF FF")
SEG5_PRELOAD_LIMIT_SITE = 0x051B
SEG5_PRELOAD_LIMIT_RETAIL = 0x0D
SEG5_INIT_SITE = 0x0CD1
SEG5_INIT_RETAIL = bytes.fromhex("0E E8 47 F7")
SEG5_SKIP_SWAP_SITE = 0x0CD8
SEG5_SKIP_SWAP_TARGET = 0x0D6B

SEG32_BASE = 0x182800
SLOT1_OFFSET = SEG32_BASE + 0x0731
SLOT2_OFFSET = SEG32_BASE + 0x0736
FINAL_OFFSET = legacy.FINAL_STAFF_NAME_OFFSET
AD_OFFSET = legacy.AD_FINAL_PATH_OFFSET

SLOT1_RETAIL = b"es01"
SLOT2_RETAIL = b"es04"
SLOT1_NEW = b"ed19"
SLOT2_NEW = b"e419"
FINAL_ALLOWED = (b"os11", b"es02", b"ed19")
AD_ALLOWED = (legacy.AD_FINAL_PATH_RETAIL, legacy.AD_FINAL_PATH_OLD_OP32, legacy.AD_FINAL_PATH_OLD_ED19)

class PatchError(RuntimeError):
    pass

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _helper(name: str, expected_sha: str) -> bytes:
    data = (Path(__file__).with_name(name)).read_bytes()
    if sha256(data) != expected_sha:
        raise PatchError(f"{name} 도우미 해시가 예상과 다릅니다.")
    return data

def resolve_game_folder(path: Path) -> Path:
    return legacy.resolve_game_folder(path)

def resolve_game_files(folder: Path) -> tuple[Path, Path, Path, Path, Path]:
    ending, staff, source, ed19 = legacy.resolve_game_files(folder)
    grp = source.parent
    existing = legacy.find_child_case_insensitive(grp, HELPER_NAME)
    e419 = existing if existing is not None else grp / HELPER_NAME
    return ending, staff, source, ed19, e419

def build_staff_assets(source: bytes) -> tuple[bytes, bytes, dict[str, object]]:
    planes, palette = legacy.decode_g_ed1900(source)
    centered: list[bytes] = []
    start = CENTER_Y * ROW_BYTES
    for plane in planes:
        dst = bytearray(STAFF_PLANE_BYTES)
        dst[start:start + len(plane)] = plane
        centered.append(bytes(dst))

    ed19 = bytearray()
    for plane in centered:
        ed19.extend(plane)
    # The 4-plane init helper converts these original 4-bit DAC components to
    # the VGA DAC range; preserve all 16 source palette entries exactly.
    for red, green, blue in palette:
        ed19.extend((red, green, blue, 0))
    ed19_b = bytes(ed19)

    # The retail 3-plane preloader can fetch only three planes.  Slot 2 is a
    # carrier whose first plane is ED19 plane 3; the init helper maps it to VGA
    # plane 3 once at staff-roll startup.
    e419_b = centered[3] + bytes(STAFF_PLANE_BYTES * 2 + 32)
    if len(ed19_b) != ED19_EXPECTED_SIZE or sha256(ed19_b) != ED19_EXPECTED_SHA256:
        raise PatchError("4-plane ED19.STF 생성 결과가 예상과 다릅니다.")
    if len(e419_b) != E419_EXPECTED_SIZE or sha256(e419_b) != E419_EXPECTED_SHA256:
        raise PatchError("E419.STF 생성 결과가 예상과 다릅니다.")
    return ed19_b, e419_b, {
        "source": SOURCE_NAME,
        "source_sha256": sha256(source),
        "source_scene": "640x240 / 4 planes / 16 colors",
        "placement": {"x": 0, "y": CENTER_Y, "width": WIDTH, "height": SOURCE_HEIGHT},
        "ED19.STF": {"size": len(ed19_b), "sha256": sha256(ed19_b), "format": "640x400 / 4 planes / 16 original palette entries"},
        "E419.STF": {"size": len(e419_b), "sha256": sha256(e419_b), "purpose": "retail preloader carrier for ED19 plane 3"},
        "palette": [list(c) for c in palette],
        "text_color_index": 8,
        "text_compositor": "restore ED19 4-plane background under moving text; mask pixels become source palette index 8",
    }

def _ne(data: bytes) -> tuple[int, int, int, int]:
    if len(data) != STAFF_EXPECTED_SIZE or data[:2] != b"MZ":
        raise PatchError("STAFF.DLL 크기 또는 MZ 헤더가 예상과 다릅니다.")
    ne = int.from_bytes(data[0x3C:0x40], "little")
    if data[ne:ne+2] != b"NE":
        raise PatchError("STAFF.DLL이 NE 모듈이 아닙니다.")
    shift = int.from_bytes(data[ne+0x32:ne+0x34], "little")
    table = ne + int.from_bytes(data[ne+0x22:ne+0x24], "little")
    count = int.from_bytes(data[ne+0x1C:ne+0x1E], "little")
    return ne, shift, table, count

def segment_info(data: bytes, index: int) -> dict[str, int]:
    _ne_off, shift, table, count = _ne(data)
    if not (1 <= index <= count):
        raise PatchError("STAFF.DLL 세그먼트 번호가 범위를 벗어났습니다.")
    entry = table + (index - 1) * 8
    sector = int.from_bytes(data[entry:entry+2], "little")
    length = int.from_bytes(data[entry+2:entry+4], "little") or 0x10000
    minalloc = int.from_bytes(data[entry+6:entry+8], "little") or 0x10000
    flags = int.from_bytes(data[entry+4:entry+6], "little")
    return {"entry": entry, "file_offset": sector << shift, "length": length, "minalloc": minalloc, "flags": flags}

def relocation_blob(data: bytes, seg: dict[str, int]) -> bytes:
    start = seg["file_offset"] + seg["length"]
    count = int.from_bytes(data[start:start+2], "little")
    end = start + 2 + count * 8
    if end > len(data):
        raise PatchError("STAFF.DLL 재배치 표가 잘렸습니다.")
    return data[start:end]

def _verify_reloc(data: bytes, index: int, count: int, expected_sha: str) -> None:
    seg = segment_info(data, index)
    blob = relocation_blob(data, seg)
    if int.from_bytes(blob[:2], "little") != count or sha256(blob) != expected_sha:
        raise PatchError(f"STAFF.DLL segment {index} 재배치 표가 예상과 다릅니다.")

def _extend_segment(buf: bytearray, index: int, helper: bytes, old_len: int, new_len: int) -> None:
    data = bytes(buf)
    _ne_off, shift, table, count = _ne(data)
    seg = segment_info(data, index)
    if seg["length"] != old_len or seg["minalloc"] != old_len:
        raise PatchError(f"STAFF.DLL segment {index} 길이가 retail 기준과 다릅니다.")
    entry = seg["entry"]
    old_reloc = seg["file_offset"] + old_len
    blob = relocation_blob(data, seg)
    next_entry = table + index * 8
    if index >= count:
        next_offset = len(buf)
    else:
        next_offset = int.from_bytes(buf[next_entry:next_entry+2], "little") << shift
    if seg["file_offset"] + new_len + len(blob) > next_offset:
        raise PatchError(f"STAFF.DLL segment {index} 확장 공간이 부족합니다.")
    if len(helper) != new_len - old_len:
        raise PatchError(f"STAFF.DLL segment {index} 도우미 길이가 예상과 다릅니다.")
    buf[old_reloc:old_reloc+len(helper)] = helper
    new_reloc = seg["file_offset"] + new_len
    buf[new_reloc:new_reloc+len(blob)] = blob
    end = new_reloc + len(blob)
    buf[end:next_offset] = b"\0" * (next_offset - end)
    buf[entry+2:entry+4] = new_len.to_bytes(2, "little")
    buf[entry+6:entry+8] = new_len.to_bytes(2, "little")

def is_new_staff(data: bytes) -> bool:
    try:
        s3 = segment_info(data, SEG3); s5 = segment_info(data, SEG5)
        if (s3["length"], s3["minalloc"], s5["length"], s5["minalloc"]) != (SEG3_NEW_LENGTH, SEG3_NEW_LENGTH, SEG5_NEW_LENGTH, SEG5_NEW_LENGTH):
            return False
        _verify_reloc(data, SEG3, SEG3_RELOC_COUNT, SEG3_RELOC_SHA256)
        _verify_reloc(data, SEG5, SEG5_RELOC_COUNT, SEG5_RELOC_SHA256)
        if sha256(data[s3["file_offset"]+SEG3_HELPER_OFFSET:s3["file_offset"]+SEG3_NEW_LENGTH]) != SEG3_HELPER_SHA256:
            return False
        if sha256(data[s5["file_offset"]+SEG5_HELPER_OFFSET:s5["file_offset"]+SEG5_NEW_LENGTH]) != SEG5_HELPER_SHA256:
            return False
        if data[SLOT1_OFFSET:SLOT1_OFFSET+4] != SLOT1_NEW or data[SLOT2_OFFSET:SLOT2_OFFSET+4] != SLOT2_NEW:
            return False
        if data[FINAL_OFFSET:FINAL_OFFSET+4] != b"ed19" or data[AD_OFFSET:AD_OFFSET+len(legacy.AD_FINAL_PATH_RETAIL)] != legacy.AD_FINAL_PATH_RETAIL:
            return False
        b3=s3["file_offset"]; b5=s5["file_offset"]
        j3 = b"\xE9" + struct.pack("<H", (SEG3_HELPER_OFFSET - (SEG3_BLITTER_SITE + 3)) & 0xFFFF) + b"\x90\x90"
        if data[b3+SEG3_BLITTER_SITE:b3+SEG3_BLITTER_SITE+5] != j3: return False
        if data[b5+SEG5_FADE_SITE] != 0xCB or data[b5+SEG5_PRELOAD_LIMIT_SITE] != 0x03: return False
        j5 = b"\xE9" + struct.pack("<H", (SEG5_HELPER_OFFSET-(SEG5_INIT_SITE+3))&0xFFFF) + b"\x90"
        if data[b5+SEG5_INIT_SITE:b5+SEG5_INIT_SITE+4] != j5: return False
        js = b"\xE9" + struct.pack("<H", (SEG5_SKIP_SWAP_TARGET-(SEG5_SKIP_SWAP_SITE+3))&0xFFFF)
        if data[b5+SEG5_SKIP_SWAP_SITE:b5+SEG5_SKIP_SWAP_SITE+3] != js: return False
        return True
    except Exception:
        return False

def patch_staff(original: bytes) -> tuple[bytes, dict[str, object]]:
    if is_new_staff(original):
        return original, {"state_before": "already_v1.4.0_4plane", "changed": False, "output_sha256": sha256(original)}
    if len(original) != STAFF_EXPECTED_SIZE:
        raise PatchError("STAFF.DLL 크기가 지원되는 한국어판과 다릅니다.")
    s3 = segment_info(original, SEG3); s5 = segment_info(original, SEG5)
    if s3["length"] != SEG3_RETAIL_LENGTH or s3["minalloc"] != SEG3_RETAIL_LENGTH or s5["length"] != SEG5_RETAIL_LENGTH or s5["minalloc"] != SEG5_RETAIL_LENGTH:
        raise PatchError("STAFF.DLL이 지원되는 순정/v1.3.x 상태 또는 새 v1.4.0 상태가 아닙니다.")
    _verify_reloc(original, SEG3, SEG3_RELOC_COUNT, SEG3_RELOC_SHA256)
    _verify_reloc(original, SEG5, SEG5_RELOC_COUNT, SEG5_RELOC_SHA256)
    final = original[FINAL_OFFSET:FINAL_OFFSET+4]
    ad = original[AD_OFFSET:AD_OFFSET+len(legacy.AD_FINAL_PATH_RETAIL)]
    if final not in FINAL_ALLOWED or ad not in AD_ALLOWED:
        raise PatchError("STAFF.DLL 배경 테이블이 알려진 상태와 다릅니다.")
    slot1=original[SLOT1_OFFSET:SLOT1_OFFSET+4]; slot2=original[SLOT2_OFFSET:SLOT2_OFFSET+4]
    if slot1 != SLOT1_RETAIL or slot2 != SLOT2_RETAIL:
        raise PatchError("STAFF.DLL 스태프롤 첫 배경 슬롯이 알려진 순정 상태와 다릅니다.")
    b = bytearray(original); b3=s3["file_offset"]; b5=s5["file_offset"]
    if b[b3+SEG3_BLITTER_SITE:b3+SEG3_BLITTER_SITE+5] != SEG3_BLITTER_RETAIL: raise PatchError("STAFF.DLL 문자 블리터 진입부가 예상과 다릅니다.")
    if b[b5+SEG5_FADE_SITE:b5+SEG5_FADE_SITE+3] != SEG5_FADE_RETAIL_PREFIX: raise PatchError("STAFF.DLL 팔레트 페이드 코드가 예상과 다릅니다.")
    if b[b5+SEG5_PRELOAD_LIMIT_SITE] != SEG5_PRELOAD_LIMIT_RETAIL: raise PatchError("STAFF.DLL 이미지 preload 루프가 예상과 다릅니다.")
    if b[b5+SEG5_INIT_SITE:b5+SEG5_INIT_SITE+4] != SEG5_INIT_RETAIL: raise PatchError("STAFF.DLL 스태프롤 초기화 코드가 예상과 다릅니다.")

    h3=_helper("staff_v140_seg3_comp.bin", SEG3_HELPER_SHA256)
    h5=_helper("staff_v140_seg5_init.bin", SEG5_HELPER_SHA256)
    b[b3+SEG3_BLITTER_SITE:b3+SEG3_BLITTER_SITE+5] = b"\xE9" + struct.pack("<H", (SEG3_HELPER_OFFSET-(SEG3_BLITTER_SITE+3))&0xFFFF) + b"\x90\x90"
    _extend_segment(b, SEG3, h3, SEG3_RETAIL_LENGTH, SEG3_NEW_LENGTH)

    # Segment offsets do not move, so retail segment-5 base remains valid.
    b[b5+SEG5_PRELOAD_LIMIT_SITE] = 0x03
    b[b5+SEG5_FADE_SITE] = 0xCB
    b[b5+SEG5_INIT_SITE:b5+SEG5_INIT_SITE+4] = b"\xE9" + struct.pack("<H", (SEG5_HELPER_OFFSET-(SEG5_INIT_SITE+3))&0xFFFF) + b"\x90"
    b[b5+SEG5_SKIP_SWAP_SITE:b5+SEG5_SKIP_SWAP_SITE+3] = b"\xE9" + struct.pack("<H", (SEG5_SKIP_SWAP_TARGET-(SEG5_SKIP_SWAP_SITE+3))&0xFFFF)
    _extend_segment(b, SEG5, h5, SEG5_RETAIL_LENGTH, SEG5_NEW_LENGTH)

    b[SLOT1_OFFSET:SLOT1_OFFSET+4]=SLOT1_NEW
    b[SLOT2_OFFSET:SLOT2_OFFSET+4]=SLOT2_NEW
    b[FINAL_OFFSET:FINAL_OFFSET+4]=b"ed19"
    b[AD_OFFSET:AD_OFFSET+len(legacy.AD_FINAL_PATH_RETAIL)] = legacy.AD_FINAL_PATH_RETAIL
    out=bytes(b)
    if not is_new_staff(out):
        raise PatchError("새 4-plane STAFF.DLL 최종 검증에 실패했습니다.")
    return out, {
        "state_before": "retail_or_v1.3.x_3plane",
        "changed": True,
        "input_sha256": sha256(original),
        "output_sha256": sha256(out),
        "segments": {"3": {"length": hex(SEG3_NEW_LENGTH), "relocation_sha256": SEG3_RELOC_SHA256}, "5": {"length": hex(SEG5_NEW_LENGTH), "relocation_sha256": SEG5_RELOC_SHA256}},
        "background_slots": {"slot1": "ed19", "slot2": "e419", "intermediate_swaps": "skipped"},
        "palette_fades": "staff-roll background fades disabled; advertisement path unchanged",
        "4bpp": "all four ED19 planes retained; text composited over/restored from static ED19",
    }
