#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

import staff_v130_core as staff_core
import staff_v140_core as staff_v140
import narration_script_core as narration_core

APP = "ED2 Freya + Stable 3-Plane Staff Roll Rollback + Narration"
VERSION = "1.6.6"
REPORT_NAME = "ED2_FREYA_G_ED1900_NARRATION_V166.json"
ENDING_BACKUP_SUFFIX = ".before_combined_v166.bak"
STAFF_BACKUP_SUFFIX = ".before_combined_v166.bak"
ASSET_BACKUP_SUFFIX = ".before_combined_v166.bak"

# v1.4.0 delay experiment normalization. This combined build is explicitly based
# on v1.3.0, so a recognized v1.4.0 helper is removed instead of retained.
STAFF_CODE_SEGMENT = 5
STAFF_CODE_RETAIL_LENGTH = 0x118C
STAFF_CODE_DELAY_LENGTH = 0x119B
STAFF_CODE_RETAIL_MINALLOC = 0x118C
STAFF_CODE_DELAY_MINALLOC = 0x119B
STAFF_LOOP_ENTRY_PATCH_OFFSET = 0x0CD5
STAFF_LOOP_ENTRY_RETAIL = bytes.fromhex("E9 DC 03")
STAFF_DELAY_HELPER_OFFSET = 0x118C
STAFF_DELAY_HELPER_SIZE = 15
STAFF_RELOCATION_COUNT = 118
STAFF_RELOCATION_SHA256 = "826cd4c911dabc39ce2eef4610358f42a32c3983f4ed7c840c77500d4662d49c"


class PatchError(RuntimeError):
    pass


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _cp949(text: str) -> bytes:
    return text.encode("cp949")


ENDING_FLORA_SLOT_OFFSET = 0x03EE82
ENDING_FLORA_SLOT_CAPACITY = 53
ENDING_FLORA_CODE_OFFSET = 0x03D2BD
ENDING_FLORA_CODE = bytes.fromhex("BE 9C 02")
ENDING_FLORA_R25 = (
    b"\x05\x01" + _cp949("당신이 저를 찾는 한. ") + b"\x09\x03"
    + _cp949("플로라  ") + _cp949("저기요, 아트라스님.") + b" "
)
ENDING_FLORA_R26 = (
    b"\x05\x01" + _cp949("당신이 저를 찾는 한.   ") + b"\x09\x03"
    + _cp949("플로라  ") + _cp949("저기요, 아트라스님")
)


def normalize_flora_speaker_anchor(data: bytes) -> tuple[bytes, dict[str, object]]:
    """Repair the R25 Flora-name shift while preserving ENDING's SI=029Ch call."""
    if data[ENDING_FLORA_CODE_OFFSET:ENDING_FLORA_CODE_OFFSET + 3] != ENDING_FLORA_CODE:
        raise PatchError("ENDING.DLL의 프레이아 이후 플로라 화자 호출 코드가 예상과 다릅니다.")
    start = ENDING_FLORA_SLOT_OFFSET
    end = start + ENDING_FLORA_SLOT_CAPACITY
    slot = data[start:end]
    if slot == ENDING_FLORA_R26:
        return data, {"state_before": "r26_anchor", "changed": False, "speaker_offset": "0x029C"}
    if slot == ENDING_FLORA_R25:
        out = bytearray(data); out[start:end] = ENDING_FLORA_R26
        return bytes(out), {"state_before": "r25_shifted_anchor", "changed": True, "speaker_offset": "0x029C"}
    # Older retail/R24 text already places 03h at the correct 029Ch.  Do not
    # rewrite its wording here; only reject a structurally broken speaker start.
    speaker = start + 26
    if data[speaker:speaker + 1] != b"\x03" or data[speaker + 1:speaker + 9] != _cp949("플로라  "):
        raise PatchError("ENDING.DLL의 프레이아 이후 플로라 화자명 시작 위치가 예상과 다릅니다.")
    return data, {"state_before": "legacy_anchor_ok", "changed": False, "speaker_offset": "0x029C"}


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def ne_segment_info(data: bytes, index: int) -> dict[str, int]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("STAFF.DLL이 MZ 실행 파일이 아닙니다.")
    ne = int.from_bytes(data[0x3C:0x40], "little")
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise PatchError("STAFF.DLL이 NE 모듈이 아닙니다.")
    count = int.from_bytes(data[ne + 0x1C:ne + 0x1E], "little")
    if not (1 <= index <= count):
        raise PatchError("STAFF.DLL 세그먼트 번호가 범위를 벗어났습니다.")
    shift = int.from_bytes(data[ne + 0x32:ne + 0x34], "little")
    table = ne + int.from_bytes(data[ne + 0x22:ne + 0x24], "little")
    entry = table + (index - 1) * 8
    sector = int.from_bytes(data[entry:entry + 2], "little")
    raw_length = int.from_bytes(data[entry + 2:entry + 4], "little")
    raw_minalloc = int.from_bytes(data[entry + 6:entry + 8], "little")
    return {
        "entry": entry,
        "file_offset": sector << shift,
        "length": raw_length or 0x10000,
        "minalloc": raw_minalloc or 0x10000,
        "flags": int.from_bytes(data[entry + 4:entry + 6], "little"),
    }


def relocation_blob(data: bytes, segment: dict[str, int]) -> bytes:
    if not (segment["flags"] & 0x0100):
        raise PatchError("STAFF.DLL segment 5에 재배치 표가 없습니다.")
    start = segment["file_offset"] + segment["length"]
    if start + 2 > len(data):
        raise PatchError("STAFF.DLL 재배치 표가 잘렸습니다.")
    count = int.from_bytes(data[start:start + 2], "little")
    end = start + 2 + count * 8
    if end > len(data):
        raise PatchError("STAFF.DLL 재배치 표가 파일 범위를 벗어납니다.")
    return data[start:end]


def build_delay_helper(delay_ticks: int) -> bytes:
    helper = bytearray()
    helper += b"\x6A\x00"
    helper += b"\x68" + delay_ticks.to_bytes(2, "little")
    helper += b"\x0E"
    call_next = STAFF_DELAY_HELPER_OFFSET + len(helper) + 3
    helper += b"\xE8" + ((0x0204 - call_next) & 0xFFFF).to_bytes(2, "little")
    helper += b"\x83\xC4\x04"
    jump_next = STAFF_DELAY_HELPER_OFFSET + len(helper) + 3
    helper += b"\xE9" + ((0x10B4 - jump_next) & 0xFFFF).to_bytes(2, "little")
    if len(helper) != STAFF_DELAY_HELPER_SIZE:
        raise PatchError("내부 오류: v1.4.0 도우미 길이가 다릅니다.")
    return bytes(helper)


def parse_delay_helper(data: bytes, segment: dict[str, int]) -> int | None:
    if segment["length"] != STAFF_CODE_DELAY_LENGTH:
        return None
    base = segment["file_offset"] + STAFF_DELAY_HELPER_OFFSET
    helper = data[base:base + STAFF_DELAY_HELPER_SIZE]
    if len(helper) != STAFF_DELAY_HELPER_SIZE:
        return None
    expected = bytearray(build_delay_helper(0))
    actual = bytearray(helper)
    expected[3:5] = actual[3:5]
    if actual != expected:
        return None
    return int.from_bytes(helper[3:5], "little")


def normalize_staff_timing_to_v130(data: bytes) -> tuple[bytes, dict[str, object]]:
    segment = ne_segment_info(data, STAFF_CODE_SEGMENT)
    base = segment["file_offset"]
    site = base + STAFF_LOOP_ENTRY_PATCH_OFFSET
    reloc = relocation_blob(data, segment)
    if int.from_bytes(reloc[:2], "little") != STAFF_RELOCATION_COUNT:
        raise PatchError("STAFF.DLL segment 5 재배치 레코드 수가 예상과 다릅니다.")
    if sha256(reloc) != STAFF_RELOCATION_SHA256:
        raise PatchError("STAFF.DLL segment 5 재배치 표가 알려진 한국어판과 다릅니다.")

    if segment["length"] == STAFF_CODE_RETAIL_LENGTH:
        if segment["minalloc"] != STAFF_CODE_RETAIL_MINALLOC:
            raise PatchError("STAFF.DLL segment 5 최소 할당량이 v1.3.0과 다릅니다.")
        if data[site:site + 3] != STAFF_LOOP_ENTRY_RETAIL:
            raise PatchError("STAFF.DLL 스태프롤 진입 코드가 v1.3.0과 다릅니다.")
        return data, {"state_before": "v1.3.0_no_delay", "removed_delay_seconds": 0.0}

    if segment["length"] != STAFF_CODE_DELAY_LENGTH:
        raise PatchError(f"STAFF.DLL segment 5 길이가 지원되지 않습니다: 0x{segment['length']:04X}")
    ticks = parse_delay_helper(data, segment)
    helper_jump = b"\xE9" + ((STAFF_DELAY_HELPER_OFFSET - (STAFF_LOOP_ENTRY_PATCH_OFFSET + 3)) & 0xFFFF).to_bytes(2, "little")
    if segment["minalloc"] != STAFF_CODE_DELAY_MINALLOC or ticks is None or data[site:site + 3] != helper_jump:
        raise PatchError("STAFF.DLL의 v1.4.0 지연 도우미가 예상과 다릅니다.")

    patched = bytearray(data)
    old_reloc_start = base + STAFF_CODE_DELAY_LENGTH
    new_reloc_start = base + STAFF_CODE_RETAIL_LENGTH
    patched[new_reloc_start:new_reloc_start + len(reloc)] = reloc
    # v1.4.0 shifted the table by exactly 15 bytes into zero padding.
    patched[new_reloc_start + len(reloc):old_reloc_start + len(reloc)] = b"\0" * STAFF_DELAY_HELPER_SIZE
    patched[site:site + 3] = STAFF_LOOP_ENTRY_RETAIL
    entry = segment["entry"]
    patched[entry + 2:entry + 4] = STAFF_CODE_RETAIL_LENGTH.to_bytes(2, "little")
    patched[entry + 6:entry + 8] = STAFF_CODE_RETAIL_MINALLOC.to_bytes(2, "little")
    result = bytes(patched)

    check = ne_segment_info(result, STAFF_CODE_SEGMENT)
    if check["length"] != STAFF_CODE_RETAIL_LENGTH or check["minalloc"] != STAFF_CODE_RETAIL_MINALLOC:
        raise PatchError("v1.4.0 지연 제거 후 세그먼트 길이 검증에 실패했습니다.")
    if result[check["file_offset"] + STAFF_LOOP_ENTRY_PATCH_OFFSET:check["file_offset"] + STAFF_LOOP_ENTRY_PATCH_OFFSET + 3] != STAFF_LOOP_ENTRY_RETAIL:
        raise PatchError("v1.4.0 지연 제거 후 진입 코드 검증에 실패했습니다.")
    if sha256(relocation_blob(result, check)) != STAFF_RELOCATION_SHA256:
        raise PatchError("v1.4.0 지연 제거 후 재배치 표 검증에 실패했습니다.")
    return result, {
        "state_before": "v1.4.0_delay_helper",
        "removed_delay_ticks": ticks,
        "removed_delay_seconds": ticks / 256.0,
        "state_after": "v1.3.0_no_delay",
    }



STAFF_V130_STABLE_SHA256 = "a479f4d33768221e8e186011701f3ace1e34661b341c5fb8879260a2490c7095"
OLD_V140_HELPER_NAME = "E419.STF"
OLD_V140_HELPER_SHA256 = staff_v140.E419_EXPECTED_SHA256


def _shrink_v140_segment(buf: bytearray, index: int, current_len: int, retail_len: int) -> None:
    data = bytes(buf)
    seg = staff_v140.segment_info(data, index)
    if seg["length"] != current_len or seg["minalloc"] != current_len:
        raise PatchError(f"STAFF.DLL segment {index} 길이가 v1.3.98~v1.3.99 4bpp 상태와 다릅니다.")
    blob = staff_v140.relocation_blob(data, seg)
    next_seg = staff_v140.segment_info(data, index + 1)
    new_reloc = seg["file_offset"] + retail_len
    next_offset = next_seg["file_offset"]
    if new_reloc + len(blob) > next_offset:
        raise PatchError(f"STAFF.DLL segment {index} 롤백 공간이 부족합니다.")
    buf[new_reloc:new_reloc + len(blob)] = blob
    buf[new_reloc + len(blob):next_offset] = b"\0" * (next_offset - (new_reloc + len(blob)))
    entry = seg["entry"]
    buf[entry + 2:entry + 4] = retail_len.to_bytes(2, "little")
    buf[entry + 6:entry + 8] = retail_len.to_bytes(2, "little")


def rollback_staff_v140_to_v130(data: bytes) -> tuple[bytes, dict[str, object]]:
    """Reverse only the v1.3.98/v1.3.99 4-plane staff-roll renderer.

    The narration/timing lives in ENDING.DLL and is intentionally not touched.
    The result is byte-identical to the v1.3.97 stable 3-plane STAFF.DLL.
    """
    if not staff_v140.is_new_staff(data):
        return data, {"state_before": "not_v140_4plane", "changed": False}

    b = bytearray(data)
    s3 = staff_v140.segment_info(data, staff_v140.SEG3)
    s5 = staff_v140.segment_info(data, staff_v140.SEG5)
    b3 = s3["file_offset"]
    b5 = s5["file_offset"]

    # Restore the retail 3-plane text blitter and staff-roll control flow.
    b[b3 + staff_v140.SEG3_BLITTER_SITE:b3 + staff_v140.SEG3_BLITTER_SITE + len(staff_v140.SEG3_BLITTER_RETAIL)] = staff_v140.SEG3_BLITTER_RETAIL
    b[b5 + staff_v140.SEG5_FADE_SITE:b5 + staff_v140.SEG5_FADE_SITE + len(staff_v140.SEG5_FADE_RETAIL_PREFIX)] = staff_v140.SEG5_FADE_RETAIL_PREFIX
    b[b5 + staff_v140.SEG5_PRELOAD_LIMIT_SITE] = staff_v140.SEG5_PRELOAD_LIMIT_RETAIL
    b[b5 + staff_v140.SEG5_INIT_SITE:b5 + staff_v140.SEG5_INIT_SITE + len(staff_v140.SEG5_INIT_RETAIL)] = staff_v140.SEG5_INIT_RETAIL
    b[b5 + staff_v140.SEG5_SKIP_SWAP_SITE:b5 + staff_v140.SEG5_SKIP_SWAP_SITE + 3] = bytes.fromhex("8B C6 BB")

    # Move both relocation tables back to the v1.3.97 segment ends and clear the helper area.
    _shrink_v140_segment(b, staff_v140.SEG3, staff_v140.SEG3_NEW_LENGTH, staff_v140.SEG3_RETAIL_LENGTH)
    _shrink_v140_segment(b, staff_v140.SEG5, staff_v140.SEG5_NEW_LENGTH, staff_v140.SEG5_RETAIL_LENGTH)

    # Restore the original rotating staff-roll background slots.  Keep the stable
    # v1.3.97 final ED19 replacement and the unrelated advertisement path.
    b[staff_v140.SLOT1_OFFSET:staff_v140.SLOT1_OFFSET + 4] = staff_v140.SLOT1_RETAIL
    b[staff_v140.SLOT2_OFFSET:staff_v140.SLOT2_OFFSET + 4] = staff_v140.SLOT2_RETAIL
    b[staff_core.FINAL_STAFF_NAME_OFFSET:staff_core.FINAL_STAFF_NAME_OFFSET + 4] = staff_core.FINAL_STAFF_NAME_NEW
    b[staff_core.AD_FINAL_PATH_OFFSET:staff_core.AD_FINAL_PATH_OFFSET + len(staff_core.AD_FINAL_PATH_RETAIL)] = staff_core.AD_FINAL_PATH_RETAIL

    out = bytes(b)
    if sha256(out) != STAFF_V130_STABLE_SHA256:
        raise PatchError("4bpp 스태프롤 롤백 결과가 v1.3.97 안정 STAFF.DLL과 일치하지 않습니다.")
    s3_after = staff_v140.segment_info(out, staff_v140.SEG3)
    s5_after = staff_v140.segment_info(out, staff_v140.SEG5)
    if (s3_after["length"], s5_after["length"]) != (staff_v140.SEG3_RETAIL_LENGTH, staff_v140.SEG5_RETAIL_LENGTH):
        raise PatchError("4bpp 스태프롤 롤백 후 NE 세그먼트 길이 검증에 실패했습니다.")
    staff_v140._verify_reloc(out, staff_v140.SEG3, staff_v140.SEG3_RELOC_COUNT, staff_v140.SEG3_RELOC_SHA256)
    staff_v140._verify_reloc(out, staff_v140.SEG5, staff_v140.SEG5_RELOC_COUNT, staff_v140.SEG5_RELOC_SHA256)
    return out, {
        "state_before": "v1.3.98_v1.3.99_4plane_staff",
        "changed": True,
        "state_after": "v1.3.97_stable_3plane_staff",
        "output_sha256": sha256(out),
        "segment3": {"length": hex(s3_after["length"]), "relocation_sha256": staff_v140.SEG3_RELOC_SHA256},
        "segment5": {"length": hex(s5_after["length"]), "relocation_sha256": staff_v140.SEG5_RELOC_SHA256},
    }

def prepare_staff_output(original: bytes) -> tuple[bytes, dict[str, object]]:
    if len(original) != staff_core.STAFF_EXPECTED_SIZE:
        raise PatchError(f"STAFF.DLL 크기가 지원되는 한국어판과 다릅니다: {len(original)} bytes")
    rolled_back, rollback = rollback_staff_v140_to_v130(original)
    normalized, timing = normalize_staff_timing_to_v130(rolled_back)
    final_name = normalized[staff_core.FINAL_STAFF_NAME_OFFSET:staff_core.FINAL_STAFF_NAME_OFFSET + 4]
    if final_name not in (
        staff_core.FINAL_STAFF_NAME_RETAIL,
        staff_core.FINAL_STAFF_NAME_OLD_ES02,
        staff_core.FINAL_STAFF_NAME_NEW,
    ):
        raise PatchError("STAFF.DLL의 실제 마지막 배경 항목이 예상과 다릅니다: " + repr(final_name))
    ad_path = normalized[staff_core.AD_FINAL_PATH_OFFSET:staff_core.AD_FINAL_PATH_OFFSET + len(staff_core.AD_FINAL_PATH_RETAIL)]
    if ad_path not in (
        staff_core.AD_FINAL_PATH_RETAIL,
        staff_core.AD_FINAL_PATH_OLD_OP32,
        staff_core.AD_FINAL_PATH_OLD_ED19,
    ):
        raise PatchError("STAFF.DLL의 광고 화면 표가 예상과 다릅니다: " + repr(ad_path))
    patched = bytearray(normalized)
    patched[staff_core.FINAL_STAFF_NAME_OFFSET:staff_core.FINAL_STAFF_NAME_OFFSET + 4] = staff_core.FINAL_STAFF_NAME_NEW
    patched[staff_core.AD_FINAL_PATH_OFFSET:staff_core.AD_FINAL_PATH_OFFSET + len(staff_core.AD_FINAL_PATH_RETAIL)] = staff_core.AD_FINAL_PATH_RETAIL
    output = bytes(patched)
    return output, {
        "input_sha256": sha256(original),
        "output_sha256": sha256(output),
        "input_final_background": final_name.decode("ascii"),
        "final_background": "grp\\ed19.stf",
        "input_advertisement_final": ad_path.decode("ascii"),
        "advertisement_final": "grp\\op06.STF",
        "timing": timing,
        "four_plane_rollback": rollback,
    }


def backup_once(path: Path, suffix: str) -> Path:
    backup = path.with_name(path.name + suffix)
    # All-In-One already owns the transaction backup.  Suppress duplicate
    # component backups when invoked from that environment; standalone use
    # keeps the traditional one-time backup behavior.
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        return backup
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


def apply_patch(selected: Path) -> dict[str, object]:
    folder = staff_core.resolve_game_folder(selected)
    ending, staff, source, asset = staff_core.resolve_game_files(folder)
    old_helper = staff_core.find_child_case_insensitive(source.parent, OLD_V140_HELPER_NAME)

    source_raw = source.read_bytes()
    asset_output, conversion = staff_core.build_centered_staff_stf(source_raw)
    ending_original = ending.read_bytes()
    ending_output, narration_report = narration_core.apply_patch(ending_original)
    ending_output, flora_anchor_report = normalize_flora_speaker_anchor(ending_output)
    staff_original = staff.read_bytes()
    staff_output, staff_report = prepare_staff_output(staff_original)
    asset_original = asset.read_bytes() if asset.exists() else None
    helper_original = old_helper.read_bytes() if old_helper is not None and old_helper.is_file() else None
    remove_old_helper = helper_original is not None and sha256(helper_original) == OLD_V140_HELPER_SHA256

    changes = {
        "ENDING.DLL": ending_output != ending_original,
        "STAFF.DLL": staff_output != staff_original,
        "GRP\\ED19.STF": asset_original != asset_output,
        "GRP\\E419.STF_removed": remove_old_helper,
    }
    backups: dict[str, str | None] = {"ENDING.DLL": None, "STAFF.DLL": None, "GRP\\ED19.STF": None, "GRP\\E419.STF": None}

    # All outputs are fully built and verified before any game file is written.
    try:
        if changes["ENDING.DLL"]:
            backups["ENDING.DLL"] = str(backup_once(ending, ENDING_BACKUP_SUFFIX))
        if changes["STAFF.DLL"]:
            backups["STAFF.DLL"] = str(backup_once(staff, STAFF_BACKUP_SUFFIX))
        if changes["GRP\\ED19.STF"] and asset_original is not None:
            backups["GRP\\ED19.STF"] = str(backup_once(asset, ASSET_BACKUP_SUFFIX))
        if remove_old_helper and old_helper is not None:
            backups["GRP\\E419.STF"] = str(backup_once(old_helper, ASSET_BACKUP_SUFFIX))

        if changes["ENDING.DLL"]:
            atomic_write(ending, ending_output)
        if changes["STAFF.DLL"]:
            atomic_write(staff, staff_output)
        if changes["GRP\\ED19.STF"]:
            atomic_write(asset, asset_output)
        if remove_old_helper and old_helper is not None and old_helper.exists():
            old_helper.unlink()

        if ending.read_bytes() != ending_output:
            raise PatchError("ENDING.DLL 저장 후 검증에 실패했습니다.")
        if staff.read_bytes() != staff_output:
            raise PatchError("STAFF.DLL 저장 후 검증에 실패했습니다.")
        if asset.read_bytes() != asset_output:
            raise PatchError("ED19.STF 저장 후 검증에 실패했습니다.")
        if remove_old_helper and old_helper is not None and old_helper.exists():
            raise PatchError("E419.STF 롤백 삭제 검증에 실패했습니다.")
    except Exception:
        # Restore the exact in-memory originals if any write fails.
        try:
            atomic_write(ending, ending_original)
            atomic_write(staff, staff_original)
            if asset_original is None:
                if asset.exists():
                    asset.unlink()
            else:
                atomic_write(asset, asset_original)
            if helper_original is not None and old_helper is not None:
                atomic_write(old_helper, helper_original)
        except Exception:
            pass
        raise

    status = "patched" if any(changes.values()) else "already_patched"
    report = {
        "tool": APP,
        "version": VERSION,
        "status": status,
        "selected_folder": str(selected.expanduser().resolve()),
        "resolved_game_folder": str(folder),
        "basis": {
            "freya": "v5.0.0 Fresh Page Only",
            "staff_final": "v1.3.0 3-plane centered G_ED1900",
            "narration": "Narration Script Add-on v1.0.17; final prayer hold 64/64=1.000 s and 525/64=8.203125 s distributed before Reisia; combined budget 589 ticks unchanged",
            "legacy_staff_delay_experiment": "not included; recognized helper is removed",
        },
        "changes": changes,
        "backups": backups,
        "ending": narration_report,
        "flora_speaker_anchor": flora_anchor_report,
        "staff": staff_report,
        "generated_asset": {
            "target": str(asset),
            "size": len(asset_output),
            "sha256": sha256(asset_output),
            "status": "generated" if changes["GRP\\ED19.STF"] else "already_generated",
        },
        "conversion": conversion,
        "scope": {
            "folder_selection": "preserved",
            "freya_v5.0.0": "preserved/installed",
            "final_background": "v1.3.97 stable rotating 3-plane staff roll; final background is centered ED19",
            "staff_timing": "v1.3.97 stable 3-plane rotating staff roll; original scrolling speed; no 4bpp compositor",
            "ending_timing": "64-Hz timeline retained from v1.3.98/v1.3.99: final prayer hold 64 ticks (1.000 s); post-prayer/pre-Reisia extension 525 ticks (8.203125 s, 105x5); combined budget 589 ticks unchanged",
            "narration_method": "keep 0A:2847 -> 11:05BC and extend the original stream in place",
            "dormant_pc98_scene": "not entered or modified; v1.6.2 direct-render helper is removed when detected",
        },
    }
    atomic_write(folder / REPORT_NAME, json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8"))
    return report


def gui() -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox

    root = tk.Tk()
    root.withdraw()
    try:
        folder = filedialog.askdirectory(title="영웅전설 II 한국어판 게임 폴더 선택")
        if not folder:
            return 0
        text = (
            "다음 수정만 함께 적용합니다.\n\n"
            "1. 프레이아: 안정판 v5.0.0\n"
            "2. 스태프롤 마지막 배경: 중앙 정렬 G_ED1900 (v1.3.0)\n"
            "3. 원래 메시지 위치를 유지한 채 나레이션 두 줄 추가\n"
            "4. \"부디 지켜보아 주십시오.\" 뒤 5개 구간은 525/64초(8.203125초) 유지\n"
            "5. 마지막 나레이션 정지는 64틱(1초) 유지; 엔딩 총길이 변화 없음\n"
            "6. 단색→컬러 전환은 원래 3틱 간격 유지\n"
            "7. 완전한 컬러 화면을 192틱(정확히 3초) 유지한 뒤 원래 팔레트 페이드아웃 실행\n"
            "8. 프레이아 4분할 로드/크롭 순간만 타이머 콜백을 임시 보호하여 1프레임 노출 방지\n"
            "9. v1.3.98~v1.3.99 4bpp STAFF.DLL은 v1.3.97 안정 3-plane으로 롤백\n\n"
            "계속할까요?"
        )
        if not messagebox.askyesno(APP + " v" + VERSION, text):
            return 0
        report = apply_patch(Path(folder))
        if report["status"] == "already_patched":
            messagebox.showinfo(APP, "이미 같은 통합 수정이 적용되어 있습니다.")
        else:
            messagebox.showinfo(
                APP,
                "통합 패치를 적용했습니다.\n\n"
                "프레이아: v5.0.0\n"
                "스태프롤: v1.3.97 안정 3-plane 동작으로 롤백\n"
                "나레이션: 원래 11:05BC 스트림 인플레이스 확장\n"
                "\"부디 지켜보아 주십시오.\" 이후 레이시아 전 구간: +525/64초 = +8.203125초\n"
                "요슈아→컬러 전환 대기: 16틱 = 0.250초\n"
                "마지막 나레이션 정지: 64틱 = 1.000초; 엔딩 총길이 유지\n"
                "단색→컬러: 원래 3틱/단계 유지\n"
                "완전 컬러 화면 유지: 192틱 = 3.000초, 이후 원래 팔레트 페이드아웃\n"
                "프레이아 4분할 1프레임: 세 번의 fresh-page 로드/크롭 동안만 콜백을 임시 차단하고 즉시 복원",
            )
        return 0
    except Exception as exc:
        messagebox.showerror(APP, str(exc))
        return 1
    finally:
        root.destroy()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=APP)
    parser.add_argument("path", nargs="?", help="게임 폴더, ENDING.DLL 또는 STAFF.DLL")
    args = parser.parse_args(argv)
    if args.path is None:
        return gui()
    try:
        print(json.dumps(apply_patch(Path(args.path)), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
