# ED2 All-In-One Patcher v1.4.48

영웅전설 II 한국 DOS판 종합 개선 패치의 권장 설치기입니다.

## 실행

Windows에서는:

```text
run_all_in_one.bat
```

또는 Python 3.10+에서:

```text
python ed2_all_in_one_patcher.py
```

게임 폴더를 인자로 직접 지정할 수도 있습니다.

```text
python ed2_all_in_one_patcher.py "C:\ED2" --apply-all --no-gui
```

## 주요 옵션

```text
--apply-all                 기본 구성요소 전부 적용
--components a,b,c          선택한 구성요소만 적용
--music-mode vgm|original    BGM 소스 선택
--validate                  게임 폴더 기본 구조 검증
--restore-stock             생성된 순정 영구 백업에서 복원
--rebuild-export            현재 패치 상태에서 배포용 변경 파일 재생성
--no-permanent-backup       순정 영구 백업 생성 안 함
--no-export                 적용 후 변경 파일 폴더 생성 안 함
--no-gui                    GUI 없이 실행
```

## BGM 소스 선택

GUI의 `BGM 모드`에서 다음 중 하나를 선택합니다.

- `교체 VGM BGM (기본)`
- `원본 BGM`

원본 BGM 모드는 순정 MUS/곡 매핑을 사용하지만 BGM hard-stop 및 제어 안정성 수정은 유지합니다. 이미 VGM BGM을 적용한 게임에서 원본으로 전환하려면 AIO가 최초 적용 때 만든 `*_STOCK_BACKUP`이 필요합니다.

CLI 예시:

```text
python ed2_all_in_one_patcher.py "C:\ED2" --apply-all --music-mode original --no-gui
```

## 안전 정책

- SAVE 파일은 읽거나 수정하지 않습니다.
- 지원되지 않는 바이너리 상태를 추측해서 패치하지 않습니다.
- 기본 적용은 트랜잭션 방식으로 진행하며 최종 manifest를 검증합니다.
- M_504 관련 기본 순서는 `m504_restoration` 다음 `balance`입니다.

구성요소 설명과 개발 규칙은 상위 저장소의 `docs/` 문서를 참고하십시오.
