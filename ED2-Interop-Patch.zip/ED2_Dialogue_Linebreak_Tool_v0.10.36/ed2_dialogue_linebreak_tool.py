#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,struct,sys,os,stat
from pathlib import Path
APP_NAME='ED2 Dialogue Linebreak Tool'; VERSION='0.10.36'
def u16(b,o):return struct.unpack_from('<H',b,o)[0]
def u32(b,o):return struct.unpack_from('<I',b,o)[0]
def segments(data):
 ne=u32(data,0x3C);count=u16(data,ne+0x1C);table=ne+u16(data,ne+0x22);shift=u16(data,ne+0x32);out={}
 for i in range(count):
  sector,length,flags,alloc=struct.unpack_from('<HHHH',data,table+i*8);out[i+1]=(sector<<shift,65536 if length==0 else length)
 return out
def load(path):
 with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 out=[]
 for r in rows:
  out.append(dict(dll=r['dll'],segment=int(r['segment'],0),rel=int(r['offset_hex'],0),fileoff=int(r['file_offset_hex'],0),
                  original=int(r['original_hex'],16),patched=int(r['patched_hex'],16),
                  legacy=tuple(int(x,16) for x in (r.get('legacy_hex') or '').replace(',',' ').split()),
                  before=tuple(bytes.fromhex(x) for x in (r.get('before_hex') or '').split('|')) if (r.get('before_hex') or '') else (b'',),after=tuple(bytes.fromhex(x) for x in (r.get('after_hex') or '').split('|')) if (r.get('after_hex') or '') else (b'',),
                  operation=r.get('operation') or 'patch',note=r.get('note') or ''))
 seen=set()
 for r in out:
  k=(r['dll'].upper(),r['segment'],r['rel'])
  if k in seen:raise ValueError(f'중복 패치 위치: {k}')
  seen.add(k)
  # Every line break emitted by this manifest must replace one existing ASCII
  # word separator.  Never insert 01h before a surviving space: that produces
  # the visible one-cell indent reported in earlier packs.  Requiring a space
  # at the patched byte also guarantees we never split a CP949 two-byte glyph.
  if r['patched']==0x01:
   if r['original']!=0x20 and not (r['original']==0x05 and r['operation'] in {'page_to_line_v1','page_semantic_reflow_v141'}) and not (r['original']==0xFF and r['operation']=='branch_boundary_linebreak_v1397'):
    raise ValueError(f'잘못된 개행 원본(공백/허용된 페이지·분기 경계 아님): {k}')
   if any(x[:1]==b' ' for x in r['after']) or any(x[-1:]==b' ' for x in r['before']):
    raise ValueError(f'개행 직전/직후에 불필요한 공백이 남습니다: {k}')
 return out
def context_matches(blob,off,before_options,after_options):
 return any(blob[max(0,off-len(x)):off]==x for x in before_options) and any(blob[off+1:off+1+len(x)]==x for x in after_options)

def _safe_replace_bytes(path: Path, data: bytes | bytearray) -> None:
    """Replace a managed DLL while preserving its original read-only state.

    Windows raises PermissionError when Path.write_bytes() targets a file with
    the DOS read-only attribute.  Final verification temporarily restores the
    presentation bytes, so even an otherwise untouched read-only DLL must be
    writable for that pass.  Clear only the write-protection bit long enough
    to atomically replace the file, then restore the original mode.
    """
    original_mode = path.stat().st_mode
    temp = path.with_name(path.name + ".ed2lb.tmp")
    try:
        if temp.exists():
            try:
                temp.chmod(temp.stat().st_mode | stat.S_IWRITE)
            except OSError:
                pass
            temp.unlink()
        temp.write_bytes(bytes(data))
        try:
            path.chmod(original_mode | stat.S_IWRITE)
        except OSError:
            pass
        os.replace(temp, path)
        try:
            path.chmod(original_mode)
        except OSError:
            pass
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass

def process(root,manifest,mode):
 root=root.resolve();scene=root/'SCENA'
 if not (root/'ED2MAIN.EXE').is_file() or not scene.is_dir():raise ValueError('게임 폴더가 아닙니다')
 rows=load(manifest);group={}
 for r in rows:group.setdefault(r['dll'],[]).append(r)
 changed=already=files=0;ops={}
 for dll,items in sorted(group.items()):
  p=scene/dll;orig=p.read_bytes();data=bytearray(orig);segs=segments(orig);context=bytearray(orig);offsets=[]
  # normalize all managed sites to canonical original for stable context checks
  for r in items:
   base,length=segs[r['segment']];off=base+r['rel']
   if off!=r['fileoff']:raise ValueError(f'{dll} {r["rel"]:#x}: file offset mismatch')
   cur=context[off]
   if cur in (r['original'],r['patched'],*r['legacy']):context[off]=r['original']
   elif mode!='restore':raise ValueError(f'{dll} seg{r["segment"]}:{r["rel"]:#06x}: unexpected {cur:02X}')
   offsets.append(off)
  fc=0
  for r,off in zip(items,offsets):
   cur=data[off];key=r['operation'];ops.setdefault(key,[0,0])
   if mode=='apply':
    if cur==r['patched']:already+=1;ops[key][1]+=1;continue
    if cur not in (r['original'],*r['legacy']):raise ValueError(f'{dll} {r["rel"]:#x}: apply unexpected {cur:02X}')
    want=r['patched']
   elif mode=='restore':
    if cur==r['original']:already+=1;ops[key][1]+=1;continue
    if cur not in (r['patched'],*r['legacy']):already+=1;ops[key][1]+=1;continue
    # A restore is safe only when the canonicalized surrounding bytes still
    # identify this exact managed site. This prevents an old manifest position
    # from mistaking an unrelated 01h/05h/FFh in newer dialogue text for a patch.
    if not context_matches(context,off,r['before'],r['after']):
     already+=1;ops[key][1]+=1;continue
    want=r['original']
   else:
    if cur==r['patched']:already+=1;ops[key][1]+=1;continue
    if cur in (r['original'],*r['legacy']):changed+=1;ops[key][0]+=1;continue
    raise ValueError(f'{dll} {r["rel"]:#x}: check unexpected {cur:02X}')
   if mode!='restore':
    if not context_matches(context,off,r['before'],r['after']):
     raise ValueError(f'{dll} {r["rel"]:#x}: surrounding bytes mismatch')
   data[off]=want;changed+=1;ops[key][0]+=1;fc+=1
  if mode!='check' and fc:
   _safe_replace_bytes(p,data);files+=1
 print(f'{APP_NAME} v{VERSION}: rows={len(rows)} changed={changed} already={already} changed_files={files}')
 for k,v in sorted(ops.items()):print(f'{k}: changed={v[0]} already={v[1]}')
 return 2 if mode=='check' and changed else 0

def load_branch_trampolines(path: Path):
 rows=[]
 if not path.is_file(): return rows
 with path.open(encoding='utf-8-sig',newline='') as f:
  for r in csv.DictReader(f):
   rows.append(dict(dll=r['dll'],segment=int(r['segment'],0),jump=int(r['jump_offset_hex'],0),
                    tramp=int(r['trampoline_offset_hex'],0),target=int(r['target_offset_hex'],0),
                    note=r.get('note') or ''))
 seen=set()
 for r in rows:
  k=(r['dll'].upper(),r['segment'],r['jump'],r['tramp'])
  if k in seen: raise ValueError(f'중복 분기 트램펄린: {k}')
  seen.add(k)
 return rows

def process_branch_trampolines(root: Path, manifest: Path, mode: str):
 rows=load_branch_trampolines(manifest)
 if not rows:
  return 0
 scene=root.resolve()/'SCENA'; changed=already=files=0
 for r in rows:
  p=scene/r['dll']; orig=p.read_bytes(); data=bytearray(orig); ss=segments(orig)
  base,length=ss[r['segment']]; jo=base+r['jump']; to=base+r['tramp']
  if r['jump']+3>length or r['tramp']+4>length: raise ValueError(f'{r["dll"]}: 분기 트램펄린 범위 초과')
  old_jump=bytes((0x0F,r['target']&0xFF,(r['target']>>8)&0xFF))
  new_jump=bytes((0x0F,r['tramp']&0xFF,(r['tramp']>>8)&0xFF))
  old_tramp=b'\xFF'*4
  new_tramp=bytes((0x01,0x0F,r['target']&0xFF,(r['target']>>8)&0xFF))
  cj=bytes(data[jo:jo+3]); ct=bytes(data[to:to+4])
  is_old=(cj==old_jump and ct==old_tramp); is_new=(cj==new_jump and ct==new_tramp)
  if mode=='apply':
   if is_new: already+=1; continue
   if not is_old: raise ValueError(f'{r["dll"]} {r["jump"]:#x}: 분기 트램펄린 apply 상태 불일치')
   data[jo:jo+3]=new_jump; data[to:to+4]=new_tramp; changed+=1
  elif mode=='restore':
   if is_old: already+=1; continue
   if not is_new: raise ValueError(f'{r["dll"]} {r["jump"]:#x}: 분기 트램펄린 restore 상태 불일치')
   data[jo:jo+3]=old_jump; data[to:to+4]=old_tramp; changed+=1
  else:
   if is_new: already+=1; continue
   if is_old: changed+=1; continue
   raise ValueError(f'{r["dll"]} {r["jump"]:#x}: 분기 트램펄린 check 상태 불일치')
  if mode!='check': _safe_replace_bytes(p,data); files+=1
 print(f'branch_trampoline_v1397: rows={len(rows)} changed={changed} already={already} changed_files={files}')
 return 2 if mode=='check' and changed else 0

def main():
 base=Path(__file__).resolve().parent;ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}');ap.add_argument('game_root',type=Path);g=ap.add_mutually_exclusive_group(required=True);g.add_argument('--apply',action='store_true');g.add_argument('--restore',action='store_true');g.add_argument('--check',action='store_true');ap.add_argument('--csv',type=Path,default=base/'dialogue_presentation.csv');a=ap.parse_args();mode='apply' if a.apply else 'restore' if a.restore else 'check'
 try:
  rc1=process(a.game_root,a.csv,mode)
  rc2=process_branch_trampolines(a.game_root,base/'branch_trampolines.csv',mode)
  return 2 if mode=='check' and (rc1==2 or rc2==2) else 0
 except Exception as e:print('ERROR:',e,file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
