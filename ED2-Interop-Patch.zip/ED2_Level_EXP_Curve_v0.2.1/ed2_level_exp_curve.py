#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, struct
from pathlib import Path

VERSION = "0.2.1"
SEGMENT_INDEX = 85
TABLE_OFFSET = 0x3557
TABLE_WORDS = 42
OLD_TABLE = [40,56,78,108,148,201,271,363,483,638,836,1087,1402,1795,2280,2873,3591,4453,5477,6682,8085,9702,11545,13623,15939,18489,21262,24239,27390,30677,34051,37456,40827,44093,47180,50011,52512,54612,56250,57375,57949,57949]
V010_TABLE = [40,55,75,105,145,195,260,350,460,610,800,1040,1350,1700,2150,2700,3350,4100,5000,6000,7200,8500,10000,11750,13750,16000,18500,21250,24250,27500,30750,34000,37250,40250,43000,45500,47500,49000,50000,50500,51000,51000]
# Lv1~25 remains exactly v0.1.0.  Chapter-4/final-chapter territory is raised
# gradually: roughly +3% per-level at first, reaching +6.9% in the late table.
V020_TABLE = [40,55,75,105,145,195,260,350,460,610,800,1040,1350,1700,2150,2700,3350,4100,5000,6000,7200,8500,10000,11750,13750,16500,19000,21800,24900,28300,31700,35100,38500,41750,44750,47500,50000,51750,53000,53750,54500,54500]
# v0.2.1 keeps the v0.2.0 curve shape and raises the whole curve by about 3%.
# Values are rounded to the same human-readable granularity used by the existing table.
NEW_TABLE = [40,55,75,110,150,200,270,360,475,630,825,1050,1400,1750,2200,2800,3450,4200,5150,6200,7400,8750,10300,12100,14150,17000,19550,22450,25650,29150,32650,36150,39650,43000,46100,48950,51500,53300,54600,55350,56150,56150]

class PatchError(RuntimeError):
    pass

def ne_segment(data: bytes, index1: int) -> tuple[int,int]:
    if data[:2] != b"MZ": raise PatchError("MZ executable is required")
    ne = struct.unpack_from('<I', data, 0x3C)[0]
    if data[ne:ne+2] != b"NE": raise PatchError("NE executable is required")
    count = struct.unpack_from('<H', data, ne+0x1C)[0]
    if not 1 <= index1 <= count: raise PatchError(f"segment {index1} is unavailable")
    segtab = ne + struct.unpack_from('<H', data, ne+0x22)[0]
    shift = struct.unpack_from('<H', data, ne+0x32)[0]
    pos = segtab + (index1-1)*8
    sector, length = struct.unpack_from('<HH', data, pos)
    off = sector << shift
    if length == 0: length = 0x10000
    if off + length > len(data): raise PatchError("segment extends beyond file")
    return off, length

def read_table(data: bytes) -> list[int]:
    off, length = ne_segment(data, SEGMENT_INDEX)
    if TABLE_OFFSET + TABLE_WORDS*2 > length: raise PatchError("EXP table is outside segment")
    return list(struct.unpack_from('<'+'H'*TABLE_WORDS, data, off+TABLE_OFFSET))

def write_table(data: bytearray, values: list[int]) -> None:
    off, _ = ne_segment(data, SEGMENT_INDEX)
    struct.pack_into('<'+'H'*TABLE_WORDS, data, off+TABLE_OFFSET, *values)

def state(table: list[int]) -> str:
    if table == OLD_TABLE: return 'old'
    if table == V010_TABLE: return 'v0.1.0'
    if table == V020_TABLE: return 'v0.2.0'
    if table == NEW_TABLE: return 'new'
    return 'unknown'

def cumulative(values: list[int], level: int) -> int:
    if level <= 1: return 0
    total = 20
    if level == 2: return total
    for lv in range(2, level):
        idx = lv-2
        total += values[idx] if idx < len(values) else values[-1]
    return total

def report(table: list[int]) -> dict:
    return {
        'version': VERSION,
        'state': state(table),
        'table_segment': SEGMENT_INDEX,
        'table_offset': f'0x{TABLE_OFFSET:04X}',
        'lv1_to_2': 20,
        'lv2_to_3': table[0],
        'lv25_to_26': table[23],
        'lv26_to_27': table[24],
        'lv30_to_31': table[28],
        'lv34_to_35': table[32],
        'lv40_to_41': table[38],
        'lv43_plus_per_level': table[-1],
        'cumulative_lv26': cumulative(table,26),
        'cumulative_lv30': cumulative(table,30),
        'cumulative_lv34': cumulative(table,34),
        'cumulative_lv40': cumulative(table,40),
        'cumulative_lv43': cumulative(table,43),
        'cumulative_lv99': cumulative(table,99),
        'v0_2_0_cumulative_lv43': cumulative(V020_TABLE,43),
        'increase_vs_v0_2_0_cumulative_lv43_percent': round((cumulative(NEW_TABLE,43)/cumulative(V020_TABLE,43)-1)*100,3),
        'v0_1_0_cumulative_lv43': cumulative(V010_TABLE,43),
        'v0_1_0_cumulative_lv99': cumulative(V010_TABLE,99),
    }

def main() -> int:
    ap=argparse.ArgumentParser(description='ED2 level EXP curve patch')
    ap.add_argument('game', type=Path)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--apply', action='store_true')
    g.add_argument('--restore', action='store_true')
    g.add_argument('--check', action='store_true')
    ap.add_argument('--no-backup', action='store_true')
    args=ap.parse_args()
    exe=(args.game/'ED2MAIN.EXE').resolve()
    if not exe.is_file(): raise PatchError('ED2MAIN.EXE not found')
    before=exe.read_bytes(); current=read_table(before); curstate=state(current)
    if args.check:
        print(json.dumps(report(current), ensure_ascii=False, indent=2))
        return 0 if curstate=='new' else 1
    desired=NEW_TABLE if args.apply else OLD_TABLE
    if curstate=='unknown':
        raise PatchError('unsupported level EXP table: '+','.join(map(str,current)))
    if current != desired:
        after=bytearray(before); write_table(after,desired)
        s86off,s86len=ne_segment(after,86)
        s86=bytes(after[s86off:s86off+s86len])
        if s86[0x79A3:0x79A6] != bytes.fromhex('BE 57 35'):
            raise PatchError('EXP_TO_LEVEL table reference changed unexpectedly')
        if s86.count(bytes.fromhex('BE 57 35')) < 1:
            raise PatchError('level EXP table reference is missing')
        if not args.no_backup:
            bak=exe.with_suffix(exe.suffix+'.level_exp.bak')
            if not bak.exists(): shutil.copy2(exe,bak)
        exe.write_bytes(after)
    final=read_table(exe.read_bytes())
    print(json.dumps(report(final), ensure_ascii=False, indent=2))
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except PatchError as e:
        print(f'ERROR: {e}')
        raise SystemExit(2)
