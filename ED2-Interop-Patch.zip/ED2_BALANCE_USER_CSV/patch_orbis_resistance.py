#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse
import csv

MAGIC_ID_POISON = 5
MAGIC_ID_SLEEP = 6
MAGIC_ID_ORBIS = 8
BOSS_IMMUNITY_MAGIC_IDS = (MAGIC_ID_POISON, MAGIC_ID_SLEEP, MAGIC_ID_ORBIS)
BOSS_BGM_IDS = {8, 16}
EXPECTED_OLD = 100


def u16(data: bytes | bytearray, off: int) -> int:
    return data[off] | (data[off + 1] << 8)


def ne_segments(data: bytes) -> list[tuple[int, int]]:
    if data[:2] != b"MZ":
        raise ValueError("not MZ")
    ne = int.from_bytes(data[0x3C:0x40], "little")
    if data[ne:ne + 2] != b"NE":
        raise ValueError("not NE")
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    result: list[tuple[int, int]] = []
    for i in range(count):
        entry = table + i * 8
        sector = u16(data, entry)
        length = u16(data, entry + 2) or 0x10000
        result.append((sector << shift, length))
    return result


def find_monster_data_segment(data: bytes) -> tuple[int, int]:
    for off, length in ne_segments(data):
        if length < 0x160 or off + 64 > len(data):
            continue
        rec = data[off:off + 64]
        hp = u16(rec, 4)
        if hp and hp == u16(rec, 6) and b"\x06" in rec[0x30:0x40]:
            return off, length
    raise ValueError("monster data segment not found")


def unique_effect_offsets(data: bytearray, base: int, seg_len: int, magic_id: int) -> list[int]:
    # _MO_MAG_PTR at +0x11C points to a 4-entry uint16 table. Each entry points
    # to that monster slot's 16-byte player-magic effect table.
    ptr_table = u16(data, base + 0x11C)
    if not 0 <= ptr_table <= seg_len - 8:
        raise ValueError(f"invalid _MO_MAG_PTR 0x{ptr_table:04X}")
    offsets: list[int] = []
    for slot in range(4):
        table_ptr = u16(data, base + ptr_table + slot * 2)
        effect_rel = table_ptr + magic_id
        if not 0 <= effect_rel < seg_len:
            raise ValueError(f"slot {slot}: magic {magic_id} effect table outside data segment")
        effect_off = base + effect_rel
        if effect_off not in offsets:
            offsets.append(effect_off)
    return offsets


def unique_orbis_offsets(data: bytearray, base: int, seg_len: int) -> list[int]:
    return unique_effect_offsets(data, base, seg_len, MAGIC_ID_ORBIS)


def load_targets(csv_path: Path) -> list[tuple[str, int, str]]:
    rows: list[tuple[str, int, str]] = []
    with csv_path.open("r", newline="", encoding="utf-8-sig") as fp:
        for row in csv.DictReader(fp):
            fn = row["dll"].strip()
            value = int(row["orbis_effect_percent"], 0)
            monsters = row.get("monsters", "").strip()
            if not 0 <= value <= 255:
                raise ValueError(f"{fn}: invalid effect {value}")
            rows.append((fn, value, monsters))
    return rows


def patch_one(path: Path, target: int, check: bool) -> dict[str, object]:
    data = bytearray(path.read_bytes())
    base, seg_len = find_monster_data_segment(data)
    offsets = unique_orbis_offsets(data, base, seg_len)
    before = [data[o] for o in offsets]
    changed = 0
    for off in offsets:
        current = data[off]
        if current == target:
            continue
        if check:
            raise ValueError(f"{path.name}: Orbis effect {current}, expected {target}")
        if current != EXPECTED_OLD:
            raise ValueError(
                f"{path.name}: unexpected Orbis effect {current}; "
                f"expected retail/v1.0.85 {EXPECTED_OLD} or target {target}"
            )
        data[off] = target
        changed += 1
    if changed and not check:
        path.write_bytes(data)
    return {
        "file": path.name,
        "table_count": len(offsets),
        "before": before,
        "after": [data[o] for o in offsets],
        "changed_tables": changed,
    }



def load_boss_targets(group_csv: Path) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    with group_csv.open("r", newline="", encoding="utf-8-sig") as fp:
        for row in csv.DictReader(fp):
            bgm = int(str(row.get("bgm_id", "0")).strip() or "0", 0)
            if bgm in BOSS_BGM_IDS:
                rows.append((row["dll"].strip(), row.get("monsters", "").strip()))
    return rows


def patch_boss_status_immunity(path: Path, check: bool) -> dict[str, object]:
    data = bytearray(path.read_bytes())
    base, seg_len = find_monster_data_segment(data)
    before: dict[int, list[int]] = {}
    changed = 0
    for magic_id in BOSS_IMMUNITY_MAGIC_IDS:
        offsets = unique_effect_offsets(data, base, seg_len, magic_id)
        before[magic_id] = [data[o] for o in offsets]
        for off in offsets:
            if data[off] == 0:
                continue
            if check:
                raise ValueError(f"{path.name}: magic {magic_id} effect {data[off]}, expected boss immunity 0")
            data[off] = 0
            changed += 1
    if changed and not check:
        path.write_bytes(data)
    return {
        "file": path.name,
        "before": before,
        "after": {magic_id: [data[o] for o in unique_effect_offsets(data, base, seg_len, magic_id)]
                  for magic_id in BOSS_IMMUNITY_MAGIC_IDS},
        "changed_values": changed,
    }

def main() -> int:
    ap = argparse.ArgumentParser(description="ED2 monster status resistance adjustment")
    ap.add_argument("game_dir", type=Path)
    ap.add_argument("--csv", type=Path, default=Path(__file__).with_name("ED2_ORBIS_EFFECTS.csv"))
    ap.add_argument("--check", action="store_true")
    ns = ap.parse_args()

    total = 0
    for fn, target, monsters in load_targets(ns.csv):
        result = patch_one(ns.game_dir / "MON" / fn, target, ns.check)
        total += int(result["changed_tables"])
        print(
            f"{fn}: Orbis={target}% tables={result['table_count']} "
            f"changed={result['changed_tables']} ({monsters})"
        )

    group_csv = Path(__file__).with_name("ED2_MONSTER_GROUPS.csv")
    boss_total = 0
    boss_count = 0
    for fn, monsters in load_boss_targets(group_csv):
        result = patch_boss_status_immunity(ns.game_dir / "MON" / fn, ns.check)
        boss_total += int(result["changed_values"])
        boss_count += 1
        print(
            f"{fn}: boss immunity 푸아조/호/오비스=0% "
            f"changed={result['changed_values']} ({monsters})"
        )
    print(
        f"Status resistance {'check' if ns.check else 'apply'}: "
        f"orbis_changed_tables={total} boss_groups={boss_count} boss_effect_values_changed={boss_total}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
