#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
from pathlib import Path

APP = "ED2 M_504 Balance Extension"
VERSION = "1.0.0"
CLEAN_SHA = "aae4eaf70259956e99d905bbede5553513d5c06918ea23d9c7447f402a55ff3a"
BALANCED_SHA = "78987686c1bd0aa473e1fd931dfa8ac3a7fef685bf7109873977ba9f38fbae57"
EXPECTED_SIZE = 61981

# Offsets are in the restored Korean NE DLL. Slots 2/3 are formation-disabled,
# but mirror Dadarca's numeric profile so the four-record table stays coherent.
PATCHES = (
    (0x3404, 2, 783, 950, "slot0.hp"),
    (0x340A, 2, 1195, 1320, "slot0.attack"),
    (0x340C, 2, 4000, 2200, "slot0.exp"),
    (0x340E, 2, 1100, 1400, "slot0.gold"),
    (0x3410, 2, 517, 530, "slot0.defense"),
    (0x3412, 2, 400, 480, "slot0.magic"),
    (0x3416, 1, 30, 34, "slot0.speed"),
    (0x3417, 1, 36, 40, "slot0.luck"),
    (0x3444, 2, 1830, 1950, "slot1.hp"),
    (0x344A, 2, 1096, 1220, "slot1.attack"),
    (0x344C, 2, 3505, 2000, "slot1.exp"),
    (0x344E, 2, 1600, 1900, "slot1.gold"),
    (0x3450, 2, 559, 590, "slot1.defense"),
    (0x3452, 2, 395, 455, "slot1.magic"),
    (0x3456, 1, 43, 45, "slot1.speed"),
    (0x3457, 1, 27, 32, "slot1.luck"),
    (0x3484, 2, 783, 950, "slot2.hp"),
    (0x348A, 2, 1195, 1320, "slot2.attack"),
    (0x348C, 2, 4000, 2200, "slot2.exp"),
    (0x348E, 2, 1100, 1400, "slot2.gold"),
    (0x3490, 2, 517, 530, "slot2.defense"),
    (0x3492, 2, 400, 480, "slot2.magic"),
    (0x3496, 1, 30, 34, "slot2.speed"),
    (0x3497, 1, 36, 40, "slot2.luck"),
    (0x34C4, 2, 783, 950, "slot3.hp"),
    (0x34CA, 2, 1195, 1320, "slot3.attack"),
    (0x34CC, 2, 4000, 2200, "slot3.exp"),
    (0x34CE, 2, 1100, 1400, "slot3.gold"),
    (0x34D0, 2, 517, 530, "slot3.defense"),
    (0x34D2, 2, 400, 480, "slot3.magic"),
    (0x34D6, 1, 30, 34, "slot3.speed"),
    (0x34D7, 1, 36, 40, "slot3.luck"),
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_value(data: bytes, off: int, size: int) -> int:
    if size == 1:
        return data[off]
    return struct.unpack_from("<H", data, off)[0]


def write_value(data: bytearray, off: int, size: int, value: int) -> None:
    if size == 1:
        data[off] = value
    else:
        struct.pack_into("<H", data, off, value)


def structural_ok(data: bytes) -> bool:
    if len(data) != EXPECTED_SIZE or data[:2] != b"MZ":
        return False
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if data[ne:ne + 2] != b"NE":
        return False
    count = struct.unpack_from("<H", data, ne + 0x1C)[0]
    segtab = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne + 0x32)[0]
    if count != 4 or shift != 9:
        return False
    sector, length, _flags, _minalloc = struct.unpack_from("<HHHH", data, segtab + 2 * 8)
    if sector * (1 << shift) != 0x3400 or length != 0x0390:
        return False
    # Corrected Korean FAR callback cleanup must remain intact.
    return data[0x3640:0x3643] == b"\x83\xC4\x04"



def loader_bypassed(root: Path) -> bool | None:
    exe = root / "ED2MAIN.EXE"
    if not exe.is_file():
        return None
    data = exe.read_bytes()
    try:
        if len(data) != 1848336 or data[:2] != b"MZ":
            return False
        ne = struct.unpack_from("<I", data, 0x3C)[0]
        if data[ne:ne + 2] != b"NE":
            return False
        segtab = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
        shift = struct.unpack_from("<H", data, ne + 0x32)[0]
        sector, _length, _flags, _minalloc = struct.unpack_from("<HHHH", data, segtab + 3 * 8)
        seg4 = sector * (1 << shift)
        return data[seg4 + 0x0CDB:seg4 + 0x0CDD] == b"\xEB\x10"
    except (IndexError, struct.error):
        return False

def inspect(root: Path) -> dict:
    target = root / "MON" / "M_504.DLL"
    if not target.is_file():
        return {
            "applicable": False,
            "ok": True,
            "state": "skipped_missing_m504_restoration",
            "message": "M_504.DLL이 없어 다다르카/악토스 수치만 건너뜁니다. 다른 몬스터 밸런스에는 영향이 없습니다.",
        }
    data = target.read_bytes()
    digest = sha(data)
    loader = loader_bypassed(root)
    if loader is False:
        return {
            "applicable": False,
            "ok": True,
            "state": "skipped_m504_restoration_incomplete",
            "sha256": digest,
            "message": "M_504.DLL은 있지만 ED2MAIN의 M_504 복원 로더가 활성화되지 않아 다다르카/악토스 수치를 건너뜁니다. M_504 복원 패치를 먼저 적용하십시오.",
        }
    if digest == BALANCED_SHA:
        return {"applicable": True, "ok": True, "state": "balanced", "sha256": digest}
    if digest == CLEAN_SHA:
        return {"applicable": True, "ok": False, "state": "restored_needs_balance", "sha256": digest}
    return {
        "applicable": False,
        "ok": True,
        "state": "skipped_incompatible_m504",
        "sha256": digest,
        "structural_ok": structural_ok(data),
        "message": "현재 M_504 복원 정본과 다른 DLL이라 안전을 위해 다다르카/악토스 수치만 건너뜁니다. M_504 복원 패치를 먼저 적용하십시오.",
    }


def apply(root: Path) -> dict:
    target = root / "MON" / "M_504.DLL"
    state = inspect(root)
    if not state["applicable"]:
        return state
    if state["state"] == "balanced":
        return state

    before = target.read_bytes()
    if sha(before) != CLEAN_SHA or not structural_ok(before):
        raise RuntimeError("M_504 복원 정본 구조가 예상과 다릅니다.")
    data = bytearray(before)
    changes = []
    for off, size, old, new, field in PATCHES:
        actual = read_value(before, off, size)
        if actual != old:
            raise RuntimeError(f"M_504 {field} 원본값 불일치 @0x{off:X}: {actual} != {old}")
        write_value(data, off, size, new)
        changes.append({"field": field, "offset": f"0x{off:X}", "old": old, "new": new})
    after = bytes(data)
    if sha(after) != BALANCED_SHA:
        raise RuntimeError("M_504 밸런스 결과 SHA-256이 정본과 일치하지 않습니다.")
    changed_offsets = {i for i, (a, b) in enumerate(zip(before, after)) if a != b}
    allowed = set()
    for off, size, *_ in PATCHES:
        allowed.update(range(off, off + size))
    if not changed_offsets <= allowed:
        raise RuntimeError("M_504 수치 필드 밖의 바이트가 변경되었습니다.")

    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") != "1":
        bak = target.with_suffix(".DLL.balance.bak")
        if not bak.exists():
            shutil.copy2(target, bak)
    target.write_bytes(after)
    return {
        "applicable": True,
        "ok": True,
        "state": "patched",
        "before_sha256": CLEAN_SHA,
        "after_sha256": BALANCED_SHA,
        "changed_fields": len(changes),
        "changes": changes,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=f"{APP} v{VERSION}")
    ap.add_argument("root", type=Path)
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    if not (root / "MON").is_dir():
        raise SystemExit("게임 폴더를 지정하십시오.")
    result = inspect(root) if args.check else apply(root)
    out = {"tool": APP, "version": VERSION, "mode": "check" if args.check else "apply", **result}
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0 if result.get("ok", False) else 1


if __name__ == "__main__":
    raise SystemExit(main())
