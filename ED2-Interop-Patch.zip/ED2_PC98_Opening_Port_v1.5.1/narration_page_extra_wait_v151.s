# ED2 PC-98 Opening Port v1.5.1
# Exact 24-byte source for OPENING.EXE Segment 1Dh:0A8Ah..0AA1h.
#
# 0A8A wait_plus_64:
#   CALL 2600h
#   MOV byte ptr [0BFAh],40h
#   CALL 2600h
#   RET
# 0A96 wait_plus_80:
#   CALL 2600h
#   MOV byte ptr [0BFAh],50h
#   CALL 2600h
#   RET
#
# Page 1/2/4/5 use wait_plus_64. Page 3 uses wait_plus_80 because
# removing the comma removes one 16-tick reveal cell. Net page gain is
# exactly +64 ticks (+1.000 s) on all five pages.

.code16
.intel_syntax noprefix
.section .text
.global _start
_start:
    .byte 0xE8,0x73,0x1B,0xC6,0x06,0xFA,0x0B,0x40,0xE8,0x6B,0x1B,0xC3
    .byte 0xE8,0x67,0x1B,0xC6,0x06,0xFA,0x0B,0x50,0xE8,0x5F,0x1B,0xC3
