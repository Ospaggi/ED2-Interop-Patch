# ED2 PC-98 Opening Port v1.5.1
# Replacement for OPENING.EXE Segment 1Dh:2B48h..2BCFh.
# Body cells remain 16 pixels. ASCII cells contain up to two 8-pixel ENG.FNT
# glyphs; a zero second byte means a single punctuation glyph.
# reloc_on_insn/reloc_off_insn immediates are NE segment fixup sources.

.code16
.intel_syntax noprefix
.section .text
.global _start
_start:
.loop:
    lodsb
    cmp al, 0x20
    je .lead
    test al, al
    je .newline
    cmp al, 0xff
    je .end
    mov dh, al
    lodsb
    mov dl, al
    test dh, 0x80
    jz .ascii
.dbcs:
    mov al, 0
    push ds
reloc_on_insn:
    mov ax, 0x0000
    mov ds, ax
    mov word ptr [0x0c8c], 1
    pop ds
    mov ah, 0x0b
    int 0x41
    push ds
reloc_off_insn:
    mov ax, 0x0000
    mov ds, ax
    mov word ptr [0x0c8c], 0
    pop ds
    jmp .advance
.ascii:
    cmp dh, 0x5f
    je .advance
    mov ah, 0x0a
    mov al, dh
    push dx
    int 0x41
    pop dx
    test dl, dl
    jz .advance
    inc di
    mov al, dl
    mov ah, 0x0a
    int 0x41
    dec di
.advance:
    add di, 2
    inc word ptr [0x4e8e]
    jmp .loop
.lead:
    inc word ptr [0x4e90]
    inc di
.back:
    jmp .loop
.newline:
    mov di, word ptr [0x4e8c]
    add word ptr [0x4e8c], 0x0780
    xor ax, ax
    xchg ax, word ptr [0x4e90]
    mov word ptr [bp], ax
    xor ax, ax
    xchg ax, word ptr [0x4e8e]
    mov word ptr [bp+2], ax
    add bp, 4
    jmp .back
.end:
    or word ptr [bp], -1
    ret
