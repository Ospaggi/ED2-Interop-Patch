# ED2 PC-98 Opening Port v1.5.1

영웅전설 II 한국 DOS판 `OPENING.EXE` 전용 패치입니다. **AIO는 수정하지 않습니다.**

## v1.5.1

- v1.5.0의 실제 X=320 중앙 정렬과 ASCII 문장부호 출력기를 유지합니다.
- `그리고 무엇보다, 아버지를 닮은 올곧은 마음.`에서 쉼표를 제거합니다.
  - `그리고 무엇보다 아버지를 닮은 올곧은 마음.`
- 오프닝 내레이션 5페이지의 표시 시간을 정확히 **총 +320 tick = +5.000초** 늘립니다.
  - 64 Hz 기준입니다.
  - 실제 페이지별 순증가: **+64 / +64 / +64 / +64 / +64 tick** = 각 +1.000초.
  - 쉼표 제거로 3페이지 reveal이 16 tick 짧아지므로 내부 추가 대기는 64 / 64 / 80 / 64 / 64 tick으로 배치합니다.
- `G_OP0403.NIN`이 표시되는 OP04 구간은 정확히 **-320 tick = -5.000초** 줄입니다.
  - v1.5.0: 1324 tick = 20.6875초
  - v1.5.1: 1004 tick = 15.6875초
- OP04 종료 앵커 및 그 뒤의 모든 절대 타임라인은 그대로 유지합니다.
  - 따라서 오프닝 최종 절대 앵커도 변하지 않습니다.
- `G_OP0403.NIN` 파일 자체는 수정하지 않습니다. `OPENING.EXE`의 장면 경계 타이밍만 변경합니다.

## 기존 v1.5.0 기능 유지

- 오프닝 초반 내레이션 23줄을 실제 640px 화면 중심(X=320)에 맞춰 출력
- ASCII `.`, `,`, `...` 안전 출력
- 반전부의 기존 극적 위치 유지
  - `...그렇게 보였다.`
  - `그렇다. 아무도 알지 못했다.`
  - `새로운 재앙이 닥쳐오고 있다는 것을...`
- 플로라 232px 부드러운 스크롤 / 32px 선행 이동
- 기존 최종 내레이션 +5초 유지
- 피 장면 이전 +5.390625초 유지
- `--apply-all` 사용 시 쓰러진 사람/빨간 피 PC-98 연출

## 정확한 5초 이동 방식

v1.5.0의 OP04(`G_OP0403.NIN`) 경계는 다음과 같습니다.

```text
OP01 end             1D:2F06 = 0x2C52
OP02 end             1D:305D = 0x2DDA
OP03 end / OP04 start 1D:3100 = 0x30D0
OP04 end             1D:31BE = 0x35FC
```

v1.5.1은 앞의 세 경계만 정확히 +0x0140(320) 이동합니다.

```text
OP01 end             0x2D92  (+320)
OP02 end             0x2F1A  (+320)
OP03 end / OP04 start 0x3210  (+320)
OP04 end             0x35FC  (변경 없음)
```

따라서 OP02와 OP03 길이는 그대로이고, OP04만 정확히 320 tick 짧아집니다. 뒤의 모든 장면 경계 및 마지막 절대 앵커는 그대로입니다.

## 적용

`run_porter.bat`을 실행하거나:

```text
python ed2_pc98_opening_port.py <게임폴더> --apply-all
```

분석만 하려면:

```text
python ed2_pc98_opening_port.py <게임폴더> --analyze
```

복원은 이 도구가 기록한 바이트만 되돌립니다.

```text
python ed2_pc98_opening_port.py <게임폴더> --restore
```

## 기술 범위

- `OPENING.EXE` 크기 불변
- NE segment geometry 불변
- 내레이션 parser: Segment 1Dh `2B48h..2BCFh` (136 bytes)
- 내레이션 stream: Segment 1Eh `0300h..087Ah` (1403 bytes)
- 추가 페이지 대기 wrapper: Segment 1Dh `0A8Ah..0AA1h`의 기존 NOP 영역
- 페이지 1/2/4/5: 기존 대기 후 +64 tick
- 페이지 3: 기존 대기 후 +80 tick (쉼표 제거로 줄어든 reveal 16 tick을 상쇄)
- v1.5.0 -> v1.5.1에서 relocation table은 byte-identical
- 순정 -> v1.5.1에서는 v1.5.0과 동일하게 parser 이동에 필요한 relocation source 2개만 갱신
  - `2B70h -> 2B63h`
  - `2B83h -> 2B74h`

DOSBox/실기에서의 화면 재생 확인은 별도 런타임 검증 항목입니다.
