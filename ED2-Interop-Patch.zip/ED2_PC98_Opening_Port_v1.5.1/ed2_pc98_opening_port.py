#!/usr/bin/env python3
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path

from ed2_patch_journal import record_patch, selective_restore
import shutil
import struct
import tempfile

APP_NAME = "ED2 PC-98 Opening Port"
VERSION = "1.5.1"
BACKUP_SUFFIX = ".pc98_opening_v151.bak"
JOURNAL_COMPONENT = "ed2_pc98_opening"
KNOWN_G_OP1700_SHA256 = "4ca1212f5f7d7429204abccb8afb2e3fb52502c86e3b3b1a223d51514f087fd4"
KNOWN_G_OP2200_SHA256 = "d7a5f86efb3f3a5ff85c0b133a341274d02e94306bb6fc8c15b7b56db152bef1"

SEGMENT_ORDINAL = 0x1D
BASE_SEGMENT_LENGTH = 0x45E6
OLD_V12_TAIL_SIZE = 113
OLD_V12_MARKER = b"FLORA232"
TAIL_OFFSET = BASE_SEGMENT_LENGTH
OLD_V13_LOCAL_CODE = bytes.fromhex("601e0655bde800e81f00e89d10b9e8004de8190fe81200e8440fc606fa0b02e8d11be2ec5d071f61c3601e0636a1001d8ed836a102008ec031dbe89c3b36a104008ec0bb007de8903b36a1021d8ed836a106008ec031dbe87f3b36a108008ec0bb007de8733b071f61c3")
LOCAL_CODE = bytes.fromhex("601e0655bdc800e81f00e89d10b9c8004de8190fe81200e8440fc606fa0b02e8d11be2ec5d071f61c3601e0636a1001d8ed836a102008ec031dbe89c3b36a104008ec0bb007de8903b36a1021d8ed836a106008ec031dbe87f3b36a108008ec0bb007de8733b071f61c3")
TAIL_CODE = bytes.fromhex("bf501a81fdc800771683fd20723089e883e820e8450001deb9e800e84800c389e883e820e8340001deb9b00129e95589cde83200b9e80029e95de83b00c3b9200029e989e8e8130083c63001dee8390089deb9c80001e9e80c00c389c6c1e004c1e60601c6c3e30f51b91800f3a55983c62083c720e2f1c3e30e31c051b91800f3ab5983c720e2f4c3e31e5156b90c00f3a55e81c6000ab90c00f3a581ee000a83c63883c72059e2e2c3464c4f5241534352")
TAIL_MARKER = b"FLORASCR"
LOCAL_START_ABS = 0x0A0D
LOCAL_END_ABS = 0x0AB2

# Opening prologue narration (S_003).  The game installs the MC146818
# periodic RTC with rate-select value 0x0A.  For a 32.768 kHz RTC time base,
# RS=0x0A is 64 Hz, so WAITCOUNTER=0xA0 is 160/64 = 2.5 seconds.
# v1.4.2 incorrectly treated it as 32 Hz and added only one 0xA0 wait.
# v1.4.3 adds TWO 0xA0 waits after the original final-page hold, for an
# actual extra 320/64 = 5.0 seconds, then resumes the original clear routine.
INTRO_FINAL_CLEAR_CALL = 0x2B42
INTRO_CLEAR_TARGET = 0x2CF7
INTRO_EXTRA_WAIT_CAVE = 0x0A77
INTRO_WAIT_HELPER = 0x2600
INTRO_WAIT_TICKS = 0xA0
INTRO_EXTRA_WAIT_COUNT = 2
INTRO_ORIGINAL_CALL = b"\xE8" + struct.pack("<h", INTRO_CLEAR_TARGET - (INTRO_FINAL_CLEAR_CALL + 3))
INTRO_PATCHED_CALL = b"\xE8" + struct.pack("<h", INTRO_EXTRA_WAIT_CAVE - (INTRO_FINAL_CLEAR_CALL + 3))

def _intro_wait_call(call_site:int)->bytes:
    return (
        bytes.fromhex("C6 06 FA 0B") + bytes([INTRO_WAIT_TICKS])
        + b"\xE8" + struct.pack("<h", INTRO_WAIT_HELPER - (call_site + 5 + 3))
    )

# Legacy v1.4.2 wrapper: one 0xA0 wait = 2.5 seconds at the actual 64 Hz rate.
INTRO_WAIT_WRAPPER_V142 = (
    _intro_wait_call(INTRO_EXTRA_WAIT_CAVE)
    + b"\xE9" + struct.pack("<h", INTRO_CLEAR_TARGET - (INTRO_EXTRA_WAIT_CAVE + 8 + 3))
)
INTRO_V142_CAVE_END = INTRO_EXTRA_WAIT_CAVE + len(INTRO_WAIT_WRAPPER_V142)

# Correct v1.4.3 wrapper: two 0xA0 waits = 320 ticks = 5.0 seconds.
_intro_second = INTRO_EXTRA_WAIT_CAVE + 8
INTRO_WAIT_WRAPPER = (
    _intro_wait_call(INTRO_EXTRA_WAIT_CAVE)
    + _intro_wait_call(_intro_second)
    + b"\xE9" + struct.pack("<h", INTRO_CLEAR_TARGET - (_intro_second + 8 + 3))
)
INTRO_CAVE_END = INTRO_EXTRA_WAIT_CAVE + len(INTRO_WAIT_WRAPPER)

# Pre-blood opening pacing (inside the scene sequence immediately before S_009/S_010).
# ABS_DELAY at 1D:24E6 compares RTCCOUNTER against an absolute 64 Hz target.
# Keep the first 0x2C52 anchor unchanged, then lengthen the six following
# scene intervals by a total of 345 ticks = 5.390625 seconds. Shorter
# intervals receive more extra time so the pacing is evened out without
# slowing the animations themselves.
PREBLOOD_BASE_ANCHOR = 0x2C52
PREBLOOD_TIMING_SITES = (
    # (MOV AX instruction offset, original absolute target, extended target, extra ticks for this interval)
    (0x305D, 0x2DA0, 0x2DDA, 58),   # 5.21875 s -> 6.12500 s  (+0.90625 s)
    (0x3100, 0x3070, 0x30D0, 38),   # 11.25000 s -> 11.84375 s (+0.59375 s)
    (0x31BE, 0x3580, 0x35FC, 28),   # 20.25000 s -> 20.68750 s (+0.43750 s)
    (0x321A, 0x36A0, 0x3766, 74),   # 4.50000 s -> 5.65625 s  (+1.15625 s)
    (0x325C, 0x3720, 0x3846, 96),   # 2.00000 s -> 3.50000 s  (+1.50000 s)
    (0x32D5, 0x3890, 0x39E9, 51),   # 5.75000 s -> 6.546875 s (+0.796875 s)
)
PREBLOOD_TOTAL_EXTRA_TICKS = sum(x[3] for x in PREBLOOD_TIMING_SITES)
PREBLOOD_TOTAL_EXTRA_SECONDS = PREBLOOD_TOTAL_EXTRA_TICKS / 64.0


# v1.5.1 opening narration renderer -------------------------------------------------
# v1.5.0 introduced true centering and mixed-width ASCII punctuation. v1.5.1 keeps
# that renderer and moves exactly 5.000 seconds (320 ticks at 64 Hz) into the five
# narration pages: each page becomes exactly 64 ticks / 1.000 second longer than
# v1.5.0.  The line "그리고 무엇보다, ..." loses its comma, which removes one
# 16-tick reveal cell from page 3; therefore the page-extra wrapper adds 80 ticks on
# page 3 and 64 ticks on the other four pages. Net gain per page is exactly 64 ticks.
NARRATION_CODE_SEGMENT = 0x1D
NARRATION_DATA_SEGMENT = 0x1E
NARRATION_PARSER_OFFSET = 0x2B48
NARRATION_PARSER_LENGTH = 0x88
NARRATION_PARSER_OLD = bytes.fromhex(
    "ac3c20744b9090903c00744b9090903cff746f9090908af0ac8ad080fe5f7427909090"
    "b000501eb800008ed8c7068c0c01001f58b40bcd41501eb800008ed8c7068c0c00001f58"
    "83c702ff068e4eebb0ff06904e47eba98b3e8c4e81068c4e8007a1904e89460083c502a18e"
    "4e89460083c502c7068e4e0000c706904e0000e97effc74600ffffc3"
)
NARRATION_PARSER_NEW = bytes.fromhex(
    "ac3c20745684c074593cff747688c6ac88c2f6c6807422b0001eb800008ed8c7068c0c01001f"
    "b40bcd411eb800008ed8c7068c0c00001feb1980fe5f7414b40a88f052cd415a84d274084788"
    "d0b40acd414f83c702ff068e4eeba5ff06904e47eb9e8b3e8c4e81068c4e800731c08706904e"
    "89460031c087068e4e89460283c504ebdd834e00ffc3"
)
assert len(NARRATION_PARSER_OLD) == len(NARRATION_PARSER_NEW) == NARRATION_PARSER_LENGTH

# The two old MOV AX,<relocated work-segment> operands move when the 136-byte parser
# is compacted. Only the source offsets change; relocation type/target remain exact.
NARRATION_RELOC_OLD = (0x2B70, 0x2B83)
NARRATION_RELOC_NEW = (0x2B63, 0x2B74)
NARRATION_RELOC_SIGNATURE = (0x02, 0x04, 0x0009, 0x0C8C)

NARRATION_STREAM_OFFSET = 0x0300
NARRATION_STREAM_LENGTH = 1403
NARRATION_PAGE_BASE_CELLS = (105, 92, 176, 134, 43)
NARRATION_PAGE_WAIT_SITES = (0x2A6F, 0x2AA1, 0x2AD3, 0x2B05, 0x2B37)
NARRATION_PAGE_WAIT_CALL_SITES = (0x2A77, 0x2AA9, 0x2ADB, 0x2B0D, 0x2B3F)
NARRATION_PAGE_WAIT_OLD = (0xA0, 0xA0, 0xA0, 0xA0, 0xA0)
# v1.5.0 page holds; together with the v1.5.0 reveal-cell counts these preserved
# the old total narration timing exactly.
NARRATION_PAGE_WAIT_NEW = (0xB0, 0xC0, 0xF0, 0xE0, 0xB0)
NARRATION_WAIT_HELPER = 0x2600
NARRATION_EXTRA_WAIT_CAVE = 0x0A8A
NARRATION_EXTRA_WAIT_64 = 64
NARRATION_EXTRA_WAIT_80 = 80
NARRATION_DISTRIBUTED_EXTRA_TICKS = 320
NARRATION_DISTRIBUTED_EXTRA_SECONDS = NARRATION_DISTRIBUTED_EXTRA_TICKS / 64.0
# Page 3 gets 80 ticks because removing the comma below removes one 16-tick reveal
# cell. Thus every page is still exactly +64 ticks (+1.000 s) relative to v1.5.0.
NARRATION_PAGE_EXTRA_TICKS_V151 = (64, 64, 80, 64, 64)
assert sum(NARRATION_PAGE_EXTRA_TICKS_V151) - 16 == NARRATION_DISTRIBUTED_EXTRA_TICKS


def _near_call(site: int, target: int) -> bytes:
    return b"\xE8" + struct.pack("<h", target - (site + 3))


def _narration_wait_wrapper(site: int, extra_ticks: int) -> bytes:
    return (
        _near_call(site, NARRATION_WAIT_HELPER)
        + bytes.fromhex("C6 06 FA 0B") + bytes([extra_ticks])
        + _near_call(site + 8, NARRATION_WAIT_HELPER)
        + b"\xC3"
    )


NARRATION_WAIT_WRAPPER_64_OFFSET = NARRATION_EXTRA_WAIT_CAVE
NARRATION_WAIT_WRAPPER_64 = _narration_wait_wrapper(NARRATION_WAIT_WRAPPER_64_OFFSET, NARRATION_EXTRA_WAIT_64)
NARRATION_WAIT_WRAPPER_80_OFFSET = NARRATION_WAIT_WRAPPER_64_OFFSET + len(NARRATION_WAIT_WRAPPER_64)
NARRATION_WAIT_WRAPPER_80 = _narration_wait_wrapper(NARRATION_WAIT_WRAPPER_80_OFFSET, NARRATION_EXTRA_WAIT_80)
NARRATION_EXTRA_WAIT_BLOB = NARRATION_WAIT_WRAPPER_64 + NARRATION_WAIT_WRAPPER_80
NARRATION_EXTRA_WAIT_CAVE_END = NARRATION_EXTRA_WAIT_CAVE + len(NARRATION_EXTRA_WAIT_BLOB)
assert len(NARRATION_WAIT_WRAPPER_64) == len(NARRATION_WAIT_WRAPPER_80) == 12
NARRATION_PAGE_WAIT_CALL_TARGETS_V151 = (
    NARRATION_WAIT_WRAPPER_64_OFFSET,
    NARRATION_WAIT_WRAPPER_64_OFFSET,
    NARRATION_WAIT_WRAPPER_80_OFFSET,
    NARRATION_WAIT_WRAPPER_64_OFFSET,
    NARRATION_WAIT_WRAPPER_64_OFFSET,
)
NARRATION_PAGE_WAIT_CALLS_V150 = tuple(_near_call(site, NARRATION_WAIT_HELPER) for site in NARRATION_PAGE_WAIT_CALL_SITES)
NARRATION_PAGE_WAIT_CALLS_V151 = tuple(_near_call(site, target) for site, target in zip(NARRATION_PAGE_WAIT_CALL_SITES, NARRATION_PAGE_WAIT_CALL_TARGETS_V151))

NARRATION_TEXTS_V150 = (
    "악신 아그니쟈가 쓰러지고 이셀하사에 평화가 찾아왔다.",
    "세리오스는 디나 공주와 결혼해 파렌 왕국의 왕이 되었다.",
    "함께 싸워 온 동료들도 이제는 무기를 잡을 일이 없어,",
    "각자의 고향으로 돌아갔다.",
    "얼마 뒤, 세리오스와 디나 사이에",
    "왕자가 태어났다.",
    "모든 사람이 바라던 파렌의 황태자.",
    "왕자는 아트라스라는 이름을 얻었고,",
    "넘치는 사랑 속에서 자라 열다섯 살이 되었다.",
    "빛나는 금발과 총명한 눈동자...",
    "그리고 무엇보다, 아버지를 닮은 올곧은 마음.",
    "악을 모르는 그 눈길은 늘 백성을 바라보며,",
    "훗날 왕이 될 사명에 불타고 있다.",
    "사람들은 아트라스 왕자를 사랑하고,",
    "왕자도 사람들을 사랑한다.",
    "파렌 왕국은 세리오스 왕이라는 커다란 태양과,",
    "아트라스 왕자라는 작은 태양이 지켜 더욱 번영했다.",
    "그러던 어느 날,",
    "대지진이 이셀하사 전역을 덮쳤다.",
    "낡은 건물들이 무너지고 각지에 심각한 피해가 발생했다.",
    "갑작스러운 재앙에 처음에는 혼란이 있었으나,",
    "사람들은 힘을 합쳐 복구에 나섰고,",
    "이셀하사는 곧 예전 모습을 되찾았다.",
    "...그렇게 보였다.",
    "그렇다. 아무도 알지 못했다.",
    "새로운 재앙이 닥쳐오고 있다는 것을...",
)
NARRATION_TEXTS = list(NARRATION_TEXTS_V150)
NARRATION_TEXTS[10] = "그리고 무엇보다 아버지를 닮은 올곧은 마음."
NARRATION_TEXTS = tuple(NARRATION_TEXTS)

NARRATION_PAGE_LAYOUTS = (
    (None, None, 0, 1, 2, 3),
    (None, None, 4, 5, 6, 7, 8),
    (9, 10, 11, 12, None, 13, 14, 15, 16),
    (17, 18, 19, None, 20, 21, 22, None, 23),
    (None, None, None, 24, None, 25),
)
# Five blank reveal cells on page 5 consume the otherwise unused ten bytes at the
# end of the original stream region. They are visually empty but retain timing.
NARRATION_PAGE_FILLER_CELLS = (0, 0, 0, 0, 5)
# Removing the comma shortens the fixed stream by one byte after centering. Add one
# invisible 8px indent byte to the first blank line on page 3. It produces no glyph
# and no reveal wait, so stream geometry is preserved without changing timing.
NARRATION_BLANK_LEAD_PAD_V150 = (0, 0, 0, 0, 0)
NARRATION_BLANK_LEAD_PAD_V151 = (0, 0, 1, 0, 0)


def _encode_narration_body(text: str) -> tuple[bytes, int]:
    out = bytearray(); cells = 0; i = 0
    while i < len(text):
        ch = text[i]
        if ch == " ":
            out += b"__"; cells += 1; i += 1; continue
        if ord(ch) < 0x80:
            j = i
            while j < len(text) and text[j] != " " and ord(text[j]) < 0x80:
                j += 1
            seq = text[i:j].encode("ascii")
            for k in range(0, len(seq), 2):
                out.append(seq[k]); out.append(seq[k + 1] if k + 1 < len(seq) else 0)
                cells += 1
            i = j; continue
        raw = ch.encode("cp949")
        if len(raw) != 2:
            raise PortError(f"오프닝 내레이션 CP949 2바이트 문자가 아닙니다: {ch!r}")
        out += raw; cells += 1; i += 1
    return bytes(out), cells


def _build_narration_stream(
    texts: tuple[str, ...],
    page_extra_ticks: tuple[int, ...],
    blank_lead_pad: tuple[int, ...],
    expected_page_gain_ticks: int,
) -> tuple[bytes, tuple[tuple[dict[str, object], ...], ...]]:
    out = bytearray(); pages = []
    for page_index, layout in enumerate(NARRATION_PAGE_LAYOUTS):
        rows = []; filler_used = False; blank_pad_used = False
        for token in layout:
            if token is None:
                filler = NARRATION_PAGE_FILLER_CELLS[page_index] if not filler_used else 0
                body = b"__" * filler; cells = filler
                lead = blank_lead_pad[page_index] if not blank_pad_used else 0
                if filler: filler_used = True
                if lead: blank_pad_used = True
                text = ""
            else:
                text = texts[token]
                body, cells = _encode_narration_body(text)
                if token <= 22:
                    lead = 31 - cells
                elif token == 23:
                    lead = 39
                elif token == 24:
                    lead = 7
                else:
                    lead = 13
                if lead < 0:
                    raise PortError(f"오프닝 중앙 정렬 폭을 초과했습니다: {text!r}")
            out += b" " * lead + body + b"\x00"
            rows.append({
                "text": text, "lead_8px": lead, "cells_16px": cells,
                "center_x": 72 + lead * 8 + cells * 8,
            })
        out += b"\xFF"
        pages.append(tuple(rows))
    if len(out) != NARRATION_STREAM_LENGTH:
        raise AssertionError(f"오프닝 새 스트림 길이 {len(out)} != {NARRATION_STREAM_LENGTH}")
    for page_index, rows in enumerate(pages):
        cells = sum(int(row["cells_16px"]) for row in rows)
        lhs = cells * 16 + NARRATION_PAGE_WAIT_NEW[page_index] + page_extra_ticks[page_index]
        rhs = NARRATION_PAGE_BASE_CELLS[page_index] * 16 + 0xA0 + expected_page_gain_ticks
        if lhs != rhs:
            raise AssertionError(
                f"오프닝 {page_index + 1}페이지 타이밍 검증 실패: {lhs} != {rhs}"
            )
    centered = [row for page in pages for row in page if row["text"] in texts[:23]]
    if len(centered) != 23 or any(row["center_x"] != 320 for row in centered):
        raise AssertionError("오프닝 중앙 정렬 23줄의 중심 X=320 검증 실패")
    return bytes(out), tuple(pages)


NARRATION_STREAM_V150, _NARRATION_LAYOUT_V150 = _build_narration_stream(
    NARRATION_TEXTS_V150, (0, 0, 0, 0, 0), NARRATION_BLANK_LEAD_PAD_V150, 0
)
NARRATION_STREAM_NEW, NARRATION_LAYOUT_REPORT = _build_narration_stream(
    NARRATION_TEXTS, NARRATION_PAGE_EXTRA_TICKS_V151, NARRATION_BLANK_LEAD_PAD_V151, 64
)

# Every later direct ABS_DELAY target receives the final +345-tick offset.
# This carries the new timeline forward so only the pre-blood intervals become
# longer; blood-and-later interval lengths remain identical to the stock schedule.
POSTBLOOD_PROPAGATION_SITES = (
    # (MOV AX instruction offset, original absolute target)
    (0x334B, 0x3930),
    (0x3486, 0x3B40),
    (0x3559, 0x3CE0),
    (0x369B, 0x3D90),
    (0x37A6, 0x3F00),
    (0x3A1E, 0x43D0),
    (0x3A3E, 0x4280),
    (0x3AD4, 0x43C0),
    (0x3AF6, 0x44C0),
    (0x3B47, 0x4550),
    (0x0217, 0x4B90),
    (0x03BE, 0x4E20),
    (0x0541, 0x4EC0),
    (0x0663, 0x5070),
    (0x0744, 0x51B0),
    (0x09B3, 0x53B0),
    (0x0BAC, 0x5770),
    (0x0C54, 0x5890),
    (0x0D3C, 0x5930),
    (0x0F9A, 0x5B30),
)

# v1.5.1 exact 5-second transfer ----------------------------------------------------
# G_OP0403.NIN is OP04 in the verified opening scene map. The current v1.5.0
# boundaries are:
#   OP01 end 1D:2F06 = 0x2C52
#   OP02 end 1D:305D = 0x2DDA
#   OP03 end / OP04 start 1D:3100 = 0x30D0
#   OP04 end 1D:31BE = 0x35FC
# Add exactly 320 ticks to the narration and shift only the first three boundaries
# by the same amount. OP02/OP03 durations therefore stay identical, while OP04 starts
# 320 ticks later and ends at the exact same absolute target: 1324 -> 1004 ticks.
TEXT_GOP0403_TRANSFER_TICKS = 320
TEXT_GOP0403_TRANSFER_SECONDS = TEXT_GOP0403_TRANSFER_TICKS / 64.0
TEXT_GOP0403_BOUNDARY_SITES = (0x2F06, 0x305D, 0x3100)
TEXT_GOP0403_BOUNDARY_V150 = (0x2C52, 0x2DDA, 0x30D0)
TEXT_GOP0403_BOUNDARY_V151 = tuple(x + TEXT_GOP0403_TRANSFER_TICKS for x in TEXT_GOP0403_BOUNDARY_V150)
TEXT_GOP0403_END_SITE = 0x31BE
TEXT_GOP0403_END_TARGET = 0x35FC
G_OP0403_V150_TICKS = TEXT_GOP0403_END_TARGET - TEXT_GOP0403_BOUNDARY_V150[-1]
G_OP0403_V151_TICKS = TEXT_GOP0403_END_TARGET - TEXT_GOP0403_BOUNDARY_V151[-1]
assert G_OP0403_V150_TICKS == 1324
assert G_OP0403_V151_TICKS == 1004
assert G_OP0403_V150_TICKS - G_OP0403_V151_TICKS == TEXT_GOP0403_TRANSFER_TICKS

SCENE_ANCHOR = bytes.fromhex("B8 00 17 B2 50")
REL_SETUP_DI = 0xBC
REL_SETUP_SI = 0xBF
REL_INITIAL_CALL = 0xE1   # 0A07
REL_POST_CALL = 0xE4      # 0A0A
REL_LOCAL_START = 0xE7    # 0A0D
REL_LOCAL_END = 0x18C     # 0AB2
REL_LOOP_COUNT = 0xE7
REL_LOOP_DI = 0xEA
REL_LOOP_SI = 0xED
REL_LOOP_BLIT = 0xF6
REL_HEIGHTS = (0x114, 0x12F, 0x153, 0x16E)

ORIGINAL_SETUP_DI = bytes.fromhex("BF 50 1F")
ORIGINAL_SETUP_SI = bytes.fromhex("BE 80 3E")
ORIGINAL_INITIAL_CALL = bytes.fromhex("E8 25 00")
ORIGINAL_POST_CALL = bytes.fromhex("E8 AA 10")
ORIGINAL_LOOP_COUNT = bytes.fromhex("B9 C8 00")
ORIGINAL_LOOP_DI = ORIGINAL_SETUP_DI
ORIGINAL_LOOP_SI = ORIGINAL_SETUP_SI
ORIGINAL_LOOP_BLIT = bytes.fromhex("E8 10 00")
ORIGINAL_HEIGHT = bytes.fromhex("B9 C8 00")

V11_SETUP_DI = bytes.fromhex("BF 10 00")
V11_SETUP_SI = bytes.fromhex("BE 00 00")
V11_LOOP_BLIT = bytes.fromhex("90 90 90")
V11_HEIGHT = bytes.fromhex("B9 90 01")

V12_SETUP_DI = bytes.fromhex("BF 50 24")
V12_SETUP_SI = bytes.fromhex("BE 80 3E")
V12_LOOP_BLIT = bytes.fromhex("E8 10 00")
V12_HEIGHT = ORIGINAL_HEIGHT

PEOPLE_ORIGINAL = bytes.fromhex("75 CF EB 5B 90 B8 00 22 B2 42 E8")
PEOPLE_PATCHED  = bytes.fromhex("75 CF 90 90 90 B8 00 22 B2 42 E8")
PEOPLE_JUMP_REL = 2

BLOOD_TEMPLATE: tuple[int | None, ...] = (
    0xC6,0x44,0x06,None, 0xC6,0x44,0x08,None,
    0xC6,0x44,0x09,None, 0xC6,0x44,0x0B,None,
    0xC6,0x44,0x0C,None, 0xC6,0x44,0x0E,None,
)
BLOOD_VALUE_REL=(3,7,11,15,19,23)
BLOOD_RED_VALUES=(0,0,0,0,0,0)

class PortError(Exception):
    pass

@dataclass(frozen=True)
class Segment:
    ordinal:int
    table_entry:int
    file_offset:int
    length:int
    flags:int
    min_alloc:int

@dataclass(frozen=True)
class Analysis:
    root:Path
    opening:Path
    flora:Path
    people:Path|None
    flora_state:str
    people_state:str
    blood_values:tuple[int,int,int,int,int,int]|None
    intro_hold_state:str
    preblood_timing_state:str
    text_gop0403_timing_state:str
    narration_state:str
    opening_sha256:str
    flora_sha256:str
    segment_length:int
    relocation_count:int
    scene_offset:int


def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def atomic_write(path:Path,data:bytes)->None:
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def backup_once(path:Path)->Path:
    b=path.with_name(path.name+BACKUP_SUFFIX)
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1": return b
    if not b.exists(): shutil.copy2(path,b)
    return b


def resolve_root(path:Path)->tuple[Path,Path,Path,Path|None]:
    p=path.expanduser().resolve()
    if p.is_file() and p.name.upper()=='OPENING.EXE': root=p.parent
    elif p.is_dir(): root=p.parent if p.name.upper()=='GRP' and (p.parent/'OPENING.EXE').is_file() else p
    else: raise PortError('게임 폴더 또는 OPENING.EXE를 선택해야 합니다.')
    opening=root/'OPENING.EXE'; flora=root/'GRP'/'G_OP1700.BZP'; people=root/'GRP'/'G_OP2200.BZB'
    if not opening.is_file(): raise PortError(f'OPENING.EXE를 찾지 못했습니다: {opening}')
    if not flora.is_file(): raise PortError(f'G_OP1700.BZP를 찾지 못했습니다: {flora}')
    return root,opening,flora,(people if people.is_file() else None)


def parse_segments(exe:bytes)->list[Segment]:
    if len(exe)<0x40 or exe[:2]!=b'MZ': raise PortError('MZ 실행 파일이 아닙니다.')
    ne=struct.unpack_from('<I',exe,0x3C)[0]
    if ne+0x40>len(exe) or exe[ne:ne+2]!=b'NE': raise PortError('NE 헤더를 찾지 못했습니다.')
    count=struct.unpack_from('<H',exe,ne+0x1C)[0]
    table=ne+struct.unpack_from('<H',exe,ne+0x22)[0]
    shift=struct.unpack_from('<H',exe,ne+0x32)[0]
    out=[]
    for i in range(count):
        ent=table+i*8
        units,length,flags,min_alloc=struct.unpack_from('<HHHH',exe,ent)
        real=0x10000 if length==0 else length; off=units<<shift
        if off+real>len(exe): raise PortError(f'NE 세그먼트 {i+1}이 파일 범위를 벗어납니다.')
        out.append(Segment(i+1,ent,off,real,flags,min_alloc))
    return out


def relocation_blob(exe:bytes,seg:Segment)->tuple[int,bytes,list[int]]:
    if not (seg.flags & 0x0100): return 0,b'',[]
    p=seg.file_offset+seg.length
    if p+2>len(exe): raise PortError('세그먼트 재배치 표가 잘렸습니다.')
    count=struct.unpack_from('<H',exe,p)[0]; size=2+count*8
    if p+size>len(exe): raise PortError('세그먼트 재배치 항목이 잘렸습니다.')
    blob=exe[p:p+size]
    sources=[struct.unpack_from('<H',blob,2+i*8+2)[0] for i in range(count)]
    return count,blob,sources


def find_scene(block:bytes)->int:
    hits=[];start=0
    while True:
        i=block.find(SCENE_ANCHOR,start)
        if i<0: break
        hits.append(i);start=i+1
    if len(hits)!=1: raise PortError(f'G_OP1700 장면 시그니처가 정확히 한 곳이 아닙니다: {len(hits)}')
    return hits[0]


def near_target(block:bytes,at:int,opcode:int)->int|None:
    if at+3>len(block) or block[at]!=opcode: return None
    return at+3+struct.unpack_from('<h',block,at+1)[0]


def find_people_state(block:bytes)->str:
    a=block.find(PEOPLE_ORIGINAL); b=block.find(PEOPLE_PATCHED)
    if a>=0 and b<0:return 'skipped'
    if b>=0 and a<0:return 'enabled'
    return 'unknown'


def blood_values(block:bytes)->tuple[int,int,int,int,int,int]|None:
    hits=[]
    for off in range(len(block)-len(BLOOD_TEMPLATE)+1):
        if all(v is None or block[off+i]==v for i,v in enumerate(BLOOD_TEMPLATE)): hits.append(off)
    if len(hits)!=1:return None
    off=hits[0]
    return tuple(block[off+i] for i in BLOOD_VALUE_REL)  # type: ignore[return-value]


def flora_state(exe:bytes,segs:list[Segment])->tuple[str,int]:
    seg=segs[SEGMENT_ORDINAL-1]; block=exe[seg.file_offset:seg.file_offset+seg.length]; scene=find_scene(block)
    initial=scene+REL_INITIAL_CALL; post=scene+REL_POST_CALL
    if (seg.length==BASE_SEGMENT_LENGTH+len(TAIL_CODE)
        and block[scene+REL_LOCAL_START:scene+REL_LOCAL_START+len(LOCAL_CODE)]==LOCAL_CODE
        and block[TAIL_OFFSET:TAIL_OFFSET+len(TAIL_CODE)]==TAIL_CODE
        and near_target(block,initial,0xE8)==scene+REL_LOCAL_START
        and near_target(block,post,0xE9)==scene+REL_LOCAL_END):
        return 'pc98_smooth_200_preshift32',scene
    if (seg.length==BASE_SEGMENT_LENGTH+len(TAIL_CODE)
        and block[scene+REL_LOCAL_START:scene+REL_LOCAL_START+len(OLD_V13_LOCAL_CODE)]==OLD_V13_LOCAL_CODE
        and block[TAIL_OFFSET:TAIL_OFFSET+len(TAIL_CODE)]==TAIL_CODE
        and near_target(block,initial,0xE8)==scene+REL_LOCAL_START
        and near_target(block,post,0xE9)==scene+REL_LOCAL_END):
        return 'v13_smooth_232_black_start',scene
    if (seg.length==BASE_SEGMENT_LENGTH+OLD_V12_TAIL_SIZE
        and OLD_V12_MARKER in block[TAIL_OFFSET:TAIL_OFFSET+OLD_V12_TAIL_SIZE]
        and near_target(block,initial,0xE8)==TAIL_OFFSET):
        return 'v12_fixed_strip_flicker',scene
    di=block[scene+REL_SETUP_DI:scene+REL_SETUP_DI+3]
    si=block[scene+REL_SETUP_SI:scene+REL_SETUP_SI+3]
    loop=block[scene+REL_LOOP_BLIT:scene+REL_LOOP_BLIT+3]
    hs=[block[scene+r:scene+r+3] for r in REL_HEIGHTS]
    if di==V11_SETUP_DI and si==V11_SETUP_SI and loop==V11_LOOP_BLIT and all(x==V11_HEIGHT for x in hs):
        return 'v11_static_fullheight',scene
    if di==ORIGINAL_SETUP_DI and si==ORIGINAL_SETUP_SI and loop==ORIGINAL_LOOP_BLIT and all(x==ORIGINAL_HEIGHT for x in hs):
        return 'dos_200_scroll',scene
    if di==V12_SETUP_DI and si==V12_SETUP_SI and loop==V12_LOOP_BLIT and all(x==V12_HEIGHT for x in hs):
        return 'v12_partial_or_damaged',scene
    return 'unknown',scene


def intro_hold_state(exe:bytes,segs:list[Segment])->str:
    seg=segs[SEGMENT_ORDINAL-1]
    block=exe[seg.file_offset:seg.file_offset+seg.length]
    if INTRO_CAVE_END>len(block) or INTRO_FINAL_CLEAR_CALL+3>len(block):
        return 'unsupported'
    call=block[INTRO_FINAL_CLEAR_CALL:INTRO_FINAL_CLEAR_CALL+3]
    cave=block[INTRO_EXTRA_WAIT_CAVE:INTRO_CAVE_END]
    if call==INTRO_PATCHED_CALL and cave==INTRO_WAIT_WRAPPER:
        return 'extended_5s'
    if call==INTRO_ORIGINAL_CALL and all(x==0x90 for x in cave):
        return 'original'
    return 'unknown'


def patch_intro_hold(exe:bytes)->bytes:
    segs=parse_segments(exe)
    if len(segs)<SEGMENT_ORDINAL:
        raise PortError('필요한 NE 세그먼트 0x1D가 없습니다.')
    seg=segs[SEGMENT_ORDINAL-1]
    state=intro_hold_state(exe,segs)
    if state=='extended_5s':
        return exe
    if state != 'original':
        raise PortError(f'오프닝 앞부분 설명 타이밍 위치가 지원 상태가 아닙니다: {state}')
    count,fixups,sources=relocation_blob(exe,seg)
    protected=set(range(INTRO_FINAL_CLEAR_CALL,INTRO_FINAL_CLEAR_CALL+3)) | set(range(INTRO_EXTRA_WAIT_CAVE,INTRO_CAVE_END))
    bad=[src for src in sources if src in protected]
    if bad:
        raise PortError(f'설명 타이밍 패치 위치에 NE 재배치 항목이 있습니다: {bad}')
    out=bytearray(exe)
    base=seg.file_offset
    out[base+INTRO_EXTRA_WAIT_CAVE:base+INTRO_CAVE_END]=INTRO_WAIT_WRAPPER
    out[base+INTRO_FINAL_CLEAR_CALL:base+INTRO_FINAL_CLEAR_CALL+3]=INTRO_PATCHED_CALL
    check=bytes(out)
    csegs=parse_segments(check)
    cseg=csegs[SEGMENT_ORDINAL-1]
    ccount,cfix,_=relocation_blob(check,cseg)
    if ccount!=count or cfix!=fixups:
        raise PortError('설명 타이밍 패치 후 NE 재배치 표 보존 검증에 실패했습니다.')
    if intro_hold_state(check,csegs)!='extended_5s':
        raise PortError('설명 구간 +5초 패치 검증에 실패했습니다.')
    return check


def text_gop0403_timing_state(exe: bytes, segs: list[Segment]) -> str:
    seg = segs[SEGMENT_ORDINAL - 1]
    block = exe[seg.file_offset:seg.file_offset + seg.length]
    vals = []
    for off in TEXT_GOP0403_BOUNDARY_SITES:
        if off + 3 > len(block) or block[off] != 0xB8:
            return "unsupported"
        vals.append(struct.unpack_from("<H", block, off + 1)[0])
    if TEXT_GOP0403_END_SITE + 3 > len(block) or block[TEXT_GOP0403_END_SITE] != 0xB8:
        return "unsupported"
    end = struct.unpack_from("<H", block, TEXT_GOP0403_END_SITE + 1)[0]
    if end != TEXT_GOP0403_END_TARGET:
        return "unknown"
    if tuple(vals) == TEXT_GOP0403_BOUNDARY_V150:
        return "v150"
    if tuple(vals) == TEXT_GOP0403_BOUNDARY_V151:
        return "text_plus5_gop0403_minus5"
    return "mixed"


def patch_text_gop0403_timing(exe: bytes) -> bytes:
    segs = parse_segments(exe)
    if len(segs) < SEGMENT_ORDINAL:
        raise PortError("필요한 NE 세그먼트 0x1D가 없습니다.")
    seg = segs[SEGMENT_ORDINAL - 1]
    state = text_gop0403_timing_state(exe, segs)
    if state == "text_plus5_gop0403_minus5":
        return exe
    if state != "v150":
        raise PortError(f"오프닝 +5초 / G_OP0403 -5초 타이밍 상태가 지원되지 않습니다: {state}")
    count, fixups, sources = relocation_blob(exe, seg)
    protected = set()
    for off in TEXT_GOP0403_BOUNDARY_SITES:
        protected.update(range(off, off + 3))
    protected.update(range(TEXT_GOP0403_END_SITE, TEXT_GOP0403_END_SITE + 3))
    bad = [src for src in sources if src in protected]
    if bad:
        raise PortError(f"오프닝 장면 경계 타이밍 위치에 NE 재배치 항목이 있습니다: {bad}")
    out = bytearray(exe); base = seg.file_offset
    for off, old, new in zip(TEXT_GOP0403_BOUNDARY_SITES, TEXT_GOP0403_BOUNDARY_V150, TEXT_GOP0403_BOUNDARY_V151):
        cur = struct.unpack_from("<H", out, base + off + 1)[0]
        if cur != old:
            raise PortError(f"오프닝 장면 경계 값이 예상과 다릅니다: 1D:{off:04X} = 0x{cur:04X}")
        struct.pack_into("<H", out, base + off + 1, new)
    # OP04 end is deliberately unchanged; this is what makes G_OP0403 exactly 5 s shorter.
    if struct.unpack_from("<H", out, base + TEXT_GOP0403_END_SITE + 1)[0] != TEXT_GOP0403_END_TARGET:
        raise PortError("G_OP0403 종료 앵커가 예상과 다릅니다.")
    check = bytes(out); csegs = parse_segments(check); cseg = csegs[SEGMENT_ORDINAL - 1]
    ccount, cfix, _ = relocation_blob(check, cseg)
    if ccount != count or cfix != fixups:
        raise PortError("오프닝 +5초 / G_OP0403 -5초 패치 후 NE 재배치 표가 변했습니다.")
    if text_gop0403_timing_state(check, csegs) != "text_plus5_gop0403_minus5":
        raise PortError("오프닝 +5초 / G_OP0403 -5초 타이밍 검증에 실패했습니다.")
    return check


def preblood_timing_state(exe:bytes,segs:list[Segment])->str:
    seg=segs[SEGMENT_ORDINAL-1]
    block=exe[seg.file_offset:seg.file_offset+seg.length]
    transfer = text_gop0403_timing_state(exe, segs)
    states=[]
    transfer_map = {0x305D: TEXT_GOP0403_BOUNDARY_V151[1], 0x3100: TEXT_GOP0403_BOUNDARY_V151[2]}
    for off,old,new,_extra in PREBLOOD_TIMING_SITES:
        if off+3>len(block) or block[off]!=0xB8:
            return 'unsupported'
        target=struct.unpack_from('<H',block,off+1)[0]
        if target==old: states.append('original')
        elif target==new: states.append('extended')
        elif transfer == 'text_plus5_gop0403_minus5' and off in transfer_map and target == transfer_map[off]:
            states.append('transfer')
        else: states.append('unknown')
    for off,old in POSTBLOOD_PROPAGATION_SITES:
        if off+3>len(block) or block[off]!=0xB8:
            return 'unsupported'
        target=struct.unpack_from('<H',block,off+1)[0]
        new=old+PREBLOOD_TOTAL_EXTRA_TICKS
        if target==old: states.append('original')
        elif target==new: states.append('extended')
        else: states.append('unknown')
    if all(x=='original' for x in states): return 'original'
    if all(x=='extended' for x in states): return 'extended_5_390625s'
    if transfer == 'text_plus5_gop0403_minus5' and all(x in ('extended','transfer') for x in states):
        return 'extended_5_390625s_text5_gop0403_minus5'
    if 'unknown' in states: return 'unknown'
    return 'mixed'


def patch_preblood_timing(exe:bytes)->bytes:
    segs=parse_segments(exe)
    if len(segs)<SEGMENT_ORDINAL:
        raise PortError('필요한 NE 세그먼트 0x1D가 없습니다.')
    seg=segs[SEGMENT_ORDINAL-1]
    state=preblood_timing_state(exe,segs)
    if state in ('extended_5_390625s','extended_5_390625s_text5_gop0403_minus5'):
        return exe
    if state not in ('original','mixed'):
        raise PortError(f'피 장면 이전 타이밍 위치가 지원 상태가 아닙니다: {state}')
    count,fixups,sources=relocation_blob(exe,seg)
    protected=set()
    for off,_old,_new,_extra in PREBLOOD_TIMING_SITES:
        protected.update(range(off,off+3))
    for off,_old in POSTBLOOD_PROPAGATION_SITES:
        protected.update(range(off,off+3))
    bad=[src for src in sources if src in protected]
    if bad:
        raise PortError(f'피 장면 이전 타이밍 패치 위치에 NE 재배치 항목이 있습니다: {bad}')
    out=bytearray(exe); base=seg.file_offset
    for off,old,new,_extra in PREBLOOD_TIMING_SITES:
        cur=struct.unpack_from('<H',out,base+off+1)[0]
        if cur==new:
            continue
        if cur!=old:
            raise PortError(f'피 장면 이전 타이밍 값이 예상과 다릅니다: 1D:{off:04X} = 0x{cur:04X}')
        struct.pack_into('<H',out,base+off+1,new)
    for off,old in POSTBLOOD_PROPAGATION_SITES:
        new=old+PREBLOOD_TOTAL_EXTRA_TICKS
        cur=struct.unpack_from('<H',out,base+off+1)[0]
        if cur==new:
            continue
        if cur!=old:
            raise PortError(f'피 장면 이후 절대 타임라인 값이 예상과 다릅니다: 1D:{off:04X} = 0x{cur:04X}')
        struct.pack_into('<H',out,base+off+1,new)
    check=bytes(out); csegs=parse_segments(check); cseg=csegs[SEGMENT_ORDINAL-1]
    ccount,cfix,_=relocation_blob(check,cseg)
    if ccount!=count or cfix!=fixups:
        raise PortError('피 장면 이전 타이밍 패치 후 NE 재배치 표 보존 검증에 실패했습니다.')
    if preblood_timing_state(check,csegs)!='extended_5_390625s':
        raise PortError('피 장면 이전 +5.39초 타이밍 패치 검증에 실패했습니다.')
    return check



def _narration_relocation_state(exe: bytes, seg: Segment) -> str:
    if not (seg.flags & 0x0100):
        return "unsupported"
    rp = seg.file_offset + seg.length
    count = struct.unpack_from("<H", exe, rp)[0]
    matched = []
    for i in range(count):
        ep = rp + 2 + i * 8
        typ, flags, source, target_seg, target_off = struct.unpack_from("<BBHHH", exe, ep)
        if (typ, flags, target_seg, target_off) == NARRATION_RELOC_SIGNATURE and source in (*NARRATION_RELOC_OLD, *NARRATION_RELOC_NEW):
            matched.append(source)
    pair = tuple(matched)
    if pair == NARRATION_RELOC_OLD: return "legacy"
    if pair == NARRATION_RELOC_NEW: return "centered"
    return "unknown"


def _narration_wait_extension_state(exe: bytes, code: Segment) -> str:
    calls = tuple(
        exe[code.file_offset + off:code.file_offset + off + 3]
        for off in NARRATION_PAGE_WAIT_CALL_SITES
    )
    cave = exe[
        code.file_offset + NARRATION_EXTRA_WAIT_CAVE:
        code.file_offset + NARRATION_EXTRA_WAIT_CAVE_END
    ]
    if calls == NARRATION_PAGE_WAIT_CALLS_V151 and cave == NARRATION_EXTRA_WAIT_BLOB:
        return "distributed_5s"
    if calls == NARRATION_PAGE_WAIT_CALLS_V150 and cave == b"\x90" * len(NARRATION_EXTRA_WAIT_BLOB):
        return "none"
    return "unknown"


def narration_state(exe: bytes, segs: list[Segment]) -> str:
    if len(segs) < NARRATION_DATA_SEGMENT:
        return "unsupported"
    code = segs[NARRATION_CODE_SEGMENT - 1]; data = segs[NARRATION_DATA_SEGMENT - 1]
    parser = exe[code.file_offset + NARRATION_PARSER_OFFSET:code.file_offset + NARRATION_PARSER_OFFSET + NARRATION_PARSER_LENGTH]
    stream = exe[data.file_offset + NARRATION_STREAM_OFFSET:data.file_offset + NARRATION_STREAM_OFFSET + NARRATION_STREAM_LENGTH]
    waits = tuple(exe[code.file_offset + off + 4] for off in NARRATION_PAGE_WAIT_SITES)
    reloc = _narration_relocation_state(exe, code)
    ext = _narration_wait_extension_state(exe, code)
    if parser == NARRATION_PARSER_NEW and stream == NARRATION_STREAM_NEW and waits == NARRATION_PAGE_WAIT_NEW and reloc == "centered" and ext == "distributed_5s":
        return "centered_punctuation_v151_text_plus5"
    if parser == NARRATION_PARSER_NEW and stream == NARRATION_STREAM_V150 and waits == NARRATION_PAGE_WAIT_NEW and reloc == "centered" and ext == "none":
        return "centered_punctuation_v150"
    if parser == NARRATION_PARSER_OLD and waits == NARRATION_PAGE_WAIT_OLD and reloc == "legacy" and ext == "none":
        return "legacy_renderer"
    return "unknown"


def patch_narration_centering(exe: bytes) -> bytes:
    segs = parse_segments(exe)
    state = narration_state(exe, segs)
    if state == "centered_punctuation_v151_text_plus5":
        return exe
    if state not in ("legacy_renderer", "centered_punctuation_v150"):
        raise PortError(f"오프닝 내레이션 렌더러가 지원 상태가 아닙니다: {state}")
    code = segs[NARRATION_CODE_SEGMENT - 1]; data = segs[NARRATION_DATA_SEGMENT - 1]
    if NARRATION_STREAM_OFFSET + NARRATION_STREAM_LENGTH > data.length:
        raise PortError("오프닝 내레이션 스트림 영역이 데이터 세그먼트를 벗어납니다.")
    _dc, _db, data_sources = relocation_blob(exe, data)
    bad_data = [x for x in data_sources if NARRATION_STREAM_OFFSET <= x < NARRATION_STREAM_OFFSET + NARRATION_STREAM_LENGTH]
    if bad_data:
        raise PortError(f"오프닝 내레이션 데이터 영역에 NE 재배치 항목이 있습니다: {bad_data}")

    before_count, before_blob, code_sources = relocation_blob(exe, code)
    protected = set(range(NARRATION_EXTRA_WAIT_CAVE, NARRATION_EXTRA_WAIT_CAVE_END))
    for off in NARRATION_PAGE_WAIT_CALL_SITES:
        protected.update(range(off, off + 3))
    bad_code = [x for x in code_sources if x in protected]
    if bad_code:
        raise PortError(f"오프닝 분산 대기 코드 위치에 NE 재배치 항목이 있습니다: {bad_code}")

    out = bytearray(exe); base = code.file_offset
    # Both supported source states use direct CALL 2600h and an all-NOP cave.
    for off, expected in zip(NARRATION_PAGE_WAIT_CALL_SITES, NARRATION_PAGE_WAIT_CALLS_V150):
        if out[base + off:base + off + 3] != expected:
            raise PortError(f"오프닝 페이지 대기 CALL이 예상 상태가 아닙니다: 1D:{off:04X}")
    if out[base + NARRATION_EXTRA_WAIT_CAVE:base + NARRATION_EXTRA_WAIT_CAVE_END] != b"\x90" * len(NARRATION_EXTRA_WAIT_BLOB):
        raise PortError("오프닝 분산 대기 code cave가 비어 있지 않습니다.")

    if state == "legacy_renderer":
        out[base + NARRATION_PARSER_OFFSET:base + NARRATION_PARSER_OFFSET + NARRATION_PARSER_LENGTH] = NARRATION_PARSER_NEW
        for off, expected, value in zip(NARRATION_PAGE_WAIT_SITES, NARRATION_PAGE_WAIT_OLD, NARRATION_PAGE_WAIT_NEW):
            if out[base + off:base + off + 4] != bytes.fromhex("C6 06 FA 0B") or out[base + off + 4] != expected:
                raise PortError(f"오프닝 페이지 대기값이 예상 상태가 아닙니다: 1D:{off:04X}")
            out[base + off + 4] = value

        # Retarget exactly the two segment-word fixups used by the compacted parser.
        rp = code.file_offset + code.length
        found = []
        for i in range(before_count):
            ep = rp + 2 + i * 8
            typ, flags, source, target_seg, target_off = struct.unpack_from("<BBHHH", out, ep)
            if source in NARRATION_RELOC_OLD:
                if (typ, flags, target_seg, target_off) != NARRATION_RELOC_SIGNATURE:
                    raise PortError(f"오프닝 parser relocation 서명이 다릅니다: source=0x{source:04X}")
                index = NARRATION_RELOC_OLD.index(source)
                struct.pack_into("<H", out, ep + 2, NARRATION_RELOC_NEW[index])
                found.append(source)
        if tuple(found) != NARRATION_RELOC_OLD:
            raise PortError(f"오프닝 parser relocation 두 항목을 찾지 못했습니다: {found}")

    out[data.file_offset + NARRATION_STREAM_OFFSET:data.file_offset + NARRATION_STREAM_OFFSET + NARRATION_STREAM_LENGTH] = NARRATION_STREAM_NEW
    out[base + NARRATION_EXTRA_WAIT_CAVE:base + NARRATION_EXTRA_WAIT_CAVE_END] = NARRATION_EXTRA_WAIT_BLOB
    for off, patched_call in zip(NARRATION_PAGE_WAIT_CALL_SITES, NARRATION_PAGE_WAIT_CALLS_V151):
        out[base + off:base + off + 3] = patched_call

    check = bytes(out); csegs = parse_segments(check); ccode = csegs[NARRATION_CODE_SEGMENT - 1]
    after_count, after_blob, _ = relocation_blob(check, ccode)
    if after_count != before_count or len(after_blob) != len(before_blob):
        raise PortError("오프닝 parser 패치 후 NE 재배치 표 구조가 달라졌습니다.")
    if state == "legacy_renderer":
        normalized = bytearray(after_blob)
        for i in range(after_count):
            ep = 2 + i * 8
            source = struct.unpack_from("<H", normalized, ep + 2)[0]
            if source in NARRATION_RELOC_NEW:
                index = NARRATION_RELOC_NEW.index(source)
                struct.pack_into("<H", normalized, ep + 2, NARRATION_RELOC_OLD[index])
        if bytes(normalized) != before_blob:
            raise PortError("오프닝 parser relocation source 외의 항목이 변경됐습니다.")
    elif after_blob != before_blob:
        raise PortError("v1.5.0 -> v1.5.1 갱신 중 relocation이 변경됐습니다.")
    if narration_state(check, csegs) != "centered_punctuation_v151_text_plus5":
        raise PortError("오프닝 중앙 정렬/문장부호/+5초 분산 렌더러 검증에 실패했습니다.")
    return check


def analyze(path:Path)->Analysis:
    root,opening,flora,people=resolve_root(path); exe=opening.read_bytes(); segs=parse_segments(exe)
    if len(segs)<SEGMENT_ORDINAL:raise PortError('필요한 NE 세그먼트 0x1D가 없습니다.')
    st,scene=flora_state(exe,segs); seg=segs[SEGMENT_ORDINAL-1]; rc,_,_=relocation_blob(exe,seg)
    block=exe[seg.file_offset:seg.file_offset+seg.length]
    return Analysis(root,opening,flora,people,st,find_people_state(block),blood_values(block),intro_hold_state(exe,segs),preblood_timing_state(exe,segs),text_gop0403_timing_state(exe,segs),narration_state(exe,segs),sha256_file(opening),sha256_file(flora),seg.length,rc,scene)


def analysis_dict(a:Analysis)->dict:
    transfer_ok = a.text_gop0403_timing_state == 'text_plus5_gop0403_minus5'
    narration_ok = a.narration_state == 'centered_punctuation_v151_text_plus5'
    preblood_ok = a.preblood_timing_state in ('extended_5_390625s','extended_5_390625s_text5_gop0403_minus5')
    return {
        'tool_version':VERSION,'root':str(a.root),'opening':str(a.opening),'opening_sha256':a.opening_sha256,
        'flora_state':a.flora_state,'flora_scene':f'1D:{a.scene_offset:04X}',
        'segment_1d_length':a.segment_length,'segment_1d_relocation_count':a.relocation_count,
        'g_op1700_sha256':a.flora_sha256,'g_op1700_matches_verified_asset':a.flora_sha256==KNOWN_G_OP1700_SHA256,
        'people_state':a.people_state,'blood_values':None if a.blood_values is None else list(a.blood_values),
        'intro_narration_hold':a.intro_hold_state,'intro_narration_extra_seconds':5 if a.intro_hold_state=='extended_5s' else 0,
        'preblood_timing':a.preblood_timing_state,'preblood_extra_ticks':PREBLOOD_TOTAL_EXTRA_TICKS if preblood_ok else 0,
        'preblood_extra_seconds':PREBLOOD_TOTAL_EXTRA_SECONDS if preblood_ok else 0,
        'text_gop0403_timing':a.text_gop0403_timing_state,
        'distributed_text_extra_ticks':NARRATION_DISTRIBUTED_EXTRA_TICKS if (narration_ok and transfer_ok) else 0,
        'distributed_text_extra_seconds':NARRATION_DISTRIBUTED_EXTRA_SECONDS if (narration_ok and transfer_ok) else 0,
        'distributed_text_page_net_extra_ticks':[64,64,64,64,64] if (narration_ok and transfer_ok) else [0,0,0,0,0],
        'g_op0403_duration_ticks':G_OP0403_V151_TICKS if transfer_ok else G_OP0403_V150_TICKS,
        'g_op0403_duration_seconds':(G_OP0403_V151_TICKS if transfer_ok else G_OP0403_V150_TICKS)/64.0,
        'g_op0403_reduction_ticks':TEXT_GOP0403_TRANSFER_TICKS if transfer_ok else 0,
        'g_op0403_reduction_seconds':TEXT_GOP0403_TRANSFER_SECONDS if transfer_ok else 0,
        'intro_narration_renderer':a.narration_state,
        'intro_narration_centering':{
            'center_x':320,
            'centered_through':'이셀하사는 곧 예전 모습을 되찾았다.',
            'punctuation_supported':a.narration_state in ('centered_punctuation_v150','centered_punctuation_v151_text_plus5'),
            'removed_comma':'그리고 무엇보다 아버지를 닮은 올곧은 마음.' if narration_ok else None,
        },
        'smooth_scroll':{
            'window':{'x':128,'y':84,'width':384,'height':232},
            'virtual_rows':432,'start_virtual_row':200,'end_virtual_row':0,'movement_frames':200,
            'upper_extension_rows':32,
            'behavior':'The animation starts 32 rows higher than v1.3, so the 384x232 window is full from frame 0; the upper extension still enters naturally during the final 32 frames.'
        }
    }


def normalize_original_scene(out:bytearray,seg:Segment,scene:int)->None:
    b=seg.file_offset+scene
    out[b+REL_SETUP_DI:b+REL_SETUP_DI+3]=ORIGINAL_SETUP_DI
    out[b+REL_SETUP_SI:b+REL_SETUP_SI+3]=ORIGINAL_SETUP_SI
    out[b+REL_LOOP_COUNT:b+REL_LOOP_COUNT+3]=ORIGINAL_LOOP_COUNT
    out[b+REL_LOOP_DI:b+REL_LOOP_DI+3]=ORIGINAL_LOOP_DI
    out[b+REL_LOOP_SI:b+REL_LOOP_SI+3]=ORIGINAL_LOOP_SI
    out[b+REL_LOOP_BLIT:b+REL_LOOP_BLIT+3]=ORIGINAL_LOOP_BLIT
    for r in REL_HEIGHTS: out[b+r:b+r+3]=ORIGINAL_HEIGHT


def inject_smooth_flora(exe:bytes)->bytes:
    segs=parse_segments(exe); seg=segs[SEGMENT_ORDINAL-1]; state,scene=flora_state(exe,segs)
    if state=='pc98_smooth_200_preshift32': return exe
    if state not in ('dos_200_scroll','v11_static_fullheight','v12_fixed_strip_flicker','v12_partial_or_damaged','v13_smooth_232_black_start'):
        raise PortError(f'지원하지 않는 플로라 코드 상태입니다: {state}')
    if SEGMENT_ORDINAL>=len(segs): raise PortError('세그먼트 0x1D 다음 영역을 찾을 수 없습니다.')
    if seg.length not in (BASE_SEGMENT_LENGTH,BASE_SEGMENT_LENGTH+OLD_V12_TAIL_SIZE,BASE_SEGMENT_LENGTH+len(TAIL_CODE)):
        raise PortError(f'세그먼트 0x1D 길이가 지원 범위와 다릅니다: 0x{seg.length:X}')
    count,fixups,sources=relocation_blob(exe,seg)
    local_lo=scene+REL_LOCAL_START; local_hi=scene+REL_LOCAL_END
    bad=[x for x in sources if local_lo<=x<local_hi]
    if bad: raise PortError(f'교체할 플로라 루틴 안에 NE 재배치 항목이 있습니다: {bad}')
    next_off=segs[SEGMENT_ORDINAL].file_offset
    required=len(TAIL_CODE)+len(fixups)
    capacity=next_off-(seg.file_offset+BASE_SEGMENT_LENGTH)
    if required>capacity: raise PortError(f'새 루틴과 재배치 표 공간이 부족합니다: 필요 {required}, 사용 가능 {capacity}')

    out=bytearray(exe)
    normalize_original_scene(out,seg,scene)
    # Replace the old per-frame blit body with the controller. The unused remainder
    # is filled with NOPs so v1.1/v1.2 leftovers cannot execute accidentally.
    local_file=seg.file_offset+local_lo
    out[local_file:seg.file_offset+local_hi]=b'\x90'*(local_hi-local_lo)
    out[local_file:local_file+len(LOCAL_CODE)]=LOCAL_CODE

    # Rebuild the tail from the verified original segment boundary. This upgrades
    # v1.2 in place and moves the original relocation table intact.
    old_base_end=seg.file_offset+BASE_SEGMENT_LENGTH
    out[old_base_end:next_off]=b'\0'*(next_off-old_base_end)
    out[old_base_end:old_base_end+len(TAIL_CODE)]=TAIL_CODE
    out[old_base_end+len(TAIL_CODE):old_base_end+len(TAIL_CODE)+len(fixups)]=fixups
    new_len=BASE_SEGMENT_LENGTH+len(TAIL_CODE)
    struct.pack_into('<H',out,seg.table_entry+2,new_len)
    struct.pack_into('<H',out,seg.table_entry+6,max(new_len,seg.min_alloc))
    newseg=Segment(seg.ordinal,seg.table_entry,seg.file_offset,new_len,seg.flags,max(new_len,seg.min_alloc))

    # Initial CALL -> local controller at 0A0D. Controller starts 32 rows higher and performs 200 one-row frames.
    call_at=newseg.file_offset+scene+REL_INITIAL_CALL
    call_target=scene+REL_LOCAL_START
    call_disp=call_target-(scene+REL_INITIAL_CALL+3)
    out[call_at:call_at+3]=b'\xE8'+struct.pack('<h',call_disp)
    # After controller returns, skip the obsolete original loop/blitter body.
    post_at=newseg.file_offset+scene+REL_POST_CALL
    post_target=scene+REL_LOCAL_END
    post_disp=post_target-(scene+REL_POST_CALL+3)
    out[post_at:post_at+3]=b'\xE9'+struct.pack('<h',post_disp)

    check=bytes(out); csegs=parse_segments(check); cseg=csegs[SEGMENT_ORDINAL-1]
    ccount,cfix,_=relocation_blob(check,cseg)
    if ccount!=count or cfix!=fixups: raise PortError('NE 재배치 표 보존 검증에 실패했습니다.')
    cstate,_=flora_state(check,csegs)
    if cstate!='pc98_smooth_200_preshift32': raise PortError('32픽셀 선행 이동 플로라 패치 검증에 실패했습니다.')
    return check


def patch_people(exe:bytes)->bytes:
    seg=parse_segments(exe)[SEGMENT_ORDINAL-1]; block=exe[seg.file_offset:seg.file_offset+seg.length]
    a=block.find(PEOPLE_ORIGINAL); b=block.find(PEOPLE_PATCHED)
    if b>=0 and a<0:return exe
    if a<0 or b>=0:raise PortError('쓰러진 사람 패치 위치를 고유하게 찾지 못했습니다.')
    out=bytearray(exe); p=seg.file_offset+a+PEOPLE_JUMP_REL; out[p:p+2]=b'\x90\x90'; return bytes(out)


def patch_blood(exe:bytes)->bytes:
    seg=parse_segments(exe)[SEGMENT_ORDINAL-1]; block=exe[seg.file_offset:seg.file_offset+seg.length]
    hits=[]
    for off in range(len(block)-len(BLOOD_TEMPLATE)+1):
        if all(v is None or block[off+i]==v for i,v in enumerate(BLOOD_TEMPLATE)):hits.append(off)
    if len(hits)!=1:raise PortError('피 색상 명령을 고유하게 찾지 못했습니다.')
    out=bytearray(exe); base=seg.file_offset+hits[0]
    for r,v in zip(BLOOD_VALUE_REL,BLOOD_RED_VALUES):out[base+r]=v
    return bytes(out)


def apply(path:Path,all_pc98:bool=False)->dict:
    before=analyze(path)
    if before.flora_sha256!=KNOWN_G_OP1700_SHA256:
        raise PortError('G_OP1700.BZP가 검증한 한국판/PC-98 공통 원본과 다릅니다. 다른 버전에는 적용하지 않습니다.')
    original=before.opening.read_bytes(); patched=inject_smooth_flora(original)
    patched=patch_intro_hold(patched)
    patched=patch_preblood_timing(patched)
    patched=patch_narration_centering(patched)
    patched=patch_text_gop0403_timing(patched)
    if all_pc98:
        patched=patch_people(patched); patched=patch_blood(patched)
    backup=backup_once(before.opening)
    atomic_write(before.opening,patched)
    try:
        record_patch(before.opening, original, patched, JOURNAL_COMPONENT)
        after=analyze(before.root)
        if after.flora_state!='pc98_smooth_200_preshift32':raise PortError('저장 후 플로라 상태가 올바르지 않습니다.')
        if after.intro_hold_state!='extended_5s':raise PortError('저장 후 오프닝 설명 +5초 상태가 올바르지 않습니다.')
        if after.preblood_timing_state!='extended_5_390625s_text5_gop0403_minus5':raise PortError('저장 후 피 장면 이전/오프닝 시간 이동 상태가 올바르지 않습니다.')
        if after.narration_state!='centered_punctuation_v151_text_plus5':raise PortError('저장 후 오프닝 중앙 정렬/문장부호/+5초 분산 상태가 올바르지 않습니다.')
        if after.text_gop0403_timing_state!='text_plus5_gop0403_minus5':raise PortError('저장 후 G_OP0403 -5초 상태가 올바르지 않습니다.')
        if all_pc98 and after.people_state!='enabled':raise PortError('저장 후 쓰러진 사람 상태가 올바르지 않습니다.')
        if all_pc98 and after.blood_values!=BLOOD_RED_VALUES:raise PortError('저장 후 피 색상이 올바르지 않습니다.')
    except Exception:
        atomic_write(before.opening,original)
        try:
            jp=before.opening.with_name(before.opening.name+'.ed2_pc98_opening.journal.json')
            if jp.exists(): jp.unlink()
        except OSError:
            pass
        raise
    diffs=[i for i,(a,b) in enumerate(zip(original,patched)) if a!=b]
    return {'tool_version':VERSION,'backup':str(backup),'all_pc98':all_pc98,'changed_bytes':len(diffs),
            'opening_sha256_before':before.opening_sha256,'opening_sha256_after':after.opening_sha256,
            'before':analysis_dict(before),'after':analysis_dict(after)}


def restore(path:Path)->dict:
    root,opening,_,_=resolve_root(path)
    try:
        selective_restore(opening,JOURNAL_COMPONENT)
    except FileNotFoundError as exc:
        raise PortError(str(exc)+"; 기존 전체 백업은 다른 패치를 지울 수 있어 자동 복원에 사용하지 않습니다.") from exc
    return analysis_dict(analyze(root))


class GUI:
    def __init__(self):
        import tkinter as tk
        from tkinter import ttk
        self.tk=tk; self.ttk=ttk; self.project=None
        self.root=tk.Tk(); self.root.title(f'{APP_NAME} v{VERSION}'); self.root.minsize(880,650)
        outer=ttk.Frame(self.root,padding=12);outer.pack(fill='both',expand=True)
        top=ttk.Frame(outer);top.pack(fill='x')
        ttk.Button(top,text='게임 폴더 열기',command=self.choose).pack(side='left')
        self.path=ttk.Label(top,text='OPENING.EXE와 GRP 폴더가 있는 위치를 선택하십시오.');self.path.pack(side='left',padx=10,fill='x',expand=True)
        why=ttk.LabelFrame(outer,text='v1.5.1 수정 방식',padding=10);why.pack(fill='x',pady=(12,8))
        ttk.Label(why,text='v1.5.0의 중앙 정렬/문장부호를 유지하면서 5개 내레이션 페이지를 각각 정확히 +1.000초 늘리고, G_OP0403.NIN(OP04)은 정확히 -5.000초 줄입니다. 전체 오프닝 타임라인 끝은 그대로 유지합니다.',wraplength=820,justify='left').pack(anchor='w')
        box=ttk.LabelFrame(outer,text='현재 파일 분석',padding=10);box.pack(fill='both',expand=True,pady=8)
        self.info=tk.Text(box,height=19,wrap='word',state='disabled');self.info.pack(fill='both',expand=True)
        buttons=ttk.Frame(outer);buttons.pack(fill='x',pady=(8,0))
        ttk.Button(buttons,text='오프닝 중앙 정렬 + 문장부호 + 연출 보정 적용',command=lambda:self.do_apply(False)).pack(side='left')
        ttk.Button(buttons,text='PC-98 오프닝 전체 복원',command=lambda:self.do_apply(True)).pack(side='left',padx=8)
        ttk.Button(buttons,text='오프닝 변경만 복원',command=self.do_restore).pack(side='left')
    def show(self,text):
        self.info.configure(state='normal');self.info.delete('1.0','end');self.info.insert('1.0',text);self.info.configure(state='disabled')
    def choose(self):
        from tkinter import filedialog,messagebox
        p=filedialog.askdirectory(title='OPENING.EXE가 있는 게임 폴더 선택')
        if not p:return
        try:self.project=Path(p);self.refresh()
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def refresh(self):
        a=analyze(self.project);self.path.configure(text=str(a.root));self.show(json.dumps(analysis_dict(a),ensure_ascii=False,indent=2))
    def do_apply(self,all_pc98):
        from tkinter import messagebox
        if not self.project:return
        label='오프닝 중앙 정렬/문장부호와 연출 보정, 사람/빨간 피를 함께 적용' if all_pc98 else '오프닝 중앙 정렬/문장부호와 기존 연출 보정을 적용'
        if not messagebox.askyesno(APP_NAME,label+'할까요?\n\nv1.3/v1.4.1/v1.4.2가 적용되어 있어도 자동으로 갱신하며, 현재 OPENING.EXE를 기존 v1.4 계열 백업으로 보존합니다.'):return
        try:r=apply(self.project,all_pc98);self.refresh();messagebox.showinfo(APP_NAME,'적용했습니다.\n\n'+json.dumps(r,ensure_ascii=False,indent=2))
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def do_restore(self):
        from tkinter import messagebox
        if not self.project:return
        if not messagebox.askyesno(APP_NAME,'오프닝 포팅이 변경한 바이트와 추가 코드만 복원할까요?\n다른 텍스트 패치는 유지됩니다.'):return
        try:r=restore(self.project);self.refresh();messagebox.showinfo(APP_NAME,'복원했습니다.\n\n'+json.dumps(r,ensure_ascii=False,indent=2))
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def run(self):self.root.mainloop()


def main(argv=None):
    ap=argparse.ArgumentParser(description=APP_NAME);ap.add_argument('path',nargs='?',type=Path)
    ap.add_argument('--analyze',action='store_true');ap.add_argument('--apply-flora',action='store_true');ap.add_argument('--apply-all',action='store_true');ap.add_argument('--restore',action='store_true');ap.add_argument('--no-gui',action='store_true')
    args=ap.parse_args(argv)
    if args.analyze or args.apply_flora or args.apply_all or args.restore:
        if not args.path:ap.error('게임 폴더 또는 OPENING.EXE 경로가 필요합니다.')
        r=restore(args.path) if args.restore else apply(args.path,args.apply_all) if (args.apply_flora or args.apply_all) else analysis_dict(analyze(args.path))
        print(json.dumps(r,ensure_ascii=False,indent=2));return 0
    if args.no_gui:return 0
    GUI().run();return 0
if __name__=='__main__':raise SystemExit(main())
