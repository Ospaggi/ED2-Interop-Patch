.code16

.equ WAIT_BEFORE_FRAME, 0x193A
.equ WAIT_AFTER_FRAME,  0x196B
.equ WAIT_INITIAL,      0x1AB7
.equ FRAME_SERVICE,    0x2600

.section .local,"ax"
.global _start
_start:
    pusha
    push %ds
    push %es
    push %bp

    # Start 32 rows above v1.3 so frame 0 already fills all 232 rows.
    mov $200, %bp
    call draw_frame
    call WAIT_INITIAL

    mov $200, %cx
scroll_loop:
    dec %bp
    call WAIT_BEFORE_FRAME
    call draw_frame
    call WAIT_AFTER_FRAME
    movb $2, %ds:0x0BFA
    call FRAME_SERVICE
    loop scroll_loop

    pop %bp
    pop %es
    pop %ds
    popa
    ret

draw_frame:
    pusha
    push %ds
    push %es

    mov %ss:0x1D00, %ax
    mov %ax, %ds
    mov %ss:0x0002, %ax
    mov %ax, %es
    xor %bx, %bx
    call draw_plane

    mov %ss:0x0004, %ax
    mov %ax, %es
    mov $0x7D00, %bx
    call draw_plane

    mov %ss:0x1D02, %ax
    mov %ax, %ds
    mov %ss:0x0006, %ax
    mov %ax, %es
    xor %bx, %bx
    call draw_plane

    mov %ss:0x0008, %ax
    mov %ax, %es
    mov $0x7D00, %bx
    call draw_plane

    pop %es
    pop %ds
    popa
    ret

.section .tail,"ax"
draw_plane:
    mov $0x1A50, %di          # screen x=128, y=84
    cmp $200, %bp
    ja initial_tail
    cmp $32, %bp
    jb upper_extension

    mov %bp, %ax
    sub $32, %ax
    call row_to_offset
    add %bx, %si
    mov $232, %cx
    call copy_rows
    ret

initial_tail:
    mov %bp, %ax
    sub $32, %ax
    call row_to_offset
    add %bx, %si
    mov $432, %cx
    sub %bp, %cx
    push %bp
    mov %cx, %bp
    call copy_rows
    mov $232, %cx
    sub %bp, %cx
    pop %bp
    call clear_rows
    ret

upper_extension:
    mov $32, %cx
    sub %bp, %cx
    mov %bp, %ax
    call row_to_offset
    add $48, %si
    add %bx, %si
    call copy_extension_rows

    mov %bx, %si
    mov $200, %cx
    add %bp, %cx
    call copy_rows
    ret

row_to_offset:
    mov %ax, %si
    shl $4, %ax
    shl $6, %si
    add %ax, %si
    ret

copy_rows:
    jcxz copy_rows_done
copy_rows_loop:
    push %cx
    mov $24, %cx
    rep movsw
    pop %cx
    add $32, %si
    add $32, %di
    loop copy_rows_loop
copy_rows_done:
    ret

clear_rows:
    jcxz clear_rows_done
    xor %ax, %ax
clear_rows_loop:
    push %cx
    mov $24, %cx
    rep stosw
    pop %cx
    add $32, %di
    loop clear_rows_loop
clear_rows_done:
    ret

copy_extension_rows:
    jcxz extension_done
extension_loop:
    push %cx
    push %si
    mov $12, %cx
    rep movsw
    pop %si
    add $0x0A00, %si
    mov $12, %cx
    rep movsw
    sub $0x0A00, %si
    add $56, %si
    add $32, %di
    pop %cx
    loop extension_loop
extension_done:
    ret

.ascii "FLORASCR"
