; ED2 PC-98 Opening Port v1.4.3 - initial narration extra hold
; Segment 1Dh offsets.
;
; OPENING.EXE programs MC146818 Register A with rate-select 0Ah.
; With the 32.768 kHz time base, RS=0Ah is 64 Hz.
; WAITCOUNTER=A0h is therefore 160 / 64 = 2.5 seconds.
;
; The original S_003 final page already has its own A0h wait.  To EXTEND
; the section by 5.0 seconds, this wrapper performs TWO additional A0h waits
; before jumping to the original text-clear routine at 2CF7h.
BITS 16
ORG 0x0A77
extra_intro_hold:
    mov byte [0x0BFA], 0xA0
    call 0x2600
    mov byte [0x0BFA], 0xA0
    call 0x2600
    jmp 0x2CF7

; Original near CALL at 1Dh:2B42 targeted 2CF7h.
; v1.4.3 retargets it to extra_intro_hold.
;
; v1.4.2 legacy wrapper used only the first MOV/CALL pair and therefore
; added 2.5 seconds.  The Python patcher detects that byte pattern and
; upgrades it to this two-wait wrapper without stacking another patch.
