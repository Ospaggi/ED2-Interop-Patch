#!/usr/bin/env python3
"""ED2 Mod Studio

Reverse-engineering based content editor for the Korean IBM PC/DOS release of
Dragon Slayer: The Legend of Heroes II.

Confirmed writable systems:
- MON/M_*.DLL monster records
- MON/M_*.DLL battle-group metadata (drops, BGM, appearance references)
- MON/M_*.DLL immediate AI writes to runtime drop probability (_MO_ATT_TRP)
- Confirmed CALC_DMG_PST-based HP thresholds linked to dynamic drop paths
- Actual drop scenario calculator, special-rule analysis, baselines and presets
- ED2MAIN.EXE regular item table (IDs 0..75) and event item names (IDs 100..126)
- ED2MAIN.EXE magic parameter table (IDs 0..31) and bulk recharge-cycle unification
- ED2MAIN.EXE experience recipient, party split, EXP/Gold 90% and EXP/Gold level-scaling rules
- SCENA/T_*.DLL shop inventories, including condition-dependent stock variants
- Read-only AI/hook analysis from bundled debug symbols
- MON/C_MO*.BZH appearance resource replacement/export
- Generic resource browser with conservative same-size replacement

All writes are atomic and create a .bak file once. Python standard library only.
"""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import math
import os
import shutil
import struct
import sys
import tempfile
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Iterable, Optional, Any

from ed2_patch_journal import record_patch, selective_restore, journal_path

APP_NAME = "ED2 Mod Studio"
VERSION = "0.13.1"
ITEM_COUNT = 76
ITEM_NAME_BASE = 0x14A185
ITEM_STRIDE = 20
EVENT_ITEM_ID_BASE = 100
EVENT_ITEM_COUNT = 27
EVENT_ITEM_NAME_BASE = 0x14A775
EVENT_ITEM_NAME_SIZE = 14
MAGIC_COUNT = 32
MAGIC_PARAM_BASE = 0x14AA3C
MAGIC_RECORD_SIZE = 12
MAGIC_HANDLER_TABLE_BASE = 0x14B4B8

# ED2MAIN.EXE import ordinals used by MON DLL AI analysis.
MO_ATT_TRP_IMPORT_ORDINAL = 0x023A
CALC_DMG_PST_IMPORT_ORDINAL = 0x008A
ADD_MO_EXP_IMPORT_ORDINAL = 0x0082
GET_EXP_IMPORT_ORDINAL = 0x0053
GET_GOLD_IMPORT_ORDINAL = 0x0059
LOAD_BGM_IMPORT_ORDINAL = 0x005B
LOAD_BGM_SET_IMPORT_ORDINAL = 0x0062
MO_ATT_TRS_IMPORT_ORDINAL = 0x0239

BASELINE_DIR_NAME = ".ed2_mod_studio_baseline"
BASELINE_MANIFEST_NAME = "manifest.json"

# ED2MAIN.EXE per-item magic-power mode patch (segment 86).
#
# The original game always substitutes ITEM_MAGIC_NUM * 10 for the caster's
# magic stat when a spell is invoked by an item.  v0.9.1 installs a small
# runtime dispatcher and a 76-byte mode table in verified zero padding:
#
#   fixed:        virtual_magic = ITEM_MAGIC_NUM_raw * 10
#   proportional: virtual_magic = floor(player_magic * ITEM_MAGIC_NUM_raw / 20)  # raw 1 = 5%
#
# The normal spell MAGIC_BAIRITU is applied afterwards in both modes.  The
# item record itself remains byte-for-byte compatible; the per-item choice is
# stored in the added mode table, while a verified unused byte in the writable
# data segment holds only the currently loaded item's mode at runtime.
ITEM_MAGIC_DATA_SEGMENT = 85
ITEM_MAGIC_PATCH_SEGMENT = 86
ITEM_MAGIC_RUNTIME_FLAG = 0xBEEF
ITEM_MAGIC_CALC_ENTRY = 0x4101
ITEM_MAGIC_GET_ITEM_EXPORT = 0x74DE
ITEM_MAGIC_GET_ITEM_ENTRY = 0x759B
ITEM_MAGIC_LEGACY_CAVE = 0xB81F
ITEM_MAGIC_CODE_START = 0x1F00
ITEM_MAGIC_SELECT_CODE = 0x1F00
ITEM_MAGIC_CALC_CODE = 0x1F30
ITEM_MAGIC_MODE_TABLE = 0x1F80
ITEM_MAGIC_CODE_END = ITEM_MAGIC_MODE_TABLE + ITEM_COUNT

ITEM_MAGIC_ORIGINAL_CALC_HEAD = bytes.fromhex(
    "51 A0 3D 20 FE C8 B4 0A 8B 1E 70 96 74 05 B4 00 8B 5C 0A"
)
# v0.9.0 global proportional patch, retained only for migration.
ITEM_MAGIC_LEGACY_CALC_HEAD = bytes.fromhex(
    "51 30 E4 80 3E 3D 20 01 75 06 E8 11 77 EB 04 90 8B 5C 0A"
)
ITEM_MAGIC_PER_ITEM_CALC_HEAD = bytes.fromhex(
    "51 E8 2B DE " + "90 " * 15
)
ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD = bytes.fromhex("AC B4 0A F6 E4 AB")
ITEM_MAGIC_PER_ITEM_GET_ITEM_HEAD = bytes.fromhex("E8 62 A9 90 90 AB")
ITEM_MAGIC_LEGACY_ORIGINAL_CAVE = bytes.fromhex("00 " + "FF " * 29)
ITEM_MAGIC_LEGACY_PATCHED_CAVE = bytes.fromhex(
    "52 51 8B 44 0A F7 26 70 96 B9 64 00 3B D1 73 06 "
    "F7 F1 8B D8 EB 03 BB FF FF B4 0A 59 5A C3"
)
# v0.12.6 per-item selector: ITEM_MAGIC_NUM is always scaled by 10.
# Retained so already-patched executables can be migrated losslessly.
ITEM_MAGIC_SELECT_CODE_X10_BYTES = bytes.fromhex(
    "AC B4 0A F6 E4 53 C6 06 EF BE 00 31 DB 88 D3 80 FB "
    "4C 73 0D 2E 80 BF 80 1F 00 74 05 C6 06 EF BE 01 "
    "5B C3"
)
# v0.12.7: fixed-power items keep x10, while proportional items use x5%.
# This permits exact 5% steps (e.g. raw 5 = 25%) without changing fixed items.
ITEM_MAGIC_SELECT_CODE_BYTES = bytes.fromhex(
    "AC 53 C6 06 EF BE 00 31 DB 88 D3 80 FB 4C 73 11 "
    "2E 80 BF 80 1F 00 74 09 C6 06 EF BE 01 B4 05 "
    "EB 02 B4 0A F6 E4 5B C3"
)
ITEM_MAGIC_CALC_CODE_BYTES = bytes.fromhex(
    "A0 3D 20 FE C8 75 2C B4 0A 80 3E EF BE 00 74 1E 52 "
    "51 8B 44 0A F7 26 70 96 B9 64 00 39 CA 73 06 F7 "
    "F1 89 C3 EB 03 BB FF FF B4 0A 59 5A C3 8B 1E 70 "
    "96 C3 B4 00 8B 5C 0A C3"
)
ITEM_MAGIC_MODE_FIXED_LABEL = "고정 위력"
ITEM_MAGIC_MODE_PROPORTIONAL_LABEL = "플레이어 마력 비례"

# ED2MAIN.EXE experience-award rule patch (segment 86).
#
# The original flow is:
#   1) count active, non-incapacitated party members (CALC_NAKAMA_NUM),
#   2) ceil(CUR_EXP / eligible_count),
#   3) add that share only to active, non-incapacitated members.
#
# These in-place patches are deliberately independent. They only replace
# verified instruction sequences and preserve the NE segment size/fixups.
EXP_PATCH_SEGMENT = 86
EXP_GET_EXP_ENTRY = 0x3728
EXP_AWARD_STATUS_CHECK = 0x3760
EXP_GENERAL_90_CALL = 0x41B7
EXP_LEVEL_RATE_CALL = 0x41BB
EXP_COUNT_ROUTINE = 0x428E
EXP_COUNT_STATUS_CHECK = 0x42A4

EXP_SPLIT_ORIGINAL = bytes.fromhex(
    "B0 00 9A FF FF 00 00 98 8B C8 33 D2 A1 B4 95 F7 F1 23 D2 74 01 40 8B D8"
)
EXP_SPLIT_FULL_EACH = bytes.fromhex("B0 00 9A FF FF 00 00 A1 B4 95 8B D8 " + "90 " * 12)
EXP_AWARD_STATUS_ORIGINAL = bytes.fromhex("F6 44 24 80 75 10")
EXP_AWARD_STATUS_INCLUDE = bytes.fromhex("90 " * 6)
EXP_COUNT_STATUS_ORIGINAL = bytes.fromhex("F6 44 24 80 75 02")
EXP_COUNT_STATUS_INCLUDE = bytes.fromhex("90 " * 6)
EXP_GENERAL_90_ORIGINAL = bytes.fromhex("0E E8 2B 00")
EXP_GENERAL_90_DISABLED = bytes.fromhex("90 90 90 90")
EXP_LEVEL_RATE_ORIGINAL = bytes.fromhex("0E E8 3F 00")
EXP_LEVEL_RATE_DISABLED = bytes.fromhex("B0 64 90 90")

# ADD_MO_GOLD has its own call to CALC_EXP_SUB.  Keep this independent from
# EXP so users can restore or disable the ordinary-battle 90% Gold reduction
# without changing experience rules or the later level-rate call.
GOLD_GENERAL_90_CALL = 0x41D3
GOLD_GENERAL_90_ORIGINAL = bytes.fromhex("0E E8 0F 00")
GOLD_GENERAL_90_DISABLED = bytes.fromhex("90 90 90 90")
GOLD_LEVEL_RATE_CALL = 0x41D7
GOLD_LEVEL_RATE_ORIGINAL = bytes.fromhex("0E E8 23 00")
GOLD_LEVEL_RATE_DISABLED = bytes.fromhex("B0 64 90 90")


@dataclass(frozen=True)
class ExperienceRuleState:
    include_incapacitated: bool
    no_party_split: bool
    no_general_90_percent: bool
    no_level_penalty: bool
    recognized: bool = True
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def summary(self) -> str:
        if not self.recognized:
            return "알 수 없는 경험치 패치"
        enabled: list[str] = []
        if self.include_incapacitated:
            enabled.append("기절자 포함")
        if self.no_party_split:
            enabled.append("파티 분배 없음")
        if self.no_general_90_percent:
            enabled.append("일반전투 90% 보정 없음")
        if self.no_level_penalty:
            enabled.append("레벨 차감 없음")
        return ", ".join(enabled) if enabled else "원본 방식"


@dataclass(frozen=True)
class GoldRewardRuleState:
    no_general_90_percent: bool
    no_level_scaling: bool
    recognized: bool = True
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def summary(self) -> str:
        if not self.recognized:
            return "알 수 없는 Gold 보상 패치"
        enabled: list[str] = []
        if self.no_general_90_percent:
            enabled.append("일반전투 Gold 90% 보정 없음")
        if self.no_level_scaling:
            enabled.append("Gold 레벨 스케일링 없음")
        return ", ".join(enabled) if enabled else "원본 Gold 방식"


def normalize_item_magic_mode(value: Any) -> str:
    text = str(value).strip().lower().replace("_", " ")
    if text in ("fixed", "고정", "고정 위력", "원본", "0"):
        return "fixed"
    if text in ("proportional", "비례", "플레이어 마력 비례", "마력 비례", "1"):
        return "proportional"
    raise ValueError("주문 위력 방식은 고정 위력 또는 플레이어 마력 비례여야 합니다.")


def item_magic_mode_label(mode: str) -> str:
    return ITEM_MAGIC_MODE_PROPORTIONAL_LABEL if mode == "proportional" else ITEM_MAGIC_MODE_FIXED_LABEL



class FormatError(Exception):
    pass


def u16(data: bytes | bytearray, off: int) -> int:
    if off < 0 or off + 2 > len(data):
        raise FormatError(f"u16 read outside file at 0x{off:X}")
    return struct.unpack_from("<H", data, off)[0]


def p16(data: bytearray, off: int, value: int) -> None:
    if not 0 <= value <= 0xFFFF:
        raise ValueError("16-bit value must be 0..65535")
    if off < 0 or off + 2 > len(data):
        raise FormatError(f"u16 write outside file at 0x{off:X}")
    struct.pack_into("<H", data, off, value)


def parse_number(text: str, minimum: int, maximum: int, label: str = "value") -> int:
    value = int(text.strip(), 0)
    if not minimum <= value <= maximum:
        raise ValueError(f"{label} must be {minimum}..{maximum}")
    return value


def csv_int(value: Any, minimum: int, maximum: int, label: str) -> int:
    text = str(value).strip()
    if not text:
        raise ValueError(f"{label} is empty")
    return parse_number(text, minimum, maximum, label)


def backup_once(path: Path) -> Path:
    backup = path.with_name(path.name + ".bak")
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        return backup
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


MOD_STUDIO_JOURNAL_COMPONENT = "ed2_mod_studio"


def atomic_write(path: Path, data: bytes, make_backup: bool = True) -> None:
    before = path.read_bytes()
    if before == data:
        return
    if make_backup:
        backup_once(path)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp_name, path)
        try:
            record_patch(path, before, data, MOD_STUDIO_JOURNAL_COMPONENT)
        except Exception:
            # A write without a matching selective-restore journal is unsafe.
            # Roll the file back immediately if journal creation fails.
            fd2, tmp2 = tempfile.mkstemp(prefix=path.name + ".", suffix=".journal_rollback.tmp", dir=str(path.parent))
            try:
                with os.fdopen(fd2, "wb") as fp:
                    fp.write(before); fp.flush(); os.fsync(fp.fileno())
                os.replace(tmp2, path)
            finally:
                try: os.unlink(tmp2)
                except OSError: pass
            raise
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def restore_backup(path: Path) -> None:
    """Restore only bytes changed by Mod Studio.

    The legacy whole-file .bak remains for manual disaster recovery, but the
    GUI no longer copies it over ED2MAIN/SCENA because doing so could erase a
    text, ending, opening, or dialogue patch applied later.
    """
    try:
        selective_restore(path, MOD_STUDIO_JOURNAL_COMPONENT)
    except FileNotFoundError as exc:
        backup = path.with_name(path.name + ".bak")
        suffix = f" (긴급 전체 백업은 {backup.name})" if backup.exists() else ""
        raise FileNotFoundError(
            f"선택적 Mod Studio 복원 기록이 없습니다: {journal_path(path, MOD_STUDIO_JOURNAL_COMPONENT).name}{suffix}. "
            "다른 패치를 지우지 않기 위해 전체 파일 복원은 자동 실행하지 않습니다."
        ) from exc


# ---------------------------------------------------------------------------
# Safe formula evaluator
# ---------------------------------------------------------------------------

_ALLOWED_FUNCS = {
    "log": math.log,
    "ln": math.log,
    "log10": math.log10,
    "log2": math.log2,
    "log1p": math.log1p,
    "sqrt": math.sqrt,
    "abs": abs,
    "min": min,
    "max": max,
}


def _eval_formula_node(node: ast.AST, x: float) -> float:
    if isinstance(node, ast.Expression):
        return _eval_formula_node(node.body, x)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return float(node.value)
    if isinstance(node, ast.Name):
        if node.id.lower() == "x":
            return float(x)
        if node.id.lower() == "e":
            return math.e
        if node.id.lower() == "pi":
            return math.pi
        raise ValueError(f"Unknown name: {node.id}")
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        value = _eval_formula_node(node.operand, x)
        return value if isinstance(node.op, ast.UAdd) else -value
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod)):
        left = _eval_formula_node(node.left, x)
        right = _eval_formula_node(node.right, x)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise ValueError("Division by zero")
            return left / right
        if isinstance(node.op, ast.Mod):
            if right == 0:
                raise ValueError("Modulo by zero")
            return left % right
        if abs(right) > 32:
            raise ValueError("Exponent magnitude must be <= 32")
        return left ** right
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        name = node.func.id.lower()
        if name not in _ALLOWED_FUNCS:
            raise ValueError(f"Unsupported function: {node.func.id}")
        if node.keywords:
            raise ValueError("Keyword arguments are not allowed")
        args = [_eval_formula_node(arg, x) for arg in node.args]
        if name in ("log", "ln"):
            if len(args) not in (1, 2):
                raise ValueError("log() accepts one value or value and base")
            if args[0] <= 0:
                raise ValueError("log() requires a positive value; use log1p(x) when zero is possible")
            if len(args) == 2 and (args[1] <= 0 or args[1] == 1):
                raise ValueError("Invalid logarithm base")
        elif name in ("log10", "log2") and (len(args) != 1 or args[0] <= 0):
            raise ValueError(f"{name}() requires one positive value")
        elif name == "log1p" and (len(args) != 1 or args[0] <= -1):
            raise ValueError("log1p() requires one value greater than -1")
        elif name == "sqrt" and (len(args) != 1 or args[0] < 0):
            raise ValueError("sqrt() requires one nonnegative value")
        elif name == "abs" and len(args) != 1:
            raise ValueError("abs() accepts one value")
        elif name in ("min", "max") and not 1 <= len(args) <= 8:
            raise ValueError(f"{name}() accepts 1..8 values")
        return float(_ALLOWED_FUNCS[name](*args))
    raise ValueError("Formula may only use x, numbers, + - * / % ** and approved math functions")


def eval_formula(x: int, expression: str) -> int:
    text = expression.strip()
    if not text:
        raise ValueError("Formula is empty")
    compact = text.replace(" ", "")
    if len(compact) >= 2 and compact[0] in "+-*/=":
        try:
            operand = Decimal(compact[1:])
        except InvalidOperation as exc:
            raise ValueError("Invalid numeric operand") from exc
        if not operand.is_finite():
            raise ValueError("Operand must be finite")
        current = Decimal(x)
        if compact[0] == "+": result = current + operand
        elif compact[0] == "-": result = current - operand
        elif compact[0] == "*": result = current * operand
        elif compact[0] == "/":
            if operand == 0: raise ValueError("Division by zero")
            result = current / operand
        else: result = operand
        return int(result.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as exc:
        raise ValueError("Invalid formula") from exc
    result = _eval_formula_node(tree, float(x))
    if not math.isfinite(result):
        raise ValueError("Formula result is not finite")
    return int(Decimal(str(result)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


# ---------------------------------------------------------------------------
# NE / MON DLL parser
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class NESegment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


@dataclass(frozen=True)
class NERelocation:
    segment_index: int
    source_type: int
    flags: int
    source_offset: int
    target1: int
    target2: int

    @property
    def is_imported_ordinal(self) -> bool:
        return (self.flags & 0x03) == 1


def parse_ne_segments(data: bytes) -> list[NESegment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise FormatError("Not an MZ executable")
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    if ne_off + 0x40 > len(data) or data[ne_off:ne_off + 2] != b"NE":
        raise FormatError("Not a 16-bit NE module")
    count = u16(data, ne_off + 0x1C)
    table = ne_off + u16(data, ne_off + 0x22)
    shift = u16(data, ne_off + 0x32)
    if table + count * 8 > len(data):
        raise FormatError("Truncated NE segment table")
    result: list[NESegment] = []
    for i in range(count):
        sector, length, flags, min_alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        offset = sector << shift
        real_len = 65536 if length == 0 else length
        if offset > len(data):
            raise FormatError("NE segment outside file")
        result.append(NESegment(i + 1, offset, real_len, flags, min_alloc))
    return result


def parse_ne_relocations(data: bytes, segment: NESegment) -> list[NERelocation]:
    """Read the relocation records appended to one NE segment.

    ED2 MON DLLs use imported-ordinal fixups for engine globals such as
    ``_MO_ATT_TRP``.  The original instruction operand is usually zero in the
    file and only becomes the real address when DOS/Windows loads the module,
    so ordinary byte-pattern scanning cannot identify these references.
    """
    if not (segment.flags & 0x0100):
        return []
    pos = segment.file_offset + segment.length
    if pos + 2 > len(data):
        raise FormatError(f"Segment {segment.index} relocation table is truncated")
    count = u16(data, pos)
    pos += 2
    end = pos + count * 8
    if end > len(data):
        raise FormatError(f"Segment {segment.index} relocation records are truncated")
    result: list[NERelocation] = []
    for index in range(count):
        off = pos + index * 8
        source_type, flags, source_offset, target1, target2 = struct.unpack_from("<BBHHH", data, off)
        result.append(NERelocation(segment.index, source_type, flags, source_offset, target1, target2))
    return result


def parse_ne_exports(data: bytes) -> dict[str, tuple[int, int]]:
    """Return exported NE symbols as name -> (segment, offset).

    The Korean ED2 executable keeps most engine globals and routines in the
    resident-name table.  Parsing the actual export table lets the editor
    validate item/magic locations instead of trusting file offsets alone.
    """
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise FormatError("Not an MZ executable")
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise FormatError("Not a 16-bit NE module")

    entry_off = ne + u16(data, ne + 0x04)
    entry_end = entry_off + u16(data, ne + 0x06)
    ordinal = 1
    entries: dict[int, tuple[int, int]] = {}
    pos = entry_off
    while pos < entry_end:
        if pos + 2 > len(data):
            raise FormatError("Truncated NE entry table")
        count, bundle_type = data[pos], data[pos + 1]
        pos += 2
        if count == 0:
            break
        if bundle_type == 0:
            ordinal += count
            continue
        if bundle_type == 0xFF:
            for _ in range(count):
                if pos + 6 > len(data):
                    raise FormatError("Truncated movable entry bundle")
                segment = data[pos + 3]
                offset = u16(data, pos + 4)
                entries[ordinal] = (segment, offset)
                ordinal += 1
                pos += 6
        else:
            for _ in range(count):
                if pos + 3 > len(data):
                    raise FormatError("Truncated fixed entry bundle")
                offset = u16(data, pos + 1)
                entries[ordinal] = (bundle_type, offset)
                ordinal += 1
                pos += 3

    def read_name_table(offset: int, size_limit: Optional[int] = None) -> list[tuple[str, int]]:
        result_names: list[tuple[str, int]] = []
        end = len(data) if size_limit is None else min(len(data), offset + size_limit)
        pos2 = offset
        while pos2 < end:
            length = data[pos2]
            pos2 += 1
            if length == 0:
                break
            if pos2 + length + 2 > end:
                raise FormatError("Truncated NE name table")
            name = data[pos2:pos2 + length].decode("latin1")
            pos2 += length
            ord_value = u16(data, pos2)
            pos2 += 2
            result_names.append((name, ord_value))
        return result_names

    resident = read_name_table(ne + u16(data, ne + 0x26))
    nonresident_off = struct.unpack_from("<I", data, ne + 0x2C)[0]
    nonresident_size = u16(data, ne + 0x20)
    nonresident = read_name_table(nonresident_off, nonresident_size)
    exports: dict[str, tuple[int, int]] = {}
    for name, ord_value in resident + nonresident:
        if ord_value in entries:
            exports[name] = entries[ord_value]
    return exports



def parse_ne_export_ordinals(data: bytes) -> dict[int, str]:
    """Return exported NE names keyed by ordinal.

    MON DLL relocation records identify ED2MAIN imports by ordinal rather than
    by name.  Keeping the ordinal map lets the studio explain rare engine calls
    without relying on an external symbol file.
    """
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise FormatError("Not an MZ executable")
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise FormatError("Not a 16-bit NE module")

    def read_name_table(offset: int, size_limit: Optional[int] = None) -> list[tuple[int, str]]:
        result: list[tuple[int, str]] = []
        end = len(data) if size_limit is None else min(len(data), offset + size_limit)
        pos = offset
        while pos < end:
            length = data[pos]
            pos += 1
            if length == 0:
                break
            if pos + length + 2 > end:
                raise FormatError("Truncated NE name table")
            name = data[pos:pos + length].decode("latin1")
            pos += length
            ordinal = u16(data, pos)
            pos += 2
            if ordinal:
                result.append((ordinal, name))
        return result

    resident = read_name_table(ne + u16(data, ne + 0x26))
    nonresident_off = struct.unpack_from("<I", data, ne + 0x2C)[0]
    nonresident_size = u16(data, ne + 0x20)
    nonresident = read_name_table(nonresident_off, nonresident_size)
    return {ordinal: name for ordinal, name in resident + nonresident}


def signed8(value: int) -> int:
    return value - 256 if value >= 128 else value


def hp_ratio_raw_to_percent(raw: int) -> float:
    return max(0, min(255, int(raw))) * 100.0 / 256.0


def hp_ratio_percent_to_raw(percent: float) -> int:
    if not 0.0 <= float(percent) <= 100.0:
        raise ValueError("HP condition percent must be 0..100")
    # CALC_DMG_PST uses an 8-bit 0..255 fixed-point ratio.  100% therefore
    # maps to 255 rather than wrapping to 0.
    return min(255, max(0, int(Decimal(str(percent * 256.0 / 100.0)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))))


def ne_address_to_file(data: bytes, segment: int, offset: int) -> int:
    segments = parse_ne_segments(data)
    if not 1 <= segment <= len(segments):
        raise FormatError(f"NE segment {segment} is outside the module")
    seg = segments[segment - 1]
    if not 0 <= offset < seg.length:
        raise FormatError(f"Offset 0x{offset:X} is outside NE segment {segment}")
    return seg.file_offset + offset


def decode_cp949_terminated(field: bytes, terminators: tuple[int, ...] = (0x06, 0x00)) -> str:
    end = len(field)
    for marker in terminators:
        try:
            end = min(end, field.index(marker))
        except ValueError:
            pass
    raw = field[:end]
    for enc in ("cp949", "euc-kr"):
        try:
            return raw.decode(enc).rstrip()
        except UnicodeDecodeError:
            pass
    return raw.decode("latin1", errors="replace").rstrip()


def encode_fixed_cp949(text: str, size: int, terminator: int = 0x06, left_pad: bool = False) -> bytes:
    raw = text.encode("cp949")
    if len(raw) > size - 1:
        raise ValueError(f"Text is too long: CP949 byte length must be <= {size - 1}")
    if left_pad:
        return b" " * (size - 1 - len(raw)) + raw + bytes([terminator])
    return raw + bytes([terminator]) + b"\x00" * (size - 1 - len(raw))


def _is_kajasm_record(path: Path, slot: int, data: bytes | bytearray, base: int) -> bool:
    # M_401 slot 0 is the only retail monster record whose nominal name field
    # contains two additional 06h bytes after the normal name terminator.
    # Retail-corpus comparison shows this layout only for Kajasum.  Old CSV
    # name writes erased the two bytes, matching the state of the game build
    # that exhibits the reported battle-action text corruption.
    return (
        path.name.upper() == "M_401.DLL"
        and slot == 0
        and base + 0x40 <= len(data)
        and u16(data, base + 0x00) == 0x1A04
    )


def preserve_monster_record_quirks(path: Path, slot: int, data: bytearray, base: int) -> None:
    if _is_kajasm_record(path, slot, data, base):
        # Retail bytes at name-field offsets +7/+8 are 06 06.  Old Mod Studio
        # versions replaced them with 00 00 whenever a CSV row rewrote the name.
        data[base + 0x37:base + 0x39] = b"\x06\x06"


def encode_monster_name(text: str, path: Path, slot: int, data: bytes | bytearray, base: int) -> bytes:
    raw = text.encode("cp949")
    if _is_kajasm_record(path, slot, data, base):
        # Keep the retail M_401 layout exactly: 6-byte name + 06 06 06.
        # A different byte length would overlap the protected record bytes.
        if len(raw) != 6:
            raise ValueError("M_401 slot 0 name must remain exactly 6 CP949 bytes to preserve its protected 06 06 bytes")
        return raw + b"\x06\x06\x06" + b"\x00" * 7
    return encode_fixed_cp949(text, 16)


def is_monster_record(raw: bytes) -> bool:
    if len(raw) != 64 or 0x06 not in raw[48:64]:
        return False
    name = decode_cp949_terminated(raw[48:64])
    hp_cur, hp_max = u16(raw, 4), u16(raw, 6)
    return bool(name) and hp_cur > 0 and hp_cur == hp_max


def find_monster_table(data: bytes) -> tuple[NESegment, int]:
    best: Optional[tuple[NESegment, int]] = None
    for seg in parse_ne_segments(data):
        count = 0
        segment_end = min(len(data), seg.file_offset + seg.length)
        for slot in range(4):
            off = seg.file_offset + slot * 64
            if off + 64 > segment_end or not is_monster_record(data[off:off + 64]):
                break
            count += 1
        if count and (best is None or count > best[1]):
            best = (seg, count)
    if best is None:
        raise FormatError("No safe monster table found")
    return best


MONSTER_FIELDS: dict[str, tuple[int, int, str]] = {
    "record_id": (0x00, 2, "Record/Sprite slot reference"),
    "level": (0x03, 1, "Monster level"),
    "hp": (0x04, 2, "HP"),
    "attack": (0x0A, 2, "Attack"),
    "exp": (0x0C, 2, "Raw EXP"),
    "gold": (0x0E, 2, "Raw Gold"),
    "defense": (0x10, 2, "Defense"),
    "magic": (0x12, 2, "Magic"),
    "speed": (0x16, 1, "Speed"),
    "luck": (0x17, 1, "Luck"),
}


@dataclass
class MonsterRecord:
    dll_path: Path
    dll_number: int
    slot: int
    file_offset: int
    segment_offset: int
    raw: bytes

    @property
    def name(self) -> str:
        return decode_cp949_terminated(self.raw[48:64])

    def value(self, key: str) -> int:
        off, size, _ = MONSTER_FIELDS[key]
        return self.raw[off] if size == 1 else u16(self.raw, off)

    @property
    def active_in_formation(self) -> bool:
        """Whether this record is enabled in the DLL's initial battle formation.

        The high bit of the first record byte is set on unused/disabled slots.
        This distinction matters for the 16-bit battle reward accumulator: only
        active formation members are included in the normal encounter total.
        """
        return (self.raw[0] & 0x80) == 0


@dataclass(frozen=True)
class DynamicDropReference:
    dll_path: Path
    segment_index: int
    instruction_offset: int
    operand_offset: int
    operation: str
    value: Optional[int]
    value_file_offset: Optional[int]
    editable: bool
    note: str

    @property
    def location(self) -> str:
        return f"seg{self.segment_index}:0x{self.instruction_offset:04X}"

    @property
    def value_text(self) -> str:
        return "-" if self.value is None else f"{self.value}%"


@dataclass(frozen=True)
class AIConditionReference:
    dll_path: Path
    segment_index: int
    instruction_offset: int
    threshold_raw: int
    threshold_file_offset: int
    relation: str
    branch_target: int
    linked_drop_instruction_offset: int
    editable: bool
    note: str

    @property
    def location(self) -> str:
        return f"seg{self.segment_index}:0x{self.instruction_offset:04X}"

    @property
    def threshold_percent(self) -> float:
        return hp_ratio_raw_to_percent(self.threshold_raw)

    @property
    def condition_text(self) -> str:
        return f"현재 HP {self.threshold_percent:.1f}% {self.relation} (원시 0x{self.threshold_raw:02X})"


@dataclass(frozen=True)
class ImportedOrdinalReference:
    dll_path: Path
    segment_index: int
    instruction_offset: int
    operand_offset: int
    ordinal: int
    symbol: str
    operation: str
    value: Optional[int] = None

    @property
    def location(self) -> str:
        return f"seg{self.segment_index}:0x{self.instruction_offset:04X}"


@dataclass(frozen=True)
class SpecialRule:
    dll_path: Path
    category: str
    confidence: str
    location: str
    summary: str
    detail: str


@dataclass(frozen=True)
class ModificationRow:
    file: str
    category: str
    target: str
    field: str
    original: str
    current: str


@dataclass
class MonsterGroup:
    dll_path: Path
    dll_number: int
    segment_offset: int
    record_count: int
    monster_names: list[str]
    graphic_id0: int
    graphic_addr0: int
    graphic_id1: int
    graphic_addr1: int
    init_message: int
    player_hook: int
    death_hook: int
    init_proc: int
    attack_escape_hook: int
    before_magic_hook: int
    before_damage_hook: int
    animation_hook: int
    drop_item_id: int
    drop_chance: int
    bgm_id: int
    magic_table_ptr: int
    attack_algo: int
    defense_algo: int
    magic_algo: int
    death_algo: int
    advanced_hex: str
    dynamic_drop_refs: list[DynamicDropReference] = field(default_factory=list)
    ai_conditions: list[AIConditionReference] = field(default_factory=list)
    special_rules: list[SpecialRule] = field(default_factory=list)

    @property
    def label(self) -> str:
        names = ", ".join(self.monster_names[:2])
        return f"M_{self.dll_number:03X}  {names}"

    def hook_rows(self) -> list[tuple[str, int, str]]:
        return [
            ("_MO_INIT_MESS", self.init_message, "초기 메시지/데이터 포인터"),
            ("_MO_PLY_HOOK", self.player_hook, "플레이어 행동 훅"),
            ("_MO_DEAD_HOOK", self.death_hook, "사망 훅"),
            ("_MO_INIT_PROC", self.init_proc, "전투 초기화 루틴"),
            ("_MO_ATT_ESC", self.attack_escape_hook, "공격/도주 훅"),
            ("_MO_BFR_MAG", self.before_magic_hook, "주문 적용 직전 훅"),
            ("_MO_BFR_DMG", self.before_damage_hook, "피해 적용 직전 훅"),
            ("_MO_ANIME_HOOK", self.animation_hook, "애니메이션 훅"),
            ("_MO_MAG_PTR", self.magic_table_ptr, "몬스터 주문 테이블 포인터"),
            ("_MO_ATT_ALGO", self.attack_algo, "공격 AI 진입점"),
            ("_MO_DEF_ALGO", self.defense_algo, "방어 AI 진입점"),
            ("_MO_MAG_ALGO", self.magic_algo, "주문 AI 진입점"),
            ("_MO_DED_ALGO", self.death_algo, "사망 판정 AI 진입점"),
        ]

    @property
    def dynamic_drop_writes(self) -> list[DynamicDropReference]:
        return [ref for ref in self.dynamic_drop_refs if ref.operation == "AI 즉시값 설정" and ref.value is not None]

    def condition_for_drop(self, ref: DynamicDropReference) -> Optional[AIConditionReference]:
        return next((condition for condition in self.ai_conditions
                     if condition.segment_index == ref.segment_index
                     and condition.linked_drop_instruction_offset == ref.instruction_offset), None)

    @property
    def drop_scenarios(self) -> list[tuple[str, int]]:
        scenarios: list[tuple[str, int]] = [("전투 시작/AI 변경 전", self.drop_chance)]
        for ref in self.dynamic_drop_writes:
            condition = self.condition_for_drop(ref)
            if condition:
                label = f"{condition.condition_text} 조건 경로 실행 후"
            else:
                label = f"{ref.location} AI 경로 실행 후"
            scenarios.append((label, int(ref.value or 0)))
        # Preserve order while removing exact duplicate rows.
        unique: list[tuple[str, int]] = []
        seen: set[tuple[str, int]] = set()
        for row in scenarios:
            if row not in seen:
                unique.append(row); seen.add(row)
        return unique

    @property
    def dynamic_drop_summary(self) -> str:
        values = [ref.value for ref in self.dynamic_drop_writes if ref.value is not None]
        if values:
            unique = list(dict.fromkeys(values))
            return f"초기 {self.drop_chance}% → AI " + "/".join(f"{value}%" for value in unique)
        if self.dynamic_drop_refs:
            return f"초기 {self.drop_chance}% · AI 참조"
        return f"{self.drop_chance}%"


def dll_number(path: Path) -> int:
    try:
        return int(path.stem.split("_")[-1], 16)
    except ValueError:
        return -1


def load_monsters(path: Path) -> list[MonsterRecord]:
    data = path.read_bytes()
    seg, count = find_monster_table(data)
    number = dll_number(path)
    return [
        MonsterRecord(path, number, slot, seg.file_offset + slot * 64, seg.file_offset,
                      data[seg.file_offset + slot * 64:seg.file_offset + (slot + 1) * 64])
        for slot in range(count)
    ]


def _dynamic_drop_note(path: Path, segment_index: int, instruction_offset: int,
                       operation: str, value: Optional[int]) -> str:
    key = (path.name.upper(), segment_index, instruction_offset)
    if key == ("M_327.DLL", 3, 0x0245):
        return (
            "누캇치 특수 행동의 HP 비율 분기에서 "
            f"드롭 확률을 {value}%로 변경합니다. 조건값은 AI 조건 편집기에서 별도로 표시됩니다."
        )
    if operation == "AI 즉시값 설정":
        return f"전투 AI가 실행 중 _MO_ATT_TRP를 {value}%로 덮어쓸 수 있습니다."
    if operation == "AI 확률 비교":
        return "전투 AI가 현재 _MO_ATT_TRP 값을 조건 판단에 사용합니다. 직접 변경하는 명령은 아닙니다."
    if operation == "AI 값 읽기":
        return "전투 AI가 현재 _MO_ATT_TRP 값을 읽습니다."
    if operation == "AI 동적 설정":
        return "전투 AI가 레지스터/계산 결과로 _MO_ATT_TRP를 변경합니다. 정확한 값은 실행 경로에 따라 달라집니다."
    return "전투 AI가 _MO_ATT_TRP를 참조합니다."


def analyze_dynamic_drop_references(path: Path) -> list[DynamicDropReference]:
    """Find runtime references to ED2MAIN's ``_MO_ATT_TRP`` variable.

    The operand bytes are relocation placeholders in the DLL file.  We first
    resolve imported-ordinal relocation records and then classify the x86
    instruction containing each operand.  Immediate byte writes can be edited
    safely without changing the module size or relocation table.
    """
    data = path.read_bytes()
    result: list[DynamicDropReference] = []
    for segment in parse_ne_segments(data):
        segment_data = data[segment.file_offset:segment.file_offset + segment.length]
        for reloc in parse_ne_relocations(data, segment):
            if not reloc.is_imported_ordinal or reloc.target2 != MO_ATT_TRP_IMPORT_ORDINAL:
                continue
            src = reloc.source_offset
            if not 0 <= src < len(segment_data):
                continue
            instruction_offset = src
            operation = "AI 참조"
            value: Optional[int] = None
            value_file_offset: Optional[int] = None
            editable = False

            if src >= 2 and src + 3 <= len(segment_data) and segment_data[src - 2:src] == b"\xC6\x06":
                instruction_offset = src - 2
                operation = "AI 즉시값 설정"
                value = segment_data[src + 2]
                value_file_offset = segment.file_offset + src + 2
                editable = True
            elif src >= 2 and src + 3 <= len(segment_data) and segment_data[src - 2:src] == b"\x80\x3E":
                instruction_offset = src - 2
                operation = "AI 확률 비교"
                value = segment_data[src + 2]
            elif src >= 1 and segment_data[src - 1:src] == b"\xA0":
                instruction_offset = src - 1
                operation = "AI 값 읽기"
            elif src >= 1 and segment_data[src - 1:src] == b"\xA2":
                instruction_offset = src - 1
                operation = "AI 동적 설정"
            elif src >= 2 and segment_data[src - 2:src] in (b"\x88\x06", b"\xFE\x06"):
                instruction_offset = src - 2
                operation = "AI 동적 설정"

            result.append(DynamicDropReference(
                path, segment.index, instruction_offset, src, operation, value,
                value_file_offset, editable,
                _dynamic_drop_note(path, segment.index, instruction_offset, operation, value),
            ))
    return result


def patch_dynamic_drop_reference(ref: DynamicDropReference, value: int,
                                 make_backup: bool = True) -> None:
    value = int(value)
    if not 0 <= value <= 100:
        raise ValueError("AI drop chance must be 0..100")
    if not ref.editable or ref.value_file_offset is None:
        raise ValueError("This AI reference is read-only")
    current = analyze_dynamic_drop_references(ref.dll_path)
    fresh = next((item for item in current
                  if item.segment_index == ref.segment_index
                  and item.instruction_offset == ref.instruction_offset
                  and item.operation == "AI 즉시값 설정"), None)
    if fresh is None or fresh.value_file_offset is None:
        raise ValueError("AI drop instruction changed; reload the project")
    data = bytearray(ref.dll_path.read_bytes())
    data[fresh.value_file_offset] = value
    atomic_write(ref.dll_path, bytes(data), make_backup)



def analyze_dynamic_drop_conditions(
    path: Path, refs: Optional[list[DynamicDropReference]] = None
) -> list[AIConditionReference]:
    """Detect confirmed HP-ratio branches that lead to a drop-probability write.

    The editable pattern is deliberately narrow:

      CALL CALC_DMG_PST
      CMP  AL, imm8
      Jcc  branch
      ... branch target ...
      MOV  BYTE PTR [_MO_ATT_TRP], imm8

    This keeps condition editing confined to a verified fixed-size immediate
    operand and avoids exposing arbitrary AI byte editing.
    """
    data = path.read_bytes()
    refs = refs if refs is not None else analyze_dynamic_drop_references(path)
    writes = [ref for ref in refs if ref.operation == "AI 즉시값 설정"]
    result: list[AIConditionReference] = []
    relation_by_opcode = {0x72: "미만", 0x76: "이하", 0x73: "이상", 0x77: "초과"}
    for segment in parse_ne_segments(data):
        segment_writes = [ref for ref in writes if ref.segment_index == segment.index]
        if not segment_writes:
            continue
        segment_data = data[segment.file_offset:segment.file_offset + segment.length]
        calc_calls = [
            reloc for reloc in parse_ne_relocations(data, segment)
            if reloc.is_imported_ordinal and reloc.target2 == CALC_DMG_PST_IMPORT_ORDINAL
        ]
        for write in segment_writes:
            candidates: list[tuple[int, AIConditionReference]] = []
            for reloc in calc_calls:
                src = reloc.source_offset
                call_instruction = src - 1
                if not (0 <= call_instruction < len(segment_data)) or segment_data[call_instruction] != 0x9A:
                    continue
                if call_instruction >= write.instruction_offset or write.instruction_offset - call_instruction > 0x180:
                    continue
                scan_start = src + 4  # byte after the far-call relocation operand
                scan_end = min(len(segment_data) - 3, scan_start + 24, write.instruction_offset)
                for cmp_off in range(scan_start, scan_end + 1):
                    if segment_data[cmp_off] != 0x3C:
                        continue
                    threshold = segment_data[cmp_off + 1]
                    branch_off = cmp_off + 2
                    opcode = segment_data[branch_off]
                    relation = relation_by_opcode.get(opcode)
                    if relation is None:
                        continue
                    target = branch_off + 2 + signed8(segment_data[branch_off + 1])
                    # The confirmed path branches into the block containing the
                    # drop write.  Allow a small block window for intervening calls.
                    reaches_write = target <= write.instruction_offset <= target + 0x50
                    if not reaches_write:
                        continue
                    note = (
                        f"CALC_DMG_PST의 8비트 HP 비율을 0x{threshold:02X}와 비교해 "
                        f"{relation}일 때 {write.location} 드롭 변경 경로로 진입합니다."
                    )
                    if path.name.upper() == "M_327.DLL":
                        note = (
                            "누캇치 특수 행동의 HP 조건입니다. 현재 HP 비율이 이 값 미만인 분기에서 "
                            "드롭 확률 변경 코드가 실행될 수 있습니다."
                        )
                    ref = AIConditionReference(
                        path, segment.index, cmp_off, threshold,
                        segment.file_offset + cmp_off + 1, relation, target,
                        write.instruction_offset, True, note,
                    )
                    candidates.append((write.instruction_offset - cmp_off, ref))
            if candidates:
                result.append(min(candidates, key=lambda row: row[0])[1])
    return result


def patch_ai_condition_threshold(
    ref: AIConditionReference, percent: float, make_backup: bool = True
) -> int:
    if not ref.editable:
        raise ValueError("This AI condition is read-only")
    raw = hp_ratio_percent_to_raw(percent)
    refs = analyze_dynamic_drop_references(ref.dll_path)
    fresh_conditions = analyze_dynamic_drop_conditions(ref.dll_path, refs)
    fresh = next((condition for condition in fresh_conditions
                  if condition.segment_index == ref.segment_index
                  and condition.instruction_offset == ref.instruction_offset
                  and condition.linked_drop_instruction_offset == ref.linked_drop_instruction_offset), None)
    if fresh is None:
        raise ValueError("AI condition pattern changed; reload the project")
    data = bytearray(ref.dll_path.read_bytes())
    data[fresh.threshold_file_offset] = raw
    atomic_write(ref.dll_path, bytes(data), make_backup)
    return raw


def analyze_imported_ordinal_references(
    path: Path, ordinal_names: Optional[dict[int, str]] = None
) -> list[ImportedOrdinalReference]:
    ordinal_names = ordinal_names or {}
    data = path.read_bytes()
    result: list[ImportedOrdinalReference] = []
    for segment in parse_ne_segments(data):
        segment_data = data[segment.file_offset:segment.file_offset + segment.length]
        for reloc in parse_ne_relocations(data, segment):
            if not reloc.is_imported_ordinal:
                continue
            src = reloc.source_offset
            if not 0 <= src < len(segment_data):
                continue
            operation = "참조"
            instruction_offset = src
            value: Optional[int] = None
            if src >= 1 and segment_data[src - 1] == 0x9A:
                instruction_offset = src - 1; operation = "호출"
            elif src >= 2 and src + 3 <= len(segment_data) and segment_data[src - 2:src] == b"\xC6\x06":
                instruction_offset = src - 2; operation = "8비트 즉시값 설정"; value = segment_data[src + 2]
            elif src >= 2 and src + 4 <= len(segment_data) and segment_data[src - 2:src] == b"\xC7\x06":
                instruction_offset = src - 2; operation = "16비트 즉시값 설정"; value = u16(segment_data, src + 2)
            elif src >= 1 and segment_data[src - 1] in (0xA0, 0xA1):
                instruction_offset = src - 1; operation = "값 읽기"
            elif src >= 1 and segment_data[src - 1] in (0xA2, 0xA3):
                instruction_offset = src - 1; operation = "동적 값 설정"
            elif src >= 2 and segment_data[src - 2:src] == b"\x80\x3E" and src + 3 <= len(segment_data):
                instruction_offset = src - 2; operation = "8비트 비교"; value = segment_data[src + 2]
            elif src >= 2 and segment_data[src - 2:src] in (b"\x88\x06", b"\x89\x06", b"\xFE\x06"):
                instruction_offset = src - 2; operation = "동적 값 설정"
            symbol = ordinal_names.get(reloc.target2, f"ordinal_0x{reloc.target2:04X}")
            result.append(ImportedOrdinalReference(
                path, segment.index, instruction_offset, src, reloc.target2, symbol, operation, value
            ))
    return result


def build_special_rules(
    group: MonsterGroup,
    import_refs: list[ImportedOrdinalReference],
    ordinal_frequency: dict[int, int],
    group_count: int,
) -> list[SpecialRule]:
    rules: list[SpecialRule] = []
    for ref in group.dynamic_drop_refs:
        if ref.operation == "AI 즉시값 설정":
            condition = group.condition_for_drop(ref)
            condition_text = condition.condition_text if condition else "실행 경로 조건 미확정"
            rules.append(SpecialRule(
                group.dll_path, "드롭", "확정", ref.location,
                f"전투 중 드롭 확률을 {ref.value}%로 변경",
                f"초기값 {group.drop_chance}%와 별개입니다. 조건: {condition_text}",
            ))
        elif ref.operation == "AI 확률 비교":
            rules.append(SpecialRule(
                group.dll_path, "드롭", "확정", ref.location,
                f"현재 드롭 확률을 {ref.value}%와 비교",
                "AI가 드롭 확률을 행동 조건으로 사용합니다.",
            ))
        else:
            rules.append(SpecialRule(
                group.dll_path, "드롭", "확정", ref.location,
                f"런타임 드롭 확률 {ref.operation}", ref.note,
            ))
    for condition in group.ai_conditions:
        rules.append(SpecialRule(
            group.dll_path, "HP 조건", "확정", condition.location,
            f"{condition.condition_text}에서 특수 경로 분기", condition.note,
        ))

    # Direct reward/drop/BGM engine calls are uncommon enough to merit a
    # warning that table values alone may not describe the encounter.
    interesting = {
        ADD_MO_EXP_IMPORT_ORDINAL: ("보상", "추가 EXP 처리 루틴 ADD_MO_EXP 호출"),
        GET_EXP_IMPORT_ORDINAL: ("보상", "전투 보상 GET_EXP 직접 호출"),
        GET_GOLD_IMPORT_ORDINAL: ("보상", "전투 보상 GET_GOLD 직접 호출"),
        LOAD_BGM_IMPORT_ORDINAL: ("BGM", "전투 중 LOAD_BGM 직접 호출"),
        LOAD_BGM_SET_IMPORT_ORDINAL: ("BGM", "전투 중 LOAD_BGM_SET 직접 호출"),
        MO_ATT_TRS_IMPORT_ORDINAL: ("드롭", "런타임 드롭 아이템 변수 _MO_ATT_TRS 참조"),
    }
    seen: set[tuple[int, int, int]] = set()
    for ref in import_refs:
        info = interesting.get(ref.ordinal)
        if info is None:
            continue
        key = (ref.ordinal, ref.segment_index, ref.instruction_offset)
        if key in seen:
            continue
        seen.add(key)
        category, summary = info
        frequency = ordinal_frequency.get(ref.ordinal, 0)
        confidence = "확정" if ref.ordinal in (MO_ATT_TRS_IMPORT_ORDINAL,) else "주의"
        if ref.ordinal == MO_ATT_TRS_IMPORT_ORDINAL:
            if ref.operation == "8비트 즉시값 설정" and ref.value is not None:
                summary = f"전투 중 드롭 아이템을 ID {ref.value}로 설정"
            elif "설정" in ref.operation:
                summary = "전투 중 드롭 아이템을 동적으로 변경"
            elif "비교" in ref.operation:
                summary = f"현재 드롭 아이템을 {ref.value}와 비교"
        detail = (
            f"{ref.symbol} {ref.operation}. 전체 {group_count}개 그룹 중 {frequency}개 DLL에서 검출되었습니다. "
            "기본 MON 데이터만으로 결과를 단정하지 마세요."
        )
        rules.append(SpecialRule(group.dll_path, category, confidence, ref.location, summary, detail))

    # Additional battle-state patterns.  These are reported but remain
    # read-only because the exact surrounding condition is not reconstructed.
    stat_symbols = {
        "MG_ATT_UP", "MG_DEF_UP", "MG_DEF_DOWN", "MG_LUCK_UP", "MG_LUCK_DOWN",
        "MG_GET_HP", "HEAL_HP_SUB",
    }
    for ref in import_refs:
        symbol = ref.symbol.upper()
        frequency = ordinal_frequency.get(ref.ordinal, 0)
        rule: Optional[SpecialRule] = None
        if symbol == "_MO_ATT_ALGO" and "설정" in ref.operation:
            rule = SpecialRule(
                group.dll_path, "행동 패턴", "확정", ref.location,
                "전투 중 공격 AI 진입점을 변경",
                f"{ref.symbol} {ref.operation}. 행동 단계나 조건에 따라 공격 패턴이 교체될 수 있습니다. "
                "조건 자체는 읽기 전용 분석 대상입니다.",
            )
        elif symbol == "BGM_NO" and ("설정" in ref.operation or "비교" in ref.operation):
            if "비교" in ref.operation and ref.value is not None:
                summary = f"전투 중 BGM 번호 상태를 {ref.value}와 비교"
            elif ref.value is not None:
                summary = f"전투 중 BGM 번호 상태를 {ref.value}로 설정"
            else:
                summary = "전투 중 BGM 번호 상태를 동적으로 설정"
            rule = SpecialRule(
                group.dll_path, "BGM", "확정", ref.location, summary,
                "그룹 데이터의 초기 BGM과 별도로 런타임 BGM 상태를 다룹니다.",
            )
        elif symbol == "MO_BROKEN" and ("설정" in ref.operation or "비교" in ref.operation):
            if "비교" in ref.operation and ref.value is not None:
                summary = f"MO_BROKEN 상태를 {ref.value}와 비교"
            elif ref.value is not None:
                summary = f"MO_BROKEN 상태를 {ref.value}로 설정"
            else:
                summary = f"MO_BROKEN 상태를 {ref.operation}"
            rule = SpecialRule(
                group.dll_path, "전투 상태", "확정", ref.location, summary,
                "특수 파괴·종료 상태를 전투 로직에서 사용합니다.",
            )
        elif symbol in stat_symbols:
            rule = SpecialRule(
                group.dll_path, "능력치", "주의", ref.location,
                f"{ref.symbol} 루틴 사용",
                f"{ref.operation}. 전체 {group_count}개 그룹 중 {frequency}개 DLL에서 검출되었습니다. "
                "대상과 수치는 주변 AI 코드에 따라 달라집니다.",
            )
        if rule is not None:
            rules.append(rule)

    # Non-zero hooks are explicit extension points.  Report only the hooks
    # that can materially change battle results, not every normal AI pointer.
    for symbol, value, description in group.hook_rows():
        if value == 0 or symbol in ("_MO_MAG_PTR", "_MO_ATT_ALGO", "_MO_DEF_ALGO", "_MO_MAG_ALGO", "_MO_DED_ALGO"):
            continue
        if symbol in ("_MO_DEAD_HOOK", "_MO_BFR_MAG", "_MO_BFR_DMG", "_MO_INIT_PROC", "_MO_PLY_HOOK"):
            rules.append(SpecialRule(
                group.dll_path, "전투 훅", "후보", f"data+{symbol}",
                f"{description} 사용 (0x{value:04X})",
                "훅 내부에서 능력치·보상·행동이 추가로 변경될 수 있습니다. 포인터 자체는 읽기 전용입니다.",
            ))
    # Stable order and duplicate suppression.
    unique: list[SpecialRule] = []
    keys: set[tuple[str, str, str]] = set()
    for rule in rules:
        key = (rule.category, rule.location, rule.summary)
        if key not in keys:
            unique.append(rule); keys.add(key)
    return unique


def drop_probability_summary(chance: int, battles: int) -> dict[str, float]:
    chance = max(0, min(100, int(chance)))
    battles = max(1, int(battles))
    per = chance / 100.0
    return {
        "per_battle_percent": float(chance),
        "at_least_one_percent": (1.0 - (1.0 - per) ** battles) * 100.0,
        "none_percent": ((1.0 - per) ** battles) * 100.0,
        "expected_drops": battles * per,
    }



def load_group(path: Path) -> MonsterGroup:
    data = path.read_bytes()
    seg, count = find_monster_table(data)
    base = seg.file_offset
    if base + 0x128 > min(len(data), seg.file_offset + seg.length):
        raise FormatError("MON group block is truncated")
    records = load_monsters(path)
    return MonsterGroup(
        path, dll_number(path), base, count, [r.name for r in records],
        u16(data, base + 0x100), u16(data, base + 0x102),
        u16(data, base + 0x104), u16(data, base + 0x106),
        u16(data, base + 0x108), u16(data, base + 0x10A),
        u16(data, base + 0x10C), u16(data, base + 0x10E),
        u16(data, base + 0x110), u16(data, base + 0x112),
        u16(data, base + 0x114), u16(data, base + 0x116),
        data[base + 0x118], data[base + 0x119], data[base + 0x11A],
        u16(data, base + 0x11C),
        u16(data, base + 0x120), u16(data, base + 0x122),
        u16(data, base + 0x124), u16(data, base + 0x126),
        data[base + 0x108:base + 0x128].hex(" ").upper(),
        dynamic_refs := analyze_dynamic_drop_references(path),
        analyze_dynamic_drop_conditions(path, dynamic_refs),
    )


def patch_monster(rec: MonsterRecord, values: dict[str, Any], make_backup: bool = True) -> dict[str, Any]:
    path = rec.dll_path
    data = bytearray(path.read_bytes())
    current = load_monsters(path)
    applied = dict(values)
    group = load_group(path)
    for reward_key in ("exp", "gold"):
        if reward_key in applied:
            applied[reward_key] = clamp_single_reward_raw(
                current, reward_key, rec.slot, int(applied[reward_key]), rec.dll_number, group.bgm_id
            )
    values = applied
    if rec.slot >= len(current):
        raise ValueError("Monster slot no longer exists; reload the project")
    target = current[rec.slot]
    base = target.file_offset
    preserve_monster_record_quirks(path, rec.slot, data, base)
    if "name" in values:
        new_name = str(values["name"])
        if new_name != target.name or _is_kajasm_record(path, rec.slot, data, base):
            data[base + 48:base + 64] = encode_monster_name(new_name, path, rec.slot, data, base)
    for key in MONSTER_FIELDS:
        if key not in values:
            continue
        value = int(values[key])
        off, size, _ = MONSTER_FIELDS[key]
        if size == 1:
            if not 0 <= value <= 255: raise ValueError(f"{key}: 0..255 required")
            data[base + off] = value
        elif key == "hp":
            if not 1 <= value <= 65535: raise ValueError("HP: 1..65535 required")
            p16(data, base + 0x04, value)
            p16(data, base + 0x06, value)
        else:
            if not 0 <= value <= 65535: raise ValueError(f"{key}: 0..65535 required")
            p16(data, base + off, value)
    if "advanced_hex" in values:
        raw = bytes.fromhex(str(values["advanced_hex"]))
        if len(raw) != 24:
            raise ValueError("Advanced bytes must contain exactly 24 bytes (0x18..0x2F)")
        data[base + 0x18:base + 0x30] = raw
    if not is_monster_record(bytes(data[base:base + 64])):
        raise ValueError("Edited record failed safety validation")
    if len(data) != path.stat().st_size:
        raise AssertionError("In-place MON edit changed file size")
    atomic_write(path, bytes(data), make_backup)
    return applied


def patch_group(group: MonsterGroup, values: dict[str, int], make_backup: bool = True) -> None:
    path = group.dll_path
    data = bytearray(path.read_bytes())
    fresh = load_group(path)
    base = fresh.segment_offset
    mapping = {
        "graphic_id0": (0x100, 2, 0xFFFF),
        "graphic_addr0": (0x102, 2, 0xFFFF),
        "graphic_id1": (0x104, 2, 0xFFFF),
        "graphic_addr1": (0x106, 2, 0xFFFF),
        "drop_item_id": (0x118, 1, 255),
        "drop_chance": (0x119, 1, 100),
        "bgm_id": (0x11A, 1, 255),
    }
    for key, value in values.items():
        if key not in mapping: continue
        off, size, maximum = mapping[key]
        value = int(value)
        if not 0 <= value <= maximum:
            raise ValueError(f"{key}: 0..{maximum} required")
        if size == 1: data[base + off] = value
        else: p16(data, base + off, value)
    if data[base + 0x119] > 100:
        raise ValueError("Drop chance must be 0..100")
    atomic_write(path, bytes(data), make_backup)


# Runtime EXP estimator reconstructed from ED2MAIN.EXE.
def general_reward_90(raw: int) -> int:
    if raw <= 0: return 0
    value = (raw * 90) // 100
    return max(1, value)


def level_reward_rate(monster_level: int, party_average_level: int) -> int:
    difference = party_average_level - monster_level
    if difference <= 2: return 100
    if difference == 3: return 75
    if difference == 4: return 50
    if difference == 5: return 25
    return 0


def estimated_reward(raw: int, monster_level: int, party_average_level: int,
                     dll_num: int, bgm_id: int, *, no_general_90: bool = False,
                     no_level_penalty: bool = False) -> tuple[int, str]:
    if raw <= 0: return 0, "No reward"
    if bgm_id == 8:
        return raw, "BGM 8 special battle: raw value"
    base = raw if no_general_90 else general_reward_90(raw)
    base_label = "100%" if no_general_90 else "90%"
    if no_level_penalty or dll_num >= 0x505:
        return base, f"{base_label}, level attenuation disabled"
    rate = level_reward_rate(monster_level, party_average_level)
    return (base * rate) // 100, f"{base_label} × level rate {rate}%"


REWARD_ACCUMULATOR_MAX = 0xFFFF

def reward_before_accumulator(raw: int, dll_num: int, bgm_id: int) -> int:
    """Maximum value added to the 16-bit battle accumulator for one monster.

    Pre-M_505 level attenuation is intentionally not included: the guard uses
    the 100% case so the edited data stays safe at every possible party level.
    """
    if raw <= 0:
        return 0
    return raw if bgm_id == 8 else general_reward_90(raw)

def _active_records(records: list[MonsterRecord]) -> list[MonsterRecord]:
    active = [record for record in records if record.active_in_formation]
    return active or list(records)

def formation_reward_total(records: list[MonsterRecord], key: str, dll_num: int, bgm_id: int,
                           overrides: Optional[dict[int, int]] = None) -> int:
    overrides = overrides or {}
    return sum(
        reward_before_accumulator(overrides.get(record.slot, record.value(key)), dll_num, bgm_id)
        for record in _active_records(records)
    )

def max_raw_for_accumulator_reward(allowed_reward: int, dll_num: int, bgm_id: int) -> int:
    allowed_reward = max(0, min(REWARD_ACCUMULATOR_MAX, int(allowed_reward)))
    if bgm_id == 8:
        return allowed_reward
    if allowed_reward == 0:
        return 0
    # Largest raw value satisfying floor(raw * 90 / 100) <= allowed_reward.
    return min(0xFFFF, (((allowed_reward + 1) * 100) - 1) // 90)

def clamp_single_reward_raw(records: list[MonsterRecord], key: str, slot: int, desired_raw: int,
                            dll_num: int, bgm_id: int) -> int:
    target = next((record for record in records if record.slot == slot), None)
    if target is None or not target.active_in_formation:
        return max(0, min(0xFFFF, desired_raw))
    others = sum(
        reward_before_accumulator(record.value(key), dll_num, bgm_id)
        for record in _active_records(records) if record.slot != slot
    )
    allowed = max(0, REWARD_ACCUMULATOR_MAX - others)
    return min(max(0, desired_raw), max_raw_for_accumulator_reward(allowed, dll_num, bgm_id))

def fit_group_reward_raws(records: list[MonsterRecord], key: str, proposed: dict[int, int],
                          dll_num: int, bgm_id: int) -> tuple[dict[int, int], int]:
    """Proportionally reduce active formation rewards until the 16-bit sum is safe."""
    result = {record.slot: max(0, min(0xFFFF, proposed.get(record.slot, record.value(key))))
              for record in records}
    active = _active_records(records)
    total = sum(reward_before_accumulator(result[record.slot], dll_num, bgm_id) for record in active)
    if total <= REWARD_ACCUMULATOR_MAX:
        return result, 0

    # Integer binary search avoids float-dependent results. 1_000_000 means 100%.
    lo, hi = 0, 1_000_000
    while lo < hi:
        mid = (lo + hi + 1) // 2
        scaled_total = sum(
            reward_before_accumulator((result[record.slot] * mid) // 1_000_000, dll_num, bgm_id)
            for record in active
        )
        if scaled_total <= REWARD_ACCUMULATOR_MAX:
            lo = mid
        else:
            hi = mid - 1
    scale = lo
    adjusted = dict(result)
    for record in active:
        adjusted[record.slot] = (result[record.slot] * scale) // 1_000_000

    # Use any small remaining capacity without changing the relative ordering.
    while True:
        current_total = sum(
            reward_before_accumulator(adjusted[record.slot], dll_num, bgm_id) for record in active
        )
        best_slot = None
        best_gain = None
        for record in active:
            slot = record.slot
            if adjusted[slot] >= result[slot]:
                continue
            old_reward = reward_before_accumulator(adjusted[slot], dll_num, bgm_id)
            new_reward = reward_before_accumulator(adjusted[slot] + 1, dll_num, bgm_id)
            gain = new_reward - old_reward
            if current_total + gain <= REWARD_ACCUMULATOR_MAX:
                best_slot, best_gain = slot, gain
                if gain > 0:
                    break
        if best_slot is None:
            break
        adjusted[best_slot] += 1
        if best_gain == 0:
            # Zero-gain raw increments can otherwise create long loops. Jump to the
            # next reward boundary, but never beyond the requested value.
            allowed = REWARD_ACCUMULATOR_MAX - current_total
            max_raw = max_raw_for_accumulator_reward(
                reward_before_accumulator(adjusted[best_slot], dll_num, bgm_id) + allowed, dll_num, bgm_id
            )
            adjusted[best_slot] = min(result[best_slot], max(adjusted[best_slot], max_raw))
    changed = sum(adjusted[record.slot] != result[record.slot] for record in active)
    return adjusted, changed


# ---------------------------------------------------------------------------
# ED2MAIN item table
# ---------------------------------------------------------------------------

STAT_GROUP_LABELS = {
    0: "없음 / 소모품 / 특수",
    1: "공격력 PLY_ATT (+0x10)",
    2: "방어력 PLY_DEF (+0x12)",
    3: "주문능력 PLY_INT2 (+0x0A)",
    4: "민첩 PLY_AGL (+0x16)",
    5: "행운 PLY_LUCK (+0x17)",
    6: "지능 PLY_INT (+0x15)",
    7: "없음 / 특수",
}

ITEM_KOUKA_OFFSETS = (0x00, 0x10, 0x12, 0x0A, 0x16, 0x17, 0x15, 0x00)


@dataclass
class ItemRecord:
    item_id: int
    name: str
    price: int
    price_mantissa: int
    price_exponent: int
    packed: int
    stat_group: int
    effect_id: int
    power_raw: int
    secondary_raw: int
    type_mask: int
    file_offset: int
    magic_mode: str = "fixed"
    proportional_unit: int = 5

    @property
    def power_effective(self) -> int:
        return self.power_raw * 5

    @property
    def secondary_effective(self) -> int:
        unit = self.proportional_unit if self.magic_mode == "proportional" else 10
        return self.secondary_raw * unit

    @property
    def stat_label(self) -> str:
        return STAT_GROUP_LABELS.get(self.stat_group, f"Group {self.stat_group}")

    @property
    def item_kouka_offset(self) -> int:
        return ITEM_KOUKA_OFFSETS[self.stat_group]

    @property
    def item_magic_id(self) -> int:
        return self.effect_id

    @property
    def item_koka_num(self) -> int:
        return self.power_effective

    @property
    def item_magic_num(self) -> int:
        return self.secondary_effective


def verify_item_table(data: bytes) -> None:
    end = ITEM_NAME_BASE + (ITEM_COUNT - 1) * ITEM_STRIDE + 20
    if end > len(data):
        raise FormatError("ED2MAIN.EXE is too small for the known item table")
    exports = parse_ne_exports(data)
    address = exports.get("ITEM_TABLE")
    if address is None or ne_address_to_file(data, *address) != ITEM_NAME_BASE:
        raise FormatError("ITEM_TABLE export does not match the known item table")


def decode_price(mantissa: int, exponent: int) -> int:
    if exponent > 9:
        raise FormatError("Item price exponent is implausibly large")
    return mantissa * (10 ** exponent)


def encode_price(price: int) -> tuple[int, int]:
    if price < 0:
        raise ValueError("Price must be nonnegative")
    if price == 0:
        return 0, 0
    mantissa = price
    exponent = 0
    while mantissa > 255 and mantissa % 10 == 0 and exponent < 9:
        mantissa //= 10
        exponent += 1
    if mantissa > 255:
        raise ValueError("Price is not exactly representable as byte × 10^exponent; use a price with enough trailing zeros")
    return mantissa, exponent


def decode_item_name(raw: bytes) -> str:
    # Names are fixed 14-byte CP949 fields, generally left padded with spaces.
    return raw.rstrip(b"\x00").decode("cp949", errors="replace").strip()


def encode_item_name(name: str) -> bytes:
    raw = name.encode("cp949")
    if len(raw) > 14:
        raise ValueError("Item name must be <= 14 bytes in CP949")
    return b" " * (14 - len(raw)) + raw


def load_items(exe_path: Path) -> list[ItemRecord]:
    data = exe_path.read_bytes()
    verify_item_table(data)
    state = _item_magic_scaling_state_data(data)
    proportional_unit = 5 if state == "per_item" else 10
    result: list[ItemRecord] = []
    for item_id in range(ITEM_COUNT):
        off = ITEM_NAME_BASE + item_id * ITEM_STRIDE
        mantissa, exponent = data[off + 14], data[off + 15]
        packed = data[off + 16]
        result.append(ItemRecord(
            item_id, decode_item_name(data[off:off + 14]), decode_price(mantissa, exponent),
            mantissa, exponent, packed, packed >> 5, packed & 0x1F,
            data[off + 17], data[off + 18], data[off + 19], off,
            proportional_unit=proportional_unit,
        ))
    return result


def patch_item(exe_path: Path, item_id: int, values: dict[str, Any], make_backup: bool = True) -> None:
    data = bytearray(exe_path.read_bytes())
    verify_item_table(data)
    if not 0 <= item_id < ITEM_COUNT:
        raise ValueError("Regular item ID must be 0..75")
    off = ITEM_NAME_BASE + item_id * ITEM_STRIDE
    if "name" in values:
        data[off:off + 14] = encode_item_name(str(values["name"]))
    if "price" in values:
        mantissa, exponent = encode_price(int(values["price"]))
        data[off + 14] = mantissa
        data[off + 15] = exponent
    stat_group = int(values.get("stat_group", data[off + 16] >> 5))
    effect_id = int(values.get("effect_id", data[off + 16] & 0x1F))
    if not 0 <= stat_group <= 7: raise ValueError("Stat group must be 0..7")
    if not 0 <= effect_id <= 31: raise ValueError("Effect ID must be 0..31")
    data[off + 16] = (stat_group << 5) | effect_id
    for key, delta in (("power_raw", 17), ("secondary_raw", 18), ("type_mask", 19)):
        if key in values:
            value = int(values[key])
            if not 0 <= value <= 255: raise ValueError(f"{key}: 0..255 required")
            data[off + delta] = value
    if "magic_mode" in values:
        _set_item_magic_mode_data(data, item_id, str(values["magic_mode"]))
    if len(data) != exe_path.stat().st_size:
        raise AssertionError("In-place item edit changed executable size")
    # Reparse before commit.
    verify_item_table(bytes(data))
    atomic_write(exe_path, bytes(data), make_backup)


@dataclass
class EventItemRecord:
    item_id: int
    name: str
    file_offset: int


def verify_event_item_table(data: bytes) -> None:
    end = EVENT_ITEM_NAME_BASE + EVENT_ITEM_COUNT * EVENT_ITEM_NAME_SIZE
    if end > len(data):
        raise FormatError("ED2MAIN.EXE is too small for the event item name table")
    exports = parse_ne_exports(data)
    address = exports.get("ITEM_TABLE2")
    if address is None or ne_address_to_file(data, *address) != EVENT_ITEM_NAME_BASE:
        raise FormatError("ITEM_TABLE2 export does not match the event item table")


def load_event_items(exe_path: Path) -> list[EventItemRecord]:
    data = exe_path.read_bytes()
    verify_event_item_table(data)
    return [
        EventItemRecord(
            EVENT_ITEM_ID_BASE + index,
            decode_item_name(data[EVENT_ITEM_NAME_BASE + index * EVENT_ITEM_NAME_SIZE:
                                  EVENT_ITEM_NAME_BASE + (index + 1) * EVENT_ITEM_NAME_SIZE]),
            EVENT_ITEM_NAME_BASE + index * EVENT_ITEM_NAME_SIZE,
        )
        for index in range(EVENT_ITEM_COUNT)
    ]


def patch_event_item(exe_path: Path, item_id: int, name: str, make_backup: bool = True) -> None:
    if not EVENT_ITEM_ID_BASE <= item_id < EVENT_ITEM_ID_BASE + EVENT_ITEM_COUNT:
        raise ValueError("Event item ID must be 100..126")
    data = bytearray(exe_path.read_bytes())
    verify_event_item_table(data)
    off = EVENT_ITEM_NAME_BASE + (item_id - EVENT_ITEM_ID_BASE) * EVENT_ITEM_NAME_SIZE
    data[off:off + EVENT_ITEM_NAME_SIZE] = encode_item_name(name)
    verify_event_item_table(bytes(data))
    atomic_write(exe_path, bytes(data), make_backup)


@dataclass
class MagicRecord:
    magic_id: int
    name: str
    cost: int
    select_flags: int
    packed_select_multiplier: int
    count_raw: int
    file_offset: int
    handler_offset: int
    handler_name: str

    @property
    def secondary_select(self) -> bool:
        return bool(self.packed_select_multiplier & 0x80)

    @property
    def multiplier(self) -> int:
        return self.packed_select_multiplier & 0x7F

    @property
    def count_high(self) -> int:
        return (self.count_raw >> 4) & 0x0F

    @property
    def count_low(self) -> int:
        return self.count_raw & 0x0F


def describe_magic_multiplier(multiplier: int) -> str:
    """Return a concise Korean explanation of MAGIC_BAIRITU."""
    if not 0 <= multiplier <= 0x7F:
        return "MAGIC_BAIRITU 값이 0..127 범위를 벗어났습니다."
    if multiplier == 100:
        scale = "기준 효과와 동일"
    elif multiplier == 0:
        scale = "효과 기준값이 0"
    elif multiplier < 100:
        scale = f"기준 효과의 약 {multiplier}%"
    else:
        scale = f"기준 효과보다 약 {multiplier - 100}% 강함"
    return f"MAGIC_BAIRITU={multiplier}: 주문 효과 배율 · {scale} (100=기준)"


def describe_magic_count(count_raw: int) -> tuple[str, bool]:
    """Explain the packed MAGIC_CNT recharge timing byte.

    The low nibble is the initial countdown and the high nibble is the
    repeating countdown. A zero nibble can underflow in the original code,
    so the UI flags it as unsafe rather than presenting it as instant charge.
    """
    if not 0 <= count_raw <= 0xFF:
        return "MAGIC_CNT 값이 0..255 범위를 벗어났습니다.", True
    high = (count_raw >> 4) & 0x0F
    low = count_raw & 0x0F
    if high == 0 or low == 0:
        return (
            f"MAGIC_CNT=0x{count_raw:02X}: 시작 주기 {low}, 반복 주기 {high} · "
            "0 니블은 언더플로로 비정상 충전될 수 있으므로 사용하지 않는 것이 안전합니다.",
            True,
        )
    estimated = low + high * 14
    if high == low == 1:
        speed = "가장 빠른 안정 권장값"
    elif high == low:
        speed = f"0x11보다 대략 {high}배 느린 균일 주기"
    else:
        speed = "초기 주기와 반복 주기가 다른 사용자 설정"
    return (
        f"MAGIC_CNT=0x{count_raw:02X}: 시작 주기 {low}, 반복 주기 {high}, "
        f"예상 총 카운트 {estimated} · {speed}",
        False,
    )


def decode_magic_name(raw: bytes) -> str:
    return raw.decode("cp949", errors="replace").strip()


def encode_magic_name(name: str) -> bytes:
    raw = name.encode("cp949")
    if len(raw) > 8:
        raise ValueError("Magic name must be <= 8 bytes in CP949")
    return b" " * (8 - len(raw)) + raw


def verify_magic_table(data: bytes) -> None:
    end = MAGIC_PARAM_BASE + MAGIC_COUNT * MAGIC_RECORD_SIZE
    if end > len(data):
        raise FormatError("ED2MAIN.EXE is too small for the magic parameter table")
    exports = parse_ne_exports(data)
    handler = exports.get("MAGIC_TABLE")
    get_prm = exports.get("GET_MAGIC_PRM")
    if handler is None or get_prm is None:
        raise FormatError("Required ED2 magic exports are missing")
    if ne_address_to_file(data, *handler) != MAGIC_HANDLER_TABLE_BASE:
        raise FormatError("MAGIC_TABLE export does not match the known handler table")
    # GET_MAGIC_PRM contains: mov ah,0Ch / mul ah / add ax,363Ch
    get_prm_file = ne_address_to_file(data, *get_prm)
    if data[get_prm_file + 2:get_prm_file + 9] != bytes.fromhex("B4 0C F6 E4 05 3C 36"):
        raise FormatError("GET_MAGIC_PRM signature does not match this editor build")


def load_magics(exe_path: Path) -> list[MagicRecord]:
    data = exe_path.read_bytes()
    verify_magic_table(data)
    exports = parse_ne_exports(data)
    address_names = {address: name for name, address in exports.items()}
    result: list[MagicRecord] = []
    for magic_id in range(MAGIC_COUNT):
        off = MAGIC_PARAM_BASE + magic_id * MAGIC_RECORD_SIZE
        record = data[off:off + MAGIC_RECORD_SIZE]
        handler_offset = u16(data, MAGIC_HANDLER_TABLE_BASE + magic_id * 2)
        result.append(MagicRecord(
            magic_id=magic_id,
            name=decode_magic_name(record[:8]),
            cost=record[8],
            select_flags=record[9],
            packed_select_multiplier=record[10],
            count_raw=record[11],
            file_offset=off,
            handler_offset=handler_offset,
            handler_name=address_names.get((86, handler_offset), f"sub_{handler_offset:04X}"),
        ))
    return result


def patch_magic(exe_path: Path, magic_id: int, values: dict[str, Any], make_backup: bool = True) -> None:
    if not 0 <= magic_id < MAGIC_COUNT:
        raise ValueError("Magic ID must be 0..31")
    data = bytearray(exe_path.read_bytes())
    verify_magic_table(data)
    off = MAGIC_PARAM_BASE + magic_id * MAGIC_RECORD_SIZE
    if "name" in values:
        data[off:off + 8] = encode_magic_name(str(values["name"]))
    for key, delta in (("cost", 8), ("select_flags", 9), ("count_raw", 11)):
        if key in values:
            value = int(values[key])
            if not 0 <= value <= 255:
                raise ValueError(f"{key}: 0..255 required")
            data[off + delta] = value
    if "packed_select_multiplier" in values:
        value = int(values["packed_select_multiplier"])
        if not 0 <= value <= 255:
            raise ValueError("packed_select_multiplier: 0..255 required")
        data[off + 10] = value
    else:
        packed = data[off + 10]
        if "secondary_select" in values:
            packed = (packed | 0x80) if bool(values["secondary_select"]) else (packed & 0x7F)
        if "multiplier" in values:
            multiplier = int(values["multiplier"])
            if not 0 <= multiplier <= 0x7F:
                raise ValueError("Multiplier must be 0..127")
            packed = (packed & 0x80) | multiplier
        data[off + 10] = packed
    verify_magic_table(bytes(data))
    atomic_write(exe_path, bytes(data), make_backup)


def patch_magic_recharge_bulk(exe_path: Path, magic_ids: Iterable[int], count_raw: int,
                              make_backup: bool = True, allow_unsafe: bool = False) -> int:
    """Set one MAGIC_CNT value for several spells in a single atomic write."""
    ids = sorted(set(int(value) for value in magic_ids))
    if not ids:
        raise ValueError("재충전 주기를 적용할 주문이 선택되지 않았습니다.")
    if any(not 0 <= magic_id < MAGIC_COUNT for magic_id in ids):
        raise ValueError("Magic ID must be 0..31")
    count_raw = int(count_raw)
    if not 0 <= count_raw <= 0xFF:
        raise ValueError("MAGIC_CNT must be 0..255")
    _description, unsafe = describe_magic_count(count_raw)
    if unsafe and not allow_unsafe:
        raise ValueError("통일 값의 상·하위 니블은 모두 1..15여야 합니다. 0 니블은 충전 언더플로 위험이 있습니다.")
    data = bytearray(exe_path.read_bytes())
    verify_magic_table(data)
    changed = 0
    for magic_id in ids:
        off = MAGIC_PARAM_BASE + magic_id * MAGIC_RECORD_SIZE + 11
        if data[off] != count_raw:
            data[off] = count_raw
            changed += 1
    if changed:
        verify_magic_table(bytes(data))
        atomic_write(exe_path, bytes(data), make_backup)
    return changed


def parse_magic_id_list(text: str) -> list[int]:
    value = text.strip().lower()
    if value in ("all", "전체", "*"):
        return list(range(MAGIC_COUNT))
    result: set[int] = set()
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            left, right = part.split("-", 1)
            start = parse_number(left, 0, MAGIC_COUNT - 1, "magic ID")
            end = parse_number(right, 0, MAGIC_COUNT - 1, "magic ID")
            if end < start:
                start, end = end, start
            result.update(range(start, end + 1))
        else:
            result.add(parse_number(part, 0, MAGIC_COUNT - 1, "magic ID"))
    if not result:
        raise ValueError("주문 ID 목록이 비어 있습니다.")
    return sorted(result)


def _experience_patch_offsets(data: bytes | bytearray) -> dict[str, int]:
    raw = bytes(data)
    exports = parse_ne_exports(raw)
    expected = {
        "GET_EXP": (EXP_PATCH_SEGMENT, EXP_GET_EXP_ENTRY),
        "ADD_MO_EXP": (EXP_PATCH_SEGMENT, 0x41AE),
        "CALC_NAKAMA_NUM": (EXP_PATCH_SEGMENT, EXP_COUNT_ROUTINE),
    }
    for name, address in expected.items():
        if exports.get(name) != address:
            raise FormatError(f"{name} does not match the supported ED2MAIN.EXE build")
    segments = parse_ne_segments(raw)
    segment = segments[EXP_PATCH_SEGMENT - 1]
    required_end = max(
        EXP_GET_EXP_ENTRY + len(EXP_SPLIT_ORIGINAL),
        EXP_AWARD_STATUS_CHECK + len(EXP_AWARD_STATUS_ORIGINAL),
        EXP_GENERAL_90_CALL + len(EXP_GENERAL_90_ORIGINAL),
        EXP_LEVEL_RATE_CALL + len(EXP_LEVEL_RATE_ORIGINAL),
        EXP_COUNT_STATUS_CHECK + len(EXP_COUNT_STATUS_ORIGINAL),
    )
    if required_end > segment.length:
        raise FormatError("ED2MAIN.EXE segment 86 is too small for the experience-rule patch")
    base = segment.file_offset
    return {
        "split": base + EXP_GET_EXP_ENTRY,
        "award_status": base + EXP_AWARD_STATUS_CHECK,
        "general_90": base + EXP_GENERAL_90_CALL,
        "level_rate": base + EXP_LEVEL_RATE_CALL,
        "count_status": base + EXP_COUNT_STATUS_CHECK,
    }


def _match_binary_choice(data: bytes, offset: int, original: bytes, patched: bytes,
                         label: str) -> tuple[Optional[bool], str]:
    current = data[offset:offset + len(original)]
    if current == original:
        return False, ""
    if current == patched:
        return True, ""
    return None, f"{label} 위치의 코드가 원본/지원 패치와 일치하지 않습니다."


def load_experience_rules(exe_path: Path) -> ExperienceRuleState:
    data = exe_path.read_bytes()
    try:
        off = _experience_patch_offsets(data)
    except Exception as exc:
        return ExperienceRuleState(False, False, False, False, False, str(exc))
    split, split_error = _match_binary_choice(data, off["split"], EXP_SPLIT_ORIGINAL, EXP_SPLIT_FULL_EACH, "파티 분배")
    award, award_error = _match_binary_choice(data, off["award_status"], EXP_AWARD_STATUS_ORIGINAL, EXP_AWARD_STATUS_INCLUDE, "경험치 지급 대상")
    count, count_error = _match_binary_choice(data, off["count_status"], EXP_COUNT_STATUS_ORIGINAL, EXP_COUNT_STATUS_INCLUDE, "파티원 수 계산")
    general, general_error = _match_binary_choice(data, off["general_90"], EXP_GENERAL_90_ORIGINAL, EXP_GENERAL_90_DISABLED, "90% 보정")
    level, level_error = _match_binary_choice(data, off["level_rate"], EXP_LEVEL_RATE_ORIGINAL, EXP_LEVEL_RATE_DISABLED, "레벨 보정")
    errors = [text for text in (split_error, award_error, count_error, general_error, level_error) if text]
    if award is not None and count is not None and award != count:
        errors.append("기절자 포함 패치가 지급 루프와 인원 계산 루프에 서로 다르게 적용되어 있습니다.")
    if errors or None in (split, award, count, general, level):
        return ExperienceRuleState(False, False, False, False, False, " ".join(errors))
    return ExperienceRuleState(bool(award), bool(split), bool(general), bool(level), True, "")


def patch_experience_rules(exe_path: Path, state: ExperienceRuleState,
                           make_backup: bool = True) -> int:
    if not state.recognized:
        raise ValueError("인식되지 않은 경험치 패치 상태는 적용할 수 없습니다.")
    data = bytearray(exe_path.read_bytes())
    current = load_experience_rules(exe_path)
    if not current.recognized:
        raise FormatError(current.detail or "현재 경험치 루틴을 안전하게 인식할 수 없습니다.")
    off = _experience_patch_offsets(data)
    replacements = {
        "split": EXP_SPLIT_FULL_EACH if state.no_party_split else EXP_SPLIT_ORIGINAL,
        "award_status": EXP_AWARD_STATUS_INCLUDE if state.include_incapacitated else EXP_AWARD_STATUS_ORIGINAL,
        "count_status": EXP_COUNT_STATUS_INCLUDE if state.include_incapacitated else EXP_COUNT_STATUS_ORIGINAL,
        "general_90": EXP_GENERAL_90_DISABLED if state.no_general_90_percent else EXP_GENERAL_90_ORIGINAL,
        "level_rate": EXP_LEVEL_RATE_DISABLED if state.no_level_penalty else EXP_LEVEL_RATE_ORIGINAL,
    }
    changed = 0
    for key, replacement in replacements.items():
        start = off[key]
        old = bytes(data[start:start + len(replacement)])
        if old != replacement:
            data[start:start + len(replacement)] = replacement
            changed += 1
    if changed:
        atomic_write(exe_path, bytes(data), make_backup)
    verified = load_experience_rules(exe_path)
    if verified != state:
        raise AssertionError(f"experience patch verification failed: {verified} != {state}")
    return changed


def _gold_reward_patch_offsets(data: bytes | bytearray) -> dict[str, int]:
    raw = bytes(data)
    exports = parse_ne_exports(raw)
    if exports.get("ADD_MO_GOLD") != (EXP_PATCH_SEGMENT, 0x41CA):
        raise FormatError("ADD_MO_GOLD does not match the supported ED2MAIN.EXE build")
    segments = parse_ne_segments(raw)
    segment = segments[EXP_PATCH_SEGMENT - 1]
    required_end = max(
        GOLD_GENERAL_90_CALL + len(GOLD_GENERAL_90_ORIGINAL),
        GOLD_LEVEL_RATE_CALL + len(GOLD_LEVEL_RATE_ORIGINAL),
    )
    if required_end > segment.length:
        raise FormatError("ED2MAIN.EXE segment 86 is too small for the Gold-rule patch")
    base = segment.file_offset
    return {
        "general_90": base + GOLD_GENERAL_90_CALL,
        "level_rate": base + GOLD_LEVEL_RATE_CALL,
    }


def load_gold_reward_rules(exe_path: Path) -> GoldRewardRuleState:
    data = exe_path.read_bytes()
    try:
        off = _gold_reward_patch_offsets(data)
    except Exception as exc:
        return GoldRewardRuleState(False, False, False, str(exc))
    general, general_error = _match_binary_choice(
        data, off["general_90"], GOLD_GENERAL_90_ORIGINAL, GOLD_GENERAL_90_DISABLED,
        "Gold 90% 보정",
    )
    level, level_error = _match_binary_choice(
        data, off["level_rate"], GOLD_LEVEL_RATE_ORIGINAL, GOLD_LEVEL_RATE_DISABLED,
        "Gold 레벨 스케일링",
    )
    errors = [text for text in (general_error, level_error) if text]
    if errors or None in (general, level):
        return GoldRewardRuleState(False, False, False, " ".join(errors))
    return GoldRewardRuleState(bool(general), bool(level), True, "")


def patch_gold_reward_rules(exe_path: Path, state: GoldRewardRuleState,
                            make_backup: bool = True) -> int:
    if not state.recognized:
        raise ValueError("인식되지 않은 Gold 보상 패치 상태는 적용할 수 없습니다.")
    data = bytearray(exe_path.read_bytes())
    current = load_gold_reward_rules(exe_path)
    if not current.recognized:
        raise FormatError(current.detail or "현재 Gold 보상 루틴을 안전하게 인식할 수 없습니다.")
    off = _gold_reward_patch_offsets(data)
    replacements = {
        "general_90": GOLD_GENERAL_90_DISABLED if state.no_general_90_percent else GOLD_GENERAL_90_ORIGINAL,
        "level_rate": GOLD_LEVEL_RATE_DISABLED if state.no_level_scaling else GOLD_LEVEL_RATE_ORIGINAL,
    }
    changed = 0
    for key, replacement in replacements.items():
        start2 = off[key]
        if bytes(data[start2:start2 + len(replacement)]) != replacement:
            data[start2:start2 + len(replacement)] = replacement
            changed += 1
    if changed:
        atomic_write(exe_path, bytes(data), make_backup)
    verified = load_gold_reward_rules(exe_path)
    if verified != state:
        raise AssertionError(f"Gold reward patch verification failed: {verified} != {state}")
    return changed


def gold_reward_preset_state(name: str) -> GoldRewardRuleState:
    mapping = {
        "original": GoldRewardRuleState(False, False),
        "no-90": GoldRewardRuleState(True, False),
        "no-level": GoldRewardRuleState(False, True),
        "full": GoldRewardRuleState(True, True),
    }
    try:
        return mapping[name]
    except KeyError as exc:
        raise ValueError(f"Unknown Gold reward preset: {name}") from exc


def experience_preset_state(name: str) -> ExperienceRuleState:
    mapping = {
        "original": ExperienceRuleState(False, False, False, False),
        "include-stunned": ExperienceRuleState(True, False, False, False),
        "no-split": ExperienceRuleState(False, True, False, False),
        "include-stunned-no-split": ExperienceRuleState(True, True, False, False),
        "full": ExperienceRuleState(True, True, True, True),
    }
    try:
        return mapping[name]
    except KeyError as exc:
        raise ValueError(f"알 수 없는 경험치 프리셋: {name}") from exc


def experience_distribution_preview(total_exp: int, active_members: int, incapacitated_members: int,
                                    state: ExperienceRuleState) -> dict[str, int]:
    total_exp = max(0, int(total_exp))
    active_members = max(0, min(4, int(active_members)))
    incapacitated_members = max(0, min(active_members, int(incapacitated_members)))
    eligible = active_members if state.include_incapacitated else active_members - incapacitated_members
    if eligible <= 0:
        return {"eligible": 0, "per_member": 0, "distributed_total": 0}
    per_member = total_exp if state.no_party_split else (total_exp + eligible - 1) // eligible
    return {"eligible": eligible, "per_member": per_member, "distributed_total": per_member * eligible}


def _item_magic_patch_offsets(data: bytes | bytearray) -> dict[str, int]:
    """Return verified file offsets used by the item-magic mode patch."""
    raw = bytes(data)
    exports = parse_ne_exports(raw)
    calc_entry = exports.get("CALC_MAG_KOKA")
    get_item_entry = exports.get("GET_ITEM_PRM")
    if calc_entry != (ITEM_MAGIC_PATCH_SEGMENT, ITEM_MAGIC_CALC_ENTRY):
        raise FormatError("CALC_MAG_KOKA does not match the supported ED2MAIN.EXE build")
    # The replaced secondary-value loader is inside GET_ITEM_PRM.
    if get_item_entry != (ITEM_MAGIC_PATCH_SEGMENT, ITEM_MAGIC_GET_ITEM_EXPORT):
        raise FormatError("GET_ITEM_PRM does not match the supported ED2MAIN.EXE build")
    segments = parse_ne_segments(raw)
    data_segment = segments[ITEM_MAGIC_DATA_SEGMENT - 1]
    code_segment = segments[ITEM_MAGIC_PATCH_SEGMENT - 1]
    required_end = max(
        ITEM_MAGIC_GET_ITEM_ENTRY + len(ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD),
        ITEM_MAGIC_LEGACY_CAVE + len(ITEM_MAGIC_LEGACY_PATCHED_CAVE),
        ITEM_MAGIC_CODE_END,
    )
    if required_end > code_segment.length:
        raise FormatError("ED2MAIN.EXE segment 86 is too small for the per-item magic patch")
    if ITEM_MAGIC_RUNTIME_FLAG >= data_segment.length:
        raise FormatError("ED2MAIN.EXE data segment is too small for the item-magic runtime flag")
    code_base = code_segment.file_offset
    return {
        "calc": code_base + ITEM_MAGIC_CALC_ENTRY,
        "get_item": code_base + ITEM_MAGIC_GET_ITEM_ENTRY,
        "legacy_cave": code_base + ITEM_MAGIC_LEGACY_CAVE,
        "code": code_base + ITEM_MAGIC_CODE_START,
        "select_code": code_base + ITEM_MAGIC_SELECT_CODE,
        "calc_code": code_base + ITEM_MAGIC_CALC_CODE,
        "mode_table": code_base + ITEM_MAGIC_MODE_TABLE,
        "runtime_flag": data_segment.file_offset + ITEM_MAGIC_RUNTIME_FLAG,
    }


def _item_magic_patch_template(select_code: bytes = ITEM_MAGIC_SELECT_CODE_BYTES) -> bytearray:
    region = bytearray(ITEM_MAGIC_CODE_END - ITEM_MAGIC_CODE_START)
    select_at = ITEM_MAGIC_SELECT_CODE - ITEM_MAGIC_CODE_START
    calc_at = ITEM_MAGIC_CALC_CODE - ITEM_MAGIC_CODE_START
    region[select_at:select_at + len(select_code)] = select_code
    region[calc_at:calc_at + len(ITEM_MAGIC_CALC_CODE_BYTES)] = ITEM_MAGIC_CALC_CODE_BYTES
    # All item modes default to fixed (zero).
    return region


def _item_magic_scaling_state_data(data: bytes | bytearray) -> str:
    """Return fixed, legacy_proportional, per_item_x10, per_item, or unknown."""
    raw = bytes(data)
    off = _item_magic_patch_offsets(raw)
    calc = raw[off["calc"]:off["calc"] + len(ITEM_MAGIC_ORIGINAL_CALC_HEAD)]
    get_item = raw[off["get_item"]:off["get_item"] + len(ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD)]
    legacy_cave = raw[
        off["legacy_cave"]:off["legacy_cave"] + len(ITEM_MAGIC_LEGACY_ORIGINAL_CAVE)
    ]
    region = raw[off["code"]:off["code"] + (ITEM_MAGIC_CODE_END - ITEM_MAGIC_CODE_START)]
    runtime_flag = raw[off["runtime_flag"]]

    if (
        calc == ITEM_MAGIC_ORIGINAL_CALC_HEAD
        and get_item == ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD
        and legacy_cave == ITEM_MAGIC_LEGACY_ORIGINAL_CAVE
        and region == bytes(len(region))
        and runtime_flag == 0
    ):
        return "fixed"
    if (
        calc == ITEM_MAGIC_LEGACY_CALC_HEAD
        and get_item == ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD
        and legacy_cave == ITEM_MAGIC_LEGACY_PATCHED_CAVE
        and region == bytes(len(region))
        and runtime_flag == 0
    ):
        return "legacy_proportional"
    if (
        calc == ITEM_MAGIC_PER_ITEM_CALC_HEAD
        and get_item == ITEM_MAGIC_PER_ITEM_GET_ITEM_HEAD
        and legacy_cave == ITEM_MAGIC_LEGACY_ORIGINAL_CAVE
        and runtime_flag == 0
    ):
        template = _item_magic_patch_template()
        table_start = ITEM_MAGIC_MODE_TABLE - ITEM_MAGIC_CODE_START
        table_end = table_start + ITEM_COUNT
        # Only the mode table is mutable.
        candidate = bytearray(region)
        modes = candidate[table_start:table_end]
        candidate[table_start:table_end] = bytes(ITEM_COUNT)
        if candidate == template and all(value in (0, 1) for value in modes):
            return "per_item"
        old_template = _item_magic_patch_template(ITEM_MAGIC_SELECT_CODE_X10_BYTES)
        if candidate == old_template and all(value in (0, 1) for value in modes):
            return "per_item_x10"
    return "unknown"


def item_magic_scaling_state(exe_path: Path) -> str:
    return _item_magic_scaling_state_data(exe_path.read_bytes())


def _read_item_magic_modes_data(data: bytes | bytearray) -> list[str]:
    state = _item_magic_scaling_state_data(data)
    if state in ("per_item", "per_item_x10"):
        off = _item_magic_patch_offsets(data)["mode_table"]
        raw = bytes(data)[off:off + ITEM_COUNT]
        return ["proportional" if value else "fixed" for value in raw]
    if state == "legacy_proportional":
        return ["proportional"] * ITEM_COUNT
    return ["fixed"] * ITEM_COUNT


def load_item_magic_modes(exe_path: Path) -> list[str]:
    return _read_item_magic_modes_data(exe_path.read_bytes())


def _install_per_item_magic_patch(data: bytearray, default_mode: str | None = None) -> None:
    state = _item_magic_scaling_state_data(data)
    if state == "unknown":
        raise FormatError(
            "Item-magic code contains unrecognized bytes; refusing to overwrite another ED2MAIN patch"
        )
    if state == "per_item":
        return
    old_modes = None
    if state == "per_item_x10":
        mode_off = _item_magic_patch_offsets(data)["mode_table"]
        old_modes = bytes(data[mode_off:mode_off + ITEM_COUNT])
        # Convert only proportional items from 10%-raw units to 5%-raw units,
        # preserving their effective percentages exactly. Fixed items stay x10.
        for item_id, mode_value in enumerate(old_modes):
            if mode_value:
                item_off = ITEM_NAME_BASE + item_id * ITEM_STRIDE + 18
                raw_value = data[item_off]
                if raw_value > 127:
                    raise FormatError(f"Item {item_id} proportional raw value is too large to migrate safely")
                data[item_off] = raw_value * 2
    if default_mode is None:
        default_mode = "proportional" if state == "legacy_proportional" else "fixed"
    if default_mode not in ("fixed", "proportional"):
        raise ValueError("default_mode must be fixed or proportional")

    off = _item_magic_patch_offsets(data)
    data[off["calc"]:off["calc"] + len(ITEM_MAGIC_PER_ITEM_CALC_HEAD)] = ITEM_MAGIC_PER_ITEM_CALC_HEAD
    data[
        off["get_item"]:off["get_item"] + len(ITEM_MAGIC_PER_ITEM_GET_ITEM_HEAD)
    ] = ITEM_MAGIC_PER_ITEM_GET_ITEM_HEAD
    data[
        off["legacy_cave"]:off["legacy_cave"] + len(ITEM_MAGIC_LEGACY_ORIGINAL_CAVE)
    ] = ITEM_MAGIC_LEGACY_ORIGINAL_CAVE
    region = _item_magic_patch_template()
    table_at = ITEM_MAGIC_MODE_TABLE - ITEM_MAGIC_CODE_START
    if old_modes is not None:
        region[table_at:table_at + ITEM_COUNT] = old_modes
    else:
        region[table_at:table_at + ITEM_COUNT] = bytes(
            [1 if default_mode == "proportional" else 0] * ITEM_COUNT
        )
    data[off["code"]:off["code"] + len(region)] = region


def _set_item_magic_mode_data(data: bytearray, item_id: int, mode: str) -> None:
    if not 0 <= item_id < ITEM_COUNT:
        raise ValueError("Regular item ID must be 0..75")
    mode = normalize_item_magic_mode(mode)
    _install_per_item_magic_patch(data)
    off = _item_magic_patch_offsets(data)["mode_table"]
    data[off + item_id] = 1 if mode == "proportional" else 0


def set_item_magic_mode(
    exe_path: Path, item_id: int, mode: str, make_backup: bool = True
) -> None:
    mode = normalize_item_magic_mode(mode)
    data = bytearray(exe_path.read_bytes())
    _set_item_magic_mode_data(data, item_id, mode)
    atomic_write(exe_path, bytes(data), make_backup)
    if load_item_magic_modes(exe_path)[item_id] != mode:
        raise AssertionError("Per-item magic mode verification failed")


def set_item_magic_modes_bulk(
    exe_path: Path, modes: dict[int, str], make_backup: bool = True
) -> None:
    data = bytearray(exe_path.read_bytes())
    for item_id, mode in modes.items():
        _set_item_magic_mode_data(data, int(item_id), normalize_item_magic_mode(mode))
    atomic_write(exe_path, bytes(data), make_backup)
    current = load_item_magic_modes(exe_path)
    for item_id, mode in modes.items():
        if current[int(item_id)] != normalize_item_magic_mode(mode):
            raise AssertionError(f"Per-item magic mode verification failed for item {item_id}")



def install_item_magic_mode_patch(
    exe_path: Path, default_mode: str | None = None, make_backup: bool = True
) -> None:
    data = bytearray(exe_path.read_bytes())
    _install_per_item_magic_patch(data, default_mode)
    atomic_write(exe_path, bytes(data), make_backup)
    if item_magic_scaling_state(exe_path) != "per_item":
        raise AssertionError("Per-item magic patch verification failed")


def restore_item_magic_original(exe_path: Path, make_backup: bool = True) -> None:
    data = bytearray(exe_path.read_bytes())
    state = _item_magic_scaling_state_data(data)
    if state == "unknown":
        raise FormatError(
            "Item-magic code contains unrecognized bytes; refusing to overwrite another ED2MAIN patch"
        )
    if state == "fixed":
        return
    off = _item_magic_patch_offsets(data)
    data[off["calc"]:off["calc"] + len(ITEM_MAGIC_ORIGINAL_CALC_HEAD)] = ITEM_MAGIC_ORIGINAL_CALC_HEAD
    data[
        off["get_item"]:off["get_item"] + len(ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD)
    ] = ITEM_MAGIC_ORIGINAL_GET_ITEM_HEAD
    data[
        off["legacy_cave"]:off["legacy_cave"] + len(ITEM_MAGIC_LEGACY_ORIGINAL_CAVE)
    ] = ITEM_MAGIC_LEGACY_ORIGINAL_CAVE
    region_len = ITEM_MAGIC_CODE_END - ITEM_MAGIC_CODE_START
    data[off["code"]:off["code"] + region_len] = bytes(region_len)
    atomic_write(exe_path, bytes(data), make_backup)
    if item_magic_scaling_state(exe_path) != "fixed":
        raise AssertionError("Original item-magic routine restoration failed")


def patch_item_magic_scaling(exe_path: Path, enable: bool, make_backup: bool = True) -> None:
    """Compatibility wrapper for the v0.9.0 CLI.

    ``on`` installs per-item support with every item proportional; ``off``
    restores the original all-fixed routine.
    """
    if enable:
        data = bytearray(exe_path.read_bytes())
        _install_per_item_magic_patch(data, "proportional")
        off = _item_magic_patch_offsets(data)["mode_table"]
        data[off:off + ITEM_COUNT] = bytes([1] * ITEM_COUNT)
        atomic_write(exe_path, bytes(data), make_backup)
    else:
        restore_item_magic_original(exe_path, make_backup)


def load_debug_symbol_catalog(base_dir: Path) -> dict[str, Any]:
    path = base_dir / "DEBUG_SYMBOLS.json"
    if not path.is_file():
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return raw if isinstance(raw, dict) else {}


# ---------------------------------------------------------------------------
# Scenario shop inventory support
# ---------------------------------------------------------------------------

BUY_SHOP_IMPORT_ORDINAL = 0x0360
SHOP_MAX_VISIBLE_ITEMS = 32

@dataclass
class ShopInventory:
    dll_path: Path
    segment_index: int
    call_offset: int
    structure_offset: int
    list_offset: int
    variant_index: int
    variant_count: int
    capacity: int
    item_codes: list[int]
    merchant_name: str = "상점"
    shared_users: int = 1

    @property
    def key(self) -> str:
        return f"{self.dll_path.name.upper()}:{self.call_offset:04X}:{self.list_offset:04X}"

    @property
    def display_name(self) -> str:
        suffix = f" · 조건 {self.variant_index + 1}/{self.variant_count}" if self.variant_count > 1 else ""
        return f"{self.dll_path.stem} · {self.merchant_name}{suffix}"


def _plausible_shop_list(data: bytes | bytearray, offset: int) -> bool:
    if not 0 <= offset < len(data):
        return False
    count = data[offset]
    if not 1 <= count <= SHOP_MAX_VISIBLE_ITEMS or offset + 1 + count > len(data):
        return False
    codes = data[offset + 1:offset + 1 + count]
    return all(code < ITEM_COUNT or 0x80 <= code < 0x80 + ITEM_COUNT for code in codes)


def _shop_capacity_from_backup(path: Path, segment: NESegment, list_offset: int, current_count: int) -> int:
    backup = path.with_name(path.name + ".bak")
    if not backup.is_file():
        return current_count
    try:
        raw = backup.read_bytes()
        segments = parse_ne_segments(raw)
        if not 1 <= segment.index <= len(segments):
            return current_count
        old_seg = segments[segment.index - 1]
        old = raw[old_seg.file_offset:old_seg.file_offset + old_seg.length]
        if _plausible_shop_list(old, list_offset):
            return max(current_count, int(old[list_offset]))
    except Exception:
        pass
    return current_count


def _decode_speaker_labels(segment_data: bytes, limit: int) -> list[tuple[int, str]]:
    result: list[tuple[int, str]] = []
    pos = 0
    limit = min(limit, len(segment_data))
    while pos < limit:
        start = segment_data.find(b"\x1E", pos, limit)
        if start < 0:
            break
        end = segment_data.find(b"\x04", start + 1, min(limit, start + 48))
        if end < 0:
            pos = start + 1
            continue
        raw = segment_data[start + 1:end]
        try:
            text = raw.decode("cp949").strip()
        except UnicodeDecodeError:
            text = ""
        if text:
            result.append((start, text))
        pos = end + 1
    return result


def _infer_shop_merchant(segment_data: bytes, structure_offset: int, call_offset: int, item_codes: list[int]) -> str:
    normal_ids = [code & 0x7F if code >= 0x80 else code for code in item_codes]
    equipment_ids = set(range(1, 34)) | {53, 54, 55, 59, 60, 61, 62, 63, 65, 67, 68, 69, 74, 75}
    tool_ids = set(range(39, 59)) | {64, 66, 70, 71, 72, 73}
    if normal_ids and all(item_id in equipment_ids for item_id in normal_ids):
        return "무기·방어구 상점"
    if normal_ids and all(item_id in tool_ids for item_id in normal_ids):
        return "도구상"
    labels = _decode_speaker_labels(segment_data, call_offset)
    shop_words = ("무기상", "도구상", "밀매상", "상인", "점원", "가게")
    nearby = [row for row in labels if row[0] <= structure_offset and structure_offset - row[0] <= 0x700]
    for _off, label in reversed(nearby):
        if any(word in label for word in shop_words):
            return label
    return "혼합 상점"


def _recent_register_immediates(data: bytes, store_offset: int, opcode: int, window: int = 40) -> list[int]:
    values: list[int] = []
    start = max(0, store_offset - window)
    for pos in range(start, store_offset):
        if data[pos] == opcode and pos + 3 <= store_offset:
            value = u16(data, pos + 1)
            if _plausible_shop_list(data, value):
                values.append(value)
    return values[-4:]


def _shop_list_candidates(segment_data: bytes, structure_offset: int, scan_start: int, call_offset: int) -> list[int]:
    target = (structure_offset + 6) & 0xFFFF
    candidates: list[int] = []
    # Direct immediate write: mov word ptr [structure+6], list_offset
    for pos in range(max(scan_start, call_offset - 320), call_offset):
        if pos + 6 <= len(segment_data) and segment_data[pos:pos + 2] == b"\xC7\x06" and u16(segment_data, pos + 2) == target:
            value = u16(segment_data, pos + 4)
            if _plausible_shop_list(segment_data, value):
                candidates.append(value)
        # Conditional BX write: mov [structure+6], bx
        if pos + 4 <= len(segment_data) and segment_data[pos:pos + 2] == b"\x89\x1E" and u16(segment_data, pos + 2) == target:
            candidates.extend(_recent_register_immediates(segment_data, pos, 0xBB))
        # Conditional AX write: mov [structure+6], ax
        if pos + 3 <= len(segment_data) and segment_data[pos] == 0xA3 and u16(segment_data, pos + 1) == target:
            candidates.extend(_recent_register_immediates(segment_data, pos, 0xB8))
    if 0 <= structure_offset and structure_offset + 8 <= len(segment_data):
        default = u16(segment_data, structure_offset + 6)
        if _plausible_shop_list(segment_data, default):
            candidates.append(default)
    unique: list[int] = []
    for value in candidates:
        if value not in unique:
            unique.append(value)
    return unique


def load_shops(root: Path, ordinal_names: Optional[dict[int, str]] = None) -> list[ShopInventory]:
    scena = root / "SCENA"
    if not scena.is_dir():
        return []
    if ordinal_names is None:
        ordinal_names = parse_ne_export_ordinals((root / "ED2MAIN.EXE").read_bytes())
    shops: list[ShopInventory] = []
    for path in sorted(scena.glob("T_*.DLL")):
        try:
            raw = path.read_bytes()
            segments = parse_ne_segments(raw)
            refs = [ref for ref in analyze_imported_ordinal_references(path, ordinal_names)
                    if ref.ordinal == BUY_SHOP_IMPORT_ORDINAL]
        except Exception:
            continue
        refs.sort(key=lambda ref: (ref.segment_index, ref.instruction_offset))
        previous_by_segment: dict[int, int] = {}
        for ref in refs:
            if not 1 <= ref.segment_index <= len(segments):
                continue
            segment = segments[ref.segment_index - 1]
            data = raw[segment.file_offset:segment.file_offset + segment.length]
            call = ref.instruction_offset
            if call < 3 or data[call - 3] != 0xBB:
                continue
            structure = u16(data, call - 2)
            if structure + 8 > len(data):
                continue
            scan_start = previous_by_segment.get(ref.segment_index, max(0, call - 320))
            previous_by_segment[ref.segment_index] = call + 5
            pointers = _shop_list_candidates(data, structure, scan_start, call)
            if not pointers:
                continue
            for variant_index, list_offset in enumerate(pointers):
                count = int(data[list_offset])
                item_codes = list(data[list_offset + 1:list_offset + 1 + count])
                capacity = _shop_capacity_from_backup(path, segment, list_offset, count)
                shops.append(ShopInventory(
                    path, ref.segment_index, call, structure, list_offset,
                    variant_index, len(pointers), capacity, item_codes,
                    _infer_shop_merchant(data, structure, call, item_codes), 1,
                ))
    usage: dict[tuple[Path, int, int], int] = {}
    for shop in shops:
        key = (shop.dll_path, shop.segment_index, shop.list_offset)
        usage[key] = usage.get(key, 0) + 1
    for shop in shops:
        shop.shared_users = usage[(shop.dll_path, shop.segment_index, shop.list_offset)]
    return shops


def shop_item_label(code: int, items: list[ItemRecord]) -> str:
    if 0 <= code < len(items):
        return f"{code:03d} {items[code].name}"
    if 0x80 <= code < 0x80 + len(items):
        base = code - 0x80
        return f"0x{code:02X} 특수·랜덤 {items[base].name} (기본 ID {base})"
    return f"0x{code:02X} [특수 상품 코드]"


def patch_shop_inventory(shop: ShopInventory, item_codes: Iterable[int], make_backup: bool = True) -> None:
    values = [int(value) for value in item_codes]
    if len(values) > shop.capacity:
        raise ValueError(f"이 상점은 원본 공간상 최대 {shop.capacity}개 상품까지만 저장할 수 있습니다.")
    invalid = [value for value in values if not (0 <= value < ITEM_COUNT or 0x80 <= value < 0x80 + ITEM_COUNT)]
    if invalid:
        joined = ", ".join(f"0x{value:02X}" for value in invalid)
        raise ValueError(f"유효하지 않은 상품 코드입니다: {joined}. 일반 ID 0..75 또는 특수 코드 0x80..0xCB만 사용할 수 있습니다.")
    raw = bytearray(shop.dll_path.read_bytes())
    segments = parse_ne_segments(raw)
    if not 1 <= shop.segment_index <= len(segments):
        raise FormatError("상점 세그먼트가 변경되었습니다.")
    segment = segments[shop.segment_index - 1]
    start = segment.file_offset + shop.list_offset
    if start + 1 + shop.capacity > len(raw):
        raise FormatError("상점 목록이 DLL 범위를 벗어났습니다.")
    raw[start] = len(values)
    raw[start + 1:start + 1 + shop.capacity] = bytes(values + [0] * (shop.capacity - len(values)))
    atomic_write(shop.dll_path, bytes(raw), make_backup)


def parse_shop_item_codes(text: str) -> list[int]:
    normalized = text.replace(",", " ").replace(";", " ").replace("/", " ")
    tokens = [token for token in normalized.split() if token]
    if not tokens:
        raise ValueError("상점에는 최소 1개의 상품이 필요합니다.")
    values = [parse_number(token, 0, 255, "상품 코드") for token in tokens]
    invalid = [value for value in values if not (0 <= value < ITEM_COUNT or 0x80 <= value < 0x80 + ITEM_COUNT)]
    if invalid:
        joined = ", ".join(f"0x{value:02X}" for value in invalid)
        raise ValueError(f"유효하지 않은 상품 코드입니다: {joined}. 일반 ID 0..75 또는 특수 코드 0x80..0xCB만 사용할 수 있습니다.")
    return values


# ---------------------------------------------------------------------------
# Appearance/resource support
# ---------------------------------------------------------------------------

@dataclass
class AppearanceAsset:
    asset_id: int
    path: Path
    size: int
    header_size_minus_one: int
    header_valid: bool
    users: list[str]


def parse_appearance_id(path: Path) -> int:
    stem = path.stem.upper()
    if not stem.startswith("C_MO"):
        return -1
    try:
        return int(stem[4:], 16)
    except ValueError:
        return -1


def validate_bzh(data: bytes) -> tuple[bool, str]:
    if len(data) < 3:
        return False, "File is too small"
    declared = u16(data, 0)
    if declared != len(data) - 1:
        return False, f"Header says {declared + 1} bytes, actual size is {len(data)}"
    return True, "Size header is valid"


def load_appearance_assets(root: Path, groups: Iterable[MonsterGroup]) -> list[AppearanceAsset]:
    users: dict[int, list[str]] = {}
    for g in groups:
        for idx, asset_id in enumerate((g.graphic_id0, g.graphic_id1)):
            if asset_id != 0xFFFF:
                users.setdefault(asset_id, []).append(f"M_{g.dll_number:03X} slot{idx}")
    result = []
    for path in sorted((root / "MON").glob("C_MO*.BZH")):
        asset_id = parse_appearance_id(path)
        data = path.read_bytes()
        declared = u16(data, 0) if len(data) >= 2 else -1
        valid, _ = validate_bzh(data)
        result.append(AppearanceAsset(asset_id, path, len(data), declared, valid, users.get(asset_id, [])))
    return result


def replace_bzh(target: Path, source: Path, make_backup: bool = True) -> None:
    data = source.read_bytes()
    valid, reason = validate_bzh(data)
    if not valid:
        raise FormatError(f"Replacement BZH failed validation: {reason}")
    atomic_write(target, data, make_backup)


# ---------------------------------------------------------------------------
# ED2MAIN player initial equipment (PL_DATA_1 .. PL_DATA_4)
# ---------------------------------------------------------------------------

PLAYER_DATA_EXPORTS = (
    (0, "아트라스", "PL_DATA_1"),
    (1, "란도", "PL_DATA_2"),
    (2, "플로라", "PL_DATA_3"),
    (3, "신디", "PL_DATA_4"),
)
PLAYER_RECORD_SIZE = 0x40
PLAYER_EQUIPMENT_OFFSETS = {
    "weapon": 0x19,
    "armor": 0x1A,
    "shield": 0x1B,
    "ring": 0x1C,
}
PLAYER_EQUIPMENT_LABELS = {
    "weapon": "무기",
    "armor": "갑옷",
    "shield": "방패",
    "ring": "반지·부적",
}
PLAYER_EQUIPMENT_TYPE_BITS = {
    "weapon": 0x01,
    "armor": 0x02,
    "shield": 0x04,
    "ring": 0x08,
}


@dataclass
class PlayerInitialEquipment:
    index: int
    name: str
    export_name: str
    segment: int
    segment_offset: int
    file_offset: int
    weapon_id: int
    armor_id: int
    shield_id: int
    ring_id: int

    def item_id(self, slot: str) -> int:
        return int(getattr(self, f"{slot}_id"))

    def equipment_dict(self) -> dict[str, int]:
        return {slot: self.item_id(slot) for slot in PLAYER_EQUIPMENT_OFFSETS}


def load_player_initial_equipment(exe_path: Path) -> list[PlayerInitialEquipment]:
    data = exe_path.read_bytes()
    exports = parse_ne_exports(data)
    result: list[PlayerInitialEquipment] = []
    for index, name, export_name in PLAYER_DATA_EXPORTS:
        address = exports.get(export_name)
        if address is None:
            raise FormatError(f"ED2MAIN.EXE export {export_name} is missing")
        segment, segment_offset = address
        file_offset = ne_address_to_file(data, segment, segment_offset)
        if file_offset + PLAYER_RECORD_SIZE > len(data):
            raise FormatError(f"{export_name} player record is truncated")
        values = {
            slot: data[file_offset + delta]
            for slot, delta in PLAYER_EQUIPMENT_OFFSETS.items()
        }
        result.append(PlayerInitialEquipment(
            index=index,
            name=name,
            export_name=export_name,
            segment=segment,
            segment_offset=segment_offset,
            file_offset=file_offset,
            weapon_id=values["weapon"],
            armor_id=values["armor"],
            shield_id=values["shield"],
            ring_id=values["ring"],
        ))
    return result


def equipment_item_allowed(item: ItemRecord, slot: str) -> bool:
    if item.item_id == 0:
        return True
    return bool(item.type_mask & PLAYER_EQUIPMENT_TYPE_BITS[slot])


def patch_player_initial_equipment(
    exe_path: Path,
    changes: dict[int, dict[str, int]],
    make_backup: bool = True,
) -> int:
    raw = exe_path.read_bytes()
    data = bytearray(raw)
    exports = parse_ne_exports(raw)
    items = load_items(exe_path)
    by_id = {item.item_id: item for item in items}
    changed = 0
    for index, _name, export_name in PLAYER_DATA_EXPORTS:
        values = changes.get(index)
        if values is None:
            continue
        address = exports.get(export_name)
        if address is None:
            raise FormatError(f"ED2MAIN.EXE export {export_name} is missing")
        base = ne_address_to_file(raw, *address)
        for slot, delta in PLAYER_EQUIPMENT_OFFSETS.items():
            if slot not in values:
                continue
            item_id = int(values[slot])
            item = by_id.get(item_id)
            if item is None:
                raise ValueError(f"{export_name} {PLAYER_EQUIPMENT_LABELS[slot]}: item ID {item_id} is outside 0..{ITEM_COUNT - 1}")
            if not equipment_item_allowed(item, slot):
                raise ValueError(
                    f"{export_name} {PLAYER_EQUIPMENT_LABELS[slot]}: {item_id} {item.name}은(는) 이 슬롯에 장비할 수 없습니다."
                )
            pos = base + delta
            if data[pos] != item_id:
                data[pos] = item_id
                changed += 1
    if changed:
        atomic_write(exe_path, bytes(data), make_backup)
    return changed

# ---------------------------------------------------------------------------
# Project model, validation, CSV
# ---------------------------------------------------------------------------

class Project:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.exe = self.root / "ED2MAIN.EXE"
        self.mon_dir = self.root / "MON"
        self.scena_dir = self.root / "SCENA"
        self.validate_root()
        self.monsters: list[MonsterRecord] = []
        self.groups: list[MonsterGroup] = []
        self.items: list[ItemRecord] = []
        self.player_equipment: list[PlayerInitialEquipment] = []
        self.event_items: list[EventItemRecord] = []
        self.magics: list[MagicRecord] = []
        self.shops: list[ShopInventory] = []
        self.assets: list[AppearanceAsset] = []
        self.special_rules: list[SpecialRule] = []
        self.ordinal_names: dict[int, str] = {}
        self.import_refs_by_dll: dict[str, list[ImportedOrdinalReference]] = {}
        self.item_magic_scaling = "unknown"
        self.experience_rules = ExperienceRuleState(False, False, False, False, False, "not loaded")
        self.gold_reward_rules = GoldRewardRuleState(False, False, False, "not loaded")
        self.debug_catalog = load_debug_symbol_catalog(Path(__file__).resolve().parent)
        self.reload()

    def validate_root(self) -> None:
        if not self.exe.is_file() or not self.mon_dir.is_dir():
            raise FormatError("Select the ED2 game folder containing ED2MAIN.EXE and MON")

    def reload(self) -> None:
        monsters: list[MonsterRecord] = []
        groups: list[MonsterGroup] = []
        for path in sorted(self.mon_dir.glob("M_*.DLL")):
            try:
                records = load_monsters(path)
                group = load_group(path)
            except Exception:
                continue
            monsters.extend(records)
            groups.append(group)
        self.monsters = monsters
        self.groups = groups
        self.ordinal_names = parse_ne_export_ordinals(self.exe.read_bytes())
        self.import_refs_by_dll = {}
        ordinal_frequency: dict[int, int] = {}
        for group in self.groups:
            try:
                refs = analyze_imported_ordinal_references(group.dll_path, self.ordinal_names)
            except Exception:
                refs = []
            self.import_refs_by_dll[group.dll_path.name.upper()] = refs
            for ordinal in {ref.ordinal for ref in refs}:
                ordinal_frequency[ordinal] = ordinal_frequency.get(ordinal, 0) + 1
        self.special_rules = []
        for group in self.groups:
            refs = self.import_refs_by_dll.get(group.dll_path.name.upper(), [])
            group.special_rules = build_special_rules(group, refs, ordinal_frequency, len(self.groups))
            self.special_rules.extend(group.special_rules)
        self.items = load_items(self.exe)
        self.player_equipment = load_player_initial_equipment(self.exe)
        self.item_magic_scaling = item_magic_scaling_state(self.exe)
        item_modes = load_item_magic_modes(self.exe)
        for item, mode in zip(self.items, item_modes):
            item.magic_mode = mode
        self.event_items = load_event_items(self.exe)
        self.magics = load_magics(self.exe)
        self.shops = load_shops(self.root, self.ordinal_names)
        self.experience_rules = load_experience_rules(self.exe)
        self.gold_reward_rules = load_gold_reward_rules(self.exe)
        self.assets = load_appearance_assets(self.root, self.groups)

    def equipment_item_options(self, slot: str) -> list[ItemRecord]:
        if slot not in PLAYER_EQUIPMENT_TYPE_BITS:
            raise KeyError(slot)
        return [item for item in self.items if equipment_item_allowed(item, slot)]

    def save_player_initial_equipment(self, changes: dict[int, dict[str, int]]) -> int:
        changed = patch_player_initial_equipment(self.exe, changes, True)
        self.reload()
        return changed

    def export_player_equipment_csv(self, path: Path) -> None:
        fields = ["character", "export", "weapon_id", "weapon", "armor_id", "armor", "shield_id", "shield", "ring_id", "ring"]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for rec in self.player_equipment:
                writer.writerow({
                    "character": rec.name, "export": rec.export_name,
                    "weapon_id": rec.weapon_id, "weapon": self.item_display(rec.weapon_id),
                    "armor_id": rec.armor_id, "armor": self.item_display(rec.armor_id),
                    "shield_id": rec.shield_id, "shield": self.item_display(rec.shield_id),
                    "ring_id": rec.ring_id, "ring": self.item_display(rec.ring_id),
                })

    def import_player_equipment_csv(self, path: Path) -> int:
        """Import PL_DATA_1~4 equipment from a CSV exported by Mod Studio.

        Rows may be ordered arbitrarily, but each of the four player exports must
        appear exactly once. Item names are informational; numeric *_id fields are
        authoritative and are validated against the live ITEM_TYPE slot bits.
        """
        with path.open("r", newline="", encoding="utf-8-sig") as fp:
            rows = list(csv.DictReader(fp))
        by_export = {export_name: (index, name) for index, name, export_name in PLAYER_DATA_EXPORTS}
        changes: dict[int, dict[str, int]] = {}
        seen: set[str] = set()
        for row_num, row in enumerate(rows, start=2):
            export_name = str(row.get("export", "")).strip()
            char_name = str(row.get("character", "")).strip()
            if export_name not in by_export:
                raise ValueError(f"row {row_num}: 지원하지 않는 플레이어 export: {export_name!r}")
            if export_name in seen:
                raise ValueError(f"row {row_num}: 중복 플레이어 export: {export_name}")
            index, expected_name = by_export[export_name]
            if char_name and char_name != expected_name:
                raise ValueError(f"row {row_num}: {export_name} 캐릭터명은 {expected_name!r}이어야 합니다.")
            vals: dict[str, int] = {}
            for slot in PLAYER_EQUIPMENT_OFFSETS:
                key = f"{slot}_id"
                vals[slot] = csv_int(str(row.get(key, "")).strip(), 0, ITEM_COUNT - 1, f"row {row_num} {key}")
                item = self.items[vals[slot]]
                if not equipment_item_allowed(item, slot):
                    raise ValueError(
                        f"row {row_num}: {expected_name} {PLAYER_EQUIPMENT_LABELS[slot]}에 "
                        f"{item.item_id} {item.name}을(를) 장비할 수 없습니다."
                    )
            changes[index] = vals
            seen.add(export_name)
        missing = [e for _i, _n, e in PLAYER_DATA_EXPORTS if e not in seen]
        if missing:
            raise ValueError("초기 장비 CSV에 4명 전부가 필요합니다. 누락: " + ", ".join(missing))
        changed = patch_player_initial_equipment(self.exe, changes, True)
        self.reload()
        return changed

    def item_display(self, item_id: int) -> str:
        if 0 <= item_id < len(self.items):
            return f"{item_id:03d} {self.items[item_id].name}"
        if EVENT_ITEM_ID_BASE <= item_id < EVENT_ITEM_ID_BASE + len(self.event_items):
            item = self.event_items[item_id - EVENT_ITEM_ID_BASE]
            return f"{item_id:03d} {item.name} [event]"
        return f"{item_id:03d} [unknown ID]"

    def debug_info(self, dll_name: str) -> dict[str, Any]:
        return dict(self.debug_catalog.get(dll_name.upper(), {}))

    def group_by_path(self, path: Path) -> MonsterGroup:
        for group in self.groups:
            if group.dll_path == path:
                return group
        raise KeyError(path)

    def import_monsters_csv(self, path: Path) -> int:
        with path.open("r", newline="", encoding="utf-8-sig") as fp:
            rows = list(csv.DictReader(fp))
        index = {(r.dll_path.name.upper(), r.slot): r for r in self.monsters}
        prepared: dict[Path, bytearray] = {}
        changed = 0
        for row_num, row in enumerate(rows, start=2):
            key = (str(row.get("dll", "")).upper(), csv_int(row.get("slot", ""), 0, 3, f"row {row_num} slot"))
            rec = index.get(key)
            if rec is None:
                raise ValueError(f"row {row_num}: monster {key[0]} slot {key[1]} was not found")
            data = prepared.setdefault(rec.dll_path, bytearray(rec.dll_path.read_bytes()))
            base = rec.file_offset
            preserve_monster_record_quirks(rec.dll_path, rec.slot, data, base)
            csv_name = str(row.get("name", "")).strip()
            if csv_name and (csv_name != rec.name or _is_kajasm_record(rec.dll_path, rec.slot, data, base)):
                data[base + 48:base + 64] = encode_monster_name(csv_name, rec.dll_path, rec.slot, data, base)
            mapping = {
                "level": ("level", 0, 255), "hp": ("hp", 1, 65535), "attack": ("attack", 0, 65535),
                "exp_raw": ("exp", 0, 65535), "gold_raw": ("gold", 0, 65535),
                "defense": ("defense", 0, 65535), "magic": ("magic", 0, 65535),
                "speed": ("speed", 0, 255), "luck": ("luck", 0, 255),
            }
            for column, (field, minimum, maximum) in mapping.items():
                text = str(row.get(column, "")).strip()
                if not text: continue
                value = csv_int(text, minimum, maximum, f"row {row_num} {column}")
                off, size, _ = MONSTER_FIELDS[field]
                if field == "hp": p16(data, base + 4, value); p16(data, base + 6, value)
                elif size == 1: data[base + off] = value
                else: p16(data, base + off, value)
            if not is_monster_record(bytes(data[base:base + 64])):
                raise ValueError(f"row {row_num}: edited monster failed validation")
            changed += 1
        for target, data in prepared.items():
            seg, count = find_monster_table(bytes(data))
            records = [
                MonsterRecord(target, dll_number(target), slot, seg.file_offset + slot * 64, seg.file_offset,
                              bytes(data[seg.file_offset + slot * 64:seg.file_offset + (slot + 1) * 64]))
                for slot in range(count)
            ]
            bgm_id = data[seg.file_offset + 0x11A]
            for reward_key in ("exp", "gold"):
                proposed = {record.slot: record.value(reward_key) for record in records}
                adjusted, _ = fit_group_reward_raws(records, reward_key, proposed, dll_number(target), bgm_id)
                off, _size, _label = MONSTER_FIELDS[reward_key]
                for record in records:
                    p16(data, record.file_offset + off, adjusted[record.slot])
            atomic_write(target, bytes(data), True)
        self.reload()
        return changed

    def import_groups_csv(self, path: Path) -> int:
        with path.open("r", newline="", encoding="utf-8-sig") as fp:
            rows = list(csv.DictReader(fp))
        index = {g.dll_path.name.upper(): g for g in self.groups}
        prepared: dict[Path, bytearray] = {}
        changed = 0
        columns = {
            "graphic_id0_hex": (0x100, 2, 0xFFFF), "graphic_addr0_hex": (0x102, 2, 0xFFFF),
            "graphic_id1_hex": (0x104, 2, 0xFFFF), "graphic_addr1_hex": (0x106, 2, 0xFFFF),
            "drop_item_id": (0x118, 1, 255), "drop_chance": (0x119, 1, 100), "bgm_id": (0x11A, 1, 255),
        }
        known_assets = {a.asset_id for a in self.assets}
        for row_num, row in enumerate(rows, start=2):
            name = str(row.get("dll", "")).upper()
            group = index.get(name)
            if group is None: raise ValueError(f"row {row_num}: group {name} was not found")
            data = prepared.setdefault(group.dll_path, bytearray(group.dll_path.read_bytes()))
            for column, (delta, size, maximum) in columns.items():
                text = str(row.get(column, "")).strip()
                if not text: continue
                value = csv_int(text, 0, maximum, f"row {row_num} {column}")
                if column in ("graphic_id0_hex", "graphic_id1_hex") and value != 0xFFFF and value not in known_assets:
                    raise ValueError(f"row {row_num}: C_MO{value:03X}.BZH does not exist")
                if size == 1: data[group.segment_offset + delta] = value
                else: p16(data, group.segment_offset + delta, value)
            changed += 1
        for target, data in prepared.items(): atomic_write(target, bytes(data), True)
        self.reload()
        return changed

    def import_shops_csv(self, path: Path) -> int:
        with path.open("r", newline="", encoding="utf-8-sig") as fp:
            rows = list(csv.DictReader(fp))
        index = {
            (shop.dll_path.name.upper(), shop.call_offset, shop.list_offset): shop
            for shop in self.shops
        }
        prepared: dict[Path, bytearray] = {}
        pending: dict[tuple[Path, int, int], list[int]] = {}
        changed = 0
        for row_num, row in enumerate(rows, start=2):
            dll_name = str(row.get("dll", "")).strip().upper()
            call_offset = csv_int(row.get("call_offset_hex", ""), 0, 0xFFFF, f"row {row_num} call_offset_hex")
            list_offset = csv_int(row.get("list_offset_hex", ""), 0, 0xFFFF, f"row {row_num} list_offset_hex")
            shop = index.get((dll_name, call_offset, list_offset))
            if shop is None:
                raise ValueError(
                    f"row {row_num}: shop {dll_name} call 0x{call_offset:04X} list 0x{list_offset:04X} was not found"
                )
            values = parse_shop_item_codes(str(row.get("item_codes", "")))
            if len(values) > shop.capacity:
                raise ValueError(f"row {row_num}: 최대 상품 수는 {shop.capacity}개입니다.")
            key = (shop.dll_path, shop.segment_index, shop.list_offset)
            previous = pending.get(key)
            if previous is not None and previous != values:
                raise ValueError(f"row {row_num}: 공유 상품 목록에 서로 다른 값이 지정되었습니다.")
            pending[key] = values
            changed += 1
        for (target, segment_index, list_offset), values in pending.items():
            data = prepared.setdefault(target, bytearray(target.read_bytes()))
            segments = parse_ne_segments(data)
            segment = segments[segment_index - 1]
            matching = next(
                shop for shop in self.shops
                if shop.dll_path == target and shop.segment_index == segment_index and shop.list_offset == list_offset
            )
            start = segment.file_offset + list_offset
            data[start] = len(values)
            data[start + 1:start + 1 + matching.capacity] = bytes(values + [0] * (matching.capacity - len(values)))
        for target, data in prepared.items():
            atomic_write(target, bytes(data), True)
        self.reload()
        return changed

    def import_items_csv(self, path: Path) -> int:
        with path.open("r", newline="", encoding="utf-8-sig") as fp:
            rows = list(csv.DictReader(fp))
        data = bytearray(self.exe.read_bytes())
        verify_item_table(data)

        # v0.12.8 always writes proportional ITEM_MAGIC_NUM in 5%-per-raw units.
        # If the executable still uses the older 10%-per-raw selector, migrate it
        # before importing row values so row order cannot produce mixed units.
        if _item_magic_scaling_state_data(data) == "per_item_x10":
            _install_per_item_magic_patch(data)

        current_modes = _read_item_magic_modes_data(data)
        seen: set[int] = set()
        for row_num, row in enumerate(rows, start=2):
            item_id = csv_int(row.get("item_id", ""), 0, ITEM_COUNT - 1, f"row {row_num} item_id")
            if item_id in seen: raise ValueError(f"row {row_num}: duplicate item ID {item_id}")
            seen.add(item_id)
            off = ITEM_NAME_BASE + item_id * ITEM_STRIDE
            name = str(row.get("name", "")).strip()
            if name: data[off:off + 14] = encode_item_name(name)
            price_text = str(row.get("price", "")).strip()
            if price_text:
                mantissa, exponent = encode_price(csv_int(price_text, 0, 10**12, f"row {row_num} price"))
                data[off + 14], data[off + 15] = mantissa, exponent
            group_text, effect_text = str(row.get("stat_group", "")).strip(), str(row.get("effect_id", "")).strip()
            stat_group = (data[off + 16] >> 5) if not group_text else csv_int(group_text, 0, 7, f"row {row_num} stat_group")
            effect_id = (data[off + 16] & 0x1F) if not effect_text else csv_int(effect_text, 0, 31, f"row {row_num} effect_id")
            data[off + 16] = (stat_group << 5) | effect_id

            power_text = str(row.get("power_raw", "")).strip()
            if power_text:
                data[off + 17] = csv_int(power_text, 0, 255, f"row {row_num} power_raw")

            mode_text = str(row.get("magic_mode", "")).strip()
            desired_mode = normalize_item_magic_mode(mode_text) if mode_text else current_modes[item_id]

            secondary_text = str(row.get("secondary_raw", "")).strip()
            secondary_effective_text = str(row.get("secondary_effective", "")).strip()
            if secondary_text:
                raw_value = csv_int(secondary_text, 0, 255, f"row {row_num} secondary_raw")
                if desired_mode == "proportional" and secondary_effective_text:
                    effective = csv_int(secondary_effective_text, 0, 1275, f"row {row_num} secondary_effective")
                    if effective % 5:
                        raise ValueError(
                            f"row {row_num}: proportional secondary_effective must be a multiple of 5%"
                        )
                    if raw_value * 5 == effective:
                        pass  # current v0.12.8+ CSV
                    elif raw_value * 10 == effective:
                        raw_value *= 2  # legacy x10 CSV; preserve effective percent
                    else:
                        raise ValueError(
                            f"row {row_num}: secondary_raw={raw_value} conflicts with "
                            f"secondary_effective={effective}%"
                        )
                    if raw_value > 255:
                        raise ValueError(f"row {row_num}: migrated secondary_raw exceeds 255")
                data[off + 18] = raw_value

            mask_text = str(row.get("type_mask_hex", "")).strip()
            if mask_text: data[off + 19] = csv_int(mask_text, 0, 255, f"row {row_num} type_mask")
            if mode_text:
                _set_item_magic_mode_data(data, item_id, desired_mode)
                current_modes[item_id] = desired_mode
        atomic_write(self.exe, bytes(data), True)
        self.reload()
        return len(seen)

    @property
    def baseline_dir(self) -> Path:
        return self.root / BASELINE_DIR_NAME

    @property
    def baseline_exists(self) -> bool:
        return (self.baseline_dir / "ED2MAIN.EXE").is_file() and (self.baseline_dir / "MON").is_dir()

    def create_baseline(self, overwrite: bool = False) -> Path:
        target = self.baseline_dir
        if target.exists():
            if not overwrite:
                raise FileExistsError("기준점이 이미 있습니다. 덮어쓰기를 선택해야 다시 만들 수 있습니다.")
            shutil.rmtree(target)
        temp = Path(tempfile.mkdtemp(prefix=BASELINE_DIR_NAME + ".tmp.", dir=str(self.root)))
        try:
            (temp / "MON").mkdir(parents=True, exist_ok=True)
            (temp / "SCENA").mkdir(parents=True, exist_ok=True)
            shutil.copy2(self.exe, temp / "ED2MAIN.EXE")
            files = [self.exe]
            for source in sorted(self.mon_dir.glob("M_*.DLL")):
                shutil.copy2(source, temp / "MON" / source.name)
                files.append(source)
            if self.scena_dir.is_dir():
                for source in sorted(self.scena_dir.glob("T_*.DLL")):
                    shutil.copy2(source, temp / "SCENA" / source.name)
                    files.append(source)
            manifest = {
                "format": "ED2 Mod Studio baseline",
                "version": 1,
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "tool_version": VERSION,
                "files": {
                    str(path.relative_to(self.root)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in files
                },
            }
            (temp / BASELINE_MANIFEST_NAME).write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            os.replace(temp, target)
        except Exception:
            shutil.rmtree(temp, ignore_errors=True)
            raise
        return target

    def restore_baseline(self) -> int:
        """Safely revert only Mod Studio-owned bytes.

        A whole-file baseline copy is still retained for comparison and manual
        disaster recovery, but copying it over live files could erase text,
        ending, opening, or dialogue patches applied later.
        """
        candidates = [self.exe]
        candidates.extend(sorted(self.mon_dir.glob("M_*.DLL")))
        if self.scena_dir.is_dir():
            candidates.extend(sorted(self.scena_dir.glob("T_*.DLL")))
        restored = 0
        missing = 0
        for target in candidates:
            try:
                changed = selective_restore(target, MOD_STUDIO_JOURNAL_COMPONENT)
            except FileNotFoundError:
                missing += 1
                continue
            restored += 1 if changed >= 0 else 0
        if restored == 0:
            raise FileNotFoundError(
                "선택적으로 복원할 Mod Studio 변경 기록이 없습니다. "
                "다른 패치를 지우지 않기 위해 저장된 기준점 전체 파일은 자동으로 덮어쓰지 않습니다."
            )
        self.reload()
        return restored

    def _copy_comparison_root(self, target: Path) -> str:
        (target / "MON").mkdir(parents=True, exist_ok=True)
        (target / "SCENA").mkdir(parents=True, exist_ok=True)
        if self.baseline_exists:
            shutil.copy2(self.baseline_dir / "ED2MAIN.EXE", target / "ED2MAIN.EXE")
            for source in (self.baseline_dir / "MON").glob("M_*.DLL"):
                shutil.copy2(source, target / "MON" / source.name)
            for source in (self.baseline_dir / "SCENA").glob("T_*.DLL"):
                shutil.copy2(source, target / "SCENA" / source.name)
            return "저장된 기준점"
        exe_source = self.exe.with_name(self.exe.name + ".bak")
        shutil.copy2(exe_source if exe_source.is_file() else self.exe, target / "ED2MAIN.EXE")
        used_backup = exe_source.is_file()
        for source in sorted(self.mon_dir.glob("M_*.DLL")):
            backup = source.with_name(source.name + ".bak")
            shutil.copy2(backup if backup.is_file() else source, target / "MON" / source.name)
            used_backup = used_backup or backup.is_file()
        if self.scena_dir.is_dir():
            for source in sorted(self.scena_dir.glob("T_*.DLL")):
                backup = source.with_name(source.name + ".bak")
                shutil.copy2(backup if backup.is_file() else source, target / "SCENA" / source.name)
                used_backup = used_backup or backup.is_file()
        return ".bak 원본과 현재 파일 혼합" if used_backup else "현재 상태(기준점 없음)"

    def modification_rows(self) -> tuple[str, list[ModificationRow]]:
        rows: list[ModificationRow] = []
        has_backup = (
            self.exe.with_name(self.exe.name + ".bak").is_file()
            or any(path.with_name(path.name + ".bak").is_file() for path in self.mon_dir.glob("M_*.DLL"))
            or any(path.with_name(path.name + ".bak").is_file() for path in self.scena_dir.glob("T_*.DLL"))
        )
        if not self.baseline_exists and not has_backup:
            return "기준점 없음", rows
        with tempfile.TemporaryDirectory(prefix="ed2_mod_compare_") as temp_name:
            temp_root = Path(temp_name)
            source_label = self._copy_comparison_root(temp_root)
            original = Project(temp_root)

            def add(file: str, category: str, target: str, field_name: str, before: Any, after: Any) -> None:
                if before != after:
                    rows.append(ModificationRow(file, category, target, field_name, str(before), str(after)))

            original_monsters = {(rec.dll_path.name.upper(), rec.slot): rec for rec in original.monsters}
            for rec in self.monsters:
                before = original_monsters.get((rec.dll_path.name.upper(), rec.slot))
                if before is None:
                    continue
                target = f"slot {rec.slot} {rec.name}"
                add(rec.dll_path.name, "몬스터", target, "name", before.name, rec.name)
                for key in MONSTER_FIELDS:
                    add(rec.dll_path.name, "몬스터", target, key, before.value(key), rec.value(key))

            original_groups = {g.dll_path.name.upper(): g for g in original.groups}
            for group in self.groups:
                before = original_groups.get(group.dll_path.name.upper())
                if before is None:
                    continue
                target = " / ".join(group.monster_names)
                for field_name in (
                    "graphic_id0", "graphic_addr0", "graphic_id1", "graphic_addr1",
                    "drop_item_id", "drop_chance", "bgm_id",
                ):
                    add(group.dll_path.name, "전투 그룹", target, field_name,
                        getattr(before, field_name), getattr(group, field_name))
                before_writes = {(r.segment_index, r.instruction_offset): r for r in before.dynamic_drop_writes}
                for ref in group.dynamic_drop_writes:
                    old = before_writes.get((ref.segment_index, ref.instruction_offset))
                    if old is not None:
                        add(group.dll_path.name, "AI 드롭", ref.location, "runtime_drop_chance", old.value, ref.value)
                before_conditions = {(c.segment_index, c.instruction_offset): c for c in before.ai_conditions}
                for condition in group.ai_conditions:
                    old = before_conditions.get((condition.segment_index, condition.instruction_offset))
                    if old is not None:
                        add(group.dll_path.name, "AI 조건", condition.location, "hp_threshold_raw",
                            f"0x{old.threshold_raw:02X} ({old.threshold_percent:.1f}%)",
                            f"0x{condition.threshold_raw:02X} ({condition.threshold_percent:.1f}%)")

            original_shops = {
                (shop.dll_path.name.upper(), shop.call_offset, shop.list_offset): shop
                for shop in original.shops
            }
            for shop in self.shops:
                before = original_shops.get((shop.dll_path.name.upper(), shop.call_offset, shop.list_offset))
                if before is not None:
                    add(
                        shop.dll_path.name, "상점", shop.display_name, "item_codes",
                        " ".join(f"0x{value:02X}" for value in before.item_codes),
                        " ".join(f"0x{value:02X}" for value in shop.item_codes),
                    )

            for before, item in zip(original.items, self.items):
                target = f"{item.item_id:03d} {item.name}"
                for field_name in ("name", "price", "stat_group", "effect_id", "power_raw", "secondary_raw", "type_mask", "magic_mode"):
                    add("ED2MAIN.EXE", "아이템", target, field_name, getattr(before, field_name), getattr(item, field_name))
            original_players = {rec.index: rec for rec in original.player_equipment}
            for rec in self.player_equipment:
                before = original_players.get(rec.index)
                if before is None:
                    continue
                for slot, label in PLAYER_EQUIPMENT_LABELS.items():
                    add(
                        "ED2MAIN.EXE", "초기 장비", rec.name, label,
                        original.item_display(before.item_id(slot)),
                        self.item_display(rec.item_id(slot)),
                    )

            for before, magic in zip(original.magics, self.magics):
                target = f"{magic.magic_id:02d} {magic.name}"
                for field_name in ("name", "cost", "select_flags", "packed_select_multiplier", "count_raw"):
                    add("ED2MAIN.EXE", "주문", target, field_name, getattr(before, field_name), getattr(magic, field_name))
            for field_name, label in (
                ("include_incapacitated", "기절자 경험치 포함"),
                ("no_party_split", "파티원 수 분배 해제"),
                ("no_general_90_percent", "일반전투 90% 보정 제거"),
                ("no_level_penalty", "레벨 차이 감소 제거"),
            ):
                add("ED2MAIN.EXE", "경험치", "전투 종료 보상", label,
                    getattr(original.experience_rules, field_name), getattr(self.experience_rules, field_name))
            add("ED2MAIN.EXE", "Gold", "전투 종료 보상", "일반전투 Gold 90% 보정 제거",
                original.gold_reward_rules.no_general_90_percent, self.gold_reward_rules.no_general_90_percent)
            add("ED2MAIN.EXE", "Gold", "전투 종료 보상", "Gold 레벨 스케일링 제거",
                original.gold_reward_rules.no_level_scaling, self.gold_reward_rules.no_level_scaling)
        return source_label, rows

    def preview_builtin_preset(self, name: str) -> list[ModificationRow]:
        rows: list[ModificationRow] = []
        if name == "드롭률 2배":
            for group in self.groups:
                if group.drop_chance > 0:
                    new = min(100, group.drop_chance * 2)
                    if new != group.drop_chance:
                        rows.append(ModificationRow(group.dll_path.name, "전투 그룹", group.label, "초기 드롭률", f"{group.drop_chance}%", f"{new}%"))
                for ref in group.dynamic_drop_writes:
                    if ref.value and ref.value > 0:
                        new = min(100, ref.value * 2)
                        if new != ref.value:
                            rows.append(ModificationRow(group.dll_path.name, "AI 드롭", ref.location, "AI 드롭률", f"{ref.value}%", f"{new}%"))
        elif name == "희귀 드롭 최소 5%":
            for group in self.groups:
                if 0 < group.drop_chance < 5:
                    rows.append(ModificationRow(group.dll_path.name, "전투 그룹", group.label, "초기 드롭률", f"{group.drop_chance}%", "5%"))
                for ref in group.dynamic_drop_writes:
                    if ref.value is not None and 0 < ref.value < 5:
                        rows.append(ModificationRow(group.dll_path.name, "AI 드롭", ref.location, "AI 드롭률", f"{ref.value}%", "5%"))
        elif name == "ITEM_MAGIC_NUM 아이템 비례화":
            for item in self.items:
                if item.secondary_raw > 0 and item.effect_id != 15 and item.magic_mode != "proportional":
                    rows.append(ModificationRow("ED2MAIN.EXE", "아이템", f"{item.item_id:03d} {item.name}", "주문 위력 방식", item_magic_mode_label(item.magic_mode), ITEM_MAGIC_MODE_PROPORTIONAL_LABEL))
        elif name == "모든 아이템 고정 위력":
            for item in self.items:
                if item.magic_mode != "fixed":
                    rows.append(ModificationRow("ED2MAIN.EXE", "아이템", f"{item.item_id:03d} {item.name}", "주문 위력 방식", item_magic_mode_label(item.magic_mode), ITEM_MAGIC_MODE_FIXED_LABEL))
        elif name == "기준점 상태 복원":
            if not self.baseline_exists:
                raise FileNotFoundError("기준점 상태 복원은 먼저 기준점을 저장해야 합니다.")
            _source, current_changes = self.modification_rows()
            rows = [ModificationRow(row.file, row.category, row.target, row.field, row.current, row.original) for row in current_changes]
        else:
            raise ValueError(f"알 수 없는 프리셋: {name}")
        return rows

    def apply_builtin_preset(self, name: str) -> int:
        preview = self.preview_builtin_preset(name)
        if not preview:
            return 0
        if name == "기준점 상태 복원":
            self.restore_baseline()
            return len(preview)
        if name in ("드롭률 2배", "희귀 드롭 최소 5%"):
            for group in list(self.groups):
                if name == "드롭률 2배":
                    initial = min(100, group.drop_chance * 2) if group.drop_chance > 0 else group.drop_chance
                else:
                    initial = 5 if 0 < group.drop_chance < 5 else group.drop_chance
                if initial != group.drop_chance:
                    patch_group(group, {"drop_chance": initial}, True)
                for ref in group.dynamic_drop_writes:
                    value = int(ref.value or 0)
                    new = min(100, value * 2) if name == "드롭률 2배" and value > 0 else (5 if 0 < value < 5 else value)
                    if new != value:
                        patch_dynamic_drop_reference(ref, new, True)
        elif name in ("ITEM_MAGIC_NUM 아이템 비례화", "모든 아이템 고정 위력"):
            modes: dict[int, str] = {}
            for item in self.items:
                if name == "ITEM_MAGIC_NUM 아이템 비례화":
                    if item.secondary_raw > 0 and item.effect_id != 15:
                        modes[item.item_id] = "proportional"
                else:
                    modes[item.item_id] = "fixed"
            set_item_magic_modes_bulk(self.exe, modes, True)
        self.reload()
        return len(preview)

    def export_balance_preset(self, path: Path) -> None:
        data = {
            "format": "ED2 Mod Studio balance preset",
            "version": 3,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "groups": [
                {
                    "dll": group.dll_path.name,
                    "drop_item_id": group.drop_item_id,
                    "drop_chance": group.drop_chance,
                    "bgm_id": group.bgm_id,
                    "ai_drop": [
                        {"segment": ref.segment_index, "offset": ref.instruction_offset, "value": ref.value}
                        for ref in group.dynamic_drop_writes
                    ],
                    "ai_hp_conditions": [
                        {"segment": ref.segment_index, "offset": ref.instruction_offset, "percent": round(ref.threshold_percent, 4)}
                        for ref in group.ai_conditions
                    ],
                }
                for group in self.groups
            ],
            "item_magic_modes": {str(item.item_id): item.magic_mode for item in self.items},
            "magic_recharge": {str(magic.magic_id): magic.count_raw for magic in self.magics},
            "experience_rules": self.experience_rules.to_dict(),
            "gold_reward_rules": self.gold_reward_rules.to_dict(),
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def import_balance_preset(self, path: Path) -> int:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if raw.get("format") != "ED2 Mod Studio balance preset" or raw.get("version") not in (1, 2, 3):
            raise ValueError("지원하지 않는 밸런스 프리셋 형식입니다.")
        groups = {group.dll_path.name.upper(): group for group in self.groups}
        changed = 0
        for row in raw.get("groups", []):
            group = groups.get(str(row.get("dll", "")).upper())
            if group is None:
                raise ValueError(f"프리셋 그룹을 찾을 수 없습니다: {row.get('dll')}")
            values = {
                "drop_item_id": csv_int(row.get("drop_item_id", group.drop_item_id), 0, 255, "drop_item_id"),
                "drop_chance": csv_int(row.get("drop_chance", group.drop_chance), 0, 100, "drop_chance"),
                "bgm_id": csv_int(row.get("bgm_id", group.bgm_id), 0, 255, "bgm_id"),
            }
            if any(getattr(group, key) != value for key, value in values.items()):
                patch_group(group, values, True); changed += 1
            current_drop = {(ref.segment_index, ref.instruction_offset): ref for ref in analyze_dynamic_drop_references(group.dll_path) if ref.editable}
            for ref_row in row.get("ai_drop", []):
                key = (int(ref_row["segment"]), int(ref_row["offset"]))
                ref = current_drop.get(key)
                if ref is None:
                    raise ValueError(f"{group.dll_path.name}: AI 드롭 위치 {key}를 찾을 수 없습니다.")
                value = csv_int(ref_row.get("value", ""), 0, 100, "AI drop")
                if ref.value != value:
                    patch_dynamic_drop_reference(ref, value, True); changed += 1
            current_conditions = {(ref.segment_index, ref.instruction_offset): ref for ref in analyze_dynamic_drop_conditions(group.dll_path)}
            for ref_row in row.get("ai_hp_conditions", []):
                key = (int(ref_row["segment"]), int(ref_row["offset"]))
                ref = current_conditions.get(key)
                if ref is None:
                    raise ValueError(f"{group.dll_path.name}: AI HP 조건 위치 {key}를 찾을 수 없습니다.")
                percent = float(ref_row["percent"])
                new_raw = hp_ratio_percent_to_raw(percent)
                if ref.threshold_raw != new_raw:
                    patch_ai_condition_threshold(ref, percent, True); changed += 1
        modes = {int(item_id): normalize_item_magic_mode(mode) for item_id, mode in dict(raw.get("item_magic_modes", {})).items()}
        if modes:
            set_item_magic_modes_bulk(self.exe, modes, True); changed += sum(self.items[item_id].magic_mode != mode for item_id, mode in modes.items())
        recharge = {int(magic_id): csv_int(value, 0, 255, "MAGIC_CNT") for magic_id, value in dict(raw.get("magic_recharge", {})).items()}
        if recharge:
            prepared = bytearray(self.exe.read_bytes())
            verify_magic_table(prepared)
            recharge_changes = 0
            for magic_id, value in recharge.items():
                if not 0 <= magic_id < MAGIC_COUNT:
                    raise ValueError(f"프리셋 주문 ID가 범위를 벗어났습니다: {magic_id}")
                off = MAGIC_PARAM_BASE + magic_id * MAGIC_RECORD_SIZE + 11
                if prepared[off] != value:
                    prepared[off] = value
                    recharge_changes += 1
            if recharge_changes:
                atomic_write(self.exe, bytes(prepared), True)
                changed += recharge_changes
        exp_raw = raw.get("experience_rules")
        if isinstance(exp_raw, dict):
            exp_state = ExperienceRuleState(
                bool(exp_raw.get("include_incapacitated", False)),
                bool(exp_raw.get("no_party_split", False)),
                bool(exp_raw.get("no_general_90_percent", False)),
                bool(exp_raw.get("no_level_penalty", False)),
            )
            current_exp = load_experience_rules(self.exe)
            if current_exp != exp_state:
                changed += patch_experience_rules(self.exe, exp_state, True)
        gold_raw = raw.get("gold_reward_rules")
        if isinstance(gold_raw, dict):
            gold_state = GoldRewardRuleState(
                bool(gold_raw.get("no_general_90_percent", False)),
                bool(gold_raw.get("no_level_scaling", False)),
            )
            current_gold = load_gold_reward_rules(self.exe)
            if current_gold != gold_state:
                changed += patch_gold_reward_rules(self.exe, gold_state, True)
        self.reload()
        return changed

    def validate(self) -> dict[str, Any]:
        warnings: list[str] = []
        errors: list[str] = []
        notes: list[str] = []
        known_asset_ids = {a.asset_id for a in self.assets}
        for group in self.groups:
            if not 0 <= group.drop_chance <= 100:
                errors.append(f"{group.dll_path.name}: drop chance {group.drop_chance} is outside 0..100")
            for index, asset_id in enumerate((group.graphic_id0, group.graphic_id1)):
                if asset_id != 0xFFFF and asset_id not in known_asset_ids:
                    errors.append(f"{group.dll_path.name}: C_MO{asset_id:03X}.BZH for graphic {index} is missing")
            valid_drop_id = (
                0 <= group.drop_item_id < ITEM_COUNT
                or EVENT_ITEM_ID_BASE <= group.drop_item_id < EVENT_ITEM_ID_BASE + EVENT_ITEM_COUNT
            )
            if not valid_drop_id:
                warnings.append(f"{group.dll_path.name}: drop ID {group.drop_item_id} is unknown")

            runtime_values = [int(ref.value) for ref in group.dynamic_drop_writes if ref.value is not None]
            for ref in group.dynamic_drop_writes:
                if ref.value is not None and not 0 <= ref.value <= 100:
                    errors.append(
                        f"{group.dll_path.name} {ref.location}: AI drop chance {ref.value} is outside 0..100"
                    )
            possible_positive = group.drop_chance > 0 or any(value > 0 for value in runtime_values)
            if valid_drop_id and group.drop_item_id != 0 and not possible_positive:
                warnings.append(
                    f"{group.dll_path.name}: 드롭 아이템 {self.item_display(group.drop_item_id)}이 설정되어 있지만 "
                    "초기값과 확인된 AI 변경값이 모두 0%입니다. 일반 드롭으로는 획득 불가할 수 있습니다."
                )
            if len(set(runtime_values)) > 1:
                warnings.append(
                    f"{group.dll_path.name}: AI가 드롭 확률을 여러 값 {sorted(set(runtime_values))}%로 변경합니다. "
                    "실행 경로에 따라 최종 확률이 달라집니다."
                )
            if group.drop_chance == 0 and any(value > 0 for value in runtime_values):
                notes.append(
                    f"{group.dll_path.name}: 표시상 초기 0%지만 AI 경로 후 최대 {max(runtime_values)}%로 변경됩니다."
                )
            for condition in group.ai_conditions:
                if condition.threshold_raw == 0 and condition.relation in ("미만", "이하"):
                    warnings.append(
                        f"{group.dll_path.name} {condition.location}: HP 조건 원시값 0은 해당 분기가 거의/완전히 실행되지 않을 수 있습니다."
                    )
                if condition.threshold_raw >= 250:
                    warnings.append(
                        f"{group.dll_path.name} {condition.location}: HP 조건이 {condition.threshold_percent:.1f}%로 매우 높습니다."
                    )

            records = [record for record in self.monsters if record.dll_path == group.dll_path]
            for reward_key, label in (("exp", "EXP"), ("gold", "Gold")):
                total = formation_reward_total(records, reward_key, group.dll_number, group.bgm_id)
                if total > REWARD_ACCUMULATOR_MAX:
                    errors.append(f"{group.dll_path.name}: {label} accumulator overflow ({total})")

        for asset in self.assets:
            if not asset.header_valid:
                errors.append(f"{asset.path.name}: invalid BZH size header")
        for item in self.items:
            try:
                encode_price(item.price)
            except ValueError as exc:
                errors.append(f"Item {item.item_id}: {exc}")
            if item.magic_mode == "proportional":
                if item.secondary_raw == 0:
                    warnings.append(
                        f"아이템 {item.item_id} {item.name}: 마력 비례 방식이지만 ITEM_MAGIC_NUM이 0이라 비례 효과가 0입니다."
                    )
                elif item.secondary_effective > 100:
                    warnings.append(
                        f"아이템 {item.item_id} {item.name}: 비례 배율이 플레이어 마력의 {item.secondary_effective}%로 높습니다."
                    )
                if item.effect_id == 15:
                    warnings.append(
                        f"아이템 {item.item_id} {item.name}: 일반/없음 효과 ID 15에 마력 비례 방식이 지정되어 있습니다."
                    )
        for rec in self.player_equipment:
            for slot, label in PLAYER_EQUIPMENT_LABELS.items():
                item_id = rec.item_id(slot)
                if not 0 <= item_id < len(self.items):
                    errors.append(f"{rec.name} 초기 {label}: unknown item ID {item_id}")
                    continue
                item = self.items[item_id]
                if not equipment_item_allowed(item, slot):
                    errors.append(f"{rec.name} 초기 {label}: {item_id} {item.name}은(는) 슬롯 타입과 맞지 않습니다.")

        for magic in self.magics:
            _description, unsafe = describe_magic_count(magic.count_raw)
            if unsafe:
                warnings.append(
                    f"주문 {magic.magic_id} {magic.name}: MAGIC_CNT=0x{magic.count_raw:02X}에 0 니블이 있어 충전 언더플로 위험이 있습니다."
                )
        if not self.experience_rules.recognized:
            errors.append("ED2MAIN.EXE 경험치 루틴을 인식할 수 없습니다: " + self.experience_rules.detail)
        else:
            notes.append("경험치 획득 방식: " + self.experience_rules.summary)
            if self.experience_rules.no_party_split:
                warnings.append("파티 분배 없음이 활성화되어 각 획득 대상이 전투 총 경험치를 모두 받습니다.")
            if self.experience_rules.include_incapacitated:
                notes.append("기절/전투불능 플래그가 있는 활성 파티원도 경험치를 받으며 인원 계산에도 포함됩니다.")
        if not self.gold_reward_rules.recognized:
            errors.append("ED2MAIN.EXE Gold 보상 루틴을 인식할 수 없습니다: " + self.gold_reward_rules.detail)
        else:
            notes.append("Gold 획득 방식: " + self.gold_reward_rules.summary)
        if self.item_magic_scaling == "unknown":
            warnings.append("ED2MAIN.EXE item-magic scaling routine contains an unrecognized patch")
        if self.scena_dir.is_dir() and not self.shops:
            warnings.append("SCENA 폴더가 있지만 편집 가능한 BUY_SHOP 상품 목록을 찾지 못했습니다.")
        for shop in self.shops:
            if not 1 <= len(shop.item_codes) <= shop.capacity:
                errors.append(f"{shop.dll_path.name} 0x{shop.list_offset:04X}: 상품 개수/공간이 올바르지 않습니다.")
            if shop.shared_users > 1:
                notes.append(
                    f"{shop.dll_path.name} list 0x{shop.list_offset:04X}: {shop.shared_users}개 상점 경로가 상품 목록을 공유합니다."
                )

        return {
            "tool": f"{APP_NAME} {VERSION}",
            "root": str(self.root),
            "counts": {
                "monster_dlls": len(self.groups),
                "monster_records": len(self.monsters),
                "dynamic_drop_groups": sum(bool(group.dynamic_drop_refs) for group in self.groups),
                "editable_ai_conditions": sum(len(group.ai_conditions) for group in self.groups),
                "special_rules": len(self.special_rules),
                "regular_items": len(self.items),
                "player_initial_equipment_records": len(self.player_equipment),
                "event_items": len(self.event_items),
                "magics": len(self.magics),
                "shops": len(self.shops),
                "appearance_assets": len(self.assets),
                "item_magic_scaling": self.item_magic_scaling,
                "experience_rules": self.experience_rules.to_dict(),
                "gold_reward_rules": self.gold_reward_rules.to_dict(),
                "baseline": self.baseline_exists,
            },
            "errors": errors,
            "warnings": warnings,
            "notes": notes,
            "ok": not errors,
        }

    def export_monsters_csv(self, path: Path) -> None:
        fields = ["dll", "slot", "name", "level", "hp", "attack", "exp_raw", "gold_raw", "defense", "magic", "speed", "luck"]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for rec in self.monsters:
                writer.writerow({
                    "dll": rec.dll_path.name, "slot": rec.slot, "name": rec.name,
                    "level": rec.value("level"), "hp": rec.value("hp"), "attack": rec.value("attack"),
                    "exp_raw": rec.value("exp"), "gold_raw": rec.value("gold"),
                    "defense": rec.value("defense"), "magic": rec.value("magic"),
                    "speed": rec.value("speed"), "luck": rec.value("luck"),
                })

    def export_groups_csv(self, path: Path) -> None:
        fields = ["dll", "monsters", "graphic_id0_hex", "graphic_addr0_hex", "graphic_id1_hex", "graphic_addr1_hex", "drop_item_id", "drop_item_name", "drop_chance", "runtime_drop_summary", "runtime_drop_writes", "runtime_drop_conditions", "special_rules", "bgm_id"]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for g in self.groups:
                writer.writerow({
                    "dll": g.dll_path.name, "monsters": " / ".join(g.monster_names),
                    "graphic_id0_hex": f"0x{g.graphic_id0:04X}", "graphic_addr0_hex": f"0x{g.graphic_addr0:04X}",
                    "graphic_id1_hex": f"0x{g.graphic_id1:04X}", "graphic_addr1_hex": f"0x{g.graphic_addr1:04X}",
                    "drop_item_id": g.drop_item_id, "drop_item_name": self.item_display(g.drop_item_id),
                    "drop_chance": g.drop_chance,
                    "runtime_drop_summary": g.dynamic_drop_summary,
                    "runtime_drop_writes": "; ".join(
                        f"{ref.location}={ref.value}%" for ref in g.dynamic_drop_writes if ref.value is not None
                    ),
                    "runtime_drop_conditions": "; ".join(
                        f"{condition.location}: {condition.condition_text}" for condition in g.ai_conditions
                    ),
                    "special_rules": "; ".join(
                        f"[{rule.confidence}] {rule.category}: {rule.summary}" for rule in g.special_rules
                    ),
                    "bgm_id": g.bgm_id,
                })

    def export_shops_csv(self, path: Path) -> None:
        fields = [
            "dll", "shop_index", "merchant", "call_offset_hex", "structure_offset_hex",
            "variant_index", "variant_count", "list_offset_hex", "capacity",
            "item_codes", "item_names", "shared_users",
        ]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for index, shop in enumerate(self.shops):
                writer.writerow({
                    "dll": shop.dll_path.name, "shop_index": index, "merchant": shop.merchant_name,
                    "call_offset_hex": f"0x{shop.call_offset:04X}",
                    "structure_offset_hex": f"0x{shop.structure_offset:04X}",
                    "variant_index": shop.variant_index, "variant_count": shop.variant_count,
                    "list_offset_hex": f"0x{shop.list_offset:04X}", "capacity": shop.capacity,
                    "item_codes": " ".join(f"0x{value:02X}" for value in shop.item_codes),
                    "item_names": " / ".join(shop_item_label(value, self.items) for value in shop.item_codes),
                    "shared_users": shop.shared_users,
                })

    def export_items_csv(self, path: Path) -> None:
        fields = ["item_id", "name", "price", "price_mantissa", "price_exponent", "stat_group", "stat_label", "effect_id", "power_raw", "power_effective_x5", "secondary_raw", "secondary_effective", "magic_mode", "type_mask_hex"]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for item in self.items:
                writer.writerow({
                    "item_id": item.item_id, "name": item.name, "price": item.price,
                    "price_mantissa": item.price_mantissa, "price_exponent": item.price_exponent,
                    "stat_group": item.stat_group, "stat_label": item.stat_label, "effect_id": item.effect_id,
                    "power_raw": item.power_raw, "power_effective_x5": item.power_effective,
                    "secondary_raw": item.secondary_raw, "secondary_effective": item.secondary_effective,
                    "magic_mode": item.magic_mode, "type_mask_hex": f"0x{item.type_mask:02X}",
                })

    def export_event_items_csv(self, path: Path) -> None:
        fields = ["item_id", "name", "file_offset_hex"]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for item in self.event_items:
                writer.writerow({
                    "item_id": item.item_id, "name": item.name,
                    "file_offset_hex": f"0x{item.file_offset:X}",
                })

    def export_magics_csv(self, path: Path) -> None:
        fields = [
            "magic_id", "name", "cost", "magic_slc_hex", "secondary_select",
            "magic_bairitu", "magic_cnt_hex", "count_high", "count_low",
            "handler_offset_hex", "handler_name",
        ]
        with path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=fields)
            writer.writeheader()
            for magic in self.magics:
                writer.writerow({
                    "magic_id": magic.magic_id, "name": magic.name, "cost": magic.cost,
                    "magic_slc_hex": f"0x{magic.select_flags:02X}",
                    "secondary_select": int(magic.secondary_select),
                    "magic_bairitu": magic.multiplier,
                    "magic_cnt_hex": f"0x{magic.count_raw:02X}",
                    "count_high": magic.count_high, "count_low": magic.count_low,
                    "handler_offset_hex": f"0x{magic.handler_offset:04X}",
                    "handler_name": magic.handler_name,
                })

    def export_ai_hooks_json(self, path: Path) -> None:
        payload: list[dict[str, Any]] = []
        for group in self.groups:
            info = self.debug_info(group.dll_path.name)
            payload.append({
                "dll": group.dll_path.name,
                "monsters": group.monster_names,
                "source": info.get("source", ""),
                "hooks": [
                    {"symbol": symbol, "offset": value, "offset_hex": f"0x{value:04X}", "description": description}
                    for symbol, value, description in group.hook_rows()
                ],
                "dynamic_drop": [
                    {
                        "location": ref.location,
                        "operation": ref.operation,
                        "value": ref.value,
                        "editable": ref.editable,
                        "condition": (group.condition_for_drop(ref).condition_text if group.condition_for_drop(ref) else None),
                        "note": ref.note,
                    }
                    for ref in group.dynamic_drop_refs
                ],
                "ai_conditions": [
                    {
                        "location": ref.location,
                        "condition": ref.condition_text,
                        "threshold_raw": ref.threshold_raw,
                        "threshold_percent": ref.threshold_percent,
                        "editable": ref.editable,
                        "linked_drop_instruction_offset": ref.linked_drop_instruction_offset,
                        "note": ref.note,
                    }
                    for ref in group.ai_conditions
                ],
                "special_rules": [asdict(rule) | {"dll_path": str(rule.dll_path)} for rule in group.special_rules],
                "debug_categories": info.get("categories", {}),
            })
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def file_inventory(root: Path) -> list[dict[str, Any]]:
    result = []
    for path in sorted(p for p in root.rglob("*") if p.is_file() and not p.name.endswith(".bak") and BASELINE_DIR_NAME not in p.parts):
        rel = path.relative_to(root)
        data = path.read_bytes()[:16]
        result.append({
            "relative": str(rel), "extension": path.suffix.upper() or "(none)",
            "size": path.stat().st_size, "header_hex": data.hex(" ").upper(),
        })
    return result


def write_analysis_bundle(project: Project, folder: Path) -> list[Path]:
    folder.mkdir(parents=True, exist_ok=True)
    paths = [
        folder / "ED2_MONSTERS.csv", folder / "ED2_MONSTER_GROUPS.csv",
        folder / "ED2_ITEMS.csv", folder / "ED2_EVENT_ITEMS.csv", folder / "ED2_PLAYER_INITIAL_EQUIPMENT.csv", folder / "ED2_SHOPS.csv",
        folder / "ED2_MAGIC.csv", folder / "ED2_AI_HOOKS.json",
        folder / "ED2_SPECIAL_RULES.json", folder / "ED2_FILE_INVENTORY.json",
        folder / "ED2_VALIDATION.json",
    ]
    project.export_monsters_csv(paths[0])
    project.export_groups_csv(paths[1])
    project.export_items_csv(paths[2])
    project.export_event_items_csv(paths[3])
    project.export_player_equipment_csv(paths[4])
    project.export_shops_csv(paths[5])
    project.export_magics_csv(paths[6])
    project.export_ai_hooks_json(paths[7])
    paths[8].write_text(
        json.dumps([asdict(rule) | {"dll_path": str(rule.dll_path)} for rule in project.special_rules], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    paths[9].write_text(json.dumps(file_inventory(project.root), ensure_ascii=False, indent=2), encoding="utf-8")
    paths[10].write_text(json.dumps(project.validate(), ensure_ascii=False, indent=2), encoding="utf-8")
    return paths


# ---------------------------------------------------------------------------
# Tkinter GUI
# ---------------------------------------------------------------------------

def run_gui(initial_root: Optional[Path] = None, audio_tool: Optional[Path] = None) -> None:
    try:
        import tkinter as tk
        from tkinter import ttk, filedialog, messagebox
    except ImportError as exc:
        raise SystemExit("Tkinter is required for GUI mode") from exc

    class Studio(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.title(f"{APP_NAME} {VERSION}")
            self.geometry("1500x920")
            self.minsize(1080, 700)
            self.project: Optional[Project] = None
            self.audio_tool = audio_tool
            self.current_monster: Optional[MonsterRecord] = None
            self.current_group: Optional[MonsterGroup] = None
            self.current_dynamic_drop_ref: Optional[DynamicDropReference] = None
            self.current_ai_condition: Optional[AIConditionReference] = None
            self.current_item: Optional[ItemRecord | EventItemRecord] = None
            self.current_magic: Optional[MagicRecord] = None
            self.current_shop: Optional[ShopInventory] = None
            self.current_asset: Optional[AppearanceAsset] = None
            self.current_resource: Optional[Path] = None
            self.resource_paths: dict[str, Path] = {}
            self.item_entries: dict[str, Any] = {}
            self._build_style()
            self._build_ui()
            if initial_root and initial_root.exists():
                self.open_project(initial_root)

        def _build_style(self) -> None:
            style = ttk.Style(self)
            try:
                style.theme_use("vista" if sys.platform == "win32" else "clam")
            except Exception:
                pass
            style.configure("Treeview", rowheight=25)
            style.configure("Title.TLabel", font=("TkDefaultFont", 13, "bold"))
            style.configure("Section.TLabel", font=("TkDefaultFont", 10, "bold"))
            style.configure("Danger.TLabel", foreground="#A00000")

        # Shared scroll helpers ------------------------------------------
        def _wheel_bind(self, widget: Any, xview: Any, yview: Any) -> None:
            def vertical(event: Any) -> str:
                delta = -1 if getattr(event, "delta", 0) > 0 else 1
                if getattr(event, "num", 0) == 4: delta = -1
                elif getattr(event, "num", 0) == 5: delta = 1
                yview("scroll", delta * 3, "units")
                return "break"

            def horizontal(event: Any) -> str:
                delta = -1 if getattr(event, "delta", 0) > 0 else 1
                xview("scroll", delta * 3, "units")
                return "break"

            def enter(_event: Any) -> None:
                self.bind_all("<MouseWheel>", vertical)
                self.bind_all("<Shift-MouseWheel>", horizontal)
                self.bind_all("<Button-4>", vertical)
                self.bind_all("<Button-5>", vertical)

            def leave(_event: Any) -> None:
                self.unbind_all("<MouseWheel>")
                self.unbind_all("<Shift-MouseWheel>")
                self.unbind_all("<Button-4>")
                self.unbind_all("<Button-5>")

            widget.bind("<Enter>", enter, add="+")
            widget.bind("<Leave>", leave, add="+")

        def _tree(self, parent: Any, columns: tuple[str, ...], **kwargs: Any) -> Any:
            box = ttk.Frame(parent)
            box.pack(fill="both", expand=True)
            tree = ttk.Treeview(box, columns=columns, show="headings", **kwargs)
            ybar = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
            xbar = ttk.Scrollbar(box, orient="horizontal", command=tree.xview)
            tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
            tree.grid(row=0, column=0, sticky="nsew")
            ybar.grid(row=0, column=1, sticky="ns")
            xbar.grid(row=1, column=0, sticky="ew")
            box.rowconfigure(0, weight=1)
            box.columnconfigure(0, weight=1)
            self._wheel_bind(tree, tree.xview, tree.yview)
            return tree

        def _text(self, parent: Any, **kwargs: Any) -> Any:
            box = ttk.Frame(parent)
            box.pack(fill="both", expand=True)
            text = tk.Text(box, wrap="none", **kwargs)
            ybar = ttk.Scrollbar(box, orient="vertical", command=text.yview)
            xbar = ttk.Scrollbar(box, orient="horizontal", command=text.xview)
            text.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
            text.grid(row=0, column=0, sticky="nsew")
            ybar.grid(row=0, column=1, sticky="ns")
            xbar.grid(row=1, column=0, sticky="ew")
            box.rowconfigure(0, weight=1)
            box.columnconfigure(0, weight=1)
            self._wheel_bind(text, text.xview, text.yview)
            return text

        def _scrollable_panel(self, parent: Any, padding: int = 10) -> tuple[Any, Any]:
            outer = ttk.Frame(parent)
            canvas = tk.Canvas(outer, highlightthickness=0)
            ybar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
            xbar = ttk.Scrollbar(outer, orient="horizontal", command=canvas.xview)
            canvas.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
            canvas.grid(row=0, column=0, sticky="nsew")
            ybar.grid(row=0, column=1, sticky="ns")
            xbar.grid(row=1, column=0, sticky="ew")
            outer.rowconfigure(0, weight=1)
            outer.columnconfigure(0, weight=1)
            inner = ttk.Frame(canvas, padding=padding)
            window = canvas.create_window((0, 0), window=inner, anchor="nw")
            inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window, height=max(e.height, inner.winfo_reqheight())))
            self._wheel_bind(canvas, canvas.xview, canvas.yview)
            return outer, inner

        def _make_pane(self, parent: Any) -> tuple[Any, Any]:
            pane = ttk.Panedwindow(parent, orient="horizontal")
            pane.pack(fill="both", expand=True)
            left = ttk.Frame(pane, padding=6)
            right_holder = ttk.Frame(pane)
            right_outer, right = self._scrollable_panel(right_holder)
            right_outer.pack(fill="both", expand=True)
            pane.add(left, weight=3)
            pane.add(right_holder, weight=2)
            return left, right

        def _readonly_text(self, widget: Any, content: str) -> None:
            widget.configure(state="normal")
            widget.delete("1.0", "end")
            widget.insert("1.0", content)
            widget.configure(state="disabled")

        # Main window -----------------------------------------------------
        def _build_ui(self) -> None:
            toolbar = ttk.Frame(self, padding=(10, 8))
            toolbar.pack(fill="x")
            ttk.Label(toolbar, text=APP_NAME, style="Title.TLabel").pack(side="left")
            self.root_var = tk.StringVar()
            ttk.Entry(toolbar, textvariable=self.root_var).pack(side="left", fill="x", expand=True, padx=12)
            ttk.Button(toolbar, text="게임 폴더 열기", command=self.choose_project).pack(side="left")
            ttk.Button(toolbar, text="새로고침", command=self.reload_project).pack(side="left", padx=(6, 0))
            ttk.Button(toolbar, text="전체 검사", command=self.run_validation).pack(side="left", padx=(6, 0))
            self.status_var = tk.StringVar(value="ED2MAIN.EXE와 MON 폴더가 있는 게임 폴더를 선택하세요.")
            ttk.Label(self, textvariable=self.status_var, anchor="w", padding=(10, 0, 10, 6)).pack(fill="x")
            self.nb = ttk.Notebook(self)
            self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 8))
            self._build_monsters_tab()
            self._build_groups_tab()
            self._build_items_tab()
            self._build_player_equipment_tab()
            self._build_shops_tab()
            self._build_magic_tab()
            self._build_experience_tab()
            self._build_ai_tab()
            self._build_appearance_tab()
            self._build_resources_tab()
            self._build_changes_tab()
            self._build_audio_tab()
            self._build_diagnostics_tab()

        def choose_project(self) -> None:
            folder = filedialog.askdirectory(title="영웅전설 2 게임 폴더 선택")
            if folder: self.open_project(Path(folder))

        def open_project(self, root: Path) -> None:
            try:
                self.project = Project(root)
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))
                return
            self.root_var.set(str(self.project.root))
            self.populate_all()
            report = self.project.validate()
            self.status_var.set(
                f"로드 완료: 몬스터 {len(self.project.monsters)} / 그룹 {len(self.project.groups)} / "
                f"일반 아이템 {len(self.project.items)} / 초기 장비 {len(self.project.player_equipment)}명 / 이벤트 아이템 {len(self.project.event_items)} / "
                f"주문 {len(self.project.magics)} / 상점 경로 {len(self.project.shops)} / 외형 {len(self.project.assets)} | "
                f"오류 {len(report['errors'])}, 경고 {len(report['warnings'])}"
            )

        def reload_project(self) -> None:
            if self.project:
                self.open_project(self.project.root)
            elif self.root_var.get().strip():
                self.open_project(Path(self.root_var.get().strip()))

        def populate_all(self) -> None:
            self.populate_monsters()
            self.populate_groups()
            self.populate_items()
            self.populate_player_equipment()
            self.populate_shops()
            self.populate_magics()
            self.populate_experience()
            self.populate_ai()
            self.populate_assets()
            self.populate_resources()
            self.populate_changes()
            self.update_diagnostics()

        # Monsters --------------------------------------------------------
        def _build_monsters_tab(self) -> None:
            tab = ttk.Frame(self.nb); self.nb.add(tab, text="몬스터")
            left, right = self._make_pane(tab)
            bar = ttk.Frame(left); bar.pack(fill="x", pady=(0, 6))
            self.mon_search = tk.StringVar()
            ttk.Label(bar, text="검색").pack(side="left")
            e = ttk.Entry(bar, textvariable=self.mon_search); e.pack(side="left", fill="x", expand=True, padx=6)
            e.bind("<KeyRelease>", lambda _e: self.populate_monsters())
            ttk.Button(bar, text="CSV 내보내기", command=self.export_monsters_csv).pack(side="left")
            ttk.Button(bar, text="CSV 가져오기", command=self.import_monsters_csv_gui).pack(side="left", padx=(4, 0))
            cols = ("dll", "slot", "name", "level", "hp", "atk", "def", "magic", "speed", "luck", "exp", "gold")
            self.mon_tree = self._tree(left, cols, selectmode="browse")
            labels = {"dll":"DLL", "slot":"#", "name":"이름", "level":"Lv", "hp":"HP", "atk":"공격", "def":"방어", "magic":"주문", "speed":"속도", "luck":"행운", "exp":"EXP 원시값", "gold":"Gold 원시값"}
            widths = {"dll":80, "slot":40, "name":190, "level":45, "hp":80, "atk":70, "def":70, "magic":70, "speed":60, "luck":60, "exp":95, "gold":95}
            for col in cols:
                self.mon_tree.heading(col, text=labels[col]); self.mon_tree.column(col, width=widths[col], minwidth=40, anchor="w" if col == "name" else "center")
            self.mon_tree.bind("<<TreeviewSelect>>", lambda _e: self.show_monster())

            ttk.Label(right, text="몬스터 상세", style="Title.TLabel").pack(anchor="w")
            form = ttk.Frame(right); form.pack(fill="x", pady=(8, 0))
            self.mon_vars = {key: tk.StringVar() for key in ("name", "level", "hp", "attack", "defense", "magic", "speed", "luck", "exp", "gold")}
            rows = [("name","이름"),("level","몬스터 레벨"),("hp","HP"),("attack","공격"),("defense","방어"),("magic","주문"),("speed","속도"),("luck","행운"),("exp","EXP 원시값"),("gold","Gold 원시값")]
            for row, (key, label) in enumerate(rows):
                ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=3)
                ttk.Entry(form, textvariable=self.mon_vars[key], width=38).grid(row=row, column=1, sticky="ew", padx=(8, 0), pady=3)
            form.columnconfigure(1, weight=1)
            estimator = ttk.LabelFrame(right, text="실제 EXP 예상", padding=8); estimator.pack(fill="x", pady=10)
            self.party_level_var = tk.StringVar(value="30")
            self.party_count_var = tk.StringVar(value="4")
            ttk.Label(estimator, text="생존 파티 평균 레벨").grid(row=0, column=0, sticky="w")
            ttk.Entry(estimator, textvariable=self.party_level_var, width=8).grid(row=0, column=1, sticky="w", padx=6)
            ttk.Label(estimator, text="생존 인원").grid(row=0, column=2, sticky="w", padx=(10,0))
            ttk.Entry(estimator, textvariable=self.party_count_var, width=5).grid(row=0, column=3, sticky="w", padx=6)
            ttk.Button(estimator, text="편성 전체 계산", command=self.update_exp_estimate).grid(row=0, column=4)
            self.exp_estimate_var = tk.StringVar(value="몬스터를 선택하세요.")
            ttk.Label(estimator, textvariable=self.exp_estimate_var, wraplength=700).grid(row=1, column=0, columnspan=5, sticky="w", pady=(6, 0))
            ttk.Label(right, text="고급 바이트 0x18..0x2F", style="Section.TLabel").pack(anchor="w")
            advanced_box = ttk.Frame(right); advanced_box.pack(fill="x", pady=(4, 8))
            self.mon_advanced = self._text(advanced_box, height=3)
            btn = ttk.Frame(right); btn.pack(fill="x")
            ttk.Button(btn, text="선택 몬스터 저장 (.bak)", command=self.save_monster).pack(side="left")
            ttk.Button(btn, text="이 도구 변경만 복원", command=self.restore_current_mon_dll).pack(side="left", padx=6)
            bulk = ttk.LabelFrame(right, text="전체 몬스터 일괄 수식", padding=8); bulk.pack(fill="x", pady=(12, 0))
            self.bulk_stat_var = tk.StringVar(value="HP"); self.bulk_expr_var = tk.StringVar(value="*1.5")
            ttk.Combobox(bulk, textvariable=self.bulk_stat_var, state="readonly", values=("HP","Attack","Defense","Magic","Speed","Luck","EXP raw","Gold raw"), width=14).grid(row=0, column=0, sticky="w")
            ttk.Entry(bulk, textvariable=self.bulk_expr_var, width=34).grid(row=0, column=1, sticky="ew", padx=6)
            ttk.Button(bulk, text="미리보기", command=self.preview_bulk).grid(row=0, column=2)
            ttk.Button(bulk, text="전체 적용", command=self.apply_bulk).grid(row=0, column=3, padx=(6, 0))
            ttk.Label(bulk, text="예: +10, *1.5, log10(x)*100, x+log2(x)*20, max(1,x-5)").grid(row=1, column=0, columnspan=4, sticky="w", pady=(6,0))
            ttk.Label(bulk, text="EXP/Gold는 활성 편성 합계가 65,535를 넘지 않도록 자동 조정됩니다.").grid(row=2, column=0, columnspan=4, sticky="w", pady=(3,0))
            bulk.columnconfigure(1, weight=1)

        def populate_monsters(self) -> None:
            self.mon_tree.delete(*self.mon_tree.get_children())
            if not self.project: return
            needle = self.mon_search.get().strip().lower()
            for index, rec in enumerate(self.project.monsters):
                if needle and needle not in f"{rec.dll_path.name} {rec.name}".lower(): continue
                self.mon_tree.insert("", "end", iid=str(index), values=(rec.dll_path.stem, rec.slot, rec.name, rec.value("level"), rec.value("hp"), rec.value("attack"), rec.value("defense"), rec.value("magic"), rec.value("speed"), rec.value("luck"), rec.value("exp"), rec.value("gold")))

        def show_monster(self) -> None:
            if not self.project: return
            sel = self.mon_tree.selection()
            if not sel: return
            rec = self.project.monsters[int(sel[0])]; self.current_monster = rec
            self.mon_vars["name"].set(rec.name)
            for key in MONSTER_FIELDS:
                if key in self.mon_vars: self.mon_vars[key].set(str(rec.value(key)))
            self.mon_advanced.delete("1.0", "end"); self.mon_advanced.insert("1.0", rec.raw[0x18:0x30].hex(" ").upper())
            self.update_exp_estimate()

        def update_exp_estimate(self) -> None:
            if not self.project or not self.current_monster:
                self.exp_estimate_var.set("몬스터를 선택하세요."); return
            try:
                party_lv = parse_number(self.party_level_var.get(), 1, 255, "파티 평균 레벨")
                party_count = parse_number(self.party_count_var.get(), 1, 4, "생존 인원")
            except Exception as exc:
                self.exp_estimate_var.set(str(exc)); return
            rec = self.current_monster
            group = self.project.group_by_path(rec.dll_path)
            records = [record for record in self.project.monsters if record.dll_path == rec.dll_path]
            active = _active_records(records)
            exp_values = [estimated_reward(
                r.value("exp"), r.value("level"), party_lv, r.dll_number, group.bgm_id,
                no_general_90=self.project.experience_rules.no_general_90_percent,
                no_level_penalty=self.project.experience_rules.no_level_penalty,
            )[0] for r in active]
            gold_values = [estimated_reward(
                r.value("gold"), r.value("level"), party_lv, r.dll_number, group.bgm_id,
                no_general_90=self.project.gold_reward_rules.no_general_90_percent,
                no_level_penalty=self.project.gold_reward_rules.no_level_scaling,
            )[0] for r in active]
            exp_sum = sum(exp_values); gold_sum = sum(gold_values)
            exp_word = exp_sum & REWARD_ACCUMULATOR_MAX
            gold_word = gold_sum & REWARD_ACCUMULATOR_MAX
            share = (exp_word + party_count - 1) // party_count if exp_word else 0
            overflow = "없음" if exp_sum <= REWARD_ACCUMULATOR_MAX else f"발생: {exp_sum} → {exp_word}"
            gold_overflow = "없음" if gold_sum <= REWARD_ACCUMULATOR_MAX else f"발생: {gold_sum} → {gold_word}"
            names = ", ".join(r.name for r in active)
            self.exp_estimate_var.set(
                f"활성 편성 {len(active)}마리: {names}\n"
                f"EXP 합계 {exp_sum}, 16비트 결과 {exp_word}, 오버플로 {overflow}, "
                f"{party_count}명 기준 1인당 {share}\n"
                f"Gold 합계 {gold_sum}, 16비트 결과 {gold_word}, 오버플로 {gold_overflow}"
            )

        def save_monster(self) -> None:
            if not self.current_monster: return
            try:
                values: dict[str, Any] = {"name": self.mon_vars["name"].get(), "advanced_hex": self.mon_advanced.get("1.0", "end")}
                for key, (_off, size, _label) in MONSTER_FIELDS.items():
                    if key == "record_id": continue
                    values[key] = parse_number(self.mon_vars[key].get(), 1 if key == "hp" else 0, 255 if size == 1 else 65535, key)
                path, slot = self.current_monster.dll_path, self.current_monster.slot
                applied = patch_monster(self.current_monster, values); self.reload_project()
                for index, rec in enumerate(self.project.monsters if self.project else []):
                    if rec.dll_path == path and rec.slot == slot:
                        if self.mon_tree.exists(str(index)):
                            self.mon_tree.selection_set(str(index)); self.mon_tree.see(str(index)); self.show_monster()
                        break
                adjusted = [key.upper() for key in ("exp", "gold") if key in values and int(values[key]) != int(applied[key])]
                suffix = f" 오버플로 방지 자동 조정: {', '.join(adjusted)}" if adjusted else ""
                messagebox.showinfo(APP_NAME, "몬스터를 저장했습니다." + suffix)
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

        def restore_current_mon_dll(self) -> None:
            if not self.current_monster: return
            if not messagebox.askyesno(APP_NAME, f"{self.current_monster.dll_path.name}에서 Mod Studio가 변경한 바이트만 복원할까요?\n다른 패치는 유지됩니다."): return
            try: restore_backup(self.current_monster.dll_path); self.reload_project()
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

        def _bulk_key(self) -> tuple[str, int, int]:
            return {"HP":("hp",1,65535),"Attack":("attack",0,65535),"Defense":("defense",0,65535),"Magic":("magic",0,65535),"Speed":("speed",0,255),"Luck":("luck",0,255),"EXP raw":("exp",0,65535),"Gold raw":("gold",0,65535)}[self.bulk_stat_var.get()]

        def _bulk_proposals(self, key: str, minimum: int, maximum: int, expr: str) -> tuple[dict[Path, dict[int, int]], int, int]:
            if not self.project: return {}, 0, 0
            by_path: dict[Path, list[MonsterRecord]] = {}
            for rec in self.project.monsters:
                by_path.setdefault(rec.dll_path, []).append(rec)
            proposals: dict[Path, dict[int, int]] = {}
            clamped = adjusted = 0
            for path, records in by_path.items():
                values: dict[int, int] = {}
                for rec in records:
                    raw_new = eval_formula(rec.value(key), expr)
                    values[rec.slot] = max(minimum, min(maximum, raw_new))
                    clamped += int(values[rec.slot] != raw_new)
                if key in ("exp", "gold"):
                    group = self.project.group_by_path(path)
                    values, count = fit_group_reward_raws(records, key, values, group.dll_number, group.bgm_id)
                    adjusted += count
                proposals[path] = values
            return proposals, clamped, adjusted

        def preview_bulk(self) -> None:
            if not self.project: return
            try:
                key, minimum, maximum = self._bulk_key(); expr = self.bulk_expr_var.get()
                proposals, clamped, adjusted = self._bulk_proposals(key, minimum, maximum, expr)
                lines = []
                for rec in self.project.monsters[:12]:
                    lines.append(f"{rec.name}: {rec.value(key)} → {proposals[rec.dll_path][rec.slot]}")
                lines.append(f"\n범위 제한 {clamped}건 / 오버플로 방지 자동 조정 {adjusted}건")
                messagebox.showinfo("일괄 수식 미리보기", "\n".join(lines))
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

        def apply_bulk(self) -> None:
            if not self.project: return
            key, minimum, maximum = self._bulk_key(); expr = self.bulk_expr_var.get()
            if not messagebox.askyesno(APP_NAME, f"전체 {len(self.project.monsters)}개 몬스터의 {self.bulk_stat_var.get()}에 '{expr}'를 적용할까요?"): return
            try:
                proposals, clamped, adjusted = self._bulk_proposals(key, minimum, maximum, expr)
                by_path: dict[Path, list[MonsterRecord]] = {}
                for rec in self.project.monsters: by_path.setdefault(rec.dll_path, []).append(rec)
                changed = 0
                for path, records in by_path.items():
                    data = bytearray(path.read_bytes())
                    for rec in records:
                        new = proposals[path][rec.slot]
                        off, size, _ = MONSTER_FIELDS[key]
                        if key == "hp": p16(data, rec.file_offset + 4, new); p16(data, rec.file_offset + 6, new)
                        elif size == 1: data[rec.file_offset + off] = new
                        else: p16(data, rec.file_offset + off, new)
                        changed += 1
                    atomic_write(path, bytes(data), True)
                self.reload_project()
                messagebox.showinfo(APP_NAME, f"{changed}개 수정 완료. 범위 제한 {clamped}건, 오버플로 방지 자동 조정 {adjusted}건.")
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

        def export_monsters_csv(self) -> None:
            if not self.project: return
            path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="ED2_MONSTERS.csv", filetypes=[("CSV","*.csv")])
            if path: self.project.export_monsters_csv(Path(path))

        def import_monsters_csv_gui(self) -> None:
            if not self.project: return
            path = filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
            if not path or not messagebox.askyesno(APP_NAME, "CSV의 몬스터 값을 적용할까요?"): return
            try: count = self.project.import_monsters_csv(Path(path)); self.populate_all(); messagebox.showinfo(APP_NAME, f"{count}개 행 적용 완료")
            except Exception as exc: messagebox.showerror(APP_NAME, str(exc))

        # Groups and drops ------------------------------------------------
        def _build_groups_tab(self) -> None:
            tab = ttk.Frame(self.nb); self.nb.add(tab, text="전투 그룹·드롭")
            left, right = self._make_pane(tab)
            bar = ttk.Frame(left); bar.pack(fill="x", pady=(0,6))
            self.group_search = tk.StringVar(); ttk.Label(bar, text="검색").pack(side="left")
            e = ttk.Entry(bar, textvariable=self.group_search); e.pack(side="left", fill="x", expand=True, padx=6); e.bind("<KeyRelease>", lambda _e: self.populate_groups())
            ttk.Button(bar, text="CSV 내보내기", command=self.export_groups_csv).pack(side="left")
            ttk.Button(bar, text="CSV 가져오기", command=self.import_groups_csv_gui).pack(side="left", padx=(4,0))
            cols = ("dll","monsters","drop","initial","runtime","bgm","gfx0","gfx1")
            self.group_tree = self._tree(left, cols, selectmode="browse")
            for col,label,width in (("dll","DLL",80),("monsters","구성 몬스터",290),("drop","_MO_ATT_TRS 드롭",220),("initial","초기 %",70),("runtime","실제/AI 변경",175),("bgm","BGM",55),("gfx0","주 외형",75),("gfx1","보조 외형",75)):
                self.group_tree.heading(col,text=label); self.group_tree.column(col,width=width,minwidth=45,anchor="w" if col in ("monsters","drop") else "center")
            self.group_tree.bind("<<TreeviewSelect>>", lambda _e: self.show_group())
            ttk.Label(right,text="전투 그룹 상세",style="Title.TLabel").pack(anchor="w")
            self.group_names_var=tk.StringVar(); ttk.Label(right,textvariable=self.group_names_var,wraplength=700).pack(anchor="w",pady=(4,10))
            form=ttk.Frame(right); form.pack(fill="x")
            self.group_vars={k:tk.StringVar() for k in ("graphic_id0","graphic_addr0","graphic_id1","graphic_addr1","drop_item_id","drop_chance","bgm_id")}
            rows=[("graphic_id0","_MO_CHR_NO0 주 외형 ID"),("graphic_addr0","_MO_CHR_ADR0"),("graphic_id1","_MO_CHR_NO1 보조 외형 ID"),("graphic_addr1","_MO_CHR_ADR1"),("drop_item_id","_MO_ATT_TRS 드롭 아이템 ID"),("drop_chance","_MO_ATT_TRP 드롭 확률 %"),("bgm_id","_MO_ATT_BGM")]
            for row,(key,label) in enumerate(rows):
                ttk.Label(form,text=label).grid(row=row,column=0,sticky="w",pady=3); ttk.Entry(form,textvariable=self.group_vars[key],width=34).grid(row=row,column=1,sticky="ew",padx=(8,0),pady=3)
            form.columnconfigure(1,weight=1)
            self.drop_name_var=tk.StringVar(); ttk.Label(right,textvariable=self.drop_name_var,style="Section.TLabel").pack(anchor="w",pady=(8,4))
            runtime_box=ttk.LabelFrame(right,text="전투 중 AI 드롭 확률",padding=8);runtime_box.pack(fill="x",pady=(4,8))
            self.dynamic_drop_summary_var=tk.StringVar(value="AI 변경 없음")
            ttk.Label(runtime_box,textvariable=self.dynamic_drop_summary_var,wraplength=720).pack(anchor="w",pady=(0,6))
            self.dynamic_drop_tree=self._tree(runtime_box,("operation","value","condition","location","note"),selectmode="browse",height=4)
            for col,label,width in (("operation","동작",115),("value","값",65),("condition","적용 조건",230),("location","위치",105),("note","설명",370)):
                self.dynamic_drop_tree.heading(col,text=label);self.dynamic_drop_tree.column(col,width=width,anchor="w" if col in ("operation","condition","note") else "center")
            self.dynamic_drop_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_dynamic_drop_reference())
            runtime_edit=ttk.Frame(runtime_box);runtime_edit.pack(fill="x",pady=(6,0))
            ttk.Label(runtime_edit,text="선택 AI 변경값 %").pack(side="left")
            self.dynamic_drop_value_var=tk.StringVar();self.dynamic_drop_entry=ttk.Entry(runtime_edit,textvariable=self.dynamic_drop_value_var,width=8,state="disabled");self.dynamic_drop_entry.pack(side="left",padx=6)
            self.dynamic_drop_save_button=ttk.Button(runtime_edit,text="AI 값 저장 (.bak)",command=self.save_dynamic_drop_reference,state="disabled");self.dynamic_drop_save_button.pack(side="left")
            ttk.Label(runtime_edit,text="즉시값 설정 명령만 편집할 수 있습니다.").pack(side="left",padx=8)
            condition_edit=ttk.Frame(runtime_box);condition_edit.pack(fill="x",pady=(6,0))
            ttk.Label(condition_edit,text="선택 HP 발동 조건 %").pack(side="left")
            self.ai_condition_value_var=tk.StringVar();self.ai_condition_entry=ttk.Entry(condition_edit,textvariable=self.ai_condition_value_var,width=8,state="disabled");self.ai_condition_entry.pack(side="left",padx=6)
            self.ai_condition_save_button=ttk.Button(condition_edit,text="HP 조건 저장 (.bak)",command=self.save_ai_condition,state="disabled");self.ai_condition_save_button.pack(side="left")
            self.ai_condition_note_var=tk.StringVar(value="확인된 CALC_DMG_PST 비교 패턴에서만 편집할 수 있습니다.")
            ttk.Label(condition_edit,textvariable=self.ai_condition_note_var,wraplength=430).pack(side="left",padx=8)
            calc_box=ttk.LabelFrame(right,text="실제 드롭 확률 계산기",padding=8);calc_box.pack(fill="x",pady=(4,8))
            calc_row=ttk.Frame(calc_box);calc_row.pack(fill="x")
            ttk.Label(calc_row,text="전투 경로").pack(side="left")
            self.drop_scenario_var=tk.StringVar();self.drop_scenario_combo=ttk.Combobox(calc_row,textvariable=self.drop_scenario_var,state="readonly",width=48);self.drop_scenario_combo.pack(side="left",padx=6,fill="x",expand=True)
            self.drop_scenario_combo.bind("<<ComboboxSelected>>",lambda _e:self.update_drop_calculator())
            ttk.Label(calc_row,text="반복 전투 수").pack(side="left",padx=(8,0))
            self.drop_battles_var=tk.StringVar(value="1");battle_entry=ttk.Entry(calc_row,textvariable=self.drop_battles_var,width=8);battle_entry.pack(side="left",padx=6);battle_entry.bind("<KeyRelease>",lambda _e:self.update_drop_calculator())
            self.drop_calc_result_var=tk.StringVar(value="그룹을 선택하면 계산합니다.")
            ttk.Label(calc_box,textvariable=self.drop_calc_result_var,wraplength=720).pack(anchor="w",pady=(6,0))
            ttk.Label(right,text="AI·훅 포인터는 코드 주소이므로 이 화면에서는 읽기 전용입니다.").pack(anchor="w")
            hook_box=ttk.Frame(right); hook_box.pack(fill="both",expand=True,pady=(4,8))
            self.group_hook_tree=self._tree(hook_box,("symbol","offset","desc"),selectmode="browse")
            for col,label,width in (("symbol","심볼",160),("offset","오프셋",90),("desc","설명",350)):
                self.group_hook_tree.heading(col,text=label);self.group_hook_tree.column(col,width=width,anchor="w")
            btn=ttk.Frame(right);btn.pack(fill="x")
            ttk.Button(btn,text="그룹 저장 (.bak)",command=self.save_group).pack(side="left")
            ttk.Button(btn,text="이 도구 변경만 복원",command=self.restore_current_group).pack(side="left",padx=6)

        def populate_groups(self) -> None:
            self.group_tree.delete(*self.group_tree.get_children())
            if not self.project:return
            needle=self.group_search.get().strip().lower()
            for index,g in enumerate(self.project.groups):
                if needle and needle not in f"{g.dll_path.name} {' '.join(g.monster_names)} {self.project.item_display(g.drop_item_id)} {g.dynamic_drop_summary}".lower():continue
                runtime=" / ".join(f"{ref.value}%" for ref in g.dynamic_drop_writes if ref.value is not None) or ("참조" if g.dynamic_drop_refs else "-")
                self.group_tree.insert("","end",iid=str(index),values=(g.dll_path.stem," / ".join(g.monster_names),self.project.item_display(g.drop_item_id),g.drop_chance,runtime,g.bgm_id,f"{g.graphic_id0:04X}",f"{g.graphic_id1:04X}"))

        def show_group(self) -> None:
            if not self.project:return
            sel=self.group_tree.selection()
            if not sel:return
            g=self.project.groups[int(sel[0])];self.current_group=g;self.group_names_var.set(" / ".join(g.monster_names))
            for key in ("graphic_id0","graphic_addr0","graphic_id1","graphic_addr1"):
                self.group_vars[key].set(f"0x{getattr(g,key):04X}")
            self.group_vars["drop_item_id"].set(str(g.drop_item_id));self.group_vars["drop_chance"].set(str(g.drop_chance));self.group_vars["bgm_id"].set(str(g.bgm_id))
            self.drop_name_var.set("드롭: "+self.project.item_display(g.drop_item_id)+" · "+g.dynamic_drop_summary)
            self.current_dynamic_drop_ref=None;self.current_ai_condition=None;self.dynamic_drop_value_var.set("");self.ai_condition_value_var.set("")
            self.dynamic_drop_entry.configure(state="disabled");self.dynamic_drop_save_button.configure(state="disabled")
            self.ai_condition_entry.configure(state="disabled");self.ai_condition_save_button.configure(state="disabled")
            self.ai_condition_note_var.set("확인된 CALC_DMG_PST 비교 패턴에서만 편집할 수 있습니다.")
            self.dynamic_drop_tree.delete(*self.dynamic_drop_tree.get_children())
            if g.dynamic_drop_refs:
                self.dynamic_drop_summary_var.set(g.dynamic_drop_summary+" · 초기값만 보고 최종 드롭률로 판단하면 안 됩니다.")
                for index,ref in enumerate(g.dynamic_drop_refs):
                    condition=g.condition_for_drop(ref)
                    condition_text=condition.condition_text if condition else "-"
                    self.dynamic_drop_tree.insert("","end",iid=str(index),values=(ref.operation,ref.value_text,condition_text,ref.location,ref.note))
            else:
                self.dynamic_drop_summary_var.set(f"초기 {g.drop_chance}% · 전투 AI의 _MO_ATT_TRP 참조/변경 코드가 검출되지 않았습니다.")
            self.drop_scenario_values=list(g.drop_scenarios)
            scenario_labels=[label for label,_chance in self.drop_scenario_values]
            self.drop_scenario_combo.configure(values=scenario_labels)
            self.drop_scenario_var.set(scenario_labels[0] if scenario_labels else "")
            self.update_drop_calculator()
            self.group_hook_tree.delete(*self.group_hook_tree.get_children())
            for symbol,value,description in g.hook_rows(): self.group_hook_tree.insert("","end",values=(symbol,f"0x{value:04X}",description))

        def show_dynamic_drop_reference(self) -> None:
            if not self.current_group:return
            sel=self.dynamic_drop_tree.selection()
            if not sel:return
            index=int(sel[0])
            if not 0<=index<len(self.current_group.dynamic_drop_refs):return
            ref=self.current_group.dynamic_drop_refs[index];self.current_dynamic_drop_ref=ref
            self.dynamic_drop_value_var.set("" if ref.value is None else str(ref.value))
            state="normal" if ref.editable else "disabled"
            self.dynamic_drop_entry.configure(state=state);self.dynamic_drop_save_button.configure(state=state)
            condition=self.current_group.condition_for_drop(ref);self.current_ai_condition=condition
            if condition:
                self.ai_condition_value_var.set(f"{condition.threshold_percent:.1f}")
                condition_state="normal" if condition.editable else "disabled"
                self.ai_condition_entry.configure(state=condition_state);self.ai_condition_save_button.configure(state=condition_state)
                self.ai_condition_note_var.set(condition.note)
            else:
                self.ai_condition_value_var.set("");self.ai_condition_entry.configure(state="disabled");self.ai_condition_save_button.configure(state="disabled")
                self.ai_condition_note_var.set("이 AI 드롭 변경과 연결된 편집 가능한 HP 조건은 검출되지 않았습니다.")

        def update_drop_calculator(self) -> None:
            if not self.current_group or not hasattr(self,"drop_scenario_values"):
                self.drop_calc_result_var.set("그룹을 선택하면 계산합니다.");return
            try:
                battles=parse_number(self.drop_battles_var.get(),1,1000000,"battle count")
                selected=self.drop_scenario_var.get()
                chance=next((value for label,value in self.drop_scenario_values if label==selected),self.current_group.drop_chance)
                result=drop_probability_summary(chance,battles)
                self.drop_calc_result_var.set(
                    f"이 경로의 전투당 확률 {chance}% · {battles:,}회 안에 1개 이상 획득 {result['at_least_one_percent']:.4f}% · "
                    f"한 번도 못 얻을 확률 {result['none_percent']:.4f}% · 기대 획득 수 {result['expected_drops']:.3f}개"
                )
            except Exception as exc:
                self.drop_calc_result_var.set(f"입력 확인: {exc}")

        def save_ai_condition(self) -> None:
            if not self.project or not self.current_group or not self.current_ai_condition:return
            try:
                percent=float(self.ai_condition_value_var.get().strip())
                group_path=self.current_group.dll_path
                drop_instruction=self.current_ai_condition.linked_drop_instruction_offset
                condition_instruction=(self.current_ai_condition.segment_index,self.current_ai_condition.instruction_offset)
                raw=patch_ai_condition_threshold(self.current_ai_condition,percent,True);self.reload_project()
                for i,g in enumerate(self.project.groups if self.project else []):
                    if g.dll_path==group_path and self.group_tree.exists(str(i)):
                        self.group_tree.selection_set(str(i));self.group_tree.see(str(i));self.show_group()
                        for j,ref in enumerate(g.dynamic_drop_refs):
                            if ref.segment_index==condition_instruction[0] and ref.instruction_offset==drop_instruction:
                                self.dynamic_drop_tree.selection_set(str(j));self.dynamic_drop_tree.see(str(j));self.show_dynamic_drop_reference();break
                        break
                messagebox.showinfo(APP_NAME,f"HP 조건을 {hp_ratio_raw_to_percent(raw):.1f}% (원시 0x{raw:02X})로 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def save_dynamic_drop_reference(self) -> None:
            if not self.project or not self.current_group or not self.current_dynamic_drop_ref:return
            try:
                value=parse_number(self.dynamic_drop_value_var.get(),0,100,"AI drop chance")
                group_path=self.current_group.dll_path
                instruction=(self.current_dynamic_drop_ref.segment_index,self.current_dynamic_drop_ref.instruction_offset)
                patch_dynamic_drop_reference(self.current_dynamic_drop_ref,value,True);self.reload_project()
                for i,g in enumerate(self.project.groups if self.project else []):
                    if g.dll_path==group_path:
                        if self.group_tree.exists(str(i)):
                            self.group_tree.selection_set(str(i));self.group_tree.see(str(i));self.show_group()
                            for j,ref in enumerate(g.dynamic_drop_refs):
                                if (ref.segment_index,ref.instruction_offset)==instruction:
                                    self.dynamic_drop_tree.selection_set(str(j));self.dynamic_drop_tree.see(str(j));self.show_dynamic_drop_reference();break
                        break
                messagebox.showinfo(APP_NAME,"전투 중 AI 드롭 확률 변경값을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def save_group(self) -> None:
            if not self.project or not self.current_group:return
            try:
                values={"graphic_id0":parse_number(self.group_vars["graphic_id0"].get(),0,0xFFFF,"graphic_id0"),"graphic_addr0":parse_number(self.group_vars["graphic_addr0"].get(),0,0xFFFF,"graphic_addr0"),"graphic_id1":parse_number(self.group_vars["graphic_id1"].get(),0,0xFFFF,"graphic_id1"),"graphic_addr1":parse_number(self.group_vars["graphic_addr1"].get(),0,0xFFFF,"graphic_addr1"),"drop_item_id":parse_number(self.group_vars["drop_item_id"].get(),0,255,"drop item"),"drop_chance":parse_number(self.group_vars["drop_chance"].get(),0,100,"drop chance"),"bgm_id":parse_number(self.group_vars["bgm_id"].get(),0,255,"BGM ID")}
                known={a.asset_id for a in self.project.assets}
                for key in ("graphic_id0","graphic_id1"):
                    if values[key]!=0xFFFF and values[key] not in known:raise ValueError(f"C_MO{values[key]:03X}.BZH does not exist")
                path=self.current_group.dll_path;patch_group(self.current_group,values);self.reload_project()
                for i,g in enumerate(self.project.groups if self.project else []):
                    if g.dll_path==path:
                        if self.group_tree.exists(str(i)):
                            self.group_tree.selection_set(str(i));self.group_tree.see(str(i));self.show_group()
                        break
                messagebox.showinfo(APP_NAME,"전투 그룹을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def restore_current_group(self) -> None:
            if not self.current_group:return
            try:restore_backup(self.current_group.dll_path);self.reload_project()
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def export_groups_csv(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".csv",initialfile="ED2_MONSTER_GROUPS.csv",filetypes=[("CSV","*.csv")])
            if path:self.project.export_groups_csv(Path(path))

        def import_groups_csv_gui(self) -> None:
            if not self.project:return
            path=filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
            if not path or not messagebox.askyesno(APP_NAME,"CSV의 전투 그룹 값을 적용할까요?"):return
            try:count=self.project.import_groups_csv(Path(path));self.populate_all();messagebox.showinfo(APP_NAME,f"{count}개 그룹 적용 완료")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Items -----------------------------------------------------------
        def _build_items_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="아이템")
            left,right=self._make_pane(tab)
            bar=ttk.Frame(left);bar.pack(fill="x",pady=(0,6));self.item_search=tk.StringVar();ttk.Label(bar,text="검색").pack(side="left")
            e=ttk.Entry(bar,textvariable=self.item_search);e.pack(side="left",fill="x",expand=True,padx=6);e.bind("<KeyRelease>",lambda _e:self.populate_items())
            ttk.Button(bar,text="일반 CSV",command=self.export_items_csv).pack(side="left")
            ttk.Button(bar,text="이벤트 CSV",command=self.export_event_items_csv).pack(side="left",padx=(4,0))
            ttk.Button(bar,text="일반 CSV 가져오기",command=self.import_items_csv_gui).pack(side="left",padx=(4,0))
            cols=("kind","id","name","price","kouka","magic","koka_num","magic_num","mode","type")
            self.item_tree=self._tree(left,cols,selectmode="browse")
            for col,label,width in (("kind","구분",65),("id","ID",45),("name","이름",190),("price","가격",85),("kouka","ITEM_KOUKA",210),("magic","ITEM_MAGIC",85),("koka_num","ITEM_KOKA_NUM",110),("magic_num","ITEM_MAGIC_NUM",120),("mode","주문 위력 방식",145),("type","ITEM_TYPE",80)):
                self.item_tree.heading(col,text=label);self.item_tree.column(col,width=width,minwidth=45,anchor="w" if col in ("name","kouka") else "center")
            self.item_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_item())
            ttk.Label(right,text="아이템 상세",style="Title.TLabel").pack(anchor="w")
            form=ttk.Frame(right);form.pack(fill="x",pady=(8,0))
            self.item_vars={k:tk.StringVar() for k in ("id","name","price","stat_group","effect_id","power_raw","secondary_raw","type_mask")}
            rows=[("id","아이템 ID"),("name","ITEM_NAME (CP949 최대 14바이트)"),("price","ITEM_COST"),("stat_group","ITEM_KOUKA 그룹 0..7"),("effect_id","ITEM_MAGIC ID 0..31"),("power_raw","ITEM_KOKA_NUM 원시값 (실제 ×5)"),("secondary_raw","ITEM_MAGIC_NUM 원시값 (고정: 1=10 / 비례: 1=5%)"),("type_mask","ITEM_TYPE 마스크")]
            self.item_entries={}
            for row,(key,label) in enumerate(rows):
                ttk.Label(form,text=label).grid(row=row,column=0,sticky="w",pady=3);ent=ttk.Entry(form,textvariable=self.item_vars[key],width=38);ent.grid(row=row,column=1,sticky="ew",padx=(8,0),pady=3);self.item_entries[key]=ent
            mode_row=len(rows)
            ttk.Label(form,text="아이템 주문 위력 방식").grid(row=mode_row,column=0,sticky="w",pady=3)
            self.item_magic_mode_var=tk.StringVar(value=ITEM_MAGIC_MODE_FIXED_LABEL)
            self.item_mode_combo=ttk.Combobox(form,textvariable=self.item_magic_mode_var,state="readonly",values=(ITEM_MAGIC_MODE_FIXED_LABEL,ITEM_MAGIC_MODE_PROPORTIONAL_LABEL),width=35)
            self.item_mode_combo.grid(row=mode_row,column=1,sticky="ew",padx=(8,0),pady=3)
            form.columnconfigure(1,weight=1);self.item_entries["id"].configure(state="readonly")
            self.item_effective_var=tk.StringVar();ttk.Label(right,textvariable=self.item_effective_var,style="Section.TLabel",wraplength=720).pack(anchor="w",pady=(10,3))
            self.item_usage_var=tk.StringVar();ttk.Label(right,textvariable=self.item_usage_var,wraplength=720).pack(anchor="w",pady=(0,8))
            ttk.Label(right,text="각 일반 아이템에서 고정 위력과 플레이어 마력 비례를 독립적으로 선택할 수 있습니다. 선택 후 아이템 저장을 누르면 필요한 ED2MAIN 패치와 해당 아이템 모드가 함께 저장됩니다.",wraplength=720).pack(anchor="w",pady=(0,8))
            scaling=ttk.LabelFrame(right,text="아이템별 주문 위력 선택 기능",padding=10);scaling.pack(fill="x",pady=(0,10))
            self.item_magic_scaling_var=tk.StringVar(value="게임 폴더를 열면 현재 상태를 표시합니다.")
            ttk.Label(scaling,textvariable=self.item_magic_scaling_var,wraplength=680).pack(anchor="w")
            scaling_btn=ttk.Frame(scaling);scaling_btn.pack(fill="x",pady=(8,0))
            ttk.Button(scaling_btn,text="개별 선택 기능 설치",command=self.install_item_magic_mode_support).pack(side="left")
            ttk.Button(scaling_btn,text="원본 코드 복원 (모두 고정)",command=self.restore_item_magic_mode_support).pack(side="left",padx=6)
            btn=ttk.Frame(right);btn.pack(fill="x")
            ttk.Button(btn,text="아이템 저장 (EXE.bak)",command=self.save_item).pack(side="left")
            ttk.Button(btn,text="이 도구 변경만 복원",command=self.restore_exe).pack(side="left",padx=6)

        def populate_items(self) -> None:
            self.item_tree.delete(*self.item_tree.get_children())
            self.update_item_magic_scaling_ui()
            if not self.project:return
            needle=self.item_search.get().strip().lower()
            for item in self.project.items:
                mode_label=item_magic_mode_label(item.magic_mode)
                if needle and needle not in f"{item.item_id} {item.name} {item.stat_label} {mode_label}".lower():continue
                magic_num=f"{item.secondary_effective}%" if item.magic_mode=="proportional" else item.secondary_effective
                self.item_tree.insert("","end",iid=f"r:{item.item_id}",values=("일반",item.item_id,item.name,item.price,item.stat_label,item.effect_id,item.power_effective,magic_num,mode_label,f"0x{item.type_mask:02X}"))
            for item in self.project.event_items:
                if needle and needle not in f"{item.item_id} {item.name} event 이벤트".lower():continue
                self.item_tree.insert("","end",iid=f"e:{item.item_id}",values=("이벤트",item.item_id,item.name,"-","공통 특수 파라미터","-","-","-","-","-"))

        def show_item(self) -> None:
            if not self.project:return
            sel=self.item_tree.selection()
            if not sel:return
            kind,raw_id=sel[0].split(":",1);item_id=int(raw_id)
            if kind=="r":
                item=self.project.items[item_id];self.current_item=item
                values={"id":item.item_id,"name":item.name,"price":item.price,"stat_group":item.stat_group,"effect_id":item.effect_id,"power_raw":item.power_raw,"secondary_raw":item.secondary_raw,"type_mask":f"0x{item.type_mask:02X}"}
                for key,value in values.items():self.item_vars[key].set(str(value))
                for key,entry in self.item_entries.items():entry.configure(state="readonly" if key=="id" else "normal")
                self.item_magic_mode_var.set(item_magic_mode_label(item.magic_mode));self.item_mode_combo.configure(state="readonly")
                if item.magic_mode=="proportional":
                    magic=self.project.magics[item.effect_id]
                    applied_multiplier=magic.multiplier or 10
                    combined=item.secondary_effective*applied_multiplier/100
                    magic_text=(
                        f"[플레이어 마력 비례] ITEM_MAGIC_NUM {item.secondary_raw} → 플레이어 마력의 {item.secondary_effective}% "
                        f"(가상 마력=floor(플레이어 마력×{item.secondary_effective}/100)) · "
                        f"{magic.name} 적용 배율 {applied_multiplier}% → 최종 기준 약 플레이어 마력의 {combined:g}%"
                    )
                else:
                    magic_text=f"[고정 위력] ITEM_MAGIC_NUM {item.secondary_raw}×10={item.secondary_effective} 고정 가상 마력"
                self.item_effective_var.set(f"{item.stat_label} · ITEM_KOUKA offset 0x{item.item_kouka_offset:02X} · ITEM_KOKA_NUM {item.power_raw}×5={item.power_effective} · {magic_text} · packed 0x{item.packed:02X}")
            else:
                item=self.project.event_items[item_id-EVENT_ITEM_ID_BASE];self.current_item=item
                for key in self.item_vars:self.item_vars[key].set("")
                self.item_vars["id"].set(str(item.item_id));self.item_vars["name"].set(item.name)
                for key,entry in self.item_entries.items():entry.configure(state="normal" if key=="name" else "readonly")
                self.item_magic_mode_var.set("이벤트 아이템은 해당 없음");self.item_mode_combo.configure(state="disabled")
                self.item_effective_var.set(f"이벤트 아이템 ID {item.item_id} · ED2MAIN.EXE 0x{item.file_offset:X} · 이름만 안전 편집 가능")
            uses=[f"M_{g.dll_number:03X} ({g.dynamic_drop_summary})" for g in self.project.groups if g.drop_item_id==item_id]
            self.item_usage_var.set("드롭 사용처: "+(", ".join(uses) if uses else "없음"))

        def update_item_magic_scaling_ui(self) -> None:
            if not hasattr(self,"item_magic_scaling_var"):return
            if not self.project:
                self.item_magic_scaling_var.set("게임 폴더를 열면 현재 상태를 표시합니다.")
                return
            state=self.project.item_magic_scaling
            if state=="per_item":
                proportional=sum(item.magic_mode=="proportional" for item in self.project.items)
                self.item_magic_scaling_var.set(
                    f"개별 선택 기능 적용됨: 비례 {proportional}개 / 고정 {ITEM_COUNT-proportional}개. "
                    "비례 모드의 ITEM_MAGIC_NUM은 원시값 1당 5%입니다. "
                    "각 아이템 상세의 '아이템 주문 위력 방식'에서 독립적으로 변경할 수 있습니다."
                )
            elif state=="per_item_x10":
                self.item_magic_scaling_var.set(
                    "구버전 개별 비례 패치(10% 단위) 상태입니다. "+
                    "개별 선택 기능 설치 또는 아이템 저장 시 비례 아이템 원시값을 자동 변환해 실효 비율을 유지하면서 5% 단위로 마이그레이션합니다."
                )
            elif state=="legacy_proportional":
                self.item_magic_scaling_var.set(
                    "v0.9.0 전역 비례 패치 상태입니다. 아이템 하나를 저장하거나 개별 선택 기능을 설치하면 "
                    "현재 동작을 보존하여 모든 아이템을 비례로 시작한 뒤 개별 설정으로 전환합니다."
                )
            elif state=="fixed":
                self.item_magic_scaling_var.set(
                    "원본 코드 상태: 현재 모든 아이템이 고정 위력입니다. 아이템에서 비례를 선택하고 저장하면 "
                    "개별 선택 기능을 자동 설치하며, 나머지 아이템은 고정 상태를 유지합니다."
                )
            else:
                self.item_magic_scaling_var.set(
                    "알 수 없는 코드 상태: 다른 ED2MAIN 패치와 충돌할 수 있어 개별 선택 기능을 적용하지 않습니다."
                )

        def install_item_magic_mode_support(self) -> None:
            if not self.project:return
            if not messagebox.askyesno(APP_NAME,"아이템별 고정/비례 선택 기능을 ED2MAIN.EXE에 설치할까요?\n비례 모드는 ITEM_MAGIC_NUM 원시값 1당 5%로 저장됩니다.\n구버전 10% 단위 패치는 실효 비율을 유지한 채 자동 변환합니다."):return
            try:
                install_item_magic_mode_patch(self.project.exe,None,True)
                self.reload_project();messagebox.showinfo(APP_NAME,"아이템별 주문 위력 선택 기능을 설치했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def restore_item_magic_mode_support(self) -> None:
            if not self.project:return
            if not messagebox.askyesno(APP_NAME,"개별 선택 패치를 제거하고 원본 코드로 복원할까요?\n모든 아이템이 고정 위력으로 동작합니다."):return
            try:
                restore_item_magic_original(self.project.exe,True)
                self.reload_project();messagebox.showinfo(APP_NAME,"원본 아이템 주문 계산으로 복원했습니다. 모든 아이템은 고정 위력입니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def save_item(self) -> None:
            if not self.project or not self.current_item:return
            try:
                item_id=self.current_item.item_id
                if isinstance(self.current_item,EventItemRecord):
                    patch_event_item(self.project.exe,item_id,self.item_vars["name"].get())
                    iid=f"e:{item_id}"
                else:
                    values={"name":self.item_vars["name"].get(),"price":parse_number(self.item_vars["price"].get(),0,10**12,"price"),"stat_group":parse_number(self.item_vars["stat_group"].get(),0,7,"ITEM_KOUKA"),"effect_id":parse_number(self.item_vars["effect_id"].get(),0,31,"ITEM_MAGIC"),"power_raw":parse_number(self.item_vars["power_raw"].get(),0,255,"ITEM_KOKA_NUM"),"secondary_raw":parse_number(self.item_vars["secondary_raw"].get(),0,255,"ITEM_MAGIC_NUM"),"type_mask":parse_number(self.item_vars["type_mask"].get(),0,255,"ITEM_TYPE"),"magic_mode":normalize_item_magic_mode(self.item_magic_mode_var.get())}
                    patch_item(self.project.exe,item_id,values);iid=f"r:{item_id}"
                self.reload_project()
                if self.item_tree.exists(iid):
                    self.item_tree.selection_set(iid);self.item_tree.see(iid);self.show_item()
                messagebox.showinfo(APP_NAME,"아이템을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def restore_exe(self) -> None:
            if not self.project:return
            if not messagebox.askyesno(APP_NAME,"ED2MAIN.EXE에서 Mod Studio가 변경한 바이트만 복원할까요?\n텍스트·엔딩 패치는 유지됩니다."):return
            try:restore_backup(self.project.exe);self.reload_project()
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def export_items_csv(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".csv",initialfile="ED2_ITEMS.csv",filetypes=[("CSV","*.csv")])
            if path:self.project.export_items_csv(Path(path))

        def export_event_items_csv(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".csv",initialfile="ED2_EVENT_ITEMS.csv",filetypes=[("CSV","*.csv")])
            if path:self.project.export_event_items_csv(Path(path))

        def import_items_csv_gui(self) -> None:
            if not self.project:return
            path=filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
            if not path or not messagebox.askyesno(APP_NAME,"CSV의 일반 아이템 테이블을 적용할까요?"):return
            try:count=self.project.import_items_csv(Path(path));self.populate_all();messagebox.showinfo(APP_NAME,f"{count}개 일반 아이템 적용 완료")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Player initial equipment ---------------------------------------
        def _build_player_equipment_tab(self) -> None:
            tab = ttk.Frame(self.nb); self.nb.add(tab, text="초기 장비")
            outer, panel = self._scrollable_panel(tab, padding=14); outer.pack(fill="both", expand=True)
            ttk.Label(panel, text="플레이어 초기 장비", style="Title.TLabel").pack(anchor="w")
            ttk.Label(
                panel,
                text=(
                    "ED2MAIN.EXE의 PL_DATA_1~4 기본 플레이어 레코드를 직접 편집합니다. "
                    "아트라스·란도·플로라·신디의 무기/갑옷/방패/반지·부적을 지정할 수 있습니다. "
                    "아이템 종류가 슬롯과 맞지 않으면 저장되지 않습니다."
                ),
                wraplength=980,
            ).pack(anchor="w", pady=(4, 4))
            ttk.Label(
                panel,
                text="주의: 이 값은 새 게임/캐릭터 초기 데이터용입니다. 이미 저장된 세이브의 장비는 세이브 데이터가 우선할 수 있습니다.",
                style="Danger.TLabel", wraplength=980,
            ).pack(anchor="w", pady=(0, 12))

            table = ttk.Frame(panel); table.pack(fill="x")
            headers = ("캐릭터", "무기", "갑옷", "방패", "반지·부적")
            for col, label in enumerate(headers):
                ttk.Label(table, text=label, style="Section.TLabel").grid(row=0, column=col, sticky="w", padx=4, pady=(0, 5))
            self.player_equip_vars = {}
            self.player_equip_combos = {}
            for row, (_index, name, _export) in enumerate(PLAYER_DATA_EXPORTS, start=1):
                ttk.Label(table, text=name, width=10).grid(row=row, column=0, sticky="w", padx=4, pady=4)
                for col, slot in enumerate(PLAYER_EQUIPMENT_OFFSETS, start=1):
                    var = tk.StringVar()
                    combo = ttk.Combobox(table, textvariable=var, state="readonly", width=28)
                    combo.grid(row=row, column=col, sticky="ew", padx=4, pady=4)
                    self.player_equip_vars[(_index, slot)] = var
                    self.player_equip_combos[(_index, slot)] = combo
            for col in range(1, 5): table.columnconfigure(col, weight=1)

            self.player_equip_status_var = tk.StringVar(value="게임 폴더를 열면 PL_DATA_1~4를 읽습니다.")
            ttk.Label(panel, textvariable=self.player_equip_status_var, wraplength=980).pack(anchor="w", pady=(12, 6))
            buttons = ttk.Frame(panel); buttons.pack(fill="x")
            ttk.Button(buttons, text="4명 초기 장비 저장 (EXE.bak)", command=self.save_player_equipment_gui).pack(side="left")
            ttk.Button(buttons, text="현재 파일에서 다시 읽기", command=self.populate_player_equipment).pack(side="left", padx=6)
            ttk.Button(buttons, text="CSV 가져오기", command=self.import_player_equipment_csv_gui).pack(side="left")
            ttk.Button(buttons, text="CSV 내보내기", command=self.export_player_equipment_csv_gui).pack(side="left", padx=(6,0))
            preset = ttk.Frame(panel); preset.pack(fill="x", pady=(6,0))
            ttk.Button(preset, text="프리셋 1 · 기본설정 적용", command=lambda:self.apply_player_equipment_preset_gui(1)).pack(side="left")
            ttk.Button(preset, text="프리셋 2 · 1편 복원 적용", command=lambda:self.apply_player_equipment_preset_gui(2)).pack(side="left", padx=6)

            info = ttk.LabelFrame(panel, text="확인된 구조", padding=10); info.pack(fill="x", pady=(14, 0))
            ttk.Label(
                info,
                text=(
                    "PL_DATA 레코드 크기 0x40 · 장비 오프셋: +0x19 무기 / +0x1A 갑옷 / +0x1B 방패 / +0x1C 반지·부적. "
                    "RESTORE_PLAYER가 이 네 ID를 읽어 플레이어 능력치를 재계산합니다."
                ), wraplength=980,
            ).pack(anchor="w")

        @staticmethod
        def _equipment_combo_item_id(text: str) -> int:
            try:
                return int(text.split(" ", 1)[0])
            except Exception as exc:
                raise ValueError(f"장비 항목을 해석할 수 없습니다: {text!r}") from exc

        def populate_player_equipment(self) -> None:
            if not hasattr(self, "player_equip_combos"):
                return
            if not self.project:
                return
            option_maps: dict[str, list[str]] = {}
            for slot in PLAYER_EQUIPMENT_OFFSETS:
                option_maps[slot] = [self.project.item_display(item.item_id) for item in self.project.equipment_item_options(slot)]
            for rec in self.project.player_equipment:
                for slot in PLAYER_EQUIPMENT_OFFSETS:
                    combo = self.player_equip_combos[(rec.index, slot)]
                    values = list(option_maps[slot])
                    current = self.project.item_display(rec.item_id(slot))
                    if current not in values:
                        values.insert(0, current)
                    combo.configure(values=values)
                    self.player_equip_vars[(rec.index, slot)].set(current)
            summary = " / ".join(
                f"{rec.name}: W{rec.weapon_id} A{rec.armor_id} S{rec.shield_id} R{rec.ring_id}"
                for rec in self.project.player_equipment
            )
            self.player_equip_status_var.set(summary)

        def save_player_equipment_gui(self) -> None:
            if not self.project:
                return
            try:
                changes: dict[int, dict[str, int]] = {}
                for index, _name, _export in PLAYER_DATA_EXPORTS:
                    changes[index] = {
                        slot: self._equipment_combo_item_id(self.player_equip_vars[(index, slot)].get())
                        for slot in PLAYER_EQUIPMENT_OFFSETS
                    }
                changed = self.project.save_player_initial_equipment(changes)
                self.populate_all()
                messagebox.showinfo(APP_NAME, f"플레이어 초기 장비를 저장했습니다. 변경 바이트: {changed}")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def import_player_equipment_csv_gui(self) -> None:
            if not self.project:
                return
            path = filedialog.askopenfilename(
                title="플레이어 초기 장비 CSV 가져오기",
                filetypes=[("CSV", "*.csv"), ("All files", "*.*")],
            )
            if not path:
                return
            if not messagebox.askyesno(APP_NAME, "CSV의 4명 초기 장비를 ED2MAIN.EXE에 적용할까요?"):
                return
            try:
                changed = self.project.import_player_equipment_csv(Path(path))
                self.populate_all()
                messagebox.showinfo(APP_NAME, f"초기 장비 CSV 적용 완료 · 변경 바이트: {changed}")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def apply_player_equipment_preset_gui(self, preset_no: int) -> None:
            if not self.project:
                return
            path = Path(__file__).resolve().parent / "presets" / f"ED2_PLAYER_INITIAL_EQUIPMENT_{preset_no}.csv"
            if not path.is_file():
                messagebox.showerror(APP_NAME, f"프리셋 파일을 찾지 못했습니다: {path.name}")
                return
            label = "기본설정" if preset_no == 1 else "1편 아이템 복원"
            if not messagebox.askyesno(APP_NAME, f"초기 장비 프리셋 {preset_no} ({label})을 적용할까요?"):
                return
            try:
                changed = self.project.import_player_equipment_csv(path)
                self.populate_all()
                messagebox.showinfo(APP_NAME, f"프리셋 {preset_no} 적용 완료 · 변경 바이트: {changed}")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        def export_player_equipment_csv_gui(self) -> None:
            if not self.project:
                return
            path = filedialog.asksaveasfilename(
                title="플레이어 초기 장비 CSV 저장",
                defaultextension=".csv",
                initialfile="ED2_PLAYER_INITIAL_EQUIPMENT.csv",
                filetypes=[("CSV", "*.csv"), ("All files", "*.*")],
            )
            if not path:
                return
            try:
                self.project.export_player_equipment_csv(Path(path))
                messagebox.showinfo(APP_NAME, "초기 장비 CSV를 저장했습니다.")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))

        # Shops ----------------------------------------------------------
        def _build_shops_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="상점")
            left,right=self._make_pane(tab)
            bar=ttk.Frame(left);bar.pack(fill="x",pady=(0,6))
            self.shop_search=tk.StringVar();ttk.Label(bar,text="검색").pack(side="left")
            entry=ttk.Entry(bar,textvariable=self.shop_search);entry.pack(side="left",fill="x",expand=True,padx=6)
            entry.bind("<KeyRelease>",lambda _e:self.populate_shops())
            ttk.Button(bar,text="CSV 내보내기",command=self.export_shops_csv).pack(side="left")
            ttk.Button(bar,text="CSV 가져오기",command=self.import_shops_csv_gui).pack(side="left",padx=(4,0))
            cols=("dll","merchant","variant","capacity","items","call","list")
            self.shop_tree=self._tree(left,cols,selectmode="browse")
            for col,label,width in (
                ("dll","시나리오 DLL",100),("merchant","상점 종류",120),("variant","조건",75),
                ("capacity","상품 수/최대",95),("items","판매 상품",520),("call","호출",80),("list","목록",80),
            ):
                self.shop_tree.heading(col,text=label);self.shop_tree.column(col,width=width,anchor="w" if col in ("merchant","items") else "center")
            self.shop_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_shop())

            ttk.Label(right,text="상점 상품 목록",style="Title.TLabel").pack(anchor="w")
            self.shop_title_var=tk.StringVar(value="상점을 선택하세요.")
            ttk.Label(right,textvariable=self.shop_title_var,wraplength=720,style="Section.TLabel").pack(anchor="w",pady=(8,4))
            self.shop_info_var=tk.StringVar()
            ttk.Label(right,textvariable=self.shop_info_var,wraplength=720).pack(anchor="w",pady=(0,8))
            ttk.Label(right,text="상품 코드 목록 (쉼표 또는 공백 구분)",style="Section.TLabel").pack(anchor="w")
            self.shop_codes_var=tk.StringVar()
            shop_entry=ttk.Entry(right,textvariable=self.shop_codes_var,width=80);shop_entry.pack(fill="x",pady=(4,4))
            shop_entry.bind("<KeyRelease>",lambda _e:self.update_shop_preview())
            self.shop_preview_var=tk.StringVar()
            ttk.Label(right,textvariable=self.shop_preview_var,wraplength=720).pack(anchor="w",pady=(0,8))
            ttk.Label(
                right,
                text=(
                    "일반 상품은 0~75 또는 0x00~0x4B로 입력합니다. 0x80 이상은 게임이 사용하는 "
                    "특수·랜덤 장비 코드(0x80~0xCB)입니다. 상품 수는 원본 DLL에 확보된 최대 슬롯을 넘길 수 없지만, "
                    "그 범위 안에서는 교체·삭제·재정렬할 수 있습니다. 조건부 상점은 조건별 목록으로 분리 표시됩니다."
                ),
                wraplength=720,
            ).pack(anchor="w",pady=(0,10))
            buttons=ttk.Frame(right);buttons.pack(fill="x")
            ttk.Button(buttons,text="상품 목록 저장 (.bak)",command=self.save_shop).pack(side="left")
            ttk.Button(buttons,text="현재 상점 변경만 복원",command=self.restore_shop_dll).pack(side="left",padx=6)

            price_box=ttk.LabelFrame(right,text="판매 아이템 전역 가격",padding=8);price_box.pack(fill="x",pady=(14,0))
            line=ttk.Frame(price_box);line.pack(fill="x")
            self.shop_price_item_var=tk.StringVar()
            self.shop_price_combo=ttk.Combobox(line,textvariable=self.shop_price_item_var,state="readonly",width=48)
            self.shop_price_combo.pack(side="left",fill="x",expand=True)
            self.shop_price_combo.bind("<<ComboboxSelected>>",lambda _e:self.update_shop_price())
            self.shop_price_var=tk.StringVar()
            ttk.Entry(line,textvariable=self.shop_price_var,width=16).pack(side="left",padx=6)
            ttk.Button(line,text="가격 저장",command=self.save_shop_price).pack(side="left")
            ttk.Label(
                price_box,
                text="가격은 ED2MAIN.EXE의 ITEM_COST 전역값입니다. 같은 아이템을 파는 모든 상점에 함께 적용됩니다.",
                wraplength=700,
            ).pack(anchor="w",pady=(6,0))

        def populate_shops(self) -> None:
            self.shop_tree.delete(*self.shop_tree.get_children())
            if not self.project:return
            needle=self.shop_search.get().strip().lower()
            for index,shop in enumerate(self.project.shops):
                item_text=" / ".join(shop_item_label(code,self.project.items) for code in shop.item_codes)
                searchable=f"{shop.dll_path.name} {shop.merchant_name} {item_text}".lower()
                if needle and needle not in searchable:continue
                variant=(f"{shop.variant_index+1}/{shop.variant_count}" if shop.variant_count>1 else "-")
                self.shop_tree.insert("","end",iid=str(index),values=(
                    shop.dll_path.stem,shop.merchant_name,variant,f"{len(shop.item_codes)}/{shop.capacity}",item_text,
                    f"0x{shop.call_offset:04X}",f"0x{shop.list_offset:04X}",
                ))

        def show_shop(self) -> None:
            if not self.project:return
            selected=self.shop_tree.selection()
            if not selected:return
            shop=self.project.shops[int(selected[0])];self.current_shop=shop
            self.shop_title_var.set(shop.display_name)
            shared=(f" · 같은 목록을 {shop.shared_users}개 경로가 공유" if shop.shared_users>1 else "")
            self.shop_info_var.set(
                f"{shop.dll_path.name} · seg{shop.segment_index}: call 0x{shop.call_offset:04X} · "
                f"structure 0x{shop.structure_offset:04X} · list 0x{shop.list_offset:04X} · "
                f"현재 {len(shop.item_codes)}개 / 최대 {shop.capacity}개{shared}"
            )
            self.shop_codes_var.set(" ".join(f"0x{code:02X}" for code in shop.item_codes))
            self.update_shop_preview()
            unique=[]
            for code in shop.item_codes:
                item_id=code if code<ITEM_COUNT else code-0x80 if 0x80<=code<0x80+ITEM_COUNT else -1
                if 0<=item_id<ITEM_COUNT and item_id not in unique:unique.append(item_id)
            self.shop_price_ids=unique
            values=[f"{item_id:03d} {self.project.items[item_id].name}" for item_id in unique]
            self.shop_price_combo.configure(values=values)
            if values:self.shop_price_combo.current(0);self.update_shop_price()
            else:self.shop_price_item_var.set("");self.shop_price_var.set("")

        def update_shop_preview(self) -> None:
            if not self.project or not self.current_shop:
                self.shop_preview_var.set("");return
            try:
                codes=parse_shop_item_codes(self.shop_codes_var.get())
                labels=" / ".join(shop_item_label(code,self.project.items) for code in codes)
                state="저장 가능" if len(codes)<=self.current_shop.capacity else f"최대 {self.current_shop.capacity}개 초과"
                self.shop_preview_var.set(f"{len(codes)}개 · {state}\n{labels}")
            except Exception as exc:self.shop_preview_var.set(str(exc))

        def save_shop(self) -> None:
            if not self.project or not self.current_shop:return
            try:
                codes=parse_shop_item_codes(self.shop_codes_var.get())
                patch_shop_inventory(self.current_shop,codes,True)
                key=(self.current_shop.dll_path.name.upper(),self.current_shop.call_offset,self.current_shop.list_offset)
                self.reload_project()
                if self.project:
                    for index,shop in enumerate(self.project.shops):
                        if (shop.dll_path.name.upper(),shop.call_offset,shop.list_offset)==key:
                            if self.shop_tree.exists(str(index)):
                                self.shop_tree.selection_set(str(index));self.shop_tree.see(str(index));self.show_shop()
                            break
                messagebox.showinfo(APP_NAME,"상점 상품 목록을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def restore_shop_dll(self) -> None:
            if not self.current_shop:return
            if not messagebox.askyesno(APP_NAME,f"{self.current_shop.dll_path.name}에서 상점 편집이 변경한 바이트만 복원할까요?\n다른 패치는 유지됩니다."):return
            try:restore_backup(self.current_shop.dll_path);self.reload_project()
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def update_shop_price(self) -> None:
            if not self.project:return
            try:
                index=self.shop_price_combo.current()
                if index<0:return
                item_id=self.shop_price_ids[index]
                self.shop_price_var.set(str(self.project.items[item_id].price))
            except Exception:self.shop_price_var.set("")

        def save_shop_price(self) -> None:
            if not self.project:return
            try:
                index=self.shop_price_combo.current()
                if index<0:raise ValueError("가격을 수정할 아이템을 선택하세요.")
                item_id=self.shop_price_ids[index]
                price=parse_number(self.shop_price_var.get(),0,10**12,"가격")
                patch_item(self.project.exe,item_id,{"price":price},True)
                self.reload_project();messagebox.showinfo(APP_NAME,"아이템 전역 가격을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def export_shops_csv(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".csv",initialfile="ED2_SHOPS.csv",filetypes=[("CSV","*.csv")])
            if path:self.project.export_shops_csv(Path(path))

        def import_shops_csv_gui(self) -> None:
            if not self.project:return
            path=filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
            if not path or not messagebox.askyesno(APP_NAME,"CSV의 상점 상품 목록을 적용할까요?"):return
            try:
                count=self.project.import_shops_csv(Path(path));self.populate_all()
                messagebox.showinfo(APP_NAME,f"{count}개 상점 경로 적용 완료")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Magic -----------------------------------------------------------
        def _build_magic_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="주문")
            left,right=self._make_pane(tab)
            bar=ttk.Frame(left);bar.pack(fill="x",pady=(0,6));self.magic_search=tk.StringVar();ttk.Label(bar,text="검색").pack(side="left")
            e=ttk.Entry(bar,textvariable=self.magic_search);e.pack(side="left",fill="x",expand=True,padx=6);e.bind("<KeyRelease>",lambda _e:self.populate_magics())
            ttk.Button(bar,text="CSV 내보내기",command=self.export_magics_csv).pack(side="left")
            cols=("id","name","cost","slc","slc2","ratio","cnt","handler")
            self.magic_tree=self._tree(left,cols,selectmode="extended")
            for col,label,width in (("id","ID",45),("name","MAGIC_NAME",150),("cost","MAGIC_COST",85),("slc","MAGIC_SLC",85),("slc2","MAGIC_SLC2",90),("ratio","MAGIC_BAIRITU (효과%)",145),("cnt","MAGIC_CNT (충전)",125),("handler","MAGIC_TABLE handler",180)):
                self.magic_tree.heading(col,text=label);self.magic_tree.column(col,width=width,minwidth=45,anchor="w" if col in ("name","handler") else "center")
            self.magic_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_magic())
            ttk.Label(right,text="주문 상세",style="Title.TLabel").pack(anchor="w")
            form=ttk.Frame(right);form.pack(fill="x",pady=(8,0))
            self.magic_vars={k:tk.StringVar() for k in ("id","name","cost","select_flags","multiplier","count_raw","handler")}
            rows=[("id","주문 ID"),("name","MAGIC_NAME (CP949 최대 8바이트)"),("cost","MAGIC_COST"),("select_flags","MAGIC_SLC 원시 플래그"),("multiplier","MAGIC_BAIRITU 효과 배율 % (0..127)"),("count_raw","MAGIC_CNT 재충전 주기 (0x11 권장 최소)"),("handler","MAGIC_TABLE 처리 함수 (읽기 전용)")]
            self.magic_entries={}
            for row,(key,label) in enumerate(rows):
                ttk.Label(form,text=label).grid(row=row,column=0,sticky="w",pady=3);ent=ttk.Entry(form,textvariable=self.magic_vars[key],width=42);ent.grid(row=row,column=1,sticky="ew",padx=(8,0),pady=3);self.magic_entries[key]=ent
                if key in ("multiplier","count_raw"):
                    ent.bind("<KeyRelease>",lambda _e:self.update_magic_parameter_help())
            self.magic_entries["id"].configure(state="readonly");self.magic_entries["handler"].configure(state="readonly");form.columnconfigure(1,weight=1)
            self.magic_secondary_var=tk.BooleanVar();ttk.Checkbutton(right,text="MAGIC_SLC2 bit7: 보조 선택 플래그",variable=self.magic_secondary_var).pack(anchor="w",pady=(8,2))
            self.magic_info_var=tk.StringVar();ttk.Label(right,textvariable=self.magic_info_var,wraplength=720,style="Section.TLabel").pack(anchor="w",pady=(4,8))
            self.magic_parameter_help_var=tk.StringVar()
            ttk.Label(right,textvariable=self.magic_parameter_help_var,wraplength=720).pack(anchor="w",pady=(0,8))
            ttk.Label(
                right,
                text=(
                    "MAGIC_BAIRITU는 주문 효과 배율입니다. 100은 기준 효과, 25는 약 25%입니다. "
                    "bit7은 배율이 아니라 MAGIC_SLC2 보조 선택 플래그로 따로 편집됩니다.\n"
                    "MAGIC_CNT는 재충전 주기입니다. 하위 니블은 최초 주기, 상위 니블은 반복 주기이며 숫자가 작을수록 빠릅니다. "
                    "0x11은 가장 빠른 안정 권장값, 0x22는 약 2배, 0x55는 약 5배 느립니다. "
                    "0x00처럼 어느 한 니블이 0인 값은 언더플로 위험이 있으므로 피하십시오."
                ),
                wraplength=720,
            ).pack(anchor="w",pady=(0,8))
            recharge=ttk.LabelFrame(right,text="주문 재충전 주기 통일",padding=8);recharge.pack(fill="x",pady=(4,10))
            line=ttk.Frame(recharge);line.pack(fill="x")
            self.magic_recharge_scope_var=tk.StringVar(value="선택한 주문")
            ttk.Combobox(line,textvariable=self.magic_recharge_scope_var,state="readonly",values=("선택한 주문","전체 32개"),width=16).pack(side="left")
            self.magic_recharge_preset_var=tk.StringVar(value="가장 빠름 0x11")
            preset=ttk.Combobox(line,textvariable=self.magic_recharge_preset_var,state="readonly",values=("가장 빠름 0x11","빠름 0x22","보통 0x33","느림 0x55","사용자 지정"),width=18)
            preset.pack(side="left",padx=6);preset.bind("<<ComboboxSelected>>",lambda _e:self.set_magic_recharge_preset())
            self.magic_recharge_value_var=tk.StringVar(value="0x11")
            ttk.Entry(line,textvariable=self.magic_recharge_value_var,width=10).pack(side="left")
            ttk.Button(line,text="같은 주기로 적용 (EXE.bak)",command=self.unify_magic_recharge).pack(side="left",padx=6)
            ttk.Label(recharge,text="Ctrl/Shift로 여러 주문을 선택할 수 있습니다. 전체 적용은 32개 MAGIC_CNT만 한 번에 변경하며 다른 주문 수치는 유지합니다.",wraplength=700).pack(anchor="w",pady=(6,0))
            ttk.Label(right,text="MAGIC_TABLE 처리 함수 포인터는 코드 주소이므로 수정할 수 없습니다.",wraplength=720).pack(anchor="w",pady=(0,8))
            btn=ttk.Frame(right);btn.pack(fill="x")
            ttk.Button(btn,text="주문 저장 (EXE.bak)",command=self.save_magic).pack(side="left")
            ttk.Button(btn,text="이 도구 변경만 복원",command=self.restore_exe).pack(side="left",padx=6)

        def populate_magics(self) -> None:
            self.magic_tree.delete(*self.magic_tree.get_children())
            if not self.project:return
            needle=self.magic_search.get().strip().lower()
            for magic in self.project.magics:
                if needle and needle not in f"{magic.magic_id} {magic.name} {magic.handler_name}".lower():continue
                self.magic_tree.insert("","end",iid=str(magic.magic_id),values=(magic.magic_id,magic.name,magic.cost,f"0x{magic.select_flags:02X}",int(magic.secondary_select),magic.multiplier,f"0x{magic.count_raw:02X}",magic.handler_name))

        def show_magic(self) -> None:
            if not self.project:return
            sel=self.magic_tree.selection()
            if not sel:return
            magic=self.project.magics[int(sel[0])];self.current_magic=magic
            values={"id":magic.magic_id,"name":magic.name,"cost":magic.cost,"select_flags":f"0x{magic.select_flags:02X}","multiplier":magic.multiplier,"count_raw":f"0x{magic.count_raw:02X}","handler":f"{magic.handler_name} @ 86:{magic.handler_offset:04X}"}
            for key,value in values.items():self.magic_vars[key].set(str(value))
            self.magic_secondary_var.set(magic.secondary_select)
            self.magic_info_var.set(f"원시 packed select/multiplier=0x{magic.packed_select_multiplier:02X}")
            self.update_magic_parameter_help()

        def update_magic_parameter_help(self) -> None:
            if not hasattr(self,"magic_parameter_help_var"):
                return
            try:
                multiplier=parse_number(self.magic_vars["multiplier"].get(),0,0x7F,"MAGIC_BAIRITU")
                multiplier_text=describe_magic_multiplier(multiplier)
            except Exception as exc:
                multiplier_text=f"MAGIC_BAIRITU 입력 확인: {exc}"
            try:
                count_raw=parse_number(self.magic_vars["count_raw"].get(),0,0xFF,"MAGIC_CNT")
                count_text,_unsafe=describe_magic_count(count_raw)
            except Exception as exc:
                count_text=f"MAGIC_CNT 입력 확인: {exc}"
            self.magic_parameter_help_var.set(multiplier_text+"\n"+count_text)

        def save_magic(self) -> None:
            if not self.project or not self.current_magic:return
            try:
                magic_id=self.current_magic.magic_id
                values={"name":self.magic_vars["name"].get(),"cost":parse_number(self.magic_vars["cost"].get(),0,255,"MAGIC_COST"),"select_flags":parse_number(self.magic_vars["select_flags"].get(),0,255,"MAGIC_SLC"),"secondary_select":self.magic_secondary_var.get(),"multiplier":parse_number(self.magic_vars["multiplier"].get(),0,127,"MAGIC_BAIRITU"),"count_raw":parse_number(self.magic_vars["count_raw"].get(),0,255,"MAGIC_CNT")}
                patch_magic(self.project.exe,magic_id,values);self.reload_project()
                if self.magic_tree.exists(str(magic_id)):
                    self.magic_tree.selection_set(str(magic_id));self.magic_tree.see(str(magic_id));self.show_magic()
                messagebox.showinfo(APP_NAME,"주문을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def export_magics_csv(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".csv",initialfile="ED2_MAGIC.csv",filetypes=[("CSV","*.csv")])
            if path:self.project.export_magics_csv(Path(path))

        def set_magic_recharge_preset(self) -> None:
            mapping={"가장 빠름 0x11":"0x11","빠름 0x22":"0x22","보통 0x33":"0x33","느림 0x55":"0x55"}
            value=mapping.get(self.magic_recharge_preset_var.get())
            if value:self.magic_recharge_value_var.set(value)

        def unify_magic_recharge(self) -> None:
            if not self.project:return
            try:
                value=parse_number(self.magic_recharge_value_var.get(),0,255,"MAGIC_CNT")
                description,unsafe=describe_magic_count(value)
                if unsafe:raise ValueError(description)
                if self.magic_recharge_scope_var.get()=="전체 32개":
                    ids=list(range(MAGIC_COUNT))
                else:
                    ids=[int(item) for item in self.magic_tree.selection()]
                    if not ids:raise ValueError("왼쪽 목록에서 하나 이상의 주문을 선택하세요.")
                names=", ".join(self.project.magics[i].name for i in ids[:8])+(" ..." if len(ids)>8 else "")
                if not messagebox.askyesno(APP_NAME,f"{len(ids)}개 주문의 재충전 주기를 0x{value:02X}로 통일할까요?\n{names}\n\n{description}"):
                    return
                changed=patch_magic_recharge_bulk(self.project.exe,ids,value,True)
                self.reload_project();messagebox.showinfo(APP_NAME,f"{changed}개 주문의 재충전 주기를 변경했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Experience ------------------------------------------------------
        def _build_experience_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="경험치")
            outer,body=self._scrollable_panel(tab);outer.pack(fill="both",expand=True)
            ttk.Label(body,text="경험치 획득 방식",style="Title.TLabel").pack(anchor="w")
            ttk.Label(body,text="ED2MAIN의 전투 종료 경험치 계산과 지급 대상을 독립적으로 변경합니다. 모든 수정은 확인된 명령열만 제자리 교체하며 EXE 크기를 바꾸지 않습니다.",wraplength=980).pack(anchor="w",pady=(4,10))
            rule=ttk.LabelFrame(body,text="규칙 선택",padding=10);rule.pack(fill="x")
            self.exp_include_var=tk.BooleanVar();self.exp_no_split_var=tk.BooleanVar();self.exp_no_90_var=tk.BooleanVar();self.exp_no_level_var=tk.BooleanVar();self.gold_no_90_var=tk.BooleanVar();self.gold_no_level_var=tk.BooleanVar()
            for text,var in (
                ("기절·전투불능 파티원도 경험치를 획득하고 분배 인원에 포함",self.exp_include_var),
                ("총 경험치를 파티원 수로 나누지 않음 — 각 획득 대상이 전투 총 EXP를 모두 획득",self.exp_no_split_var),
                ("일반 전투의 EXP 90% 보정 제거 — 몬스터 EXP 원시값을 100% 누적",self.exp_no_90_var),
                ("일반 전투의 Gold 90% 보정 제거 — 몬스터 Gold 원시값을 100% 누적",self.gold_no_90_var),
                ("Gold 레벨 스케일링 제거 — 파티 평균 레벨과 관계없이 Gold 레벨 배율 100%",self.gold_no_level_var),
                ("파티 평균 레벨이 높을 때의 경험치 감소 제거 — 항상 EXP 레벨 배율 100%",self.exp_no_level_var),
            ):
                ttk.Checkbutton(rule,text=text,variable=var,command=self.update_experience_preview).pack(anchor="w",pady=3)
            buttons=ttk.Frame(rule);buttons.pack(fill="x",pady=(8,0))
            ttk.Button(buttons,text="규칙 저장 (EXE.bak)",command=self.save_experience_rules).pack(side="left")
            ttk.Button(buttons,text="원본 방식 선택",command=self.select_original_experience).pack(side="left",padx=6)
            ttk.Button(buttons,text="이 도구 변경만 복원",command=self.restore_exe).pack(side="left")
            self.exp_state_var=tk.StringVar();ttk.Label(body,textvariable=self.exp_state_var,style="Section.TLabel",wraplength=980).pack(anchor="w",pady=(10,6))
            calc=ttk.LabelFrame(body,text="전투 종료 분배 미리 보기",padding=10);calc.pack(fill="x",pady=(6,10))
            row=ttk.Frame(calc);row.pack(fill="x")
            self.exp_preview_total=tk.StringVar(value="1000");self.exp_preview_active=tk.StringVar(value="4");self.exp_preview_stunned=tk.StringVar(value="1")
            for label,var,width in (("누적 총 EXP",self.exp_preview_total,12),("활성 파티원",self.exp_preview_active,8),("그중 기절",self.exp_preview_stunned,8)):
                ttk.Label(row,text=label).pack(side="left");entry=ttk.Entry(row,textvariable=var,width=width);entry.pack(side="left",padx=(4,12));entry.bind("<KeyRelease>",lambda _e:self.update_experience_preview())
            self.exp_preview_var=tk.StringVar();ttk.Label(calc,textvariable=self.exp_preview_var,wraplength=950).pack(anchor="w",pady=(8,0))
            tech=ttk.LabelFrame(body,text="확인된 원본 처리",padding=10);tech.pack(fill="x")
            ttk.Label(tech,text=("GET_EXP 86:3728은 CALC_NAKAMA_NUM으로 대상 수를 구한 뒤 CUR_EXP를 올림 나눗셈합니다. "
                "GET_EXP 86:3760과 CALC_NAKAMA_NUM 86:42A4는 같은 +0x24 bit7 기절/전투불능 플래그를 검사합니다. "
                "ADD_MO_EXP 86:41B7은 EXP 90% 보정, 86:41BB는 EXP 레벨 차이 배율을 적용합니다. "
                "ADD_MO_GOLD 86:41D3은 Gold 90% 보정, 86:41D7은 Gold 레벨 스케일링을 적용하며 두 호출을 독립적으로 해제할 수 있습니다."),wraplength=950).pack(anchor="w")

        def populate_experience(self) -> None:
            if not self.project or not hasattr(self,"exp_state_var"):return
            state=self.project.experience_rules
            if state.recognized:
                self.exp_include_var.set(state.include_incapacitated);self.exp_no_split_var.set(state.no_party_split);self.exp_no_90_var.set(state.no_general_90_percent);self.exp_no_level_var.set(state.no_level_penalty)
                gold=self.project.gold_reward_rules
                if gold.recognized:
                    self.gold_no_90_var.set(gold.no_general_90_percent);self.gold_no_level_var.set(gold.no_level_scaling)
                    self.exp_state_var.set("현재 상태: "+state.summary+" / "+gold.summary)
                else:
                    self.exp_state_var.set("현재 EXP: "+state.summary+" / Gold 인식 불가 — "+gold.detail)
            else:
                self.exp_state_var.set("현재 상태: 인식 불가 — "+state.detail)
            self.update_experience_preview()

        def selected_experience_state(self) -> ExperienceRuleState:
            return ExperienceRuleState(self.exp_include_var.get(),self.exp_no_split_var.get(),self.exp_no_90_var.get(),self.exp_no_level_var.get())

        def update_experience_preview(self) -> None:
            if not hasattr(self,"exp_preview_var"):return
            try:
                state=self.selected_experience_state()
                total=parse_number(self.exp_preview_total.get(),0,0xFFFF,"누적 총 EXP")
                active=parse_number(self.exp_preview_active.get(),0,4,"활성 파티원")
                stunned=parse_number(self.exp_preview_stunned.get(),0,4,"기절 인원")
                if stunned>active:raise ValueError("기절 인원은 활성 파티원 수보다 많을 수 없습니다.")
                result=experience_distribution_preview(total,active,stunned,state)
                gold_bits=[]
                if self.gold_no_90_var.get(): gold_bits.append("Gold 90% 보정 없음")
                if self.gold_no_level_var.get(): gold_bits.append("Gold 레벨 스케일링 없음")
                gold_summary = ", ".join(gold_bits) if gold_bits else "원본 Gold 방식"
                self.exp_preview_var.set(f"획득 대상 {result['eligible']}명 · 1인당 {result['per_member']} EXP · 파티 전체 지급 합계 {result['distributed_total']} EXP\n선택 상태: {state.summary} / {gold_summary}")
            except Exception as exc:self.exp_preview_var.set("입력 확인: "+str(exc))

        def select_original_experience(self) -> None:
            self.exp_include_var.set(False);self.exp_no_split_var.set(False);self.exp_no_90_var.set(False);self.gold_no_90_var.set(False);self.gold_no_level_var.set(False);self.exp_no_level_var.set(False);self.update_experience_preview()

        def save_experience_rules(self) -> None:
            if not self.project:return
            try:
                state=self.selected_experience_state()
                gold_state=GoldRewardRuleState(self.gold_no_90_var.get(),self.gold_no_level_var.get())
                if not messagebox.askyesno(APP_NAME,"다음 전투 보상 규칙을 ED2MAIN.EXE에 적용할까요?\n\nEXP: "+state.summary+"\nGold: "+gold_state.summary):return
                changed=patch_experience_rules(self.project.exe,state,True)
                changed += patch_gold_reward_rules(self.project.exe,gold_state,True)
                self.reload_project();messagebox.showinfo(APP_NAME,f"전투 보상 규칙 {changed}개 코드 구간을 갱신했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # AI and hooks ----------------------------------------------------
        def _build_ai_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="AI·훅")
            left,right=self._make_pane(tab)
            bar=ttk.Frame(left);bar.pack(fill="x",pady=(0,6));self.ai_search=tk.StringVar();ttk.Label(bar,text="검색").pack(side="left")
            e=ttk.Entry(bar,textvariable=self.ai_search);e.pack(side="left",fill="x",expand=True,padx=6);e.bind("<KeyRelease>",lambda _e:self.populate_ai())
            ttk.Button(bar,text="JSON 내보내기",command=self.export_ai_json).pack(side="left")
            self.ai_group_tree=self._tree(left,("dll","monsters","source"),selectmode="browse")
            for col,label,width in (("dll","DLL",80),("monsters","몬스터",300),("source","원본 ASM 경로",420)):
                self.ai_group_tree.heading(col,text=label);self.ai_group_tree.column(col,width=width,minwidth=60,anchor="w")
            self.ai_group_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_ai())
            ttk.Label(right,text="AI 행동·전투 훅",style="Title.TLabel").pack(anchor="w")
            self.ai_title_var=tk.StringVar();ttk.Label(right,textvariable=self.ai_title_var,wraplength=760).pack(anchor="w",pady=(4,8))
            ttk.Label(right,text="자동 감지된 특수 규칙",style="Section.TLabel").pack(anchor="w")
            special_holder=ttk.Frame(right);special_holder.pack(fill="both",expand=True,pady=(4,8))
            self.ai_special_tree=self._tree(special_holder,("confidence","category","location","summary","detail"),selectmode="browse",height=7)
            for col,label,width in (("confidence","판정",65),("category","분류",80),("location","위치",110),("summary","규칙",260),("detail","설명",430)):
                self.ai_special_tree.heading(col,text=label);self.ai_special_tree.column(col,width=width,anchor="w" if col in ("summary","detail") else "center")
            ttk.Label(right,text="확정된 그룹 전역 포인터",style="Section.TLabel").pack(anchor="w")
            hook_holder=ttk.Frame(right);hook_holder.pack(fill="both",expand=True,pady=(4,8))
            self.ai_hook_tree=self._tree(hook_holder,("symbol","offset","desc"),selectmode="browse")
            for col,label,width in (("symbol","심볼",180),("offset","오프셋",90),("desc","설명",380)):
                self.ai_hook_tree.heading(col,text=label);self.ai_hook_tree.column(col,width=width,anchor="w")
            ttk.Label(right,text="디버그 DLL에서 복구한 지역 함수·행동명",style="Section.TLabel").pack(anchor="w")
            symbol_holder=ttk.Frame(right);symbol_holder.pack(fill="both",expand=True,pady=(4,8))
            self.ai_symbol_tree=self._tree(symbol_holder,("category","symbol"),selectmode="browse")
            self.ai_symbol_tree.heading("category",text="분류");self.ai_symbol_tree.column("category",width=150,anchor="w")
            self.ai_symbol_tree.heading("symbol",text="심볼/행동명");self.ai_symbol_tree.column("symbol",width=520,anchor="w")
            ttk.Label(right,text="포인터 편집은 충돌 위험 때문에 제공하지 않습니다. 디버그 DLL의 로드 영역은 정식판과 동일하며, 이 화면은 이름과 주소를 읽기 전용으로 연결합니다.",wraplength=760).pack(anchor="w")

        def populate_ai(self) -> None:
            self.ai_group_tree.delete(*self.ai_group_tree.get_children())
            if not self.project:return
            needle=self.ai_search.get().strip().lower()
            for index,g in enumerate(self.project.groups):
                info=self.project.debug_info(g.dll_path.name);source=str(info.get("source",""));cats=info.get("categories",{})
                special_text=" ".join(f"{rule.category} {rule.summary} {rule.detail}" for rule in g.special_rules)
                hay=f"{g.dll_path.name} {' '.join(g.monster_names)} {source} {json.dumps(cats,ensure_ascii=False)} {special_text}".lower()
                if needle and needle not in hay:continue
                self.ai_group_tree.insert("","end",iid=str(index),values=(g.dll_path.stem," / ".join(g.monster_names),source))

        def show_ai(self) -> None:
            if not self.project:return
            sel=self.ai_group_tree.selection()
            if not sel:return
            g=self.project.groups[int(sel[0])];info=self.project.debug_info(g.dll_path.name)
            self.ai_title_var.set(f"{g.dll_path.name} · {' / '.join(g.monster_names)}\n{info.get('source','디버그 소스 경로 없음')}")
            self.ai_special_tree.delete(*self.ai_special_tree.get_children())
            for rule in g.special_rules:
                self.ai_special_tree.insert("","end",values=(rule.confidence,rule.category,rule.location,rule.summary,rule.detail))
            self.ai_hook_tree.delete(*self.ai_hook_tree.get_children())
            for symbol,value,description in g.hook_rows():self.ai_hook_tree.insert("","end",values=(symbol,f"0x{value:04X}",description))
            self.ai_symbol_tree.delete(*self.ai_symbol_tree.get_children())
            for category,names in info.get("categories",{}).items():
                for name in names:self.ai_symbol_tree.insert("","end",values=(category,name))

        def export_ai_json(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".json",initialfile="ED2_AI_HOOKS.json",filetypes=[("JSON","*.json")])
            if path:self.project.export_ai_hooks_json(Path(path))

        # Appearance ------------------------------------------------------
        def _build_appearance_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="몬스터 외형")
            left,right=self._make_pane(tab)
            self.asset_tree=self._tree(left,("id","file","size","valid","users"),selectmode="browse")
            for col,label,width in (("id","ID",65),("file","BZH",170),("size","크기",80),("valid","헤더",70),("users","사용 그룹",420)):
                self.asset_tree.heading(col,text=label);self.asset_tree.column(col,width=width,anchor="w" if col in ("file","users") else "center")
            self.asset_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_asset())
            ttk.Label(right,text="몬스터 외형 리소스",style="Title.TLabel").pack(anchor="w")
            self.asset_info=tk.StringVar();ttk.Label(right,textvariable=self.asset_info,wraplength=720).pack(anchor="w",pady=(8,8))
            hexholder=ttk.Frame(right);hexholder.pack(fill="both",expand=True)
            self.asset_hex=self._text(hexholder,height=12,state="disabled")
            btn=ttk.Frame(right);btn.pack(fill="x",pady=8)
            ttk.Button(btn,text="BZH 내보내기",command=self.export_asset).pack(side="left")
            ttk.Button(btn,text="BZH 교체",command=self.import_asset).pack(side="left",padx=6)
            ttk.Button(btn,text="이 도구 변경만 복원",command=self.restore_asset).pack(side="left")
            assign=ttk.LabelFrame(right,text="선택 외형을 전투 그룹에 지정",padding=8);assign.pack(fill="x")
            self.asset_group_var=tk.StringVar();self.asset_group_combo=ttk.Combobox(assign,textvariable=self.asset_group_var,state="readonly",width=50);self.asset_group_combo.grid(row=0,column=0,sticky="ew")
            self.asset_slot_var=tk.StringVar(value="주 외형");ttk.Combobox(assign,textvariable=self.asset_slot_var,state="readonly",values=("주 외형","보조 외형"),width=12).grid(row=0,column=1,padx=6)
            ttk.Button(assign,text="지정",command=self.assign_asset).grid(row=0,column=2);assign.columnconfigure(0,weight=1)

        def populate_assets(self) -> None:
            self.asset_tree.delete(*self.asset_tree.get_children())
            if not self.project:return
            self.asset_group_combo.configure(values=[g.label for g in self.project.groups])
            for index,a in enumerate(self.project.assets):self.asset_tree.insert("","end",iid=str(index),values=(f"0x{a.asset_id:03X}",a.path.name,a.size,"OK" if a.header_valid else "ERROR",", ".join(a.users)))

        def show_asset(self) -> None:
            if not self.project:return
            sel=self.asset_tree.selection()
            if not sel:return
            a=self.project.assets[int(sel[0])];self.current_asset=a
            self.asset_info.set(f"{a.path.name} · {a.size} bytes · header size-1={a.header_size_minus_one} · {'정상' if a.header_valid else '비정상'}\n사용: {', '.join(a.users) or '없음'}")
            self._readonly_text(self.asset_hex,a.path.read_bytes()[:512].hex(" ").upper())

        def export_asset(self) -> None:
            if not self.current_asset:return
            path=filedialog.asksaveasfilename(initialfile=self.current_asset.path.name,defaultextension=".BZH")
            if path:shutil.copy2(self.current_asset.path,path)

        def import_asset(self) -> None:
            if not self.current_asset:return
            path=filedialog.askopenfilename(filetypes=[("BZH","*.BZH"),("All files","*")])
            if not path:return
            try:replace_bzh(self.current_asset.path,Path(path));self.reload_project();messagebox.showinfo(APP_NAME,"외형 BZH를 교체했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def restore_asset(self) -> None:
            if not self.current_asset:return
            try:restore_backup(self.current_asset.path);self.reload_project()
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def assign_asset(self) -> None:
            if not self.project or not self.current_asset:return
            group=next((g for g in self.project.groups if g.label==self.asset_group_var.get()),None)
            if not group:messagebox.showerror(APP_NAME,"전투 그룹을 선택하세요.");return
            key="graphic_id0" if self.asset_slot_var.get()=="주 외형" else "graphic_id1"
            try:patch_group(group,{key:self.current_asset.asset_id});self.reload_project();messagebox.showinfo(APP_NAME,"외형을 지정했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Resources -------------------------------------------------------
        def _build_resources_tab(self) -> None:
            tab=ttk.Frame(self.nb);self.nb.add(tab,text="리소스 탐색기")
            left,right=self._make_pane(tab)
            bar=ttk.Frame(left);bar.pack(fill="x",pady=(0,6));self.res_search=tk.StringVar();ttk.Label(bar,text="파일 검색").pack(side="left")
            e=ttk.Entry(bar,textvariable=self.res_search);e.pack(side="left",fill="x",expand=True,padx=6);e.bind("<KeyRelease>",lambda _e:self.populate_resources())
            self.res_tree=self._tree(left,("path","ext","size"),selectmode="browse")
            for col,label,width in (("path","상대 경로",500),("ext","형식",90),("size","크기",110)):
                self.res_tree.heading(col,text=label);self.res_tree.column(col,width=width,anchor="w" if col=="path" else "center")
            self.res_tree.bind("<<TreeviewSelect>>",lambda _e:self.show_resource())
            ttk.Label(right,text="보수적 원본 리소스 관리",style="Title.TLabel").pack(anchor="w")
            self.res_info=tk.StringVar();ttk.Label(right,textvariable=self.res_info,wraplength=720).pack(anchor="w",pady=(8,8))
            holder=ttk.Frame(right);holder.pack(fill="both",expand=True)
            self.res_hex=self._text(holder,height=15,state="disabled")
            btn=ttk.Frame(right);btn.pack(fill="x",pady=8)
            ttk.Button(btn,text="내보내기",command=self.export_resource).pack(side="left")
            ttk.Button(btn,text="같은 크기 파일로 교체",command=self.replace_resource).pack(side="left",padx=6)
            ttk.Button(btn,text="이 도구 변경만 복원",command=self.restore_resource).pack(side="left")

        def populate_resources(self) -> None:
            self.res_tree.delete(*self.res_tree.get_children());self.resource_paths={}
            if not self.project:return
            needle=self.res_search.get().strip().lower();index=0
            for path in sorted(p for p in self.project.root.rglob("*") if p.is_file() and not p.name.endswith(".bak")):
                rel=str(path.relative_to(self.project.root))
                if needle and needle not in rel.lower():continue
                iid=str(index);index+=1;self.resource_paths[iid]=path;self.res_tree.insert("","end",iid=iid,values=(rel,path.suffix.upper() or "(none)",path.stat().st_size))

        def show_resource(self) -> None:
            sel=self.res_tree.selection()
            if not sel:return
            path=self.resource_paths[sel[0]];self.current_resource=path
            self.res_info.set(f"{path.relative_to(self.project.root) if self.project else path.name} · {path.stat().st_size} bytes · 최초 512바이트")
            self._readonly_text(self.res_hex,path.read_bytes()[:512].hex(" ").upper())

        def export_resource(self) -> None:
            if not self.current_resource:return
            path=filedialog.asksaveasfilename(initialfile=self.current_resource.name)
            if path:shutil.copy2(self.current_resource,path)

        def replace_resource(self) -> None:
            if not self.current_resource:return
            source=filedialog.askopenfilename()
            if not source:return
            try:
                data=Path(source).read_bytes()
                if len(data)!=self.current_resource.stat().st_size:raise ValueError("원본과 크기가 정확히 같아야 합니다.")
                atomic_write(self.current_resource,data,True);self.reload_project();messagebox.showinfo(APP_NAME,"리소스를 교체했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def restore_resource(self) -> None:
            if not self.current_resource:return
            try:restore_backup(self.current_resource);self.reload_project()
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Changes and presets ----------------------------------------------
        def _build_changes_tab(self) -> None:
            tab=ttk.Frame(self.nb,padding=10);self.nb.add(tab,text="변경·프리셋")
            top=ttk.Frame(tab);top.pack(fill="x")
            self.baseline_status_var=tk.StringVar(value="게임 폴더를 열면 기준점 상태를 표시합니다.")
            ttk.Label(top,textvariable=self.baseline_status_var,style="Section.TLabel").pack(side="left",fill="x",expand=True)
            ttk.Button(top,text="현재 상태를 기준점으로 저장",command=self.create_baseline_gui).pack(side="left")
            ttk.Button(top,text="변경 비교 새로고침",command=self.populate_changes).pack(side="left",padx=(6,0))

            preset_box=ttk.LabelFrame(tab,text="밸런스 프리셋",padding=8);preset_box.pack(fill="x",pady=(8,8))
            self.preset_var=tk.StringVar(value="드롭률 2배")
            self.preset_combo=ttk.Combobox(preset_box,textvariable=self.preset_var,state="readonly",width=34,values=(
                "드롭률 2배","희귀 드롭 최소 5%","ITEM_MAGIC_NUM 아이템 비례화","모든 아이템 고정 위력","기준점 상태 복원",
            ));self.preset_combo.pack(side="left")
            ttk.Button(preset_box,text="미리보기",command=self.preview_preset_gui).pack(side="left",padx=6)
            ttk.Button(preset_box,text="적용 (.bak)",command=self.apply_preset_gui).pack(side="left")
            ttk.Separator(preset_box,orient="vertical").pack(side="left",fill="y",padx=10)
            ttk.Button(preset_box,text="커스텀 프리셋 저장",command=self.export_balance_preset_gui).pack(side="left")
            ttk.Button(preset_box,text="커스텀 프리셋 불러오기",command=self.import_balance_preset_gui).pack(side="left",padx=6)

            self.changes_source_var=tk.StringVar(value="변경 비교")
            ttk.Label(tab,textvariable=self.changes_source_var,wraplength=1200).pack(anchor="w",pady=(0,6))
            self.changes_tree=self._tree(tab,("file","category","target","field","original","current"),selectmode="browse")
            for col,label,width in (("file","파일",135),("category","분류",90),("target","대상",230),("field","항목",155),("original","기준값",230),("current","현재/적용값",230)):
                self.changes_tree.heading(col,text=label);self.changes_tree.column(col,width=width,anchor="w")

        def _show_change_rows(self, title: str, rows: list[ModificationRow]) -> None:
            if not hasattr(self,"changes_tree"):return
            self.changes_tree.delete(*self.changes_tree.get_children())
            for index,row in enumerate(rows):
                self.changes_tree.insert("","end",iid=str(index),values=(row.file,row.category,row.target,row.field,row.original,row.current))
            self.changes_source_var.set(f"{title} · 변경 {len(rows)}건")

        def populate_changes(self) -> None:
            if not hasattr(self,"changes_tree"):return
            if not self.project:
                self.baseline_status_var.set("게임 폴더를 열면 기준점 상태를 표시합니다.")
                self._show_change_rows("변경 비교",[]);return
            self.baseline_status_var.set(
                "저장된 기준점 있음" if self.project.baseline_exists
                else "저장된 기준점 없음 · 기존 .bak가 있으면 그것을 원본으로 비교합니다."
            )
            try:
                source,rows=self.project.modification_rows();self._show_change_rows(f"기준: {source}",rows)
            except Exception as exc:
                self._show_change_rows(f"변경 비교 실패: {exc}",[])

        def create_baseline_gui(self) -> None:
            if not self.project:return
            overwrite=self.project.baseline_exists
            prompt=("기존 기준점을 현재 상태로 덮어쓸까요?" if overwrite else
                    "현재 ED2MAIN.EXE, 모든 M_*.DLL과 상점 T_*.DLL을 변경 비교 기준점으로 저장할까요?")
            if not messagebox.askyesno(APP_NAME,prompt):return
            try:
                self.project.create_baseline(overwrite=overwrite);self.populate_changes()
                messagebox.showinfo(APP_NAME,"기준점을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def preview_preset_gui(self) -> None:
            if not self.project:return
            try:
                rows=self.project.preview_builtin_preset(self.preset_var.get())
                self._show_change_rows(f"프리셋 미리보기: {self.preset_var.get()}",rows)
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def apply_preset_gui(self) -> None:
            if not self.project:return
            try:
                rows=self.project.preview_builtin_preset(self.preset_var.get())
                if not rows:
                    messagebox.showinfo(APP_NAME,"변경할 항목이 없습니다.");return
                if not messagebox.askyesno(APP_NAME,f"'{self.preset_var.get()}' 프리셋의 {len(rows)}개 변경을 적용할까요?\n각 파일의 최초 원본은 .bak로 보존됩니다."):return
                count=self.project.apply_builtin_preset(self.preset_var.get());self.reload_project()
                messagebox.showinfo(APP_NAME,f"프리셋 적용 완료: {count}개 항목")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def export_balance_preset_gui(self) -> None:
            if not self.project:return
            path=filedialog.asksaveasfilename(defaultextension=".json",initialfile="ED2_BALANCE_PRESET.json",filetypes=[("JSON","*.json")])
            if not path:return
            try:self.project.export_balance_preset(Path(path));messagebox.showinfo(APP_NAME,"커스텀 밸런스 프리셋을 저장했습니다.")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        def import_balance_preset_gui(self) -> None:
            if not self.project:return
            path=filedialog.askopenfilename(filetypes=[("JSON","*.json")])
            if not path or not messagebox.askyesno(APP_NAME,"이 커스텀 밸런스 프리셋을 적용할까요?"):return
            try:
                count=self.project.import_balance_preset(Path(path));self.reload_project()
                messagebox.showinfo(APP_NAME,f"커스텀 프리셋 적용 완료: {count}개 변경")
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Audio -----------------------------------------------------------
        def _build_audio_tab(self) -> None:
            tab=ttk.Frame(self.nb);outer,content=self._scrollable_panel(tab,padding=20);outer.pack(fill="both",expand=True);self.nb.add(tab,text="음악·VGM")
            ttk.Label(content,text="기존 MUS / INS / VGM 도구",style="Title.TLabel").pack(anchor="w")
            ttk.Label(content,text="VGM/VGZ→MUS+INS, OPL 악기, MUS 이벤트 편집 도구를 별도 창으로 실행합니다.",wraplength=900).pack(anchor="w",pady=(10,12))
            ttk.Button(content,text="오디오 도구 열기",command=self.launch_audio_tool).pack(anchor="w")

        def launch_audio_tool(self) -> None:
            if not self.audio_tool or not self.audio_tool.exists():messagebox.showerror(APP_NAME,"ed2_audio_tool.py를 찾을 수 없습니다.");return
            args=[sys.executable,str(self.audio_tool)]
            if self.project:args.append(str(self.project.root))
            try:
                import subprocess;subprocess.Popen(args,cwd=str(self.audio_tool.parent))
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

        # Diagnostics -----------------------------------------------------
        def _build_diagnostics_tab(self) -> None:
            tab=ttk.Frame(self.nb,padding=10);self.nb.add(tab,text="검사·분석")
            top=ttk.Frame(tab);top.pack(fill="x")
            ttk.Button(top,text="검사 다시 실행",command=self.run_validation).pack(side="left")
            ttk.Button(top,text="분석 파일 묶음 내보내기",command=self.export_analysis).pack(side="left",padx=6)
            holder=ttk.Frame(tab);holder.pack(fill="both",expand=True,pady=(8,0))
            self.diag_text=self._text(holder)

        def update_diagnostics(self) -> None:
            if not self.project:self._readonly_text(self.diag_text,"");return
            report=self.project.validate()
            lines=[report["tool"],f"Root: {report['root']}","",json.dumps(report["counts"],ensure_ascii=False,indent=2),"",f"Errors ({len(report['errors'])})"]
            lines.extend("  - "+x for x in report["errors"]);lines.extend(["",f"Warnings ({len(report['warnings'])})"]);lines.extend("  - "+x for x in report["warnings"])
            lines.extend(["",f"Notes ({len(report.get('notes',[]))})"]);lines.extend("  - "+x for x in report.get("notes",[]))
            lines.extend([
                "", "v0.13.1 추가:",
                "- stat group 3 / PLY_INT2 (+0x0A) 표시를 주문능력으로 정정",
                "", "v0.13.0 추가:",
                "  ED2MAIN PL_DATA_1~4에서 아트라스·란도·플로라·신디 초기 장비 직접 편집",
                "  +0x19 무기 / +0x1A 갑옷 / +0x1B 방패 / +0x1C 반지·부적",
                "  ITEM_TYPE 슬롯 비트로 장비 종류를 검증해 잘못된 슬롯 저장 방지",
                "  분석 묶음에 ED2_PLAYER_INITIAL_EQUIPMENT.csv 추가",
                "", "v0.12.8 추가:",
                "  비례 아이템 ITEM_MAGIC_NUM을 원시값 1당 5%로 표시·편집",
                "  예: raw 5=25%, 16=80%, 18=90%, 20=100%, 40=200%",
                "  구버전 개별 비례 x10 상태를 자동 감지해 실효 비율 보존 후 x5% 상태로 변환",
                "  CSV/검사 화면도 현재 5% 단위의 실효 비율을 기준으로 표시",
                "", "v0.12.3 추가:",
                "  일반전투 Gold 90% 보정과 Gold 레벨 스케일링을 각각 독립적으로 해제/복원",
                "  ADD_MO_GOLD 86:41D3 / 86:41D7 호출을 안전하게 제자리 패치",
                "", "v0.12.0 추가:",
                "  SCENA/T_*.DLL 상점 상품 목록 자동 검출·편집",
                "  진행 조건에 따라 바뀌는 상점 재고를 조건별로 분리 표시",
                "  원본 상품 슬롯 범위 안에서 교체·삭제·재정렬",
                "  상점 화면에서 ITEM_COST 전역 가격 편집",
                "  ED2_SHOPS.csv 가져오기·내보내기와 SCENA 기준점 복원",
                "", "v0.11.0 추가:",
                "  주문 재충전 주기를 선택 주문 또는 전체 32개에 일괄 통일",
                "  기절/전투불능 파티원의 경험치 획득과 분배 인원 포함을 독립 선택",
                "  전투 총 경험치의 파티원 수 분배 해제",
                "  일반전투 EXP 90% 보정 및 레벨 차이 경험치 감소를 독립 해제",
                "  경험치 분배 미리 보기와 원본 코드 패턴 검증",
                "", "v0.10.0 추가:",
                "  전투 경로별 실제 드롭 확률과 반복 전투 누적 확률 계산",
                "  CALC_DMG_PST 기반 HP 조건을 퍼센트로 안전 편집",
                "  동적 드롭·보상·BGM·전투 훅의 특수 규칙 자동 경고",
                "  기준점/.bak 대비 변경 전후 비교와 내장·커스텀 프리셋",
                "  획득 불가 드롭, 충돌하는 AI 확률, 과도한 마력 비례, MAGIC_CNT 위험 검사",
                "", "v0.9.2 추가:",
                "  NE 재배치 표에서 ED2MAIN _MO_ATT_TRP imported ordinal 0x023A 참조 자동 검출",
                "  초기 드롭 확률과 전투 중 AI 변경값을 별도 표시",
                "  확인된 AI 즉시값 쓰기를 0~100% 범위에서 안전 편집",
                "", "v0.9.1 추가:",
                "  일반 아이템 76개마다 고정 위력/플레이어 마력 비례 방식을 독립 선택",
                "  원본 코드와 v0.9.0 전역 비례 패치에서 개별 선택 방식으로 안전하게 전환",
                "  원본 고정 가상 마력 방식 복원 지원",
            ])
            self._readonly_text(self.diag_text,"\n".join(lines))

        def run_validation(self) -> None:
            if not self.project:return
            self.project.reload();self.populate_all();report=self.project.validate();messagebox.showinfo(APP_NAME,f"검사 완료: 오류 {len(report['errors'])}, 경고 {len(report['warnings'])}")

        def export_analysis(self) -> None:
            if not self.project:return
            folder=filedialog.askdirectory(title="분석 파일을 저장할 폴더")
            if not folder:return
            try:files=write_analysis_bundle(self.project,Path(folder));messagebox.showinfo(APP_NAME,"저장 완료:\n"+"\n".join(p.name for p in files))
            except Exception as exc:messagebox.showerror(APP_NAME,str(exc))

    Studio().mainloop()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[list[str]] = None) -> int:
    parser=argparse.ArgumentParser(description=f"{APP_NAME} {VERSION}")
    parser.add_argument("root",nargs="?",type=Path,help="ED2 game root")
    parser.add_argument("--report",type=Path,help="write validation JSON")
    parser.add_argument("--export-analysis",type=Path,help="export CSV/JSON analysis bundle")
    parser.add_argument("--item-magic-support",choices=("status","install","restore"),help="inspect, install, or restore per-item magic-power mode support")
    parser.add_argument("--item-magic-mode",metavar="ITEM_ID:MODE",help="set one item to fixed or proportional, e.g. 34:proportional")
    parser.add_argument("--item-magic-scaling",choices=("status","on","off"),help="v0.9.0 compatibility: set every item proportional or restore all fixed")
    parser.add_argument("--ai-drop",metavar="DLL:SEGMENT:OFFSET:VALUE",help="edit one immediate AI _MO_ATT_TRP write, e.g. M_327.DLL:3:0x245:5")
    parser.add_argument("--ai-hp-condition",metavar="DLL:SEGMENT:CMP_OFFSET:PERCENT",help="edit a confirmed CALC_DMG_PST HP threshold, e.g. M_327.DLL:3:0x1D1:50")
    parser.add_argument("--drop-probability",metavar="DLL:SCENARIO_INDEX:BATTLES",help="calculate cumulative drop probability for one detected path")
    parser.add_argument("--baseline",choices=("status","create","restore"),help="inspect, create, or restore the comparison baseline")
    parser.add_argument("--builtin-preset",choices=("drop2x","rare5","magic-proportional","all-fixed","restore-baseline"),help="apply a built-in balance preset")
    parser.add_argument("--export-balance-preset",type=Path,help="write current drop/AI/item-magic settings as JSON")
    parser.add_argument("--import-balance-preset",type=Path,help="apply a balance preset JSON")
    parser.add_argument("--magic-recharge",metavar="VALUE",help="unify MAGIC_CNT, e.g. 0x11")
    parser.add_argument("--magic-ids",default="all",help="magic IDs for --magic-recharge: all, 0,1,4-7")
    parser.add_argument("--experience-rules",choices=("status","original","include-stunned","no-split","include-stunned-no-split","full"),help="inspect or apply experience-award rules")
    parser.add_argument("--gold-rules",choices=("status","original","no-90","no-level","full"),help="inspect or apply Gold 90% and level-scaling rules")
    parser.add_argument("--player-equipment-preset",choices=("1","2"),help="apply bundled player initial-equipment preset 1 or 2")
    parser.add_argument("--import-player-equipment-csv",type=Path,help="import player initial-equipment CSV")
    parser.add_argument("--export-player-equipment-csv",type=Path,help="export current player initial-equipment CSV")
    parser.add_argument("--no-gui",action="store_true")
    args=parser.parse_args(argv)
    has_cli_action=any((
        args.report,args.export_analysis,args.item_magic_support,args.item_magic_mode,args.item_magic_scaling,
        args.ai_drop,args.ai_hp_condition,args.drop_probability,args.baseline,args.builtin_preset,
        args.export_balance_preset,args.import_balance_preset,args.magic_recharge,args.experience_rules,args.gold_rules,
        args.player_equipment_preset,args.import_player_equipment_csv,args.export_player_equipment_csv,args.no_gui,
    ))
    if args.root and has_cli_action:
        write_actions=[
            args.item_magic_support in ("install","restore"),
            bool(args.item_magic_mode),
            args.item_magic_scaling in ("on","off"),
            bool(args.ai_drop),bool(args.ai_hp_condition),
            args.baseline in ("create","restore"),
            bool(args.builtin_preset),bool(args.import_balance_preset),bool(args.magic_recharge),
            args.experience_rules not in (None,"status"),
            args.gold_rules not in (None,"status"),
            bool(args.player_equipment_preset),bool(args.import_player_equipment_csv),bool(args.export_player_equipment_csv),
        ]
        if sum(bool(value) for value in write_actions)>1:
            parser.error("use only one write action at a time")
        exe=args.root/"ED2MAIN.EXE"
        item_id: Optional[int]=None
        ai_drop_result: Optional[tuple[str,int,int,int]]=None
        ai_condition_result: Optional[tuple[str,int,int,float,int]]=None
        if args.item_magic_support=="install":install_item_magic_mode_patch(exe,None,True)
        elif args.item_magic_support=="restore":restore_item_magic_original(exe,True)
        if args.item_magic_mode:
            try:
                item_text,mode_text=args.item_magic_mode.split(":",1)
                item_id=parse_number(item_text,0,ITEM_COUNT-1,"item ID");mode=normalize_item_magic_mode(mode_text)
                set_item_magic_mode(exe,item_id,mode,True)
            except Exception as exc:parser.error(str(exc))
        if args.item_magic_scaling in ("on","off"):
            patch_item_magic_scaling(exe,args.item_magic_scaling=="on",True)
        if args.ai_drop:
            try:
                dll_text,segment_text,offset_text,value_text=args.ai_drop.split(":",3)
                dll_name=Path(dll_text).name.upper();dll_name=dll_name if dll_name.endswith(".DLL") else dll_name+".DLL"
                segment_index=parse_number(segment_text,1,255,"segment")
                instruction_offset=parse_number(offset_text,0,0xFFFF,"instruction offset")
                value=parse_number(value_text,0,100,"AI drop chance")
                dll_path=args.root/"MON"/dll_name
                refs=analyze_dynamic_drop_references(dll_path)
                ref=next((item for item in refs if item.segment_index==segment_index and item.instruction_offset==instruction_offset and item.editable),None)
                if ref is None:raise ValueError("editable AI drop write was not found at that location")
                patch_dynamic_drop_reference(ref,value,True);ai_drop_result=(dll_name,segment_index,instruction_offset,value)
            except Exception as exc:parser.error(str(exc))
        if args.ai_hp_condition:
            try:
                dll_text,segment_text,offset_text,percent_text=args.ai_hp_condition.split(":",3)
                dll_name=Path(dll_text).name.upper();dll_name=dll_name if dll_name.endswith(".DLL") else dll_name+".DLL"
                segment_index=parse_number(segment_text,1,255,"segment")
                instruction_offset=parse_number(offset_text,0,0xFFFF,"CMP instruction offset")
                percent=float(percent_text)
                conditions=analyze_dynamic_drop_conditions(args.root/"MON"/dll_name)
                ref=next((item for item in conditions if item.segment_index==segment_index and item.instruction_offset==instruction_offset and item.editable),None)
                if ref is None:raise ValueError("editable AI HP condition was not found at that location")
                raw=patch_ai_condition_threshold(ref,percent,True)
                ai_condition_result=(dll_name,segment_index,instruction_offset,hp_ratio_raw_to_percent(raw),raw)
            except Exception as exc:parser.error(str(exc))

        if args.magic_recharge:
            try:
                recharge_value=parse_number(args.magic_recharge,0,255,"MAGIC_CNT")
                recharge_ids=parse_magic_id_list(args.magic_ids)
                changed=patch_magic_recharge_bulk(exe,recharge_ids,recharge_value,True)
                print(f"magic_recharge=0x{recharge_value:02X} targets={len(recharge_ids)} changed={changed}")
            except Exception as exc:parser.error(str(exc))
        if args.experience_rules and args.experience_rules!="status":
            try:
                exp_state=experience_preset_state(args.experience_rules)
                changed=patch_experience_rules(exe,exp_state,True)
                print(f"experience_rules={exp_state.summary} changed_regions={changed}")
            except Exception as exc:parser.error(str(exc))
        if args.gold_rules and args.gold_rules!="status":
            try:
                gold_state=gold_reward_preset_state(args.gold_rules)
                changed=patch_gold_reward_rules(exe,gold_state,True)
                print(f"gold_rules={gold_state.summary} changed_regions={changed}")
            except Exception as exc:parser.error(str(exc))

        project=Project(args.root)
        preset_names={
            "drop2x":"드롭률 2배","rare5":"희귀 드롭 최소 5%",
            "magic-proportional":"ITEM_MAGIC_NUM 아이템 비례화","all-fixed":"모든 아이템 고정 위력",
            "restore-baseline":"기준점 상태 복원",
        }
        if args.baseline=="create":project.create_baseline(overwrite=project.baseline_exists);project.reload()
        elif args.baseline=="restore":project.restore_baseline()
        if args.builtin_preset:
            count=project.apply_builtin_preset(preset_names[args.builtin_preset]);print(f"preset_changes={count}")
        if args.import_balance_preset:
            count=project.import_balance_preset(args.import_balance_preset);print(f"imported_preset_changes={count}")
        if args.export_balance_preset:
            args.export_balance_preset.parent.mkdir(parents=True,exist_ok=True);project.export_balance_preset(args.export_balance_preset)
        if args.player_equipment_preset:
            preset_path=Path(__file__).resolve().parent/"presets"/f"ED2_PLAYER_INITIAL_EQUIPMENT_{args.player_equipment_preset}.csv"
            count=project.import_player_equipment_csv(preset_path); project.reload(); print(f"player_equipment_preset={args.player_equipment_preset} changed_bytes={count}")
        if args.import_player_equipment_csv:
            count=project.import_player_equipment_csv(args.import_player_equipment_csv); project.reload(); print(f"player_equipment_csv_changes={count}")
        if args.export_player_equipment_csv:
            args.export_player_equipment_csv.parent.mkdir(parents=True,exist_ok=True); project.export_player_equipment_csv(args.export_player_equipment_csv); print(f"player_equipment_csv_export={args.export_player_equipment_csv}")
        if args.item_magic_support or args.item_magic_scaling:
            proportional=sum(item.magic_mode=="proportional" for item in project.items)
            print(f"item_magic_support={project.item_magic_scaling} proportional={proportional} fixed={ITEM_COUNT-proportional}")
        if item_id is not None:
            item=project.items[item_id];print(f"item_magic_mode[{item_id}:{item.name}]={item.magic_mode}")
        if ai_drop_result:
            dll_name,segment_index,instruction_offset,value=ai_drop_result
            print(f"ai_drop[{dll_name}:seg{segment_index}:0x{instruction_offset:04X}]={value}%")
        if ai_condition_result:
            dll_name,segment_index,instruction_offset,percent,raw=ai_condition_result
            print(f"ai_hp_condition[{dll_name}:seg{segment_index}:0x{instruction_offset:04X}]={percent:.1f}% raw=0x{raw:02X}")
        if args.drop_probability:
            try:
                dll_text,index_text,battles_text=args.drop_probability.split(":",2)
                dll_name=Path(dll_text).name.upper();dll_name=dll_name if dll_name.endswith(".DLL") else dll_name+".DLL"
                group=next((g for g in project.groups if g.dll_path.name.upper()==dll_name),None)
                if group is None:raise ValueError("monster group was not found")
                scenario_index=parse_number(index_text,0,len(group.drop_scenarios)-1,"scenario index")
                battles=parse_number(battles_text,1,1000000,"battles")
                label,chance=group.drop_scenarios[scenario_index]
                print(json.dumps({"dll":dll_name,"scenario_index":scenario_index,"scenario":label,"chance":chance,"battles":battles,**drop_probability_summary(chance,battles)},ensure_ascii=False,indent=2))
            except Exception as exc:parser.error(str(exc))
        if args.experience_rules:
            print("experience_rules="+json.dumps(project.experience_rules.to_dict(),ensure_ascii=False))
        if args.gold_rules:
            print("gold_rules="+json.dumps(project.gold_reward_rules.to_dict(),ensure_ascii=False))
        if args.baseline:
            print(f"baseline={'present' if project.baseline_exists else 'missing'} path={project.baseline_dir}")
        if args.report:
            args.report.parent.mkdir(parents=True,exist_ok=True)
            args.report.write_text(json.dumps(project.validate(),ensure_ascii=False,indent=2),encoding="utf-8")
        if args.export_analysis:write_analysis_bundle(project,args.export_analysis)
        if has_cli_action:
            print(json.dumps(project.validate(),ensure_ascii=False,indent=2));return 0
    audio_tool=Path(__file__).with_name("ed2_audio_tool.py")
    run_gui(args.root,audio_tool)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
