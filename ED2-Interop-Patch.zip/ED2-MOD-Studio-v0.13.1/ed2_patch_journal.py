#!/usr/bin/env python3
"""Byte-range patch journals for interoperable ED2 tools.

A normal .bak remains as an emergency full-file copy.  The journal is used by
ordinary Restore buttons so one tool only reverts the bytes it owns and leaves
later changes made by other tools intact.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

FORMAT = "ED2 selective patch journal"
VERSION = 1


class JournalError(RuntimeError):
    pass


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def journal_path(path: Path, component: str) -> Path:
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in component)
    return path.with_name(path.name + f".{safe}.journal.json")


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".journal.tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_replace(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(text.encode("ascii"), validate=True)


def _load(path: Path, component: str) -> dict[str, Any] | None:
    jp = journal_path(path, component)
    if not jp.is_file():
        return None
    try:
        raw = json.loads(jp.read_text(encoding="utf-8"))
    except Exception as exc:
        raise JournalError(f"패치 기록을 읽을 수 없습니다: {jp}") from exc
    if raw.get("format") != FORMAT or raw.get("version") != VERSION:
        raise JournalError(f"지원하지 않는 패치 기록 형식입니다: {jp}")
    if raw.get("component") != component:
        raise JournalError(f"패치 기록 구성 요소가 다릅니다: {jp}")
    return raw


def _range_map(journal: dict[str, Any]) -> dict[int, tuple[int, int]]:
    result: dict[int, tuple[int, int]] = {}
    for row in journal.get("ranges", []):
        offset = int(row["offset"])
        original = _unb64(row["original"])
        expected = _unb64(row["expected"])
        if len(original) != len(expected):
            raise JournalError("패치 기록의 원본/적용 길이가 다릅니다.")
        for i, (a, b) in enumerate(zip(original, expected)):
            result[offset + i] = (a, b)
    return result


def _compress(mapping: dict[int, tuple[int, int]]) -> list[dict[str, Any]]:
    if not mapping:
        return []
    rows: list[dict[str, Any]] = []
    keys = sorted(mapping)
    start = previous = keys[0]
    original = bytearray([mapping[start][0]])
    expected = bytearray([mapping[start][1]])
    for key in keys[1:]:
        if key == previous + 1:
            original.append(mapping[key][0])
            expected.append(mapping[key][1])
        else:
            rows.append({"offset": start, "original": _b64(bytes(original)), "expected": _b64(bytes(expected))})
            start = key
            original = bytearray([mapping[key][0]])
            expected = bytearray([mapping[key][1]])
        previous = key
    rows.append({"offset": start, "original": _b64(bytes(original)), "expected": _b64(bytes(expected))})
    return rows


def record_patch(path: Path, before: bytes, after: bytes, component: str) -> int:
    """Merge one successful mutation into the component journal.

    Same-size files use byte ranges.  A file that only grows uses a guarded
    append journal plus byte ranges in the original prefix, allowing Restore
    to truncate this component's tail while preserving unrelated prefix edits.
    Other size changes fall back to a guarded whole-file snapshot.
    """
    if os.environ.get("ED2_AIO_NO_COMPONENT_JOURNAL") == "1":
        # The AIO owns an external transaction snapshot, so per-component
        # selective-restore journals are redundant I/O. Preserve the changed-byte
        # count expected by callers without writing metadata files.
        return sum(a != b for a, b in zip(before, after)) + abs(len(after) - len(before))
    if before == after:
        return 0
    jp = journal_path(path, component)
    existing = _load(path, component)

    if len(before) != len(after):
        if len(after) > len(before) and existing is None:
            mapping: dict[int, tuple[int, int]] = {}
            for offset, (old, new) in enumerate(zip(before, after[:len(before)])):
                if old != new:
                    mapping[offset] = (old, new)
            journal = {
                "format": FORMAT,
                "version": VERSION,
                "component": component,
                "file_name": path.name,
                "mode": "resize_append",
                "original_size": len(before),
                "expected_size": len(after),
                "ranges": _compress(mapping),
                "appended": _b64(after[len(before):]),
            }
            _atomic_write(jp, json.dumps(journal, ensure_ascii=False, indent=2).encode("utf-8"))
            return sum(a != b for a, b in zip(before, after[:len(before)])) + len(after) - len(before)

        if existing and existing.get("mode") != "whole_file":
            raise JournalError("기존 바이트/추가 영역 기록과 호환되지 않는 크기 변경입니다.")
        if existing:
            original = _unb64(existing["original_file"])
            expected_before = existing.get("expected_sha256")
            if _sha256(before) not in (expected_before, _sha256(original)):
                raise JournalError("다른 도구가 같은 크기 변경 파일을 수정해 패치 기록을 갱신할 수 없습니다.")
        else:
            original = before
        journal = {
            "format": FORMAT,
            "version": VERSION,
            "component": component,
            "file_name": path.name,
            "mode": "whole_file",
            "original_file": _b64(original),
            "original_sha256": _sha256(original),
            "expected_sha256": _sha256(after),
            "expected_size": len(after),
        }
        _atomic_write(jp, json.dumps(journal, ensure_ascii=False, indent=2).encode("utf-8"))
        return max(len(before), len(after))

    if existing and existing.get("mode") == "whole_file":
        original = _unb64(existing["original_file"])
        if _sha256(before) not in (existing.get("expected_sha256"), _sha256(original)):
            raise JournalError("다른 도구가 같은 파일을 수정해 전체 파일 패치 기록을 갱신할 수 없습니다.")
        existing["expected_sha256"] = _sha256(after)
        existing["expected_size"] = len(after)
        _atomic_write(jp, json.dumps(existing, ensure_ascii=False, indent=2).encode("utf-8"))
        return sum(a != b for a, b in zip(before, after))

    mode = existing.get("mode") if existing else "ranges"
    mapping = _range_map(existing) if existing else {}
    changed = 0
    for offset, (old, new) in enumerate(zip(before, after)):
        if old == new:
            continue
        changed += 1
        if offset in mapping:
            original, expected = mapping[offset]
            if old not in (original, expected):
                raise JournalError(
                    f"0x{offset:X}가 이 도구의 마지막 적용값과 다릅니다. "
                    "다른 패치와 같은 바이트를 수정한 것으로 보입니다."
                )
            if new == original:
                mapping.pop(offset, None)
            else:
                mapping[offset] = (original, new)
        else:
            mapping[offset] = (old, new)

    if mode == "resize_append":
        existing["ranges"] = _compress(mapping)
        _atomic_write(jp, json.dumps(existing, ensure_ascii=False, indent=2).encode("utf-8"))
        return changed

    if not mapping:
        if jp.exists():
            jp.unlink()
        return changed

    journal = {
        "format": FORMAT,
        "version": VERSION,
        "component": component,
        "file_name": path.name,
        "mode": "ranges",
        "file_size": len(after),
        "ranges": _compress(mapping),
    }
    _atomic_write(jp, json.dumps(journal, ensure_ascii=False, indent=2).encode("utf-8"))
    return changed

def selective_restore(path: Path, component: str) -> int:
    """Restore only this component's bytes, refusing overlapping unknown edits."""
    journal = _load(path, component)
    if journal is None:
        raise FileNotFoundError(f"선택적 복원 기록이 없습니다: {journal_path(path, component).name}")
    current = path.read_bytes()
    mode = journal.get("mode")
    if mode == "resize_append":
        original_size = int(journal["original_size"])
        expected_size = int(journal["expected_size"])
        appended = _unb64(journal["appended"])
        if len(current) != expected_size:
            raise JournalError(f"{path.name} 크기가 추가 영역 패치 기록과 다릅니다.")
        if current[original_size:] != appended:
            raise JournalError(
                f"{path.name}의 추가 코드 영역이 다른 도구에 의해 변경되었습니다. "
                "해당 변경을 보존하기 위해 복원을 중단합니다."
            )
        mapping = _range_map(journal)
        output = bytearray(current[:original_size])
        conflicts: list[int] = []
        restored = len(current) - original_size
        for offset, (original, expected) in mapping.items():
            value = output[offset]
            if value == expected:
                output[offset] = original
                restored += 1
            elif value == original:
                continue
            else:
                conflicts.append(offset)
        if conflicts:
            preview = ", ".join(f"0x{x:X}" for x in conflicts[:12])
            more = " ..." if len(conflicts) > 12 else ""
            raise JournalError(
                f"{path.name}의 {len(conflicts)}바이트가 다른 도구에 의해 변경되었습니다 "
                f"({preview}{more}). 해당 변경을 보존하기 위해 복원을 중단합니다."
            )
        atomic_replace(path, bytes(output))
    elif mode == "whole_file":
        original = _unb64(journal["original_file"])
        current_hash = _sha256(current)
        if current_hash == journal.get("original_sha256"):
            restored = 0
        elif current_hash == journal.get("expected_sha256"):
            atomic_replace(path, original)
            restored = max(len(current), len(original))
        else:
            raise JournalError(
                f"{path.name}이 기록된 적용본과 다릅니다. 다른 도구의 변경을 지우지 않기 위해 복원을 중단합니다."
            )
    elif mode == "ranges":
        expected_size = int(journal.get("file_size", len(current)))
        if len(current) != expected_size:
            raise JournalError(f"{path.name} 크기가 패치 기록과 다릅니다.")
        mapping = _range_map(journal)
        conflicts: list[int] = []
        output = bytearray(current)
        restored = 0
        for offset, (original, expected) in mapping.items():
            value = current[offset]
            if value == expected:
                output[offset] = original
                restored += 1
            elif value == original:
                continue
            else:
                conflicts.append(offset)
        if conflicts:
            preview = ", ".join(f"0x{x:X}" for x in conflicts[:12])
            more = " ..." if len(conflicts) > 12 else ""
            raise JournalError(
                f"{path.name}의 {len(conflicts)}바이트가 다른 도구에 의해 변경되었습니다 "
                f"({preview}{more}). 해당 변경을 보존하기 위해 복원을 중단합니다."
            )
        if restored:
            atomic_replace(path, bytes(output))
    else:
        raise JournalError("패치 기록 모드가 잘못되었습니다.")

    jp = journal_path(path, component)
    if jp.exists():
        jp.unlink()
    return restored
