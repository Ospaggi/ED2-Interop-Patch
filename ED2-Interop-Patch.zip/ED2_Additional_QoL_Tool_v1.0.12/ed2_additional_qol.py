#!/usr/bin/env python3
from __future__ import annotations

import os

import argparse
import hashlib
import json
import shutil
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

APP_NAME = "ED2 Additional QoL Tool"
VERSION = "1.0.12"
COMPONENT = "ed2_additional_qol_v1"

HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent
sys.path.insert(0, str(HERE))

from ed2_patch_journal import atomic_replace, journal_path, record_patch, selective_restore  # type: ignore


class PatchError(RuntimeError):
    pass


@dataclass(frozen=True)
class NESegment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


def parse_ne_segments(data: bytes | bytearray) -> list[NESegment]:
    """Parse the 16-bit NE segment table needed by this QoL patch.

    Kept local so the standalone QoL component no longer depends on a
    particular ED2-MOD-Studio folder/version being present beside it.
    """
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("지원하는 MZ 실행 파일이 아닙니다.")
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    if ne_off + 0x40 > len(data) or data[ne_off:ne_off + 2] != b"NE":
        raise PatchError("지원하는 16비트 NE 실행 파일이 아닙니다.")
    count = struct.unpack_from("<H", data, ne_off + 0x1C)[0]
    table = ne_off + struct.unpack_from("<H", data, ne_off + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne_off + 0x32)[0]
    if table + count * 8 > len(data):
        raise PatchError("NE 세그먼트 표가 잘렸습니다.")
    result: list[NESegment] = []
    for i in range(count):
        sector, length, flags, min_alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        offset = sector << shift
        real_len = 65536 if length == 0 else length
        if offset > len(data):
            raise PatchError("NE 세그먼트가 파일 범위를 벗어났습니다.")
        result.append(NESegment(i + 1, offset, real_len, flags, min_alloc))
    return result


@dataclass(frozen=True)
class Setting:
    turbo_move: bool = True
    menu_cursor_wrap: bool = True
    menu_key_repeat_fast: bool = True
    dialogue_instant_complete: bool = False


SEG86 = 86
CAVE_START = 0x1800
CAVE_END = 0x1B00
MENU_WRAP_HELPER = 0x1800
MENU_KEY_DETECT_HELPER = 0x1860
DIALOGUE_BEGIN_HELPER = 0x18C0
DIALOGUE_DELAY_HELPER = 0x18E0
DIALOGUE_END_HELPER = 0x1920
BATTLE_HMASK_HELPER = 0x1960
BATTLE_HWRAP_HELPER = 0x1980
TURBO_MOVE_HELPER = 0x19C0

# Common SELECT_MENU direction block.  Wrap ordinary menus, but preserve
# vanilla boundaries for inventory/equipment and the warp-wing town selector.
MENU_WRAP_SITE = 0xA057
MENU_WRAP_RETURN_CHANGED = 0xA06D
MENU_WRAP_RETURN_NONE = 0xA0AC
MENU_WRAP_ORIGINAL = bytes.fromhex(
    "F6 C4 01 75 0D F6 C4 02 74 4B FE C0 3A C1 72 06 EB 43 FE C8 78 3F"
)

# SELECT_MENU calls KEY_DETECT here. v1.0.27 keeps the vanilla 20-tick
# initial delay and accelerates only the held-key repeat interval from 8 to 4
# ticks for every menu selector, including inventory and the warp-wing menu.
# Non-menu MESS_PAUSE remains on vanilla INKEY$ timing.
MENU_KEY_DETECT_SITE = 0xA023
MENU_KEY_DETECT_ORIGINAL = bytes.fromhex("E8 BF D5")

# v1.0.19 changed KEY_DETECT globally to 10/4.  v1.0.20 restores these
# constants and performs menu-only acceleration through the wrapper above.
KEY_REPEAT_SITE = 0x75FD
KEY_REPEAT_ORIGINAL = bytes.fromhex("B5 08")
KEY_REPEAT_V119_FAST = bytes.fromhex("B5 04")
KEY_INITIAL_SITE = 0x7609
KEY_INITIAL_ORIGINAL = bytes.fromhex("B5 14")
KEY_INITIAL_V119_FAST = bytes.fromhex("B5 0A")

# Dialogue/message renderer. Confirm (0x20) bypasses delay checks only for the
# current renderer invocation; it does not modify the global 3F42 delay value.
# The end hook waits for release to prevent the same press advancing next text.
DIALOGUE_BEGIN_SITE = 0x87BA
DIALOGUE_BEGIN_ORIGINAL = bytes.fromhex("33 C0 87 06 A6 91")
DIALOGUE_DELAY_SITES = (0x8904, 0x8920)
DIALOGUE_DELAY_ORIGINAL = bytes.fromhex("80 3E 42 3F 00")
DIALOGUE_END_SITE = 0x898D
DIALOGUE_END_ORIGINAL = bytes.fromhex("8B 46 FE A3 A6 91")

# Battle command menu horizontal edge handling.  This is the common 2-D menu
# that does not already wrap horizontally.  Inventory and SELECT_TOWN are not
# patched here.
BATTLE_HMASK_SITE = 0x399F
BATTLE_HMASK_ORIGINAL = bytes.fromhex("3C 02 73 0A FE C1 B5 08 22 C0 74 02 B5 0C")
BATTLE_HWRAP_SITE = 0x39C7
BATTLE_HWRAP_ORIGINAL = bytes.fromhex(
    "8A E0 8A 44 01 F6 C4 04 75 07 F6 C4 08 75 06 EB C1 FE C8 EB 0E "
    "FE C0 3C 02 75 08 80 3C 02 75 03 C6 04 01"
)

# Other menu selectors that call INKEY$ directly rather than through
# SELECT_MENU2. Redirect them to the same 20/4 repeat wrapper.
SELECT_CHR_KEY_SITE = 0x98D0
SELECT_CHR_KEY_ORIGINAL = bytes.fromhex("E8 12 DD")
SELECT_MONSTER_KEY_SITE = 0x99F0
SELECT_MONSTER_KEY_ORIGINAL = bytes.fromhex("E8 F2 DB")

# Removed v1.0.10/v1.0.11 features; always restore their relocation targets.
REMOVED_SHOP_RELOCS = {0x24AB: (0x9944, 0x1800)}
REMOVED_EQUIP_RELOCS = {
    0x468F: (0x9AB0, 0x1900),
    0x4699: (0x9B01, 0x1915),
    0x9B0D: (0x84FF, 0x1922),
    0x9BD2: (0x84FF, 0x1922),
    0x9BDF: (0x84FF, 0x1922),
}

TURBO_SITE = 0x9877
TURBO_ORIGINAL = bytes.fromhex("A0 48 20")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_root(root: Path) -> Path:
    root = root.expanduser().resolve()
    if not (root / "ED2MAIN.EXE").is_file():
        raise PatchError("ED2MAIN.EXE가 있는 영웅전설 II 게임 폴더를 선택해야 합니다.")
    return root


def _near(site: int, target: int, opcode: int = 0xE9) -> bytes:
    displacement = (target - (site + 3)) & 0xFFFF
    return bytes((opcode, displacement & 0xFF, displacement >> 8))


def _load_helper(name: str) -> bytes:
    raw = (HERE / name).read_bytes()
    expected = CAVE_END - CAVE_START
    if len(raw) != expected:
        raise PatchError(f"{name} 크기 오류: {len(raw)} (정상 {expected})")
    return raw


def load_helper() -> bytes:
    return _load_helper("helpers_v131.bin")


def load_previous_helpers() -> tuple[bytes, ...]:
    names = ("helpers_v130.bin", "helpers_v129.bin", "helpers_v128.bin", "helpers_v127.bin", "helpers_v121.bin", "helpers_v120.bin", "helpers_v119.bin", "helpers_v112.bin", "helpers_v111.bin", "helpers_v110_legacy.bin")
    return tuple(_load_helper(name) for name in names)


def _patch_cave(code86: bytearray, enabled: bool, helper: bytes, previous: tuple[bytes, ...]) -> None:
    current = bytes(code86[CAVE_START:CAVE_END])
    zero = b"\0" * (CAVE_END - CAVE_START)
    if current not in (zero, helper, *previous):
        raise PatchError("ED2MAIN 86:1800~1AFF가 다른 패치에서 사용 중입니다.")
    code86[CAVE_START:CAVE_END] = helper if enabled else zero


def _patch_site(code86: bytearray, offset: int, original: bytes, patched: bytes, enabled: bool) -> None:
    current = bytes(code86[offset:offset + len(original)])
    if current not in (original, patched):
        raise PatchError(
            f"ED2MAIN 코드 86:{offset:04X}가 지원 상태와 다릅니다. "
            f"현재={current.hex(' ')} 원본={original.hex(' ')}"
        )
    code86[offset:offset + len(original)] = patched if enabled else original


def _patch_menu_wrap(code86: bytearray, enabled: bool) -> None:
    hook = _near(MENU_WRAP_SITE, MENU_WRAP_HELPER) + b"\x90" * (len(MENU_WRAP_ORIGINAL) - 3)
    _patch_site(code86, MENU_WRAP_SITE, MENU_WRAP_ORIGINAL, hook, enabled)

def _restore_v119_repeat_constants(code86: bytearray) -> None:
    for offset, original, legacy in (
        (KEY_REPEAT_SITE, KEY_REPEAT_ORIGINAL, KEY_REPEAT_V119_FAST),
        (KEY_INITIAL_SITE, KEY_INITIAL_ORIGINAL, KEY_INITIAL_V119_FAST),
    ):
        current = bytes(code86[offset:offset + len(original)])
        if current not in (original, legacy):
            raise PatchError(
                f"ED2MAIN 키 반복 코드 86:{offset:04X}가 지원 상태와 다릅니다: {current.hex(' ')}"
            )
        code86[offset:offset + len(original)] = original


def _patch_menu_key_repeat(code86: bytearray, enabled: bool) -> None:
    for site, original in (
        (MENU_KEY_DETECT_SITE, MENU_KEY_DETECT_ORIGINAL),
        (SELECT_CHR_KEY_SITE, SELECT_CHR_KEY_ORIGINAL),
        (SELECT_MONSTER_KEY_SITE, SELECT_MONSTER_KEY_ORIGINAL),
    ):
        hook = _near(site, MENU_KEY_DETECT_HELPER, 0xE8)
        _patch_site(code86, site, original, hook, enabled)


def _patch_battle_horizontal_wrap(code86: bytearray, enabled: bool) -> None:
    hmask = _near(BATTLE_HMASK_SITE, BATTLE_HMASK_HELPER, 0xE8) + b"\x90" * (len(BATTLE_HMASK_ORIGINAL) - 3)
    _patch_site(code86, BATTLE_HMASK_SITE, BATTLE_HMASK_ORIGINAL, hmask, enabled)
    hwrap = _near(BATTLE_HWRAP_SITE, BATTLE_HWRAP_HELPER, 0xE8) + b"\x90" * (len(BATTLE_HWRAP_ORIGINAL) - 3)
    _patch_site(code86, BATTLE_HWRAP_SITE, BATTLE_HWRAP_ORIGINAL, hwrap, enabled)


def _patch_dialogue_instant(code86: bytearray, enabled: bool) -> None:
    begin_hook = _near(DIALOGUE_BEGIN_SITE, DIALOGUE_BEGIN_HELPER, 0xE8) + b"\x90" * (len(DIALOGUE_BEGIN_ORIGINAL) - 3)
    _patch_site(code86, DIALOGUE_BEGIN_SITE, DIALOGUE_BEGIN_ORIGINAL, begin_hook, enabled)
    delay_hook = lambda site: _near(site, DIALOGUE_DELAY_HELPER, 0xE8) + b"\x90" * (len(DIALOGUE_DELAY_ORIGINAL) - 3)
    for site in DIALOGUE_DELAY_SITES:
        _patch_site(code86, site, DIALOGUE_DELAY_ORIGINAL, delay_hook(site), enabled)
    end_hook = _near(DIALOGUE_END_SITE, DIALOGUE_END_HELPER, 0xE8) + b"\x90" * (len(DIALOGUE_END_ORIGINAL) - 3)
    _patch_site(code86, DIALOGUE_END_SITE, DIALOGUE_END_ORIGINAL, end_hook, enabled)


def _relocation_records(data: bytes | bytearray, segment: Any) -> list[tuple[int, int, int, int, int, int]]:
    if not (segment.flags & 0x0100):
        raise PatchError("ED2MAIN 코드 세그먼트에 재배치 표가 없습니다.")
    pos = segment.file_offset + segment.length
    if pos + 2 > len(data):
        raise PatchError("ED2MAIN 재배치 표가 잘렸습니다.")
    count = struct.unpack_from("<H", data, pos)[0]
    pos += 2
    rows = []
    for index in range(count):
        entry = pos + index * 8
        if entry + 8 > len(data):
            raise PatchError("ED2MAIN 재배치 레코드가 잘렸습니다.")
        source_type, flags, source, target1, target2 = struct.unpack_from("<BBHHH", data, entry)
        rows.append((entry, source_type, flags, source, target1, target2))
    return rows


def patch_internal_relocation(data: bytearray, segment: Any, source: int,
                              original_target: int, patched_target: int, enabled: bool) -> None:
    matches = [row for row in _relocation_records(data, segment) if row[3] == source]
    if len(matches) != 1:
        raise PatchError(f"재배치 source 86:{source:04X} 레코드 수가 {len(matches)}개입니다.")
    entry, source_type, flags, _, target1, current = matches[0]
    if source_type != 0x03 or flags != 0x00 or target1 != SEG86:
        raise PatchError(
            f"재배치 source 86:{source:04X} 형식이 지원 상태와 다릅니다: "
            f"type={source_type:02X} flags={flags:02X} target1={target1:04X}"
        )
    if current not in (original_target, patched_target):
        raise PatchError(f"재배치 source 86:{source:04X} 대상이 지원 상태와 다릅니다: {current:04X}")
    struct.pack_into("<H", data, entry + 6, patched_target if enabled else original_target)


def relocation_targets(data: bytes, segment: Any, sources: set[int]) -> dict[int, int]:
    return {source: target2 for _, _, _, source, _, target2 in _relocation_records(data, segment) if source in sources}


def apply_patch(root: Path, settings: Setting) -> dict[str, Any]:
    root = validate_root(root)
    exe = root / "ED2MAIN.EXE"
    before = exe.read_bytes()
    segments = parse_ne_segments(before)
    if len(segments) < SEG86:
        raise PatchError("지원하는 ED2MAIN.EXE가 아닙니다.")
    s86 = segments[SEG86 - 1]
    code86 = bytearray(before[s86.file_offset:s86.file_offset + s86.length])
    helper = load_helper()
    previous = load_previous_helpers()

    helper_needed = (
        settings.turbo_move or settings.menu_cursor_wrap or settings.menu_key_repeat_fast
    )
    _patch_cave(code86, helper_needed, helper, previous)
    _patch_site(code86, TURBO_SITE, TURBO_ORIGINAL, _near(TURBO_SITE, TURBO_MOVE_HELPER), settings.turbo_move)
    _patch_menu_wrap(code86, settings.menu_cursor_wrap)
    _patch_battle_horizontal_wrap(code86, settings.menu_cursor_wrap)
    _restore_v119_repeat_constants(code86)
    _patch_menu_key_repeat(code86, settings.menu_key_repeat_fast)
    # v1.0.9: restore the vanilla dialogue renderer. The base game already owns confirm-to-complete.
    _patch_dialogue_instant(code86, False)

    after = bytearray(before)
    after[s86.file_offset:s86.file_offset + s86.length] = code86

    for source, (original, patched) in REMOVED_SHOP_RELOCS.items():
        patch_internal_relocation(after, s86, source, original, patched, False)
    for source, (original, patched) in REMOVED_EQUIP_RELOCS.items():
        patch_internal_relocation(after, s86, source, original, patched, False)

    if before != after:
        backup = exe.with_suffix(exe.suffix + ".bak")
        if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") != "1" and not backup.exists():
            shutil.copy2(exe, backup)
        record_patch(exe, before, bytes(after), COMPONENT)
        atomic_replace(exe, bytes(after))

    result = inspect_patch(root)
    result.update({
        "version": VERSION,
        "changed_bytes": sum(a != b for a, b in zip(before, after)),
        "sha256_before": sha256_bytes(before),
        "sha256_after": sha256_bytes(bytes(after)),
        "settings": settings.__dict__,
    })
    return result


def inspect_patch(root: Path) -> dict[str, Any]:
    root = validate_root(root)
    data = (root / "ED2MAIN.EXE").read_bytes()
    segments = parse_ne_segments(data)
    if len(segments) < SEG86:
        raise PatchError("지원하는 ED2MAIN.EXE가 아닙니다.")
    s86 = segments[SEG86 - 1]
    code86 = data[s86.file_offset:s86.file_offset + s86.length]
    helper = load_helper()
    previous = load_previous_helpers()
    sources = set(REMOVED_SHOP_RELOCS) | set(REMOVED_EQUIP_RELOCS)
    targets = relocation_targets(data, s86, sources)

    shop_removed = all(targets.get(source) == original for source, (original, _) in REMOVED_SHOP_RELOCS.items())
    equip_removed = all(targets.get(source) == original for source, (original, _) in REMOVED_EQUIP_RELOCS.items())
    turbo_patch = _near(TURBO_SITE, TURBO_MOVE_HELPER)
    turbo_bytes = bytes(code86[TURBO_SITE:TURBO_SITE + 3])
    menu_hook = _near(MENU_WRAP_SITE, MENU_WRAP_HELPER) + b"\x90" * (len(MENU_WRAP_ORIGINAL) - 3)
    menu_bytes = bytes(code86[MENU_WRAP_SITE:MENU_WRAP_SITE + len(MENU_WRAP_ORIGINAL)])
    battle_hmask_hook = _near(BATTLE_HMASK_SITE, BATTLE_HMASK_HELPER, 0xE8) + b"\x90" * (len(BATTLE_HMASK_ORIGINAL) - 3)
    battle_hwrap_hook = _near(BATTLE_HWRAP_SITE, BATTLE_HWRAP_HELPER, 0xE8) + b"\x90" * (len(BATTLE_HWRAP_ORIGINAL) - 3)
    battle_hmask_bytes = bytes(code86[BATTLE_HMASK_SITE:BATTLE_HMASK_SITE + len(BATTLE_HMASK_ORIGINAL)])
    battle_hwrap_bytes = bytes(code86[BATTLE_HWRAP_SITE:BATTLE_HWRAP_SITE + len(BATTLE_HWRAP_ORIGINAL)])
    repeat_bytes = bytes(code86[KEY_REPEAT_SITE:KEY_REPEAT_SITE + 2])
    initial_bytes = bytes(code86[KEY_INITIAL_SITE:KEY_INITIAL_SITE + 2])
    menu_key_hook = _near(MENU_KEY_DETECT_SITE, MENU_KEY_DETECT_HELPER, 0xE8)
    menu_key_bytes = bytes(code86[MENU_KEY_DETECT_SITE:MENU_KEY_DETECT_SITE + len(MENU_KEY_DETECT_ORIGINAL)])
    dialogue_begin_hook = _near(DIALOGUE_BEGIN_SITE, DIALOGUE_BEGIN_HELPER, 0xE8) + b"\x90" * (len(DIALOGUE_BEGIN_ORIGINAL) - 3)
    dialogue_delay_hooks = {
        site: _near(site, DIALOGUE_DELAY_HELPER, 0xE8) + b"\x90" * (len(DIALOGUE_DELAY_ORIGINAL) - 3)
        for site in DIALOGUE_DELAY_SITES
    }
    dialogue_end_hook = _near(DIALOGUE_END_SITE, DIALOGUE_END_HELPER, 0xE8) + b"\x90" * (len(DIALOGUE_END_ORIGINAL) - 3)
    dialogue_states = [
        bytes(code86[DIALOGUE_BEGIN_SITE:DIALOGUE_BEGIN_SITE + len(DIALOGUE_BEGIN_ORIGINAL)]) == dialogue_begin_hook,
        *(bytes(code86[site:site + len(DIALOGUE_DELAY_ORIGINAL)]) == hook for site, hook in dialogue_delay_hooks.items()),
        bytes(code86[DIALOGUE_END_SITE:DIALOGUE_END_SITE + len(DIALOGUE_END_ORIGINAL)]) == dialogue_end_hook,
    ]
    dialogue_originals = [
        bytes(code86[DIALOGUE_BEGIN_SITE:DIALOGUE_BEGIN_SITE + len(DIALOGUE_BEGIN_ORIGINAL)]) == DIALOGUE_BEGIN_ORIGINAL,
        *(bytes(code86[site:site + len(DIALOGUE_DELAY_ORIGINAL)]) == DIALOGUE_DELAY_ORIGINAL for site in DIALOGUE_DELAY_SITES),
        bytes(code86[DIALOGUE_END_SITE:DIALOGUE_END_SITE + len(DIALOGUE_END_ORIGINAL)]) == DIALOGUE_END_ORIGINAL,
    ]
    cave = bytes(code86[CAVE_START:CAVE_END])

    direct_repeat_hooks = {
        SELECT_CHR_KEY_SITE: _near(SELECT_CHR_KEY_SITE, MENU_KEY_DETECT_HELPER, 0xE8),
        SELECT_MONSTER_KEY_SITE: _near(SELECT_MONSTER_KEY_SITE, MENU_KEY_DETECT_HELPER, 0xE8),
    }
    direct_repeat_states = [
        bytes(code86[site:site + 3]) == hook for site, hook in direct_repeat_hooks.items()
    ]
    direct_repeat_originals = [
        bytes(code86[SELECT_CHR_KEY_SITE:SELECT_CHR_KEY_SITE + 3]) == SELECT_CHR_KEY_ORIGINAL,
        bytes(code86[SELECT_MONSTER_KEY_SITE:SELECT_MONSTER_KEY_SITE + 3]) == SELECT_MONSTER_KEY_ORIGINAL,
    ]
    if repeat_bytes != KEY_REPEAT_ORIGINAL or initial_bytes != KEY_INITIAL_ORIGINAL:
        repeat_state: bool | str = "legacy_or_unknown"
    elif menu_key_bytes == menu_key_hook and all(direct_repeat_states):
        repeat_state = True
    elif menu_key_bytes == MENU_KEY_DETECT_ORIGINAL and all(direct_repeat_originals):
        repeat_state = False
    else:
        repeat_state = "unknown"

    dialogue_state: bool | str
    if all(dialogue_states):
        dialogue_state = True
    elif all(dialogue_originals):
        dialogue_state = False
    else:
        dialogue_state = "unknown"

    return {
        "shop_quantity_removed": shop_removed,
        "equipment_preview_removed": equip_removed,
        "turbo_move": True if turbo_bytes == turbo_patch else False if turbo_bytes == TURBO_ORIGINAL else "unknown",
        "turbo_key": "Left/Right Shift",
        "menu_cursor_wrap": (
            True if menu_bytes == menu_hook and battle_hmask_bytes == battle_hmask_hook and battle_hwrap_bytes == battle_hwrap_hook
            else False if menu_bytes == MENU_WRAP_ORIGINAL and battle_hmask_bytes == BATTLE_HMASK_ORIGINAL and battle_hwrap_bytes == BATTLE_HWRAP_ORIGINAL
            else "unknown"
        ),
        "menu_vertical_wrap": True if menu_bytes == menu_hook else False if menu_bytes == MENU_WRAP_ORIGINAL else "unknown",
        "menu_horizontal_wrap": True if battle_hmask_bytes == battle_hmask_hook and battle_hwrap_bytes == battle_hwrap_hook else False if battle_hmask_bytes == BATTLE_HMASK_ORIGINAL and battle_hwrap_bytes == BATTLE_HWRAP_ORIGINAL else "unknown",
        "wrap_exceptions": ["inventory", "equipment", "warp_wing_town"],
        "menu_key_repeat_fast": repeat_state,
        "menu_key_repeat_initial_ticks": 20 if repeat_state in (True, False) else "unknown",
        "menu_key_repeat_interval_ticks": 4 if repeat_state is True else 8 if repeat_state is False else "unknown",
        "inventory_menu_exception": True,
        "inventory_menu_repeat_ticks": "20/4" if repeat_state is True else "20/8" if repeat_state is False else "unknown",
        "warp_menu_repeat_ticks": "20/4" if repeat_state is True else "20/8" if repeat_state is False else "unknown",
        "dialogue_instant_complete": dialogue_state,
        "dialogue_instant_key": "Confirm (0x20)",
        "dialogue_confirm_release_guard": dialogue_state is True,
        "helper_installed": cave == helper,
        "v1_0_10_helper_installed": cave == previous[0],
        "v1_0_9_helper_installed": cave == previous[1],
        "v1_0_8_helper_installed": cave == previous[2],
        "v1_0_21_helper_installed": cave == previous[3],
        "helper_empty": cave == b"\0" * len(helper),
        "relocation_targets": {f"0x{k:04X}": f"0x{v:04X}" for k, v in sorted(targets.items())},
        "journal": str(journal_path(root / "ED2MAIN.EXE", COMPONENT)),
    }


def restore_patch(root: Path) -> dict[str, Any]:
    root = validate_root(root)
    exe = root / "ED2MAIN.EXE"
    restored = selective_restore(exe, COMPONENT)
    return {"restored_bytes": restored, "sha256": sha256_bytes(exe.read_bytes()), "state": inspect_patch(root)}


def load_settings(path: Path | None) -> Setting:
    if path is None or not path.is_file():
        return Setting()
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    return Setting(
        turbo_move=bool(raw.get("turbo_move", True)),
        menu_cursor_wrap=bool(raw.get("menu_cursor_wrap", True)),
        menu_key_repeat_fast=bool(raw.get("menu_key_repeat_fast", True)),
        dialogue_instant_complete=False,
    )


class GUI:
    def __init__(self, initial: Path | None = None):
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
        self.tk, self.ttk, self.filedialog, self.messagebox = tk, ttk, filedialog, messagebox
        self.root = tk.Tk()
        self.root.title(f"{APP_NAME} v{VERSION}")
        self.root.minsize(720, 510)
        self.path = tk.StringVar(value=str(initial or ""))
        self.turbo = tk.BooleanVar(value=True)
        self.wrap = tk.BooleanVar(value=True)
        self.repeat = tk.BooleanVar(value=True)
        outer = ttk.Frame(self.root, padding=12); outer.pack(fill="both", expand=True)
        row = ttk.Frame(outer); row.pack(fill="x")
        ttk.Entry(row, textvariable=self.path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="게임 폴더", command=self.choose).pack(side="left", padx=8)
        box = ttk.LabelFrame(outer, text="추가 편의 기능", padding=10); box.pack(fill="x", pady=10)
        ttk.Checkbutton(box, text="Shift를 누르는 동안 고속 이동", variable=self.turbo).pack(anchor="w", pady=3)
        ttk.Checkbutton(box, text="메뉴 커서 상하·좌우 끝↔끝 순환", variable=self.wrap).pack(anchor="w", pady=3)
        ttk.Checkbutton(box, text="메뉴 방향키 반복 속도 개선 (모든 메뉴 20/4틱)", variable=self.repeat).pack(anchor="w", pady=3)
        ttk.Label(
            box,
            text=("인벤토리·장비 선택·워프의 날개 목적지 메뉴는 커서 순환만 적용하지 않습니다.\n"
                  "방향키 반복은 이 메뉴들도 20/4틱으로 동일합니다. 대사 출력/결정키 처리는 순정 동작을 유지합니다."),
            justify="left",
        ).pack(anchor="w", pady=(8, 2))
        self.log = tk.Text(outer, height=12, wrap="word", state="disabled"); self.log.pack(fill="both", expand=True)
        buttons = ttk.Frame(outer); buttons.pack(fill="x", pady=(8, 0))
        ttk.Button(buttons, text="선택 기능 적용", command=self.apply).pack(side="left")
        ttk.Button(buttons, text="상태 검사", command=self.check).pack(side="left", padx=6)
        ttk.Button(buttons, text="이 도구 변경 복원", command=self.restore).pack(side="left")
        ttk.Button(buttons, text="닫기", command=self.root.destroy).pack(side="right")

    def choose(self) -> None:
        path = self.filedialog.askdirectory(title="영웅전설 II 게임 폴더")
        if path: self.path.set(path)

    def put(self, value: Any) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def setting(self) -> Setting:
        return Setting(self.turbo.get(), self.wrap.get(), self.repeat.get(), False)

    def apply(self) -> None:
        try:
            result = apply_patch(Path(self.path.get()), self.setting())
            self.put(result); self.messagebox.showinfo(APP_NAME, "적용했습니다.")
        except Exception as exc: self.messagebox.showerror(APP_NAME, str(exc))

    def check(self) -> None:
        try: self.put(inspect_patch(Path(self.path.get())))
        except Exception as exc: self.messagebox.showerror(APP_NAME, str(exc))

    def restore(self) -> None:
        try:
            result = restore_patch(Path(self.path.get()))
            self.put(result); self.messagebox.showinfo(APP_NAME, "복원했습니다.")
        except Exception as exc: self.messagebox.showerror(APP_NAME, str(exc))

    def run(self) -> None:
        self.root.mainloop()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("path", nargs="?", type=Path)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--restore", action="store_true")
    parser.add_argument("--settings", type=Path)
    parser.add_argument("--turbo-move", choices=("on", "off"))
    parser.add_argument("--menu-cursor-wrap", choices=("on", "off"))
    parser.add_argument("--menu-key-repeat-fast", choices=("on", "off"))
    parser.add_argument("--no-gui", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.path and (args.apply or args.check or args.restore):
            if args.restore:
                result = restore_patch(args.path)
            elif args.check:
                result = inspect_patch(args.path)
            else:
                setting = load_settings(args.settings)
                setting = Setting(
                    turbo_move=setting.turbo_move if args.turbo_move is None else args.turbo_move == "on",
                    menu_cursor_wrap=setting.menu_cursor_wrap if args.menu_cursor_wrap is None else args.menu_cursor_wrap == "on",
                    menu_key_repeat_fast=setting.menu_key_repeat_fast if args.menu_key_repeat_fast is None else args.menu_key_repeat_fast == "on",
                    dialogue_instant_complete=False,
                )
                result = apply_patch(args.path, setting)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.no_gui:
            parser.error("--no-gui에서는 path와 작업 옵션이 필요합니다.")
        GUI(args.path).run()
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
