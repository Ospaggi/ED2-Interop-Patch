#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

APP_NAME = "ED2 Stability & QoL Tool"
VERSION = "1.2.4"
COMPONENT = "ed2_stability_qol_v1"

HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent

def _natural_version_key(path: Path) -> tuple[int, ...]:
    nums = tuple(int(x) for x in re.findall(r"\d+", path.name))
    return nums or (0,)

def _find_dependency_dir(pattern: str, marker: str, child_pattern: str | None = None) -> Path:
    candidates: list[Path] = []
    for base in BUNDLE.glob(pattern):
        if child_pattern is None:
            if (base / marker).is_file():
                candidates.append(base)
        else:
            for child in base.glob(child_pattern):
                if (child / marker).is_file():
                    candidates.append(child)
    if not candidates:
        searched = str(BUNDLE / pattern)
        raise RuntimeError(f"필수 모듈을 찾을 수 없습니다: {marker} (검색 위치: {searched})")
    return max(candidates, key=lambda path: (_natural_version_key(path.parent), _natural_version_key(path)))

MOD_DIR = _find_dependency_dir("ED2-MOD-Studio-v*", "ed2_mod_studio.py")
SCENE_DIR = _find_dependency_dir(
    "ED2_Text_and_Dialogue_Revision_Pack_v*",
    "ed2_scene_editor.py",
    "scene_editor",
)

sys.path.insert(0, str(HERE))
sys.path.insert(0, str(MOD_DIR))
sys.path.insert(0, str(SCENE_DIR))

from ed2_patch_journal import atomic_replace, record_patch, selective_restore, journal_path  # type: ignore
from ed2_mod_studio import parse_ne_segments, parse_ne_exports  # type: ignore
from ed2_scene_editor import SceneProject  # type: ignore


class PatchError(RuntimeError):
    pass


@dataclass(frozen=True)
class Setting:
    runtime_safety: bool = True
    dialogue_speed: int = 0  # 0 fast, 1 normal, 2 slow
    repair_saves: bool = False


SEG86 = 86
SEG85 = 85
SAFETY_CAVE = (0x1B00, 0x1B9A)
INVENTORY_CAVE = (0x1C00, 0x1CC0)
ANIMATION_CAVE = (0x1D00, 0x1D18)

# Symbol addresses in helpers_v107.bin.
H = {
    "state": 0x1B00,
    "level_div": 0x1B0A,
    "physical_luck": 0x1B16,
    "magic_luck": 0x1B29,
    "effect_luck": 0x1B42,
    "ratio_luck": 0x1B58,
    "exp_party": 0x1B6B,
    "avg_level": 0x1B78,
    "charge": 0x1B84,
    "level_to_exp": 0x1B8E,
    "inv_space": 0x1C00,
    "inv_check": 0x1C27,
    "inv_delete": 0x1C48,
    "inv_map_dx": 0x1C8C,
    "inv_map_bx": 0x1CA4,
    "anim_short": 0x1D00,
    "anim_instant": 0x1D12,
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_root(root: Path) -> Path:
    root = root.expanduser().resolve()
    if not (root / "ED2MAIN.EXE").is_file() or not (root / "SCENA").is_dir():
        raise PatchError("ED2MAIN.EXE와 SCENA 폴더가 있는 영웅전설 II 폴더를 선택해야 합니다.")
    return root


def _near(site: int, target: int, opcode: int = 0xE8) -> bytes:
    disp = (target - (site + 3)) & 0xFFFF
    return bytes([opcode, disp & 0xFF, disp >> 8])


def _site(seg86: bytearray, offset: int, original: bytes, desired: bytes, known: list[bytes] | None = None) -> None:
    current = bytes(seg86[offset:offset + len(original)])
    allowed = [original, desired] + list(known or [])
    if current not in allowed:
        raise PatchError(
            f"ED2MAIN 코드 86:{offset:04X}가 지원 상태와 다릅니다. "
            f"현재={current.hex(' ')} 원본={original.hex(' ')}"
        )
    seg86[offset:offset + len(original)] = desired


def _cave(seg86: bytearray, start: int, end: int, desired: bytes, all_known: list[bytes] | None = None) -> None:
    size = end - start
    if len(desired) > size:
        raise PatchError("코드 동굴 크기가 부족합니다.")
    desired_full = desired + b"\0" * (size - len(desired))
    current = bytes(seg86[start:end])
    allowed = [b"\0" * size, desired_full] + list(all_known or [])
    if current not in allowed:
        raise PatchError(f"ED2MAIN 86:{start:04X} 코드 공간이 다른 패치에서 사용 중입니다.")
    seg86[start:end] = desired_full


def load_helper_ranges() -> tuple[bytes, bytes, bytes]:
    raw = (HERE / "helpers_v107.bin").read_bytes()
    return raw[SAFETY_CAVE[0]:SAFETY_CAVE[1]], raw[INVENTORY_CAVE[0]:INVENTORY_CAVE[1]], raw[ANIMATION_CAVE[0]:ANIMATION_CAVE[1]]


def patch_runtime_safety(seg: bytearray, enabled: bool, helper: bytes) -> None:
    zero = b"\0" * (SAFETY_CAVE[1] - SAFETY_CAVE[0])
    desired_cave = helper if enabled else zero
    _cave(seg, *SAFETY_CAVE, desired_cave, [helper, zero])

    sites = [
        (0x3F00, bytes.fromhex("FE 4D 29"), _near(0x3F00, H["state"])),
        (0x3F4F, bytes.fromhex("8A 5D 03 F6 F3"), _near(0x3F4F, H["level_div"]) + b"\x90\x90"),
        (0x3FDD, bytes.fromhex("F6 E5 F6 F1"), _near(0x3FDD, H["physical_luck"]) + b"\x90"),
        (0x40F6, bytes.fromhex("8A 5C 17 F6 E3 8A 5D 17 F6 F3"), _near(0x40F6, H["magic_luck"]) + b"\x90" * 7),
        (0x4134, bytes.fromhex("F6 E4 8A 5C 15 F6 F3"), _near(0x4134, H["effect_luck"]) + b"\x90" * 4),
        (0x4283, bytes.fromhex("F6 E5 F6 F1"), _near(0x4283, H["ratio_luck"]) + b"\x90"),
        (0x3734, bytes.fromhex("A1 B4 95 F7 F1"), _near(0x3734, H["exp_party"]) + b"\x90\x90"),
        (0x4233, bytes.fromhex("F6 F2 2A 45 03"), _near(0x4233, H["avg_level"]) + b"\x90\x90"),
        (0x9522, bytes.fromhex("FE 49 39"), _near(0x9522, H["charge"])),
        (0x79ED, bytes.fromhex("8A F0 BE 57 35"), _near(0x79ED, H["level_to_exp"]) + b"\x90\x90"),
    ]
    for off, original, patched in sites:
        # 경험치 무분배 패치는 86:3734의 나눗셈 자체를 NOP 처리합니다.
        # 이 경우 0명 나눗셈 위험도 사라지므로 기존 경험치 패치를 그대로 보존합니다.
        if off == 0x3734 and bytes(seg[off:off + len(original)]) == b"\x90" * len(original):
            continue
        _site(seg, off, original, patched if enabled else original, [patched])


def patch_inventory(seg: bytearray, slots: int, helper: bytes) -> None:
    if slots not in (28, 32):
        raise PatchError("아이템 최대 보유량은 28 또는 32만 지원합니다.")
    enabled = slots == 32
    zero = b"\0" * (INVENTORY_CAVE[1] - INVENTORY_CAVE[0])
    _cave(seg, *INVENTORY_CAVE, helper if enabled else zero, [helper, zero])

    sites = [
        (0x73D0, bytes.fromhex("57 51 50"), _near(0x73D0, H["inv_space"], 0xE9)),
        (0x73F2, bytes.fromhex("51 BF 54"), _near(0x73F2, H["inv_check"], 0xE9)),
        (0x7446, bytes.fromhex("57 56 51"), _near(0x7446, H["inv_delete"], 0xE9)),
        (0x84FF, bytes.fromhex("33 D2 8A 16 29 20 81 C2 54 20"), _near(0x84FF, H["inv_map_dx"]) + b"\x90" * 7),
        (0x9B66, bytes.fromhex("33 DB 8A 1E 23 20 02 1E 29 20 81 C3 54 20"), _near(0x9B66, H["inv_map_bx"]) + b"\x90" * 11),
    ]
    for off, original, patched in sites:
        _site(seg, off, original, patched if enabled else original, [patched])

    constants = {
        0x9B3D: (0x15, 0x19),
        0x9B9F: (0x16, 0x1A),
        0x9BAE: (0x15, 0x19),
        0x9BB7: (0x16, 0x1A),
        0x9BBB: (0x15, 0x19),
    }
    for off, (orig, ext) in constants.items():
        cur = seg[off]
        if cur not in (orig, ext):
            raise PatchError(f"아이템 메뉴 상한 86:{off:04X}가 지원 상태와 다릅니다.")
        seg[off] = ext if enabled else orig


def restore_vanilla_animation(seg: bytearray, helper: bytes) -> None:
    """Remove v1.0.6/v1.0.7 animation speed hooks and restore vanilla timing."""
    zero = b"\0" * (ANIMATION_CAVE[1] - ANIMATION_CAVE[0])
    _cave(seg, *ANIMATION_CAVE, zero, [helper, zero])

    original = bytes.fromhex("88 26 43 3F")
    short = _near(0x5DA0, H["anim_short"]) + b"\x90"
    instant = _near(0x5DA0, H["anim_instant"]) + b"\x90"
    _site(seg, 0x5DA0, original, original, [short, instant])

    for off in (0x5E7B, 0x5EDA, 0x5F1A):
        cur = seg[off]
        if cur not in (1, 2):
            raise PatchError(f"전투 애니메이션 지연값 86:{off:04X}가 지원 상태와 다릅니다.")
        seg[off] = 2

    loops = {
        0x5E6B: (6, 3, 1),
        0x5E75: (10, 5, 1),
        0x5ECA: (4, 2, 1),
        0x5ED4: (8, 4, 1),
        0x5F14: (8, 4, 1),
    }
    for off, values in loops.items():
        current = int.from_bytes(seg[off:off+2], "little")
        if current not in values:
            raise PatchError(f"전투 애니메이션 반복값 86:{off:04X}가 지원 상태와 다릅니다.")
        seg[off:off+2] = int(values[0]).to_bytes(2, "little")


def patch_c631_inventory_count(root: Path, slots: int) -> dict[str, Any]:
    """Extend C_631's direct item scan to include the four added slots.

    C_631 is the only SCENA module that imports ITEM_LIST directly instead of
    using ITEM_CHECK/ITEM_SPACE_CHECK. Its second scan starts at
    STORE_ITEM_LIST (21B8); the extra slots are deliberately placed at
    21CC..21CF so changing that scan from 20 to 24 covers both areas.
    """
    path = root / "SCENA" / "C_631.DLL"
    if not path.is_file():
        raise PatchError("SCENA/C_631.DLL이 없습니다.")
    before = path.read_bytes()
    segments = parse_ne_segments(before)
    if len(segments) < 3:
        raise PatchError("C_631.DLL의 세그먼트 구조가 지원 형식과 다릅니다.")
    seg3 = segments[2]
    pos = seg3.file_offset + 0x350  # MOV CX,0014h immediate
    current = before[pos:pos + 2]
    if current not in (b"\x14\x00", b"\x18\x00"):
        raise PatchError(f"C_631.DLL 아이템 검색 길이가 지원 상태와 다릅니다: {current.hex(' ')}")
    desired = b"\x18\x00" if slots == 32 else b"\x14\x00"
    if current == desired:
        return {"changed_bytes": 0, "scan_count": int.from_bytes(desired, "little")}
    after = bytearray(before)
    after[pos:pos + 2] = desired
    record_patch(path, before, bytes(after), COMPONENT)
    atomic_replace(path, bytes(after))
    return {"changed_bytes": 1, "scan_count": int.from_bytes(desired, "little")}




# ---------------------------------------------------------------------------
# Dialogue-visible scene event timing fixes (v1.2.3)
# ---------------------------------------------------------------------------
# Warp-wing events use page-flipped world rendering.  In C_00E and C_204 the
# stock disappearance helpers set their PL_TOP hidden flags only *after* the
# last world/message page copy.  That leaves one display page containing the
# old character image and can look like blinking instead of a clean vanish.
#
# v1.0.7 also removed C_00E's post-DISP_MESS helper entirely because Gale
# already invokes it through message opcode 15.  That avoided running Gale's
# 20-step effect twice, but the same message stream also contains Rando's warp
# line without opcode 15, so Rando lost the disappearance call altogether.
#
# v1.2.3 keeps the chapter transition path completely separate from C_00E.
# C_00E is a Chapter 3 Ludia-castle scene, not the Chapter 2 -> 3 transition.
# Gale and Rando already invoke the stock 3:0F75 warp effect through their original
# call sites.  v1.2.3 therefore does not redirect either caller or append code.
# It changes only the stock helper tail in place: after setting the hidden flags,
# execution jumps to C_00E's pre-existing two-page redraw block.  This settles the
# hidden state without NE segment growth or new relocation records.
# C_204 keeps the analogous Barbara wrapper, and C_625 keeps its monster settle.

EVENT_SCENA_FILES = ("C_00E.DLL", "C_204.DLL", "C_625.DLL")


def _scene_seg3(data: bytes, name: str):
    segments = parse_ne_segments(data)
    if len(segments) < 3:
        raise PatchError(f"{name}: 세그먼트 3이 없습니다.")
    return segments[2]


def _ne_seg_entry_offset(data: bytes, segment_index: int) -> int:
    if len(data) < 0x40:
        raise PatchError("MZ 헤더가 잘렸습니다.")
    ne = int.from_bytes(data[0x3C:0x40], "little")
    if ne + 0x34 > len(data) or data[ne:ne + 2] != b"NE":
        raise PatchError("NE 헤더를 찾을 수 없습니다.")
    seg_table = ne + int.from_bytes(data[ne + 0x22:ne + 0x24], "little")
    off = seg_table + (segment_index - 1) * 8
    if off + 8 > len(data):
        raise PatchError("NE 세그먼트 테이블이 잘렸습니다.")
    return off


def _append_segment_helper(data: bytes, name: str, segment_index: int, helper: bytes,
                           new_relocs: list[tuple[int, int, int, int, int]]) -> tuple[bytes, int]:
    """Append code before one segment relocation table and add relocation records.

    Relocation tuples are (source_type, flags, source_offset_within_helper,
    target1, target2).  flags low target type 0 is an internal NE reference and
    target type 1 is an imported ordinal.  File size and later segment locations
    stay fixed.
    """
    segs = parse_ne_segments(data)
    if len(segs) < segment_index:
        raise PatchError(f"{name}: 세그먼트 {segment_index}이(가) 없습니다.")
    seg = segs[segment_index - 1]
    old_len = seg.length
    old_tab = seg.file_offset + old_len
    if old_tab + 2 > len(data):
        raise PatchError(f"{name}: relocation table이 잘렸습니다.")
    count = int.from_bytes(data[old_tab:old_tab + 2], "little")
    old_table_size = 2 + count * 8
    old_end = old_tab + old_table_size
    if old_end > len(data):
        raise PatchError(f"{name}: relocation record가 잘렸습니다.")
    next_offsets = [s.file_offset for s in segs if s.file_offset > seg.file_offset]
    next_off = min(next_offsets) if next_offsets else len(data)
    required = len(helper) + len(new_relocs) * 8
    if next_off - old_end < required:
        raise PatchError(
            f"{name}: 세그먼트 3 뒤 여유 공간이 부족합니다: "
            f"need={required}, available={next_off-old_end}"
        )

    old_records = data[old_tab + 2:old_end]
    helper_start = old_len
    new_tab = old_tab + len(helper)
    new_count = count + len(new_relocs)
    records = bytearray(old_records)
    for source_type, flags, rel_source, target1, target2 in new_relocs:
        source = helper_start + rel_source
        records += bytes((source_type & 0xFF, flags & 0xFF))
        records += int(source).to_bytes(2, "little")
        records += int(target1).to_bytes(2, "little")
        records += int(target2).to_bytes(2, "little")

    out = bytearray(data)
    out[old_tab:old_tab + len(helper)] = helper
    out[new_tab:new_tab + 2] = int(new_count).to_bytes(2, "little")
    out[new_tab + 2:new_tab + 2 + len(records)] = records
    new_end = new_tab + 2 + len(records)
    if new_end < next_off:
        out[new_end:next_off] = b"\x00" * (next_off - new_end)

    entry = _ne_seg_entry_offset(out, segment_index)
    new_len = old_len + len(helper)
    out[entry + 2:entry + 4] = int(new_len).to_bytes(2, "little")
    # These SCENA modules use min_alloc == on-disk segment length.  Grow both
    # fields together so the NE loader reserves memory for the appended helper.
    old_min_alloc = int.from_bytes(out[entry + 6:entry + 8], "little")
    if old_min_alloc not in (0, old_len):
        raise PatchError(f"{name}: 예상 밖 seg3 min_alloc={old_min_alloc:04X}, length={old_len:04X}")
    if old_min_alloc != 0:
        out[entry + 6:entry + 8] = int(new_len).to_bytes(2, "little")
    return bytes(out), helper_start


def _append_seg3_helper(data: bytes, name: str, helper: bytes,
                        new_relocs: list[tuple[int, int, int, int, int]]) -> tuple[bytes, int]:
    return _append_segment_helper(data, name, 3, helper, new_relocs)


def _patch_relocation_source(data: bytearray, segment, old_source: int, new_source: int,
                             target_ordinal: int) -> None:
    table = segment.file_offset + segment.length
    if table + 2 > len(data):
        raise PatchError("SCENA relocation table이 잘렸습니다.")
    count = int.from_bytes(data[table:table + 2], "little")
    pos = table + 2
    matches: list[int] = []
    for _ in range(count):
        if pos + 8 > len(data):
            raise PatchError("SCENA relocation record가 잘렸습니다.")
        source_type = data[pos]
        flags = data[pos + 1]
        source = int.from_bytes(data[pos + 2:pos + 4], "little")
        target = int.from_bytes(data[pos + 6:pos + 8], "little")
        if source == old_source and target == target_ordinal and (flags & 3) == 1:
            matches.append(pos)
        pos += 8
    if len(matches) != 1:
        raise PatchError(
            f"relocation {old_source:04X} -> ordinal {target_ordinal}를 정확히 하나 찾지 못했습니다: {len(matches)}"
        )
    rec = matches[0]
    data[rec + 2:rec + 4] = int(new_source).to_bytes(2, "little")


def _relocation_source_state(data: bytes, segment, sources: set[int], target_ordinal: int) -> set[int]:
    table = segment.file_offset + segment.length
    if table + 2 > len(data):
        return set()
    count = int.from_bytes(data[table:table + 2], "little")
    pos = table + 2
    found: set[int] = set()
    for _ in range(count):
        if pos + 8 > len(data):
            break
        flags = data[pos + 1]
        source = int.from_bytes(data[pos + 2:pos + 4], "little")
        target = int.from_bytes(data[pos + 6:pos + 8], "little")
        if source in sources and target == target_ordinal and (flags & 3) == 1:
            found.add(source)
        pos += 8
    return found


def _internal_far_relocation_target(data: bytes, segment, source_offset: int) -> tuple[int, int] | None:
    """Return (target_segment, target_offset) for one internal FAR relocation."""
    table = segment.file_offset + segment.length
    if table + 2 > len(data):
        return None
    count = int.from_bytes(data[table:table + 2], "little")
    pos = table + 2
    found: list[tuple[int, int]] = []
    for _ in range(count):
        if pos + 8 > len(data):
            return None
        source_type = data[pos]
        flags = data[pos + 1]
        source = int.from_bytes(data[pos + 2:pos + 4], "little")
        target1 = int.from_bytes(data[pos + 4:pos + 6], "little")
        target2 = int.from_bytes(data[pos + 6:pos + 8], "little")
        if source_type == 0x03 and (flags & 3) == 0 and source == source_offset:
            found.append((target1, target2))
        pos += 8
    return found[0] if len(found) == 1 else None


def _make_c00e_warp_finalizer_split() -> tuple[bytes, list[tuple[int, int, int, int, int]]]:
    """Build the full C_00E finalizer for segment 1.

    Segment 3 has very little tail room after the PC-98-faithful dialogue
    expansion.  The callback therefore lands on a five-byte FAR-JMP trampoline
    in segment 3; the real helper lives in segment 1, whose verified alignment
    padding is much larger.
    """
    # test [PL_TOP15],80 / jz effect / test [PL_TOP16],80 / jnz redraw
    b = bytearray(bytes.fromhex("F6 06 00 00 80 74 07 F6 06 00 00 80 75 05"))
    # FAR CALL original effect at internal 3:0F75.
    op = len(b)
    b += bytes.fromhex("9A 00 00 00 00")
    relocs: list[tuple[int, int, int, int, int]] = [
        (0x05, 0x05, 2, 1, 805),
        (0x05, 0x05, 9, 1, 808),
        (0x03, 0x00, op + 1, 3, 0x0F75),
    ]
    # Settle both world pages, restoring the original display bank.
    for ordinal in (331, 62, 331, 62):
        op = len(b)
        b += bytes.fromhex("9A FF FF 00 00")
        relocs.append((0x03, 0x01, op + 1, 1, ordinal))
    b += b"\xCB"
    return bytes(b), relocs



def _make_c00e_gale_wrapper_split() -> tuple[bytes, list[tuple[int, int, int, int, int]]]:
    """Build Gale's Chapter-3 in-message warp wrapper in segment 1.

    The message opcode 15 remains the only Gale trigger.  A five-byte segment-3
    trampoline jumps here, this helper FAR-calls the original 3:0F75 effect once,
    then settles both page-flipped world buffers while restoring the message and
    the original display bank.  No post-DISP/scene-exit code is modified.
    """
    b = bytearray(bytes.fromhex("9A 00 00 00 00"))
    relocs: list[tuple[int, int, int, int, int]] = [
        (0x03, 0x00, 1, 3, 0x0F75),
    ]
    for ordinal in (331, 61, 62, 331, 61, 62):  # DS_MZH, COPY_MESS2, NEG x2
        op = len(b)
        b += bytes.fromhex("9A FF FF 00 00")
        relocs.append((0x03, 0x01, op + 1, 1, ordinal))
    b += b"\xCB"
    return bytes(b), relocs


def _make_c00e_warp_finalizer(helper_start: int) -> tuple[bytes, list[tuple[int, int, int, int, int]]]:
    # test [PL_TOP15],80 / jz effect / test [PL_TOP16],80 / jnz redraw
    b = bytearray(bytes.fromhex("F6 06 00 00 80 74 07 F6 06 00 00 80 75 04"))
    # PUSH CS + near CALL original 3:0F75.
    call_pos = len(b)
    b += b"\x0E\xE8\x00\x00"
    rel = 0x0F75 - (helper_start + call_pos + 4)
    b[call_pos + 2:call_pos + 4] = int(rel & 0xFFFF).to_bytes(2, "little")
    # Final two-page world redraw, restoring the original display bank.
    call_offsets: list[tuple[int, int]] = []
    for ordinal in (331, 62, 331, 62):  # DS_MZH, NEG_DSP_BANK, DS_MZH, NEG_DSP_BANK
        op = len(b)
        b += bytes.fromhex("9A FF FF 00 00")
        call_offsets.append((op + 1, ordinal))
    b += b"\xCB"
    relocs: list[tuple[int, int, int, int, int]] = [
        (0x05, 0x05, 2, 1, 805),   # PL_TOP15
        (0x05, 0x05, 9, 1, 808),   # PL_TOP16
    ]
    relocs.extend((0x03, 0x01, off, 1, ordinal) for off, ordinal in call_offsets)
    return bytes(b), relocs


def _make_c204_barbara_wrapper(helper_start: int) -> tuple[bytes, list[tuple[int, int, int, int, int]]]:
    # Run the original 20-step effect first.
    b = bytearray(b"\x0E\xE8\x00\x00")
    rel = 0x0444 - (helper_start + 4)
    b[2:4] = int(rel & 0xFFFF).to_bytes(2, "little")
    # Then settle both VGA pages while preserving the currently displayed message.
    call_offsets: list[tuple[int, int]] = []
    for ordinal in (331, 61, 62, 331, 61, 62):  # DS_MZH, COPY_MESS2, NEG ... x2
        op = len(b)
        b += bytes.fromhex("9A FF FF 00 00")
        call_offsets.append((op + 1, ordinal))
    b += b"\xCB"
    relocs = [(0x03, 0x01, off, 1, ordinal) for off, ordinal in call_offsets]
    return bytes(b), relocs




def _make_c625_monster_settle(helper_start: int) -> tuple[bytes, list[tuple[int, int, int, int, int]]]:
    # Final-chapter surrounded-monster scene: after PL_TOP2/MO_NUM have been
    # committed, redraw both world pages and return to the original display bank.
    # The first DS_MZH relocation is reused from the old scene call; the other
    # three imports are appended as new relocation records.
    b = bytearray()
    call_offsets: list[tuple[int, int]] = []
    for ordinal in (331, 62, 331, 62):  # DS_MZH, NEG_DSP_BANK x2
        op = len(b)
        b += bytes.fromhex("9A FF FF 00 00")
        call_offsets.append((op + 1, ordinal))
    b += b"\xC3"
    # The caller moves its existing DS_MZH relocation to call_offsets[0].
    relocs = [(0x03, 0x01, off, 1, ordinal) for off, ordinal in call_offsets[1:]]
    return bytes(b), relocs


def _signed16(value: int) -> int:
    return value - 0x10000 if value & 0x8000 else value


def _seg3_growth_compatible(seg, stock_length: int) -> bool:
    """Return True when seg3 may already contain another audited tail payload.

    Slot-expanding tools never insert in the middle of a segment.  Therefore a
    pre-existing compatible expansion is represented by length >= stock_length,
    with min_alloc either zero (loader default) or at least the on-disk length.
    """
    if seg.length < stock_length:
        return False
    return seg.min_alloc == 0 or seg.min_alloc >= seg.length


def _c625_monster_state(data: bytes) -> dict[str, Any]:
    seg = _scene_seg3(data, "C_625.DLL")
    base = seg.file_offset
    current = data[base + 0x0530:base + 0x0548]
    # Patched layout is fixed except for the near-CALL displacement at 0544:0546.
    prefix = bytes.fromhex(
        "BB 00 00 B9 0C 00 80 0F 80 83 C3 08 E2 F8 "
        "C6 06 00 00 0B E8"
    )
    if len(current) != 0x18 or current[:0x14] != prefix or current[0x16:0x18] != b"\x90\x90":
        return {"ok": False, "reason": "site", "block": current.hex(" ")}
    disp = _signed16(int.from_bytes(current[0x14:0x16], "little"))
    helper_start = (0x0546 + disp) & 0xFFFF
    helper, _ = _make_c625_monster_settle(helper_start)
    if helper_start < 0x0945 or seg.length < helper_start + len(helper):
        return {"ok": False, "reason": "segment-length", "helper_start": helper_start,
                "length": seg.length, "min_alloc": seg.min_alloc}
    if seg.min_alloc not in (0, seg.length) and seg.min_alloc < seg.length:
        return {"ok": False, "reason": "min-alloc", "length": seg.length, "min_alloc": seg.min_alloc}
    if data[base + helper_start:base + helper_start + len(helper)] != helper:
        return {"ok": False, "reason": "helper", "helper_start": helper_start}
    reloc_ok = (
        _relocation_source_state(data, seg, {0x0531, 0x0536}, 722) == {0x0531}
        and _relocation_source_state(data, seg, {0x0540, 0x0545}, 726) == {0x0540}
        and _relocation_source_state(
            data, seg,
            {0x0531, 0x0544, helper_start + 1, helper_start + 11}, 331
        ) == {helper_start + 1, helper_start + 11}
        and _relocation_source_state(
            data, seg, {helper_start + 6, helper_start + 16}, 62
        ) == {helper_start + 6, helper_start + 16}
    )
    return {
        "ok": reloc_ok,
        "two_page_settle_after_hide": reloc_ok,
        "helper_start": helper_start,
        "segment_length": seg.length,
        "tail_after_helper": seg.length - (helper_start + len(helper)),
    }



def _c00e_gale_wrapper_state(data: bytes) -> dict[str, Any]:
    """Recognize the retired v1.2.2 Gale-only wrapper for migration/diagnostics."""
    segs = parse_ne_segments(data)
    if len(segs) < 3:
        return {"ok": False, "reason": "segments"}
    seg1, seg3 = segs[0], segs[2]
    base3 = seg3.file_offset
    callback = data[base3 + 0x09DC:base3 + 0x09DF]
    post = data[base3 + 0x0EEA:base3 + 0x0EEE]
    transition_relocs_ok = (
        _relocation_source_state(data, seg3, {0x0EE6}, 627) == {0x0EE6}
        and _relocation_source_state(data, seg3, {0x0EEF}, 332) == {0x0EEF}
        and _relocation_source_state(data, seg3, {0x0EF4}, 823) == {0x0EF4}
    )
    if len(callback) != 3 or callback[0] != 0x15 or post != bytes.fromhex("0E E8 87 00"):
        return {
            "ok": False,
            "reason": "callback_or_rando_post",
            "callback": callback.hex(" "),
            "rando_post": post.hex(" "),
            "transition_relocations_ok": transition_relocs_ok,
        }
    trampoline_start = int.from_bytes(callback[1:3], "little")
    if trampoline_start < 0x105E or seg3.length < trampoline_start + 5:
        return {"ok": False, "reason": "trampoline_range", "trampoline_start": trampoline_start}
    tramp = data[base3 + trampoline_start:base3 + trampoline_start + 5]
    target = _internal_far_relocation_target(data, seg3, trampoline_start + 1)
    if tramp != bytes.fromhex("EA 00 00 00 00") or not target or target[0] != 1:
        return {
            "ok": False,
            "reason": "trampoline",
            "trampoline": tramp.hex(" "),
            "target": target,
        }
    helper_start = target[1]
    helper, _ = _make_c00e_gale_wrapper_split()
    base1 = seg1.file_offset
    helper_ok = (
        helper_start >= 0
        and seg1.length >= helper_start + len(helper)
        and data[base1 + helper_start:base1 + helper_start + len(helper)] == helper
    )
    reloc_ok = False
    if helper_ok:
        reloc_ok = (
            _internal_far_relocation_target(data, seg1, helper_start + 1) == (3, 0x0F75)
            and _relocation_source_state(data, seg1, {helper_start + 6, helper_start + 21}, 331)
                == {helper_start + 6, helper_start + 21}
            and _relocation_source_state(data, seg1, {helper_start + 11, helper_start + 26}, 61)
                == {helper_start + 11, helper_start + 26}
            and _relocation_source_state(data, seg1, {helper_start + 16, helper_start + 31}, 62)
                == {helper_start + 16, helper_start + 31}
        )
    return {
        "ok": bool(helper_ok and reloc_ok and transition_relocs_ok),
        "mode": "gale_in_message_wrapper_rando_stock_exit",
        "gale_callback_wrapped": True,
        "original_effect_target": "3:0F75",
        "two_page_settle_after_gale_hide": bool(reloc_ok),
        "message_preserved": bool(reloc_ok),
        "rando_stock_post_effect_preserved": True,
        "transition_relocations_ok": transition_relocs_ok,
        "trampoline_start": trampoline_start,
        "helper_segment": 1,
        "helper_start": helper_start,
        "seg1_length": seg1.length,
        "seg3_length": seg3.length,
    }


def _apply_c00e_gale_wrapper(path: Path) -> dict[str, Any]:
    """Install the retired v1.2.2 Gale-only wrapper (legacy helper; not current path)."""
    initial = path.read_bytes()
    current = _c00e_gale_wrapper_state(initial)
    if current.get("ok"):
        return {"file": path.name, "changed_bytes": 0, "migration": "already_v1.2.2", **current}

    migration = _retire_c00e_warp_finalizer(path)
    before = path.read_bytes()
    stock = _c00e_stock_transition_state(before)
    if not stock.get("ok"):
        raise PatchError(f"C_00E.DLL 게일 wrapper 적용 전 순정 호출 흐름 검증 실패: {stock}")

    helper, helper_relocs = _make_c00e_gale_wrapper_split()
    after1, helper_start = _append_segment_helper(before, path.name, 1, helper, helper_relocs)
    trampoline = bytes.fromhex("EA 00 00 00 00")
    after2, trampoline_start = _append_segment_helper(
        after1,
        path.name,
        3,
        trampoline,
        [(0x03, 0x00, 1, 1, helper_start)],
    )
    seg3 = parse_ne_segments(after2)[2]
    out = bytearray(after2)
    out[seg3.file_offset + 0x09DD:seg3.file_offset + 0x09DF] = int(trampoline_start).to_bytes(2, "little")
    after = bytes(out)
    final = _c00e_gale_wrapper_state(after)
    if not final.get("ok"):
        raise PatchError(f"C_00E.DLL 게일 즉시 숨김 wrapper 자체 검증 실패: {final}")
    record_patch(path, before, after, COMPONENT)
    atomic_replace(path, after)
    return {
        "file": path.name,
        "changed_bytes": sum(a != b for a, b in zip(before, after)),
        "migration": migration.get("migration", "stock"),
        "old_post_disp_finalizer_retired": True,
        **final,
    }


def _c00e_stock_transition_state(data: bytes) -> dict[str, Any]:
    """Validate the stock C_00E Gale/Rando call structure in Chapter 3.

    Gale invokes 3:0F75 through in-message opcode 15.  After the final Rando
    warp message DISP_MESS returns, stock code performs one local 3:0F75 call,
    then immediately executes HS_WORK_INIT and EXIT.
    """
    segs = parse_ne_segments(data)
    if len(segs) < 3:
        return {"ok": False, "reason": "segments"}
    seg3 = segs[2]
    base = seg3.file_offset
    callback = data[base + 0x09DC:base + 0x09DF]
    post = data[base + 0x0EEA:base + 0x0EEE]
    callback_ok = callback == bytes.fromhex("15 75 0F")
    post_ok = post == bytes.fromhex("0E E8 87 00")
    reloc_ok = (
        _relocation_source_state(data, seg3, {0x0EE6}, 627) == {0x0EE6}  # DISP_MESS
        and _relocation_source_state(data, seg3, {0x0EEF}, 332) == {0x0EEF}  # HS_WORK_INIT
        and _relocation_source_state(data, seg3, {0x0EF4}, 823) == {0x0EF4}  # EXIT
    )
    return {
        "ok": bool(callback_ok and post_ok and reloc_ok),
        "mode": "stock_chapter_exit_flow",
        "callback_ok": callback_ok,
        "post_effect_ok": post_ok,
        "transition_relocations_ok": reloc_ok,
        "seg3_length": seg3.length,
        "seg3_min_alloc": seg3.min_alloc,
    }



def _c00e_inplace_warp_hide_state(data: bytes) -> dict[str, Any]:
    """Validate the v1.2.3 no-growth Gale/Rando warp disappearance fix.

    The stock 3:0F75 effect already commits MW_FLG and the PL_TOP15/16 hidden
    flags.  v1.2.3 keeps both callers and the NE layout stock, but after those
    flags are committed it jumps into C_00E's existing 3:1030 two-page redraw
    tail.  No helper, segment growth, or extra relocation record is required.
    """
    segs = parse_ne_segments(data)
    if len(segs) < 3:
        return {"ok": False, "reason": "segments"}
    seg3 = segs[2]
    base = seg3.file_offset
    callback = data[base + 0x09DC:base + 0x09DF]
    rando_post = data[base + 0x0EEA:base + 0x0EEE]
    desired_tail = bytes.fromhex("B0 80 A2 00 00 A2 00 00 EB 48 90")
    tail = data[base + 0x0FDE:base + 0x0FE9]

    callback_ok = callback == bytes.fromhex("15 75 0F")
    rando_ok = rando_post == bytes.fromhex("0E E8 87 00")
    tail_ok = tail == desired_tail
    pl15_reloc = _relocation_source_state(data, seg3, {0x0FE0, 0x0FE1}, 805)
    pl16_reloc = _relocation_source_state(data, seg3, {0x0FE4, 0x0FE5}, 808)
    hidden_reloc_ok = pl15_reloc == {0x0FE1} and pl16_reloc == {0x0FE4}

    redraw_relocs_ok = (
        _relocation_source_state(data, seg3, {0x1031}, 882) == {0x1031}
        and _relocation_source_state(data, seg3, {0x1036}, 62) == {0x1036}
        and _relocation_source_state(data, seg3, {0x103B}, 882) == {0x103B}
        and _relocation_source_state(data, seg3, {0x1040, 0x104F}, 331) == {0x1040, 0x104F}
        and _relocation_source_state(data, seg3, {0x1045, 0x1054}, 61) == {0x1045, 0x1054}
        and _relocation_source_state(data, seg3, {0x104A}, 62) == {0x104A}
        and _relocation_source_state(data, seg3, {0x105A}, 613) == {0x105A}
    )
    # Short JMP at 0x0FE6 is relative to 0x0FE8: 0x1030 - 0x0FE8 = 0x48.
    jump_target = 0x1030 if len(tail) >= 10 and tail[8:10] == bytes.fromhex("EB 48") else None
    return {
        "ok": bool(callback_ok and rando_ok and tail_ok and hidden_reloc_ok and redraw_relocs_ok),
        "mode": "stock_warp_effect_inplace_two_page_settle",
        "gale_callback_stock": callback_ok,
        "rando_post_effect_stock": rando_ok,
        "hidden_tail_ok": tail_ok,
        "hidden_relocations_ok": hidden_reloc_ok,
        "existing_redraw_block_ok": redraw_relocs_ok,
        "redraw_jump_target": jump_target,
        "segment_length": seg3.length,
        "segment_min_alloc": seg3.min_alloc,
        "no_helper_or_trampoline": True,
    }


def _apply_c00e_inplace_warp_hide(path: Path) -> dict[str, Any]:
    """Apply a no-growth two-page settle to the stock C_00E warp routine."""
    initial = path.read_bytes()
    current = _c00e_inplace_warp_hide_state(initial)
    if current.get("ok"):
        return {"file": path.name, "changed_bytes": 0, "migration": "already_v1.2.3", **current}

    # Restore any v1.0.7..v1.2.2 C_00E Stability-owned helper first.  Normal
    # AIO installs keep the selective journal, so legacy segment extensions
    # are truncated safely while unrelated dialogue edits in the prefix remain.
    migration = _retire_c00e_warp_finalizer(path)
    before = path.read_bytes()
    stock = _c00e_stock_transition_state(before)
    if not stock.get("ok"):
        raise PatchError(f"C_00E.DLL no-growth 워프 보정 전 순정 호출 흐름 검증 실패: {stock}")

    segs_before = parse_ne_segments(before)
    seg3 = segs_before[2]
    base = seg3.file_offset
    stock_tail = bytes.fromhex("C6 06 00 00 80 C6 06 00 00 80 CB")
    if before[base + 0x0FDE:base + 0x0FE9] != stock_tail:
        raise PatchError(
            "C_00E.DLL 3:0FDE 숨김 tail이 순정 상태와 다릅니다: "
            + before[base + 0x0FDE:base + 0x0FE9].hex(" ")
        )
    if _relocation_source_state(before, seg3, {0x0FE0, 0x0FE1}, 805) != {0x0FE0}:
        raise PatchError("C_00E.DLL PL_TOP15 relocation이 순정 위치와 다릅니다.")
    if _relocation_source_state(before, seg3, {0x0FE4, 0x0FE5}, 808) != {0x0FE5}:
        raise PatchError("C_00E.DLL PL_TOP16 relocation이 순정 위치와 다릅니다.")

    out = bytearray(before)
    # 11 bytes, exactly replacing the two stock MOV-immediate stores + RETF:
    #   mov al,80h
    #   mov [PL_TOP15],al
    #   mov [PL_TOP16],al
    #   jmp short 1030h       ; existing two-page redraw + RETF
    #   nop
    out[base + 0x0FDE:base + 0x0FE9] = bytes.fromhex(
        "B0 80 A2 00 00 A2 00 00 EB 48 90"
    )
    _patch_relocation_source(out, seg3, 0x0FE0, 0x0FE1, 805)
    _patch_relocation_source(out, seg3, 0x0FE5, 0x0FE4, 808)
    after = bytes(out)

    segs_after = parse_ne_segments(after)
    if len(before) != len(after):
        raise PatchError("C_00E.DLL no-growth 보정이 파일 크기를 변경했습니다.")
    before_layout = [(x.file_offset, x.length, x.min_alloc) for x in segs_before]
    after_layout = [(x.file_offset, x.length, x.min_alloc) for x in segs_after]
    if before_layout != after_layout:
        raise PatchError(f"C_00E.DLL no-growth 보정이 NE 세그먼트 구조를 변경했습니다: {before_layout} -> {after_layout}")

    def reloc_count(blob: bytes, seg) -> int:
        pos = seg.file_offset + seg.length
        if pos + 2 > len(blob):
            raise PatchError("C_00E.DLL relocation table이 잘렸습니다.")
        return int.from_bytes(blob[pos:pos+2], "little")
    before_rc = reloc_count(before, segs_before[2])
    after_rc = reloc_count(after, segs_after[2])
    if before_rc != after_rc:
        raise PatchError(f"C_00E.DLL relocation 개수가 바뀌었습니다: {before_rc} -> {after_rc}")

    final = _c00e_inplace_warp_hide_state(after)
    if not final.get("ok"):
        raise PatchError(f"C_00E.DLL no-growth 게일/란도 숨김 보정 검증 실패: {final}")
    record_patch(path, before, after, COMPONENT)
    atomic_replace(path, after)
    return {
        "file": path.name,
        "changed_bytes": sum(a != b for a, b in zip(before, after)),
        "migration": migration.get("migration", "stock"),
        "file_size_unchanged": True,
        "segment_layout_unchanged": True,
        "relocation_count_unchanged": before_rc == after_rc,
        **final,
    }

def _retire_c00e_warp_finalizer(path: Path) -> dict[str, Any]:
    """Retire the old two-page finalizer and preserve the stock scene-exit flow.

    v1.0.8..v1.2.0 appended helper code and replaced 3:0EEA.  When the selective
    journal is present we remove the entire owned append safely.  Journal-less
    legacy copies are repaired conservatively by restoring only the original
    3:0EEA call; the unreachable legacy tail is left intact rather than risking
    unrelated out-of-line dialogue payloads.
    """
    before = path.read_bytes()
    stock = _c00e_stock_transition_state(before)
    if stock.get("ok"):
        return {"file": path.name, "changed_bytes": 0, "migration": "already_stock", **stock}

    jp = journal_path(path, COMPONENT)
    if jp.is_file():
        restored = selective_restore(path, COMPONENT)
        after = path.read_bytes()
        final = _c00e_stock_transition_state(after)
        if not final.get("ok"):
            raise PatchError(f"C_00E.DLL 기존 워프 보정 저널 복원 후 순정 흐름 검증 실패: {final}")
        return {"file": path.name, "changed_bytes": restored, "migration": "journal_restored", **final}

    seg = _scene_seg3(before, path.name)
    base = seg.file_offset
    callback = before[base + 0x09DC:base + 0x09DF]
    if callback != bytes.fromhex("15 75 0F"):
        raise PatchError(f"C_00E.DLL 게일 워프 콜백이 예상과 다릅니다: {callback.hex(' ')}")
    current = before[base + 0x0EEA:base + 0x0EEE]
    legacy_state = _c00e_warp_state(before)
    # v1.0.7 NOP state or v1.0.8+ finalizer state.  In the latter case the
    # appended helper may be shared with later dialogue-tail layouts, so only
    # restore the live call site when no ownership journal is available.
    if current == b"\x90" * 4 or legacy_state.get("ok"):
        out = bytearray(before)
        out[base + 0x0EEA:base + 0x0EEE] = bytes.fromhex("0E E8 87 00")
        atomic_replace(path, bytes(out))
        after = path.read_bytes()
        final = _c00e_stock_transition_state(after)
        if not final.get("ok"):
            raise PatchError(f"C_00E.DLL 저널 없는 구 워프 보정 복구 실패: {final}")
        return {
            "file": path.name,
            "changed_bytes": sum(a != b for a, b in zip(before, after)),
            "migration": "callsite_only_legacy_cleanup",
            "legacy_tail_left_unreachable": True,
            **final,
        }
    raise PatchError(
        "C_00E.DLL 게일/란도 워프 경로가 지원 상태와 다릅니다: "
        f"3:0EEA={current.hex(' ')} legacy={legacy_state}"
    )


def _c00e_warp_state(data: bytes) -> dict[str, Any]:
    segs = parse_ne_segments(data)
    if len(segs) < 3:
        return {"ok": False, "reason": "segments"}
    seg1, seg3 = segs[0], segs[2]
    base3 = seg3.file_offset
    callback_ok = data[base3 + 0x09DC:base3 + 0x09DF] == bytes.fromhex("15 75 0F")
    post = data[base3 + 0x0EEA:base3 + 0x0EEE]
    if len(post) != 4 or post[:2] != b"\x0E\xE8":
        return {"ok": False, "callback_ok": callback_ok, "seg3_length": seg3.length,
                "seg3_min_alloc": seg3.min_alloc, "post": post.hex(" ")}
    disp = _signed16(int.from_bytes(post[2:4], "little"))
    trampoline_start = (0x0EEE + disp) & 0xFFFF

    # v1.2.0 split layout: segment-3 trampoline FAR-JMPs to segment-1 helper.
    if trampoline_start >= 0x105E and seg3.length >= trampoline_start + 5:
        tramp = data[base3 + trampoline_start:base3 + trampoline_start + 5]
        target = _internal_far_relocation_target(data, seg3, trampoline_start + 1)
        if tramp == bytes.fromhex("EA 00 00 00 00") and target and target[0] == 1:
            helper_start = target[1]
            helper, _ = _make_c00e_warp_finalizer_split()
            base1 = seg1.file_offset
            helper_ok = (helper_start >= 0 and seg1.length >= helper_start + len(helper)
                         and data[base1 + helper_start:base1 + helper_start + len(helper)] == helper)
            reloc_ok = False
            if helper_ok:
                rel1 = (
                    _relocation_source_state(data, seg1, {helper_start + 2}, 805) == {helper_start + 2}
                    and _relocation_source_state(data, seg1, {helper_start + 9}, 808) == {helper_start + 9}
                    and _internal_far_relocation_target(data, seg1, helper_start + 15) == (3, 0x0F75)
                    and _relocation_source_state(data, seg1, {helper_start + 20, helper_start + 30}, 331)
                        == {helper_start + 20, helper_start + 30}
                    and _relocation_source_state(data, seg1, {helper_start + 25, helper_start + 35}, 62)
                        == {helper_start + 25, helper_start + 35}
                )
                reloc_ok = bool(rel1)
            return {
                "ok": bool(callback_ok and helper_ok and reloc_ok),
                "layout": "split_seg1_helper",
                "callback_ok": callback_ok, "helper_ok": helper_ok, "reloc_ok": reloc_ok,
                "trampoline_start": trampoline_start, "helper_segment": 1,
                "helper_start": helper_start, "seg3_length": seg3.length,
                "seg3_min_alloc": seg3.min_alloc,
                "tail_after_trampoline": seg3.length - (trampoline_start + 5),
            }

    # Legacy v1.1.0 layout: full helper appended directly to segment 3.
    helper_start = trampoline_start
    helper, _ = _make_c00e_warp_finalizer(helper_start)
    if helper_start < 0x105E or seg3.length < helper_start + len(helper):
        return {"ok": False, "callback_ok": callback_ok, "reason": "segment-length",
                "helper_start": helper_start, "seg3_length": seg3.length, "seg3_min_alloc": seg3.min_alloc}
    if seg3.min_alloc not in (0, seg3.length) and seg3.min_alloc < seg3.length:
        return {"ok": False, "callback_ok": callback_ok, "reason": "min-alloc",
                "helper_start": helper_start, "seg3_length": seg3.length, "seg3_min_alloc": seg3.min_alloc}
    helper_ok = data[base3 + helper_start:base3 + helper_start + len(helper)] == helper
    reloc_ok = (
        _relocation_source_state(data, seg3, {helper_start + 2}, 805) == {helper_start + 2}
        and _relocation_source_state(data, seg3, {helper_start + 9}, 808) == {helper_start + 9}
        and _relocation_source_state(data, seg3, {helper_start + 19, helper_start + 29}, 331)
            == {helper_start + 19, helper_start + 29}
        and _relocation_source_state(data, seg3, {helper_start + 24, helper_start + 34}, 62)
            == {helper_start + 24, helper_start + 34}
    )
    return {"ok": bool(callback_ok and helper_ok and reloc_ok), "layout": "legacy_seg3_helper",
            "callback_ok": callback_ok, "helper_ok": helper_ok, "reloc_ok": reloc_ok,
            "helper_start": helper_start, "seg3_length": seg3.length, "seg3_min_alloc": seg3.min_alloc,
            "tail_after_helper": seg3.length - (helper_start + len(helper))}


def _c204_barbara_state(data: bytes) -> dict[str, Any]:
    seg = _scene_seg3(data, "C_204.DLL")
    base = seg.file_offset
    callback = data[base + 0x023B:base + 0x023E]
    if len(callback) != 3 or callback[0] != 0x15:
        return {"ok": False, "callback": callback.hex(" "), "seg3_length": seg.length,
                "seg3_min_alloc": seg.min_alloc}
    helper_start = int.from_bytes(callback[1:3], "little")
    helper, _ = _make_c204_barbara_wrapper(helper_start)
    if helper_start < 0x04B5 or seg.length < helper_start + len(helper):
        return {"ok": False, "callback": callback.hex(" "), "reason": "segment-length",
                "helper_start": helper_start, "seg3_length": seg.length, "seg3_min_alloc": seg.min_alloc}
    if seg.min_alloc not in (0, seg.length) and seg.min_alloc < seg.length:
        return {"ok": False, "callback": callback.hex(" "), "reason": "min-alloc",
                "helper_start": helper_start, "seg3_length": seg.length, "seg3_min_alloc": seg.min_alloc}
    helper_ok = data[base + helper_start:base + helper_start + len(helper)] == helper
    expected = {
        331: {helper_start + 5, helper_start + 20},
        61: {helper_start + 10, helper_start + 25},
        62: {helper_start + 15, helper_start + 30},
    }
    reloc_ok = all(_relocation_source_state(data, seg, sources, ordinal) == sources
                   for ordinal, sources in expected.items())
    return {"ok": bool(helper_ok and reloc_ok), "callback_ok": True,
            "helper_ok": helper_ok, "reloc_ok": reloc_ok, "helper_start": helper_start,
            "seg3_length": seg.length, "seg3_min_alloc": seg.min_alloc,
            "tail_after_helper": seg.length - (helper_start + len(helper))}

def patch_dialogue_visible_events(root: Path) -> dict[str, Any]:
    results: dict[str, Any] = {}

    # C_00E / Chapter 3 Ludia castle: patch the stock shared warp routine in-place; no helper/NE growth.
    # The Chapter 2 -> 3 transition is elsewhere and is intentionally untouched.
    # Gale and Rando both keep their stock call sites; only 3:0F75's tail is redirected to an existing redraw block.
    path = root / "SCENA" / "C_00E.DLL"
    if not path.is_file():
        raise PatchError("SCENA/C_00E.DLL이 없습니다.")
    c00e = _apply_c00e_inplace_warp_hide(path)
    results["warp_gale_rando"] = {
        **c00e,
        "gale_hide_policy": "stock opcode-15 effect; hidden flags then existing in-place two-page redraw",
        "rando_policy": "stock post-DISP effect using the same no-growth hide routine; scene exits normally",
        "chapter_2_to_3_transition_modified": False,
    }

    # C_204: Barbara's original effect already runs in-message, but the final
    # hidden flag is not drawn to both pages.  Redirect callback to a wrapper.
    path = root / "SCENA" / "C_204.DLL"
    if not path.is_file():
        raise PatchError("SCENA/C_204.DLL이 없습니다.")
    before = path.read_bytes()
    state = _c204_barbara_state(before)
    if state.get("ok"):
        results["warp_barbara"] = {"file": path.name, "changed_bytes": 0, **state}
    else:
        seg = _scene_seg3(before, path.name)
        if not _seg3_growth_compatible(seg, 0x04B5):
            raise PatchError(
                f"C_204.DLL seg3 길이/min_alloc이 지원 상태가 아닙니다: "
                f"length={seg.length:04X}, min_alloc={seg.min_alloc:04X}"
            )
        base = seg.file_offset
        callback = before[base + 0x023B:base + 0x023E]
        if callback != bytes.fromhex("15 44 04"):
            raise PatchError(f"C_204.DLL 바바라 워프 콜백이 예상과 다릅니다: {callback.hex(' ')}")
        helper_start = seg.length
        helper, relocs = _make_c204_barbara_wrapper(helper_start)
        after, actual_start = _append_seg3_helper(before, path.name, helper, relocs)
        if actual_start != helper_start:
            raise PatchError("C_204.DLL helper 시작 위치 계산 오류")
        out = bytearray(after)
        out[base + 0x023C:base + 0x023E] = int(helper_start).to_bytes(2, "little")
        after = bytes(out)
        record_patch(path, before, after, COMPONENT)
        atomic_replace(path, after)
        final = _c204_barbara_state(after)
        if not final.get("ok"):
            raise PatchError(f"C_204.DLL 바바라 워프 패치 자체 검증 실패: {final}")
        results["warp_barbara"] = {
            "file": path.name,
            "changed_bytes": sum(a != b for a, b in zip(before, after)),
            "original_effect_preserved": True,
            "two_page_settle_after_hide": True,
            **final,
        }

    # Final chapter: hide all 12 monsters first, then settle both VGA pages.
    path = root / "SCENA" / "C_625.DLL"
    if not path.is_file():
        raise PatchError("SCENA/C_625.DLL이 없습니다.")
    before = path.read_bytes()
    already = _c625_monster_state(before)
    if already.get("ok"):
        changed = 0
        final = already
    else:
        seg = _scene_seg3(before, path.name)
        base = seg.file_offset
        # Stock order: DS_MZH -> hide -> MO_NUM.
        stock_block = bytes.fromhex(
            "9A FF FF 00 00 "
            "BB 00 00 B9 0C 00 80 0F 80 83 C3 08 E2 F8 "
            "C6 06 00 00 0B"
        )
        # v1.0.7/v1.0.8 order: hide -> MO_NUM -> one DS_MZH.
        one_page_block = bytes.fromhex(
            "BB 00 00 B9 0C 00 80 0F 80 83 C3 08 E2 F8 "
            "C6 06 00 00 0B 9A FF FF 00 00"
        )
        current = before[base + 0x0530:base + 0x0548]
        stock_reloc = (
            _relocation_source_state(before, seg, {0x0531, 0x0544}, 331) == {0x0531}
            and _relocation_source_state(before, seg, {0x0531, 0x0536}, 722) == {0x0536}
            and _relocation_source_state(before, seg, {0x0540, 0x0545}, 726) == {0x0545}
        )
        one_page_reloc = (
            _relocation_source_state(before, seg, {0x0531, 0x0544}, 331) == {0x0544}
            and _relocation_source_state(before, seg, {0x0531, 0x0536}, 722) == {0x0531}
            and _relocation_source_state(before, seg, {0x0540, 0x0545}, 726) == {0x0540}
        )
        if not _seg3_growth_compatible(seg, 0x0945):
            raise PatchError(
                f"C_625.DLL 종장 몬스터 seg3 상태가 지원 형태가 아닙니다: "
                f"length={seg.length:04X}, min_alloc={seg.min_alloc:04X}"
            )
        if current == stock_block and stock_reloc:
            ds_source = 0x0531
            move_pl = True
            move_mo = True
        elif current == one_page_block and one_page_reloc:
            ds_source = 0x0544
            move_pl = False
            move_mo = False
        else:
            raise PatchError(
                "C_625.DLL 종장 몬스터 소거 블록/relocation이 지원 상태와 다릅니다. "
                f"block={current.hex(' ')}"
            )

        helper_start = seg.length
        helper, new_relocs = _make_c625_monster_settle(helper_start)
        final_block = bytearray(bytes.fromhex(
            "BB 00 00 B9 0C 00 80 0F 80 83 C3 08 E2 F8 "
            "C6 06 00 00 0B E8 00 00 90 90"
        ))
        # Near CALL at 3:0543 to helper at 3:0945.
        disp = (helper_start - (0x0543 + 3)) & 0xFFFF
        final_block[0x14:0x16] = disp.to_bytes(2, "little")

        prepared = bytearray(before)
        prepared[base + 0x0530:base + 0x0548] = final_block
        # Reuse the pre-existing DS_MZH import relocation as the helper's first call.
        _patch_relocation_source(prepared, seg, ds_source, helper_start + 1, 331)
        if move_pl:
            _patch_relocation_source(prepared, seg, 0x0536, 0x0531, 722)
        if move_mo:
            _patch_relocation_source(prepared, seg, 0x0545, 0x0540, 726)

        after, actual_start = _append_seg3_helper(bytes(prepared), path.name, helper, new_relocs)
        if actual_start != helper_start:
            raise PatchError("C_625.DLL helper 시작 위치 계산 오류")
        final = _c625_monster_state(after)
        if not final.get("ok"):
            raise PatchError(f"C_625.DLL 종장 몬스터 두 페이지 소거 자체 검증 실패: {final}")
        record_patch(path, before, after, COMPONENT)
        atomic_replace(path, after)
        changed = sum(a != b for a, b in zip(before, after))

    results["final_monsters"] = {
        "file": path.name,
        "changed_bytes": changed,
        "redraw_after_hide": True,
        "two_page_settle_after_hide": True,
        **final,
    }
    results["warp_audit"] = {
        "live_use_scenes": ["C_00E.DLL (Gale/Rando)", "C_204.DLL (Barbara)", "T_000.DLL (Rauel)"],
        "patched": ["C_00E.DLL (shared stock warp routine tail, no growth)", "C_204.DLL"],
        "retired_for_runtime_safety": ["C_00E.DLL post-DISP two-page finalizer"],
        "c00e": "Chapter 3: Gale/Rando call sites stay stock; 3:0F75 uses the existing 3:1030 two-page redraw after hidden flags, with no NE growth.",
        "rauel": "T_000 clears the full screen immediately after DISP_MESS and enters the next program; no persistent page remains.",
        "non_live_reference": "C_733.DLL is retrospective dialogue only.",
    }
    return results


def inspect_dialogue_visible_events(root: Path) -> dict[str, Any]:
    result: dict[str, Any] = {}
    p = root / "SCENA" / "C_00E.DLL"
    result["warp_gale_rando"] = _c00e_inplace_warp_hide_state(p.read_bytes()).get("ok", False) if p.is_file() else False

    p = root / "SCENA" / "C_204.DLL"
    result["warp_barbara"] = _c204_barbara_state(p.read_bytes()).get("ok", False) if p.is_file() else False

    p = root / "SCENA" / "C_625.DLL"
    result["final_monsters"] = _c625_monster_state(p.read_bytes()).get("ok", False) if p.is_file() else False
    result["rauel_transition_audited"] = True
    result["ok"] = bool(result.get("warp_gale_rando") and result.get("warp_barbara") and result.get("final_monsters"))
    return result

def find_expanded_save_items(root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in find_save_files(root):
        raw = path.read_bytes()
        if len(raw) != 0x400:
            continue
        extra = list(raw[0x1CC:0x1D0])
        used = [{"slot": 29 + i, "item": value} for i, value in enumerate(extra) if value]
        if used:
            rows.append({"file": path.name, "items": used})
    return rows


def apply_patch(root: Path, settings: Setting) -> dict[str, Any]:
    root = validate_root(root)
    exe = root / "ED2MAIN.EXE"
    before = exe.read_bytes()
    segments = parse_ne_segments(before)
    if len(segments) < 86:
        raise PatchError("지원하는 ED2MAIN.EXE가 아닙니다.")
    s85 = segments[84]
    s86 = segments[85]
    data85 = bytearray(before[s85.file_offset:s85.file_offset+s85.length])
    code86 = bytearray(before[s86.file_offset:s86.file_offset+s86.length])
    safety, inventory, animation = load_helper_ranges()

    patch_runtime_safety(code86, settings.runtime_safety, safety)
    # v1.0.1부터 인벤토리 확장은 철회합니다. 이전 v1.0.0/v1.0.6 적용본이면
    # ED2MAIN 훅과 코드 동굴을 순정 28칸 상태로 되돌립니다.
    patch_inventory(code86, 28, inventory)
    # 전투 애니메이션 속도 조정은 v1.0.2부터 철회합니다. 이전 버전의 훅도 제거합니다.
    restore_vanilla_animation(code86, animation)

    if not 0 <= settings.dialogue_speed <= 2:
        raise PatchError("대사 속도는 0..2여야 합니다.")
    data85[0x2048] = settings.dialogue_speed
    # v1.0.8까지 올인원이 강제로 넣었던 FIGHT_MESS=0(빠르게)는 철회합니다.
    # 순정 ED2MAIN의 기본값은 1(보통)이며, 실제 저장 파일의 0x49 설정은 건드리지 않습니다.
    if data85[0x2049] == 0:
        data85[0x2049] = 1

    after = bytearray(before)
    after[s85.file_offset:s85.file_offset+s85.length] = data85
    after[s86.file_offset:s86.file_offset+s86.length] = code86
    if before != after:
        bak = exe.with_suffix(exe.suffix + ".bak")
        if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") != "1" and not bak.exists():
            shutil.copy2(exe, bak)
        record_patch(exe, before, bytes(after), COMPONENT)
        atomic_replace(exe, bytes(after))

    # C_631의 직접 아이템 검색 길이도 순정 20개로 복원합니다.
    c631_result = patch_c631_inventory_count(root, 28)
    event_timing_result = patch_dialogue_visible_events(root)
    save_result = None
    if settings.repair_saves:
        save_result = repair_saves(root, settings.dialogue_speed, False)
    return {
        "version": VERSION,
        "changed_bytes": sum(a != b for a, b in zip(before, after)),
        "sha256_before": sha256_bytes(before),
        "sha256_after": sha256_bytes(bytes(after)),
        "settings": settings.__dict__,
        "c631_inventory_scan": c631_result,
        "dialogue_visible_events": event_timing_result,
        "save_repair": save_result,
    }


def inspect_patch(root: Path) -> dict[str, Any]:
    root = validate_root(root)
    data = (root / "ED2MAIN.EXE").read_bytes()
    segs = parse_ne_segments(data)
    s85, s86 = segs[84], segs[85]
    d85 = data[s85.file_offset:s85.file_offset+s85.length]
    c86 = data[s86.file_offset:s86.file_offset+s86.length]
    safety, inventory, animation = load_helper_ranges()
    safety_on = c86[SAFETY_CAVE[0]:SAFETY_CAVE[1]] == safety
    inventory_on = c86[INVENTORY_CAVE[0]:INVENTORY_CAVE[1]] == inventory
    anim_site = c86[0x5DA0:0x5DA4]
    short = _near(0x5DA0, H["anim_short"]) + b"\x90"
    instant = _near(0x5DA0, H["anim_instant"]) + b"\x90"
    anim = "short" if anim_site == short else "instant" if anim_site == instant else "normal" if anim_site == bytes.fromhex("88 26 43 3F") else "unknown"
    c631 = root / "SCENA" / "C_631.DLL"
    c631_count = None
    if c631.is_file():
        cdata = c631.read_bytes()
        csegs = parse_ne_segments(cdata)
        if len(csegs) >= 3:
            cpos = csegs[2].file_offset + 0x350
            c631_count = int.from_bytes(cdata[cpos:cpos + 2], "little")
    return {
        "runtime_safety": safety_on,
        "inventory_expansion": inventory_on,
        "inventory_slots": 32 if inventory_on else 28,
        "c631_inventory_scan_count": c631_count,
        "battle_animation": anim,
        "dialogue_speed": d85[0x2048],
        "battle_message_speed": d85[0x2049],
        "dialogue_visible_events": inspect_dialogue_visible_events(root),
        "journal": str(journal_path(root / "ED2MAIN.EXE", COMPONENT)),
    }


def restore_patch(root: Path) -> dict[str, Any]:
    root = validate_root(root)
    exe = root / "ED2MAIN.EXE"
    c631 = root / "SCENA" / "C_631.DLL"
    restored_main = selective_restore(exe, COMPONENT) if journal_path(exe, COMPONENT).is_file() else 0
    restored_c631 = selective_restore(c631, COMPONENT) if journal_path(c631, COMPONENT).is_file() else 0
    restored_events = 0
    for name in EVENT_SCENA_FILES:
        scene = root / "SCENA" / name
        if journal_path(scene, COMPONENT).is_file():
            restored_events += selective_restore(scene, COMPONENT)
    return {
        "restored_bytes": restored_main + restored_c631 + restored_events,
        "ed2main_restored_bytes": restored_main,
        "c631_restored_bytes": restored_c631,
        "event_scene_restored_bytes": restored_events,
        "sha256": sha256_bytes(exe.read_bytes()),
    }


def compute_save_checksum(data: bytes | bytearray) -> tuple[int, int]:
    if len(data) != 0x400:
        raise ValueError("save size must be 1024 bytes")
    buf = bytearray(data)
    buf[0x1FE] = 0
    buf[0x1FF] = 0
    return sum(buf) & 0xFF, _xor_all(buf)


def _xor_all(data: bytes | bytearray) -> int:
    x = 0
    for value in data:
        x ^= value
    return x


def analyze_save(path: Path, expanded: bool = False) -> dict[str, Any]:
    raw = path.read_bytes()
    errors: list[str] = []
    warnings: list[str] = []
    if len(raw) != 0x400:
        return {"file": path.name, "ok": False, "errors": [f"파일 크기 {len(raw)} (정상 1024)"], "warnings": []}
    if raw[0x1FA:0x1FE] != b"ED-2":
        errors.append("세이브 식별자 ED-2 불일치")
    expected = compute_save_checksum(raw)
    actual = (raw[0x1FE], raw[0x1FF])
    if actual != expected:
        errors.append(f"체크섬 불일치 actual={actual} expected={expected}")
    if raw[0x48] > 2:
        warnings.append(f"SCR_SPEED 범위 초과: {raw[0x48]}")
    if raw[0x49] > 3:
        warnings.append(f"FIGHT_MESS 범위 초과: {raw[0x49]}")
    active = 0
    players = []
    for i, base in enumerate((0x300, 0x340, 0x380, 0x3C0), start=1):
        is_active = (raw[base] & 0x80) == 0
        if is_active:
            active += 1
        level = raw[base+3]
        hp = int.from_bytes(raw[base+4:base+6], "little")
        max_hp = int.from_bytes(raw[base+6:base+8], "little")
        if is_active and not 1 <= level <= 99:
            errors.append(f"파티원{i} 레벨 범위 오류: {level}")
        if is_active and max_hp == 0:
            errors.append(f"파티원{i} 최대 HP 0")
        if hp > max_hp and max_hp:
            warnings.append(f"파티원{i} 현재 HP({hp}) > 최대 HP({max_hp})")
        status_flags = raw[base + 0x24]
        status_counter = raw[base + 0x29]
        if is_active and (status_flags & 0x08) and status_counter == 0:
            warnings.append(f"파티원{i} 상태 플래그 0x08이 켜졌지만 카운터가 0")
        inconsistent_magic = []
        for magic_slot in range(7):
            magic_state = raw[base + 0x1D + magic_slot]
            charge_counter = raw[base + 0x39 + magic_slot]
            if is_active and magic_state != 0xEF and (magic_state & 0xE0) and charge_counter == 0:
                inconsistent_magic.append(magic_slot)
        if inconsistent_magic:
            warnings.append(f"파티원{i} 주문 충전 플래그/카운터 불일치: 슬롯 {inconsistent_magic}")
        players.append({"slot": i, "active": is_active, "level": level, "hp": hp, "max_hp": max_hp})
    if active == 0:
        errors.append("활성 파티원이 0명")
    inv = list(raw[0x54:0x70])
    if expanded:
        inv += list(raw[0x1CC:0x1D0])
    invalid = [(i, v) for i, v in enumerate(inv) if v > 0xCB]
    if invalid:
        warnings.append("비정상 아이템 코드: " + ", ".join(f"{i}=0x{v:02X}" for i, v in invalid))
    return {
        "file": path.name,
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "active_players": active,
        "players": players,
        "inventory_slots": len(inv),
        "used_inventory": sum(v != 0 for v in inv),
    }


def repair_save(path: Path, dialogue_speed: int, expanded: bool) -> dict[str, Any]:
    raw = bytearray(path.read_bytes())
    if len(raw) != 0x400:
        return {"file": path.name, "changed": False, "skipped": "size"}
    before = bytes(raw)
    if raw[0x1FA:0x1FE] != b"ED-2":
        return {"file": path.name, "changed": False, "skipped": "invalid_id"}
    raw[0x48] = max(0, min(2, dialogue_speed))
    for base in (0x300, 0x340, 0x380, 0x3C0):
        if raw[base] & 0x80:
            continue
        raw[base+3] = max(1, min(99, raw[base+3]))
        max_hp = int.from_bytes(raw[base+6:base+8], "little")
        if max_hp == 0:
            max_hp = 1
            raw[base+6:base+8] = (1).to_bytes(2, "little")
        hp = int.from_bytes(raw[base+4:base+6], "little")
        if hp > max_hp:
            raw[base+4:base+6] = max_hp.to_bytes(2, "little")
        # 알려진 상태 지속 플래그(0x08)와 카운터가 불일치하면 상태를 해제합니다.
        if (raw[base + 0x24] & 0x08) and raw[base + 0x29] == 0:
            raw[base + 0x24] &= 0xF7
        # 충전 중인 주문 상태인데 보조 카운터가 0이면 1로 정상화합니다.
        for magic_slot in range(7):
            magic_state = raw[base + 0x1D + magic_slot]
            if magic_state != 0xEF and (magic_state & 0xE0) and raw[base + 0x39 + magic_slot] == 0:
                raw[base + 0x39 + magic_slot] = 1
    ranges = [(0x54, 0x70)] + ([(0x1CC, 0x1D0)] if expanded else [])
    for start, end in ranges:
        for i in range(start, end):
            if raw[i] > 0xCB:
                raw[i] = 0
    dl, dh = compute_save_checksum(raw)
    raw[0x1FE], raw[0x1FF] = dl, dh
    if bytes(raw) != before:
        bak = path.with_name(path.name + ".stability_qol.bak")
        if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") != "1" and not bak.exists():
            shutil.copy2(path, bak)
        atomic_replace(path, bytes(raw))
    return {"file": path.name, "changed": bytes(raw) != before, "changed_bytes": sum(a != b for a, b in zip(before, raw))}


def find_save_files(root: Path) -> list[Path]:
    save_dir = root / "SAVE"
    if not save_dir.is_dir():
        return []
    return sorted(p for p in save_dir.glob("S_*.DAT") if p.is_file())


def repair_saves(root: Path, dialogue_speed: int, expanded: bool) -> dict[str, Any]:
    rows = [repair_save(p, dialogue_speed, expanded) for p in find_save_files(root)]
    return {"files": len(rows), "changed": sum(bool(r.get("changed")) for r in rows), "results": rows}


def audit_saves(root: Path, expanded: bool = False) -> dict[str, Any]:
    rows = [analyze_save(p, expanded) for p in find_save_files(root)]
    return {"files": len(rows), "errors": sum(len(r.get("errors", [])) for r in rows), "warnings": sum(len(r.get("warnings", [])) for r in rows), "results": rows}


def visual_width(text: str) -> int:
    return sum(1 if ord(ch) < 0x80 else 2 for ch in text)


def audit_scena_and_text(root: Path) -> dict[str, Any]:
    project = SceneProject(root)
    base = project.validate()
    missing_dest: list[dict[str, Any]] = []
    missing_algo: list[str] = []
    text_warnings: list[dict[str, Any]] = []
    control_warnings: list[dict[str, Any]] = []
    seen: set[tuple[str, int, int]] = set()
    duplicate: list[dict[str, Any]] = []
    for path in project.paths:
        try:
            scene = project.load(path)
        except Exception:
            continue
        if path.name.startswith("F_") and "ALGO_00" not in scene.exports:
            missing_algo.append(path.name)
        for t in scene.transitions:
            if not (project.scene_dir / t.destination_scene).is_file():
                missing_dest.append({"source": path.name, "destination": t.destination_scene, "segment": t.call_segment, "offset": t.call_source_offset})
        for item in scene.strings:
            key = (path.name, item.segment, item.offset)
            if key in seen:
                duplicate.append({"dll": path.name, "segment": item.segment, "offset": item.offset})
            seen.add(key)
            try:
                encoded = item.text.encode("cp949")
            except UnicodeEncodeError as exc:
                text_warnings.append({"dll": path.name, "segment": item.segment, "offset": item.offset, "issue": "CP949 인코딩 불가", "detail": str(exc)})
                continue
            if len(encoded) > item.capacity:
                text_warnings.append({"dll": path.name, "segment": item.segment, "offset": item.offset, "issue": "문자열 슬롯 초과", "bytes": len(encoded), "capacity": item.capacity})
            lines = item.text.replace("\r", "").split("\n")
            max_width = max((visual_width(line) for line in lines), default=0)
            # 원작은 긴 문자열을 런타임에서 자동 줄바꿈하므로 매우 긴 경우만 경고합니다.
            if max_width > 160:
                text_warnings.append({"dll": path.name, "segment": item.segment, "offset": item.offset, "issue": "표시 폭 경고", "width": max_width, "text": item.text[:80]})
            if item.raw.count(0x1E) != item.raw.count(0x04):
                control_warnings.append({"dll": path.name, "segment": item.segment, "offset": item.offset, "issue": "화자명 제어코드 1E/04 불균형"})
    errors = list(base.get("errors", []))
    audit_warnings = list(base.get("warnings", []))
    if missing_dest:
        audit_warnings.append(f"파일이 없는 전환 참조 후보 {len(missing_dest)}개 (미사용/그래픽 호출일 수 있어 자동 수정하지 않음)")
    return {
        "ok": not errors,
        "scene_project": base,
        "missing_destination_count": len(missing_dest),
        "missing_destinations": missing_dest,
        "missing_algo00_count": len(missing_algo),
        "missing_algo00": missing_algo,
        "text_warning_count": len(text_warnings),
        "text_warnings": text_warnings,
        "control_warning_count": len(control_warnings),
        "control_warnings": control_warnings,
        "duplicate_string_address_count": len(duplicate),
        "duplicate_string_addresses": duplicate,
        "warnings": audit_warnings,
        "errors": errors,
    }


def run_full_audit(root: Path, write_report: bool = True) -> dict[str, Any]:
    root = validate_root(root)
    state = inspect_patch(root)
    report = {
        "tool": APP_NAME,
        "version": VERSION,
        "root": str(root),
        "patch_state": state,
        "scena_text": audit_scena_and_text(root),
        "saves": audit_saves(root, False),
    }
    if write_report:
        (root / "ED2_STABILITY_AUDIT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        lines = [
            f"{APP_NAME} v{VERSION}",
            f"SCENA/Text OK: {report['scena_text']['ok']}",
            f"SCENA errors: {len(report['scena_text']['errors'])}",
            f"Text warnings: {report['scena_text']['text_warning_count']}",
            f"Control warnings: {report['scena_text']['control_warning_count']}",
            f"Save files: {report['saves']['files']}",
            f"Save errors: {report['saves']['errors']}",
            f"Save warnings: {report['saves']['warnings']}",
        ]
        (root / "ED2_STABILITY_AUDIT_KO.txt").write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
    return report


def load_settings(path: Path | None) -> Setting:
    if path is None or not path.is_file():
        return Setting()
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    return Setting(
        runtime_safety=bool(raw.get("runtime_safety", True)),
        dialogue_speed=int(raw.get("dialogue_speed", 0)),
        repair_saves=bool(raw.get("repair_saves", False)),
    )


class GUI:
    def __init__(self, initial: Path | None = None):
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
        self.tk, self.ttk, self.filedialog, self.messagebox = tk, ttk, filedialog, messagebox
        self.root = tk.Tk(); self.root.title(f"{APP_NAME} v{VERSION}"); self.root.minsize(760, 570)
        self.path = tk.StringVar(value=str(initial or ""))
        self.runtime = tk.BooleanVar(value=True)
        self.dialogue = tk.StringVar(value="0")
        self.repair = tk.BooleanVar(value=False)
        outer = ttk.Frame(self.root, padding=12); outer.pack(fill="both", expand=True)
        row = ttk.Frame(outer); row.pack(fill="x")
        ttk.Entry(row, textvariable=self.path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="게임 폴더", command=self.choose).pack(side="left", padx=8)
        box = ttk.LabelFrame(outer, text="안정성 및 편의 설정", padding=10); box.pack(fill="x", pady=10)
        ttk.Checkbutton(box, text="전투 수치 안전성 패치", variable=self.runtime).grid(row=0, column=0, columnspan=2, sticky="w", pady=3)
        ttk.Label(box, text="대사 표시 속도").grid(row=1, column=0, sticky="w")
        ttk.Combobox(box, textvariable=self.dialogue, values=("0", "1", "2"), state="readonly", width=18).grid(row=1, column=1, sticky="w")
        ttk.Checkbutton(box, text="기존 SAVE/S_*.DAT도 검사·보정", variable=self.repair).grid(row=2, column=0, columnspan=2, sticky="w", pady=3)
        ttk.Label(box, text="대사 속도: 0=빠르게, 1=보통, 2=느리게", justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=5)
        self.log = tk.Text(outer, height=15, wrap="word", state="disabled"); self.log.pack(fill="both", expand=True)
        buttons = ttk.Frame(outer); buttons.pack(fill="x", pady=(8,0))
        ttk.Button(buttons, text="적용", command=self.apply).pack(side="left")
        ttk.Button(buttons, text="전체 검사", command=self.audit).pack(side="left", padx=6)
        ttk.Button(buttons, text="이 도구 변경 복원", command=self.restore).pack(side="left")
        ttk.Button(buttons, text="닫기", command=self.root.destroy).pack(side="right")

    def choose(self):
        p = self.filedialog.askdirectory(title="영웅전설 II 게임 폴더")
        if p: self.path.set(p)
    def put(self, obj: Any):
        self.log.configure(state="normal"); self.log.insert("end", json.dumps(obj, ensure_ascii=False, indent=2)+"\n"); self.log.see("end"); self.log.configure(state="disabled")
    def settings(self) -> Setting:
        return Setting(self.runtime.get(), int(self.dialogue.get()), self.repair.get())
    def apply(self):
        try:
            result = apply_patch(Path(self.path.get()), self.settings()); self.put(result); self.messagebox.showinfo(APP_NAME, "적용했습니다.")
        except Exception as exc: self.messagebox.showerror(APP_NAME, str(exc))
    def audit(self):
        try:
            result = run_full_audit(Path(self.path.get())); self.put(result); self.messagebox.showinfo(APP_NAME, "검사 보고서를 게임 폴더에 저장했습니다.")
        except Exception as exc: self.messagebox.showerror(APP_NAME, str(exc))
    def restore(self):
        try:
            result = restore_patch(Path(self.path.get())); self.put(result); self.messagebox.showinfo(APP_NAME, "복원했습니다.")
        except Exception as exc: self.messagebox.showerror(APP_NAME, str(exc))
    def run(self): self.root.mainloop()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    ap.add_argument("path", nargs="?", type=Path)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--audit", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--restore", action="store_true")
    ap.add_argument("--settings", type=Path)
    ap.add_argument("--runtime-safety", choices=("on", "off"))
    ap.add_argument("--dialogue-speed", type=int, choices=(0,1,2))
    ap.add_argument("--repair-saves", action="store_true")
    ap.add_argument("--no-gui", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.path and (args.apply or args.audit or args.check or args.restore):
            if args.restore:
                result = restore_patch(args.path)
            elif args.audit:
                result = run_full_audit(args.path)
            elif args.check:
                result = inspect_patch(args.path)
            else:
                s = load_settings(args.settings)
                s = Setting(
                    runtime_safety=s.runtime_safety if args.runtime_safety is None else args.runtime_safety == "on",
                    dialogue_speed=s.dialogue_speed if args.dialogue_speed is None else args.dialogue_speed,
                    repair_saves=s.repair_saves or args.repair_saves,
                )
                result = apply_patch(args.path, s)
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0
        if args.no_gui:
            ap.error("--no-gui에서는 path와 작업 옵션이 필요합니다.")
        GUI(args.path).run(); return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr); return 1


if __name__ == "__main__":
    raise SystemExit(main())
