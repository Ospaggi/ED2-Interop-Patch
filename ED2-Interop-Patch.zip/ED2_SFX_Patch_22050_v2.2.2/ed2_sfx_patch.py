#!/usr/bin/env python3
from __future__ import annotations

import os
import argparse, hashlib, json, os, re, shutil, struct, sys
from pathlib import Path

APP = "ED2 22.05 kHz SFX Patch"
VERSION = "2.2.2"
TARGET_RATE = 22050
MAX_PAYLOAD = 0xFFFF
DEFAULT_MIXING_RATE = 22050
PATCH_DIR = Path(__file__).resolve().parent
ASSET_DIR = PATCH_DIR / "SMP"
PATCH_NAMES = ['EFC1.SMP', 'EFC12.SMP', 'EFC14.SMP', 'EFC15.SMP', 'EFC19.SMP', 'EFC2.SMP', 'EFC20.SMP', 'EFC4.SMP', 'EFC5.SMP', 'EFC7.SMP', 'EFC8.SMP', 'EFC9.SMP', 'FE049.SMP', 'FE059.SMP', 'FE079.SMP', 'FE089.SMP', 'FE099.SMP', 'FE109.SMP', 'FE119.SMP', 'FE129.SMP', 'FE139.SMP', 'FE999.SMP']
MANIFEST_NAME = "manifest.json"
BACKUP_REL = Path("ED2_BACKUP") / "SFX_22050"
BACKUP_DIR_NAME = "ED2_SFX_ORIGINAL_BACKUP"  # legacy root-level directory
LEGACY_BACKUP_DIRS = ("ED2_SFX_44100_BACKUP", "ED2_SFX_22050_BACKUP")

class PatchError(Exception): pass

def _move_tree(src: Path, dst: Path) -> None:
    if not src.exists(): return
    if not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst)); return
    if src.is_dir() and dst.is_dir():
        for child in list(src.iterdir()):
            target=dst/child.name
            if not target.exists(): shutil.move(str(child), str(target))
            elif child.is_dir() and target.is_dir(): _move_tree(child,target)
            else:
                legacy=dst/(child.name+'.legacy')
                i=2
                while legacy.exists(): legacy=dst/(child.name+f'.legacy{i}'); i+=1
                shutil.move(str(child),str(legacy))
        try: src.rmdir()
        except OSError: pass

def migrate_backup_layout(root: Path) -> None:
    base=root/BACKUP_REL
    # v2.2.0 current backup becomes the new Original tree.
    _move_tree(root/BACKUP_DIR_NAME, base/'Original')
    old_manifest=root/'ED2_SFX_22050_PATCH_MANIFEST.json'
    if old_manifest.is_file():
        target=base/MANIFEST_NAME; target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists(): shutil.move(str(old_manifest),str(target))
        else:
            leg=base/'LEGACY'/'ED2_SFX_22050_PATCH_MANIFEST.json'; leg.parent.mkdir(parents=True,exist_ok=True)
            if not leg.exists(): shutil.move(str(old_manifest),str(leg))
    for name in LEGACY_BACKUP_DIRS:
        _move_tree(root/name, base/'LEGACY'/name)


def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024), b''): h.update(c)
    return h.hexdigest()

def validate_smp(path: Path):
    d=path.read_bytes()
    if len(d)<14: raise PatchError(f"Invalid SMP: {path.name}")
    rate,n,e1,e2=struct.unpack_from('<HIII',d,0)
    if rate!=TARGET_RATE: raise PatchError(f"{path.name}: expected {TARGET_RATE}, got {rate}")
    if n!=len(d)-14 or not (1<=n<=MAX_PAYLOAD): raise PatchError(f"{path.name}: invalid payload length")
    if e1!=n-1 or e2!=n-1: raise PatchError(f"{path.name}: invalid end markers")
    return n

def find_game_root(start: Path) -> Path:
    start=start.resolve()
    if start.is_file(): start=start.parent
    def is_root(p: Path)->bool:
        try: return any(x.is_file() and x.name.upper()=='ED2MAIN.EXE' for x in p.iterdir())
        except OSError: return False
    if is_root(start): return start
    for parent in start.parents:
        if is_root(parent): return parent
    hits=[]; patch_resolved=PATCH_DIR.resolve()
    excluded={"ED2_BACKUP", BACKUP_DIR_NAME.upper(),*(x.upper() for x in LEGACY_BACKUP_DIRS)}
    for base,dirs,files in os.walk(start):
        base_path=Path(base); kept=[]
        for d in dirs:
            child=(base_path/d).resolve()
            if d.upper() in excluded or child==patch_resolved: continue
            kept.append(d)
        dirs[:]=kept
        if any(f.upper()=='ED2MAIN.EXE' for f in files): hits.append(base_path)
    if len(hits)==1: return hits[0]
    if not hits: raise PatchError('ED2MAIN.EXE was not found. Select the ED2 game folder.')
    raise PatchError('Multiple ED2MAIN.EXE files found. Select the exact ED2 game folder.')

def find_root_file(root:Path,name:str)->Path:
    hits=[p for p in root.iterdir() if p.is_file() and p.name.upper()==name.upper()]
    if len(hits)!=1: raise PatchError(f'{name} was not found uniquely in the game root.')
    return hits[0]

def find_bgm_dir(root:Path)->Path:
    hits=[p for p in root.iterdir() if p.is_dir() and p.name.upper()=='BGM']
    if len(hits)==1: return hits[0]
    if not hits: raise PatchError('BGM directory was not found in the ED2 game root.')
    raise PatchError('Multiple BGM directories were found in the ED2 game root.')

def locate_smp(root:Path):
    bgm=find_bgm_dir(root)
    files={p.name.upper():p for p in bgm.iterdir() if p.is_file()}
    missing=[n for n in PATCH_NAMES if n.upper() not in files]
    if missing: raise PatchError('Missing original SMP file(s) in BGM: '+', '.join(missing))
    return {n.upper():files[n.upper()] for n in PATCH_NAMES}

def patch_cnf_bytes(data:bytes,mixing_rate:int)->bytes:
    m=re.search(br'(?im)^(\s*MixingRate\s*=\s*)(\d+)([^\r\n]*)',data)
    if not m: raise PatchError('MixingRate entry was not found in ED2.CNF.')
    return data[:m.start(2)]+str(mixing_rate).encode('ascii')+data[m.end(2):]

def seed_original_backup(root:Path, rel:Path, current:Path, backup:Path):
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1": return 'aio_transaction'
    if backup.exists(): return 'existing'
    # If the 44.1 kHz patch was applied first, its backup contains the true stock file.
    for legacy_name in LEGACY_BACKUP_DIRS:
        for legacy in (root/legacy_name/rel, root/BACKUP_REL/'LEGACY'/legacy_name/rel):
            if legacy.exists():
                backup.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(legacy,backup)
                return f'migrated:{legacy_name}'
    backup.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(current,backup)
    return 'current'

def apply(root_arg:str,mixing_rate:int):
    if not (1000<=mixing_rate<=65535): raise PatchError('MixingRate must fit 1000..65535.')
    root=find_game_root(Path(root_arg)); aio_no_backup=os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP') == '1'
    if not aio_no_backup: migrate_backup_layout(root)
    cnf=find_root_file(root,'ED2.CNF'); targets=locate_smp(root)
    backup=root/BACKUP_REL/"Original"; manifest_path=root/BACKUP_REL/MANIFEST_NAME
    manifest={'patch':APP,'version':VERSION,'smp_rate':TARGET_RATE,'mixing_rate':mixing_rate,'files':[]}

    cnf_rel=cnf.relative_to(root); cnf_bak=backup/cnf_rel
    origin=seed_original_backup(root,cnf_rel,cnf,cnf_bak)
    old_data=cnf.read_bytes(); cnf.write_bytes(patch_cnf_bytes(old_data,mixing_rate))
    manifest['cnf']={'path':cnf_rel.as_posix(),'backup':(cnf_bak.relative_to(root).as_posix() if origin != 'aio_transaction' else ''),
                     'backup_source':origin,'patched_sha256':sha256_file(cnf)}
    print(f'Patched {cnf_rel}: MixingRate -> {mixing_rate}')

    for name in PATCH_NAMES:
        src=ASSET_DIR/name; validate_smp(src)
        dst=targets[name]; rel=dst.relative_to(root); bak=backup/rel
        origin=seed_original_backup(root,rel,dst,bak)
        shutil.copy2(src,dst); size=validate_smp(dst)
        manifest['files'].append({'name':name,'path':rel.as_posix(),'backup':(bak.relative_to(root).as_posix() if origin != 'aio_transaction' else ''),
                                  'backup_source':origin,'patched_sha256':sha256_file(dst),'payload_bytes':size})
        print(f'Patched {rel} -> {TARGET_RATE} Hz ({size} samples)')
    if not aio_no_backup:
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'\nPatched {len(PATCH_NAMES)} effect files at 22.05 kHz.')
    print(f'ED2.CNF MixingRate = {mixing_rate}')
    print('EFFECT7.SMP was not supplied and was left unchanged.')
    print('Backup directories: ignored by All-in-One' if aio_no_backup else f'Original backup: {backup}')

def restore(root_arg:str):
    root=find_game_root(Path(root_arg)); migrate_backup_layout(root); manifest_path=root/BACKUP_REL/MANIFEST_NAME
    if not manifest_path.exists():
        legacy_manifest=root/"ED2_SFX_22050_PATCH_MANIFEST.json"
        if legacy_manifest.exists(): manifest_path=legacy_manifest
        else: raise PatchError(f'Manifest not found: {manifest_path}')
    m=json.loads(manifest_path.read_text(encoding='utf-8')); recs=[]
    if 'cnf' in m: recs.append(m['cnf'])
    recs.extend(m.get('files',[]))
    count=0
    for rec in recs:
        dst=root/rec['path']
        if rec.get('backup_source') == 'aio_transaction':
            raise PatchError('이 설치는 올인원 트랜잭션 백업을 사용합니다. 올인원 패처의 복원 기능을 사용하세요.')
        bak=root/rec['backup']
        if not bak.exists(): raise PatchError(f'Backup missing: {bak}')
        dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(bak,dst); count+=1
        print(f'Restored {rec["path"]}')
    print(f'\nRestored ED2.CNF and {max(0,count-1)} effect files.')

def verify_assets():
    for n in PATCH_NAMES:
        size=validate_smp(ASSET_DIR/n); print(f'{n:12} {TARGET_RATE} Hz {size:5} samples OK')
    print(f'Verified {len(PATCH_NAMES)} assets.')

def main():
    ap=argparse.ArgumentParser(description=f'{APP} v{VERSION}')
    ap.add_argument('game',nargs='?',default='.',help='ED2 game folder')
    ap.add_argument('--mixing-rate',type=int,default=DEFAULT_MIXING_RATE,help='ED2.CNF MixingRate (default: 22050)')
    ap.add_argument('--restore',action='store_true'); ap.add_argument('--verify-assets',action='store_true')
    a=ap.parse_args()
    try:
        if a.verify_assets: verify_assets()
        elif a.restore: restore(a.game)
        else: apply(a.game,a.mixing_rate)
        return 0
    except Exception as e:
        print(f'ERROR: {e}',file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
