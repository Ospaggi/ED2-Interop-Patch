# 구성요소

AIO 기본 적용 순서는 기능 충돌과 소유권을 고려해 정해져 있습니다. 순서를 임의로 바꾸지 않는 것을 권장합니다.

| 순서 | 키 | 기능 |
|---:|---|---|
| 1 | `dialogue` | 전체 대사 교정 및 표시 보정 |
| 2 | `text` | UI·텍스트·전투 표시 수정 |
| 3 | `opening` | PC-98판 기반 오프닝 연출 보정 |
| 4 | `ending` | 엔딩·스태프롤·나레이션 보정 |
| 5 | `map_preset` | 지하동굴 미로 간소화 |
| 6 | `initial_equipment` | 플레이어 초기 장비 기본 설정 |
| 7 | `items` | 아이템 효과·수치 조정 |
| 8 | `shops` | 1편 아이템 복원 |
| 9 | `bug_fix` | EXP·Gold 오버플로 및 마법 카운터 버그 수정 |
| 10 | `magic_recharge` | 오비스 제외 마법 재충전 속도 조정 |
| 11 | `m504_restoration` | M_504 다다르카·악토스 전투 복원 |
| 12 | `balance` | 몬스터·전투 편성 밸런스 조정 |
| 13 | `monster_text` | 몬스터 전투·특수행동 문구 수정 |
| 14 | `experience` | EXP·Gold 획득 규칙 개선 |
| 15 | `level_exp` | 레벨별 요구 EXP 곡선 조정 |
| 16 | `stability_qol` | 전투 안정성·일부 연출 오류 수정 |
| 17 | `additional_qol` | Shift 고속 이동·메뉴 편의 기능 |
| 18A | `vgm_bgm` | 교체 VGM BGM 사용 (기본) |
| 18B | `original_bgm` | 원본 MUS BGM 사용; 제어/hard-stop 수정 유지 |
| 19 | `sfx_22050` | 효과음 22종 갱신 |
| 20 | `flute_bgm` | 전사의 피리 음악·연출 수정 |
| 21 | `chapter_refresh` | 장 제목 갱신·장 종료 화면 공백 정렬 |
| 22 | `final_battle_presentation` | 마지막 보스전 연출 보정 |
| 23 | `direct_ending` | 직접 엔딩 실행 기능 추가 |

## 대사 데이터 구조

대사 구성요소는 현재 R51 정본만 배포합니다. 과거 R26~R50 중간 스냅샷과 `apply_rXX_*.py` 증분 스크립트는 포함하지 않습니다. `apply_dialogue.py` 하나가 순정 SCENA에서 현재 정본으로 직접 수렴시키며, 과거 작업 이력은 Git 이력으로 관리합니다.

줄바꿈 데이터도 현재 정본인 `dialogue_presentation.csv`와 `dialogue_presentation_dialogue_only.csv`만 유지합니다. 과거 `*_COMPAT.csv`, `*_AUDIT.csv`, R45~R48 중간 manifest는 배포본에서 제거했습니다.

## 선택 적용

CLI에서는 쉼표로 구성요소 키를 지정합니다.

```text
python ed2_all_in_one_patcher.py "C:\ED2" --components dialogue,text,monster_text --no-gui
```

특정 항목만 적용할 때도 패처의 최종 검증을 통과해야 합니다.

## 소유권이 중요한 항목

### M_504

`m504_restoration`은 로더 우회와 복원된 `M_504.DLL` 설치를 담당합니다. 다다르카·악토스의 수치 조정은 `balance`가 담당합니다. 따라서 기본 순서인 **복원 → 밸런스**를 유지합니다.

### M_501

최종전용 `M_501.DLL`은 일반 몬스터 DLL과 구조가 다르므로 `monster_text` 일반 일괄 처리 대상에서 제외합니다. 최종전 관련 처리는 `final_battle_presentation`에서 관리합니다.

### 오디오

BGM 소스는 `vgm_bgm`과 `original_bgm` 중 하나만 사용합니다. `original_bgm`은 순정 MUS/곡 매핑을 복원하되 BGM 제어·hard-stop 수정은 유지합니다. VGM BGM, 전사의 피리, 최종전 연출은 ED2MAIN의 서로 다른 hook 영역을 사용하며 한 구성요소의 편의를 위해 다른 구성요소 영역을 재사용하지 않습니다.
