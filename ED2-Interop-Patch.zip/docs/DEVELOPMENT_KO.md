# 개발 및 검증 원칙

이 문서는 버전별 변경 이력이 아니라, 저장소에서 계속 유지해야 하는 **현재 규칙**만 정리합니다.

## 기준 상태

- 현재 패치 정본: v1.4.45
- Text & Dialogue: v4.1R51
- AIO는 `ED2_All_In_One_Patcher_v1.4.45/baselines.json` 하나에서 순정/current/지원 이전 버전 baseline을 읽습니다.
- JSON은 실행에 실제로 필요한 설정·manifest만 저장소에 둡니다. 버전별 검증 결과, 과거 hash snapshot, 변환 리포트 JSON은 저장소 정본으로 유지하지 않습니다.

## SAVE 금지

SAVE 파일은 프로젝트의 패치 대상이 아닙니다.

- 읽지 않음
- 검색하지 않음
- 해시 계산하지 않음
- 백업/복원하지 않음
- 수정/migration하지 않음
- 배포 파일과 상태 판정에 포함하지 않음

## 대사 렌더링

한국 DOS판 대사 검수는 CP949 표시 바이트/셀 기준 **34셀**을 기본 폭으로 봅니다.

- `01h`: 명시적 줄바꿈
- `05h`: 페이지 전환/대기 계열 제어
- `FFh`: 일부 기존 패치 위치의 filler/no-op이지만 문맥 없이 전역 규칙으로 가정하지 않음
- 34셀에 도달하면 엔진 자동 wrap 가능

문자열 전체 길이가 아니라 **실제 표시행 단위**로 계산해야 합니다. 앞에 이미 `01h`/`05h`가 있으면 마지막 표시행 길이는 전체 문자열 길이와 다릅니다.

새 문장이 기존 슬롯을 넘을 때는 임의 축약보다 안전한 로컬 `0F` redirect 또는 검증된 segment 확장 방식을 우선 검토합니다. NE segment table, relocation, FAR/near callback 규약을 확인하지 않은 확장은 금지합니다.

## 번역 원칙

다음 요소를 동시에 만족시키는 방향으로 판단합니다.

1. PC-98 원문의 의미와 장면 기능
2. 자연스러운 한국어
3. 화자별 말투와 관계/높임말
4. 프로젝트에서 이미 확정한 용어
5. 34셀 표시 제약
6. 메시지 제어 코드와 페이지 흐름

원문의 줄 위치를 기계적으로 복제하거나, 모든 문장부호/호칭/개행을 일괄 변환하지 않습니다.

## 바이너리 이식

PC-98 코드/데이터를 한국 DOS NE 파일에 그대로 memcpy하지 않습니다. 특히 callback 호출 규약과 return address 크기가 다를 수 있으므로 다음을 확인합니다.

- segment ordinal/길이/min alloc
- relocation table
- export/import
- FAR/near 호출 규약
- 로컬 포인터/redirect 대상
- 기존 hook과의 겹침

## 특수 DLL

- `M_501`: 최종전 특수 구조. 일반 Monster Text 일괄 패치 금지.
- `M_504`: 복원 로직과 숫자 밸런스의 소유권을 분리. 복원 후 밸런스 순서 유지.

## 릴리스 검증

코드나 패치 데이터를 바꾼 릴리스는 최소 다음을 확인합니다.

1. previous CURRENT 또는 stock manifest에서 시작했는지
2. 예상한 파일만 변경됐는지
3. 직접 업그레이드와 신규 적용 결과가 정본 manifest에 수렴하는지
4. 즉시 재적용이 idempotent한지
5. 각 패처 `--check`/검증 경로가 통과하는지
6. Python compile 및 JSON parse 오류가 없는지
7. ZIP CRC, duplicate entry, cache 파일이 없는지
8. SAVE 관련 파일이 패키지에 없는지
9. 정적 검증과 실제 DOSBox/실기 검증을 구분했는지

문서만 정리한 경우에는 게임 payload를 다시 만들지 않고, **비문서 파일의 해시가 정리 전후 동일한지** 확인합니다.

## 저장소 문서 정책

버전별 CHANGELOG, 일회성 검증 보고서, 인수인계 문서, 임시 역공학 메모는 저장소 정본 문서로 유지하지 않습니다.

- 변경 이력: Git 커밋 / GitHub Releases
- 현재 사용법: `README.md`
- 구성요소: `docs/COMPONENTS_KO.md`
- 장기 유지 규칙: 이 문서

패처가 실제로 읽는 manifest/CSV/JSON만 유지합니다. 생성형 `*_REPORT.json`, `*.journal.json`, `*.rawopl.json`과 과거 버전 hash snapshot은 커밋하지 않습니다.
