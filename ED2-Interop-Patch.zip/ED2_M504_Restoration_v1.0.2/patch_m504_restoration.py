#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, struct
from pathlib import Path

APP='ED2 M_504 Restoration'
VERSION='1.0.2'
EXPECTED_EXE_SIZE=1848336
M504_SHA='aae4eaf70259956e99d905bbede5553513d5c06918ea23d9c7447f402a55ff3a'
M504_BALANCED_SHA='78987686c1bd0aa473e1fd931dfa8ac3a7fef685bf7109873977ba9f38fbae57'
M504_PREV={
 'd6417d26116a0780791891022e97377c45f8ef08f01c992d0c79e368bc3b6995',
 '523542677b108a737890bae4bbf2a3f764d46a475f96532979d2d41f6a86570c',
}

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def u16(b,o):return struct.unpack_from('<H',b,o)[0]
def u32(b,o):return struct.unpack_from('<I',b,o)[0]

def ne_segments(b:bytes):
    if len(b)!=EXPECTED_EXE_SIZE or b[:2]!=b'MZ': raise RuntimeError('지원하지 않는 ED2MAIN.EXE 크기/형식입니다.')
    ne=u32(b,0x3c)
    if b[ne:ne+2]!=b'NE': raise RuntimeError('NE 실행 파일이 아닙니다.')
    n=u16(b,ne+0x1c); st=ne+u16(b,ne+0x22); align=1<<u16(b,ne+0x32)
    out=[]
    for i in range(n):
        sector,length,flags,minalloc=struct.unpack_from('<HHHH',b,st+i*8)
        out.append((sector*align,length or 0x10000,flags,minalloc))
    return ne,st,out

def patch_loader(path:Path,check_only=False):
    before=path.read_bytes(); data=bytearray(before); ne,st,segs=ne_segments(before); s4=segs[3][0]
    off=s4+0x0cdb; cur=bytes(data[off:off+2])
    if cur==b'\xeb\x10': state='already'
    elif cur==b'\x75\x10':
        state='would_patch' if check_only else 'patched'; data[off]=0xeb
    else: raise RuntimeError(f'M_504 loader remap opcode 불일치 @0x{off:X}: {cur.hex()}')
    after=bytes(data)
    if ne_segments(after)!=(ne,st,segs): raise RuntimeError('M_504 loader 수정 중 NE 구조가 변경되었습니다.')
    if not check_only and after!=before:
        if os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP')!='1':
            bak=path.with_suffix(path.suffix+'.m504_restore.bak')
            if not bak.exists(): shutil.copy2(path,bak)
        path.write_bytes(after)
    return {'state':state,'offset':f'0x{off:X}','before_sha256':sha(before),'after_sha256':sha(after),'ne_structure_preserved':True}

def install_dll(root:Path,check_only=False):
    src=Path(__file__).with_name('M_504.DLL'); payload=src.read_bytes()
    if sha(payload)!=M504_SHA: raise RuntimeError('동봉 M_504.DLL SHA-256 불일치')
    target=root/'MON'/'M_504.DLL'
    if target.exists():
        old=sha(target.read_bytes())
        if old==M504_SHA:return {'state':'already','sha256':old,'size':target.stat().st_size}
        # Numeric balance is owned by the balance component. Do not erase it
        # when the restoration component is re-run after a full install.
        if old==M504_BALANCED_SHA:return {'state':'already_restored_balanced','sha256':old,'size':target.stat().st_size}
        if old not in M504_PREV: raise RuntimeError('알 수 없는 사용자 M_504.DLL이 존재하여 덮어쓰지 않습니다.')
        state='upgrade'
    else: state='missing'
    if not check_only:
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists() and os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP')!='1':
            bak=target.with_suffix('.DLL.m504_restore.bak')
            if not bak.exists(): shutil.copy2(target,bak)
        shutil.copy2(src,target)
    return {'state':('would_'+state) if check_only else state,'sha256':M504_SHA,'size':len(payload)}

def verify(root:Path):
    b=(root/'ED2MAIN.EXE').read_bytes(); _,_,segs=ne_segments(b); s4=segs[3][0]
    m=root/'MON'/'M_504.DLL'; digest=sha(m.read_bytes()) if m.is_file() else None
    checks={
      'loader_remap_bypassed': b[s4+0x0cdb:s4+0x0cdd]==b'\xeb\x10',
      'm504_restored_payload': digest in {M504_SHA,M504_BALANCED_SHA},
      'm504_numeric_balance_not_owned_here': True,
    }
    return checks,digest

def main():
    ap=argparse.ArgumentParser(description=f'{APP} v{VERSION}')
    ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    root=a.root.resolve()
    if not (root/'ED2MAIN.EXE').is_file() or not (root/'MON').is_dir(): raise SystemExit('게임 폴더를 지정하십시오.')
    if a.check:
        checks,digest=verify(root)
        print(json.dumps({'tool':APP,'version':VERSION,'mode':'check','checks':checks,'m504_sha256':digest,'ok':all(checks.values())},ensure_ascii=False,indent=2))
        return 0 if all(checks.values()) else 1
    loader=patch_loader(root/'ED2MAIN.EXE'); dll=install_dll(root); checks,digest=verify(root)
    print(json.dumps({'tool':APP,'version':VERSION,'mode':'apply','loader':loader,'dll':dll,'checks':checks,'m504_sha256':digest,'ok':all(checks.values())},ensure_ascii=False,indent=2))
    return 0 if all(checks.values()) else 1
if __name__=='__main__': raise SystemExit(main())
