#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
DATA=HERE/'data'
MANIFEST=DATA/'dialogue_targets.json'
SNAPSHOT=DATA/'dialogue_snapshot.zip'
CHAPTER=DATA/'chapter_overlay.zip'
VERSION='v4.1R51-consolidated'
class DialogueError(RuntimeError): pass
def sha_bytes(b: bytes)->str: return hashlib.sha256(b).hexdigest()
def sha_file(p: Path)->str: return sha_bytes(p.read_bytes())
def atomic_write(p: Path,b: bytes):
    tmp=p.with_name(p.name+'.dialogue.tmp'); tmp.write_bytes(b); os.replace(tmp,p)
def load_manifest(): return json.loads(MANIFEST.read_text(encoding='utf-8'))
def zip_map(path: Path):
    with zipfile.ZipFile(path) as z: return {n:z.read(n) for n in z.namelist() if not n.endswith('/')}
def desired_map(with_chapter: bool):
    m=load_manifest(); base=zip_map(SNAPSHOT); overlay=zip_map(CHAPTER) if with_chapter else {}
    rows={r['file']:r for r in m['base_files']}; ov={r['file']:r for r in m['chapter_overlay']}
    out={}
    for name,r in rows.items():
        b=overlay.get(name,base[name]); h=sha_bytes(b)
        expected=(ov[name]['sha256'] if name in overlay else r['dialogue_sha256'])
        if h!=expected: raise DialogueError(f'내장 스냅샷 해시 불일치: {name}')
        out[name]=(b,r['stock_sha256'],expected)
    return out
def apply_snapshot(root: Path, with_chapter: bool, check: bool, no_backup: bool):
    root=root.resolve(); scena=root/'SCENA'
    if not (root/'ED2MAIN.EXE').is_file() or not scena.is_dir(): raise DialogueError('영웅전설 II 게임 폴더를 찾지 못했습니다.')
    desired=desired_map(with_chapter); unknown=[]; changed=[]
    for name,(data,stock_h,want_h) in desired.items():
        p=scena/name
        if not p.is_file(): unknown.append((name,'missing')); continue
        cur=sha_file(p)
        allowed={stock_h,want_h}
        # The non-chapter snapshot is also accepted when switching to the chapter profile.
        if with_chapter:
            row=next(r for r in load_manifest()['base_files'] if r['file']==name); allowed.add(row['dialogue_sha256'])
        if cur not in allowed: unknown.append((name,cur))
    if unknown:
        sample=', '.join(f'{n}:{h[:12]}' for n,h in unknown[:8]); raise DialogueError('지원하지 않는 SCENA 상태가 있습니다: '+sample)
    if check:
        bad=[]
        for name,(_,_,want_h) in desired.items():
            h=sha_file(scena/name)
            if h!=want_h: bad.append(name)
        print(json.dumps({'version':VERSION,'mode':'check','profile':'dialogue+chapter' if with_chapter else 'dialogue','ok':not bad,'mismatches':bad},ensure_ascii=False))
        return 0 if not bad else 1
    backup_ok=not no_backup and os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP')!='1'
    backup=root/'ED2_DIALOGUE_BACKUP'
    if backup_ok: backup.mkdir(exist_ok=True)
    for name,(data,_,want_h) in desired.items():
        p=scena/name; cur=sha_file(p)
        if cur==want_h: continue
        if backup_ok:
            bp=backup/name
            if not bp.exists(): shutil.copy2(p,bp)
        atomic_write(p,data); changed.append(name)
    bad=[name for name,(_,_,want_h) in desired.items() if sha_file(scena/name)!=want_h]
    if bad: raise DialogueError('적용 후 해시 검증 실패: '+', '.join(bad[:8]))
    print(json.dumps({'version':VERSION,'profile':'dialogue+chapter' if with_chapter else 'dialogue','changed_files':len(changed),'files':changed},ensure_ascii=False))
    return 0
def run_internal(script: str, root: Path, args: list[str]):
    cmd=[sys.executable,str(HERE/'internal'/script),str(root),*args]
    cp=subprocess.run(cmd,text=True,capture_output=True)
    if cp.stdout: print(cp.stdout.rstrip())
    if cp.returncode:
        if cp.stderr: print(cp.stderr.rstrip(),file=sys.stderr)
        raise DialogueError(f'{script} 실행 실패 (exit {cp.returncode})')
def legacy_upgrade(root: Path):
    run_internal('legacy_context_upgrade.py',root,['--no-backup']); run_internal('flora_morgan_upgrade.py',root,['--no-backup']); return 0
def verify_runtime(root: Path):
    run_internal('legacy_context_upgrade.py',root,['--check']); run_internal('flora_morgan_upgrade.py',root,['--check'])
    # R49 C_101 rollback guard.
    raw=(root/'SCENA'/'C_101.DLL').read_bytes(); ok=('못하는 것도 무리는 아니지.'.encode('cp949') in raw and '못해도'.encode('cp949') not in raw)
    print(json.dumps({'version':VERSION,'mode':'runtime-check','c101_r49_rollback':ok,'ok':ok},ensure_ascii=False))
    return 0 if ok else 1
def repair_c734(root: Path):
    scene=HERE/'scene_editor'; source=DATA/'c734_dialogue.csv'
    sys.path.insert(0,str(scene)); from ed2_scene_editor import SceneProject
    p=SceneProject(root); changed=p.import_strings_csv(source,dialogues_only=False); validation=p.validate()
    report={'version':VERSION,'mode':'repair-c734','rows_changed':changed,'validation':validation}
    print(json.dumps(report,ensure_ascii=False)); return 0 if validation.get('ok',False) else 1
def main():
    ap=argparse.ArgumentParser(description='ED2 consolidated dialogue patch')
    ap.add_argument('game_root',type=Path); ap.add_argument('--with-chapter',action='store_true'); ap.add_argument('--check',action='store_true')
    ap.add_argument('--legacy-upgrade',action='store_true'); ap.add_argument('--verify-runtime',action='store_true'); ap.add_argument('--repair-c734',action='store_true'); ap.add_argument('--no-backup',action='store_true')
    a=ap.parse_args()
    try:
        if a.legacy_upgrade: return legacy_upgrade(a.game_root)
        if a.verify_runtime: return verify_runtime(a.game_root)
        if a.repair_c734: return repair_c734(a.game_root)
        return apply_snapshot(a.game_root,a.with_chapter,a.check,a.no_backup)
    except Exception as e:
        print('ERROR:',e,file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
