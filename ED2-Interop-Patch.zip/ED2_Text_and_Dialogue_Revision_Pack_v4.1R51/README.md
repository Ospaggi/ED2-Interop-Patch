# Text & Dialogue Patch

현재 대사 정본만 보관하는 통합 구성요소입니다.

- `apply_dialogue.py`: 공개 적용/검증 진입점
- `data/dialogue_snapshot.zip`: 순정 SCENA에서 현재 R51 대사 상태로 가는 최종 스냅샷
- `data/chapter_overlay.zip`: 장 제목 기능을 함께 사용할 때 필요한 4개 SCENA 최종 오버레이
- `data/dialogue_current.csv`: 현재 대사 정본 참고 CSV
- `scene_editor/`: SCENA 구조 검증 및 C_734 대사 복구에 필요한 공용 코드
- `text_patch/`: UI/텍스트 구성요소
- `internal/`: 이전 정식판 업그레이드와 회귀 검증에만 필요한 최소 내부 로직

R26~R50의 중간 스냅샷과 `apply_rXX_*.py` 증분 스크립트는 배포본에서 제거했습니다.
Git 이력이 과거 변경 이력을 대신합니다.
