@echo off
cd /d "%~dp0"
py -3 ed2_all_in_one_patcher.py
if errorlevel 1 python ed2_all_in_one_patcher.py
