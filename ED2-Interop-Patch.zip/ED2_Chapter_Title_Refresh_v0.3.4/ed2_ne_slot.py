#!/usr/bin/env python3
"""Safe 16-bit NE segment-tail allocator for Korean DOS ED2 DLL modules.

The allocator NEVER inserts bytes in the middle of a segment.  It consumes only
verified alignment padding after the segment's relocation table, moves that
relocation table forward as a byte-identical block, and increases the segment
length.  Existing segment-relative offsets therefore remain stable.
"""
from __future__ import annotations

from dataclasses import dataclass
import struct
from typing import Iterable

SAFE_PADDING = frozenset((0x00, 0x90, 0xCC, 0xFF))

class SlotExpansionError(RuntimeError):
    pass


def u16(data: bytes | bytearray, off: int) -> int:
    return struct.unpack_from('<H', data, off)[0]


def u32(data: bytes | bytearray, off: int) -> int:
    return struct.unpack_from('<I', data, off)[0]


@dataclass(frozen=True)
class NESegmentInfo:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int
    table_offset: int
    shift: int


@dataclass(frozen=True)
class TailLayout:
    segment: NESegmentInfo
    segment_end: int
    relocation_size: int
    next_segment_offset: int
    available_padding: int


@dataclass(frozen=True)
class TailAllocation:
    data: bytes
    segment_offsets: tuple[int, ...]
    file_offsets: tuple[int, ...]
    old_length: int
    new_length: int
    consumed_padding: int
    relocation_size: int


def parse_segments(data: bytes | bytearray) -> list[NESegmentInfo]:
    if len(data) < 0x40 or bytes(data[:2]) != b'MZ':
        raise SlotExpansionError('MZ 헤더가 없습니다')
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or bytes(data[ne:ne+2]) != b'NE':
        raise SlotExpansionError('16비트 NE 모듈이 아닙니다')
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    out: list[NESegmentInfo] = []
    for i in range(count):
        pos = table + i * 8
        sector, raw_length, flags, alloc = struct.unpack_from('<HHHH', data, pos)
        length = 0x10000 if raw_length == 0 else raw_length
        out.append(NESegmentInfo(i+1, sector << shift, length, flags, alloc, pos, shift))
    return out


def tail_layout(data: bytes | bytearray, segment_index: int) -> TailLayout:
    segments = parse_segments(data)
    if not 1 <= segment_index <= len(segments):
        raise SlotExpansionError(f'세그먼트 번호가 잘못되었습니다: {segment_index}')
    seg = segments[segment_index-1]
    if seg.length >= 0x10000:
        raise SlotExpansionError('64KiB 세그먼트는 더 확장할 수 없습니다')
    seg_end = seg.file_offset + seg.length
    if seg_end > len(data):
        raise SlotExpansionError('세그먼트가 파일 범위를 벗어납니다')
    reloc_size = 0
    if seg.flags & 0x0100:
        if seg_end + 2 > len(data):
            raise SlotExpansionError('재배치 테이블 카운트가 잘렸습니다')
        reloc_count = u16(data, seg_end)
        reloc_size = 2 + reloc_count * 8
        if seg_end + reloc_size > len(data):
            raise SlotExpansionError('재배치 테이블이 잘렸습니다')
    later = [item.file_offset for item in segments if item.file_offset > seg.file_offset]
    next_off = min(later) if later else len(data)
    available = next_off - (seg_end + reloc_size)
    if available < 0:
        raise SlotExpansionError('세그먼트/재배치 테이블이 다음 세그먼트와 겹칩니다')
    return TailLayout(seg, seg_end, reloc_size, next_off, available)


def allocate_tail(data: bytes | bytearray, segment_index: int, payloads: Iterable[bytes],
                  *, allowed_padding: frozenset[int] = SAFE_PADDING) -> TailAllocation:
    blobs = tuple(bytes(item) for item in payloads)
    if not blobs or any(not item for item in blobs):
        raise SlotExpansionError('빈 확장 payload는 허용하지 않습니다')
    total = sum(map(len, blobs))
    layout = tail_layout(data, segment_index)
    seg = layout.segment
    if seg.length + total >= 0x10000:
        raise SlotExpansionError('확장 후 세그먼트가 64KiB 한계를 넘습니다')
    if total > layout.available_padding:
        raise SlotExpansionError(
            f'세그먼트 {segment_index} 정렬 패딩 부족: 필요 {total}, 사용 가능 {layout.available_padding}'
        )
    pad_start = layout.segment_end + layout.relocation_size
    pad = bytes(data[pad_start:pad_start+total])
    if len(pad) != total or any(value not in allowed_padding for value in pad):
        raise SlotExpansionError('재배치 테이블 뒤 대상 영역이 안전한 정렬 패딩이 아닙니다')

    original_size = len(data)
    out = bytearray(data)
    reloc = bytes(out[layout.segment_end:layout.segment_end+layout.relocation_size])
    cursor = layout.segment_end
    seg_offsets: list[int] = []
    file_offsets: list[int] = []
    logical = seg.length
    for blob in blobs:
        seg_offsets.append(logical)
        file_offsets.append(seg.file_offset + logical)
        out[cursor:cursor+len(blob)] = blob
        cursor += len(blob)
        logical += len(blob)
    if layout.relocation_size:
        out[cursor:cursor+layout.relocation_size] = reloc

    new_length = seg.length + total
    raw_length = 0 if new_length == 0x10000 else new_length
    struct.pack_into('<H', out, seg.table_offset + 2, raw_length)
    # Keep minimum allocation coherent.  0 means 64KiB in NE and is left as-is.
    if seg.min_alloc and seg.min_alloc < new_length:
        struct.pack_into('<H', out, seg.table_offset + 6, new_length)
    if len(out) != original_size:
        raise SlotExpansionError('DLL 파일 크기가 변했습니다')

    # Strong postcondition checks.
    verify = tail_layout(out, segment_index)
    if verify.segment.length != new_length:
        raise SlotExpansionError('세그먼트 길이 갱신 검증 실패')
    if layout.relocation_size:
        moved = bytes(out[layout.segment_end+total:layout.segment_end+total+layout.relocation_size])
        if moved != reloc:
            raise SlotExpansionError('재배치 테이블 보존 검증 실패')
    return TailAllocation(bytes(out), tuple(seg_offsets), tuple(file_offsets), seg.length,
                          new_length, total, layout.relocation_size)



@dataclass(frozen=True)
class MessageSlotPatch:
    data: bytes
    changed: bool
    redirected: bool
    pointer: int | None
    encoded_length: int
    editable_length: int
    consumed_padding: int


def message_redirect_payload(encoded: bytes, return_offset: int) -> bytes:
    if not 0 <= return_offset <= 0xFFFF:
        raise SlotExpansionError('메시지 복귀 오프셋이 16비트 범위를 벗어났습니다')
    return bytes(encoded) + b"\x0F" + struct.pack('<H', return_offset)


def _cp949_split_boundaries(encoded: bytes, maximum: int) -> list[int]:
    """Return valid CP949 character boundaries <= maximum, largest first."""
    maximum = min(maximum, len(encoded))
    out: list[int] = []
    for pos in range(maximum, -1, -1):
        try:
            encoded[:pos].decode('cp949')
            encoded[pos:].decode('cp949')
        except UnicodeDecodeError:
            continue
        out.append(pos)
    return out


def message_redirect_stub(pointer: int, editable: int, prefix: bytes = b'', *, fill: int = 0xFF) -> bytes:
    """Build an in-slot prefix + 0F redirect stub.

    Keeping a CP949-safe prefix in the original slot minimizes tail padding use.
    """
    prefix = bytes(prefix)
    if editable < len(prefix) + 3:
        raise SlotExpansionError('0F 메시지 리다이렉트에 필요한 슬롯 여유가 없습니다')
    if not 0 <= pointer <= 0xFFFF:
        raise SlotExpansionError('메시지 확장 포인터가 16비트 범위를 벗어났습니다')
    if not 0 <= fill <= 0xFF:
        raise SlotExpansionError('fill 바이트가 잘못되었습니다')
    return prefix + b"\x0F" + struct.pack('<H', pointer) + bytes((fill,)) * (editable - len(prefix) - 3)


def _redirect_descriptor(raw_editable: bytes, encoded: bytes, fill: int = 0xFF):
    """Return (prefix_len, pointer) for a compatible split redirect stub."""
    for pos in _cp949_split_boundaries(encoded, max(0, len(raw_editable) - 3)):
        if raw_editable[:pos] != encoded[:pos]:
            continue
        if pos + 3 > len(raw_editable) or raw_editable[pos] != 0x0F:
            continue
        if raw_editable[pos+3:] != bytes((fill,)) * (len(raw_editable) - pos - 3):
            continue
        return pos, u16(raw_editable, pos + 1)
    return None


def message_redirect_matches(data: bytes | bytearray, segment_index: int, offset: int,
                             editable: int, encoded: bytes, suffix: bytes = b'',
                             *, fill: int = 0xFF) -> bool:
    """Return True when a verified ED2 message slot already points to this payload.

    Supports both the original full out-of-line redirect and the compact split
    form that keeps the longest CP949-safe prefix inside the original slot.
    """
    segments = parse_segments(data)
    if not 1 <= segment_index <= len(segments) or editable < 3:
        return False
    seg = segments[segment_index - 1]
    base = seg.file_offset
    total = editable + len(suffix)
    if offset < 0 or offset + total > seg.length:
        return False
    raw = bytes(data[base + offset:base + offset + total])
    if len(raw) != total or raw[editable:] != bytes(suffix):
        return False
    desc = _redirect_descriptor(raw[:editable], bytes(encoded), fill)
    if desc is None:
        return False
    prefix_len, pointer = desc
    payload = message_redirect_payload(bytes(encoded)[prefix_len:], offset + editable)
    if pointer + len(payload) > seg.length:
        return False
    return bytes(data[base + pointer:base + pointer + len(payload)]) == payload


def patch_message_slot_0f(data: bytes | bytearray, segment_index: int, offset: int,
                          editable: int, encoded: bytes, suffix: bytes = b'',
                          *, fill: int = 0xFF) -> MessageSlotPatch:
    """Patch one verified ED2 message slot, expanding out-of-line when necessary.

    When the replacement is too large, the longest CP949-safe prefix that leaves
    room for a 3-byte 0F command remains in the original slot. Only the overflow
    suffix plus a 3-byte return redirect is allocated at the segment tail. This
    sharply reduces padding consumption while preserving all existing offsets.
    """
    if not 0 <= fill <= 0xFF:
        raise SlotExpansionError('fill 바이트가 잘못되었습니다')
    segments = parse_segments(data)
    if not 1 <= segment_index <= len(segments):
        raise SlotExpansionError(f'세그먼트 번호가 잘못되었습니다: {segment_index}')
    seg = segments[segment_index - 1]
    total = editable + len(suffix)
    if editable <= 0 or offset < 0 or offset + total > seg.length:
        raise SlotExpansionError('메시지 슬롯 범위가 세그먼트를 벗어납니다')
    encoded = bytes(encoded); suffix = bytes(suffix)
    begin = seg.file_offset + offset
    current = bytes(data[begin:begin + total])

    if len(encoded) <= editable:
        replacement = encoded + bytes((fill,)) * (editable - len(encoded)) + suffix
        if current == replacement:
            return MessageSlotPatch(bytes(data), False, False, None, len(encoded), editable, 0)
        out = bytearray(data); out[begin:begin + total] = replacement
        return MessageSlotPatch(bytes(out), True, False, None, len(encoded), editable, 0)

    if editable < 3:
        raise SlotExpansionError('확장할 메시지 슬롯이 3바이트 미만입니다')
    if message_redirect_matches(data, segment_index, offset, editable, encoded, suffix, fill=fill):
        desc = _redirect_descriptor(current[:editable], encoded, fill)
        pointer = desc[1] if desc else None
        return MessageSlotPatch(bytes(data), False, True, pointer, len(encoded), editable, 0)

    layout = tail_layout(data, segment_index)
    # Prefer the longest in-place prefix, so the out-of-line payload is minimal.
    chosen_prefix = None
    for prefix_len in _cp949_split_boundaries(encoded, editable - 3):
        need = len(encoded) - prefix_len + 3
        if need > layout.available_padding:
            continue
        pad_start = layout.segment_end + layout.relocation_size
        pad = bytes(data[pad_start:pad_start+need])
        if len(pad) == need and all(value in SAFE_PADDING for value in pad):
            chosen_prefix = prefix_len
            break
    if chosen_prefix is None:
        min_need = min((len(encoded) - k + 3 for k in _cp949_split_boundaries(encoded, editable - 3)), default=len(encoded)+3)
        raise SlotExpansionError(
            f'세그먼트 {segment_index} 정렬 패딩 부족: 최소 필요 {min_need}, 사용 가능 {layout.available_padding}'
        )

    prefix = encoded[:chosen_prefix]
    overflow = encoded[chosen_prefix:]
    payload = message_redirect_payload(overflow, offset + editable)
    allocation = allocate_tail(data, segment_index, [payload])
    out = bytearray(allocation.data)
    seg2 = parse_segments(out)[segment_index - 1]
    pointer = allocation.segment_offsets[0]
    begin2 = seg2.file_offset + offset
    out[begin2:begin2 + total] = message_redirect_stub(pointer, editable, prefix, fill=fill) + suffix
    result = bytes(out)
    if not message_redirect_matches(result, segment_index, offset, editable, encoded, suffix, fill=fill):
        raise SlotExpansionError('0F 메시지 리다이렉트 적용 후 검증 실패')
    return MessageSlotPatch(result, True, True, pointer, len(encoded), editable, allocation.consumed_padding)

def inspect_capacity(data: bytes | bytearray) -> list[dict[str, int]]:
    rows = []
    for seg in parse_segments(data):
        layout = tail_layout(data, seg.index)
        pad_start = layout.segment_end + layout.relocation_size
        raw = bytes(data[pad_start:layout.next_segment_offset])
        safe = 0
        for value in raw:
            if value not in SAFE_PADDING:
                break
            safe += 1
        rows.append({
            'segment': seg.index,
            'file_offset': seg.file_offset,
            'length': seg.length,
            'flags': seg.flags,
            'min_alloc': seg.min_alloc,
            'relocation_size': layout.relocation_size,
            'tail_padding': layout.available_padding,
            'safe_tail_padding': safe,
        })
    return rows
