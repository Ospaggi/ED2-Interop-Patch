@echo off
setlocal
cd /d "%~dp0"
py -3 patch_soldiers_flute_bgm.py restore auto
if errorlevel 1 python patch_soldiers_flute_bgm.py restore auto
pause
