@echo off
setlocal
cd /d "%~dp0"
py -3 patch_soldiers_flute_bgm.py status auto
if errorlevel 1 python patch_soldiers_flute_bgm.py status auto
pause
