#!/usr/bin/env python3
"""Create an ending-only launcher for Korean DOS ED2.

The original ED2MAIN.EXE is not modified. A copy named ED2END.EXE is made,
and one NE relocation is redirected from the final normal-start display call
to the exported _THEEND routine. The normal executable initialization still
runs before the ending module is loaded.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import struct
import sys
from pathlib import Path

APP_NAME = "ED2 Direct Ending Launcher"
VERSION = "1.0.0"
SOURCE_NAME = "ED2MAIN.EXE"
OUTPUT_NAME = "ED2END.EXE"
BATCH_NAME = "ENDING.BAT"

EXPECTED_SIZE = 1_848_336
# Original Korean DOS ED2MAIN.EXE supplied for analysis.
EXPECTED_SHA256 = "9574c7e553ee4fd4d2fc5eea981a24ffe1fb0f1a22d14cf22b9d5b05b7b59ca5"

# NE relocation to patch:
#   source segment 86, source offset 2378h
#   original target 86:A8A1h (DISP_STATUS)
#   new target       05:0128h (_THEEND)
SOURCE_SEGMENT = 86
SOURCE_OFFSET = 0x2378
SOURCE_TYPE = 0x03        # 16:16 far pointer
RELOC_TYPE = 0x00         # internal reference
OLD_TARGET_SEGMENT = 86
OLD_TARGET_OFFSET = 0xA8A1
NEW_TARGET_SEGMENT = 5
NEW_TARGET_OFFSET = 0x0128


def u16(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_ne_segments(data: bytes | bytearray) -> tuple[int, list[tuple[int, int, int, int]]]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise ValueError("ED2MAIN.EXE is not an MZ executable.")
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise ValueError("ED2MAIN.EXE is not a Borland NE executable.")

    segment_count = u16(data, ne + 0x1C)
    segment_table = ne + u16(data, ne + 0x22)
    alignment = 1 << u16(data, ne + 0x32)
    segments: list[tuple[int, int, int, int]] = []

    if segment_table + segment_count * 8 > len(data):
        raise ValueError("Invalid NE segment table.")

    for index in range(segment_count):
        sector, length, flags, minimum = struct.unpack_from(
            "<HHHH", data, segment_table + index * 8
        )
        file_offset = sector * alignment
        file_length = length if length else 0x10000
        if file_offset + file_length > len(data):
            raise ValueError(f"Segment {index + 1} lies outside the executable.")
        segments.append((file_offset, file_length, flags, minimum))
    return ne, segments


def find_relocation(data: bytes | bytearray) -> tuple[int, tuple[int, int]]:
    _ne, segments = parse_ne_segments(data)
    if SOURCE_SEGMENT > len(segments):
        raise ValueError("This ED2MAIN.EXE has an incompatible segment layout.")

    file_offset, file_length, flags, _minimum = segments[SOURCE_SEGMENT - 1]
    if not (flags & 0x0100):
        raise ValueError("Expected relocation table is missing from segment 86.")

    pos = file_offset + file_length
    if pos + 2 > len(data):
        raise ValueError("Truncated relocation table.")
    count = u16(data, pos)
    pos += 2

    found: list[tuple[int, tuple[int, int]]] = []
    for _ in range(count):
        if pos + 8 > len(data):
            raise ValueError("Truncated relocation record.")
        source_type, reloc_type, source_offset = struct.unpack_from("<BBH", data, pos)
        target_segment = data[pos + 4]
        target_zero = data[pos + 5]
        target_offset = u16(data, pos + 6)

        if (
            source_type == SOURCE_TYPE
            and reloc_type == RELOC_TYPE
            and source_offset == SOURCE_OFFSET
        ):
            found.append((pos, (target_segment, target_offset)))
        pos += 8

    if len(found) != 1:
        raise ValueError(
            f"Expected exactly one ending-launch relocation, found {len(found)}."
        )
    record_offset, target = found[0]
    if data[record_offset + 5] != 0:
        raise ValueError("Unexpected internal relocation encoding.")
    return record_offset, target


def verify_theend_export(data: bytes | bytearray) -> None:
    ne, _segments = parse_ne_segments(data)
    entry_offset = ne + u16(data, ne + 0x04)
    entry_length = u16(data, ne + 0x06)
    end = entry_offset + entry_length
    ordinal = 1
    pos = entry_offset
    entry_6: tuple[int, int] | None = None

    while pos < end:
        count = data[pos]
        bundle_type = data[pos + 1]
        pos += 2
        if count == 0:
            break
        if bundle_type == 0:
            ordinal += count
            continue
        if bundle_type == 0xFF:
            for _ in range(count):
                if pos + 6 > end:
                    raise ValueError("Truncated movable entry bundle.")
                segment = data[pos + 3]
                offset = u16(data, pos + 4)
                if ordinal == 6:
                    entry_6 = (segment, offset)
                ordinal += 1
                pos += 6
        else:
            for _ in range(count):
                if pos + 3 > end:
                    raise ValueError("Truncated fixed entry bundle.")
                segment = bundle_type
                offset = u16(data, pos + 1)
                if ordinal == 6:
                    entry_6 = (segment, offset)
                ordinal += 1
                pos += 3

    if entry_6 != (NEW_TARGET_SEGMENT, NEW_TARGET_OFFSET):
        raise ValueError(
            "Export ordinal 6 is not the expected _THEEND entry at 05:0128h."
        )


def patch_executable(source: Path, output: Path) -> dict[str, object]:
    original = source.read_bytes()
    original_hash = sha256_bytes(original)
    if len(original) != EXPECTED_SIZE:
        raise ValueError(
            f"Unexpected ED2MAIN.EXE size: {len(original):,} bytes "
            f"(expected {EXPECTED_SIZE:,})."
        )

    verify_theend_export(original)
    record_offset, current_target = find_relocation(original)
    if current_target == (NEW_TARGET_SEGMENT, NEW_TARGET_OFFSET):
        patched = original
        status = "already_patched"
    elif current_target == (OLD_TARGET_SEGMENT, OLD_TARGET_OFFSET):
        patched_data = bytearray(original)
        patched_data[record_offset + 4] = NEW_TARGET_SEGMENT
        patched_data[record_offset + 5] = 0
        struct.pack_into("<H", patched_data, record_offset + 6, NEW_TARGET_OFFSET)
        patched = bytes(patched_data)
        status = "patched"
    else:
        raise ValueError(
            "The ending-launch relocation has an unexpected target: "
            f"{current_target[0]:02X}:{current_target[1]:04X}."
        )

    # Reparse and verify the exact new target.
    new_record_offset, new_target = find_relocation(patched)
    if new_record_offset != record_offset or new_target != (
        NEW_TARGET_SEGMENT,
        NEW_TARGET_OFFSET,
    ):
        raise AssertionError("Patched relocation verification failed.")

    changed = [i for i, (a, b) in enumerate(zip(original, patched)) if a != b]
    if status == "patched" and changed != [record_offset + 4, record_offset + 6, record_offset + 7]:
        raise AssertionError(f"Unexpected changed byte offsets: {changed}")

    output.write_bytes(patched)
    return {
        "tool": APP_NAME,
        "version": VERSION,
        "status": status,
        "source": str(source),
        "output": str(output),
        "source_size": len(original),
        "source_sha256": original_hash,
        "known_source_sha256_match": original_hash == EXPECTED_SHA256,
        "output_sha256": sha256_bytes(patched),
        "relocation_record_file_offset": record_offset,
        "old_target": f"{current_target[0]:02X}:{current_target[1]:04X}",
        "new_target": f"{NEW_TARGET_SEGMENT:02X}:{NEW_TARGET_OFFSET:04X}",
        "changed_file_offsets": [f"0x{i:X}" for i in changed],
    }


def write_batch(folder: Path) -> Path:
    batch = folder / BATCH_NAME
    batch.write_text(
        "@echo off\r\n"
        "if not exist ED2END.EXE goto missing\r\n"
        "if not exist GKEY.EXE goto missing\r\n"
        "GKEY.EXE -s ED2END.EXE\r\n"
        "goto end\r\n"
        ":missing\r\n"
        "echo ED2END.EXE or GKEY.EXE was not found.\r\n"
        ":end\r\n",
        encoding="ascii",
        newline="",
    )
    return batch


def install(folder: Path) -> dict[str, object]:
    folder = folder.resolve()
    source = folder / SOURCE_NAME
    if not source.is_file():
        raise FileNotFoundError(f"{SOURCE_NAME} was not found in {folder}")
    for required in ("ENDING.DLL", "STAFF.DLL", "GKEY.EXE", "RTM.EXE", "DPMI16BI.OVL"):
        if not (folder / required).is_file():
            raise FileNotFoundError(f"Required file is missing: {required}")

    output = folder / OUTPUT_NAME
    report = patch_executable(source, output)
    batch = write_batch(folder)
    report["batch"] = str(batch)
    report_path = folder / "ED2END_PATCH.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def choose_folder_gui() -> Path | None:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None
    root = tk.Tk()
    root.withdraw()
    selected = filedialog.askdirectory(title="Select the ED2 game folder")
    root.destroy()
    return Path(selected) if selected else None


def main(argv: list[str]) -> int:
    try:
        if len(argv) >= 2:
            folder = Path(argv[1])
        else:
            folder = choose_folder_gui() or Path.cwd()
        report = install(folder)
        print(f"{APP_NAME} v{VERSION}")
        print(f"Created: {report['output']}")
        print(f"Created: {report['batch']}")
        print("Run ENDING.BAT inside DOSBox to start the ending directly.")
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        try:
            input("Press Enter to close...")
        except EOFError:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
