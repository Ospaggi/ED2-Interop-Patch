# ED2 Symbol Encounter Density v0.1.0

영웅전설 II 한국 DOS판의 **일반 심볼 인카운트 밀도만 조금 낮추는 독립형 실험 패치**입니다.

**v1.4.49부터 All-In-One 패치의 선택 구성요소로 포함됩니다.** 독립형으로도 그대로 사용할 수 있습니다.

## v0.1.0 조정 범위

### 월드맵 F 계열
- `F_000.DLL`, `F_200.DLL`의 일반 필드 심볼 초기 생성 목표를 조정합니다.
- 근거리 계산식의 기준값: `10 -> 9`
- 원거리 고정값: `3 -> 2`
- 결과적으로 지역 진입 시 일반적으로 **심볼 약 1개가 덜 생성**되도록 합니다.

### 던전 G 계열
일반 생성형 던전 21개만 조정합니다.

- 보통 던전: `5 -> 4`
- `G_200`: `6 -> 5`
- `G_220`: `9 -> 7`
- 전체 기준: **110개 -> 88개**, 정확히 **20.0% 감소**

## 의도적으로 건드리지 않는 것

- `C_*.DLL`, `D_*.DLL`, `T_*.DLL`의 스토리/이벤트 장면
- 보스/중간보스 고정 심볼
- NPC 및 이벤트 캐릭터
- 몬스터 편성 자체, 능력치, EXP/Gold, 드롭
- 기존 SAVE

C/D/T 계열에는 일반 몬스터와 이벤트/NPC가 함께 관리되는 경우가 있어 v0.1.0에서는 안전을 위해 제외했습니다. 실제 플레이 후 특정 지역만 여전히 과밀하다고 확인되면 다음 버전에서 해당 장면을 개별 분석하는 방식이 적절합니다.

## 사용법

게임 폴더는 `ED2MAIN.EXE`와 `SCENA` 폴더가 있는 루트입니다.

### 전체 적용
```bat
python ed2_symbol_encounter_density.py "C:\Games\ED2"
```

또는 Windows에서:
```bat
apply_symbol_density.bat "C:\Games\ED2"
```

### 현재 상태만 검사
```bat
python ed2_symbol_encounter_density.py "C:\Games\ED2" --check
```

### 월드맵만
```bat
python ed2_symbol_encounter_density.py "C:\Games\ED2" --scope world
```

### 던전만
```bat
python ed2_symbol_encounter_density.py "C:\Games\ED2" --scope dungeon
```

### 원래 밀도로 복원
```bat
python ed2_symbol_encounter_density.py "C:\Games\ED2" --restore
```

## 백업
기본 적용 시 수정 전 파일은 게임 폴더의 다음 위치에 최초 1회 백업됩니다.

`ED2_SYMBOL_DENSITY_BACKUP\SCENA\...`

`--no-backup`을 주면 백업을 생략합니다.

## 호환성 / 검증

정적·바이너리 검증 기준:

- 한국 DOS 순정 STOCK manifest 1,041파일 기준: PASS
- ED2 Interop Patch Pack v1.4.48 전체 적용 상태 기준: PASS
- 두 기준 모두 적용 대상: **23개 SCENA DLL**
- 실제 수정량: **25바이트**
- 파일 크기 변경: 없음
- 즉시 재적용: 변경 0개
- `--restore` 후 순정 대상 바이트 복원: PASS

G 계열은 파일 SHA에 의존하지 않고 NE relocation에서 `ED2MAIN!MO_NUM` 초기화 지점을 구조적으로 찾습니다. 따라서 v1.4.48의 지하미로 변경으로 G DLL 해시가 달라져도 동일한 심볼 수 지점을 검증 후 수정합니다.

## 런타임 상태

**DOSBox/실기 플레이 검증은 아직 하지 않았습니다.**

특히 확인하면 좋은 점은 다음과 같습니다.

1. 월드맵에서 체감상 심볼이 너무 적어지지는 않는지
2. G 계열 던전에서 이동/전투/재생성이 정상인지
3. 전투 후 심볼 수가 비정상적으로 늘어나거나 사라지지 않는지
4. 특정 장/지역에서 여전히 심볼이 지나치게 많은지

v0.1.0은 의도적으로 보수적인 약 20% 감소안입니다.
