@echo off
setlocal
if "%~1"=="" (
  echo Usage: restore_symbol_density.bat ^<ED2 game folder^>
  echo Example: restore_symbol_density.bat "C:\Games\ED2"
  exit /b 2
)
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0ed2_symbol_encounter_density.py" "%~1" --restore
) else (
  python "%~dp0ed2_symbol_encounter_density.py" "%~1" --restore
)
exit /b %errorlevel%
