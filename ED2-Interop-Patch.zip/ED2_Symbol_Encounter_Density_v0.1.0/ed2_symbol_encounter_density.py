#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ED2 Korean DOS - roaming symbol encounter density patch.

v0.1.0 deliberately touches only the two audited generic spawn systems:
  * F_000/F_200 overworld roaming-symbol initial population formula
  * G_200..G_274 dungeon roaming-symbol MO_NUM limits

Story/scripted C/D/T scene actor counts are not modified.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

VERSION = "0.1.0"
MO_NUM_ORDINAL = 726

# original roaming monsters (MO_NUM includes the player, hence +1 in the DLL)
DUNGEON_MONSTERS = {
    "G_200.DLL": (6, 5),
    "G_202.DLL": (5, 4),
    "G_204.DLL": (5, 4),
    "G_210.DLL": (5, 4),
    "G_212.DLL": (5, 4),
    "G_214.DLL": (5, 4),
    "G_220.DLL": (9, 7),
    "G_222.DLL": (5, 4),
    "G_224.DLL": (5, 4),
    "G_230.DLL": (5, 4),
    "G_232.DLL": (5, 4),
    "G_240.DLL": (5, 4),
    "G_242.DLL": (5, 4),
    "G_244.DLL": (5, 4),
    "G_250.DLL": (5, 4),
    "G_252.DLL": (5, 4),
    "G_254.DLL": (5, 4),
    "G_262.DLL": (5, 4),
    "G_264.DLL": (5, 4),
    "G_272.DLL": (5, 4),
    "G_274.DLL": (5, 4),
}
WORLD_FILES = ("F_000.DLL", "F_200.DLL")
# For distance bucket < 80: AL = base - tens(distance). For >= 80: AL = far.
# The init routine spawns AL - 1 symbols. v0.1.0 lowers both by exactly one.
WORLD_ORIGINAL = (10, 3)
WORLD_MILD = (9, 2)

class PatchError(RuntimeError):
    pass


def u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]

@dataclass(frozen=True)
class Segment:
    index: int
    file_offset: int
    length: int
    flags: int

@dataclass(frozen=True)
class Reloc:
    segment: int
    source_offset: int
    module: str
    ordinal: Optional[int]


def parse_segments(data: bytes) -> list[Segment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("MZ 실행 파일이 아닙니다.")
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or data[ne:ne+2] != b"NE":
        raise PatchError("16-bit NE 모듈이 아닙니다.")
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    out: list[Segment] = []
    for i in range(count):
        sector, length, flags, _alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        out.append(Segment(i + 1, sector << shift, 65536 if length == 0 else length, flags))
    return out


def import_tables(data: bytes) -> tuple[list[str], int]:
    ne = u32(data, 0x3C)
    names_base = ne + u16(data, ne + 0x2A)
    refs = ne + u16(data, ne + 0x28)
    count = u16(data, ne + 0x1E)
    modules: list[str] = []
    for i in range(count):
        off = u16(data, refs + i * 2)
        pos = names_base + off
        n = data[pos]
        modules.append(data[pos+1:pos+1+n].decode("latin1"))
    return modules, names_base


def parse_relocs(data: bytes) -> list[Reloc]:
    modules, _names_base = import_tables(data)
    out: list[Reloc] = []
    for seg in parse_segments(data):
        if not (seg.flags & 0x0100):
            continue
        pos = seg.file_offset + seg.length
        if pos + 2 > len(data):
            raise PatchError(f"segment {seg.index} relocation table truncated")
        count = u16(data, pos)
        pos += 2
        for _ in range(count):
            if pos + 8 > len(data):
                raise PatchError(f"segment {seg.index} relocation record truncated")
            _source_type, flags, source, target1, target2 = struct.unpack_from("<BBHHH", data, pos)
            pos += 8
            kind = flags & 3
            module = modules[target1 - 1] if 0 < target1 <= len(modules) else f"module#{target1}"
            ordinal = target2 if kind == 1 else None
            out.append(Reloc(seg.index, source, module, ordinal))
    return out


def seg3(data: bytes) -> Segment:
    segs = parse_segments(data)
    if len(segs) < 3:
        raise PatchError("segment 3이 없습니다.")
    return segs[2]


def find_dungeon_count_site(data: bytes, name: str) -> tuple[int, int]:
    s3 = seg3(data)
    block = data[s3.file_offset:s3.file_offset+s3.length]
    candidates: list[int] = []
    for r in parse_relocs(data):
        if r.segment != 3 or r.module.upper() != "ED2MAIN" or r.ordinal != MO_NUM_ORDINAL:
            continue
        o = r.source_offset
        if o >= 2 and o + 2 < len(block) and block[o-2:o] == b"\xC6\x06":
            candidates.append(o)
    if len(candidates) != 1:
        raise PatchError(f"{name}: MO_NUM 초기화 지점을 하나로 확정할 수 없습니다: {candidates}")
    reloc_source = candidates[0]
    imm_file = s3.file_offset + reloc_source + 2
    return imm_file, data[imm_file]


def find_world_sites(data: bytes, name: str) -> tuple[int, int, int, int]:
    s3 = seg3(data)
    block = data[s3.file_offset:s3.file_offset+s3.length]
    # near-field formula: 8A C3 / AAM 10 / MOV AL,base / SUB AL,AH
    prefix = bytes.fromhex("8A C3 D4 0A B0")
    suffix = bytes.fromhex("2A C4")
    formula = [i for i in range(0, len(block)-8) if block[i:i+5] == prefix and block[i+6:i+8] == suffix]
    # far-field fixed branch: CMP BX,50 / MOV AL,far
    far_sig = bytes.fromhex("83 FB 50 B0")
    far = [i for i in range(0, len(block)-5) if block[i:i+4] == far_sig]
    if len(formula) != 1 or len(far) != 1:
        raise PatchError(f"{name}: 월드 심볼 수식 지점을 확정할 수 없습니다: formula={formula}, far={far}")
    formula_file = s3.file_offset + formula[0] + 5
    far_file = s3.file_offset + far[0] + 4
    return formula_file, data[formula_file], far_file, data[far_file]


def atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_name(path.name + ".symbol-density.tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def backup_file(game: Path, path: Path) -> None:
    rel = path.relative_to(game)
    dst = game / "ED2_SYMBOL_DENSITY_BACKUP" / rel
    if dst.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)


def desired_world(restore: bool) -> tuple[int, int]:
    return WORLD_ORIGINAL if restore else WORLD_MILD


def desired_dungeon(name: str, restore: bool) -> int:
    original, mild = DUNGEON_MONSTERS[name]
    monsters = original if restore else mild
    return monsters + 1  # MO_NUM includes player record


def inspect(game: Path, scope: str, restore: bool) -> tuple[list[dict], list[str]]:
    if not (game / "ED2MAIN.EXE").is_file():
        raise PatchError(f"ED2MAIN.EXE가 없습니다. 게임 루트 폴더를 지정하십시오: {game}")
    scene = game / "SCENA"
    if not scene.is_dir():
        raise PatchError(f"SCENA 폴더가 없습니다: {scene}")
    rows: list[dict] = []
    errors: list[str] = []
    if scope in ("all", "world"):
        want_base, want_far = desired_world(restore)
        for name in WORLD_FILES:
            path = scene / name
            if not path.is_file():
                errors.append(f"{name}: 파일 없음")
                continue
            try:
                data = path.read_bytes()
                base_at, base, far_at, far = find_world_sites(data, name)
                known = base in WORLD_ORIGINAL + WORLD_MILD and far in WORLD_ORIGINAL + WORLD_MILD
                # Pair validation is stricter than independent-value validation.
                pair_known = (base, far) in (WORLD_ORIGINAL, WORLD_MILD)
                rows.append({
                    "file": name, "kind": "world", "base_offset": base_at, "far_offset": far_at,
                    "current": [base, far], "desired": [want_base, want_far],
                    "state": "desired" if (base, far) == (want_base, want_far) else ("known-other" if pair_known else "unknown"),
                })
                if not known or not pair_known:
                    errors.append(f"{name}: 알 수 없는 월드 수식 값 base={base}, far={far}")
            except Exception as e:
                errors.append(f"{name}: {e}")
    if scope in ("all", "dungeon"):
        for name, (original, mild) in DUNGEON_MONSTERS.items():
            path = scene / name
            if not path.is_file():
                errors.append(f"{name}: 파일 없음")
                continue
            try:
                data = path.read_bytes()
                at, mo = find_dungeon_count_site(data, name)
                current_monsters = mo - 1
                desired_mo = desired_dungeon(name, restore)
                state = "desired" if mo == desired_mo else ("known-other" if current_monsters in (original, mild) else "unknown")
                rows.append({
                    "file": name, "kind": "dungeon", "offset": at,
                    "original_monsters": original, "mild_monsters": mild,
                    "current_monsters": current_monsters, "desired_monsters": desired_mo - 1,
                    "state": state,
                })
                if current_monsters not in (original, mild):
                    errors.append(f"{name}: 알 수 없는 MO_NUM={mo} (몬스터 {current_monsters})")
            except Exception as e:
                errors.append(f"{name}: {e}")
    return rows, errors


def apply(game: Path, scope: str, restore: bool, no_backup: bool, check_only: bool) -> dict:
    rows, errors = inspect(game, scope, restore)
    if errors:
        raise PatchError("\n".join(errors))
    changed: list[str] = []
    if not check_only:
        for row in rows:
            if row["state"] == "desired":
                continue
            path = game / "SCENA" / row["file"]
            data = bytearray(path.read_bytes())
            if not no_backup:
                backup_file(game, path)
            if row["kind"] == "world":
                base, far = desired_world(restore)
                data[row["base_offset"]] = base
                data[row["far_offset"]] = far
            else:
                data[row["offset"]] = desired_dungeon(row["file"], restore)
            atomic_write(path, bytes(data))
            changed.append(row["file"])
        # exact postcondition
        post, post_errors = inspect(game, scope, restore)
        if post_errors or any(r["state"] != "desired" for r in post):
            raise PatchError("적용 후 검증 실패: " + "; ".join(post_errors + [r["file"] for r in post if r["state"] != "desired"]))
        rows = post
    original_total = sum(v[0] for v in DUNGEON_MONSTERS.values()) if scope in ("all", "dungeon") else 0
    mild_total = sum(v[1] for v in DUNGEON_MONSTERS.values()) if scope in ("all", "dungeon") else 0
    return {
        "tool": f"ED2 Symbol Encounter Density v{VERSION}",
        "mode": "check" if check_only else ("restore" if restore else "apply"),
        "scope": scope,
        "changed_files": len(changed),
        "changed": changed,
        "world_formula": {
            "original": {"near_base": WORLD_ORIGINAL[0], "far": WORLD_ORIGINAL[1]},
            "mild": {"near_base": WORLD_MILD[0], "far": WORLD_MILD[1]},
            "note": "initial roaming-symbol target is lowered by about one on F_000/F_200",
        } if scope in ("all", "world") else None,
        "dungeon": {
            "scene_files": len(DUNGEON_MONSTERS),
            "original_symbols_total": original_total,
            "mild_symbols_total": mild_total,
            "reduction_percent": round((1 - mild_total / original_total) * 100, 1) if original_total else 0,
        } if scope in ("all", "dungeon") else None,
        "rows": rows,
        "runtime_tested": False,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="영웅전설 II 한국 DOS판 일반 심볼 인카운트 밀도 조정 v0.1.0")
    ap.add_argument("game_dir", type=Path, help="ED2MAIN.EXE와 SCENA 폴더가 있는 게임 폴더")
    ap.add_argument("--scope", choices=("all", "world", "dungeon"), default="all", help="기본값: all")
    ap.add_argument("--check", action="store_true", help="수정 없이 현재 상태만 검증")
    ap.add_argument("--restore", action="store_true", help="이 패치가 조정하는 심볼 수를 원래 값으로 복원")
    ap.add_argument("--no-backup", action="store_true", help="ED2_SYMBOL_DENSITY_BACKUP 백업을 만들지 않음")
    ap.add_argument("--json", action="store_true", help="결과를 JSON으로 출력")
    args = ap.parse_args()
    game = args.game_dir.resolve()
    try:
        result = apply(game, args.scope, args.restore, args.no_backup, args.check)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        mode = result["mode"]
        print(f"ED2 Symbol Encounter Density v{VERSION} - {mode}")
        print(f"scope: {result['scope']}")
        print(f"changed_files: {result['changed_files']}")
        if result.get("dungeon"):
            d = result["dungeon"]
            print(f"dungeon roaming symbols: {d['original_symbols_total']} -> {d['mild_symbols_total']} ({d['reduction_percent']}% reduction)")
        if result.get("world_formula"):
            print("world roaming symbols: F_000/F_200 initial target reduced by about one")
        print("runtime_tested: false")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
