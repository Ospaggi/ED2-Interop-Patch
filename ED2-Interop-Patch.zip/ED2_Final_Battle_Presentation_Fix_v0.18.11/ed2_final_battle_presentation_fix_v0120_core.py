#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json
from pathlib import Path

APP_NAME='ED2 Final Battle Presentation Fix'
VERSION='0.12.0'
CORE_FILE=Path(__file__).with_name('ed2_final_battle_presentation_fix_v0110_core.py')
if not CORE_FILE.is_file():
    alt=Path('/mnt/data/ed2_final_battle_presentation_fix_v0110.py')
    CORE_FILE=alt if alt.is_file() else CORE_FILE
_spec=importlib.util.spec_from_file_location('ed2_fb_v0110_core',CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError('v0.11.0 compatibility core could not be loaded')
v110=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(v110)
core=v110.core; PatchError=v110.PatchError; sha256=v110.sha256; atomic_write=v110.atomic_write

C734_SEGMENT=3
SEG_LEN=v110.SEG_LEN
RELOC_COUNT=v110.RELOC_COUNT
PRE_HELPER=v110.PRE_HELPER
PRE_HELPER_END=v110.PRE_HELPER_END
FINAL_START=v110.FINAL_START
FINAL_END=v110.FINAL_END
POST_HELPER=v110.POST_HELPER
POST_HELPER_END=v110.POST_HELPER_END

# Critical correction:
# C_734's final-boss record is a special/large record with byte0 == 04h.
# ED2MAIN CLR_MON_STS (ordinal 887) tests bit 04h BEFORE bit 80h and enters its
# special cleanup path only while 04h is still present.  v0.10/v0.11 changed
# byte0 to 80h before cleanup, which bypassed that special path and left both
# the large Godwin image/status residue and the 0HP display visible.
#
# Keep the 20-tick white hold, but DO NOT mutate EN_DATA_1 before the original
# five cleanup calls.  This is the first released combination that matches the
# old working v1.0.63 cleanup semantics while also keeping the later 20-tick
# white hold, 180-tick defeat-message hold, field-scene repair and black fade.
C734_V073_PRE_HELPER=(
    b'\x9A\xFF\xFF\x00\x00' +  # CALL FAR ABS_DELAY (AL=20)
    b'\xCB' +                       # RETF, record remains 04h
    b'\x90'*5
)
assert len(C734_V073_PRE_HELPER)==11

# Main controller is deliberately byte-identical to v1.0.72: it sets DI to
# EN_DATA_1, waits 20 ticks through PRE_HELPER, then performs the original five
# cleanup calls contiguously, restores palette, displays the defeat message,
# waits 180 ticks and enters the true-black fade.
C734_V073_FINAL=v110.C734_V072_FINAL
C734_V073_POST_HELPER=v110.C734_V072_POST_HELPER


def inspect_c734_v073(data:bytes)->dict:
    try:
        # Normalize structural checks through v1.0.72 inspector, but ignore its
        # obsolete exact-byte expectation for PRE_HELPER.
        _,_,segs=core.ne_info(data); seg=segs[2]; base=seg['off']; rows=core.relocation_records(data,seg)
        next_off=core.next_segment_offset(segs,seg); reloc_end=base+seg['len']+2+len(rows)*8
        structure=seg['len']==SEG_LEN and seg['alloc']==SEG_LEN and len(rows)==RELOC_COUNT and reloc_end<=next_off
        reveal_ok=core._reveal_state(data,seg)[1]; timing_ok=core._timing_state(data,seg)[1]
        wrapper_ok=core._c734_wrapper_state(data,seg)[0]
        algo_ok=bytes(data[base+v110.v100.v090.v080.v070.v060.C734_ALGO09_CALL:base+v110.v100.v090.v080.v070.v060.C734_ALGO09_CALL+3])==v110.v100.v090.v080.v070.v060.C734_ALGO09_CALL_V067
        pre_ok=bytes(data[base+PRE_HELPER:base+PRE_HELPER_END])==C734_V073_PRE_HELPER
        final_ok=bytes(data[base+FINAL_START:base+FINAL_END])==C734_V073_FINAL
        dummy_ok=bytes(data[base+v110.DUMMY_HELPER1:base+v110.DUMMY_HELPER1_END])==v110.C734_V072_DUMMY1
        post_ok=bytes(data[base+POST_HELPER:base+POST_HELPER_END])==C734_V073_POST_HELPER
        zero_target=bytes(data[base+0x057E:base+0x059C])==b'\0'*30
        reloc_ok=all(core.reloc_matches(data,seg,src,*exp) for src,exp in v110.EXPECTED_RELOCS.items())
        sources=[r[3] for r in rows]
        unique=len(sources)==len(set(sources)); retired=not any(s in v110.RETIRED_SOURCES for s in sources)
        patched=bool(structure and reveal_ok and timing_ok and wrapper_ok and algo_ok and pre_ok and final_ok and dummy_ok and post_ok and zero_target and reloc_ok and unique and retired)
        return {
            'supported':patched,'patched':patched,
            'field_scene_open_wind_reveal':reveal_ok,'field_scene_fixed_256_frames':timing_ok,
            'white_screen_hold_ticks':20 if pre_ok and final_ok else None,
            'godwin_record_preserved_as_special_during_cleanup':pre_ok,
            'godwin_record_forced_0x80_before_cleanup':False if pre_ok else None,
            'original_five_cleanup_calls_contiguous':final_ok,
            'cleanup_order':'CLR_MON -> CLR_MON_STS -> NEG_DSP_BANK -> CLR_MON -> CLR_MON_STS' if final_ok else None,
            'palette_restore_after_cleanup':'ST_SIN_PAL' if final_ok else None,
            'defeat_message_hold_ticks':180 if post_ok else None,
            'true_black_fade_after_message_hold':final_ok and post_ok and zero_target,
            'segment_length':seg['len'],'segment_minalloc':seg['alloc'],'relocation_count':len(rows),
            'relocation_table_end':reloc_end,'next_segment_offset':next_off,'relocation_slack_bytes':next_off-reloc_end,
            'relocations_ok':reloc_ok and unique and retired,'sha256':sha256(data)
        }
    except Exception:
        return {'supported':False,'patched':False,'sha256':sha256(data)}


def patch_c734_v073(before:bytes)->bytes:
    if inspect_c734_v073(before).get('patched'):
        return before
    # Normalize every previously supported state through v1.0.72 first.  Then
    # change only the erroneous record-deactivation portion of PRE_HELPER.
    base_bytes=v110.patch_c734_v072(before)
    if not v110.inspect_c734_v072(base_bytes).get('patched'):
        raise PatchError('C_734 could not normalize to v1.0.72')
    d=bytearray(base_bytes); _,_,segs=core.ne_info(d); seg=segs[2]; base=seg['off']
    d[base+PRE_HELPER:base+PRE_HELPER_END]=C734_V073_PRE_HELPER
    out=bytes(d)
    st=inspect_c734_v073(out)
    if not st.get('patched'):
        raise PatchError(f'post-patch verification failed: {st}')
    return out


def validate_root(root:Path)->Path: return v110.validate_root(root)
def repair_ed2main(root:Path,make_backup=True): return v110.repair_ed2main(root,make_backup)
def inspect_patch(root:Path):
    root=validate_root(root)
    e=core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes())
    m=core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes())
    c=inspect_c734_v073((root/'SCENA/C_734.DLL').read_bytes())
    return {
        'tool_version':VERSION,'ed2main':e,'m501':m,'c734':c,
        'ed2main_stable_no_new_patch':e['stable'],'m501_wrong_experiment_removed':m['original'],
        'godwin_special_flag_preserved_until_cleanup':c.get('godwin_record_preserved_as_special_during_cleanup',False),
        'white_screen_hold_20_ticks':c.get('white_screen_hold_ticks')==20,
        'defeat_message_hold_180_then_true_black_fade':c.get('defeat_message_hold_ticks')==180 and c.get('true_black_fade_after_message_hold',False),
        'ok':bool(e['stable'] and m['original'] and c.get('patched'))
    }
def apply_patch(root:Path,make_backup=True):
    root=validate_root(root); er=repair_ed2main(root,make_backup)
    mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
    if ma!=mb: atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734_v073(cb)
    if ca!=cb: atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st=inspect_patch(root)
    if not st['ok']: raise PatchError('Final verification failed')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}
def main():
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}'); ap.add_argument('root',type=Path)
    g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true')
    ap.add_argument('--no-backup',action='store_true'); a=ap.parse_args()
    try:
        r=repair_ed2main(a.root,not a.no_backup) if a.repair_ed2main_only else inspect_patch(a.root) if a.check else apply_patch(a.root,not a.no_backup)
        print(json.dumps(r,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as e:
        print('ERROR:',e); return 1
if __name__=='__main__': raise SystemExit(main())
