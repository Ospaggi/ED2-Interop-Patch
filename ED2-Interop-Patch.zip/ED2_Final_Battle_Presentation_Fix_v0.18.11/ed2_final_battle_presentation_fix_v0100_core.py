#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, struct
from pathlib import Path

APP_NAME='ED2 Final Battle Presentation Fix'
VERSION='0.10.0'
CORE_FILE=Path(__file__).with_name('ed2_final_battle_presentation_fix_v090_core.py')
if not CORE_FILE.is_file():
    alt=Path('/mnt/data/ed2_v1070_final/ED2_Final_Battle_Presentation_Fix_v0.9.0/ed2_final_battle_presentation_fix.py')
    CORE_FILE=alt if alt.is_file() else CORE_FILE
_spec=importlib.util.spec_from_file_location('ed2_fb_v090_core',CORE_FILE)
if _spec is None or _spec.loader is None: raise RuntimeError('v0.9.0 compatibility core could not be loaded')
v090=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(v090)
core=v090.core; PatchError=v090.PatchError; sha256=v090.sha256; atomic_write=v090.atomic_write

C734_SEGMENT=3
SEG_LEN=v090.SEG_LEN
OLD_RELOC_COUNT=v090.NEW_RELOC_COUNT # 187
NEW_RELOC_COUNT=186
CLR_MON=v090.CLR_MON
CLEANUP_HELPER=v090.CLEANUP_HELPER
CLEANUP_HELPER_END=v090.CLEANUP_HELPER_END
FIRST_CLEAR_CALL=v090.FIRST_CLEAR_CALL
# Standard END_OF_BATTLE/END_OF_BATTLE2 set the current monster record's byte 0 exactly to 80h.
# Do the same before the existing C_734 dual-bank clear.  Clearing 04h is essential: the special
# DISP_MO_STATUS branch tests bit 04h before it tests bit 80h.
C734_V071_CLEANUP_HELPER=(
    b'\xC6\x05\x80' +          # MOV BYTE PTR [DI],80h
    b'\xEA\xFF\xFF\x00\x00' + # JMP FAR CLR_MON
    b'\x90\x90\x90'
)
assert len(C734_V071_CLEANUP_HELPER)==11
C734_V071_FINAL=v090.C734_V070_FINAL
EXPECTED_V071_RELOCS=dict(v090.v080.EXPECTED_V069_RELOCS)
EXPECTED_V071_RELOCS.pop(v090.FIRST_CLEAR_SOURCE)
EXPECTED_V071_RELOCS[0x0B6D]=(3,1,1,CLR_MON)

def _raw_reloc_rows(data,seg):
    return [[r[1],r[2],r[3],r[4],r[5]] for r in core.relocation_records(data,seg)]

def inspect_c734_v071(data:bytes)->dict:
    try:
        _,_,segs=core.ne_info(data); seg=segs[2]; base=seg['off']; rows=core.relocation_records(data,seg)
        next_off=core.next_segment_offset(segs,seg); reloc_end=base+seg['len']+2+len(rows)*8
        structure=seg['len']==SEG_LEN and seg['alloc']==SEG_LEN and len(rows)==NEW_RELOC_COUNT and reloc_end<=next_off
        reveal_ok=core._reveal_state(data,seg)[1]; timing_ok=core._timing_state(data,seg)[1]
        wrapper_ok=core._c734_wrapper_state(data,seg)[0]
        algo_call_ok=bytes(data[base+v090.v080.v070.v060.C734_ALGO09_CALL:base+v090.v080.v070.v060.C734_ALGO09_CALL+3])==v090.v080.v070.v060.C734_ALGO09_CALL_V067
        final_ok=bytes(data[base+v090.v080.v070.C734_FINAL_START:base+v090.v080.v070.C734_FINAL_END])==C734_V071_FINAL
        helper_ok=bytes(data[base+CLEANUP_HELPER:base+CLEANUP_HELPER_END])==C734_V071_CLEANUP_HELPER
        h1_ok=bytes(data[base+v090.v080.HELPER1:base+v090.v080.HELPER1+len(v090.v080.C734_V069_HELPER1)])==v090.v080.C734_V069_HELPER1
        h2_ok=bytes(data[base+v090.v080.HELPER2:base+v090.v080.HELPER2+len(v090.v080.C734_V069_HELPER2)])==v090.v080.C734_V069_HELPER2
        zero_target=bytes(data[base+0x057E:base+0x059C])==b'\0'*30
        reloc_ok=all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_V071_RELOCS.items())
        sources=[r[3] for r in rows]
        no_wrong_mc1=not any(r[3]==0x0B6A for r in rows)
        no_old_first=not any(r[3]==v090.FIRST_CLEAR_SOURCE for r in rows)
        unique=len(sources)==len(set(sources))
        patched=bool(structure and reveal_ok and timing_ok and wrapper_ok and algo_call_ok and final_ok and helper_ok and h1_ok and h2_ok and zero_target and reloc_ok and no_wrong_mc1 and no_old_first and unique)
        return {'supported':patched,'patched':patched,'field_scene_open_wind_reveal':reveal_ok,'field_scene_fixed_256_frames':timing_ok,
                'white_screen_hold_ticks':20 if final_ok else None,'godwin_record_deactivated_exact_0x80':helper_ok and reloc_ok,
                'wrong_monster_clear1_removed':no_wrong_mc1,'ordinary_dual_bank_clear_preserved':final_ok and h1_ok,
                'normal_scene_palette_restore_after_clear':final_ok and h1_ok,'pc98_post_message_cleanup_0C44_0C5C':h2_ok,
                'defeat_message_hold_ticks':180 if h2_ok else None,'true_black_fade_after_message_hold':final_ok and h2_ok and zero_target,
                'segment_length':seg['len'],'segment_minalloc':seg['alloc'],'relocation_count':len(rows),'relocation_table_end':reloc_end,
                'next_segment_offset':next_off,'relocation_slack_bytes':next_off-reloc_end,'relocations_ok':reloc_ok and no_wrong_mc1 and no_old_first and unique,'sha256':sha256(data)}
    except Exception:
        return {'supported':False,'patched':False,'sha256':sha256(data)}

def patch_c734_v071(before:bytes)->bytes:
    if inspect_c734_v071(before).get('patched'): return before
    # Normalize all supported stock/v1.0.64..v1.0.70 inputs to v1.0.70, then replace the incorrect MC1 helper.
    base_bytes=v090.patch_c734_v070(before)
    if not v090.inspect_c734_v070(base_bytes).get('patched'): raise PatchError('C_734 could not be normalized to v1.0.70 state')
    d=bytearray(base_bytes); _,_,segs=core.ne_info(d); seg=segs[2]; base=seg['off']
    rows0=core.relocation_records(d,seg)
    if len(rows0)!=OLD_RELOC_COUNT: raise PatchError(f'v1.0.70 relocation count differs: {len(rows0)}')
    next_off=core.next_segment_offset(segs,seg); reloc_start=base+seg['len']
    untouched={s['num']:bytes(d[s['off']:s['off']+s['len']]) for s in segs if s['num']!=3}
    d[base+CLEANUP_HELPER:base+CLEANUP_HELPER_END]=C734_V071_CLEANUP_HELPER
    meta=_raw_reloc_rows(d,seg)
    # Drop the wrong MONSTER_CLEAR1 import, and move the CLR_MON far-pointer fixup to our tail jump.
    meta=[r for r in meta if r[2]!=0x0B6A]
    found=[r for r in meta if r[2]==0x0B6F]
    if len(found)!=1: raise PatchError(f'v1.0.70 CLR_MON helper relocation expected once, found {len(found)}')
    found[0][2]=0x0B6D; found[0][0]=3; found[0][1]=(found[0][1]&~7)|1; found[0][3]=1; found[0][4]=CLR_MON
    if len(meta)!=NEW_RELOC_COUNT: raise PatchError('v1.0.71 relocation count construction failed')
    sources=[r[2] for r in meta]
    if len(sources)!=len(set(sources)): raise PatchError('v1.0.71 relocation sources not unique')
    table=struct.pack('<H',len(meta))+b''.join(bytes((st&255,fl&255))+struct.pack('<HHH',src,mod,tgt) for st,fl,src,mod,tgt in meta)
    end=reloc_start+len(table)
    if end>next_off: raise PatchError('v1.0.71 relocation table overlaps next segment')
    d[reloc_start:end]=table; d[end:next_off]=b'\0'*(next_off-end)
    out=bytes(d); _,_,segs2=core.ne_info(out)
    for s in segs2:
        if s['num']==3: continue
        if bytes(out[s['off']:s['off']+s['len']])!=untouched[s['num']]: raise PatchError(f'unexpected change in segment {s["num"]}')
    st=inspect_c734_v071(out)
    if not st.get('patched'): raise PatchError(f'post-patch verification failed: {st}')
    return out

def validate_root(root:Path)->Path: return v090.validate_root(root)
def repair_ed2main(root:Path,make_backup=True): return v090.repair_ed2main(root,make_backup)
def inspect_patch(root:Path):
    root=validate_root(root); e=core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes()); m=core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes()); c=inspect_c734_v071((root/'SCENA/C_734.DLL').read_bytes())
    return {'tool_version':VERSION,'ed2main':e,'m501':m,'c734':c,'ed2main_stable_no_new_patch':e['stable'],'m501_wrong_experiment_removed':m['original'],
            'godwin_record_deactivated_exact_0x80':c.get('godwin_record_deactivated_exact_0x80',False),'wrong_v1070_monster_clear1_removed':c.get('wrong_monster_clear1_removed',False),
            'white_screen_hold_20_ticks':c.get('white_screen_hold_ticks')==20,'defeat_message_hold_180_then_true_black_fade':c.get('defeat_message_hold_ticks')==180 and c.get('true_black_fade_after_message_hold',False),
            'ok':bool(e['stable'] and m['original'] and c.get('patched'))}
def apply_patch(root:Path,make_backup=True):
    root=validate_root(root); er=repair_ed2main(root,make_backup)
    mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
    if ma!=mb: atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734_v071(cb)
    if ca!=cb: atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st=inspect_patch(root)
    if not st['ok']: raise PatchError('Final verification failed')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}
def main():
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}'); ap.add_argument('root',type=Path); g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true'); ap.add_argument('--no-backup',action='store_true'); a=ap.parse_args()
    try:
        r=repair_ed2main(a.root,not a.no_backup) if a.repair_ed2main_only else inspect_patch(a.root) if a.check else apply_patch(a.root,not a.no_backup)
        print(json.dumps(r,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as e: print('ERROR:',e); return 1
if __name__=='__main__': raise SystemExit(main())
