#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, struct, tempfile
from pathlib import Path

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.6.0"

CORE_FILE = Path(__file__).with_name("ed2_final_battle_presentation_fix_v050_core.py")
if not CORE_FILE.is_file():
    # Development fallback only; packaged builds always ship the core beside this file.
    alt = Path('/mnt/data/ed2_final_battle_presentation_fix_v050.py')
    CORE_FILE = alt if alt.is_file() else CORE_FILE
_spec = importlib.util.spec_from_file_location("ed2_fb_v050_core", CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError("v0.5.0 compatibility core could not be loaded")
core = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(core)

PatchError = core.PatchError
sha256 = core.sha256
atomic_write = core.atomic_write

C734_SEGMENT = 3
C734_LEN = 0x0CBE
C734_ALGO09_CALL = 0x05DC
C734_ALGO09_CALL_V066 = bytes.fromhex('E8 8A 05')  # -> 0B69
C734_ALGO09_CALL_V067 = bytes.fromhex('E8 95 05')  # -> 0B74, skip post-message helper

# v1.0.66 used this 11-byte slot to zero the fade target before the explosion.
# That was too early. v1.0.67 turns it into a post-message helper:
#   CALL COPY_MESS
#   JMP  ABS_DELAY  (AL contains 120)
# The far JMP tail-calls ABS_DELAY so its RETF returns directly to the caller.
C734_HELPER = 0x0B69
C734_HELPER_END = 0x0B74
C734_V066_PREP = bytes.fromhex('31 C0 BF 7E 05 B9 0F 00 F3 AB 90')
C734_V067_HELPER = bytes.fromhex('9A FF FF 00 00 EA FF FF 00 00 90')

# 51-byte fixed slot. Preserve the requested 150-tick explosion hold, then
# clear the battle display and show the defeat message. After DISP_MESS_LOW,
# AL=120 and the local helper performs COPY_MESS + ABS_DELAY. Only after that
# does the existing 15-step true-black fade at 0BDC begin.
C734_FINAL_START = 0x0BA9
C734_FINAL_END = 0x0BDC
C734_V067_FINAL = (
    b'\xB0\x96' +                 # AL=150
    b'\x9A\xFF\xFF\x00\x00' + # ABS_DELAY
    b'\xBF\xFF\xFF' +           # EN_DATA_1
    b'\x9A\xFF\xFF\x00\x00' * 5 +
    b'\xBE\xEF\x02' +           # defeat message pointer
    b'\x9A\xFF\xFF\x00\x00' + # DISP_MESS_LOW
    b'\xB0\x78' +                 # AL=120
    b'\x0E\xE8\x8F\xFF' +       # PUSH CS / CALL 0B69
    b'\x90\x90'
)
assert len(C734_V067_FINAL) == 51

COPY_MESS = 55
ABS_DELAY = 252
CLR_MON = 303
DISP_MESS_LOW = 599
EN_DATA_1 = 682
NEG_DSP_BANK = 62
CLR_MON_STS = 887
PAL_DATA = 652
ETC_SKIP = 255
ETC_DELAY = 257
SET_PAL_CONT = 656
THEEND = 6

# v1.0.66 relocation sources -> v1.0.67 sources/targets.
# No relocation is added or removed: the old ETC_SKIP record is repurposed as
# the helper's ABS_DELAY far pointer.
MOVE_SIMPLE = {
    0x0BB4: 0x0BB1, # EN_DATA_1
    0x0BB7: 0x0BB4, # CLR_MON
    0x0BBC: 0x0BB9, # CLR_MON_STS
    0x0BC1: 0x0BBE, # NEG_DSP_BANK
    0x0BC6: 0x0BC3, # CLR_MON
    0x0BCB: 0x0BC8, # CLR_MON_STS
    0x0BD3: 0x0BD0, # DISP_MESS_LOW
    0x0BD8: 0x0B6A, # COPY_MESS into helper
}

EXPECTED_V067_RELOCS = {
    0x0B6A: (3,1,1,COPY_MESS),
    0x0B6F: (3,1,1,ABS_DELAY),
    0x0BAC: (3,1,1,ABS_DELAY),
    0x0BB1: (5,5,1,EN_DATA_1),
    0x0BB4: (3,1,1,CLR_MON),
    0x0BB9: (3,1,1,CLR_MON_STS),
    0x0BBE: (3,1,1,NEG_DSP_BANK),
    0x0BC3: (3,1,1,CLR_MON),
    0x0BC8: (3,1,1,CLR_MON_STS),
    0x0BD0: (3,1,1,DISP_MESS_LOW),
    # Existing fade and ending relocations stay where stock/v1.0.66 had them.
    0x0BE0: (5,5,1,PAL_DATA),
    0x0BE9: (5,5,1,ETC_SKIP),
    0x0BFB: (3,1,1,ETC_DELAY),
    0x0C00: (3,1,1,SET_PAL_CONT),
    0x0C14: (3,1,1,THEEND),
}


def _rewrite_reloc(d: bytearray, seg, old_source: int, *, new_source: int, stype: int, flags_low: int, module: int, target: int):
    r = core.reloc_one(d, seg, old_source)
    ro = r[0]
    d[ro] = stype & 0xFF
    d[ro+1] = (r[2] & ~7) | (flags_low & 7)
    core.p16(d, ro+2, new_source)
    core.p16(d, ro+4, module)
    core.p16(d, ro+6, target)


def inspect_c734_v067(data: bytes) -> dict:
    _,_,segs = core.ne_info(data)
    seg = segs[C734_SEGMENT-1]
    base = seg['off']
    rows = core.relocation_records(data, seg)
    structure = seg['len']==C734_LEN and seg['alloc']==C734_LEN and \
        seg['off']+seg['len']+2+len(rows)*8 <= core.next_segment_offset(segs,seg)
    reveal_ok = core._reveal_state(data,seg)[1]
    timing_ok = core._timing_state(data,seg)[1]
    wrapper_ok = core._c734_wrapper_state(data,seg)[0]
    call_ok = bytes(data[base+C734_ALGO09_CALL:base+C734_ALGO09_CALL+3]) == C734_ALGO09_CALL_V067
    helper_ok = bytes(data[base+C734_HELPER:base+C734_HELPER_END]) == C734_V067_HELPER
    final_ok = bytes(data[base+C734_FINAL_START:base+C734_FINAL_END]) == C734_V067_FINAL
    zero_target = bytes(data[base+0x057E:base+0x059C]) == b'\0'*30
    reloc_ok = all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_V067_RELOCS.items())
    # Retired v1.0.66 final-block relocation positions must no longer exist.
    retired = {0x0BAB,0x0BAF,0x0BB7,0x0BBC,0x0BC1,0x0BC6,0x0BCB,0x0BD3,0x0BD8}
    retired_ok = not any(r[3] in retired for r in rows)
    patched = bool(structure and wrapper_ok and reveal_ok and timing_ok and call_ok and helper_ok and final_ok and zero_target and reloc_ok and retired_ok and len(rows)==185)
    return {
        'supported': patched,
        'patched': patched,
        'field_scene_open_wind_reveal': reveal_ok,
        'field_scene_fixed_256_frames': timing_ok,
        'explosion_hold_150': final_ok,
        'defeat_message_hold_120': final_ok and helper_ok,
        'true_black_fade_after_message_hold': final_ok and helper_ok and zero_target,
        'algo09_skips_helper_on_entry': call_ok,
        'post_message_helper': helper_ok,
        'fade_target_file_zero': zero_target,
        'relocations_ok': reloc_ok and retired_ok,
        'relocation_count': len(rows),
        'segment_length': seg['len'],
        'segment_minalloc': seg['alloc'],
        'sha256': sha256(data),
    }


def patch_c734_v067(before: bytes) -> bytes:
    st = inspect_c734_v067(before)
    if st['patched']:
        return before

    # First converge every supported stock/v1.0.61..v1.0.66 state to the
    # runtime-confirmed v1.0.66 base (field-scene repair + true-black fade).
    base_bytes = core.patch_c734_bytes(before)
    d = bytearray(base_bytes)
    _,_,segs = core.ne_info(d)
    seg = segs[C734_SEGMENT-1]
    base = seg['off']
    if bytes(d[base+C734_ALGO09_CALL:base+C734_ALGO09_CALL+3]) != C734_ALGO09_CALL_V066:
        raise PatchError('C_734 ALGO_09 호출 서명이 v1.0.66 기준과 다릅니다.')
    if bytes(d[base+C734_HELPER:base+C734_HELPER_END]) != C734_V066_PREP:
        raise PatchError('C_734 v1.0.66 페이드 준비 슬롯 서명이 다릅니다.')
    if bytes(d[base+C734_FINAL_START:base+C734_FINAL_END]) != core.C734_FINAL_PATCHED:
        raise PatchError('C_734 v1.0.66 최종 장면 슬롯 서명이 다릅니다.')

    # Make 0B69 a post-message helper and have ALGO_09 begin at 0B74 so the
    # helper is not executed at boss-death entry.
    d[base+C734_ALGO09_CALL:base+C734_ALGO09_CALL+3] = C734_ALGO09_CALL_V067
    d[base+C734_HELPER:base+C734_HELPER_END] = C734_V067_HELPER
    d[base+C734_FINAL_START:base+C734_FINAL_END] = C734_V067_FINAL

    # Repurpose/move the v1.0.66 relocation records without changing count.
    # ETC_SKIP record (0BAB) becomes helper ABS_DELAY at 0B6F.
    _rewrite_reloc(d,seg,0x0BAB,new_source=0x0B6F,stype=3,flags_low=1,module=1,target=ABS_DELAY)
    # ETC_DELAY record (0BAF) becomes pre-explosion ABS_DELAY at 0BAC.
    _rewrite_reloc(d,seg,0x0BAF,new_source=0x0BAC,stype=3,flags_low=1,module=1,target=ABS_DELAY)
    # Other fixed-slot calls/data are only shifted.
    for old,new in MOVE_SIMPLE.items():
        r=core.reloc_one(d,seg,old)
        core.p16(d,r[0]+2,new)

    out = bytes(d)
    st2 = inspect_c734_v067(out)
    if not st2['patched']:
        raise PatchError(f'C_734 v1.0.67 패치 후 검증 실패: {st2}')
    return out


def validate_root(root: Path) -> Path:
    return core.validate_root(root)


def inspect_patch(root: Path):
    root = validate_root(root)
    e = core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes())
    m = core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes())
    c = inspect_c734_v067((root/'SCENA/C_734.DLL').read_bytes())
    return {
        'tool_version': VERSION, 'ed2main': e, 'm501': m, 'c734': c,
        'ed2main_stable_no_new_patch': e['stable'],
        'm501_wrong_experiment_removed': m['original'],
        'field_scene_open_wind_reveal': c['field_scene_open_wind_reveal'],
        'field_scene_fixed_256_frames': c['field_scene_fixed_256_frames'],
        'explosion_hold_150': c['explosion_hold_150'],
        'defeat_message_hold_120_then_true_black_fade': c['defeat_message_hold_120'] and c['true_black_fade_after_message_hold'],
        'ok': bool(e['stable'] and m['original'] and c['patched']),
    }


def repair_ed2main(root: Path, make_backup=True):
    root=validate_root(root); p=root/'ED2MAIN.EXE'; before=p.read_bytes(); after=core.repair_ed2main_bytes(before)
    if after!=before: atomic_write(p,after,'.v1.0.61_unsafe.bak' if make_backup else None)
    return {'changed':after!=before,'before_sha256':sha256(before),'after_sha256':sha256(after),'state':core.inspect_ed2main_bytes(after)}


def apply_patch(root: Path, make_backup=True):
    root=validate_root(root)
    er=repair_ed2main(root,make_backup)
    mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
    if ma!=mb: atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734_v067(cb)
    if ca!=cb: atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st=inspect_patch(root)
    if not st['ok']: raise PatchError('최종 검증에 실패했습니다.')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}


def main() -> int:
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}')
    ap.add_argument('root',type=Path)
    g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true')
    ap.add_argument('--no-backup',action='store_true'); args=ap.parse_args()
    try:
        if args.repair_ed2main_only: result=repair_ed2main(args.root,not args.no_backup)
        elif args.check: result=inspect_patch(args.root)
        else: result=apply_patch(args.root,not args.no_backup)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}'); return 1

if __name__=='__main__':
    raise SystemExit(main())
