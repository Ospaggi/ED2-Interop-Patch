#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, struct
from pathlib import Path

APP_NAME='ED2 Final Battle Presentation Fix'
VERSION='0.13.0'
CORE_FILE=Path(__file__).with_name('ed2_final_battle_presentation_fix_v0120_core.py')
if not CORE_FILE.is_file():
    alt=Path('/mnt/data/ed2_final_battle_presentation_fix_v0120.py')
    CORE_FILE=alt if alt.is_file() else CORE_FILE
_spec=importlib.util.spec_from_file_location('ed2_fb_v0120_core',CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError('v0.12.0 compatibility core could not be loaded')
v120=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(v120)
core=v120.core; PatchError=v120.PatchError; sha256=v120.sha256; atomic_write=v120.atomic_write

C734_SEGMENT=3
SEG_LEN=v120.SEG_LEN
RELOC_COUNT=v120.RELOC_COUNT
PRE_HELPER=v120.PRE_HELPER
PRE_HELPER_END=v120.PRE_HELPER_END
FINAL_START=v120.FINAL_START
FINAL_END=v120.FINAL_END
POST_HELPER=v120.POST_HELPER
POST_HELPER_END=v120.POST_HELPER_END
POST_CLEAR_HELPER=v120.v110.DUMMY_HELPER1
POST_CLEAR_HELPER_END=v120.v110.DUMMY_HELPER1_END
ST_SIN_PAL=v120.v110.ST_SIN_PAL

# v0.13.0 correction:
# - CLR_MON (ED2MAIN 86:60EB) and CLR_MON_STS (86:A92E) do not inspect record byte 0;
#   they clear using the record's position/size fields and preserve DI.
# - The redraw/status path around 86:A95C *does* inspect byte 0 and can re-enter the
#   special 04h path while Godwin remains active.
# - Therefore the safe order is: clear BOTH banks first while all geometry is intact,
#   then set byte0 exactly to 80h to prevent any later redraw, then restore palette.
# This exact post-clear deactivation ordering has not been used by v1.0.71-v1.0.73.

def _near_disp(target:int,next_ip:int)->bytes:
    return struct.pack('<H',(target-next_ip)&0xFFFF)

# Keep v1.0.73 20-tick white hold: ABS_DELAY only, no record mutation.
C734_V074_PRE_HELPER=v120.C734_V073_PRE_HELPER

# Replace only the inline ST_SIN_PAL far call with a local post-clear helper call.
# Layout at 3:0BCB is five bytes, so PUSH CS + near CALL + NOP fits exactly.
C734_V074_FINAL=bytearray(v120.C734_V073_FINAL)
_st_rel=0x0BCB-FINAL_START
C734_V074_FINAL[_st_rel:_st_rel+5]=(
    b'\x0E\xE8' + _near_disp(POST_CLEAR_HELPER,0x0BCF) + b'\x90'
)
C734_V074_FINAL=bytes(C734_V074_FINAL)
assert len(C734_V074_FINAL)==len(v120.C734_V073_FINAL)==51

# Called only after:
#   CLR_MON -> CLR_MON_STS -> NEG_DSP_BANK -> CLR_MON -> CLR_MON_STS
# DI is preserved by all five routines and still points to EN_DATA_1.
# Deactivate after the actual pixel/status clears, then tail-call ST_SIN_PAL.
C734_V074_POST_CLEAR_HELPER=(
    b'\xC6\x05\x80' +          # MOV BYTE PTR [DI],80h
    b'\xEA\xFF\xFF\x00\x00' + # JMP FAR ST_SIN_PAL
    b'\x90\x90\x90'
)
assert len(C734_V074_POST_CLEAR_HELPER)==11

C734_V074_POST_HELPER=v120.C734_V073_POST_HELPER

# v1.0.73 expected relocation set, except ST_SIN_PAL pointer moves from inline
# source 0x0BCC to helper far-jump source 0x0CC2.
EXPECTED_RELOCS=dict(v120.v110.EXPECTED_RELOCS)
EXPECTED_RELOCS.pop(0x0BCC)
EXPECTED_RELOCS[0x0CC2]=(3,1,1,ST_SIN_PAL)


def _raw_reloc_rows(data,seg):
    return [[r[1],r[2],r[3],r[4],r[5]] for r in core.relocation_records(data,seg)]

def _one(meta,source):
    rows=[r for r in meta if r[2]==source]
    if len(rows)!=1:
        raise PatchError(f'relocation source 0x{source:04X}: expected one, found {len(rows)}')
    return rows[0]


def inspect_c734_v074(data:bytes)->dict:
    try:
        _,_,segs=core.ne_info(data); seg=segs[2]; base=seg['off']; rows=core.relocation_records(data,seg)
        next_off=core.next_segment_offset(segs,seg); reloc_end=base+seg['len']+2+len(rows)*8
        structure=seg['len']==SEG_LEN and seg['alloc']==SEG_LEN and len(rows)==RELOC_COUNT and reloc_end<=next_off
        reveal_ok=core._reveal_state(data,seg)[1]; timing_ok=core._timing_state(data,seg)[1]
        wrapper_ok=core._c734_wrapper_state(data,seg)[0]
        algo_ok=bytes(data[base+v120.v110.v100.v090.v080.v070.v060.C734_ALGO09_CALL:base+v120.v110.v100.v090.v080.v070.v060.C734_ALGO09_CALL+3])==v120.v110.v100.v090.v080.v070.v060.C734_ALGO09_CALL_V067
        pre_ok=bytes(data[base+PRE_HELPER:base+PRE_HELPER_END])==C734_V074_PRE_HELPER
        final_ok=bytes(data[base+FINAL_START:base+FINAL_END])==C734_V074_FINAL
        postclear_ok=bytes(data[base+POST_CLEAR_HELPER:base+POST_CLEAR_HELPER_END])==C734_V074_POST_CLEAR_HELPER
        post_ok=bytes(data[base+POST_HELPER:base+POST_HELPER_END])==C734_V074_POST_HELPER
        zero_target=bytes(data[base+0x057E:base+0x059C])==b'\0'*30
        reloc_ok=all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_RELOCS.items())
        sources=[r[3] for r in rows]; unique=len(sources)==len(set(sources))
        no_old_st=0x0BCC not in sources
        patched=bool(structure and reveal_ok and timing_ok and wrapper_ok and algo_ok and pre_ok and final_ok and postclear_ok and post_ok and zero_target and reloc_ok and unique and no_old_st)
        return {
            'supported':patched,'patched':patched,
            'field_scene_open_wind_reveal':reveal_ok,'field_scene_fixed_256_frames':timing_ok,
            'white_screen_hold_ticks':20 if pre_ok and final_ok else None,
            'clear_before_deactivate':final_ok and postclear_ok,
            'cleanup_order':'CLR_MON -> CLR_MON_STS -> NEG_DSP_BANK -> CLR_MON -> CLR_MON_STS -> EN_DATA_1[0]=80h' if final_ok and postclear_ok else None,
            'godwin_record_deactivated_after_both_bank_clears':postclear_ok,
            'palette_restore_after_deactivate':'ST_SIN_PAL' if postclear_ok else None,
            'defeat_message_hold_ticks':180 if post_ok else None,
            'true_black_fade_after_message_hold':final_ok and post_ok and zero_target,
            'segment_length':seg['len'],'segment_minalloc':seg['alloc'],'relocation_count':len(rows),
            'relocation_table_end':reloc_end,'next_segment_offset':next_off,'relocation_slack_bytes':next_off-reloc_end,
            'relocations_ok':reloc_ok and unique and no_old_st,'sha256':sha256(data)
        }
    except Exception:
        return {'supported':False,'patched':False,'sha256':sha256(data)}


def patch_c734_v074(before:bytes)->bytes:
    if inspect_c734_v074(before).get('patched'):
        return before
    # Normalize stock and all earlier supported releases through v1.0.73.
    base_bytes=v120.patch_c734_v073(before)
    if not v120.inspect_c734_v073(base_bytes).get('patched'):
        raise PatchError('C_734 could not normalize to v1.0.73')
    d=bytearray(base_bytes); _,_,segs=core.ne_info(d); seg=segs[2]; base=seg['off']; next_off=core.next_segment_offset(segs,seg)
    if seg['len']!=SEG_LEN or seg['alloc']!=SEG_LEN:
        raise PatchError('segment layout differs')
    rows0=core.relocation_records(d,seg)
    if len(rows0)!=RELOC_COUNT:
        raise PatchError(f'v1.0.73 relocation count differs: {len(rows0)}')
    untouched={s['num']:bytes(d[s['off']:s['off']+s['len']]) for s in segs if s['num']!=3}

    d[base+FINAL_START:base+FINAL_END]=C734_V074_FINAL
    d[base+POST_CLEAR_HELPER:base+POST_CLEAR_HELPER_END]=C734_V074_POST_CLEAR_HELPER

    meta=_raw_reloc_rows(d,seg)
    r=_one(meta,0x0BCC)
    r[2]=0x0CC2; r[0]=3; r[1]=(r[1]&~7)|1; r[3]=1; r[4]=ST_SIN_PAL
    sources=[r[2] for r in meta]
    if len(meta)!=RELOC_COUNT or len(sources)!=len(set(sources)):
        raise PatchError('relocation reconstruction failed')
    reloc_start=base+seg['len']
    table=struct.pack('<H',len(meta))+b''.join(bytes((st&255,fl&255))+struct.pack('<HHH',src,mod,tgt) for st,fl,src,mod,tgt in meta)
    end=reloc_start+len(table)
    if end>next_off:
        raise PatchError('relocation table overlaps next segment')
    d[reloc_start:end]=table; d[end:next_off]=b'\0'*(next_off-end)
    out=bytes(d); _,_,segs2=core.ne_info(out)
    for s in segs2:
        if s['num']==3: continue
        if bytes(out[s['off']:s['off']+s['len']])!=untouched[s['num']]:
            raise PatchError(f'unexpected segment {s["num"]} change')
    st=inspect_c734_v074(out)
    if not st.get('patched'):
        raise PatchError(f'post-patch verification failed: {st}')
    return out


def validate_root(root:Path)->Path: return v120.validate_root(root)
def repair_ed2main(root:Path,make_backup=True): return v120.repair_ed2main(root,make_backup)
def inspect_patch(root:Path):
    root=validate_root(root)
    e=core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes())
    m=core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes())
    c=inspect_c734_v074((root/'SCENA/C_734.DLL').read_bytes())
    return {
        'tool_version':VERSION,'ed2main':e,'m501':m,'c734':c,
        'ed2main_stable_no_new_patch':e['stable'],'m501_wrong_experiment_removed':m['original'],
        'godwin_cleared_then_deactivated':c.get('godwin_record_deactivated_after_both_bank_clears',False),
        'white_screen_hold_20_ticks':c.get('white_screen_hold_ticks')==20,
        'defeat_message_hold_180_then_true_black_fade':c.get('defeat_message_hold_ticks')==180 and c.get('true_black_fade_after_message_hold',False),
        'ok':bool(e['stable'] and m['original'] and c.get('patched'))
    }

def apply_patch(root:Path,make_backup=True):
    root=validate_root(root); er=repair_ed2main(root,make_backup)
    mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
    if ma!=mb: atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734_v074(cb)
    if ca!=cb: atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st=inspect_patch(root)
    if not st['ok']: raise PatchError('Final verification failed')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}

def main():
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}'); ap.add_argument('root',type=Path)
    g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true')
    ap.add_argument('--no-backup',action='store_true'); a=ap.parse_args()
    try:
        r=repair_ed2main(a.root,not a.no_backup) if a.repair_ed2main_only else inspect_patch(a.root) if a.check else apply_patch(a.root,not a.no_backup)
        print(json.dumps(r,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as e:
        print('ERROR:',e); return 1
if __name__=='__main__': raise SystemExit(main())
