#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
import struct
import sys
import tempfile
from pathlib import Path

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.18.11"
CORE_FILE = Path(__file__).with_name("ed2_final_battle_presentation_fix_v0140_core.py")
_spec = importlib.util.spec_from_file_location("ed2_fb_v0140_core", CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError("v0.14.0 core load failed")
v140 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v140)

core = v140.core
PatchError = v140.PatchError
sha256 = v140.sha256
atomic_write = v140.atomic_write

# ---------------------------------------------------------------------------
# M_501 final Godwin battle data
# ---------------------------------------------------------------------------
M501_SEGMENT = 3
M501_HP = 9999
M501_NAME = "고드윈"
M501_NAME_BYTES = M501_NAME.encode("cp949") + b"\x06"
M501_NAME_FIELD = M501_NAME_BYTES + b"\x00" * (16 - len(M501_NAME_BYTES))
assert len(M501_NAME_FIELD) == 16

M501_HP_CUR = 0x0004
M501_HP_MAX = 0x0006
M501_NAME_OFF = 0x0030
M501_TITLE_OFF = 0x0056
# v0.18.5: the stray-glyph bug exists only in the special quote scene.  Restore
# the original Korean DOS composition exactly: literal "황제 " + 0F pointer to
# the stock actor-name slot at 0030h + 05h + 06h.  Do not rewrite the general
# skill strings or renderer paths.
M501_TITLE = "황제 ".encode("cp949") + bytes.fromhex("0F 30 00 05 06")
M501_TITLE_LEN = len(M501_TITLE)
M501_TITLE_FIELD = M501_TITLE + b"\x00\x00"
assert M501_TITLE_LEN == 10 and len(M501_TITLE_FIELD) == 12

# PC-98: 「この私の本当の力を思い知るがいい。」
# Exact 36-byte in-place replacement for the Korean stock sentence.
M501_QUOTE_OFF = 0x00D4
M501_QUOTE_OLD = "이제, 나의 진정한 힘을 보여 주겠다. ".encode("cp949")
M501_QUOTE_V01810 = "이 몸의 진정한 힘을 똑똑히 깨달아라.".encode("cp949")
# 34-cell battle quote window: replace the inter-phrase space with 01h so the
# wording remains unchanged but renders as 19 cells / 16 cells instead of 36.
M501_QUOTE_NEW = "이 몸의 진정한 힘을".encode("cp949") + b"\x01" + "똑똑히 깨달아라.".encode("cp949")
assert len(M501_QUOTE_OLD) == len(M501_QUOTE_V01810) == len(M501_QUOTE_NEW) == 36

# v0.18.4: rollback v0.18.2/v0.18.3 skill-message rewrite completely.
# The user's runtime reports show that touching these message/render paths causes
# battle-presentation corruption. Keep the original M_501 skill streams and calls
# byte-for-byte, and fix only the dynamic actor name source by restoring stock
# "고드윈" in the monster name field. Fixed speaker/title slots remain literal
# "황제 고드윈".
M501_SKILL_REGION_START = 0x0062
M501_SKILL_REGION_END = 0x00C1
M501_SKILL_REGION_STOCK = bytes.fromhex(
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 "
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 "
    "86 C0 C7 20 B0 A1 BD BF C0 CC 20 B9 F8 C2 BD BF B4 B4 D9 21 21 07 "
    "02 C0 C7 20 BF AC BC D3 20 B0 F8 B0 DD 21 21 07 "
    "02 B4 C2 20 B4 EB B1 E2 B8 A6 20 C2 F5 BE EE 20 B0 A1 B8 A3 B4 C2 20 C6 C4 B5 87"
)
assert len(M501_SKILL_REGION_STOCK) == 95

# v0.18.7: the Korean retail third Godwin skill is malformed in place.
# 03:00A6 begins with actor-name control 02h, but the final Hangul byte is
# B5 87 instead of the CP949 bytes for "동" (B5 BF), and there is no 07h
# message terminator before the live 00C1 control stream.  Relocate only this
# one message into the verified 30-byte zero pad at 0062..007F.
M501_SKILL3_FIXED_OFF = 0x0062
M501_SKILL3_FIXED_TEXT = "은 대기를 찢는 파동을 냈다.".encode("cp949")
M501_SKILL3_FIXED = b"\x02" + M501_SKILL3_FIXED_TEXT + b"\x07"
M501_SKILL3_PAD_LEN = 0x001E
assert len(M501_SKILL3_FIXED) == 29 and M501_SKILL3_PAD_LEN == 30
M501_SKILL3_FIELD = M501_SKILL3_FIXED + b"\x00"
assert len(M501_SKILL3_FIELD) == M501_SKILL3_PAD_LEN
M501_SKILL_REGION_FIXED = bytearray(M501_SKILL_REGION_STOCK)
M501_SKILL_REGION_FIXED[:M501_SKILL3_PAD_LEN] = M501_SKILL3_FIELD
M501_SKILL_REGION_FIXED = bytes(M501_SKILL_REGION_FIXED)
M501_SKILL3_SI_FIXED = bytes.fromhex("BE 62 00")
M501_POST_SKILL_CONTROL_OFF = 0x00C1
M501_POST_SKILL_CONTROL = bytes.fromhex("1E 10 56 00 04")
M501_SKILL1_SI = 0x025A
M501_SKILL3_SI = 0x02D1
M501_SKILL2_SI = 0x0349
M501_SKILL_SI_STOCK = {
    M501_SKILL1_SI: bytes.fromhex("BE 81 00"),
    M501_SKILL3_SI: bytes.fromhex("BE A6 00"),
    M501_SKILL2_SI: bytes.fromhex("BE 96 00"),
}
M501_SKILL1_CALL_RELOC = 0x025E
M501_MESSAGE_MODULE = 1
M501_SKILL1_ORDINAL_STOCK = 615
M501_SKILL1_ORDINAL_V018X = 599

# Exact v0.18.2/v0.18.3 literal region signature. Used only to recognize and
# undo our own previous experimental state; unknown/custom M_501 binaries are
# not normalized speculatively.
_M501_V018X_TEXTS = (
    "황제 고드윈의 가슴이 빛났다!!",
    "황제 고드윈의 연속 공격!!",
    "황제 고드윈은 대기를 찢는 파동을 쐈다.",
)
M501_SKILL_REGION_V018X = b"".join(t.encode("cp949") + b"\x07" for t in _M501_V018X_TEXTS)
assert len(M501_SKILL_REGION_V018X) == 95
M501_SKILL_SI_V018X = {
    M501_SKILL1_SI: bytes.fromhex("BE 62 00"),
    M501_SKILL3_SI: bytes.fromhex("BE 9A 00"),
    M501_SKILL2_SI: bytes.fromhex("BE 80 00"),
}

# v0.18.8: fix the continuous-attack target selector without touching the
# successful v0.18.7 skill-3/string fix.  Retail calls the shared CHOICE_TEKI
# routine once per hit.  That routine derives its side from mutable current-actor
# state, so after a hit/status update a later iteration can select the monster
# side and make Godwin hit himself.  The local attack summary and alive check are
# player-slot-only, so select PL_DATA_1..4 directly here.
M501_MULTI_TARGET_CALL_OFF = 0x0367
M501_MULTI_TARGET_RELOC_SOURCE = 0x0368
M501_MULTI_TARGET_RETRY_DISP_OFF = 0x0371
M501_MULTI_TARGET_RETRY_STOCK = 0xF5  # JE 0367h
M501_MULTI_TARGET_RETRY_FIXED = 0xF0  # JE 0362h: rerun RANDOM for dead targets
M501_PL_DATA1_RELOC_SOURCE = 0x030C
M501_PL_DATA1_ORDINAL = 748
M501_MULTI_TARGET_HELPER_OFF = 0x00A6
M501_MULTI_TARGET_HELPER = bytes.fromhex(
    "24 03 "          # and al,03h
    "30 E4 "          # xor ah,ah
    "B1 06 "          # mov cl,06h
    "D3 E0 "          # shl ax,cl  -> 0/40/80/C0h
    "2E 8B 3E 0C 03 " # mov di,cs:[030Ch] (loader-relocated PL_DATA_1 immediate)
    "03 F8 "          # add di,ax
    "CB"              # retf
)
assert len(M501_MULTI_TARGET_HELPER) == 16
M501_MULTI_TARGET_TRAMPOLINE = (
    b"\x0E\xE8" +
    struct.pack("<H", (M501_MULTI_TARGET_HELPER_OFF - (M501_MULTI_TARGET_CALL_OFF + 4)) & 0xFFFF) +
    b"\x90"
)
assert len(M501_MULTI_TARGET_TRAMPOLINE) == 5

# PC-98 M_501: 「の胸が光った !!」.  Keep the fixed 0081..0095 slot size;
# only the Korean wording changes, followed by 07h and two zero pad bytes.
M501_SKILL1_TEXT_OFF = 0x0081
M501_SKILL1_FIELD_LEN = 0x0096 - M501_SKILL1_TEXT_OFF
M501_SKILL1_OLD = "의 가슴이 번쩍였다!!".encode("cp949") + b"\x07"
M501_SKILL1_NEW_TEXT = "의 가슴이 빛났다!!"
M501_SKILL1_NEW = M501_SKILL1_NEW_TEXT.encode("cp949") + b"\x07"
M501_SKILL1_FIELD = M501_SKILL1_NEW + b"\x00" * (M501_SKILL1_FIELD_LEN - len(M501_SKILL1_NEW))
assert len(M501_SKILL1_OLD) == M501_SKILL1_FIELD_LEN == 21
assert len(M501_SKILL1_FIELD) == M501_SKILL1_FIELD_LEN

M501_SKILL_REGION_V0188 = bytearray(M501_SKILL_REGION_FIXED)
_i = M501_SKILL1_TEXT_OFF - M501_SKILL_REGION_START
M501_SKILL_REGION_V0188[_i:_i + M501_SKILL1_FIELD_LEN] = M501_SKILL1_FIELD
_i = M501_MULTI_TARGET_HELPER_OFF - M501_SKILL_REGION_START
M501_SKILL_REGION_V0188[_i:_i + len(M501_MULTI_TARGET_HELPER)] = M501_MULTI_TARGET_HELPER
M501_SKILL_REGION_V0188 = bytes(M501_SKILL_REGION_V0188)

# ---------------------------------------------------------------------------
# C_734 Sindy ally data / AI and FE999 explosion hook
# ---------------------------------------------------------------------------
C734_SEGMENT = 3
SINDY_TEMPLATE = 0x0212
SINDY_TEMPLATE_LEN = 36
SINDY_LEVEL = 99
SINDY_HP = 9999
SINDY_ATTACK = 2800
SINDY_DEFENSE = 1050
SINDY_AGILITY = 70

# v0.18.8: make Sindy's auto-turn hook slot-based instead of ID-byte-based.
# v0.18.7 masked [DI]'s active bit and stopped the Godwin-skill leak, but the
# actor byte can still change transiently and let the hook return to the normal
# player menu.  PL_DATA_4 is Sindy's dedicated ally slot in this battle.  The
# word at CS:0A17 is already loader-relocated to PL_DATA_4, so compare DI to
# that runtime value directly without adding a relocation:
#   cmp di,cs:[0A17h] / jne 0A8Eh / nop
SINDY_AI_OFF = 0x0A8F
SINDY_AI_STOCK = bytes.fromhex("80 3D 03 74 03 E9 C8 00")
SINDY_AI_V018X = bytes.fromhex("80 7D 01 03 75 F9 90 90")
SINDY_AI_V0187 = bytes.fromhex("8A 05 24 7F 3C 03 75 F7")
SINDY_PL_DATA4_RELOC_SOURCE = 0x0A17
SINDY_PL_DATA4_ORDINAL = 747
SINDY_AI_FIXED = bytes.fromhex("2E 3B 3E 17 0A 75 F8 90")
assert len(SINDY_AI_STOCK) == len(SINDY_AI_V018X) == len(SINDY_AI_V0187) == len(SINDY_AI_FIXED) == 8

# PC-98 C_734: 「は大きくはばたいた。」 and
# 「皇帝 ゴドウィン２世を倒した。」.  Both fit their existing Korean slots.
C734_WING_MSG_OFF = 0x02DA
C734_WING_OLD_TEXT = "는 크게 날개를 쳤다."
C734_WING_NEW_TEXT = "는 크게 날갯짓했다."
C734_WING_FIELD_LEN = 21
C734_WING_OLD = C734_WING_OLD_TEXT.encode("cp949") + b"\x07"
C734_WING_NEW = C734_WING_NEW_TEXT.encode("cp949") + b"\x07" + b"\x00"
assert len(C734_WING_OLD) == len(C734_WING_NEW) == C734_WING_FIELD_LEN
C734_BATTLE_MSG_OFF = 0x02F0
C734_BATTLE_OLD_STOCK = "황제 고드윈2세를 무찔렀다. ".encode("cp949") + b"\x07"
C734_BATTLE_OLD_CURRENT = "황제 고드윈 2세를 무찔렀다.".encode("cp949") + b"\x07"
C734_BATTLE_NEW_TEXT = "황제 고드윈 2세를 격파했다."
C734_BATTLE_NEW = C734_BATTLE_NEW_TEXT.encode("cp949") + b"\x07"
assert len(C734_BATTLE_OLD_STOCK) == len(C734_BATTLE_OLD_CURRENT) == len(C734_BATTLE_NEW) == 28

# ALGO_06 has two legitimate Sindy actions.  The branch at 0AD2 enters the
# stock fire-breath path: message "화염을 내뿜었다", ITEM_MAGIC=0Ch (Framna),
# CALC_MAG_KOKA, then EXEC_MAGIC_SUB.  PC-98 C_734 uses the same Framna path.
# v0.16.0 incorrectly NOPed this jump; v0.17.0 keeps it restored.
SINDY_FIRE_BREATH_BRANCH_OFF = 0x0AD2
SINDY_FIRE_BREATH_BRANCH = bytes.fromhex("EB 37")  # JMP 0B0Bh
SINDY_V0160_WRONG_NOP = bytes.fromhex("90 90")

ALGO09_WRAPPER = 0x05DB
FE999_HELPER = 0x0CBE
FE999_HELPER_END = 0x0CC9
EXPLOSION_ENTRY = 0x0B74
FE999_ID = 0x63


def _near(target: int, next_ip: int) -> bytes:
    return struct.pack("<H", (target - next_ip) & 0xFFFF)


# PUSH CS / CALL near helper / RETF.  The helper plays FE999 once, then jumps
# into the original explosion sequence at 0B74.
ALGO09_WRAPPER_NEW = b"\x0E\xE8" + _near(FE999_HELPER, ALGO09_WRAPPER + 4) + b"\xCB"
assert len(ALGO09_WRAPPER_NEW) == 5
FE999_HELPER_BYTES = (
    b"\xBB\x01" + bytes((FE999_ID,)) +  # mov bx,6301h (effect 63h, variant 1)
    b"\xB4\x03" +                       # mov ah,03h
    b"\xCD\x40" +                       # int 40h
    b"\xE9" + _near(EXPLOSION_ENTRY, FE999_HELPER + 10) +
    b"\x90"
)
assert len(FE999_HELPER_BYTES) == FE999_HELPER_END - FE999_HELPER == 11


def _seg3(data: bytes | bytearray) -> tuple[dict[str, int], int]:
    _, _, segs = core.ne_info(data)
    seg = segs[C734_SEGMENT - 1]
    return seg, seg["off"]


def _m501_seg3(data: bytes | bytearray) -> tuple[dict[str, int], int]:
    _, _, segs = core.ne_info(data)
    seg = segs[M501_SEGMENT - 1]
    return seg, seg["off"]


def _sindy_values(data: bytes | bytearray) -> dict[str, int]:
    seg, base = _seg3(data)
    if SINDY_TEMPLATE + SINDY_TEMPLATE_LEN > seg["len"]:
        raise PatchError("C_734 Sindy template is outside segment 3")
    p = base + SINDY_TEMPLATE
    return {
        "state": data[p + 0x00],
        "slot": data[p + 0x01],
        "level": data[p + 0x03],
        "hp": struct.unpack_from("<H", data, p + 0x04)[0],
        "max_hp": struct.unpack_from("<H", data, p + 0x06)[0],
        "int2": struct.unpack_from("<H", data, p + 0x0A)[0],
        "attack": struct.unpack_from("<H", data, p + 0x10)[0],
        "defense": struct.unpack_from("<H", data, p + 0x12)[0],
        "int": data[p + 0x15],
        "agility": data[p + 0x16],
        "luck": data[p + 0x17],
    }


def inspect_m501(data: bytes) -> dict[str, object]:
    try:
        seg, base = _m501_seg3(data)
        hp = struct.unpack_from("<H", data, base + M501_HP_CUR)[0]
        max_hp = struct.unpack_from("<H", data, base + M501_HP_MAX)[0]
        name_field = bytes(data[base + M501_NAME_OFF:base + M501_NAME_OFF + 16])
        title = bytes(data[base + M501_TITLE_OFF:base + M501_TITLE_OFF + len(M501_TITLE_FIELD)])
        quote = bytes(data[base + M501_QUOTE_OFF:base + M501_QUOTE_OFF + len(M501_QUOTE_NEW)])
        skill_region = bytes(data[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END])
        post_control = bytes(data[base + M501_POST_SKILL_CONTROL_OFF:base + M501_POST_SKILL_CONTROL_OFF + 5])
        skill_si = {off: bytes(data[base + off:base + off + 3]) for off in M501_SKILL_SI_STOCK}
        rel = core.reloc_one(data, seg, M501_SKILL1_CALL_RELOC)
        skill_renderer_stock = (
            rel[1] == 3 and (rel[2] & 7) == 1 and
            rel[4] == M501_MESSAGE_MODULE and rel[5] == M501_SKILL1_ORDINAL_STOCK
        )
        rows = core.relocation_records(data, seg)
        sources = [r[3] for r in rows]
        multi_trampoline = bytes(data[base + M501_MULTI_TARGET_CALL_OFF:base + M501_MULTI_TARGET_CALL_OFF + 5])
        multi_retry = data[base + M501_MULTI_TARGET_RETRY_DISP_OFF]
        multi_helper = bytes(data[base + M501_MULTI_TARGET_HELPER_OFF:base + M501_MULTI_TARGET_HELPER_OFF + len(M501_MULTI_TARGET_HELPER)])
        pl_data1_ref_ok = core.reloc_matches(data, seg, M501_PL_DATA1_RELOC_SOURCE, 5, 5, 1, M501_PL_DATA1_ORDINAL)
        self_target_fixed = (
            multi_trampoline == M501_MULTI_TARGET_TRAMPOLINE and
            multi_retry == M501_MULTI_TARGET_RETRY_FIXED and
            multi_helper == M501_MULTI_TARGET_HELPER and
            M501_MULTI_TARGET_RELOC_SOURCE not in sources and
            pl_data1_ref_ok
        )
        skill_fixed = (
            skill_region == M501_SKILL_REGION_V0188 and
            post_control == M501_POST_SKILL_CONTROL and
            skill_si[M501_SKILL1_SI] == M501_SKILL_SI_STOCK[M501_SKILL1_SI] and
            skill_si[M501_SKILL2_SI] == M501_SKILL_SI_STOCK[M501_SKILL2_SI] and
            skill_si[M501_SKILL3_SI] == M501_SKILL3_SI_FIXED and
            skill_renderer_stock
        )
        core_state = core.inspect_m501_bytes(data)
        code_ok = bool(core_state.get("original"))
        patched = (
            hp == M501_HP and max_hp == M501_HP and
            name_field == M501_NAME_FIELD and title == M501_TITLE_FIELD and
            quote == M501_QUOTE_NEW and code_ok and skill_fixed and self_target_fixed
        )
        return {
            "supported": bool(core_state.get("supported")) or patched,
            "patched": patched,
            "godwin_hp": hp,
            "godwin_max_hp": max_hp,
            "godwin_dynamic_actor_name": M501_NAME if name_field == M501_NAME_FIELD else name_field.rstrip(b"\0").decode("cp949", "replace"),
            "godwin_quote_speaker_stream_stock": title == M501_TITLE_FIELD,
            "godwin_quote_pc98_faithful": quote == M501_QUOTE_NEW,
            "godwin_skill3_terminated_and_relocated": skill_fixed,
            "godwin_skill1_pc98_chest_message": bytes(data[base + M501_SKILL1_TEXT_OFF:base + M501_SKILL1_TEXT_OFF + M501_SKILL1_FIELD_LEN]) == M501_SKILL1_FIELD,
            "godwin_continuous_attack_player_slots_only": self_target_fixed,
            "godwin_continuous_attack_choice_teki_reloc_removed": M501_MULTI_TARGET_RELOC_SOURCE not in sources,
            "godwin_continuous_attack_retry_rerolls": multi_retry == M501_MULTI_TARGET_RETRY_FIXED,
            "skill_renderer_import_ordinal": rel[5],
            "skill_region_sha256": sha256(skill_region),
            "legacy_wrong_transform_removed": code_ok,
            "segment_length": seg["len"],
            "segment_minalloc": seg["alloc"],
            "relocation_count": len(rows),
            "sha256": sha256(data),
        }
    except Exception as exc:
        return {"supported": False, "patched": False, "error": str(exc), "sha256": sha256(data)}


def _rollback_v018x_skill_rewrite(before: bytes) -> bytes:
    """Undo only our v0.18.2/v0.18.3 M_501 skill experiment.

    This is deliberately signature-gated. Unknown/custom skill streams are left
    alone and will be rejected later rather than guessed at.
    """
    d = bytearray(before)
    seg, base = _m501_seg3(d)
    region = bytes(d[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END])
    si = {off: bytes(d[base + off:base + off + 3]) for off in M501_SKILL_SI_STOCK}
    rel = core.reloc_one(d, seg, M501_SKILL1_CALL_RELOC)
    rel_ord = rel[5]
    is_v018x = (
        region == M501_SKILL_REGION_V018X and
        all(si[k] == v for k, v in M501_SKILL_SI_V018X.items()) and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_V018X
    )
    is_stock = (
        region == M501_SKILL_REGION_STOCK and
        all(si[k] == v for k, v in M501_SKILL_SI_STOCK.items()) and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_STOCK
    )
    is_v0187 = (
        region == M501_SKILL_REGION_FIXED and
        si[M501_SKILL1_SI] == M501_SKILL_SI_STOCK[M501_SKILL1_SI] and
        si[M501_SKILL2_SI] == M501_SKILL_SI_STOCK[M501_SKILL2_SI] and
        si[M501_SKILL3_SI] == M501_SKILL3_SI_FIXED and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_STOCK
    )
    is_v0188 = (
        region == M501_SKILL_REGION_V0188 and
        si[M501_SKILL1_SI] == M501_SKILL_SI_STOCK[M501_SKILL1_SI] and
        si[M501_SKILL2_SI] == M501_SKILL_SI_STOCK[M501_SKILL2_SI] and
        si[M501_SKILL3_SI] == M501_SKILL3_SI_FIXED and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_STOCK
    )
    if is_stock or is_v0187 or is_v0188:
        return before
    if not is_v018x:
        raise PatchError(
            "M_501 skill stream is neither stock/v0.18.1 nor the exact v0.18.2/v0.18.3 experimental state"
        )
    d[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END] = M501_SKILL_REGION_STOCK
    d[base + M501_POST_SKILL_CONTROL_OFF:base + M501_POST_SKILL_CONTROL_OFF + 5] = M501_POST_SKILL_CONTROL
    for off, raw in M501_SKILL_SI_STOCK.items():
        d[base + off:base + off + 3] = raw
    core.set_reloc_target(d, seg, M501_SKILL1_CALL_RELOC, 1, M501_MESSAGE_MODULE, M501_SKILL1_ORDINAL_STOCK)
    return bytes(d)

def patch_m501(before: bytes) -> bytes:
    if inspect_m501(before).get("patched"):
        return before

    # First undo only the v0.18.2/v0.18.3 skill experiment if present. This is
    # the user-requested rollback: no skill strings, renderers or control streams
    # remain modified by the final-battle component.
    normalized = _rollback_v018x_skill_rewrite(before)

    # Then remove the much older v1.0.63 experimental transform if needed.
    try:
        d = bytearray(core.restore_m501_bytes(normalized))
    except Exception as exc:
        raise PatchError(f"M_501 base state is unsupported: {exc}") from exc

    seg, base = _m501_seg3(d)
    # Reassert stock skill bytes after legacy normalization. No-growth/no-relayout.
    d[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END] = M501_SKILL_REGION_STOCK
    d[base + M501_POST_SKILL_CONTROL_OFF:base + M501_POST_SKILL_CONTROL_OFF + 5] = M501_POST_SKILL_CONTROL
    for off, raw in M501_SKILL_SI_STOCK.items():
        d[base + off:base + off + 3] = raw
    core.set_reloc_target(d, seg, M501_SKILL1_CALL_RELOC, 1, M501_MESSAGE_MODULE, M501_SKILL1_ORDINAL_STOCK)

    # Fix only the malformed third skill without moving any live stream.  The
    # stock 00A6 bytes stay untouched; only the verified zero pad and the one
    # MOV SI immediate used by skill 3 change.
    pad = bytes(d[base + M501_SKILL3_FIXED_OFF:base + M501_SKILL3_FIXED_OFF + M501_SKILL3_PAD_LEN])
    if pad not in (b"\x00" * M501_SKILL3_PAD_LEN, M501_SKILL3_FIELD):
        raise PatchError(f"M_501 0062..007F is not the verified skill-3 pad: {pad.hex(' ')}")
    d[base + M501_SKILL3_FIXED_OFF:base + M501_SKILL3_FIXED_OFF + M501_SKILL3_PAD_LEN] = M501_SKILL3_FIELD
    d[base + M501_SKILL3_SI:base + M501_SKILL3_SI + 3] = M501_SKILL3_SI_FIXED

    # PC-98-faithful skill-1 wording, in the original fixed slot.
    old_skill1 = bytes(d[base + M501_SKILL1_TEXT_OFF:base + M501_SKILL1_TEXT_OFF + M501_SKILL1_FIELD_LEN])
    if old_skill1 not in (M501_SKILL1_OLD, M501_SKILL1_FIELD):
        raise PatchError(f"M_501 skill-1 message signature differs: {old_skill1.hex(' ')}")
    d[base + M501_SKILL1_TEXT_OFF:base + M501_SKILL1_TEXT_OFF + M501_SKILL1_FIELD_LEN] = M501_SKILL1_FIELD

    # Continuous attack must never call the side-sensitive shared CHOICE_TEKI.
    # Reuse the now-unreferenced malformed old skill-3 bytes as a tiny selector
    # helper.  A dead target retries at RANDOM (0362h), not at the helper, so a
    # different player slot is selected on each retry.
    d[base + M501_MULTI_TARGET_HELPER_OFF:base + M501_MULTI_TARGET_HELPER_OFF + len(M501_MULTI_TARGET_HELPER)] = M501_MULTI_TARGET_HELPER
    old_call = bytes(d[base + M501_MULTI_TARGET_CALL_OFF:base + M501_MULTI_TARGET_CALL_OFF + 5])
    sources = {r[3] for r in core.relocation_records(d, seg)}
    if M501_MULTI_TARGET_RELOC_SOURCE in sources:
        if old_call != b"\x9A\xFF\xFF\x00\x00":
            raise PatchError(f"M_501 continuous-attack CHOICE_TEKI call differs: {old_call.hex(' ')}")
        d[base + M501_MULTI_TARGET_CALL_OFF:base + M501_MULTI_TARGET_CALL_OFF + 5] = M501_MULTI_TARGET_TRAMPOLINE
        core.remove_reloc_sources(d, seg, {M501_MULTI_TARGET_RELOC_SOURCE})
    elif old_call != M501_MULTI_TARGET_TRAMPOLINE:
        raise PatchError("M_501 continuous-attack relocation is absent but trampoline is not present")
    retry = d[base + M501_MULTI_TARGET_RETRY_DISP_OFF]
    if retry not in (M501_MULTI_TARGET_RETRY_STOCK, M501_MULTI_TARGET_RETRY_FIXED):
        raise PatchError(f"M_501 continuous-attack retry differs: {retry:02X}")
    d[base + M501_MULTI_TARGET_RETRY_DISP_OFF] = M501_MULTI_TARGET_RETRY_FIXED

    struct.pack_into("<H", d, base + M501_HP_CUR, M501_HP)
    struct.pack_into("<H", d, base + M501_HP_MAX, M501_HP)
    # Critical minimal fix: dynamic skill-name path gets the stock actor name.
    # Do NOT inject the expanded title into this buffer.
    d[base + M501_NAME_OFF:base + M501_NAME_OFF + 16] = M501_NAME_FIELD
    # Restore the stock quote-only speaker composition and replace only the quote
    # sentence itself.  The next control/data streams are untouched.
    d[base + M501_TITLE_OFF:base + M501_TITLE_OFF + len(M501_TITLE_FIELD)] = M501_TITLE_FIELD
    old_quote = bytes(d[base + M501_QUOTE_OFF:base + M501_QUOTE_OFF + len(M501_QUOTE_NEW)])
    if old_quote not in (M501_QUOTE_OLD, M501_QUOTE_V01810, M501_QUOTE_NEW):
        raise PatchError(f"M_501 quote signature differs: {old_quote.hex(' ')}")
    d[base + M501_QUOTE_OFF:base + M501_QUOTE_OFF + len(M501_QUOTE_NEW)] = M501_QUOTE_NEW

    out = bytes(d)
    st = inspect_m501(out)
    if not st.get("patched"):
        raise PatchError(f"M_501 v0.18.11 verification failed: {st}")
    return out

def _inspect_v014_dynamic(data: bytes) -> dict[str, object]:
    """Recognize the v0.14 presentation code inside a later tail-expanded segment.

    Scene Editor v0.5.x may append out-of-line message fragments to C_734 and add
    relocation rows.  Those additions do not move the original 0000..0CDD code,
    so validate the required code and relocation sources instead of demanding the
    historical exact segment length/relocation count.
    """
    try:
        _, _, segs = core.ne_info(data)
        seg = segs[C734_SEGMENT - 1]
        base = seg["off"]
        rows = core.relocation_records(data, seg)
        nextoff = core.next_segment_offset(segs, seg)
        rend = base + seg["len"] + 2 + len(rows) * 8
        reveal_ok = core._reveal_state(data, seg)[1]
        timing_ok = core._timing_state(data, seg)[1]
        final_ok = bytes(data[base + v140.FINAL_START:base + v140.FINAL_END]) == v140.FINAL
        pre_ok = bytes(data[base + v140.PRE_HELPER:base + v140.PRE_HELPER_END]) == v140.v130.C734_V074_PRE_HELPER
        post_ok = bytes(data[base + v140.POST_HELPER:base + v140.POST_HELPER_END]) == v140.v130.C734_V074_POST_HELPER
        zero_ok = bytes(data[base + 0x057E:base + 0x059C]) == b"\0" * 30
        rel_ok = all(core.reloc_matches(data, seg, src, *exp) for src, exp in v140.EXPECTED.items())
        sources = [r[3] for r in rows]
        rel_ok = rel_ok and all(src not in sources for src in v140.RETIRED) and len(sources) == len(set(sources))
        structure_ok = (
            seg["len"] >= v140.SEG_LEN and seg["alloc"] == seg["len"] and rend <= nextoff
        )
        ok = bool(reveal_ok and timing_ok and final_ok and pre_ok and post_ok and zero_ok and rel_ok and structure_ok)
        return {
            "patched": ok,
            "tail_expanded": seg["len"] > v140.SEG_LEN,
            "field_scene_restored": bool(reveal_ok and timing_ok),
            "relocations_ok": rel_ok,
            "segment_structure_ok": structure_ok,
            "segment_length": seg["len"],
            "segment_minalloc": seg["alloc"],
            "relocation_count": len(rows),
            "relocation_table_end": rend,
            "next_segment_offset": nextoff,
        }
    except Exception as exc:
        return {"patched": False, "error": str(exc)}


def inspect_c734(data: bytes) -> dict[str, object]:
    try:
        base_state = _inspect_v014_dynamic(data)
        seg, base = _seg3(data)
        vals = _sindy_values(data)
        ai = bytes(data[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8])
        fire_branch = bytes(data[base + SINDY_FIRE_BREATH_BRANCH_OFF:base + SINDY_FIRE_BREATH_BRANCH_OFF + 2])
        wrapper = bytes(data[base + ALGO09_WRAPPER:base + ALGO09_WRAPPER + 5])
        helper = bytes(data[base + FE999_HELPER:base + FE999_HELPER_END])
        sindy_ok = (
            vals["state"] == 0x83 and vals["slot"] == 0x03 and
            vals["level"] == SINDY_LEVEL and vals["hp"] == SINDY_HP and vals["max_hp"] == SINDY_HP and
            vals["attack"] == SINDY_ATTACK and vals["defense"] == SINDY_DEFENSE and vals["agility"] == SINDY_AGILITY
        )
        ai_ok = ai == SINDY_AI_FIXED
        pl_data4_ref_ok = core.reloc_matches(data, seg, SINDY_PL_DATA4_RELOC_SOURCE, 5, 5, 1, SINDY_PL_DATA4_ORDINAL)
        fire_breath_ok = fire_branch == SINDY_FIRE_BREATH_BRANCH
        fe_ok = wrapper == ALGO09_WRAPPER_NEW and helper == FE999_HELPER_BYTES
        patched = bool(base_state.get("patched") and sindy_ok and ai_ok and pl_data4_ref_ok and fire_breath_ok and fe_ok)
        return {
            "supported": patched,
            "patched": patched,
            "v0_14_base": bool(base_state.get("patched")),
            "tail_expanded_by_scene_text": bool(base_state.get("tail_expanded")),
            "sindy": vals,
            "sindy_strengthened": sindy_ok,
            "sindy_auto_control_slot_gate": ai_ok and pl_data4_ref_ok,
            "sindy_player_menu_blocked_by_pl_data4_slot": ai_ok and pl_data4_ref_ok,
            "sindy_fire_breath_enabled": fire_breath_ok,
            "sindy_fire_breath_branch": fire_branch.hex(" "),
            "sindy_fire_breath_magic_id": 12,
            "fe999_at_explosion_start": fe_ok,
            "fe999_effect_id": FE999_ID,
            "segment_length": seg["len"],
            "segment_minalloc": seg["alloc"],
            "relocation_count": base_state.get("relocation_count"),
            "relocations_ok": base_state.get("relocations_ok"),
            "sha256": sha256(data),
        }
    except Exception as exc:
        return {"supported": False, "patched": False, "error": str(exc), "sha256": sha256(data)}


def patch_c734(before: bytes) -> bytes:
    if inspect_c734(before).get("patched"):
        return before
    # Normalize all historical final-battle presentation states to v0.14 first.
    d = bytearray(v140.patch_c734(before))
    seg, base = _seg3(d)

    # Sindy combat template: keep her stock Lv99/HP9999/INT2/LUCK, strengthen
    # physical contribution and survivability, and slightly raise agility.
    p = base + SINDY_TEMPLATE
    if d[p] != 0x83 or d[p + 1] != 0x03 or d[p + 3] != 99:
        raise PatchError("C_734 Sindy template signature does not match")
    struct.pack_into("<H", d, p + 0x04, SINDY_HP)
    struct.pack_into("<H", d, p + 0x06, SINDY_HP)
    struct.pack_into("<H", d, p + 0x10, SINDY_ATTACK)
    struct.pack_into("<H", d, p + 0x12, SINDY_DEFENSE)
    d[p + 0x16] = SINDY_AGILITY

    # Sindy is always the PL_DATA_4 ally in this battle.  Gate her automatic
    # action by the slot pointer itself so transient actor/state-byte changes can
    # never expose the normal player command menu.  The older ID-byte gates are
    # accepted only for migration.
    old_ai = bytes(d[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8])
    if old_ai not in (SINDY_AI_STOCK, SINDY_AI_V018X, SINDY_AI_V0187, SINDY_AI_FIXED):
        raise PatchError(f"C_734 ALGO_06 signature differs: {old_ai.hex(' ')}")
    if not core.reloc_matches(d, seg, SINDY_PL_DATA4_RELOC_SOURCE, 5, 5, 1, SINDY_PL_DATA4_ORDINAL):
        raise PatchError("C_734 PL_DATA_4 relocation at 0A17h differs")
    d[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8] = SINDY_AI_FIXED

    # Restore Sindy's stock fire-breath branch.  v0.16.0 replaced EB 37 with
    # NOP NOP by mistake.  Accept both states for migration, then force EB 37.
    old_fire_branch = bytes(d[base + SINDY_FIRE_BREATH_BRANCH_OFF:base + SINDY_FIRE_BREATH_BRANCH_OFF + 2])
    if old_fire_branch not in (SINDY_FIRE_BREATH_BRANCH, SINDY_V0160_WRONG_NOP):
        raise PatchError(f"C_734 Sindy fire-breath branch differs: {old_fire_branch.hex(' ')}")
    d[base + SINDY_FIRE_BREATH_BRANCH_OFF:base + SINDY_FIRE_BREATH_BRANCH_OFF + 2] = SINDY_FIRE_BREATH_BRANCH

    # Play FE999 exactly once immediately before the existing Godwin explosion
    # visual loop.  v0.14 left CBE..CC8 as verified free/NOP space.
    existing_helper = bytes(d[base + FE999_HELPER:base + FE999_HELPER_END])
    if existing_helper not in (b"\x90" * 11, FE999_HELPER_BYTES):
        raise PatchError(f"C_734 FE999 helper slot is not free: {existing_helper.hex(' ')}")
    d[base + FE999_HELPER:base + FE999_HELPER_END] = FE999_HELPER_BYTES
    d[base + ALGO09_WRAPPER:base + ALGO09_WRAPPER + 5] = ALGO09_WRAPPER_NEW

    out = bytes(d)
    st = inspect_c734(out)
    if not st.get("patched"):
        raise PatchError(f"C_734 v0.18.11 verification failed: {st}")
    return out


def _scene_interop_paths() -> tuple[Path, Path] | None:
    """Locate the consolidated dialogue owner's scene editor and data directory."""
    bundle = Path(__file__).resolve().parent.parent
    packs = sorted(
        (p for p in bundle.glob("ED2_Text_and_Dialogue_Revision_Pack_v*") if p.is_dir()),
        key=lambda p: p.name, reverse=True,
    )
    for text_pack in packs:
        scene_dir = text_pack / "scene_editor"
        data_dir = text_pack / "data"
        if (scene_dir / "ed2_scene_editor.py").is_file() and (data_dir / "c734_dialogue.csv").is_file():
            return scene_dir, data_dir
    return None

def _reapply_c734_scene_text(root: Path, scene_dir: Path, csv_dir: Path) -> int:
    """Reapply only C_734 v4 text after the final-battle core is normalized."""
    # Use a unique module name/search path so the final-battle compatibility
    # cores cannot shadow the Scene Editor's helper modules.
    old_path = list(sys.path)
    try:
        sys.path.insert(0, str(scene_dir))
        from ed2_scene_editor import SceneProject
        # The consolidated dialogue pack stores only the verified C_734 rows
        # needed after final-battle canonicalization.
        candidates = [csv_dir / "c734_dialogue.csv"]
        errors = []
        for source in candidates:
            if not source.is_file():
                continue
            import csv
            with source.open("r", newline="", encoding="utf-8-sig") as fp:
                rd = csv.DictReader(fp)
                fields = rd.fieldnames
                rows = [row for row in rd if row.get("dll") == "C_734.DLL"]
            if not rows or not fields:
                continue
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding="utf-8-sig", newline="") as tf:
                    wr = csv.DictWriter(tf, fieldnames=fields)
                    wr.writeheader(); wr.writerows(rows)
                    tmp_path = Path(tf.name)
                project = SceneProject(root)
                return project.import_strings_csv(tmp_path, dialogues_only=False)
            except Exception as exc:
                errors.append(f"{source.name}: {exc}")
            finally:
                if tmp_path is not None:
                    tmp_path.unlink(missing_ok=True)
        raise PatchError("C_734 v4 text reapply failed: " + " | ".join(errors))
    finally:
        sys.path[:] = old_path


# Known C_734 presentation bytes (legacy and v1.4.46 semantic reflow sites).  These are owned by the
# dialogue-linebreak layer, not by Scene Editor itself.  During AIO's
# pre-dialogue final-battle normalization they must be temporarily restored
# to spaces so selective_restore() does not mistake our own stacked change
# for an unknown third-party edit.
_C734_LINEBREAK_FILE_OFFSETS = (0x37BE, 0x37C3, 0x37E7, 0x37EF, 0x3813, 0x3878, 0x387D, 0x3886, 0x38BE, 0x38C7, 0x3902, 0x390E)

def _normalize_c734_linebreak_for_pre_dialogue(path: Path) -> list[int]:
    data = bytearray(path.read_bytes())
    changed = []
    for off in _C734_LINEBREAK_FILE_OFFSETS:
        if off < len(data) and data[off] == 0x01:
            data[off] = 0x20
            changed.append(off)
    if changed:
        atomic_write(path, bytes(data), None)
    return changed

def _patch_c734_with_scene_interop(root: Path, make_backup: bool, pre_dialogue: bool = False) -> tuple[bytes, bytes, bool]:
    cp = root / "SCENA" / "C_734.DLL"
    original = cp.read_bytes()
    if inspect_c734(original).get("patched"):
        return original, original, False
    try:
        patched = patch_c734(original)
        return original, patched, False
    except Exception as first_exc:
        paths = _scene_interop_paths()
        journal = Path(str(cp) + ".ed2_scene_editor.journal.json")
        if paths is None or not journal.is_file():
            raise first_exc
        scene_dir, csv_dir = paths
        # Preserve the user's pre-v0.18 file as the standalone backup, even
        # though the internal canonicalization temporarily restores its text.
        if make_backup:
            bak = Path(str(cp) + ".final_battle_presentation.bak")
            if not bak.exists():
                shutil.copy2(cp, bak)
        # In AIO pre-dialogue mode the current C_734 text is about to be
        # rebuilt from the newest canonical dialogue CSV anyway.  First undo
        # only the known Linebreak-owned 01h bytes so Scene Editor's journal
        # can be restored without a false overlap conflict.
        normalized_breaks = []
        if pre_dialogue:
            normalized_breaks = _normalize_c734_linebreak_for_pre_dialogue(cp)
        old_path = list(sys.path)
        try:
            sys.path.insert(0, str(scene_dir))
            from ed2_patch_journal import selective_restore
            selective_restore(cp, "ed2_scene_editor")
        finally:
            sys.path[:] = old_path
        restored = cp.read_bytes()
        core_patched = patch_c734(restored)
        atomic_write(cp, core_patched, None)
        if pre_dialogue:
            # Do not reinsert an old dialogue generation here.  The AIO calls
            # this mode only immediately before its current dialogue pass.
            st = inspect_c734(core_patched)
            if not st.get("patched"):
                raise PatchError(f"C_734 pre-dialogue normalization verification failed: {st}")
            return original, core_patched, True
        _reapply_c734_scene_text(root, scene_dir, csv_dir)
        final = cp.read_bytes()
        st = inspect_c734(final)
        if not st.get("patched"):
            raise PatchError(f"C_734 v4 interop verification failed: {st}")
        return original, final, True


def validate_root(root: Path) -> Path:
    return v140.validate_root(Path(root))


def repair_ed2main(root: Path, make_backup: bool = True):
    return v140.repair_ed2main(Path(root), make_backup)


def inspect_patch(root: Path) -> dict[str, object]:
    root = validate_root(root)
    e = core.inspect_ed2main_bytes((root / "ED2MAIN.EXE").read_bytes())
    m = inspect_m501((root / "MON" / "M_501.DLL").read_bytes())
    c = inspect_c734((root / "SCENA" / "C_734.DLL").read_bytes())
    return {
        "tool_version": VERSION,
        "ed2main": e,
        "m501": m,
        "c734": c,
        "ok": bool(e.get("stable") and m.get("patched") and c.get("patched")),
    }


def apply_patch(root: Path, make_backup: bool = True, pre_dialogue: bool = False) -> dict[str, object]:
    root = validate_root(root)
    er = repair_ed2main(root, make_backup)

    mp = root / "MON" / "M_501.DLL"
    mb = mp.read_bytes()
    ma = patch_m501(mb)
    if ma != mb:
        atomic_write(mp, ma, ".final_battle_presentation.bak" if make_backup else None)

    cp = root / "SCENA" / "C_734.DLL"
    # v1.3.71 All-In-One is stock-only.  By the time this late component runs,
    # R25 dialogue has already installed a tail-expanded C_734 text layout.
    # Do not replay historical C_734 normalization against that layout; deploy
    # the prevalidated final-battle+current-dialogue text target directly.
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1" and not pre_dialogue:
        target_path = Path(__file__).resolve().parent / "ED2_STOCK_C734_FINAL_TEXT_TARGET.bin"
        if not target_path.is_file():
            raise PatchError("stock-only C_734 final target is missing")
        cb = cp.read_bytes()
        ca = target_path.read_bytes()
        target_state = inspect_c734(ca)
        if not target_state.get("patched"):
            raise PatchError(f"stock-only C_734 final target verification failed: {target_state}")
        scene_rebased = False
        if ca != cb:
            atomic_write(cp, ca, None)
    else:
        cb, ca, scene_rebased = _patch_c734_with_scene_interop(root, make_backup, pre_dialogue=pre_dialogue)
        if ca != cb and not scene_rebased:
            atomic_write(cp, ca, ".final_battle_presentation.bak" if make_backup else None)

    st = inspect_patch(root)
    if not st["ok"]:
        raise PatchError("final verification failed")
    return {
        "ed2main_repair": er,
        "m501_changed": ma != mb,
        "c734_changed": ca != cb,
        "c734_scene_text_rebased": scene_rebased,
        "state": st,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    ap.add_argument("root", type=Path)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--apply", action="store_true")
    g.add_argument("--check", action="store_true")
    g.add_argument("--repair-ed2main-only", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--pre-dialogue", action="store_true", help="AIO-only: normalize C_734 core before the current dialogue pass")
    args = ap.parse_args()
    try:
        if args.repair_ed2main_only:
            result = repair_ed2main(args.root, not args.no_backup)
        elif args.check:
            result = inspect_patch(args.root)
        else:
            result = apply_patch(args.root, not args.no_backup, pre_dialogue=args.pre_dialogue)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print("ERROR:", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
