#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, struct, tempfile
from pathlib import Path
from typing import Any

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.5.0"

# Unsafe v0.1.0 / ED2 v1.0.61 ED2MAIN repair only. v0.4.0 does not add
# any new ED2MAIN code.
BAD_WRAPPER_SEGMENT = 2
BAD_WRAPPER_OLD_LEN = 0x1B3B
BAD_BANK = 0x3EC3
BAD_RELOCS = ((86, 0x2EF0), (86, 0x2F33), (86, 0x2F70), (86, 0x2FAC))
ORIGINAL_TARGET = (3, 0x1069)

# C_734 final-battle field/interstitial scene.
# v0.5.0 also repairs the broken custom full-screen reveal and makes the
# final palette fade target truly black at runtime.
C734_SEGMENT = 3
C734_EXPECTED_SEGMENT_LENGTH = 0x0CBE
C734_NEG_DSP_BANK_ORDINAL = 62
C734_CUR_DSP_BANK_ORDINAL = 66

# v0.3.0 / ED2 v1.0.64 wrong CRTC-wrapper experiment.  This area is supposed
# to be zero; 057E onward is also the zero-palette target used by the final
# fade-to-black.
C734_CAVE = 0x057A
C734_CAVE_SIZE = 38
C734_OLD_WRAPPER_NEG_SOURCE = 0x057B
C734_OLD_WRAPPER_BANK_SOURCE = 0x0585
C734_TRANSFORM_NEG_SOURCES = (0x0623, 0x065A, 0x068B, 0x06A9, 0x06C7, 0x06E6)
C734_OLD_DISPLAY_WRAPPER = (
    b"\x9A\xFF\xFF\x00\x00\x9C\x50\x53\x52\x8B\x1E\xFF\xFF\x83\xE3\x01\xD1\xCB"
    b"\xBA\xD4\x03\x8A\xE3\xB0\x0D\xEF\x8A\xE7\xB0\x0C\xEF\x5A\x5B\x58\x9D\xCB"
)
assert len(C734_OLD_DISPLAY_WRAPPER) == 36

# Actual field-scene bug.  The Korean ED2MAIN GET_BGM_CLOCK import used at
# C_734:077F returns the sentinel 8000h, so the intended loop exits after one
# timed frame.  Replace the clock test with an explicit 0100h-frame loop while
# keeping the original local motion update, NEG_DSP_BANK, and ETC_DELAY calls.
C734_TIMING_START = 0x076C
C734_TIMING_END = 0x0789
C734_TIMING_ORIGINAL = (
    b"\xC6\x06\x00\x00\x01"      # mov ETC_SKIP,1
    b"\x0E\xE8\x37\x00"          # call local 07AC
    b"\x9A\xFF\xFF\x00\x00"    # NEG_DSP_BANK
    b"\x9A\xFF\xFF\x00\x00"    # ETC_DELAY
    b"\x9A\xFF\xFF\x00\x00"    # GET_BGM_CLOCK
    b"\x3D\x00\x01"              # cmp ax,0100h
    b"\x72\xE3"                    # jb 076Ch
)
C734_TIMING_PATCHED = (
    b"\xB9\x00\x01"              # mov cx,0100h
    b"\xC6\x06\x00\x00\x01"    # mov ETC_SKIP,1
    b"\x0E\xE8\x34\x00"          # call local 07AC
    b"\x9A\xFF\xFF\x00\x00"    # NEG_DSP_BANK
    b"\x9A\xFF\xFF\x00\x00"    # ETC_DELAY
    b"\xE2\xEB"                    # loop 076Fh
    b"\x90\x90\x90\x90\x90"
)
assert len(C734_TIMING_ORIGINAL) == len(C734_TIMING_PATCHED) == C734_TIMING_END - C734_TIMING_START
C734_TIMING_RELOC_MOVE = {
    0x076E: 0x0771,  # ETC_SKIP data fixup
    0x0776: 0x0779,  # NEG_DSP_BANK
    0x077B: 0x077E,  # ETC_DELAY
}
C734_GET_BGM_CLOCK_SOURCE = 0x0780
C734_TIMING_EXPECTED_RELOCS = {
    0x076E: (5, 5, 1, 255),
    0x0776: (3, 1, 1, 62),
    0x077B: (3, 1, 1, 257),
    0x0780: (3, 1, 1, 106),
}
C734_TIMING_PATCHED_RELOCS = {
    0x0771: (5, 5, 1, 255),
    0x0779: (3, 1, 1, 62),
    0x077E: (3, 1, 1, 257),
}

# The special SAVE_FLAG==2 scene uses a hand-written copy of OPEN_WIND at
# 3:0743.  The Korean port passes C_734's own segment 4 to WIND_SET_SUB.
# Segment 4 is a 0x3FE2-byte all-zero private buffer and no code populates it
# before this route, so the reveal clears bits in an empty buffer and the
# scene remains black.  Use ED2MAIN's canonical OPEN_WIND instead.  With
# SPOT_LN=29h, OPEN_WIND uses the engine's actual window/screen buffer and
# performs the same 20-step full-screen reveal.
C734_OPEN_WIND_ORDINAL = 925
C734_WIND_SET_SUB_ORDINAL = 923
C734_CUR_ACC_TEXT_ORDINAL = 51
C734_REVEAL_START = 0x0743
C734_REVEAL_END = 0x076C
C734_REVEAL_ORIGINAL = (
    b"\xBF\x0E\x07"          # mov di,070Eh
    b"\xBA\x01\xCC"          # mov dx,CC01h
    b"\xB9\x14\x00"          # mov cx,20
    b"\xB8\xFF\xFF"          # mov ax,<C_734 seg4>
    b"\x57\x52"                  # push di / push dx
    b"\x9A\xFF\xFF\x00\x00" # WIND_SET_SUB
    b"\x0E\xE8\x52\x00"      # call local 07ACh
    b"\x9A\xFF\xFF\x00\x00" # NEG_DSP_BANK
    b"\x5A\x5F"                  # pop dx / pop di
    b"\x9A\xFF\xFF\x00\x00" # WIND_SET_SUB
    b"\x2B\x3E\x00\x00"      # sub di,CUR_ACC_TEXT
    b"\xE2\xE3"                  # loop 074Fh
)
C734_REVEAL_PATCHED = (
    b"\x90" * 14 +
    b"\x9A\xFF\xFF\x00\x00" + # OPEN_WIND at original call site
    b"\xEB\x14" +                  # jump to fixed timed-motion loop 076Ch
    b"\x90" * 20
)
assert len(C734_REVEAL_ORIGINAL) == len(C734_REVEAL_PATCHED) == C734_REVEAL_END-C734_REVEAL_START
C734_REVEAL_INTERNAL_SEG4_SOURCE = 0x074D
C734_REVEAL_CALL_SOURCE = 0x0752
C734_REVEAL_NEG_SOURCE = 0x075B
C734_REVEAL_SECOND_WIND_SOURCE = 0x0762
C734_REVEAL_CUR_ACC_SOURCE = 0x0768
C734_REVEAL_REMOVE_SOURCES = {
    C734_REVEAL_INTERNAL_SEG4_SOURCE, C734_REVEAL_NEG_SOURCE,
    C734_REVEAL_SECOND_WIND_SOURCE, C734_REVEAL_CUR_ACC_SOURCE,
}
C734_REVEAL_EXPECTED_RELOCS = {
    0x074D: (2, 0, 4, 0),
    0x0752: (3, 1, 1, C734_WIND_SET_SUB_ORDINAL),
    0x075B: (3, 1, 1, C734_NEG_DSP_BANK_ORDINAL),
    0x0762: (3, 1, 1, C734_WIND_SET_SUB_ORDINAL),
    0x0768: (5, 5, 1, C734_CUR_ACC_TEXT_ORDINAL),
}

# Final fade preparation.  Stock C_734 copies the *current* PAL_DATA into the
# 30-byte target at 057Eh, so the later 15-step loop does not fade to black.
# Fill that target with 15 zero words at runtime instead.  Same 11-byte slot.
C734_FADE_PREP_START = 0x0B69
C734_FADE_PREP_END = 0x0B74
C734_FADE_PREP_ORIGINAL = b"\xBE\x00\x00\xBF\x7E\x05\xB9\x0F\x00\xF3\xA5"
C734_FADE_PREP_PATCHED = b"\x31\xC0\xBF\x7E\x05\xB9\x0F\x00\xF3\xAB\x90"
assert len(C734_FADE_PREP_ORIGINAL)==len(C734_FADE_PREP_PATCHED)==11
C734_FADE_PREP_PAL_SOURCE = 0x0B6A

# Final sequence.  The completed explosion is held for 150 ticks *before*
# clearing the battle display.  Then the defeat message is shown; as soon as
# the message returns, the pre-existing 15-step palette fade at 0BDC starts,
# followed by _THEEND.
C734_FINAL_START = 0x0BA9
C734_FINAL_END = 0x0BDC
C734_HOLD_TICKS = 0x96
C734_FINAL_ORIGINAL_BASE = (
    b"\xBF\x00\x00" +
    b"\x9A\xFF\xFF\x00\x00" * 5 +
    b"\xBE\xEF\x02" +
    b"\x9A\xFF\xFF\x00\x00" * 2 +
    b"\xC6\x06\x00\x00\x78" +
    b"\x9A\xFF\xFF\x00\x00"
)
C734_FINAL_PATCHED = (
    b"\xC6\x06\xFF\xFF\x96" +   # ETC_SKIP=150
    b"\x9A\xFF\xFF\x00\x00" + # ETC_DELAY
    b"\xBF\xFF\xFF" +             # EN_DATA_1
    b"\x9A\xFF\xFF\x00\x00" * 5 +
    b"\xBE\xEF\x02" +
    b"\x9A\xFF\xFF\x00\x00" * 2
)
assert len(C734_FINAL_ORIGINAL_BASE) == len(C734_FINAL_PATCHED) == 51
C734_FINAL_RELOC_MOVE = {
    0x0BD4: 0x0BAB, # ETC_SKIP
    0x0BD8: 0x0BAF, # ETC_DELAY
    0x0BAA: 0x0BB4, # EN_DATA_1
    0x0BAD: 0x0BB7, # CLR_MON
    0x0BB2: 0x0BBC, # CLR_MON_STS
    0x0BB7: 0x0BC1, # NEG_DSP_BANK
    0x0BBC: 0x0BC6, # CLR_MON
    0x0BC1: 0x0BCB, # CLR_MON_STS
    0x0BC9: 0x0BD3, # DISP_MESS_LOW
    0x0BCE: 0x0BD8, # COPY_MESS
}
C734_FINAL_EXPECTED_RELOCS = {
    0x0BD4: (5, 5, 1, 255),
    0x0BD8: (3, 1, 1, 257),
    0x0BAA: (5, 5, 1, 682),
    0x0BAD: (3, 1, 1, 303),
    0x0BB2: (3, 1, 1, 887),
    0x0BB7: (3, 1, 1, 62),
    0x0BBC: (3, 1, 1, 303),
    0x0BC1: (3, 1, 1, 887),
    0x0BC9: (3, 1, 1, 599),
    0x0BCE: (3, 1, 1, 55),
}
C734_FINAL_PATCHED_RELOCS = {
    C734_FINAL_RELOC_MOVE[k]: v for k, v in C734_FINAL_EXPECTED_RELOCS.items()
}

# M_501 v0.2.0 / ED2 v1.0.63 wrong-target palette experiment.  v0.4.0 does
# NOT patch M_501 for the field scene; it only removes that released experiment
# if it is encountered during an upgrade.
M501_SEGMENT = 3
M501_EXPECTED_SEGMENT_LENGTH = 0x076A
M501_SPECIAL_PAL_CALL_SOURCE = 0x0573
M501_FINAL_PAL_CALL_SOURCE = 0x05E6
M501_DS_MON_ORDINAL = 310
M501_ST_MON_PAL_ORDINAL = 647
M501_ORIGINAL_BYTES = {
    0x0562: b"\x09\x00",
    0x0593: b"\x88\x45\x01",
    0x0596: b"\x88\x65\x07",
    0x05A2: b"\x88\x45\x0A",
    0x05A5: b"\x88\x65\x10",
    0x05B9: b"\xBF\xE8\x01",
    0x05EA: b"\x8A\x45\x02",
}
M501_EXPERIMENTAL_BYTES = {
    0x0562: b"\x00\x00",
    0x0593: b"\x90\x90\x90",
    0x0596: b"\x90\x90\x90",
    0x05A2: b"\x90\x90\x90",
    0x05A5: b"\x90\x90\x90",
    0x05B9: b"\xE9\x18\x00",
    0x05EA: b"\xE9\x57\x00",
}

class PatchError(RuntimeError):
    pass

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def u16(data: bytes | bytearray, off: int) -> int:
    return int.from_bytes(data[off:off+2], "little")

def p16(data: bytearray, off: int, value: int) -> None:
    data[off:off+2] = int(value).to_bytes(2, "little")

def atomic_write(path: Path, data: bytes, backup_suffix: str | None = None) -> None:
    if backup_suffix:
        backup = path.with_name(path.name + backup_suffix)
        if not backup.exists():
            shutil.copy2(path, backup)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data); fp.flush(); os.fsync(fp.fileno())
        os.replace(tmp, path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def ne_info(data: bytes | bytearray):
    if data[:2] != b"MZ": raise PatchError("MZ 실행 파일/DLL이 아닙니다.")
    ne = int.from_bytes(data[0x3C:0x40], "little")
    if data[ne:ne+2] != b"NE": raise PatchError("NE 실행 파일/DLL이 아닙니다.")
    count = u16(data, ne+0x1C); st = ne + u16(data, ne+0x22); shift = u16(data, ne+0x32)
    segs = []
    for i in range(count):
        eo = st + i*8
        sec, ln, flags, alloc = struct.unpack_from("<HHHH", data, eo)
        segs.append({"num":i+1,"off":sec<<shift,"len":ln or 0x10000,"flags":flags,"entry":eo,"alloc":alloc})
    return ne, shift, segs

def relocation_records(data: bytes | bytearray, seg: dict[str,int]):
    if not (seg["flags"] & 0x0100): return []
    rs = seg["off"] + seg["len"]
    if rs+2 > len(data): raise PatchError("재배치 테이블이 없습니다.")
    count = u16(data, rs); end = rs + 2 + count*8
    if end > len(data): raise PatchError("재배치 테이블이 손상되었습니다.")
    out=[]
    for i in range(count):
        ro=rs+2+i*8
        out.append((ro,data[ro],data[ro+1],u16(data,ro+2),u16(data,ro+4),u16(data,ro+6)))
    return out

def next_segment_offset(segs, seg):
    xs=sorted(s["off"] for s in segs if s["off"]>seg["off"])
    if not xs: raise PatchError("다음 세그먼트를 찾지 못했습니다.")
    return xs[0]

def reloc_one(data, seg, source, source_type=None):
    rows=[r for r in relocation_records(data,seg) if r[3]==source and (source_type is None or r[1]==source_type)]
    if len(rows)!=1: raise PatchError(f"재배치 source 0x{source:04X}를 유일하게 찾지 못했습니다: {len(rows)}")
    return rows[0]

def reloc_matches(data, seg, source, stype, flags_low, module, target):
    rows=[r for r in relocation_records(data,seg) if r[3]==source]
    return len(rows)==1 and rows[0][1]==stype and (rows[0][2]&7)==flags_low and rows[0][4]==module and rows[0][5]==target

def set_reloc_target(data: bytearray, seg, source, flags_low, module, target):
    r=reloc_one(data,seg,source)
    data[r[0]+1]=(r[2]&~7)|flags_low; p16(data,r[0]+4,module); p16(data,r[0]+6,target)

def move_reloc_sources(data: bytearray, seg, mapping: dict[int,int]):
    # Capture record offsets before changing any source values.
    rows={old:reloc_one(data,seg,old) for old in mapping}
    for old,new in mapping.items(): p16(data,rows[old][0]+2,new)

def remove_reloc_sources(data: bytearray, seg, sources: set[int]):
    rs=seg["off"]+seg["len"]; rows=relocation_records(data,seg)
    kept=[]; removed=[]
    for r in rows:
        raw=bytes(data[r[0]:r[0]+8])
        (removed if r[3] in sources else kept).append(raw)
    if len(removed)!=len(sources): raise PatchError(f"제거할 재배치 수가 다릅니다: {len(removed)} / {len(sources)}")
    old_end=rs+2+len(rows)*8; new_end=rs+2+len(kept)*8
    p16(data,rs,len(kept)); data[rs+2:new_end]=b"".join(kept); data[new_end:old_end]=b"\0"*(old_end-new_end)

# ---- ED2MAIN v1.0.61 repair ----------------------------------------------
def bad_wrapper():
    b=bytearray(); b+=b"\x8B\x1E"+struct.pack("<H",BAD_BANK); b+=b"\x83\xE3\x01\xD1\xCB"
    b+=b"\xBA\xD4\x03\x8A\xE3\xB0\x0D\xEF"; b+=b"\x8A\xE7\xB0\x0C\xEF"; b+=b"\xBA\xDA\x03"
    b+=b"\xEC\xA8\x08\x75\xFB"; b+=b"\xEC\xA8\x08\x74\xFB"; b+=b"\xCB"
    return bytes(b)

def inspect_ed2main_bytes(data: bytes):
    _,_,segs=ne_info(data); by={s["num"]:s for s in segs}; seg2=by[2]
    pairs=[]
    for sn,src in BAD_RELOCS:
        r=reloc_one(data,by[sn],src,3); pairs.append((r[4],r[5]))
    stable=seg2["len"]==BAD_WRAPPER_OLD_LEN and set(pairs)=={ORIGINAL_TARGET}
    w=bad_wrapper()
    broken=(seg2["len"]==BAD_WRAPPER_OLD_LEN+len(w) and seg2["alloc"]==BAD_WRAPPER_OLD_LEN and
            data[seg2["off"]+BAD_WRAPPER_OLD_LEN:seg2["off"]+BAD_WRAPPER_OLD_LEN+len(w)]==w and
            set(pairs)=={(2,BAD_WRAPPER_OLD_LEN)})
    return {"stable":stable,"broken_v0_1_0":broken,"segment2_length":seg2["len"],"segment2_minalloc":seg2["alloc"],"sha256":sha256(data)}

def repair_ed2main_bytes(before: bytes) -> bytes:
    st=inspect_ed2main_bytes(before)
    if st["stable"]: return before
    if not st["broken_v0_1_0"]: raise PatchError(f"지원하지 않는 ED2MAIN 상태입니다: {st}")
    d=bytearray(before); _,_,segs=ne_info(d); by={s["num"]:s for s in segs}; seg2=by[2]
    current_rel=seg2["off"]+seg2["len"]; count=u16(d,current_rel); blob=bytes(d[current_rel:current_rel+2+count*8])
    nxt=next_segment_offset(segs,seg2)
    block=bytes(d[seg2["off"]:seg2["off"]+BAD_WRAPPER_OLD_LEN])+blob
    block+=b"\0"*(nxt-seg2["off"]-len(block)); d[seg2["off"]:nxt]=block; p16(d,seg2["entry"]+2,BAD_WRAPPER_OLD_LEN)
    _,_,segs2=ne_info(d); by2={s["num"]:s for s in segs2}
    for sn,src in BAD_RELOCS: set_reloc_target(d,by2[sn],src,0,ORIGINAL_TARGET[0],ORIGINAL_TARGET[1])
    out=bytes(d)
    if not inspect_ed2main_bytes(out)["stable"]: raise PatchError("ED2MAIN v1.0.61 복구 검증 실패")
    return out

# ---- M_501 wrong experiment removal only ----------------------------------
def inspect_m501_bytes(data: bytes):
    _,_,segs=ne_info(data); seg=segs[M501_SEGMENT-1]; base=seg["off"]
    all_original=True; all_experimental=True; states={}
    for off,orig in M501_ORIGINAL_BYTES.items():
        cur=data[base+off:base+off+len(orig)]; exp=M501_EXPERIMENTAL_BYTES[off]
        if cur==orig: states[f"0x{off:04X}"]="original"; all_experimental=False
        elif cur==exp: states[f"0x{off:04X}"]="v1.0.63-experimental"; all_original=False
        else: states[f"0x{off:04X}"]=cur.hex(); all_original=all_experimental=False
    r1=reloc_one(data,seg,M501_SPECIAL_PAL_CALL_SOURCE,3); r2=reloc_one(data,seg,M501_FINAL_PAL_CALL_SOURCE,3)
    orig_relocs=r1[5]==M501_ST_MON_PAL_ORDINAL and r2[5]==M501_DS_MON_ORDINAL
    exp_relocs=r1[5]==M501_DS_MON_ORDINAL and r2[5]==M501_ST_MON_PAL_ORDINAL
    structure=(seg["len"]==M501_EXPECTED_SEGMENT_LENGTH and seg["alloc"]==M501_EXPECTED_SEGMENT_LENGTH)
    original=structure and all_original and orig_relocs
    experimental=structure and all_experimental and exp_relocs
    return {"supported":original or experimental,"original":original,"wrong_v1_0_63_experiment":experimental,"byte_states":states,"segment_length":seg["len"],"segment_minalloc":seg["alloc"],"sha256":sha256(data)}

def restore_m501_bytes(before: bytes) -> bytes:
    st=inspect_m501_bytes(before)
    if not st["supported"]: raise PatchError(f"M_501.DLL이 지원 상태와 다릅니다: {st}")
    if st["original"]: return before
    d=bytearray(before); _,_,segs=ne_info(d); seg=segs[M501_SEGMENT-1]; base=seg["off"]
    for off,orig in M501_ORIGINAL_BYTES.items(): d[base+off:base+off+len(orig)]=orig
    set_reloc_target(d,seg,M501_SPECIAL_PAL_CALL_SOURCE,1,1,M501_ST_MON_PAL_ORDINAL)
    set_reloc_target(d,seg,M501_FINAL_PAL_CALL_SOURCE,1,1,M501_DS_MON_ORDINAL)
    out=bytes(d)
    if not inspect_m501_bytes(out)["original"]: raise PatchError("M_501 v1.0.63 실험 제거 검증 실패")
    return out

# ---- C_734 ---------------------------------------------------------------
def _c734_wrapper_state(data: bytes|bytearray, seg):
    base=seg["off"]; rows=relocation_records(data,seg); cave=bytes(data[base+C734_CAVE:base+C734_CAVE+C734_CAVE_SIZE])
    direct=all(reloc_matches(data,seg,s,3,1,1,C734_NEG_DSP_BANK_ORDINAL) for s in C734_TRANSFORM_NEG_SOURCES)
    local=all(reloc_matches(data,seg,s,3,0,C734_SEGMENT,C734_CAVE) for s in C734_TRANSFORM_NEG_SOURCES)
    extra=(reloc_matches(data,seg,C734_OLD_WRAPPER_NEG_SOURCE,3,1,1,C734_NEG_DSP_BANK_ORDINAL) and
           reloc_matches(data,seg,C734_OLD_WRAPPER_BANK_SOURCE,5,5,1,C734_CUR_DSP_BANK_ORDINAL))
    original=(185 <= len(rows) <= 191 and cave==b"\0"*C734_CAVE_SIZE and direct and not extra)
    bad=(len(rows)==193 and cave[:36]==C734_OLD_DISPLAY_WRAPPER and cave[36:]==b"\0"*2 and local and extra)
    return original,bad

def normalize_c734_wrapper(d: bytearray, seg):
    original,bad=_c734_wrapper_state(d,seg)
    if original: return
    if not bad: raise PatchError("C_734 v1.0.64 CRTC 래퍼 상태를 판별할 수 없습니다.")
    base=seg["off"]; d[base+C734_CAVE:base+C734_CAVE+C734_CAVE_SIZE]=b"\0"*C734_CAVE_SIZE
    for s in C734_TRANSFORM_NEG_SOURCES: set_reloc_target(d,seg,s,1,1,C734_NEG_DSP_BANK_ORDINAL)
    remove_reloc_sources(d,seg,{C734_OLD_WRAPPER_NEG_SOURCE,C734_OLD_WRAPPER_BANK_SOURCE})

def _reveal_state(data: bytes|bytearray, seg):
    base=seg["off"]; rows=relocation_records(data,seg)
    block=bytes(data[base+C734_REVEAL_START:base+C734_REVEAL_END])
    original=(block==C734_REVEAL_ORIGINAL and all(reloc_matches(data,seg,src,*exp) for src,exp in C734_REVEAL_EXPECTED_RELOCS.items()))
    patched=(block==C734_REVEAL_PATCHED and
             reloc_matches(data,seg,C734_REVEAL_CALL_SOURCE,3,1,1,C734_OPEN_WIND_ORDINAL) and
             not any(r[3] in C734_REVEAL_REMOVE_SOURCES for r in rows))
    return original,patched

def _fade_prep_state(data: bytes|bytearray, seg):
    base=seg["off"]; rows=relocation_records(data,seg)
    block=bytes(data[base+C734_FADE_PREP_START:base+C734_FADE_PREP_END])
    original=(block==C734_FADE_PREP_ORIGINAL and reloc_matches(data,seg,C734_FADE_PREP_PAL_SOURCE,5,5,1,652))
    patched=(block==C734_FADE_PREP_PATCHED and not any(r[3]==C734_FADE_PREP_PAL_SOURCE for r in rows))
    return original,patched

def _final_old_layout(block: bytes) -> bool:
    if len(block)!=51: return False
    t=bytearray(C734_FINAL_ORIGINAL_BASE); t[45]=block[45]
    return block==bytes(t) and block[45] in (0x3C,0x78,0x96)

def _timing_state(data: bytes|bytearray, seg):
    base=seg["off"]; block=bytes(data[base+C734_TIMING_START:base+C734_TIMING_END]); rows=relocation_records(data,seg)
    original=(block==C734_TIMING_ORIGINAL and all(reloc_matches(data,seg,s,*e) for s,e in C734_TIMING_EXPECTED_RELOCS.items()))
    patched=(block==C734_TIMING_PATCHED and all(reloc_matches(data,seg,s,*e) for s,e in C734_TIMING_PATCHED_RELOCS.items()) and not any(r[3]==C734_GET_BGM_CLOCK_SOURCE for r in rows))
    return original,patched

def _final_state(data: bytes|bytearray, seg):
    base=seg["off"]; block=bytes(data[base+C734_FINAL_START:base+C734_FINAL_END]); rows=relocation_records(data,seg)
    old=_final_old_layout(block) and all(reloc_matches(data,seg,s,*e) for s,e in C734_FINAL_EXPECTED_RELOCS.items())
    new=(block==C734_FINAL_PATCHED and all(reloc_matches(data,seg,s,*e) for s,e in C734_FINAL_PATCHED_RELOCS.items()))
    if new:
        # Ensure retired source locations are gone unless the same numeric source
        # is intentionally reused by a moved fixup (0x0BD8).
        new_sources=set(C734_FINAL_PATCHED_RELOCS)
        for s in C734_FINAL_EXPECTED_RELOCS:
            if s not in new_sources and any(r[3]==s for r in rows): new=False
    return old,new

def inspect_c734_bytes(data: bytes):
    _,_,segs=ne_info(data); seg=segs[C734_SEGMENT-1]; base=seg["off"]; rows=relocation_records(data,seg)
    wrapper_original,wrapper_bad=_c734_wrapper_state(data,seg)
    reveal_original,reveal_patched=_reveal_state(data,seg)
    timing_original,timing_patched=_timing_state(data,seg)
    final_old,final_new=_final_state(data,seg)
    fade_prep_original,fade_prep_patched=_fade_prep_state(data,seg)
    fade_target_zero=data[base+0x057E:base+0x059C]==b"\0"*30
    fade_relocs=(reloc_matches(data,seg,0x0BE0,5,5,1,652) and reloc_matches(data,seg,0x0BE9,5,5,1,255) and
                 reloc_matches(data,seg,0x0BFB,3,1,1,257) and reloc_matches(data,seg,0x0C00,3,1,1,656) and
                 reloc_matches(data,seg,0x0C14,3,1,1,6))
    structure=(seg["len"]==C734_EXPECTED_SEGMENT_LENGTH and seg["alloc"]==C734_EXPECTED_SEGMENT_LENGTH and
               seg["off"]+seg["len"]+2+len(rows)*8 <= next_segment_offset(segs,seg))
    supported=structure and (wrapper_original or wrapper_bad) and (reveal_original or reveal_patched) and \
              (timing_original or timing_patched) and (final_old or final_new) and \
              (fade_prep_original or fade_prep_patched) and fade_relocs
    patched=structure and wrapper_original and reveal_patched and timing_patched and final_new and \
            fade_prep_patched and fade_target_zero and fade_relocs and len(rows)==185
    return {
        "supported":supported,"patched":patched,"bad_v1_0_64_crtc_wrapper":wrapper_bad,"crtc_wrapper_removed":wrapper_original,
        "field_scene_custom_zero_buffer_reveal":reveal_original,"field_scene_open_wind_reveal":reveal_patched,
        "field_scene_timing_original_broken_clock":timing_original,"field_scene_fixed_256_frames":timing_patched,
        "final_old_layout":final_old,"explosion_hold_150_before_defeat_message":final_new,
        "defeat_message_then_fade_to_ending":final_new,"fade_prep_copies_current_palette":fade_prep_original,
        "fade_prep_runtime_zero_target":fade_prep_patched,"fade_target_file_zero":fade_target_zero,
        "fade_loop_relocations_ok":fade_relocs,"relocation_count":len(rows),"segment_length":seg["len"],
        "segment_minalloc":seg["alloc"],"sha256":sha256(data),
    }

def patch_c734_bytes(before: bytes) -> bytes:
    d=bytearray(before); _,_,segs=ne_info(d); seg=segs[C734_SEGMENT-1]
    if seg["len"]!=C734_EXPECTED_SEGMENT_LENGTH or seg["alloc"]!=C734_EXPECTED_SEGMENT_LENGTH:
        raise PatchError("C_734 세그먼트 구조가 예상과 다릅니다.")
    # Undo the failed v1.0.64 wrapper first.
    normalize_c734_wrapper(d,seg)
    _,_,segs=ne_info(d); seg=segs[C734_SEGMENT-1]; base=seg["off"]

    # Repair the full-screen reveal: use the engine's canonical OPEN_WIND
    # instead of clearing bits in C_734's never-populated private segment 4.
    reveal_original,reveal_patched=_reveal_state(d,seg)
    if not (reveal_original or reveal_patched): raise PatchError("C_734 필드 화면 열기 코드 서명이 다릅니다.")
    if reveal_original:
        d[base+C734_REVEAL_START:base+C734_REVEAL_END]=C734_REVEAL_PATCHED
        set_reloc_target(d,seg,C734_REVEAL_CALL_SOURCE,1,1,C734_OPEN_WIND_ORDINAL)
        remove_reloc_sources(d,seg,C734_REVEAL_REMOVE_SOURCES)
        _,_,segs=ne_info(d); seg=segs[C734_SEGMENT-1]; base=seg["off"]

    # Keep the v0.4.0 fixed 256-frame motion loop, avoiding the broken
    # GET_BGM_CLOCK sentinel behavior in the Korean executable.
    timing_original,timing_patched=_timing_state(d,seg)
    if not (timing_original or timing_patched): raise PatchError("C_734 필드 연출 타이밍 코드 서명이 다릅니다.")
    if timing_original:
        d[base+C734_TIMING_START:base+C734_TIMING_END]=C734_TIMING_PATCHED
        move_reloc_sources(d,seg,C734_TIMING_RELOC_MOVE)
        remove_reloc_sources(d,seg,{C734_GET_BGM_CLOCK_SOURCE})
        _,_,segs=ne_info(d); seg=segs[C734_SEGMENT-1]; base=seg["off"]

    # Make the later 15-step palette loop target true black at runtime.
    fade_orig,fade_new=_fade_prep_state(d,seg)
    if not (fade_orig or fade_new): raise PatchError("C_734 최종 페이드 준비 코드 서명이 다릅니다.")
    if fade_orig:
        d[base+C734_FADE_PREP_START:base+C734_FADE_PREP_END]=C734_FADE_PREP_PATCHED
        remove_reloc_sources(d,seg,{C734_FADE_PREP_PAL_SOURCE})
        _,_,segs=ne_info(d); seg=segs[C734_SEGMENT-1]; base=seg["off"]

    final_old,final_new=_final_state(d,seg)
    if not (final_old or final_new): raise PatchError("C_734 최종 장면 코드 서명이 다릅니다.")
    if final_old:
        d[base+C734_FINAL_START:base+C734_FINAL_END]=C734_FINAL_PATCHED
        move_reloc_sources(d,seg,C734_FINAL_RELOC_MOVE)

    out=bytes(d); st=inspect_c734_bytes(out)
    if not st["patched"]: raise PatchError(f"C_734 패치 후 검증 실패: {st}")
    return out

# ---- filesystem / CLI ----------------------------------------------------
def validate_root(root: Path) -> Path:
    root=root.expanduser().resolve()
    for rel in ("ED2MAIN.EXE","SCENA/C_734.DLL","MON/M_501.DLL"):
        if not (root/rel).is_file(): raise PatchError(f"{rel}가 있는 게임 폴더를 선택하십시오.")
    return root

def inspect_patch(root: Path):
    root=validate_root(root)
    e=inspect_ed2main_bytes((root/"ED2MAIN.EXE").read_bytes())
    m=inspect_m501_bytes((root/"MON/M_501.DLL").read_bytes())
    c=inspect_c734_bytes((root/"SCENA/C_734.DLL").read_bytes())
    return {
        "tool_version":VERSION,"ed2main":e,"m501":m,"c734":c,
        "ed2main_stable_no_new_patch":e["stable"],"m501_wrong_experiment_removed":m["original"],
        "field_scene_open_wind_reveal":c["field_scene_open_wind_reveal"],
        "field_scene_fixed_256_frames":c["field_scene_fixed_256_frames"],
        "explosion_hold_150_before_defeat_message":c["explosion_hold_150_before_defeat_message"],
        "defeat_message_then_true_black_fade":c["fade_prep_runtime_zero_target"],
        "ok":bool(e["stable"] and m["original"] and c["patched"]),
    }

def repair_ed2main(root: Path, make_backup=True):
    root=validate_root(root); p=root/"ED2MAIN.EXE"; before=p.read_bytes(); after=repair_ed2main_bytes(before)
    if after!=before: atomic_write(p,after,".v1.0.61_unsafe.bak" if make_backup else None)
    return {"changed":after!=before,"before_sha256":sha256(before),"after_sha256":sha256(after),"state":inspect_ed2main_bytes(after)}

def apply_patch(root: Path, make_backup=True):
    root=validate_root(root); er=repair_ed2main(root,make_backup)
    mp=root/"MON/M_501.DLL"; mb=mp.read_bytes(); ma=restore_m501_bytes(mb)
    if ma!=mb: atomic_write(mp,ma,".v1.0.63_wrong_transform.bak" if make_backup else None)
    cp=root/"SCENA/C_734.DLL"; cb=cp.read_bytes(); ca=patch_c734_bytes(cb)
    if ca!=cb: atomic_write(cp,ca,".final_battle_presentation.bak" if make_backup else None)
    st=inspect_patch(root)
    if not st["ok"]: raise PatchError("최종 검증에 실패했습니다.")
    return {"ed2main_repair":er,"m501_experiment_reverted":ma!=mb,"c734_changed":ca!=cb,"state":st}

def main() -> int:
    ap=argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}"); ap.add_argument("root",type=Path)
    g=ap.add_mutually_exclusive_group(); g.add_argument("--apply",action="store_true"); g.add_argument("--check",action="store_true"); g.add_argument("--repair-ed2main-only",action="store_true")
    ap.add_argument("--no-backup",action="store_true"); args=ap.parse_args()
    try:
        if args.repair_ed2main_only: result=repair_ed2main(args.root,not args.no_backup)
        elif args.check: result=inspect_patch(args.root)
        else: result=apply_patch(args.root,not args.no_backup)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}"); return 1

if __name__=="__main__": raise SystemExit(main())
