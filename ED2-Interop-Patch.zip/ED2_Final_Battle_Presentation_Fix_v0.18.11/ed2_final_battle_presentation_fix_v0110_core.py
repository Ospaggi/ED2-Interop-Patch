#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, struct
from pathlib import Path

APP_NAME='ED2 Final Battle Presentation Fix'
VERSION='0.11.0'
CORE_FILE=Path(__file__).with_name('ed2_final_battle_presentation_fix_v0100_core.py')
if not CORE_FILE.is_file():
    alt=Path('/mnt/data/ed2_v1071_final/ED2_Final_Battle_Presentation_Fix_v0.10.0/ed2_final_battle_presentation_fix.py')
    CORE_FILE=alt if alt.is_file() else CORE_FILE
_spec=importlib.util.spec_from_file_location('ed2_fb_v100_core',CORE_FILE)
if _spec is None or _spec.loader is None: raise RuntimeError('v0.10.0 compatibility core could not be loaded')
v100=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(v100)
core=v100.core; PatchError=v100.PatchError; sha256=v100.sha256; atomic_write=v100.atomic_write

C734_SEGMENT=3
SEG_LEN=v100.SEG_LEN  # 0x0CDE
RELOC_COUNT=v100.NEW_RELOC_COUNT  # 186
ABS_DELAY=v100.v090.v080.v070.v060.ABS_DELAY
CLR_MON=v100.CLR_MON
CLR_MON_STS=v100.v090.v080.v070.v060.CLR_MON_STS
NEG_DSP_BANK=v100.v090.v080.v070.v060.NEG_DSP_BANK
ST_SIN_PAL=v100.v090.v080.v070.ST_SIN_PAL
EN_DATA_1=v100.v090.v080.v070.v060.EN_DATA_1
DISP_MESS_LOW=v100.v090.v080.v070.v060.DISP_MESS_LOW
COPY_MESS=v100.v090.v080.v070.v060.COPY_MESS
PAL_DATA=v100.v090.v080.v070.v060.PAL_DATA
ETC_SKIP=v100.v090.v080.v070.v060.ETC_SKIP
ETC_DELAY=v100.v090.v080.v070.v060.ETC_DELAY
SET_PAL_CONT=v100.v090.v080.v070.v060.SET_PAL_CONT
THEEND=v100.v090.v080.v070.v060.THEEND

PRE_HELPER=0x0B69
PRE_HELPER_END=0x0B74
POST_HELPER=0x0CC9
POST_HELPER_END=0x0CDE
FINAL_START=0x0BA9
FINAL_END=0x0BDC
DUMMY_HELPER1=0x0CBE
DUMMY_HELPER1_END=0x0CC9

# Keep the runtime-proven v1.0.63 cleanup semantics intact:
#   EN_DATA_1 -> CLR_MON -> CLR_MON_STS -> NEG_DSP_BANK -> CLR_MON -> CLR_MON_STS
# The only additions around it are:
#   20 tick terminal-white hold, exact record deactivation (80h), palette restore,
#   and the requested 180 tick message hold.
def _near_disp(target:int,next_ip:int)->bytes:
    return struct.pack('<H',(target-next_ip)&0xFFFF)

# AL=20 is set by the caller; DI already points to EN_DATA_1.
# Wait first, then deactivate record exactly like END_OF_BATTLE, and return.
C734_V072_PRE_HELPER=(
    b'\x9A\xFF\xFF\x00\x00' + # CALL FAR ABS_DELAY
    b'\xC6\x05\x80' +             # MOV BYTE PTR [DI],80h
    b'\xCB' + b'\x90\x90'         # RETF + padding
)
assert len(C734_V072_PRE_HELPER)==11

# 51-byte controller. Crucially, all five original cleanup calls are inline and
# consecutive again. No palette helper, no 0C44/0C5C calls between them.
C734_V072_FINAL=(
    b'\xBF\xFF\xFF' +                # MOV DI,EN_DATA_1
    b'\xB0\x14' +                       # MOV AL,20
    b'\x0E\xE8' + _near_disp(PRE_HELPER,0x0BB2) + # PUSH CS / CALL 0B69
    b'\x9A\xFF\xFF\x00\x00' * 5 + # CLR_MON, CLR_MON_STS, NEG_DSP_BANK, CLR_MON, CLR_MON_STS
    b'\x9A\xFF\xFF\x00\x00' +      # ST_SIN_PAL
    b'\xBE\xEF\x02' +                  # defeat message pointer
    b'\x9A\xFF\xFF\x00\x00' +      # DISP_MESS_LOW
    b'\x0E\xE8' + _near_disp(POST_HELPER,0x0BDC)   # PUSH CS / CALL 0CC9
)
assert len(C734_V072_FINAL)==51

# The old v1.0.69 helper1 is no longer needed. Keep the expanded segment layout
# stable but make the slot inert.
C734_V072_DUMMY1=b'\xCB'+b'\x90'*10
assert len(C734_V072_DUMMY1)==11

# COPY_MESS, then set AL=180 here (not relying on DISP_MESS_LOW preserving AL),
# and tail-call ABS_DELAY. No speculative 0C44/0C5C display mutations.
C734_V072_POST_HELPER=(
    b'\x9A\xFF\xFF\x00\x00' + # CALL COPY_MESS
    b'\xB0\xB4' +                  # MOV AL,180
    b'\xEA\xFF\xFF\x00\x00' + # JMP FAR ABS_DELAY
    b'\x90'*9
)
assert len(C734_V072_POST_HELPER)==21

EXPECTED_RELOCS={
    0x0B6A:(3,1,1,ABS_DELAY),
    0x0BAA:(5,5,1,EN_DATA_1),
    0x0BB3:(3,1,1,CLR_MON),
    0x0BB8:(3,1,1,CLR_MON_STS),
    0x0BBD:(3,1,1,NEG_DSP_BANK),
    0x0BC2:(3,1,1,CLR_MON),
    0x0BC7:(3,1,1,CLR_MON_STS),
    0x0BCC:(3,1,1,ST_SIN_PAL),
    0x0BD4:(3,1,1,DISP_MESS_LOW),
    0x0CCA:(3,1,1,COPY_MESS),
    0x0CD1:(3,1,1,ABS_DELAY),
    0x0BE0:(5,5,1,PAL_DATA),
    0x0BE9:(5,5,1,ETC_SKIP),
    0x0BFB:(3,1,1,ETC_DELAY),
    0x0C00:(3,1,1,SET_PAL_CONT),
    0x0C14:(3,1,1,THEEND),
}
RETIRED_SOURCES={0x0B6D,0x0BAC,0x0BB1,0x0BB4,0x0BB9,0x0BBE,0x0BC3,0x0CBF,0x0CC4,0x0BD0,0x0CD9}


def _raw_reloc_rows(data,seg):
    return [[r[1],r[2],r[3],r[4],r[5]] for r in core.relocation_records(data,seg)]

def _one(meta,source):
    x=[r for r in meta if r[2]==source]
    if len(x)!=1: raise PatchError(f'relocation source 0x{source:04X}: expected one, found {len(x)}')
    return x[0]

def inspect_c734_v072(data:bytes)->dict:
    try:
        _,_,segs=core.ne_info(data); seg=segs[2]; base=seg['off']; rows=core.relocation_records(data,seg)
        next_off=core.next_segment_offset(segs,seg); reloc_end=base+seg['len']+2+len(rows)*8
        structure=seg['len']==SEG_LEN and seg['alloc']==SEG_LEN and len(rows)==RELOC_COUNT and reloc_end<=next_off
        reveal_ok=core._reveal_state(data,seg)[1]; timing_ok=core._timing_state(data,seg)[1]
        wrapper_ok=core._c734_wrapper_state(data,seg)[0]
        algo_ok=bytes(data[base+v100.v090.v080.v070.v060.C734_ALGO09_CALL:base+v100.v090.v080.v070.v060.C734_ALGO09_CALL+3])==v100.v090.v080.v070.v060.C734_ALGO09_CALL_V067
        pre_ok=bytes(data[base+PRE_HELPER:base+PRE_HELPER_END])==C734_V072_PRE_HELPER
        final_ok=bytes(data[base+FINAL_START:base+FINAL_END])==C734_V072_FINAL
        dummy_ok=bytes(data[base+DUMMY_HELPER1:base+DUMMY_HELPER1_END])==C734_V072_DUMMY1
        post_ok=bytes(data[base+POST_HELPER:base+POST_HELPER_END])==C734_V072_POST_HELPER
        zero_target=bytes(data[base+0x057E:base+0x059C])==b'\0'*30
        reloc_ok=all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_RELOCS.items())
        sources=[r[3] for r in rows]; unique=len(sources)==len(set(sources)); retired=not any(s in RETIRED_SOURCES for s in sources)
        patched=bool(structure and reveal_ok and timing_ok and wrapper_ok and algo_ok and pre_ok and final_ok and dummy_ok and post_ok and zero_target and reloc_ok and unique and retired)
        return {
            'supported':patched,'patched':patched,'field_scene_open_wind_reveal':reveal_ok,'field_scene_fixed_256_frames':timing_ok,
            'white_screen_hold_ticks':20 if pre_ok and final_ok else None,
            'godwin_record_deactivated_exact_0x80':pre_ok,
            'original_five_cleanup_calls_contiguous':final_ok,
            'cleanup_order':'CLR_MON -> CLR_MON_STS -> NEG_DSP_BANK -> CLR_MON -> CLR_MON_STS' if final_ok else None,
            'palette_restore_after_cleanup':'ST_SIN_PAL' if final_ok else None,
            'speculative_0C44_0C5C_calls_removed':post_ok,
            'defeat_message_hold_ticks':180 if post_ok else None,
            'true_black_fade_after_message_hold':final_ok and post_ok and zero_target,
            'segment_length':seg['len'],'segment_minalloc':seg['alloc'],'relocation_count':len(rows),
            'relocation_table_end':reloc_end,'next_segment_offset':next_off,'relocation_slack_bytes':next_off-reloc_end,
            'relocations_ok':reloc_ok and unique and retired,'sha256':sha256(data)
        }
    except Exception:
        return {'supported':False,'patched':False,'sha256':sha256(data)}

def patch_c734_v072(before:bytes)->bytes:
    if inspect_c734_v072(before).get('patched'): return before
    base_bytes=v100.patch_c734_v071(before)
    if not v100.inspect_c734_v071(base_bytes).get('patched'): raise PatchError('C_734 could not normalize to v1.0.71')
    d=bytearray(base_bytes); _,_,segs=core.ne_info(d); seg=segs[2]; base=seg['off']; next_off=core.next_segment_offset(segs,seg)
    if seg['len']!=SEG_LEN or seg['alloc']!=SEG_LEN: raise PatchError('segment layout differs')
    rows0=core.relocation_records(d,seg)
    if len(rows0)!=RELOC_COUNT: raise PatchError(f'v1.0.71 relocation count differs: {len(rows0)}')
    untouched={s['num']:bytes(d[s['off']:s['off']+s['len']]) for s in segs if s['num']!=3}
    # Install code first.
    d[base+PRE_HELPER:base+PRE_HELPER_END]=C734_V072_PRE_HELPER
    d[base+FINAL_START:base+FINAL_END]=C734_V072_FINAL
    d[base+DUMMY_HELPER1:base+DUMMY_HELPER1_END]=C734_V072_DUMMY1
    d[base+POST_HELPER:base+POST_HELPER_END]=C734_V072_POST_HELPER
    # Re-home only the known v1.0.71 relocations. No count change.
    meta=_raw_reloc_rows(d,seg)
    moves={
        0x0B6D:(0x0BB3,CLR_MON),       # helper CLR_MON -> first inline CLR_MON
        0x0BAC:(0x0B6A,ABS_DELAY),     # white ABS_DELAY -> prehelper
        0x0BB1:(0x0BAA,EN_DATA_1),
        0x0BB9:(0x0BB8,CLR_MON_STS),
        0x0BBE:(0x0BBD,NEG_DSP_BANK),
        0x0BC3:(0x0BC2,CLR_MON),
        0x0CBF:(0x0BC7,CLR_MON_STS),
        0x0CC4:(0x0BCC,ST_SIN_PAL),
        0x0BD0:(0x0BD4,DISP_MESS_LOW),
        0x0CD9:(0x0CD1,ABS_DELAY),
    }
    for old,(new,tgt) in moves.items():
        r=_one(meta,old); r[2]=new; r[0]=3 if tgt not in (EN_DATA_1,) else 5; r[1]=(r[1]&~7)|(5 if tgt==EN_DATA_1 else 1); r[3]=1; r[4]=tgt
    # COPY_MESS stays at 0CCA.
    _one(meta,0x0CCA)[4]=COPY_MESS
    # Verify unique and exact count.
    sources=[r[2] for r in meta]
    if len(meta)!=RELOC_COUNT or len(sources)!=len(set(sources)): raise PatchError('relocation reconstruction failed')
    reloc_start=base+seg['len']
    table=struct.pack('<H',len(meta))+b''.join(bytes((st&255,fl&255))+struct.pack('<HHH',src,mod,tgt) for st,fl,src,mod,tgt in meta)
    end=reloc_start+len(table)
    if end>next_off: raise PatchError('relocation table overlaps next segment')
    d[reloc_start:end]=table; d[end:next_off]=b'\0'*(next_off-end)
    out=bytes(d); _,_,segs2=core.ne_info(out)
    for s in segs2:
        if s['num']==3: continue
        if bytes(out[s['off']:s['off']+s['len']])!=untouched[s['num']]: raise PatchError(f'unexpected segment {s["num"]} change')
    st=inspect_c734_v072(out)
    if not st.get('patched'): raise PatchError(f'post-patch verification failed: {st}')
    return out

def validate_root(root:Path)->Path: return v100.validate_root(root)
def repair_ed2main(root:Path,make_backup=True): return v100.repair_ed2main(root,make_backup)
def inspect_patch(root:Path):
    root=validate_root(root); e=core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes()); m=core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes()); c=inspect_c734_v072((root/'SCENA/C_734.DLL').read_bytes())
    return {'tool_version':VERSION,'ed2main':e,'m501':m,'c734':c,'ed2main_stable_no_new_patch':e['stable'],'m501_wrong_experiment_removed':m['original'],'ok':bool(e['stable'] and m['original'] and c.get('patched'))}
def apply_patch(root:Path,make_backup=True):
    root=validate_root(root); er=repair_ed2main(root,make_backup)
    mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
    if ma!=mb: atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734_v072(cb)
    if ca!=cb: atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st=inspect_patch(root)
    if not st['ok']: raise PatchError('Final verification failed')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}
def main():
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}'); ap.add_argument('root',type=Path); g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true'); ap.add_argument('--no-backup',action='store_true'); a=ap.parse_args()
    try:
        r=repair_ed2main(a.root,not a.no_backup) if a.repair_ed2main_only else inspect_patch(a.root) if a.check else apply_patch(a.root,not a.no_backup)
        print(json.dumps(r,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as e: print('ERROR:',e); return 1
if __name__=='__main__': raise SystemExit(main())
