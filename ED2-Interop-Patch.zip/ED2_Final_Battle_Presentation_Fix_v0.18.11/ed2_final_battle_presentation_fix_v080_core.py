#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, struct
from pathlib import Path

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.8.0"

CORE_FILE = Path(__file__).with_name("ed2_final_battle_presentation_fix_v070_core.py")
if not CORE_FILE.is_file():
    alt = Path('/mnt/data/ed2_final_battle_presentation_fix_v070.py')
    CORE_FILE = alt if alt.is_file() else CORE_FILE
_spec = importlib.util.spec_from_file_location("ed2_fb_v070_core", CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError("v0.7.0 compatibility core could not be loaded")
v070 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v070)

core = v070.core
PatchError = v070.PatchError
sha256 = v070.sha256
atomic_write = v070.atomic_write

C734_SEGMENT = 3
OLD_LEN = 0x0CBE
NEW_LEN = 0x0CDE
OLD_RELOC_COUNT = 185
NEW_RELOC_COUNT = 186
HELPER1 = 0x0CBE
HELPER2 = 0x0CC9
DUMMY_OLD_HELPER = b'\xCB' + b'\x90' * 10

# v1.0.69 final controller.  Keep the terminal white frame for 20 ticks,
# clear the ordinary monster/status layers, then restore the normal scene
# palette.  The defeat message is rendered next; helper2 restores the two
# PC-98 post-message cleanup calls and holds the message for 180 ticks.
def _near_disp(target: int, next_ip: int) -> bytes:
    return struct.pack('<H', (target - next_ip) & 0xFFFF)

C734_V069_FINAL = (
    b'\xB0\x14' +                         # MOV AL,20
    b'\x9A\xFF\xFF\x00\x00' +         # CALL ABS_DELAY
    b'\xBF\xFF\xFF' +                   # MOV DI,EN_DATA_1
    b'\x9A\xFF\xFF\x00\x00' * 4 +     # CLR_MON, CLR_MON_STS, NEG_DSP_BANK, CLR_MON
    b'\x0E\xE8' + _near_disp(HELPER1, 0x0BCB) + b'\x90' +
    b'\xBE\xEF\x02' +                   # defeat message pointer
    b'\x9A\xFF\xFF\x00\x00' +         # DISP_MESS_LOW
    b'\x0E\xE8' + _near_disp(HELPER2, 0x0BD8) + b'\x90\x90\x90\x90'
)
assert len(C734_V069_FINAL) == 51

# helper1: preserve second-bank CLR_MON_STS, then restore normal 16-color scene palette.
C734_V069_HELPER1 = (
    b'\x9A\xFF\xFF\x00\x00' +         # CLR_MON_STS
    b'\x9A\xFF\xFF\x00\x00' +         # ST_SIN_PAL
    b'\xCB'                                # RETF
)
assert len(C734_V069_HELPER1) == 11

# helper2: exact missing PC-98 post-message cleanup calls, then 180-tick hold.
# 0C44 and 0C5C both RETF, so PUSH CS + near CALL supplies a far return frame.
C734_V069_HELPER2 = (
    b'\x9A\xFF\xFF\x00\x00' +         # COPY_MESS
    b'\x0E\xE8' + struct.pack('<h', 0x0C44 - 0x0CD2) +
    b'\x0E\xE8' + struct.pack('<h', 0x0C5C - 0x0CD6) +
    b'\xB0\xB4' +                        # MOV AL,180
    b'\xEA\xFF\xFF\x00\x00' +         # JMP FAR ABS_DELAY (tail call)
    b'\x90'
)
assert len(C734_V069_HELPER2) == 21
C734_V069_HELPERS = C734_V069_HELPER1 + C734_V069_HELPER2
assert len(C734_V069_HELPERS) == 32

# Expected final import relocation layout.
EXPECTED_V069_RELOCS = {
    0x0BAC: (3,1,1,v070.v060.ABS_DELAY),
    0x0BB1: (5,5,1,v070.v060.EN_DATA_1),
    0x0BB4: (3,1,1,v070.v060.CLR_MON),
    0x0BB9: (3,1,1,v070.v060.CLR_MON_STS),
    0x0BBE: (3,1,1,v070.v060.NEG_DSP_BANK),
    0x0BC3: (3,1,1,v070.v060.CLR_MON),
    0x0CBF: (3,1,1,v070.v060.CLR_MON_STS),
    0x0CC4: (3,1,1,v070.ST_SIN_PAL),
    0x0BD0: (3,1,1,v070.v060.DISP_MESS_LOW),
    0x0CCA: (3,1,1,v070.v060.COPY_MESS),
    0x0CD9: (3,1,1,v070.v060.ABS_DELAY),
    0x0BE0: (5,5,1,v070.v060.PAL_DATA),
    0x0BE9: (5,5,1,v070.v060.ETC_SKIP),
    0x0BFB: (3,1,1,v070.v060.ETC_DELAY),
    0x0C00: (3,1,1,v070.v060.SET_PAL_CONT),
    0x0C14: (3,1,1,v070.v060.THEEND),
}
RETIRED_SOURCES = {0x0BAA, 0x0BC8, 0x0B6A, 0x0B6F}


def _raw_reloc_rows(data: bytes | bytearray, seg) -> list[list[int]]:
    # [source_type, flags, source, module, target]
    return [[r[1], r[2], r[3], r[4], r[5]] for r in core.relocation_records(data, seg)]


def _one_meta(rows: list[list[int]], source: int) -> list[int]:
    found = [r for r in rows if r[2] == source]
    if len(found) != 1:
        raise PatchError(f'C_734 relocation source 0x{source:04X} expected once, found {len(found)}')
    return found[0]


def inspect_c734_v069(data: bytes) -> dict:
    try:
        _,_,segs = core.ne_info(data)
        seg = segs[C734_SEGMENT-1]
        base = seg['off']
        rows = core.relocation_records(data, seg)
        next_off = core.next_segment_offset(segs, seg)
        reloc_end = base + seg['len'] + 2 + len(rows)*8
        structure = bool(
            seg['len'] == NEW_LEN and seg['alloc'] == NEW_LEN and
            len(rows) == NEW_RELOC_COUNT and reloc_end <= next_off and
            next_off - reloc_end >= 0
        )
        # All previous field-scene repairs are in offsets below OLD_LEN and must survive.
        reveal_ok = core._reveal_state(data, seg)[1]
        timing_ok = core._timing_state(data, seg)[1]
        wrapper_ok = core._c734_wrapper_state(data, seg)[0]
        algo_call_ok = bytes(data[base+v070.v060.C734_ALGO09_CALL:base+v070.v060.C734_ALGO09_CALL+3]) == v070.v060.C734_ALGO09_CALL_V067
        retired_helper_ok = bytes(data[base+0x0B69:base+0x0B74]) == DUMMY_OLD_HELPER
        final_ok = bytes(data[base+v070.C734_FINAL_START:base+v070.C734_FINAL_END]) == C734_V069_FINAL
        h1_ok = bytes(data[base+HELPER1:base+HELPER1+len(C734_V069_HELPER1)]) == C734_V069_HELPER1
        h2_ok = bytes(data[base+HELPER2:base+HELPER2+len(C734_V069_HELPER2)]) == C734_V069_HELPER2
        zero_target = bytes(data[base+0x057E:base+0x059C]) == b'\0'*30
        reloc_ok = all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_V069_RELOCS.items())
        retired_ok = not any(r[3] in RETIRED_SOURCES for r in rows)
        sources = [r[3] for r in rows]
        unique_sources = len(sources) == len(set(sources))
        # Helpers occupy exactly the 32 bytes that used to begin the relocation table.
        helpers_at_old_end = bytes(data[base+OLD_LEN:base+NEW_LEN]) == C734_V069_HELPERS
        patched = bool(structure and reveal_ok and timing_ok and wrapper_ok and algo_call_ok and
                       retired_helper_ok and final_ok and h1_ok and h2_ok and helpers_at_old_end and
                       zero_target and reloc_ok and retired_ok and unique_sources)
        return {
            'supported': patched,
            'patched': patched,
            'field_scene_open_wind_reveal': reveal_ok,
            'field_scene_fixed_256_frames': timing_ok,
            'white_screen_hold_ticks': 20 if final_ok else None,
            'post_explosion_clear_both_banks': final_ok and h1_ok,
            'normal_scene_palette_restore_after_clear': final_ok and h1_ok,
            'pc98_post_message_cleanup_0C44_0C5C': h2_ok,
            'defeat_message_hold_ticks': 180 if h2_ok else None,
            'true_black_fade_after_message_hold': final_ok and h2_ok and zero_target,
            'fade_target_file_zero': zero_target,
            'segment_length': seg['len'],
            'segment_minalloc': seg['alloc'],
            'relocation_count': len(rows),
            'relocation_table_end': reloc_end,
            'next_segment_offset': next_off,
            'relocation_slack_bytes': next_off-reloc_end,
            'relocations_ok': reloc_ok and retired_ok and unique_sources,
            'sha256': sha256(data),
        }
    except (PatchError, IndexError, ValueError, struct.error):
        return {'supported': False, 'patched': False, 'sha256': sha256(data)}


def patch_c734_v069(before: bytes) -> bytes:
    if inspect_c734_v069(before).get('patched'):
        return before

    # Converge stock/v1.0.61..v1.0.68 to the runtime-confirmed v1.0.68 base.
    base_bytes = v070.patch_c734_v068(before)
    if not v070.inspect_c734_v068(base_bytes)['patched']:
        raise PatchError('C_734 could not be normalized to the v1.0.68 base state.')

    d = bytearray(base_bytes)
    _,_,segs = core.ne_info(d)
    seg = segs[C734_SEGMENT-1]
    base = seg['off']
    if seg['len'] != OLD_LEN or seg['alloc'] != OLD_LEN:
        raise PatchError('C_734 v1.0.68 segment 3 size signature differs.')
    rows0 = core.relocation_records(d, seg)
    if len(rows0) != OLD_RELOC_COUNT:
        raise PatchError(f'C_734 v1.0.68 relocation count differs: {len(rows0)}')
    old_reloc_start = base + OLD_LEN
    old_reloc_end = old_reloc_start + 2 + 8*len(rows0)
    next_off = core.next_segment_offset(segs, seg)
    if next_off - old_reloc_end < 32 + 8:
        raise PatchError('C_734 does not have enough verified alignment slack for the v1.0.69 helpers/relocation.')

    # Preserve a byte-for-byte snapshot of all real segments other than seg3 for validation.
    untouched = {
        s['num']: bytes(d[s['off']:s['off']+s['len']])
        for s in segs if s['num'] != C734_SEGMENT
    }

    # Repurpose the old 0B69 helper as a harmless far return and install final controller.
    d[base+0x0B69:base+0x0B74] = DUMMY_OLD_HELPER
    d[base+v070.C734_FINAL_START:base+v070.C734_FINAL_END] = C734_V069_FINAL

    meta = _raw_reloc_rows(d, seg)
    # v1.0.68 source 0BAA ST_SIN_PAL -> white-hold ABS_DELAY at 0BAC.
    r = _one_meta(meta, 0x0BAA)
    r[2] = 0x0BAC; r[0] = 3; r[1] = (r[1] & ~7) | 1; r[3] = 1; r[4] = v070.v060.ABS_DELAY
    # Preserve the original second-bank status clear, but move it into helper1.
    _one_meta(meta, 0x0BC8)[2] = 0x0CBF
    # Move v1.0.68 post-message helper imports into helper2.
    _one_meta(meta, 0x0B6A)[2] = 0x0CCA
    _one_meta(meta, 0x0B6F)[2] = 0x0CD9
    # New helper1 ST_SIN_PAL import.
    meta.append([3, 1, 0x0CC4, 1, v070.ST_SIN_PAL])

    sources = [r[2] for r in meta]
    if len(sources) != len(set(sources)):
        raise PatchError('C_734 v1.0.69 relocation sources are not unique.')
    if len(meta) != NEW_RELOC_COUNT:
        raise PatchError('C_734 v1.0.69 relocation count construction failed.')

    new_reloc_start = base + NEW_LEN
    table = struct.pack('<H', len(meta)) + b''.join(
        bytes((st & 0xFF, fl & 0xFF)) + struct.pack('<HHH', src, mod, tgt)
        for st,fl,src,mod,tgt in meta
    )
    new_reloc_end = new_reloc_start + len(table)
    if new_reloc_end > next_off:
        raise PatchError('C_734 v1.0.69 relocation table would overlap the next segment.')

    # The helpers take the old relocation-table start; the table is moved by 32 bytes
    # inside the verified alignment gap.  No file offset after segment 3 changes.
    d[old_reloc_start:old_reloc_start+32] = C734_V069_HELPERS
    d[new_reloc_start:new_reloc_end] = table
    d[new_reloc_end:next_off] = b'\0' * (next_off-new_reloc_end)
    core.p16(d, seg['entry']+2, NEW_LEN)
    core.p16(d, seg['entry']+6, NEW_LEN)

    out = bytes(d)
    # Verify every other real segment is byte-identical and begins at the same file offset.
    _,_,segs2 = core.ne_info(out)
    for s in segs2:
        if s['num'] == C734_SEGMENT:
            continue
        if s['num'] not in untouched or bytes(out[s['off']:s['off']+s['len']]) != untouched[s['num']]:
            raise PatchError(f'C_734 v1.0.69 unexpectedly changed segment {s["num"]}.')
    st = inspect_c734_v069(out)
    if not st.get('patched'):
        raise PatchError(f'C_734 v1.0.69 post-patch verification failed: {st}')
    return out


def validate_root(root: Path) -> Path:
    return v070.validate_root(root)


def inspect_patch(root: Path):
    root = validate_root(root)
    e = core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes())
    m = core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes())
    c = inspect_c734_v069((root/'SCENA/C_734.DLL').read_bytes())
    return {
        'tool_version': VERSION,
        'ed2main': e,
        'm501': m,
        'c734': c,
        'ed2main_stable_no_new_patch': e['stable'],
        'm501_wrong_experiment_removed': m['original'],
        'field_scene_open_wind_reveal': c.get('field_scene_open_wind_reveal', False),
        'field_scene_fixed_256_frames': c.get('field_scene_fixed_256_frames', False),
        'white_screen_hold_20_ticks': c.get('white_screen_hold_ticks') == 20,
        'godwin_lingering_graphics_cleanup_restored': c.get('pc98_post_message_cleanup_0C44_0C5C', False),
        'defeat_message_hold_180_then_true_black_fade': c.get('defeat_message_hold_ticks') == 180 and c.get('true_black_fade_after_message_hold', False),
        'ok': bool(e['stable'] and m['original'] and c.get('patched')),
    }


def repair_ed2main(root: Path, make_backup=True):
    return v070.repair_ed2main(root, make_backup)


def apply_patch(root: Path, make_backup=True):
    root = validate_root(root)
    er = repair_ed2main(root, make_backup)
    mp = root/'MON/M_501.DLL'
    mb = mp.read_bytes(); ma = core.restore_m501_bytes(mb)
    if ma != mb:
        atomic_write(mp, ma, '.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp = root/'SCENA/C_734.DLL'
    cb = cp.read_bytes(); ca = patch_c734_v069(cb)
    if ca != cb:
        atomic_write(cp, ca, '.final_battle_presentation.bak' if make_backup else None)
    st = inspect_patch(root)
    if not st['ok']:
        raise PatchError('Final verification failed.')
    return {
        'ed2main_repair': er,
        'm501_experiment_reverted': ma != mb,
        'c734_changed': ca != cb,
        'state': st,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}')
    ap.add_argument('root', type=Path)
    g = ap.add_mutually_exclusive_group()
    g.add_argument('--apply', action='store_true')
    g.add_argument('--check', action='store_true')
    g.add_argument('--repair-ed2main-only', action='store_true')
    ap.add_argument('--no-backup', action='store_true')
    args = ap.parse_args()
    try:
        if args.repair_ed2main_only:
            result = repair_ed2main(args.root, not args.no_backup)
        elif args.check:
            result = inspect_patch(args.root)
        else:
            result = apply_patch(args.root, not args.no_backup)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (PatchError, OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}')
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
