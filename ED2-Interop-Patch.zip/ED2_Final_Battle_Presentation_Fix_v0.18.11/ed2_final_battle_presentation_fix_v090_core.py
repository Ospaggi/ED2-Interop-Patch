#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, struct
from pathlib import Path

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.9.0"

CORE_FILE = Path(__file__).with_name("ed2_final_battle_presentation_fix_v080_core.py")
if not CORE_FILE.is_file():
    alt = Path('/mnt/data/ed2_v1069_final/ED2_Final_Battle_Presentation_Fix_v0.8.0/ed2_final_battle_presentation_fix.py')
    CORE_FILE = alt if alt.is_file() else CORE_FILE
_spec = importlib.util.spec_from_file_location("ed2_fb_v080_core", CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError("v0.8.0 compatibility core could not be loaded")
v080 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v080)

core = v080.core
PatchError = v080.PatchError
sha256 = v080.sha256
atomic_write = v080.atomic_write

C734_SEGMENT = 3
SEG_LEN = v080.NEW_LEN               # 0x0CDE
OLD_RELOC_COUNT = v080.NEW_RELOC_COUNT  # 186
NEW_RELOC_COUNT = 187
MONSTER_CLEAR1 = 217
CLR_MON = v080.v070.v060.CLR_MON
CLEANUP_HELPER = 0x0B69
CLEANUP_HELPER_END = 0x0B74
FIRST_CLEAR_CALL = 0x0BB3
FIRST_CLEAR_SOURCE = 0x0BB4

# M_501 is a large/special monster: its first monster-record byte is 04h.
# Normal special-monster death paths call MONSTER_CLEAR1 before CLR_MON.
# C_734's final-boss cleanup omitted that specialized restore path.
# Reuse the already-free 0B69..0B73 slot:
#   CALL FAR MONSTER_CLEAR1
#   JMP  FAR CLR_MON
# The far JMP tail-calls CLR_MON so its RETF returns to the local caller.
C734_V070_CLEANUP_HELPER = (
    b'\x9A\xFF\xFF\x00\x00' +   # CALL MONSTER_CLEAR1
    b'\xEA\xFF\xFF\x00\x00' +   # JMP FAR CLR_MON
    b'\x90'
)
assert len(C734_V070_CLEANUP_HELPER) == 11

# Replace only the first CLR_MON far call after MOV DI,EN_DATA_1 with
# PUSH CS + near CALL 0B69 + NOP.  Everything else in v1.0.69's final
# sequence (white 20, dual-bank clear, palette restore, message 180, fade)
# remains byte-for-byte identical.
_disp = (CLEANUP_HELPER - (FIRST_CLEAR_CALL + 4)) & 0xFFFF
C734_V070_LOCAL_CALL = b'\x0E\xE8' + struct.pack('<H', _disp) + b'\x90'
assert len(C734_V070_LOCAL_CALL) == 5
C734_V070_FINAL = bytearray(v080.C734_V069_FINAL)
rel = FIRST_CLEAR_CALL - v080.v070.C734_FINAL_START
C734_V070_FINAL[rel:rel+5] = C734_V070_LOCAL_CALL
C734_V070_FINAL = bytes(C734_V070_FINAL)
assert len(C734_V070_FINAL) == len(v080.C734_V069_FINAL)

EXPECTED_V070_RELOCS = dict(v080.EXPECTED_V069_RELOCS)
EXPECTED_V070_RELOCS.pop(FIRST_CLEAR_SOURCE)
EXPECTED_V070_RELOCS[0x0B6A] = (3,1,1,MONSTER_CLEAR1)
EXPECTED_V070_RELOCS[0x0B6F] = (3,1,1,CLR_MON)


def _raw_reloc_rows(data: bytes | bytearray, seg) -> list[list[int]]:
    return [[r[1], r[2], r[3], r[4], r[5]] for r in core.relocation_records(data, seg)]


def _one_meta(rows: list[list[int]], source: int) -> list[int]:
    found = [r for r in rows if r[2] == source]
    if len(found) != 1:
        raise PatchError(f'C_734 relocation source 0x{source:04X} expected once, found {len(found)}')
    return found[0]


def _m501_large_monster_signature(root: Path) -> bool:
    try:
        d=(root/'MON/M_501.DLL').read_bytes()
        _,_,segs=core.ne_info(d)
        seg=segs[2]
        return d[seg['off']] == 0x04
    except Exception:
        return False


def inspect_c734_v070(data: bytes) -> dict:
    try:
        _,_,segs = core.ne_info(data)
        seg = segs[C734_SEGMENT-1]
        base = seg['off']
        rows = core.relocation_records(data, seg)
        next_off = core.next_segment_offset(segs, seg)
        reloc_end = base + seg['len'] + 2 + len(rows)*8
        structure = bool(
            seg['len'] == SEG_LEN and seg['alloc'] == SEG_LEN and
            len(rows) == NEW_RELOC_COUNT and reloc_end <= next_off
        )
        reveal_ok = core._reveal_state(data, seg)[1]
        timing_ok = core._timing_state(data, seg)[1]
        wrapper_ok = core._c734_wrapper_state(data, seg)[0]
        algo_call_ok = bytes(data[base+v080.v070.v060.C734_ALGO09_CALL:base+v080.v070.v060.C734_ALGO09_CALL+3]) == v080.v070.v060.C734_ALGO09_CALL_V067
        final_ok = bytes(data[base+v080.v070.C734_FINAL_START:base+v080.v070.C734_FINAL_END]) == C734_V070_FINAL
        cleanup_ok = bytes(data[base+CLEANUP_HELPER:base+CLEANUP_HELPER_END]) == C734_V070_CLEANUP_HELPER
        h1_ok = bytes(data[base+v080.HELPER1:base+v080.HELPER1+len(v080.C734_V069_HELPER1)]) == v080.C734_V069_HELPER1
        h2_ok = bytes(data[base+v080.HELPER2:base+v080.HELPER2+len(v080.C734_V069_HELPER2)]) == v080.C734_V069_HELPER2
        zero_target = bytes(data[base+0x057E:base+0x059C]) == b'\0'*30
        reloc_ok = all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_V070_RELOCS.items())
        no_old_first_import = not any(r[3] == FIRST_CLEAR_SOURCE for r in rows)
        sources=[r[3] for r in rows]
        unique_sources=len(sources)==len(set(sources))
        patched=bool(structure and reveal_ok and timing_ok and wrapper_ok and algo_call_ok and final_ok and cleanup_ok and h1_ok and h2_ok and zero_target and reloc_ok and no_old_first_import and unique_sources)
        return {
            'supported': patched,
            'patched': patched,
            'field_scene_open_wind_reveal': reveal_ok,
            'field_scene_fixed_256_frames': timing_ok,
            'white_screen_hold_ticks': 20 if final_ok else None,
            'special_monster_cleanup_monster_clear1': cleanup_ok and reloc_ok,
            'ordinary_dual_bank_clear_preserved': final_ok and h1_ok,
            'normal_scene_palette_restore_after_clear': final_ok and h1_ok,
            'pc98_post_message_cleanup_0C44_0C5C': h2_ok,
            'defeat_message_hold_ticks': 180 if h2_ok else None,
            'true_black_fade_after_message_hold': final_ok and h2_ok and zero_target,
            'segment_length': seg['len'],
            'segment_minalloc': seg['alloc'],
            'relocation_count': len(rows),
            'relocation_table_end': reloc_end,
            'next_segment_offset': next_off,
            'relocation_slack_bytes': next_off-reloc_end,
            'relocations_ok': reloc_ok and no_old_first_import and unique_sources,
            'sha256': sha256(data),
        }
    except (PatchError, IndexError, ValueError, struct.error):
        return {'supported': False, 'patched': False, 'sha256': sha256(data)}


def patch_c734_v070(before: bytes) -> bytes:
    if inspect_c734_v070(before).get('patched'):
        return before

    # Normalize every supported older state to v1.0.69 first.
    base_bytes = v080.patch_c734_v069(before)
    if not v080.inspect_c734_v069(base_bytes).get('patched'):
        raise PatchError('C_734 could not be normalized to the v1.0.69 base state.')

    d=bytearray(base_bytes)
    _,_,segs=core.ne_info(d)
    seg=segs[C734_SEGMENT-1]
    base=seg['off']
    if seg['len'] != SEG_LEN or seg['alloc'] != SEG_LEN:
        raise PatchError('C_734 v1.0.69 segment 3 size signature differs.')
    rows0=core.relocation_records(d,seg)
    if len(rows0)!=OLD_RELOC_COUNT:
        raise PatchError(f'C_734 v1.0.69 relocation count differs: {len(rows0)}')
    next_off=core.next_segment_offset(segs,seg)
    old_reloc_start=base+seg['len']
    old_reloc_end=old_reloc_start+2+8*len(rows0)
    if next_off-old_reloc_end < 8:
        raise PatchError('C_734 has insufficient relocation slack for MONSTER_CLEAR1.')

    untouched={s['num']:bytes(d[s['off']:s['off']+s['len']]) for s in segs if s['num']!=C734_SEGMENT}

    # Install specialized large-monster cleanup helper and redirect the first
    # ordinary CLR_MON call through it.
    d[base+CLEANUP_HELPER:base+CLEANUP_HELPER_END]=C734_V070_CLEANUP_HELPER
    d[base+FIRST_CLEAR_CALL:base+FIRST_CLEAR_CALL+5]=C734_V070_LOCAL_CALL

    meta=_raw_reloc_rows(d,seg)
    # Existing first CLR_MON record now belongs to helper's CLR_MON tail jump.
    r=_one_meta(meta,FIRST_CLEAR_SOURCE)
    r[2]=0x0B6F; r[0]=3; r[1]=(r[1]&~7)|1; r[3]=1; r[4]=CLR_MON
    # Add specialized MONSTER_CLEAR1 import for helper's first call.
    meta.append([3,1,0x0B6A,1,MONSTER_CLEAR1])
    sources=[x[2] for x in meta]
    if len(sources)!=len(set(sources)):
        raise PatchError('C_734 v1.0.70 relocation sources are not unique.')
    if len(meta)!=NEW_RELOC_COUNT:
        raise PatchError('C_734 v1.0.70 relocation count construction failed.')

    table=struct.pack('<H',len(meta))+b''.join(
        bytes((st&0xff,fl&0xff))+struct.pack('<HHH',src,mod,tgt)
        for st,fl,src,mod,tgt in meta
    )
    new_end=old_reloc_start+len(table)
    if new_end>next_off:
        raise PatchError('C_734 v1.0.70 relocation table overlaps next segment.')
    d[old_reloc_start:new_end]=table
    # Leave remaining alignment slack deterministic and free of stale record bytes.
    d[new_end:next_off]=b'\0'*(next_off-new_end)

    out=bytes(d)
    _,_,segs2=core.ne_info(out)
    for s in segs2:
        if s['num']==C734_SEGMENT: continue
        if s['num'] not in untouched or bytes(out[s['off']:s['off']+s['len']])!=untouched[s['num']]:
            raise PatchError(f'C_734 v1.0.70 unexpectedly changed segment {s["num"]}.')
    st=inspect_c734_v070(out)
    if not st.get('patched'):
        raise PatchError(f'C_734 v1.0.70 post-patch verification failed: {st}')
    return out


def validate_root(root: Path) -> Path:
    return v080.validate_root(root)


def inspect_patch(root: Path):
    root=validate_root(root)
    e=core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes())
    m=core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes())
    c=inspect_c734_v070((root/'SCENA/C_734.DLL').read_bytes())
    sig=_m501_large_monster_signature(root)
    return {
        'tool_version':VERSION,
        'ed2main':e,'m501':m,'c734':c,
        'm501_large_monster_flag_0x04':sig,
        'ed2main_stable_no_new_patch':e['stable'],
        'm501_wrong_experiment_removed':m['original'],
        'special_monster_cleanup_monster_clear1':c.get('special_monster_cleanup_monster_clear1',False),
        'white_screen_hold_20_ticks':c.get('white_screen_hold_ticks')==20,
        'defeat_message_hold_180_then_true_black_fade':c.get('defeat_message_hold_ticks')==180 and c.get('true_black_fade_after_message_hold',False),
        'ok':bool(e['stable'] and m['original'] and sig and c.get('patched')),
    }


def repair_ed2main(root: Path, make_backup=True):
    return v080.repair_ed2main(root, make_backup)


def apply_patch(root: Path, make_backup=True):
    root=validate_root(root)
    er=repair_ed2main(root,make_backup)
    mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
    if ma!=mb:
        atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734_v070(cb)
    if ca!=cb:
        atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st=inspect_patch(root)
    if not st['ok']:
        raise PatchError('Final verification failed.')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}


def main()->int:
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}')
    ap.add_argument('root',type=Path)
    g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true')
    ap.add_argument('--no-backup',action='store_true')
    args=ap.parse_args()
    try:
        if args.repair_ed2main_only: result=repair_ed2main(args.root,not args.no_backup)
        elif args.check: result=inspect_patch(args.root)
        else: result=apply_patch(args.root,not args.no_backup)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}'); return 1

if __name__=='__main__':
    raise SystemExit(main())
