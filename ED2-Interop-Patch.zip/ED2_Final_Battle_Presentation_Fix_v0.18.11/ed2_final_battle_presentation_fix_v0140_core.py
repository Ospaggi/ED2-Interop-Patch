#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, struct
from pathlib import Path
APP_NAME='ED2 Final Battle Presentation Fix'
VERSION='0.14.0'
CORE_FILE=Path(__file__).with_name('ed2_final_battle_presentation_fix_v0130_core.py')
_spec=importlib.util.spec_from_file_location('ed2_fb_v0130_core',CORE_FILE)
if _spec is None or _spec.loader is None: raise RuntimeError('v0.13.0 core load failed')
v130=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(v130)
core=v130.core; PatchError=v130.PatchError; sha256=v130.sha256; atomic_write=v130.atomic_write
SEG_LEN=v130.SEG_LEN; FINAL_START=v130.FINAL_START; FINAL_END=v130.FINAL_END
PRE_HELPER=v130.PRE_HELPER; PRE_HELPER_END=v130.PRE_HELPER_END
POST_HELPER=v130.POST_HELPER; POST_HELPER_END=v130.POST_HELPER_END
GW_CLR=214; NEG_DSP_BANK=62; EN_DATA_1=682; ST_SIN_PAL=v130.ST_SIN_PAL; DISP_MESS_LOW=599

def _near(target,next_ip): return struct.pack('<H',(target-next_ip)&0xffff)
# White hold is kept at 20 ticks, but the old monster-coordinate clears are replaced by
# ED2MAIN GW_CLR, which clears the entire 320x320 left game window (x=32..351) on the
# current VGA page.  Run it on both pages, then deactivate Godwin and restore palette.
FINAL=bytearray()
FINAL += b'\xBF\xFF\xFF'                 # MOV DI,EN_DATA_1
FINAL += b'\xB0\x14'                     # 20 ticks
FINAL += b'\x0E\xE8'+_near(PRE_HELPER,0x0BB2)
FINAL += b'\x9A\xFF\xFF\x00\x00'      # GW_CLR current page
FINAL += b'\x9A\xFF\xFF\x00\x00'      # NEG_DSP_BANK
FINAL += b'\x9A\xFF\xFF\x00\x00'      # GW_CLR other page
FINAL += b'\xC6\x05\x80'                # EN_DATA_1[0]=80, prevent redraw
FINAL += b'\x9A\xFF\xFF\x00\x00'      # ST_SIN_PAL
FINAL += b'\xBE\xEF\x02'                 # defeat message
FINAL += b'\x9A\xFF\xFF\x00\x00'      # DISP_MESS_LOW
FINAL += b'\x0E\xE8'+_near(POST_HELPER,0x0BD5)
FINAL += b'\x90'*(FINAL_END-FINAL_START-len(FINAL))
FINAL=bytes(FINAL)
assert len(FINAL)==FINAL_END-FINAL_START
EXPECTED={
 0x0BAA:(5,5,1,EN_DATA_1),
 0x0BB3:(3,1,1,GW_CLR),
 0x0BB8:(3,1,1,NEG_DSP_BANK),
 0x0BBD:(3,1,1,GW_CLR),
 0x0BC5:(3,1,1,ST_SIN_PAL),
 0x0BCD:(3,1,1,DISP_MESS_LOW),
}
RETIRED={0x0BC2,0x0BC7,0x0BD4,0x0CC2}

def _meta(data,seg): return [[r[1],r[2],r[3],r[4],r[5]] for r in core.relocation_records(data,seg)]
def inspect_c734(data:bytes):
 try:
  _,_,segs=core.ne_info(data); seg=segs[2]; base=seg['off']; rows=core.relocation_records(data,seg)
  nextoff=core.next_segment_offset(segs,seg); rend=base+seg['len']+2+len(rows)*8
  baseok=v130.inspect_c734_v074(data).get('field_scene_open_wind_reveal') and v130.inspect_c734_v074(data).get('field_scene_fixed_256_frames')
  finalok=bytes(data[base+FINAL_START:base+FINAL_END])==FINAL
  preok=bytes(data[base+PRE_HELPER:base+PRE_HELPER_END])==v130.C734_V074_PRE_HELPER
  postok=bytes(data[base+POST_HELPER:base+POST_HELPER_END])==v130.C734_V074_POST_HELPER
  zero=bytes(data[base+0x057E:base+0x059C])==b'\0'*30
  relok=all(core.reloc_matches(data,seg,s,*e) for s,e in EXPECTED.items())
  sources=[r[3] for r in rows]
  relok=relok and all(s not in sources for s in RETIRED) and len(sources)==len(set(sources))
  structure=seg['len']==SEG_LEN and seg['alloc']==SEG_LEN and rend<=nextoff
  ok=bool(baseok and finalok and preok and postok and zero and relok and structure)
  return {'supported':ok,'patched':ok,'field_scene_restored':bool(baseok),'white_screen_hold_ticks':20 if preok else None,
   'godwin_cleanup':'GW_CLR current page -> NEG_DSP_BANK -> GW_CLR other page -> deactivate',
   'game_window_clear_rect':'x=32..351, 320 scanlines (ED2MAIN GW_CLR)',
   'defeat_message_hold_ticks':180 if postok else None,'true_black_fade':bool(zero),
   'segment_length':seg['len'],'segment_minalloc':seg['alloc'],'relocation_count':len(rows),'relocation_table_end':rend,'next_segment_offset':nextoff,'sha256':sha256(data)}
 except Exception as e: return {'supported':False,'patched':False,'error':str(e),'sha256':sha256(data)}

def patch_c734(before:bytes)->bytes:
 if inspect_c734(before).get('patched'): return before
 d=bytearray(v130.patch_c734_v074(before))
 _,_,segs=core.ne_info(d); seg=segs[2]; base=seg['off']; nextoff=core.next_segment_offset(segs,seg)
 d[base+FINAL_START:base+FINAL_END]=FINAL
 # Remove v0.13 post-clear helper contents; no longer used.
 d[base+v130.POST_CLEAR_HELPER:base+v130.POST_CLEAR_HELPER_END]=b'\x90'*(v130.POST_CLEAR_HELPER_END-v130.POST_CLEAR_HELPER)
 meta=_meta(d,seg)
 # Drop all relocations owned by the old five per-monster clears, old DISP location,
 # and v0.13 post-clear ST_SIN_PAL trampoline. Keep unrelated scene/fade relocations.
 old={0x0BAA,0x0BB3,0x0BB8,0x0BBD,0x0BC2,0x0BC7,0x0BD4,0x0CC2}
 meta=[r for r in meta if r[2] not in old]
 meta += [ [st,fl,src,mod,tgt] for src,(st,fl,mod,tgt) in EXPECTED.items() ]
 meta.sort(key=lambda r:r[2])
 sources=[r[2] for r in meta]
 if len(sources)!=len(set(sources)): raise PatchError('duplicate relocation source')
 rs=base+seg['len']; table=struct.pack('<H',len(meta))+b''.join(bytes((st&255,fl&255))+struct.pack('<HHH',src,mod,tgt) for st,fl,src,mod,tgt in meta)
 if rs+len(table)>nextoff: raise PatchError('relocation table overlap')
 d[rs:rs+len(table)]=table; d[rs+len(table):nextoff]=b'\0'*(nextoff-rs-len(table))
 out=bytes(d); st=inspect_c734(out)
 if not st.get('patched'): raise PatchError(f'v0.14 verify failed: {st}')
 return out

def validate_root(root): return v130.validate_root(Path(root))
def repair_ed2main(root,make_backup=True): return v130.repair_ed2main(Path(root),make_backup)
def inspect_patch(root):
 root=validate_root(root); e=core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes()); m=core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes()); c=inspect_c734((root/'SCENA/C_734.DLL').read_bytes())
 return {'tool_version':VERSION,'ed2main':e,'m501':m,'c734':c,'ok':bool(e['stable'] and m['original'] and c.get('patched'))}
def apply_patch(root,make_backup=True):
 root=validate_root(root); er=repair_ed2main(root,make_backup)
 mp=root/'MON/M_501.DLL'; mb=mp.read_bytes(); ma=core.restore_m501_bytes(mb)
 if ma!=mb: atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
 cp=root/'SCENA/C_734.DLL'; cb=cp.read_bytes(); ca=patch_c734(cb)
 if ca!=cb: atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
 st=inspect_patch(root)
 if not st['ok']: raise PatchError('final verification failed')
 return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}
def main():
 ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}'); ap.add_argument('root',type=Path); g=ap.add_mutually_exclusive_group();g.add_argument('--apply',action='store_true');g.add_argument('--check',action='store_true');g.add_argument('--repair-ed2main-only',action='store_true');ap.add_argument('--no-backup',action='store_true');a=ap.parse_args()
 try:
  r=repair_ed2main(a.root,not a.no_backup) if a.repair_ed2main_only else inspect_patch(a.root) if a.check else apply_patch(a.root,not a.no_backup);print(json.dumps(r,ensure_ascii=False,indent=2));return 0
 except Exception as e: print('ERROR:',e);return 1
if __name__=='__main__': raise SystemExit(main())
