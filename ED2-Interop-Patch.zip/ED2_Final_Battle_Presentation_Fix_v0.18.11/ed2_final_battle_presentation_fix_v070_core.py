#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json
from pathlib import Path

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.7.0"

CORE_FILE = Path(__file__).with_name("ed2_final_battle_presentation_fix_v060_core.py")
if not CORE_FILE.is_file():
    alt = Path('/mnt/data/ed2_final_battle_presentation_fix_v060.py')
    CORE_FILE = alt if alt.is_file() else CORE_FILE
_spec = importlib.util.spec_from_file_location("ed2_fb_v060_core", CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError("v0.6.0 compatibility core could not be loaded")
v060 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v060)

core = v060.core
PatchError = v060.PatchError
sha256 = v060.sha256
atomic_write = v060.atomic_write

C734_SEGMENT = 3
C734_FINAL_START = v060.C734_FINAL_START
C734_FINAL_END = v060.C734_FINAL_END
C734_V067_FINAL = v060.C734_V067_FINAL
ST_SIN_PAL = 648

# v1.0.67 starts the 51-byte final controller with:
#   MOV AL,150 / CALL ABS_DELAY
# This does not extend the explosion; it freezes the terminal white palette.
# v1.0.68 replaces that 7-byte sequence with:
#   CALL ST_SIN_PAL / NOP / NOP
# so the explosion's own final white frame remains as a natural flash, then the
# normal 16-color scene palette is restored before the battle-screen cleanup and
# defeat message.
C734_V068_FINAL = bytes.fromhex('9A FF FF 00 00 90 90') + C734_V067_FINAL[7:]
assert len(C734_V068_FINAL) == 51

EXPECTED_V068_RELOCS = dict(v060.EXPECTED_V067_RELOCS)
EXPECTED_V068_RELOCS.pop(0x0BAC)
EXPECTED_V068_RELOCS[0x0BAA] = (3, 1, 1, ST_SIN_PAL)

RETIRED_V067_WHITE_HOLD_SOURCE = 0x0BAC


def inspect_c734_v068(data: bytes) -> dict:
    _,_,segs = core.ne_info(data)
    seg = segs[C734_SEGMENT-1]
    base = seg['off']
    rows = core.relocation_records(data, seg)
    structure = seg['len']==v060.C734_LEN and seg['alloc']==v060.C734_LEN and \
        seg['off']+seg['len']+2+len(rows)*8 <= core.next_segment_offset(segs,seg)
    reveal_ok = core._reveal_state(data,seg)[1]
    timing_ok = core._timing_state(data,seg)[1]
    wrapper_ok = core._c734_wrapper_state(data,seg)[0]
    call_ok = bytes(data[base+v060.C734_ALGO09_CALL:base+v060.C734_ALGO09_CALL+3]) == v060.C734_ALGO09_CALL_V067
    helper_ok = bytes(data[base+v060.C734_HELPER:base+v060.C734_HELPER_END]) == v060.C734_V067_HELPER
    final_ok = bytes(data[base+C734_FINAL_START:base+C734_FINAL_END]) == C734_V068_FINAL
    zero_target = bytes(data[base+0x057E:base+0x059C]) == b'\0'*30
    reloc_ok = all(core.reloc_matches(data,seg,src,*exp) for src,exp in EXPECTED_V068_RELOCS.items())
    old_white_hold_gone = not any(r[3] == RETIRED_V067_WHITE_HOLD_SOURCE for r in rows)
    patched = bool(structure and wrapper_ok and reveal_ok and timing_ok and call_ok and helper_ok and final_ok and zero_target and reloc_ok and old_white_hold_gone and len(rows)==185)
    return {
        'supported': patched,
        'patched': patched,
        'field_scene_open_wind_reveal': reveal_ok,
        'field_scene_fixed_256_frames': timing_ok,
        'artificial_white_hold_ticks': 0 if final_ok else None,
        'post_explosion_palette_restore': 'ST_SIN_PAL' if final_ok else None,
        'defeat_message_hold_120': final_ok and helper_ok,
        'true_black_fade_after_message_hold': final_ok and helper_ok and zero_target,
        'algo09_skips_helper_on_entry': call_ok,
        'post_message_helper': helper_ok,
        'fade_target_file_zero': zero_target,
        'relocations_ok': reloc_ok and old_white_hold_gone,
        'relocation_count': len(rows),
        'segment_length': seg['len'],
        'segment_minalloc': seg['alloc'],
        'sha256': sha256(data),
    }


def patch_c734_v068(before: bytes) -> bytes:
    st = inspect_c734_v068(before)
    if st['patched']:
        return before

    # Converge stock and all released v1.0.61..v1.0.67 states to v1.0.67 first.
    base_bytes = v060.patch_c734_v067(before)
    d = bytearray(base_bytes)
    _,_,segs = core.ne_info(d)
    seg = segs[C734_SEGMENT-1]
    base = seg['off']
    if bytes(d[base+C734_FINAL_START:base+C734_FINAL_END]) != C734_V067_FINAL:
        raise PatchError('C_734 v1.0.67 최종 장면 슬롯 서명이 다릅니다.')
    if not core.reloc_matches(d,seg,0x0BAC,3,1,1,v060.ABS_DELAY):
        raise PatchError('C_734 v1.0.67 흰 화면 150틱 ABS_DELAY 재배치 서명이 다릅니다.')

    # Replace only the artificial terminal-white hold with the engine's stock
    # base scene-palette restore. Keep field-scene repair, cleanup, message hold,
    # and final true-black fade byte-for-byte otherwise.
    d[base+C734_FINAL_START:base+C734_FINAL_END] = C734_V068_FINAL
    r = core.reloc_one(d,seg,0x0BAC)
    ro = r[0]
    core.p16(d,ro+2,0x0BAA)
    core.p16(d,ro+4,1)
    core.p16(d,ro+6,ST_SIN_PAL)
    d[ro+1] = (r[2] & ~7) | 1

    out = bytes(d)
    st2 = inspect_c734_v068(out)
    if not st2['patched']:
        raise PatchError(f'C_734 v1.0.68 패치 후 검증 실패: {st2}')
    return out


def validate_root(root: Path) -> Path:
    return v060.validate_root(root)


def inspect_patch(root: Path):
    root = validate_root(root)
    e = core.inspect_ed2main_bytes((root/'ED2MAIN.EXE').read_bytes())
    m = core.inspect_m501_bytes((root/'MON/M_501.DLL').read_bytes())
    c = inspect_c734_v068((root/'SCENA/C_734.DLL').read_bytes())
    return {
        'tool_version': VERSION,
        'ed2main': e,
        'm501': m,
        'c734': c,
        'ed2main_stable_no_new_patch': e['stable'],
        'm501_wrong_experiment_removed': m['original'],
        'field_scene_open_wind_reveal': c['field_scene_open_wind_reveal'],
        'field_scene_fixed_256_frames': c['field_scene_fixed_256_frames'],
        'terminal_white_hold_removed': c['artificial_white_hold_ticks'] == 0,
        'battle_palette_restored_before_defeat_message': c['post_explosion_palette_restore'] == 'ST_SIN_PAL',
        'defeat_message_hold_120_then_true_black_fade': c['defeat_message_hold_120'] and c['true_black_fade_after_message_hold'],
        'ok': bool(e['stable'] and m['original'] and c['patched']),
    }


def repair_ed2main(root: Path, make_backup=True):
    return v060.repair_ed2main(root, make_backup)


def apply_patch(root: Path, make_backup=True):
    root = validate_root(root)
    er = repair_ed2main(root, make_backup)
    mp = root/'MON/M_501.DLL'
    mb = mp.read_bytes(); ma = core.restore_m501_bytes(mb)
    if ma != mb:
        atomic_write(mp,ma,'.v1.0.63_wrong_transform.bak' if make_backup else None)
    cp = root/'SCENA/C_734.DLL'
    cb = cp.read_bytes(); ca = patch_c734_v068(cb)
    if ca != cb:
        atomic_write(cp,ca,'.final_battle_presentation.bak' if make_backup else None)
    st = inspect_patch(root)
    if not st['ok']:
        raise PatchError('최종 검증에 실패했습니다.')
    return {'ed2main_repair':er,'m501_experiment_reverted':ma!=mb,'c734_changed':ca!=cb,'state':st}


def main() -> int:
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}')
    ap.add_argument('root',type=Path)
    g=ap.add_mutually_exclusive_group(); g.add_argument('--apply',action='store_true'); g.add_argument('--check',action='store_true'); g.add_argument('--repair-ed2main-only',action='store_true')
    ap.add_argument('--no-backup',action='store_true'); args=ap.parse_args()
    try:
        if args.repair_ed2main_only: result=repair_ed2main(args.root,not args.no_backup)
        elif args.check: result=inspect_patch(args.root)
        else: result=apply_patch(args.root,not args.no_backup)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (PatchError,OSError,ValueError,KeyError,json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}'); return 1

if __name__=='__main__':
    raise SystemExit(main())
