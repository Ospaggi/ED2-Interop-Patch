#!/usr/bin/env python3
"""ED2MAIN confirmed bug-fix patch for Korean DOS The Legend of Heroes II."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import tempfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from ed2_patch_journal import record_patch, selective_restore, journal_path

APP_NAME = "ED2MAIN Bug Fix Patch"
VERSION = "1.0.1"
COMPONENT = "ed2main_bug_fix_v1"
TARGET_NAME = "ED2MAIN.EXE"
SEGMENT_INDEX = 86

# Confirmed original code sites in ED2MAIN segment 86.
EXP_SITE = 0x41C4
GOLD_SITE = 0x41E0
MAGIC_SITE = 0x9514

EXP_ORIGINAL = bytes.fromhex("01 1E B4 95")       # add [CUR_EXP], bx
GOLD_ORIGINAL = bytes.fromhex("01 1E B0 95")      # add [CUR_GOLD], bx
MAGIC_ORIGINAL = bytes.fromhex("FE C8 75 18")     # dec al / jne +0x18

# Verified unused padding. Item-magic support begins later at 86:1F00.
EXP_HELPER_OFF = 0x1E00
GOLD_HELPER_OFF = 0x1E10
MAGIC_HELPER_OFF = 0x1E30

# Saturating 16-bit additions. Flags from ADD remain intact; MOV does not alter flags.
EXP_HELPER = bytes.fromhex("01 1E B4 95 73 06 C7 06 B4 95 FF FF CB")
GOLD_HELPER = bytes.fromhex("01 1E B0 95 73 06 C7 06 B0 95 FF FF CB")

# If the current low recharge nibble is zero, treat it as one before DEC.
# Valid 1..15 counters are byte-for-byte behavior-equivalent to the original sequence.
# Preserve the original branch at 86:9516.  The far-call return IP is 9518;
# when DEC leaves AL nonzero, advance that return IP by 0x18 to 9530.
# AL=0 is first normalized to 1, so it follows the same recharge path as AL=1.
# BP is saved and restored; no general register remains clobbered.
MAGIC_HELPER = bytes.fromhex(
    "0A C0 75 02 B0 01 FE C8 74 09 55 8B EC 83 46 02 18 5D CB CB"
)


def near_far_call(site: int, target: int) -> bytes:
    # push cs; call near target. The helper returns with RETF.
    rel = (target - (site + 4)) & 0xFFFF
    return bytes((0x0E, 0xE8, rel & 0xFF, rel >> 8))


EXP_PATCHED = near_far_call(EXP_SITE, EXP_HELPER_OFF)
GOLD_PATCHED = near_far_call(GOLD_SITE, GOLD_HELPER_OFF)
MAGIC_PATCHED = near_far_call(MAGIC_SITE, MAGIC_HELPER_OFF)


class PatchError(RuntimeError):
    pass


@dataclass(frozen=True)
class NESegment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


def u16(data: bytes | bytearray, off: int) -> int:
    if off < 0 or off + 2 > len(data):
        raise PatchError(f"16비트 읽기 범위 오류: 0x{off:X}")
    return struct.unpack_from("<H", data, off)[0]


def parse_ne_segments(data: bytes) -> list[NESegment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("MZ 실행 파일이 아닙니다.")
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    if ne_off + 0x40 > len(data) or data[ne_off:ne_off + 2] != b"NE":
        raise PatchError("16비트 NE 실행 파일이 아닙니다.")
    count = u16(data, ne_off + 0x1C)
    table = ne_off + u16(data, ne_off + 0x22)
    shift = u16(data, ne_off + 0x32)
    if table + count * 8 > len(data):
        raise PatchError("NE 세그먼트 표가 잘렸습니다.")
    result: list[NESegment] = []
    for i in range(count):
        sector, length, flags, min_alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        file_offset = sector << shift
        real_length = 65536 if length == 0 else length
        if file_offset + real_length > len(data):
            raise PatchError(f"NE 세그먼트 {i + 1}이 파일 범위를 벗어납니다.")
        result.append(NESegment(i + 1, file_offset, real_length, flags, min_alloc))
    return result


def resolve_target(path: Path) -> Path:
    path = path.expanduser().resolve()
    exe = path / TARGET_NAME if path.is_dir() else path
    if not exe.is_file() or exe.name.upper() != TARGET_NAME:
        raise PatchError(f"{TARGET_NAME}을 찾을 수 없습니다: {exe}")
    return exe


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def backup_once(path: Path) -> Path:
    backup = path.with_name(path.name + ".bak")
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        return backup
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


def atomic_write(path: Path, data: bytes) -> None:
    before = path.read_bytes()
    if before == data:
        return
    backup_once(path)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(temp_name, path)
        try:
            record_patch(path, before, data, COMPONENT)
        except Exception:
            # Never leave an unjournaled mutation behind.
            fd2, rollback_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".rollback.tmp", dir=str(path.parent))
            try:
                with os.fdopen(fd2, "wb") as fp:
                    fp.write(before)
                    fp.flush()
                    os.fsync(fp.fileno())
                os.replace(rollback_name, path)
            finally:
                try:
                    os.unlink(rollback_name)
                except OSError:
                    pass
            raise
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


@dataclass(frozen=True)
class FeatureSpec:
    key: str
    label: str
    site: int
    original: bytes
    patched: bytes
    helper_off: int
    helper: bytes


FEATURES = (
    FeatureSpec(
        "exp_overflow",
        "전투 EXP 16비트 오버플로 방지",
        EXP_SITE,
        EXP_ORIGINAL,
        EXP_PATCHED,
        EXP_HELPER_OFF,
        EXP_HELPER,
    ),
    FeatureSpec(
        "gold_overflow",
        "전투 Gold 16비트 오버플로 방지",
        GOLD_SITE,
        GOLD_ORIGINAL,
        GOLD_PATCHED,
        GOLD_HELPER_OFF,
        GOLD_HELPER,
    ),
    FeatureSpec(
        "magic_counter",
        "마법 재충전 0 카운터 언더플로 방지",
        MAGIC_SITE,
        MAGIC_ORIGINAL,
        MAGIC_PATCHED,
        MAGIC_HELPER_OFF,
        MAGIC_HELPER,
    ),
)
FEATURE_BY_KEY = {f.key: f for f in FEATURES}


def segment86(data: bytes) -> NESegment:
    segments = parse_ne_segments(data)
    if len(segments) < SEGMENT_INDEX:
        raise PatchError("ED2MAIN에 예상한 86번 세그먼트가 없습니다.")
    seg = segments[SEGMENT_INDEX - 1]
    required = max(
        max(f.site + len(f.original) for f in FEATURES),
        max(f.helper_off + len(f.helper) for f in FEATURES),
    )
    if seg.length < required:
        raise PatchError("ED2MAIN 86번 세그먼트가 예상보다 짧습니다.")
    return seg


def _slice(data: bytes | bytearray, seg: NESegment, offset: int, length: int) -> bytes:
    start = seg.file_offset + offset
    return bytes(data[start:start + length])


def _put(data: bytearray, seg: NESegment, offset: int, value: bytes) -> None:
    start = seg.file_offset + offset
    data[start:start + len(value)] = value


def inspect_bytes(data: bytes) -> dict[str, Any]:
    seg = segment86(data)
    result: dict[str, Any] = {
        "segment": SEGMENT_INDEX,
        "segment_file_offset": seg.file_offset,
        "segment_length": seg.length,
        "file_sha256": sha256(data),
        "features": {},
        "ok": True,
    }
    for feature in FEATURES:
        site = _slice(data, seg, feature.site, len(feature.original))
        helper = _slice(data, seg, feature.helper_off, len(feature.helper))
        if site == feature.original and helper == b"\x00" * len(feature.helper):
            state = "original"
        elif site == feature.patched and helper == feature.helper:
            state = "patched"
        elif site == feature.original and helper == feature.helper:
            state = "orphan_helper"
            result["ok"] = False
        elif site == feature.patched and helper == b"\x00" * len(feature.helper):
            state = "missing_helper"
            result["ok"] = False
        else:
            state = "conflict"
            result["ok"] = False
        result["features"][feature.key] = {
            "label": feature.label,
            "state": state,
            "site": f"{SEGMENT_INDEX}:{feature.site:04X}",
            "site_bytes": site.hex(" "),
            "helper": f"{SEGMENT_INDEX}:{feature.helper_off:04X}",
            "helper_bytes": helper.hex(" "),
        }
    # Informational scan: original MG15 has 0x00 but is an unused placeholder.
    magic_param_base = 0x14AA3C
    unsafe: list[dict[str, Any]] = []
    if magic_param_base + 32 * 12 <= len(data):
        for i in range(32):
            value = data[magic_param_base + i * 12 + 11]
            if (value & 0x0F) == 0 or (value & 0xF0) == 0:
                name = data[magic_param_base + i * 12:magic_param_base + i * 12 + 8].decode("cp949", "replace").strip()
                unsafe.append({"id": i, "name": name, "magic_cnt": f"0x{value:02X}"})
    result["zero_nibble_magic_records"] = unsafe
    return result


def build_target(data: bytes, selected: set[str]) -> tuple[bytes, list[dict[str, Any]]]:
    report = inspect_bytes(data)
    if not report["ok"]:
        bad = [
            f"{key}={row['state']}"
            for key, row in report["features"].items()
            if row["state"] not in ("original", "patched")
        ]
        raise PatchError("알 수 없는 부분 패치 또는 충돌 상태입니다: " + ", ".join(bad))
    seg = segment86(data)
    output = bytearray(data)
    changes: list[dict[str, Any]] = []
    for feature in FEATURES:
        if feature.key not in selected:
            continue
        state = report["features"][feature.key]["state"]
        if state == "patched":
            continue
        current_helper = _slice(output, seg, feature.helper_off, len(feature.helper))
        if current_helper != b"\x00" * len(feature.helper):
            raise PatchError(
                f"{feature.label}용 코드 공간 {SEGMENT_INDEX}:{feature.helper_off:04X}이 비어 있지 않습니다."
            )
        _put(output, seg, feature.helper_off, feature.helper)
        _put(output, seg, feature.site, feature.patched)
        changes.append({
            "feature": feature.key,
            "label": feature.label,
            "site": f"{SEGMENT_INDEX}:{feature.site:04X}",
            "helper": f"{SEGMENT_INDEX}:{feature.helper_off:04X}",
            "before": feature.original.hex(" "),
            "after": feature.patched.hex(" "),
        })
    return bytes(output), changes


def apply_patch(exe: Path, selected: set[str]) -> dict[str, Any]:
    before = exe.read_bytes()
    target, changes = build_target(before, selected)
    if changes:
        atomic_write(exe, target)
    final = inspect_bytes(exe.read_bytes())
    if not final["ok"]:
        raise PatchError("적용 후 검증에 실패했습니다.")
    for key in selected:
        if final["features"][key]["state"] != "patched":
            raise PatchError(f"적용 후 {key}가 활성화되지 않았습니다.")
    return {
        "application": APP_NAME,
        "version": VERSION,
        "target": str(exe),
        "changed_features": changes,
        "changed_count": len(changes),
        "sha256_before": sha256(before),
        "sha256_after": sha256(exe.read_bytes()),
        "state": final,
    }


def restore_patch(exe: Path) -> dict[str, Any]:
    restored = selective_restore(exe, COMPONENT)
    state = inspect_bytes(exe.read_bytes())
    return {
        "target": str(exe),
        "restored_bytes": restored,
        "journal": str(journal_path(exe, COMPONENT)),
        "state": state,
    }


def selected_from_args(args: argparse.Namespace) -> set[str]:
    selected = {f.key for f in FEATURES}
    if args.features:
        selected = {x.strip() for x in args.features.split(",") if x.strip()}
        unknown = sorted(selected - set(FEATURE_BY_KEY))
        if unknown:
            raise PatchError("알 수 없는 기능 키: " + ", ".join(unknown))
    return selected


class GUI:
    def __init__(self, initial: Path | None = None):
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
        self.tk, self.ttk = tk, ttk
        self.filedialog, self.messagebox = filedialog, messagebox
        self.root = tk.Tk()
        self.root.title(f"{APP_NAME} v{VERSION}")
        self.root.minsize(760, 520)
        self.path_var = tk.StringVar(value=str(initial or ""))
        self.vars = {f.key: tk.BooleanVar(value=True) for f in FEATURES}

        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)
        row = ttk.Frame(outer)
        row.pack(fill="x")
        ttk.Entry(row, textvariable=self.path_var).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="게임 폴더 선택", command=self.choose).pack(side="left", padx=(8, 0))

        box = ttk.LabelFrame(outer, text="수정 항목", padding=10)
        box.pack(fill="x", pady=12)
        for feature in FEATURES:
            ttk.Checkbutton(box, text=feature.label, variable=self.vars[feature.key]).pack(anchor="w", pady=3)

        note = (
            "정상 범위의 전투 보상과 마법 충전 속도는 바꾸지 않습니다. "
            "65,535 초과 또는 0 카운터처럼 원본 코드가 순환·언더플로하는 경우만 안전 처리합니다.\n"
            "아이템 마법 코드(86:1F00)와 겹치지 않는 86:1E00 영역을 사용하며, 복원은 이 도구가 바꾼 바이트만 되돌립니다."
        )
        ttk.Label(outer, text=note, justify="left", wraplength=720).pack(anchor="w")

        self.log = tk.Text(outer, height=13, wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True, pady=10)
        buttons = ttk.Frame(outer)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="상태 검사", command=self.do_check).pack(side="left")
        ttk.Button(buttons, text="선택 항목 적용", command=self.do_apply).pack(side="left", padx=8)
        ttk.Button(buttons, text="이 패치만 복원", command=self.do_restore).pack(side="left")
        ttk.Button(buttons, text="닫기", command=self.root.destroy).pack(side="right")

    def choose(self) -> None:
        value = self.filedialog.askdirectory(title="영웅전설 II 게임 폴더 선택")
        if value:
            self.path_var.set(value)

    def append(self, value: Any) -> None:
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.root.update_idletasks()

    def exe(self) -> Path:
        return resolve_target(Path(self.path_var.get()))

    def do_check(self) -> None:
        try:
            self.append(inspect_bytes(self.exe().read_bytes()))
        except Exception as exc:
            self.messagebox.showerror(APP_NAME, str(exc))

    def do_apply(self) -> None:
        try:
            selected = {key for key, value in self.vars.items() if value.get()}
            if not selected:
                raise PatchError("적용할 항목을 하나 이상 선택하세요.")
            labels = [FEATURE_BY_KEY[key].label for key in selected]
            if not self.messagebox.askyesno(APP_NAME, "다음 항목을 적용할까요?\n\n" + "\n".join("- " + x for x in labels)):
                return
            result = apply_patch(self.exe(), selected)
            self.append(result)
            self.messagebox.showinfo(APP_NAME, f"적용 완료: {result['changed_count']}개 항목")
        except Exception as exc:
            self.append("오류: " + str(exc))
            self.messagebox.showerror(APP_NAME, str(exc))

    def do_restore(self) -> None:
        try:
            if not self.messagebox.askyesno(APP_NAME, "이 도구가 수정한 바이트만 복원할까요?"):
                return
            result = restore_patch(self.exe())
            self.append(result)
            self.messagebox.showinfo(APP_NAME, f"복원 완료: {result['restored_bytes']}바이트")
        except Exception as exc:
            self.append("오류: " + str(exc))
            self.messagebox.showerror(APP_NAME, str(exc))

    def run(self) -> None:
        self.root.mainloop()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("path", nargs="?", type=Path, help="게임 폴더 또는 ED2MAIN.EXE")
    parser.add_argument("--apply", action="store_true", help="선택 기능 적용")
    parser.add_argument("--check", action="store_true", help="상태 검사")
    parser.add_argument("--restore", action="store_true", help="이 패치만 선택 복원")
    parser.add_argument("--features", help="쉼표로 구분: exp_overflow,gold_overflow,magic_counter")
    parser.add_argument("--no-gui", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.apply or args.check or args.restore:
            if not args.path:
                parser.error("path가 필요합니다")
            exe = resolve_target(args.path)
            if args.check:
                print(json.dumps(inspect_bytes(exe.read_bytes()), ensure_ascii=False, indent=2))
            elif args.restore:
                print(json.dumps(restore_patch(exe), ensure_ascii=False, indent=2))
            else:
                print(json.dumps(apply_patch(exe, selected_from_args(args)), ensure_ascii=False, indent=2))
            return 0
        if args.no_gui:
            return 0
        GUI(args.path).run()
        return 0
    except Exception as exc:
        print(f"오류: {exc}", file=os.sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
