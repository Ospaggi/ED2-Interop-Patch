#!/usr/bin/env python3
"""Structural validation for ED2 Map Editor v0.5.5."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from ed2_formats import MapProject
from ed2_map_editor import (
    _reviewed_or_generated_udg_layout, _udg_graph,
    _udg_gate_branches_are_separate, UDG_ROOM_MASKS,
    udg_layout_statistics,
)

parser = argparse.ArgumentParser()
parser.add_argument("game_root", type=Path)
args = parser.parse_args()
project = MapProject(args.game_root)
udg = project.underground
floors = []
ok = udg.scene_metadata_complete and udg.scroll_runtime_verified
for level in range(8):
    before = udg.layout(level)
    after = _reviewed_or_generated_udg_layout(
        level, before, udg.protected_descriptors(level),
        udg.progression_gate_descriptors(level), udg.scroll_domains(level),
    )
    udg.validate_layout_edit(level, after)
    source = _udg_graph(before)
    result = _udg_graph(after)
    spots_ok = all(
        after[i] == before[i] and set(result.get(i, ())) == set(source.get(i, ()))
        for i in udg.spot_descriptor_indices(level)
    )
    exits_ok = all(
        after[i] == before[i] and set(result.get(i, ())) == set(source.get(i, ()))
        for i in udg.retail_terminal_indices(level)
    )
    scroll_rooms = udg.scroll_sensitive_indices(level)
    scroll_rooms_ok = all(
        after[i] == before[i] and set(result.get(i, ())) == set(source.get(i, ()))
        for i in scroll_rooms
    )
    retained_identity_ok = all(
        after[i] == 0xFF
        or before[i] == 0xFF
        or UDG_ROOM_MASKS[after[i] & 0x1F] != UDG_ROOM_MASKS[before[i] & 0x1F]
        or (after[i] & 0x1F) == (before[i] & 0x1F)
        for i in range(256)
    )
    gates_ok = all(
        _udg_gate_branches_are_separate(
            result, gate.descriptor_index, set(source[gate.descriptor_index])
        )
        for gate in udg.progression_gates[level]
    )
    floor_ok = (
        spots_ok and exits_ok and scroll_rooms_ok
        and retained_identity_ok and gates_ok
        and bool(udg.scroll_windows[level])
    )
    ok = ok and floor_ok
    floors.append({
        "floor": level + 1,
        "before": udg_layout_statistics(before),
        "after": udg_layout_statistics(after),
        "protected_spots": len(udg.spot_descriptor_indices(level)),
        "protected_exits": len(udg.retail_terminal_indices(level)),
        "protected_scroll_rooms": len(scroll_rooms),
        "verified_scroll_windows": len(udg.scroll_windows[level]),
        "spots_ok": spots_ok,
        "exits_ok": exits_ok,
        "scroll_rooms_ok": scroll_rooms_ok,
        "retained_identity_ok": retained_identity_ok,
        "gates_ok": gates_ok,
    })

# User-reported first cave: retail descriptors C6-D6-D7-E7-F7 must stay exact.
first_before = udg.layout(0)
first_after = _reviewed_or_generated_udg_layout(
    0, first_before, udg.protected_descriptors(0),
    udg.progression_gate_descriptors(0), udg.scroll_domains(0),
)
first_cells = (0xC6, 0xD6, 0xD7, 0xE7, 0xF7)
first_cave_ok = all(first_after[i] == first_before[i] for i in first_cells)
ok = ok and first_cave_ok

print(json.dumps({
    "ok": ok,
    "scroll_runtime_verified": udg.scroll_runtime_verified,
    "scroll_scan_warnings": list(udg.scroll_scan_warnings),
    "first_cave_scroll_cells": [f"0x{i:02X}" for i in first_cells],
    "first_cave_ok": first_cave_ok,
    "floors": floors,
}, ensure_ascii=False, indent=2))
raise SystemExit(0 if ok else 1)
