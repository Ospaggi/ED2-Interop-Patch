# ED2 Map Editor v0.5.7

한국 DOS판 영웅전설 II의 맵·지하동굴 편집기입니다.

## 실행

```text
run_map_editor.bat
```

또는:

```text
python ed2_map_editor.py
```

게임 폴더에는 `ED2MAIN.EXE`, `MAP`, `SCENA`가 필요합니다.

## 지하동굴 간소화 프리셋

`presets/UDG_RATIONAL_SIMPLIFIED`는 사용자가 검수한 8개 지하동굴 프리셋입니다. 적용 시 NPC·이벤트 방, ROOM 13/17 출입구, ROOM 0 스크롤 민감 위치, 특수 descriptor를 보존하는 검증을 수행합니다.

CLI:

```text
python ed2_map_editor.py --apply-udg-preset <게임폴더>
python ed2_map_editor.py --check-udg-preset <게임폴더>
```

수정본은 별도 게임 복사본에서 플레이 검증하는 것을 권장합니다.
