#!/usr/bin/env python3
"""ED2 Map Editor v0.5.7 - Korean DOS ED2 map editor."""
from __future__ import annotations

import argparse
import csv
import heapq
import hashlib
import json
import multiprocessing
import os
import tempfile
import time
import struct
import zlib
import tkinter as tk
from concurrent.futures import ProcessPoolExecutor
from collections import defaultdict, deque
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Optional

from ed2_formats import (
    MAP_CELLS, MAP_H, MAP_W, UDG_LAYOUT_H, UDG_LAYOUT_W,
    UDG_TEMPLATE_COUNT, UDG_TEMPLATE_H, UDG_TEMPLATE_W,
    UDG_CHEST_VARIANT, UDG_TRANSITION_A_VARIANT, UDG_TRANSITION_B_VARIANT,
    UDG_SPECIAL_TEMPLATE_IDS, UDG_RETAIL_TERMINAL_TEMPLATE_IDS,
    UDGScrollDomain, UDGScrollWindow,
    MapProject, MapRecord, TileSet,
    TransitionRecord, apply_map_changes_xmajor, expand_metatile_map_xmajor,
    parse_map_change_script,
)

APP_NAME = "ED2 Map Editor"
VERSION = "0.5.7"

UDG_VARIANT_LABELS = {
    "일반": 0x00,
    "보물상자(0x40)": UDG_CHEST_VARIANT,
    "전환 마커 A(0x80)": UDG_TRANSITION_A_VARIANT,
    "전환 마커 B(0xC0)": UDG_TRANSITION_B_VARIANT,
}
UDG_PALETTE_CELL = 96
UDG_PALETTE_COLS = 5
UDG_VARIANT_NAMES = {value: label for label, value in UDG_VARIANT_LABELS.items()}
UDG_EMPTY_PALETTE_INDEX = UDG_TEMPLATE_COUNT


def _pointer_graphic_codes(pointer_data: bytes, ptr_no: int, map_mask: int, map_code: int) -> tuple[int, int, int, int]:
    """Pickle-friendly P_000 lookup used by multiprocessing workers."""
    map_code &= 0xFF
    if (map_code >> 7) == (map_mask & 0xFF):
        index = map_code & 0x7F
    else:
        index = (map_mask - 2) & 0x7F
    offset = ptr_no * 512 + index * 4
    raw = pointer_data[offset:offset + 4]
    return raw[0], raw[2], raw[1], raw[3]


def _join_metatile(tile_ids: tuple[int, int, int, int], rgb_tiles: tuple[bytes, ...]) -> bytes:
    """Join four 16x16 RGB tiles into one 32x32 metatile using row copies."""
    tl, tr, bl, br = (rgb_tiles[value & 0x7F] for value in tile_ids)
    out = bytearray(32 * 32 * 3)
    row16 = 16 * 3
    row32 = 32 * 3
    for y in range(16):
        dst = y * row32
        src = y * row16
        out[dst:dst + row16] = tl[src:src + row16]
        out[dst + row16:dst + row32] = tr[src:src + row16]
    for y in range(16):
        dst = (y + 16) * row32
        src = y * row16
        out[dst:dst + row16] = bl[src:src + row16]
        out[dst + row16:dst + row32] = br[src:src + row16]
    return bytes(out)


def _render_atlas_chunk(args) -> list[tuple[int, bytes]]:
    """Render a subset of map codes in a worker process."""
    codes, pointer_data, ptr_no, map_mask, rgb_tiles = args
    return [
        (code, _join_metatile(
            _pointer_graphic_codes(pointer_data, ptr_no, map_mask, code), rgb_tiles
        ))
        for code in codes
    ]


def _compose_rgb_grid(codes: bytes, width: int, height: int, blocks: tuple[bytes, ...], cell: int) -> bytes:
    """Compose a tile grid with contiguous row slices instead of pixel loops."""
    if len(codes) != width * height:
        raise ValueError("Grid size does not match code count")
    row_bytes = cell * 3
    canvas_row = width * row_bytes
    out = bytearray(width * cell * height * cell * 3)
    for gy in range(height):
        base = gy * width
        for py in range(cell):
            dst = (gy * cell + py) * canvas_row
            src = py * row_bytes
            for gx in range(width):
                block = blocks[codes[base + gx] & 0xFF]
                start = dst + gx * row_bytes
                out[start:start + row_bytes] = block[src:src + row_bytes]
    return bytes(out)


def _average_rgb(block: bytes) -> tuple[int, int, int]:
    count = len(block) // 3
    if not count:
        return (0, 0, 0)
    return (
        sum(block[0::3]) // count,
        sum(block[1::3]) // count,
        sum(block[2::3]) // count,
    )


def _png_chunk(kind: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data)) + kind + data
        + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    )


def write_png_rgb_rows(path: Path, width: int, height: int, rows) -> None:
    """Write an RGB PNG from an iterable of scanlines without Pillow.

    Rows are compressed and emitted as multiple IDAT chunks, so a 5120x5120
    underground floor can be exported without holding another full-sized PNG
    buffer in memory.
    """
    if width <= 0 or height <= 0:
        raise ValueError("PNG dimensions must be positive")
    expected = width * 3
    compressor = zlib.compressobj(level=6)
    count = 0
    with Path(path).open("wb") as fp:
        fp.write(b"\x89PNG\r\n\x1a\n")
        fp.write(_png_chunk("IHDR".encode("ascii"), struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)))
        for count, row in enumerate(rows, start=1):
            row = bytes(row)
            if len(row) != expected:
                raise ValueError(
                    f"PNG row {count} has {len(row)} bytes; expected {expected}"
                )
            packed = compressor.compress(b"\x00" + row)
            if packed:
                fp.write(_png_chunk(b"IDAT", packed))
        if count != height:
            raise ValueError(f"PNG has {count} rows; expected {height}")
        packed = compressor.flush()
        if packed:
            fp.write(_png_chunk(b"IDAT", packed))
        fp.write(_png_chunk(b"IEND", b""))


def rgb_rows(rgb: bytes, width: int, height: int):
    stride = width * 3
    if len(rgb) != stride * height:
        raise ValueError("RGB buffer size does not match image dimensions")
    for y in range(height):
        yield rgb[y * stride:(y + 1) * stride]


UDG_NORTH = 0x01
UDG_EAST = 0x02
UDG_SOUTH = 0x04
UDG_WEST = 0x08
UDG_DIRECTIONS = (
    (-1, 0, UDG_NORTH, UDG_SOUTH),
    (0, 1, UDG_EAST, UDG_WEST),
    (1, 0, UDG_SOUTH, UDG_NORTH),
    (0, -1, UDG_WEST, UDG_EAST),
)

# Connectivity of the retail 10x10 UDG room modules.  The high descriptor
# bits only add chest/stair overlays; movement connectivity comes from the
# low five-bit room template number.
UDG_ROOM_MASKS = {
    # The source room sheets are x-major.  v0.4.8 inferred these openings
    # from the transposed preview, so every direction was transposed too.
    # Correct mapping under x/y transpose: N->W, E->S, S->E, W->N.
    0: UDG_NORTH | UDG_SOUTH,
    1: UDG_EAST | UDG_SOUTH,
    2: UDG_NORTH | UDG_EAST,
    3: UDG_NORTH | UDG_SOUTH,
    4: UDG_SOUTH | UDG_WEST,
    5: UDG_NORTH | UDG_WEST,
    6: UDG_EAST | UDG_WEST,
    7: UDG_EAST | UDG_SOUTH | UDG_WEST,
    8: UDG_NORTH | UDG_EAST | UDG_WEST,
    9: UDG_SOUTH,
    10: UDG_EAST,
    11: UDG_WEST,
    12: UDG_NORTH,
    13: UDG_NORTH,
    14: UDG_NORTH | UDG_EAST | UDG_SOUTH | UDG_WEST,
    15: UDG_NORTH | UDG_EAST | UDG_SOUTH,
    16: UDG_NORTH | UDG_SOUTH | UDG_WEST,
    17: UDG_SOUTH,
}
UDG_MASK_TO_ROOM = {
    UDG_NORTH: 12,
    UDG_EAST: 10,
    UDG_SOUTH: 9,
    UDG_WEST: 11,
    UDG_NORTH | UDG_EAST: 2,
    UDG_NORTH | UDG_SOUTH: 3,
    UDG_NORTH | UDG_WEST: 5,
    UDG_EAST | UDG_SOUTH: 1,
    UDG_EAST | UDG_WEST: 6,
    UDG_SOUTH | UDG_WEST: 4,
    UDG_NORTH | UDG_EAST | UDG_SOUTH: 15,
    UDG_NORTH | UDG_EAST | UDG_WEST: 8,
    UDG_NORTH | UDG_SOUTH | UDG_WEST: 16,
    UDG_EAST | UDG_SOUTH | UDG_WEST: 7,
    UDG_NORTH | UDG_EAST | UDG_SOUTH | UDG_WEST: 14,
}


def _udg_xy(index: int) -> tuple[int, int]:
    return index % UDG_LAYOUT_W, index // UDG_LAYOUT_W


def _udg_index(x: int, y: int) -> int:
    return y * UDG_LAYOUT_W + x


def _udg_graph(descriptors: bytes) -> dict[int, set[int]]:
    graph: dict[int, set[int]] = {}
    for index, value in enumerate(descriptors):
        if value == 0xFF:
            continue
        room_id = value & 0x1F
        mask = UDG_ROOM_MASKS[room_id]
        x, y = _udg_xy(index)
        graph[index] = set()
        for dy, dx, bit, opposite in UDG_DIRECTIONS:
            nx, ny = x + dx, y + dy
            if not (mask & bit) or not (0 <= nx < UDG_LAYOUT_W and 0 <= ny < UDG_LAYOUT_H):
                continue
            other = _udg_index(nx, ny)
            other_value = descriptors[other]
            if other_value != 0xFF and (UDG_ROOM_MASKS[other_value & 0x1F] & opposite):
                graph[index].add(other)
    return graph


def _udg_components(graph: dict[int, set[int]]) -> list[set[int]]:
    result: list[set[int]] = []
    visited: set[int] = set()
    for start in graph:
        if start in visited:
            continue
        component = {start}
        stack = [start]
        visited.add(start)
        while stack:
            current = stack.pop()
            for other in graph[current]:
                if other not in visited:
                    visited.add(other)
                    component.add(other)
                    stack.append(other)
        result.append(component)
    return result


def _udg_special_port(index: int, descriptor: int) -> int:
    mask = UDG_ROOM_MASKS[descriptor & 0x1F]
    if mask not in (UDG_NORTH, UDG_EAST, UDG_SOUTH, UDG_WEST):
        raise ValueError(f"Special UDG room {descriptor & 0x1F} is not a one-way terminal")
    x, y = _udg_xy(index)
    for dy, dx, bit, _opposite in UDG_DIRECTIONS:
        if mask == bit:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < UDG_LAYOUT_W and 0 <= ny < UDG_LAYOUT_H):
                raise ValueError(f"Special UDG room at {index:02X} opens outside the layout")
            return _udg_index(nx, ny)
    raise AssertionError("unreachable")


def _udg_choose_access_anchors(
    descriptors: bytes,
    component: set[int],
    graph: dict[int, set[int]],
    special: set[int],
) -> list[int]:
    """Keep a small number of ordinary endpoints for unmarked scene entries.

    The retail layouts contain several intentionally separate components.  We
    do not merge them.  Components with fewer than two scripted transition
    markers retain one or two far-apart ordinary leaves so scene code that
    starts in an unmarked room still has a valid access route.
    """
    leaves = [index for index in component if len(graph[index]) == 1 and index not in special]
    if not leaves:
        leaves = sorted(component - special) or sorted(component)
    transitions = [
        index for index in special
        if descriptors[index] & 0xC0 in (UDG_TRANSITION_A_VARIANT, UDG_TRANSITION_B_VARIANT)
    ]
    if len(transitions) >= 2:
        needed = 0
    elif transitions or special:
        needed = 1
    else:
        needed = 2
    chosen: list[int] = []
    references = list(transitions or special)
    candidates = list(leaves)
    for _ in range(needed):
        if not candidates:
            break
        if not references and not chosen:
            pick = min(candidates)
        else:
            bases = references + chosen
            pick = max(
                candidates,
                key=lambda index: (
                    min(
                        abs(_udg_xy(index)[0] - _udg_xy(base)[0])
                        + abs(_udg_xy(index)[1] - _udg_xy(base)[1])
                        for base in bases
                    ),
                    index,
                ),
            )
        chosen.append(pick)
        candidates.remove(pick)
    return chosen


def _udg_voronoi_regions(components: list[set[int]]) -> list[set[int]]:
    """Partition all 256 cells so independently simplified sections never overlap."""
    regions = [set() for _ in components]
    for index in range(UDG_LAYOUT_W * UDG_LAYOUT_H):
        x, y = _udg_xy(index)
        best: Optional[tuple[tuple[int, int, int], int]] = None
        for number, component in enumerate(components):
            distance = min(
                abs(x - _udg_xy(cell)[0]) + abs(y - _udg_xy(cell)[1])
                for cell in component
            )
            key = (distance, 0 if index in component else 1, number)
            if best is None or key < best[0]:
                best = (key, number)
        assert best is not None
        regions[best[1]].add(index)
    return regions


def _udg_route_to_tree(
    start: int,
    tree: set[int],
    allowed: set[int],
    blocked: set[int],
) -> list[int]:
    """Route a short orthogonal corridor, preferring shared segments and few turns."""
    if start in tree:
        return [start]
    queue: list[tuple[float, int, int, int]] = [(0.0, 0, start, 4)]
    best_cost: dict[tuple[int, int], float] = {(start, 4): 0.0}
    previous: dict[tuple[int, int], tuple[int, int]] = {}
    serial = 0
    target: Optional[tuple[int, int]] = None
    while queue:
        cost, _serial, current, previous_direction = heapq.heappop(queue)
        state = (current, previous_direction)
        if cost != best_cost.get(state):
            continue
        if current in tree and current not in blocked:
            target = state
            break
        x, y = _udg_xy(current)
        for direction, (dy, dx, _bit, _opposite) in enumerate(UDG_DIRECTIONS):
            nx, ny = x + dx, y + dy
            if not (0 <= nx < UDG_LAYOUT_W and 0 <= ny < UDG_LAYOUT_H):
                continue
            other = _udg_index(nx, ny)
            if other not in allowed or other in blocked:
                continue
            step = 0.18 if other in tree else 1.0
            if previous_direction != 4 and previous_direction != direction:
                step += 0.55
            if nx in (0, UDG_LAYOUT_W - 1) or ny in (0, UDG_LAYOUT_H - 1):
                step += 0.08
            new_cost = cost + step
            other_state = (other, direction)
            if new_cost + 1e-9 < best_cost.get(other_state, float("inf")):
                best_cost[other_state] = new_cost
                previous[other_state] = state
                serial += 1
                heapq.heappush(queue, (new_cost, serial, other, direction))
    if target is None:
        raise ValueError(f"Could not simplify UDG route from {_udg_xy(start)}")
    path: list[int] = []
    state = target
    while True:
        path.append(state[0])
        if state == (start, 4):
            break
        state = previous[state]
    path.reverse()
    return path


def _udg_add_path(edges: set[tuple[int, int]], path: list[int]) -> None:
    for first, second in zip(path, path[1:]):
        edges.add((first, second) if first < second else (second, first))


def udg_layout_statistics(descriptors: bytes) -> dict[str, int]:
    graph = _udg_graph(descriptors)
    components = _udg_components(graph)
    degrees = [len(value) for value in graph.values()]
    return {
        "rooms": len(graph),
        "corridors": sum(degrees) // 2,
        "components": len(components),
        "junctions": sum(value >= 3 for value in degrees),
        "dead_ends": sum(value == 1 for value in degrees),
    }


def _udg_build_sparse_component(
    descriptors: bytes,
    component: set[int],
    allowed: set[int],
    source_graph: dict[int, set[int]],
    scripted: set[int],
    retail_terminals: set[int],
    fixed_rooms: set[int],
    blocked: set[int],
    mandatory_anchors: tuple[int, ...] = (),
    strict_allowed: bool = False,
) -> set[tuple[int, int]]:
    """Rebuild one cave section while retaining exact NPC/event rooms.

    ``fixed_rooms`` are direct SINAL-linked descriptors.  Their original
    incident edges are copied byte-for-byte through the descriptor mask, but
    unrelated UG_MAP_NO 3x3 windows are not retained.  This preserves actors
    and triggers without restoring the overly broad v0.5.0 scene lock.
    """
    component_scripted = sorted(component & scripted)
    component_terminals = sorted(component & retail_terminals)
    component_fixed_set = set(component & fixed_rooms)
    component_protected = sorted(
        component & (scripted | retail_terminals | fixed_rooms)
    )
    access_anchors = _udg_choose_access_anchors(
        descriptors, component, source_graph, set(component_protected)
    )
    if strict_allowed:
        access_anchors = [index for index in access_anchors if index in allowed]

    fixed_edges: set[tuple[int, int]] = set()
    scripted_ports: list[tuple[int, int]] = []
    terminal_ports: list[tuple[int, int]] = []
    for marker in component_scripted:
        port = _udg_special_port(marker, descriptors[marker])
        scripted_ports.append((marker, port))
        fixed_edges.add(tuple(sorted((marker, port))))
    scripted_markers = {marker for marker, _port in scripted_ports}
    for marker in component_terminals:
        if marker in scripted_markers:
            continue
        port = _udg_special_port(marker, descriptors[marker])
        terminal_ports.append((marker, port))
        fixed_edges.add(tuple(sorted((marker, port))))

    # A protected room can expose an original port in the outer part of the
    # 3x3 buffer.  Do not bend that port toward a new corridor: preserve the
    # complete original outside-band chain until it reaches a verified center
    # cell.  This prevents nodes such as floor-5 0x6C from changing shape at
    # the scroll limit merely because they are attachment points.
    if strict_allowed:
        seed_cells = (
            set(component_fixed_set)
            | {port for _marker, port in scripted_ports}
            | {port for _marker, port in terminal_ports}
            | set(mandatory_anchors)
        )
        outside_queue = [
            index for index in seed_cells
            if index in component and index not in allowed
        ]
        for seed in tuple(seed_cells):
            for other in source_graph.get(seed, ()):
                if other in component and other not in allowed:
                    outside_queue.append(other)
        while outside_queue:
            current = outside_queue.pop()
            if current in component_fixed_set:
                pass
            else:
                component_fixed_set.add(current)
            for other in source_graph.get(current, ()):
                if (
                    other in component and other not in allowed
                    and other not in component_fixed_set
                ):
                    component_fixed_set.add(other)
                    outside_queue.append(other)

    component_fixed = sorted(component_fixed_set)
    effective_blocked = set(blocked) | component_fixed_set
    fixed_ports: list[int] = []
    for room in component_fixed:
        neighbors = sorted(source_graph.get(room, ()))
        if not neighbors:
            fixed_ports.append(room)
            continue
        for neighbor in neighbors:
            if neighbor not in component:
                # Gate-aware branch simplification handles the gate edge in
                # the parent routine.  A protected room adjacent to that gate
                # is still valid inside its own branch.
                continue
            fixed_edges.add(tuple(sorted((room, neighbor))))
            if neighbor not in fixed_rooms:
                fixed_ports.append(neighbor)

    fixed_adjacency: dict[int, set[int]] = defaultdict(set)
    for first, second in fixed_edges:
        fixed_adjacency[first].add(second)
        fixed_adjacency[second].add(first)

    primary = [
        port for marker, port in scripted_ports
        if descriptors[marker] & 0xC0
        in (UDG_TRANSITION_A_VARIANT, UDG_TRANSITION_B_VARIANT)
    ]
    primary += [port for _marker, port in terminal_ports]
    primary += fixed_ports
    primary += list(mandatory_anchors)
    primary += access_anchors
    # Never start a generated route from a protected descriptor.  A protected
    # room may be the inward neighbor of ROOM 13/17; routing directly from it
    # can create a new doorway even though its fixed edges are preserved.
    # Its fixed cluster already exposes ordinary boundary ports for attachment.
    primary = [node for node in primary if node not in effective_blocked]
    treasure_ports = [
        port for marker, port in scripted_ports
        if (descriptors[marker] & 0xC0) == UDG_CHEST_VARIANT
        and port not in effective_blocked
    ]

    nodes: list[int] = []
    for node in primary + treasure_ports:
        if node in component and node not in nodes:
            nodes.append(node)
    if not nodes:
        ordinary = sorted(
            (component - fixed_rooms)
            & (set(allowed) if strict_allowed else component)
        )
        if ordinary:
            nodes.append(ordinary[0])
        else:
            return fixed_edges

    if strict_allowed:
        allowed = set(allowed) | set(nodes) | set(fixed_adjacency)
    else:
        allowed = set(allowed) | component | set(nodes)
    edges = set(fixed_edges)
    tree: set[int] = set()

    def absorb_fixed_cluster(seed: int) -> None:
        stack = [seed]
        while stack:
            current = stack.pop()
            if current in tree:
                pass
            else:
                tree.add(current)
            for other in fixed_adjacency.get(current, ()):
                if other not in tree:
                    tree.add(other)
                    stack.append(other)

    def attach(node: int) -> None:
        if node in tree:
            absorb_fixed_cluster(node)
            return
        if not tree:
            absorb_fixed_cluster(node)
            return
        path = _udg_route_to_tree(node, tree, allowed, effective_blocked)
        _udg_add_path(edges, path)
        for cell in path:
            absorb_fixed_cluster(cell)

    attach((primary or nodes)[0])
    remaining = [node for node in primary if node not in tree]
    while remaining:
        node = min(
            remaining,
            key=lambda candidate: min(
                abs(_udg_xy(candidate)[0] - _udg_xy(tree_cell)[0])
                + abs(_udg_xy(candidate)[1] - _udg_xy(tree_cell)[1])
                for tree_cell in tree
            ),
        )
        attach(node)
        remaining = [candidate for candidate in remaining if candidate not in tree]

    for node in treasure_ports + nodes:
        attach(node)
    return edges

def _udg_component_without_gate(
    graph: dict[int, set[int]], component: set[int], gate: int,
) -> list[set[int]]:
    """Split a retail section into the branches controlled by one gate."""
    remaining = set(component) - {gate}
    result: list[set[int]] = []
    visited: set[int] = set()
    for start in sorted(remaining):
        if start in visited:
            continue
        branch = {start}
        visited.add(start)
        stack = [start]
        while stack:
            current = stack.pop()
            for other in graph[current]:
                if other != gate and other in remaining and other not in visited:
                    visited.add(other)
                    branch.add(other)
                    stack.append(other)
        result.append(branch)
    return result


def _udg_partition_gate_region(
    region: set[int], branches: list[set[int]], gate: int,
) -> list[set[int]]:
    """Give each original gate branch its own routing area.

    A branch-aware Voronoi partition prevents the simplifier from drawing a
    shortcut between two sides of the blocking NPC.  The only common cell is
    the gate itself, whose original doorways are restored separately.
    """
    result = [set() for _ in branches]
    for index in sorted(set(region) - {gate}):
        x, y = _udg_xy(index)
        best: Optional[tuple[tuple[int, int, int], int]] = None
        for number, branch in enumerate(branches):
            distance = min(
                abs(x - _udg_xy(cell)[0]) + abs(y - _udg_xy(cell)[1])
                for cell in branch
            )
            key = (distance, 0 if index in branch else 1, number)
            if best is None or key < best[0]:
                best = (key, number)
        assert best is not None
        result[best[1]].add(index)
    return result


def _udg_gate_branches_are_separate(
    graph: dict[int, set[int]], gate: int, expected_neighbors: set[int],
) -> bool:
    """Return True when every original side remains separated without gate."""
    neighbors = sorted(expected_neighbors)
    if set(graph.get(gate, ())) != expected_neighbors:
        return False
    for number, start in enumerate(neighbors):
        seen = {gate, start}
        stack = [start]
        while stack:
            current = stack.pop()
            for other in graph.get(current, ()):
                if other not in seen:
                    seen.add(other)
                    stack.append(other)
        if any(other in seen for other in neighbors[number + 1:]):
            return False
    return True


def simplify_udg_layout(
    descriptors: bytes,
    protected_descriptors: Optional[dict[int, int]] = None,
    progression_gates: Optional[dict[int, int]] = None,
    scroll_domains: Optional[tuple[UDGScrollDomain, ...]] = None,
) -> bytes:
    """Strongly simplify a cave while preserving gameplay-linked rooms.

    General NPC, dialogue and event rooms keep their exact descriptor and
    original doorways.  Retail ROOM 13/17 cross-map entrance/exit terminals
    also keep their coordinates, complete descriptor bytes and inward port.
    Generic UG_MAP_NO 3x3 scene windows are not blanket protected.
    Progression gates additionally retain their articulation and cannot be
    bypassed by newly generated corridors.  Retail ROOM 0 cells are fixed,
    and any retained cell keeps its original room-module ID whenever its
    generated doorway mask still matches the retail mask.  This preserves
    internal walkable geometry that the coarse room graph cannot represent.
    """
    if len(descriptors) != UDG_LAYOUT_W * UDG_LAYOUT_H:
        raise ValueError("UDG layout must contain exactly 256 descriptors")

    supplied_protected = dict(protected_descriptors or {})
    gates = dict(progression_gates or {})
    source_graph = _udg_graph(descriptors)
    source_components = _udg_components(source_graph)
    regions = _udg_voronoi_regions(source_components)
    # scroll_domains is supplied for audit compatibility.  Exact scroll-room
    # protection is already represented in protected_descriptors; broad scene
    # windows are intentionally not used as route constraints.
    _ = scroll_domains
    scripted = {
        index for index, value in enumerate(descriptors)
        if value != 0xFF and (value & 0xC0)
    }
    # ROOM 13/17 are retail cross-map entrance/exit terminals.  They are
    # visually ordinary one-way descriptors, but changing either the room ID
    # or its position changes the tile used to leave/enter the dungeon.
    retail_terminals: set[int] = {
        index for index, value in enumerate(descriptors)
        if value != 0xFF
        and (value & 0x1F) in UDG_RETAIL_TERMINAL_TEMPLATE_IDS
    }
    # Manual editing exposes ROOM 13/17 through protected_descriptors, but the
    # route builder must treat them as one-way terminal anchors rather than as
    # ordinary fixed clusters.  Otherwise a terminal adjacent to an event room
    # can accidentally make that event room absorb an extra generated doorway.
    direct = {
        index: value for index, value in supplied_protected.items()
        if index not in retail_terminals
    }
    for index, original in supplied_protected.items():
        if index not in source_graph or descriptors[index] != original:
            raise ValueError(
                f"UDG NPC/event room is missing or changed at {index:02X}"
            )
    for gate, original in gates.items():
        if gate not in source_graph or descriptors[gate] != original:
            raise ValueError(f"UDG progression gate is missing or changed at {gate:02X}")
        if len(source_graph[gate]) < 2:
            raise ValueError(f"UDG progression gate at {gate:02X} does not control a route")
        branches = _udg_component_without_gate(
            source_graph,
            next(component for component in source_components if gate in component),
            gate,
        )
        touched = [branch for branch in branches if branch & source_graph[gate]]
        if len(touched) < 2:
            raise ValueError(f"UDG progression gate at {gate:02X} is not an articulation")

    fixed_rooms = set(direct) | set(gates)
    protected = scripted | retail_terminals | fixed_rooms
    fixed_descriptors = {
        index: descriptors[index]
        for index in protected
    }
    result_edges: set[tuple[int, int]] = set()
    force_original: set[int] = set()

    def preserve_component(component: set[int]) -> None:
        force_original.update(component)
        for first in component:
            for second in source_graph[first]:
                if first < second:
                    result_edges.add((first, second))

    for component_number, component in enumerate(source_components):
        component_gates = sorted(component & set(gates))
        try:
            local_edges: set[tuple[int, int]] = set()
            if not component_gates:
                local_edges.update(_udg_build_sparse_component(
                    descriptors, component, regions[component_number], source_graph,
                    scripted, retail_terminals, fixed_rooms, protected,
                ))
            else:
                if len(component_gates) != 1:
                    raise ValueError(
                        "Multiple progression gates in one cave section require a "
                        "manual route review"
                    )
                gate = component_gates[0]
                gate_neighbors = set(source_graph[gate])
                for neighbor in gate_neighbors:
                    local_edges.add(tuple(sorted((gate, neighbor))))

                branches = _udg_component_without_gate(source_graph, component, gate)
                branch_regions = _udg_partition_gate_region(
                    regions[component_number], branches, gate
                )
                for branch, branch_region in zip(branches, branch_regions):
                    gate_ports = tuple(sorted(branch & gate_neighbors))
                    local_edges.update(_udg_build_sparse_component(
                        descriptors, branch, branch_region, source_graph,
                        scripted, retail_terminals, fixed_rooms, protected,
                        mandatory_anchors=gate_ports,
                    ))
            result_edges.update(local_edges)
        except ValueError:
            preserve_component(component)

    fixed_descriptors.update({
        index: descriptors[index] for index in force_original
    })

    masks: dict[int, int] = defaultdict(int)
    for first, second in result_edges:
        first_x, first_y = _udg_xy(first)
        second_x, second_y = _udg_xy(second)
        if second_x == first_x + 1:
            masks[first] |= UDG_EAST
            masks[second] |= UDG_WEST
        elif second_x == first_x - 1:
            masks[first] |= UDG_WEST
            masks[second] |= UDG_EAST
        elif second_y == first_y + 1:
            masks[first] |= UDG_SOUTH
            masks[second] |= UDG_NORTH
        elif second_y == first_y - 1:
            masks[first] |= UDG_NORTH
            masks[second] |= UDG_SOUTH
        else:
            raise ValueError("UDG route contains a non-adjacent edge")

    output = bytearray([0xFF] * (UDG_LAYOUT_W * UDG_LAYOUT_H))
    for index, original in fixed_descriptors.items():
        output[index] = original
    for index, mask in masks.items():
        if index in fixed_descriptors:
            original_mask = UDG_ROOM_MASKS[fixed_descriptors[index] & 0x1F]
            if mask & ~original_mask:
                raise ValueError(
                    f"UDG protected room gained a new doorway at {index:02X}: original=0x{original_mask:X}, generated=0x{mask:X}"
                )
            # Keep the original descriptor even when the retail room contains
            # a deliberately dangling visual doorway.  Graph validation below
            # checks the reciprocal, actually traversable neighbors.
            continue
        original = descriptors[index]
        if (
            original != 0xFF
            and (original & 0xC0) == 0
            and UDG_ROOM_MASKS[original & 0x1F] == mask
        ):
            # Preserve the retail module identity whenever the simplified
            # topology still uses the same cell.  ROOM 0 and ROOM 3 share a
            # coarse N/S mask but have different internal walkable geometry;
            # normalizing ROOM 0 to ROOM 3 caused the first-cave scroll lock.
            output[index] = original
            continue
        room_id = UDG_MASK_TO_ROOM.get(mask)
        if room_id is None:
            raise ValueError(
                f"No UDG room template for connectivity mask 0x{mask:X}"
            )
        output[index] = room_id

    result = bytes(output)
    result_graph = _udg_graph(result)
    result_components = _udg_components(result_graph)
    if len(result_components) != len(source_components):
        raise ValueError("UDG simplification changed the number of isolated sections")

    membership_markers = scripted | fixed_rooms
    source_groups = sorted(
        tuple(sorted(component & membership_markers))
        for component in source_components
    )
    result_groups = sorted(
        tuple(sorted(component & membership_markers))
        for component in result_components
    )
    if source_groups != result_groups:
        raise ValueError("UDG simplification changed protected-room section membership")

    for index in scripted:
        if result[index] != descriptors[index] or len(result_graph.get(index, ())) != 1:
            raise ValueError(f"UDG protected endpoint became unreachable at {index:02X}")
    for index in fixed_rooms:
        if (
            result[index] != descriptors[index]
            or set(result_graph.get(index, ())) != set(source_graph.get(index, ()))
        ):
            raise ValueError(
                f"UDG NPC/event room topology changed at {index:02X}"
            )
    for gate, original in gates.items():
        if result[gate] != original or not _udg_gate_branches_are_separate(
            result_graph, gate, set(source_graph[gate])
        ):
            raise ValueError(
                f"UDG progression gate topology changed at {gate:02X}"
            )
    return result


SCRIPT_DIR = Path(__file__).resolve().parent
UDG_RETAIL_SHA256 = (
    "ec40a15d72714d34c15903b85d9f747468032d61083c11cfa1cb174a71c12846",
    "4f0c854cb8d778e9e14ad91d0c19b74b3e92a1504ee7ed8746543a53ac1c55d0",
    "91c43aacbc3fc2a93f0bfc9a06af032fa179189a86244a62f4341aac88f06091",
    "dc284dbcc0147bf5eec0a738f84448901dd55731d65c808782f9fa9f4ed87d21",
    "e2a1934fac5b1da251d8ac4a98c582c7a411027251dc6e34f5e51ac35dd377e3",
    "fb86a5e25cddb97e0de102963431775fec3cafc4dcdbe73e2105845de824c4c5",
    "01c3f70768ff88e9ad6fd907b80dd6e328d4d7e9874f092fb2d67e72cde5f079",
    "288eebdad61221c1d3e1f2724e13e0c827cc66966a54a74464912a1f1e0be072",
)


def _bundled_udg_preset(level: int) -> Optional[bytes]:
    """Read the reviewed strong-simplification preset bundled with the tool."""
    path = SCRIPT_DIR / "presets" / "UDG_RATIONAL_SIMPLIFIED" / (
        f"ED2_special_udg-layout_{level}.csv"
    )
    if not path.is_file():
        return None
    rows: list[int] = []
    with path.open("r", encoding="utf-8-sig", newline="") as fp:
        for row in csv.reader(fp):
            if row:
                rows.extend(int(value, 0) for value in row)
    if len(rows) != UDG_LAYOUT_W * UDG_LAYOUT_H:
        raise ValueError(f"Bundled UDG floor {level + 1} preset is malformed")
    return bytes(rows)


def _reviewed_or_generated_udg_layout(
    level: int,
    descriptors: bytes,
    protected_descriptors: dict[int, int],
    progression_gates: dict[int, int],
    scroll_domains: tuple[UDGScrollDomain, ...],
) -> bytes:
    """Use reviewed retail output when applicable, otherwise simplify live data."""
    preset = _bundled_udg_preset(level)
    digest = hashlib.sha256(descriptors).hexdigest()
    if preset is not None and (
        digest == UDG_RETAIL_SHA256[level] or descriptors == preset
    ):
        # The bundled layout is the manually reviewed final preset.  It may
        # intentionally differ from the automatic simplifier, so prefer it
        # directly for the supported retail layout.  Structural safety is
        # enforced by UndergroundDungeonData.validate_layout_edit() on save.
        return preset
    return simplify_udg_layout(
        descriptors, protected_descriptors, progression_gates, scroll_domains
    )


class Editor(tk.Tk):
    def __init__(self, initial_root: Optional[Path] = None):
        super().__init__()
        self.title(f"{APP_NAME} v{VERSION}")
        self.geometry("1440x900")
        self.minsize(1024, 700)
        self.project: Optional[MapProject] = None
        self.records: dict[str, MapRecord] = {}
        self.current: Optional[MapRecord] = None
        self.tiles = bytearray()
        self.tileset: Optional[TileSet] = None
        self._preview_tile_cache: dict[tuple[str, int, int, int], bytes] = {}
        self._atlas_cache: dict[tuple[str, int, int], tuple[bytes, ...]] = {}
        self._direct_atlas_cache: dict[str, tuple[bytes, ...]] = {}
        self._palette_context_key: Optional[tuple] = None
        self._palette_rgb_cache: Optional[tuple[int, int, bytes]] = None
        self._redraw_after_id: Optional[str] = None
        self._parallel_workers = max(1, min(4, os.cpu_count() or 1))
        self._executor: Optional[ProcessPoolExecutor] = None
        self._last_render_ms = 0.0
        self.context_by_label: dict[str, TransitionRecord] = {}
        self.current_context: Optional[TransitionRecord] = None
        self.selected_code = 0
        self.modified = False
        self.undo_stack: list[bytes] = []
        self.redo_stack: list[bytes] = []
        self.drag_start: Optional[tuple[int, int]] = None
        self.last_painted: Optional[tuple[int, int]] = None
        self.zoom = tk.IntVar(value=1)
        self.tool = tk.StringVar(value="pencil")
        self.view_mode = tk.StringVar(value="graphics")
        self.grid_var = tk.BooleanVar(value=True)
        self.dynamic_changes_var = tk.BooleanVar(value=False)
        self.special_ptr_var = tk.IntVar(value=44)
        self.udg_variant_var = tk.StringVar(value="일반")
        self.udg_room_palette_image: Optional[tk.PhotoImage] = None
        self._map_base_image: Optional[tk.PhotoImage] = None
        self._map_image: Optional[tk.PhotoImage] = None
        self._palette_image: Optional[tk.PhotoImage] = None
        self._temp = tempfile.TemporaryDirectory(prefix="ed2_map_editor_")
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._close)
        if initial_root:
            self.after(30, lambda: self.open_project(initial_root))

    def _build_ui(self) -> None:
        top = ttk.Frame(self, padding=7)
        top.pack(fill="x")
        ttk.Button(top, text="게임 폴더 열기", command=self.choose_project).pack(side="left")
        ttk.Button(top, text="저장", command=self.save_current).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="이 도구 변경만 복원", command=self.restore_current).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="CSV 내보내기", command=self.export_csv).pack(side="left", padx=(18, 0))
        ttk.Button(top, text="CSV 가져오기", command=self.import_csv).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="전체 맵 PNG", command=self.export_png).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="UDG 이벤트·스크롤 안전 간소화", command=self.simplify_all_udg).pack(side="left", padx=(18, 0))
        ttk.Button(top, text="전체 검사", command=self.validate_project).pack(side="left", padx=(6, 0))
        self.root_label = ttk.Label(top, text="ED2MAIN.EXE와 MAP 폴더가 있는 게임 폴더를 선택하세요.")
        self.root_label.pack(side="left", padx=16)

        tools = ttk.Frame(self, padding=(7, 0, 7, 7))
        tools.pack(fill="x")
        for value, label in (("pencil", "연필"), ("fill", "채우기"), ("rectangle", "사각형"), ("picker", "스포이드")):
            ttk.Radiobutton(tools, text=label, value=value, variable=self.tool).pack(side="left")
        ttk.Button(tools, text="실행 취소", command=self.undo).pack(side="left", padx=(12, 0))
        ttk.Button(tools, text="다시 실행", command=self.redo).pack(side="left", padx=(4, 0))
        ttk.Label(tools, text="확대").pack(side="left", padx=(18, 4))
        zoom = ttk.Combobox(tools, values=(1, 2, 3, 4), state="readonly", width=4, textvariable=self.zoom)
        zoom.pack(side="left")
        zoom.bind("<<ComboboxSelected>>", lambda _e: self.redraw())
        ttk.Checkbutton(tools, text="격자", variable=self.grid_var, command=self.redraw).pack(side="left", padx=(8, 0))
        ttk.Checkbutton(
            tools, text="동적 맵 변경 모두 표시", variable=self.dynamic_changes_var, command=self.redraw
        ).pack(side="left", padx=(8, 0))
        ttk.Label(tools, text="특수 PTR").pack(side="left", padx=(14, 3))
        self.special_ptr_spin = ttk.Spinbox(
            tools, from_=0, to=44, width=4, textvariable=self.special_ptr_var,
            command=self._special_ptr_changed,
        )
        self.special_ptr_spin.pack(side="left")
        self.special_ptr_spin.bind("<Return>", self._special_ptr_changed)
        self.special_ptr_spin.bind("<FocusOut>", self._special_ptr_changed)
        ttk.Label(tools, text="UDG 속성").pack(side="left", padx=(12, 3))
        self.udg_variant_box = ttk.Combobox(
            tools, state="readonly", width=17,
            values=tuple(UDG_VARIANT_LABELS), textvariable=self.udg_variant_var,
        )
        self.udg_variant_box.pack(side="left")
        self.udg_variant_box.bind("<<ComboboxSelected>>", self._udg_variant_changed)
        ttk.Radiobutton(tools, text="그래픽", value="graphics", variable=self.view_mode, command=self.redraw).pack(side="left", padx=(16, 0))
        ttk.Radiobutton(tools, text="타일 번호", value="numeric", variable=self.view_mode, command=self.redraw).pack(side="left")

        pane = ttk.Panedwindow(self, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=7, pady=(0, 7))

        left = ttk.Frame(pane)
        pane.add(left, weight=2)
        ttk.Label(left, text="맵 목록").grid(row=0, column=0, sticky="w")
        self.map_tree = ttk.Treeview(left, columns=("kind", "file", "bc", "scene"), show="tree headings", selectmode="browse")
        for column, title, width in (("#0", "맵", 130), ("kind", "형식", 180), ("file", "저장 위치", 170), ("bc", "BC 후보", 130), ("scene", "사용 씬 DLL", 250)):
            self.map_tree.heading(column, text=title)
            self.map_tree.column(column, width=width, stretch=False)
        tree_y = ttk.Scrollbar(left, orient="vertical", command=self.map_tree.yview)
        tree_x = ttk.Scrollbar(left, orient="horizontal", command=self.map_tree.xview)
        self.map_tree.configure(yscrollcommand=tree_y.set, xscrollcommand=tree_x.set)
        self.map_tree.grid(row=1, column=0, sticky="nsew")
        tree_y.grid(row=1, column=1, sticky="ns")
        tree_x.grid(row=2, column=0, sticky="ew")
        self.map_tree.bind("<<TreeviewSelect>>", self._map_selected)

        ttk.Label(left, text="씬 사용처 / 실제 전환 컨텍스트").grid(row=3, column=0, sticky="w", pady=(9, 0))
        self.context_box = ttk.Combobox(left, state="readonly")
        self.context_box.grid(row=4, column=0, columnspan=2, sticky="ew")
        self.context_box.bind("<<ComboboxSelected>>", self._context_selected)

        ttk.Label(left, text="실제 배경 타일셋(BC_NO)").grid(row=5, column=0, sticky="w", pady=(9, 0))
        tileset_row = ttk.Frame(left)
        tileset_row.grid(row=6, column=0, columnspan=2, sticky="ew")
        self.tileset_box = ttk.Combobox(tileset_row, state="readonly")
        self.tileset_box.pack(side="left", fill="x", expand=True)
        self.tileset_box.bind("<<ComboboxSelected>>", self._tileset_selected)
        ttk.Button(tileset_row, text="선택 씬 BC 적용", command=self.use_auto_tileset).pack(side="left", padx=(6, 0))

        self.palette_label = ttk.Label(left, text="맵 메타타일 팔레트 (P_000 변환 결과)")
        self.palette_label.grid(row=7, column=0, sticky="w", pady=(9, 0))
        pal_holder = ttk.Frame(left)
        pal_holder.grid(row=8, column=0, columnspan=2, sticky="nsew")
        self.palette_canvas = tk.Canvas(pal_holder, background="#181818", highlightthickness=0)
        pal_y = ttk.Scrollbar(pal_holder, orient="vertical", command=self.palette_canvas.yview)
        pal_x = ttk.Scrollbar(pal_holder, orient="horizontal", command=self.palette_canvas.xview)
        self.palette_canvas.configure(yscrollcommand=pal_y.set, xscrollcommand=pal_x.set)
        self.palette_canvas.grid(row=0, column=0, sticky="nsew")
        pal_y.grid(row=0, column=1, sticky="ns")
        pal_x.grid(row=1, column=0, sticky="ew")
        pal_holder.rowconfigure(0, weight=1)
        pal_holder.columnconfigure(0, weight=1)
        self.palette_canvas.bind("<Button-1>", self._palette_click)
        left.rowconfigure(1, weight=2)
        left.rowconfigure(8, weight=3)
        left.columnconfigure(0, weight=1)

        center = ttk.Frame(pane)
        pane.add(center, weight=6)
        self.map_canvas = tk.Canvas(center, background="#101010", highlightthickness=0)
        can_y = ttk.Scrollbar(center, orient="vertical", command=self.map_canvas.yview)
        can_x = ttk.Scrollbar(center, orient="horizontal", command=self.map_canvas.xview)
        self.map_canvas.configure(yscrollcommand=can_y.set, xscrollcommand=can_x.set)
        self.map_canvas.grid(row=0, column=0, sticky="nsew")
        can_y.grid(row=0, column=1, sticky="ns")
        can_x.grid(row=1, column=0, sticky="ew")
        center.rowconfigure(0, weight=1)
        center.columnconfigure(0, weight=1)
        self.map_canvas.bind("<Button-1>", self._press)
        self.map_canvas.bind("<B1-Motion>", self._drag)
        self.map_canvas.bind("<ButtonRelease-1>", self._release)
        self.map_canvas.bind("<Button-3>", self._pick)
        self.map_canvas.bind("<MouseWheel>", lambda e: self._wheel(e, False))
        self.map_canvas.bind("<Shift-MouseWheel>", lambda e: self._wheel(e, True))

        right = ttk.Frame(pane, padding=(7, 0, 0, 0))
        pane.add(right, weight=2)
        ttk.Label(right, text="맵/팔레트 정보", font=("TkDefaultFont", 10, "bold")).pack(anchor="w")
        info_holder = ttk.Frame(right)
        info_holder.pack(fill="both", expand=True)
        self.info = tk.Text(info_holder, wrap="none", state="disabled", width=38)
        info_y = ttk.Scrollbar(info_holder, orient="vertical", command=self.info.yview)
        info_x = ttk.Scrollbar(info_holder, orient="horizontal", command=self.info.xview)
        self.info.configure(yscrollcommand=info_y.set, xscrollcommand=info_x.set)
        self.info.grid(row=0, column=0, sticky="nsew")
        info_y.grid(row=0, column=1, sticky="ns")
        info_x.grid(row=1, column=0, sticky="ew")
        info_holder.rowconfigure(0, weight=1)
        info_holder.columnconfigure(0, weight=1)

        self.status = ttk.Label(self, text="준비", relief="sunken", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def choose_project(self) -> None:
        folder = filedialog.askdirectory(title="영웅전설 2 게임 폴더 선택")
        if folder:
            self.open_project(Path(folder))

    def open_project(self, root: Path) -> None:
        try:
            self.project = MapProject(root)
            records = self.project.all_maps()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.records = {record.key: record for record in records}
        self.root_label.config(text=str(root))
        self.tileset_box["values"] = self.project.tile_names
        self.map_tree.delete(*self.map_tree.get_children())
        large_root = self.map_tree.insert("", "end", text="필드 맵 M_000 (EXE 2×2 청크 조립)", open=True)
        standard_root = self.map_tree.insert("", "end", text="표준 맵 M_001~003", open=True)
        special_root = self.map_tree.insert("", "end", text="지하동굴 특수 데이터 (UDG)", open=True)
        for record in records:
            if record.map_kind == "large":
                parent = large_root
            elif record.map_kind == "special":
                parent = special_root
            else:
                parent = standard_root
            kind = record.description
            contexts = self.project.transition_contexts(record.key)
            source_dlls = sorted({item.source_scene for item in contexts})
            bc_values = sorted({item.bc_no for item in contexts})
            scenes = ", ".join(source_dlls)
            bc_text = ", ".join(f"{value:03d}" for value in bc_values)
            if record.map_kind == "large":
                label = f"Field MP{record.field_mp:02d} MASK{record.field_mask:02d}"
            elif record.special_kind == "udg_template":
                label = f"UDG 방 모듈 {record.special_index:02d}"
            elif record.special_kind == "udg_layout":
                label = f"UDG 미로 구조 {record.special_index + 1}/8"
            else:
                label = f"Map {record.map_id:03d}"
            self.map_tree.insert(parent, "end", iid=record.key, text=label,
                                 values=(kind, f"{record.archive_name} #{record.record_index:02d}", bc_text, scenes))
        field_count = sum(record.map_kind == "large" for record in records)
        standard_count = sum(record.map_kind == "standard" for record in records)
        special_count = sum(record.map_kind == "special" for record in records)
        self.status.config(text=(f"로드 완료: 실제 필드 창 {field_count} / 표준 맵 {standard_count} / "
                                 f"UDG 특수 보기 {special_count} / "
                                 f"타일셋 {len(self.project.tile_names)} / "
                                 f"씬 전환 {len(self.project.transitions)} / "
                                 f"자동 연결 맵 {len(self.project.auto_map_tilesets)}"))
        first = next((r for r in records if r.editable), None)
        if first:
            self.map_tree.selection_set(first.key)
            self.map_tree.see(first.key)
            self.load_record(first)

    def _confirm_discard(self) -> bool:
        return not self.modified or messagebox.askyesno(APP_NAME, "저장하지 않은 변경을 버릴까요?")

    def _map_selected(self, _event=None) -> None:
        selected = self.map_tree.selection()
        if not selected or selected[0] not in self.records:
            return
        if not self._confirm_discard():
            if self.current:
                self.map_tree.selection_set(self.current.key)
            return
        self.load_record(self.records[selected[0]])

    def load_record(self, record: MapRecord) -> None:
        self.current = record
        self.tiles = bytearray(record.tiles or b"")
        self.modified = False
        self.undo_stack.clear()
        self.redo_stack.clear()
        if self.project:
            contexts = self.project.transition_contexts(record.key)
            self.context_by_label = {self.project.transition_context_label(item): item for item in contexts}
            labels = list(self.context_by_label)
            self.context_box["values"] = labels
            remembered = self.project.remembered_context(record.key)
            self.current_context = remembered
            if remembered is not None:
                label = self.project.transition_context_label(remembered)
                self.context_box.set(label)
            elif labels:
                self.context_box.set(labels[0])
                self.current_context = self.context_by_label[labels[0]]
            else:
                self.current_context = None
                self.context_box.set(
                    "지하동굴 UDG 특수 데이터" if record.map_kind == "special"
                    else "씬 전환 연결 없음"
                )
            name = self.project.remembered_tileset(record.key)
            self.tileset_box.set(name)
            try:
                self.tileset = self.project.tileset(name)
            except Exception:
                self.tileset = None
            if record.map_kind == "special":
                if self.current_context is not None:
                    self.special_ptr_var.set(self.current_context.ptr_no)
                    self.special_ptr_spin.configure(state="disabled")
                else:
                    self.special_ptr_var.set(44)
                    self.special_ptr_spin.configure(state="normal")
            else:
                self.special_ptr_spin.configure(state="disabled")
        self.selected_code = 0xFF if record.special_kind == "udg_layout" else 0
        if record.special_kind == "udg_layout":
            self.palette_label.config(text="UDG 방 모듈 팔레트 (특수 마커 위치는 안전 잠금)")
            self.udg_variant_box.configure(state="readonly")
            self.udg_variant_var.set("일반")
        else:
            self.palette_label.config(text="맵 메타타일 팔레트 (P_000 변환 결과)")
            self.udg_variant_box.configure(state="disabled")
        self._palette_context_key = None
        self.redraw()

    def _context_selected(self, _event=None) -> None:
        if not self.project or not self.current:
            return
        item = self.context_by_label.get(self.context_box.get())
        if item is None:
            return
        try:
            self.current_context = item
            self.project.remember_context(self.current.key, item)
            self.project.clear_tileset_override(self.current.key)
            name = f"C_{item.bc_no:03d}.BZH"
            if name not in self.project.tile_names:
                self.tileset = None
                self.tileset_box.set(name + " (파일 없음)")
                self.status.config(text=f"선택 씬이 참조하는 타일셋 파일이 없습니다: {name}")
            else:
                self.tileset_box.set(name)
                self.tileset = self.project.tileset(name)
                if self.current.map_kind == "special":
                    self.special_ptr_var.set(item.ptr_no)
                    self.special_ptr_spin.configure(state="disabled")
                self.status.config(text=f"씬 컨텍스트 적용: {item.source_scene} → {item.destination_scene} / {name}")
            self._preview_tile_cache.clear()
            self._palette_context_key = None
            self.redraw()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def use_auto_tileset(self) -> None:
        if not self.project or not self.current:
            return
        if self.current_context is not None:
            self._context_selected()
            return
        try:
            self.project.clear_tileset_override(self.current.key)
            name = self.project.remembered_tileset(self.current.key)
            self.tileset_box.set(name)
            self.tileset = self.project.tileset(name)
            self._palette_context_key = None
            self.redraw()
            self.status.config(text=f"연결된 BC 사용: {self.current.key} → {name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def _tileset_selected(self, _event=None) -> None:
        if not self.project or not self.current:
            return
        try:
            name = self.tileset_box.get()
            self.tileset = self.project.tileset(name)
            self.project.remember_tileset(self.current.key, name)
            self._preview_tile_cache.clear()
            self._palette_context_key = None
            self.redraw()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def _special_ptr_changed(self, _event=None) -> None:
        try:
            value = max(0, min(44, int(self.special_ptr_var.get())))
        except (TypeError, ValueError, tk.TclError):
            value = 0
        self.special_ptr_var.set(value)
        if self.current and self.current.map_kind == "special":
            if self.current_context is not None:
                # Actual G-scene context owns PTR_NO; keep the display and the
                # selected C tileset as one inseparable retail render profile.
                self.special_ptr_var.set(self.current_context.ptr_no)
                return
            self._palette_context_key = None
            self.redraw()

    def _udg_variant_changed(self, _event=None) -> None:
        if not self.current or self.current.special_kind != "udg_layout":
            return
        if self.selected_code == 0xFF:
            self.udg_variant_var.set("일반")
            return
        room_id = self.selected_code & 0x1F
        variant = UDG_VARIANT_LABELS.get(self.udg_variant_var.get(), 0)
        if variant and room_id not in UDG_SPECIAL_TEMPLATE_IDS:
            self.udg_variant_var.set("일반")
            variant = 0
            self.status.config(text="UDG 특수 속성은 방 모듈 09~12에서만 사용할 수 있습니다.")
        self.selected_code = room_id | variant
        self._draw_palette_selection()
        self._update_info()

    @staticmethod
    def _write_ppm(path: Path, width: int, height: int, rgb: bytes) -> None:
        path.write_bytes(f"P6\n{width} {height}\n255\n".encode("ascii") + rgb)

    def _photo_from_rgb(self, width: int, height: int, rgb: bytes, name: str) -> tk.PhotoImage:
        payload = f"P6\n{width} {height}\n255\n".encode("ascii") + rgb
        try:
            return tk.PhotoImage(data=payload, format="PPM")
        except tk.TclError:
            path = Path(self._temp.name) / name
            path.write_bytes(payload)
            return tk.PhotoImage(file=str(path))

    def _effective_ptr_mask(self) -> Optional[tuple[int, int]]:
        if not self.current:
            return None
        if self.current.map_kind == "special":
            if self.current_context is not None:
                return self.current_context.ptr_no, 0
            return int(self.special_ptr_var.get()), 0
        if self.current_context is None:
            return None
        return (
            self.current_context.ptr_no,
            0 if self.current.map_kind == "large" else self.current_context.map_mask,
        )

    def _get_executor(self) -> Optional[ProcessPoolExecutor]:
        if self._parallel_workers <= 1:
            return None
        if self._executor is None:
            self._executor = ProcessPoolExecutor(max_workers=self._parallel_workers)
        return self._executor

    def _direct_atlas(self) -> tuple[bytes, ...]:
        if not self.tileset:
            return tuple()
        key = self.tileset.path.name
        cached = self._direct_atlas_cache.get(key)
        if cached is None:
            cached = tuple(self.tileset.rgb_for_code(code) for code in range(256))
            self._direct_atlas_cache[key] = cached
        return cached

    def _metatile_atlas(self, ptr_no: int, map_mask: int) -> tuple[bytes, ...]:
        if not self.tileset or not self.project:
            return tuple()
        key = (self.tileset.path.name, ptr_no, map_mask)
        cached = self._atlas_cache.get(key)
        if cached is not None:
            return cached

        pointer_data = self.project.pointer_table.data
        rgb_tiles = tuple(self.tileset.rgb_tiles)
        workers = self._parallel_workers
        chunks = [list(range(start, min(256, start + 64))) for start in range(0, 256, 64)]
        atlas: list[Optional[bytes]] = [None] * 256
        executor = self._get_executor()
        try:
            if executor is not None:
                futures = [
                    executor.submit(
                        _render_atlas_chunk,
                        (chunk, pointer_data, ptr_no, map_mask, rgb_tiles),
                    )
                    for chunk in chunks[:workers]
                ]
                # If fewer than four workers are configured, distribute any
                # remaining chunks through the same persistent pool.
                for chunk in chunks[workers:]:
                    futures.append(executor.submit(
                        _render_atlas_chunk,
                        (chunk, pointer_data, ptr_no, map_mask, rgb_tiles),
                    ))
                results = [future.result() for future in futures]
            else:
                results = [
                    _render_atlas_chunk((chunk, pointer_data, ptr_no, map_mask, rgb_tiles))
                    for chunk in chunks
                ]
        except Exception:
            # Spawn restrictions or security software can block child
            # processes.  The optimized row-copy renderer is still fast in
            # one process, so fall back without making the editor unusable.
            if self._executor is not None:
                self._executor.shutdown(wait=False, cancel_futures=True)
                self._executor = None
            results = [
                _render_atlas_chunk((chunk, pointer_data, ptr_no, map_mask, rgb_tiles))
                for chunk in chunks
            ]
        for result in results:
            for code, block in result:
                atlas[code] = block
        if any(block is None for block in atlas):
            raise RuntimeError("Metatile atlas generation was incomplete")
        value = tuple(block for block in atlas if block is not None)
        self._atlas_cache[key] = value
        return value

    def _rgb_for_udg_layout(self) -> tuple[int, int, bytes]:
        """Render a 16x16 UDG descriptor page as room-module thumbnails."""
        if not self.project or not self.tileset or not self.current:
            return 0, 0, b""
        ptr_no, map_mask = self._effective_ptr_mask() or (0, 0)
        atlas = self._metatile_atlas(ptr_no, map_mask)
        swatches = tuple(_average_rgb(block) for block in atlas)
        unit = 4
        cell = UDG_TEMPLATE_W * unit
        width = UDG_LAYOUT_W * cell
        height = UDG_LAYOUT_H * UDG_TEMPLATE_H * unit
        out = bytearray(width * height * 3)
        templates = tuple(
            self.project.underground.template(index)
            for index in range(18)
        )
        for layout_y in range(UDG_LAYOUT_H):
            for template_y in range(UDG_TEMPLATE_H):
                row = bytearray(width * 3)
                for layout_x in range(UDG_LAYOUT_W):
                    descriptor = self.tiles[layout_y * UDG_LAYOUT_W + layout_x]
                    template_id, _variant = self.project.underground.descriptor_parts(descriptor)
                    for template_x in range(UDG_TEMPLATE_W):
                        if template_id is None:
                            color = (0, 0, 0)
                        else:
                            code = templates[template_id][template_y * UDG_TEMPLATE_W + template_x]
                            color = swatches[code]
                        pixel = bytes(color) * unit
                        dst = (layout_x * cell + template_x * unit) * 3
                        row[dst:dst + unit * 3] = pixel
                target_y = (layout_y * UDG_TEMPLATE_H + template_y) * unit
                for repeat in range(unit):
                    dst = (target_y + repeat) * width * 3
                    out[dst:dst + width * 3] = row
        return width, height, bytes(out)

    def _udg_full_map_rows(self):
        """Yield a full 5120x5120 UDG floor one RGB scanline at a time."""
        if not self.project or not self.tileset or not self.current:
            return
        ptr_no, map_mask = self._effective_ptr_mask() or (0, 0)
        atlas = self._metatile_atlas(ptr_no, map_mask)
        templates = tuple(
            self.project.underground.template(index)
            for index in range(UDG_TEMPLATE_COUNT)
        )
        metatile_row_bytes = 32 * 3
        full_width = UDG_LAYOUT_W * UDG_TEMPLATE_W * 32
        full_row_bytes = full_width * 3
        black = bytes(metatile_row_bytes)
        for layout_y in range(UDG_LAYOUT_H):
            for template_y in range(UDG_TEMPLATE_H):
                for pixel_y in range(32):
                    row = bytearray(full_row_bytes)
                    for layout_x in range(UDG_LAYOUT_W):
                        descriptor = self.tiles[layout_y * UDG_LAYOUT_W + layout_x]
                        template_id, _variant = self.project.underground.descriptor_parts(descriptor)
                        room_base = layout_x * UDG_TEMPLATE_W
                        for template_x in range(UDG_TEMPLATE_W):
                            if template_id is None:
                                source = black
                            else:
                                code = templates[template_id][
                                    template_y * UDG_TEMPLATE_W + template_x
                                ]
                                block = atlas[code]
                                source = block[
                                    pixel_y * metatile_row_bytes:
                                    (pixel_y + 1) * metatile_row_bytes
                                ]
                            target = (room_base + template_x) * metatile_row_bytes
                            row[target:target + metatile_row_bytes] = source
                    yield bytes(row)

    def _rgb_for_udg_room_palette(self) -> tuple[int, int, bytes]:
        """Render the 18 reusable 10x10 room templates plus an empty cell."""
        if not self.project or not self.tileset:
            return 1, 1, b"\0\0\0"
        ptr_no, map_mask = self._effective_ptr_mask() or (0, 0)
        atlas = self._metatile_atlas(ptr_no, map_mask)
        swatches = tuple(_average_rgb(block) for block in atlas)
        rows = (UDG_TEMPLATE_COUNT + 1 + UDG_PALETTE_COLS - 1) // UDG_PALETTE_COLS
        width = UDG_PALETTE_COLS * UDG_PALETTE_CELL
        height = rows * UDG_PALETTE_CELL
        background = bytes((24, 24, 24))
        out = bytearray(background * (width * height))
        unit = 8
        preview = UDG_TEMPLATE_W * unit
        inset_x = (UDG_PALETTE_CELL - preview) // 2
        inset_y = 7
        for template_id in range(UDG_TEMPLATE_COUNT):
            col, row = template_id % UDG_PALETTE_COLS, template_id // UDG_PALETTE_COLS
            template = self.project.underground.template(template_id)
            origin_x = col * UDG_PALETTE_CELL + inset_x
            origin_y = row * UDG_PALETTE_CELL + inset_y
            for ty in range(UDG_TEMPLATE_H):
                for tx in range(UDG_TEMPLATE_W):
                    color = bytes(swatches[template[ty * UDG_TEMPLATE_W + tx]])
                    x0 = origin_x + tx * unit
                    y0 = origin_y + ty * unit
                    row_data = color * unit
                    for py in range(unit):
                        dst = ((y0 + py) * width + x0) * 3
                        out[dst:dst + unit * 3] = row_data
        return width, height, bytes(out)

    def _rgb_for_current(self) -> tuple[int, int, bytes, int]:
        if not self.tileset or not self.current or not self.tiles:
            return 0, 0, b"", 1
        if self.current.special_kind == "udg_layout":
            width, height, rgb = self._rgb_for_udg_layout()
            return width, height, rgb, UDG_TEMPLATE_W * 4

        ptr_mask = self._effective_ptr_mask()
        if (
            self.dynamic_changes_var.get()
            and self.current.map_kind in {"standard", "large"}
            and ptr_mask is not None
            and self.project is not None
        ):
            ptr_no, map_mask = ptr_mask
            graphic = expand_metatile_map_xmajor(
                bytes(self.tiles), self.project.pointer_table, ptr_no, map_mask
            )
            active_flags = {
                change.flag_index
                for script, _base in self.current.change_scripts
                for change in parse_map_change_script(script)
            }
            apply_map_changes_xmajor(
                graphic, list(self.current.change_scripts), ptr_no, active_flags
            )
            row_major = bytes(
                graphic[x * 64 + y]
                for y in range(64)
                for x in range(64)
            )
            rgb = _compose_rgb_grid(row_major, 64, 64, self._direct_atlas(), 16)
            return 1024, 1024, rgb, 32

        if ptr_mask is None:
            blocks = self._direct_atlas()
            cell = 16
        else:
            blocks = self._metatile_atlas(*ptr_mask)
            cell = 32
        rgb = _compose_rgb_grid(
            bytes(self.tiles), self.current.width, self.current.height, blocks, cell
        )
        return self.current.width * cell, self.current.height * cell, rgb, cell

    def _rgb_for_palette(self) -> tuple[int, int, bytes]:
        if not self.tileset:
            return 1, 1, b"\0\0\0"
        ptr_mask = self._effective_ptr_mask()
        if ptr_mask is None:
            blocks = self._direct_atlas()
            # Keep the selector cells at 32x32.  Direct 16x16 C tiles are
            # doubled only for maps without a confirmed P_000 context.
            enlarged = []
            for block in blocks:
                out = bytearray(32 * 32 * 3)
                for y in range(16):
                    source = block[y * 48:(y + 1) * 48]
                    expanded = b"".join(source[x:x + 3] * 2 for x in range(0, 48, 3))
                    out[(y * 2) * 96:(y * 2 + 1) * 96] = expanded
                    out[(y * 2 + 1) * 96:(y * 2 + 2) * 96] = expanded
                enlarged.append(bytes(out))
            blocks = tuple(enlarged)
        else:
            blocks = self._metatile_atlas(*ptr_mask)
        codes = bytes(range(256))
        return 512, 512, _compose_rgb_grid(codes, 16, 16, blocks, 32)

    def _draw_palette_selection(self) -> None:
        self.palette_canvas.delete("selection")
        if self.current and self.current.special_kind == "udg_layout":
            slot = (
                UDG_EMPTY_PALETTE_INDEX
                if self.selected_code == 0xFF
                else self.selected_code & 0x1F
            )
            sx = (slot % UDG_PALETTE_COLS) * UDG_PALETTE_CELL
            sy = (slot // UDG_PALETTE_COLS) * UDG_PALETTE_CELL
            size = UDG_PALETTE_CELL
        else:
            sx = (self.selected_code % 16) * 32
            sy = (self.selected_code // 16) * 32
            size = 32
        self.palette_canvas.create_rectangle(
            sx, sy, sx + size, sy + size,
            outline="yellow", width=3, tags=("selection",)
        )

    def _request_redraw(self, palette: bool = False) -> None:
        self._pending_palette_redraw = getattr(self, "_pending_palette_redraw", False) or palette
        if self._redraw_after_id is not None:
            return
        self._redraw_after_id = self.after(16, self._run_scheduled_redraw)

    def _run_scheduled_redraw(self) -> None:
        self._redraw_after_id = None
        palette = getattr(self, "_pending_palette_redraw", False)
        self._pending_palette_redraw = False
        self.redraw(palette=palette)

    def redraw(self, palette: bool = True) -> None:
        if self._redraw_after_id is not None:
            self.after_cancel(self._redraw_after_id)
            self._redraw_after_id = None
        started = time.perf_counter()
        self.map_canvas.delete("all")
        if self.current and self.tileset and self.tiles:
            zoom = int(self.zoom.get())
            if self.view_mode.get() == "graphics":
                base_w, base_h, map_rgb, cell = self._rgb_for_current()
                self._map_base_image = self._photo_from_rgb(
                    base_w, base_h, map_rgb, "map.ppm"
                )
                self._map_image = (
                    self._map_base_image.zoom(zoom, zoom)
                    if zoom > 1 else self._map_base_image
                )
                width, height = base_w * zoom, base_h * zoom
                self.map_canvas.create_image(
                    0, 0, image=self._map_image, anchor="nw"
                )
            else:
                cell = 40 if self.current.special_kind == "udg_layout" else (
                    32 if self._effective_ptr_mask() is not None else 16
                )
                tile_size = cell * zoom
                width = self.current.width * tile_size
                height = self.current.height * tile_size
                for y in range(self.current.height):
                    for x in range(self.current.width):
                        code = self.tiles[y * self.current.width + x]
                        x0, y0 = x * tile_size, y * tile_size
                        self.map_canvas.create_rectangle(
                            x0, y0, x0 + tile_size, y0 + tile_size,
                            fill="#222", outline=""
                        )
                        self.map_canvas.create_text(
                            x0 + tile_size // 2, y0 + tile_size // 2,
                            text=f"{code:02X}", fill="white"
                        )

            if self.current.special_kind == "udg_layout" and self.view_mode.get() == "graphics":
                cell_px = 40 * zoom
                for y in range(UDG_LAYOUT_H):
                    for x in range(UDG_LAYOUT_W):
                        descriptor = self.tiles[y * UDG_LAYOUT_W + x]
                        if descriptor == 0xFF:
                            continue
                        template_id = descriptor & 0x1F
                        variant = descriptor & 0xC0
                        label = f"{template_id:02d}"
                        if variant:
                            label += f"/{variant:02X}"
                        self.map_canvas.create_text(
                            x * cell_px + 2, y * cell_px + 2,
                            text=label, fill="white", anchor="nw",
                            font=("TkFixedFont", max(7, 7 * zoom)),
                        )
                        if variant:
                            marker_color = {
                                UDG_CHEST_VARIANT: "#ffd966",
                                UDG_TRANSITION_A_VARIANT: "#66d9ff",
                                UDG_TRANSITION_B_VARIANT: "#ff77dd",
                            }.get(variant, "#ff6666")
                            self.map_canvas.create_rectangle(
                                x * cell_px + 1, y * cell_px + 1,
                                (x + 1) * cell_px - 1, (y + 1) * cell_px - 1,
                                outline=marker_color, width=max(2, 2 * zoom),
                            )

                level = self.current.special_index or 0

                # Direct SINAL rooms and retail ROOM 13/17 transfer terminals
                # are immutable.  Progression gates get an additional red
                # marker because their no-bypass topology is also preserved.
                event_indices = {
                    entry.descriptor_index
                    for entry in self.project.underground.spot_entries[level]
                    if entry.table_kind == "event"
                }
                npc_indices = {
                    entry.descriptor_index
                    for entry in self.project.underground.spot_entries[level]
                    if entry.table_kind == "npc"
                }
                for index in sorted(event_indices | npc_indices):
                    x, y = index % UDG_LAYOUT_W, index // UDG_LAYOUT_W
                    color = "#ffb347" if index in event_indices else "#7fd4ff"
                    label = (
                        "EV+NPC" if index in event_indices and index in npc_indices
                        else "EVENT" if index in event_indices else "NPC"
                    )
                    inset = max(2, 2 * zoom)
                    self.map_canvas.create_rectangle(
                        x * cell_px + inset, y * cell_px + inset,
                        (x + 1) * cell_px - inset, (y + 1) * cell_px - inset,
                        outline=color, width=max(2, 2 * zoom),
                    )
                    self.map_canvas.create_text(
                        x * cell_px + inset + 2,
                        y * cell_px + inset + 2,
                        text=label, fill=color, anchor="nw",
                        font=("TkFixedFont", max(7, 7 * zoom)),
                    )
                terminal_indices = self.project.underground.retail_terminal_indices(level)
                for index in sorted(terminal_indices):
                    x, y = index % UDG_LAYOUT_W, index // UDG_LAYOUT_W
                    self.map_canvas.create_rectangle(
                        x * cell_px + 3, y * cell_px + 3,
                        (x + 1) * cell_px - 3, (y + 1) * cell_px - 3,
                        outline="#9dff66", width=max(2, 2 * zoom),
                    )
                    self.map_canvas.create_text(
                        x * cell_px + cell_px // 2,
                        y * cell_px + cell_px - max(5, 5 * zoom),
                        text="EXIT", fill="#d8ffc2", anchor="s",
                        font=("TkFixedFont", max(6, 6 * zoom), "bold"),
                    )

                scroll_indices = (
                    self.project.underground.scroll_sensitive_indices(level)
                    - event_indices - npc_indices - set(terminal_indices)
                )
                for index in sorted(scroll_indices):
                    x, y = index % UDG_LAYOUT_W, index // UDG_LAYOUT_W
                    self.map_canvas.create_rectangle(
                        x * cell_px + 4, y * cell_px + 4,
                        (x + 1) * cell_px - 4, (y + 1) * cell_px - 4,
                        outline="#c68cff", width=max(2, 2 * zoom),
                    )
                    self.map_canvas.create_text(
                        x * cell_px + cell_px // 2,
                        y * cell_px + cell_px - max(5, 5 * zoom),
                        text="SCROLL", fill="#e0c0ff", anchor="s",
                        font=("TkFixedFont", max(6, 6 * zoom), "bold"),
                    )

                for gate in self.project.underground.progression_gates[level]:
                    index = gate.descriptor_index
                    x, y = index % UDG_LAYOUT_W, index // UDG_LAYOUT_W
                    inset = max(3, 3 * zoom)
                    self.map_canvas.create_rectangle(
                        x * cell_px + inset, y * cell_px + inset,
                        (x + 1) * cell_px - inset, (y + 1) * cell_px - inset,
                        outline="#ff4040", width=max(3, 3 * zoom),
                    )
                    self.map_canvas.create_text(
                        x * cell_px + inset + 2,
                        y * cell_px + inset + 2,
                        text="STORY GATE", fill="#ff7070", anchor="nw",
                        font=("TkFixedFont", max(7, 7 * zoom)),
                    )

            if self.grid_var.get():
                step = cell * zoom
                for x in range(self.current.width + 1):
                    self.map_canvas.create_line(
                        x * step, 0, x * step, height, fill="#555"
                    )
                for y in range(self.current.height + 1):
                    self.map_canvas.create_line(
                        0, y * step, width, y * step, fill="#555"
                    )
                if self.current.map_kind == "large":
                    self.map_canvas.create_line(
                        16 * step, 0, 16 * step, height,
                        fill="yellow", width=2
                    )
                    self.map_canvas.create_line(
                        0, 16 * step, width, 16 * step,
                        fill="yellow", width=2
                    )
            self.map_canvas.configure(scrollregion=(0, 0, width, height))

            palette_kind = (
                "udg_rooms" if self.current.special_kind == "udg_layout" else "map_codes"
            )
            context_key = (
                palette_kind, self.tileset.path.name, self._effective_ptr_mask(),
                self.project.underground.layout_table if palette_kind == "udg_rooms" else None,
            )
            if palette or self._palette_context_key != context_key or self._palette_rgb_cache is None:
                if palette_kind == "udg_rooms":
                    pw, ph, prgb = self._rgb_for_udg_room_palette()
                else:
                    pw, ph, prgb = self._rgb_for_palette()
                self._palette_rgb_cache = (pw, ph, prgb)
                self._palette_context_key = context_key
                self._palette_image = self._photo_from_rgb(
                    pw, ph, prgb, "palette.ppm"
                )
                self.palette_canvas.delete("all")
                self.palette_canvas.create_image(
                    0, 0, image=self._palette_image, anchor="nw", tags=("palette",)
                )
                if palette_kind == "udg_rooms":
                    rows = (UDG_TEMPLATE_COUNT + 1 + UDG_PALETTE_COLS - 1) // UDG_PALETTE_COLS
                    for slot in range(UDG_TEMPLATE_COUNT + 1):
                        col, row = slot % UDG_PALETTE_COLS, slot // UDG_PALETTE_COLS
                        x0, y0 = col * UDG_PALETTE_CELL, row * UDG_PALETTE_CELL
                        label = "EMPTY" if slot == UDG_EMPTY_PALETTE_INDEX else f"ROOM {slot:02d}"
                        self.palette_canvas.create_rectangle(
                            x0, y0, x0 + UDG_PALETTE_CELL, y0 + UDG_PALETTE_CELL,
                            outline="#555", width=1, tags=("palette",),
                        )
                        self.palette_canvas.create_text(
                            x0 + 4, y0 + UDG_PALETTE_CELL - 4, text=label,
                            fill="white", anchor="sw", font=("TkFixedFont", 8),
                            tags=("palette",),
                        )
                        if slot in UDG_SPECIAL_TEMPLATE_IDS:
                            anchor = self.project.underground.special_anchor_cell(slot)
                            if anchor is not None:
                                self.palette_canvas.create_text(
                                    x0 + UDG_PALETTE_CELL - 4, y0 + 4, text="SPECIAL",
                                    fill="#ffd966", anchor="ne", font=("TkFixedFont", 7),
                                    tags=("palette",),
                                )
                    self.palette_canvas.configure(
                        scrollregion=(0, 0, UDG_PALETTE_COLS * UDG_PALETTE_CELL, rows * UDG_PALETTE_CELL)
                    )
                else:
                    self.palette_canvas.configure(scrollregion=(0, 0, pw, ph))
            self._draw_palette_selection()
        else:
            self.palette_canvas.delete("all")
        self._last_render_ms = (time.perf_counter() - started) * 1000.0
        self._update_info()

    def _update_info(self, point: Optional[tuple[int, int]] = None) -> None:
        lines = []
        if self.current:
            lines += [
                f"키: {self.current.key}",
                f"형식: {self.current.description}",
                f"파일: {self.current.archive_name}",
                f"레코드: {self.current.record_index}",
                f"크기: {self.current.width}×{self.current.height}",
                *(
                    [f"필드 원점: MP_NUM={self.current.field_mp}, MAP_MASK={self.current.field_mask}"]
                    if self.current.map_kind == "large" else []
                ),
                f"편집 가능: {'예' if self.current.editable else '아니오'}",
            ]
            if self.current.special_kind == "udg_template" and self.project:
                template_id = self.current.special_index or 0
                lines += [
                    "UDG_MAKE_MAP이 재사용하는 10×10 방 모듈입니다.",
                    f"8개 층 전체 사용 횟수: {self.project.underground.template_usage(template_id)}회",
                    "이 모듈을 바꾸면 해당 모듈을 사용하는 모든 층의 방이 함께 바뀝니다.",
                ]
                anchor = self.project.underground.special_anchor_cell(template_id)
                if anchor is not None:
                    lines.append(
                        f"특수 오버레이 기준 셀: ({anchor[0]}, {anchor[1]}) / "
                        "상자·전환 마커 대응 모듈"
                    )
                if self.project.underground.template_is_fully_protected(template_id):
                    spots = self.project.underground.template_spot_entries(template_id)
                    gates = self.project.underground.template_progression_gates(template_id)
                    scenes = sorted(
                        {entry.source_scene for entry in spots}
                        | {entry.source_scene for entry in gates}
                    )
                    lines += [
                        "NPC·방 단위 이벤트 또는 진행 게이트가 사용하는 모듈이므로 전체가 잠겨 있습니다.",
                        "연결 씬: " + (", ".join(scenes) if scenes else "확인되지 않음"),
                    ]
                else:
                    protected_cells = self.project.underground.template_protected_cells(template_id)
                    lines.append(
                        f"정확한 이벤트 트리거 셀 {len(protected_cells)}개만 잠겨 있습니다."
                    )
            elif self.current.special_kind == "udg_layout" and self.project:
                level = self.current.special_index or 0
                chest_count = sum(
                    1 for value in self.tiles if (value & 0xC0) == UDG_CHEST_VARIANT
                )
                spot_entries = self.project.underground.spot_entries[level]
                event_rooms = {
                    entry.descriptor_index for entry in spot_entries
                    if entry.table_kind == "event"
                }
                npc_rooms = {
                    entry.descriptor_index for entry in spot_entries
                    if entry.table_kind == "npc"
                }
                scene_origins = {
                    anchor.descriptor_index
                    for anchor in self.project.underground.scene_anchors[level]
                }
                scene_cells = self.project.underground.scene_protected_cells[level]
                lines += [
                    (f"M_003 해제 데이터 0x{self.project.underground.layout_offset:04X}의 "
                     f"16×16 지하동굴 배치표 {level + 1}/8입니다."),
                    ("SCENA NPC·이벤트 메타데이터: "
                     + ("검증 완료" if self.project.underground.scene_metadata_complete else "불완전 - 편집 잠금")),
                    "0xFF는 빈 영역, 하위 5비트는 방 모듈 0~17입니다.",
                    f"0x40 보물상자 {chest_count}개 / 0x80·0xC0 전환 마커.",
                    (f"보호 SINAL: 이벤트 방 {len(event_rooms)}개 / "
                     f"NPC·상호작용 방 {len(npc_rooms)}개."),
                    f"통행 차단·강제 진행 게이트: {len(self.project.underground.progression_gates[level])}개.",
                    f"고정 맵 전환 출입구 ROOM 13/17: {len(self.project.underground.retail_terminal_indices(level))}개.",
                    f"스크롤 민감 ROOM 0: {len(self.project.underground.scroll_sensitive_indices(level))}개.",
                    f"검증된 UDG_TRANS 창: {len(self.project.underground.scroll_windows[level])}개.",
                    "일반 NPC·대화·이벤트 방은 정확한 descriptor와 출입구를 유지합니다.",
                    "ROOM 13/17 출입구는 좌표와 descriptor를 바꾸지 않습니다.",
                    "일반 UG_MAP_NO 3×3 씬 창 전체는 잠그지 않습니다.",
                    "진행 게이트는 추가로 우회 방지 분기 구조까지 고정됩니다.",
                ]
            if self.project and self.current.map_kind != "special":
                scenes = self.project.scenes_for_map(self.current.key)
                lines.append("연결 목적지 씬: " + (", ".join(scenes) if scenes else "없음/미지정"))
                if self.current_context is not None:
                    lines.append("선택 사용 DLL: " + self.current_context.source_scene)
                    lines.append("선택 전환: " + self.project.transition_context_label(self.current_context))
                    lines.append(
                        f"미리보기 변환: PTR {self.current_context.ptr_no}, "
                        f"MASK {0 if self.current.map_kind == 'large' else self.current_context.map_mask:02X}"
                    )
                change_count = sum(
                    len(parse_map_change_script(script))
                    for script, _ in self.current.change_scripts
                )
                lines.append(
                    f"동적 MAP_CHANGE: {change_count}개 / "
                    f"{'모두 표시' if self.dynamic_changes_var.get() else '표시 안 함'}"
                )
                lines.append("타일셋 결정: " + self.project.tileset_source(self.current.key))
        if self.tileset:
            lines += [
                "",
                f"타일셋: {self.tileset.path.name}",
                "타일 구조: 128개 × 160바이트 (B/R/G/I 4면 + 마스크)",
                "팔레트: ED2MAIN.EXE ST_SIN_PAL 16색",
            ]
        ptr_mask = self._effective_ptr_mask()
        lines += [
            "",
            f"렌더링: {self._last_render_ms:.1f} ms / 아틀라스 캐시 {len(self._atlas_cache)}개 / "
            f"프로세스 {self._parallel_workers}개",
        ]
        if self.current and self.current.special_kind == "udg_layout":
            if self.selected_code == 0xFF:
                lines.append("선택: 빈 영역(0xFF)")
            else:
                room_id = self.selected_code & 0x1F
                variant = self.selected_code & 0xC0
                lines.append(
                    f"선택 방 모듈: {room_id:02d} / 속성: "
                    f"{UDG_VARIANT_NAMES.get(variant, f'0x{variant:02X}')}"
                )
        else:
            lines.append(f"선택 맵 코드: {self.selected_code} (0x{self.selected_code:02X})")
            if self.tileset and self.project and ptr_mask is not None:
                ptr_no, effective_mask = ptr_mask
                ids = self.project.pointer_table.graphic_codes(
                    ptr_no, effective_mask, self.selected_code
                )
                lines += [
                    f"P_000 PTR/MASK: {ptr_no}/{effective_mask:02X}",
                    "실제 C 타일(TL,TR,BL,BR): " + ", ".join(f"{value:02X}" for value in ids),
                ]
            elif self.current and self.current.map_kind != "special":
                lines.append("씬 연결이 없어 PTR/MASK 미확정: 직접 C 타일 임시 표시")
        if point and self.tiles and self.current:
            x, y = point
            index = y * self.current.width + x
            value = self.tiles[index]
            lines += [f"좌표: ({x}, {y})", f"현재 값: {value} (0x{value:02X})"]
            if self.current.special_kind == "udg_layout" and self.project:
                template_id, variant = self.project.underground.descriptor_parts(value)
                if template_id is None:
                    lines.append("UDG descriptor: 빈 영역(0xFF)")
                else:
                    lines += [
                        f"UDG 방 모듈: {template_id:02d}",
                        f"UDG 속성: {UDG_VARIANT_NAMES.get(variant, f'0x{variant:02X}')}",
                    ]
                    if variant:
                        lines.append("이 특수 마커의 좌표와 종류는 안전을 위해 잠겨 있습니다.")
                    if variant == UDG_CHEST_VARIANT:
                        level = self.current.special_index or 0
                        entries = self.project.underground.chest_entries_at(level, index)
                        if entries:
                            lines.append("연결된 보물상자 테이블:")
                            for entry in entries:
                                lines.append(
                                    f"  {entry.source_scene}: 상태 플래그 {entry.flag_index}, "
                                    f"내용 코드 0x{entry.item_code:02X}"
                                )
                        else:
                            lines.append("보물상자 외부 테이블을 찾지 못했습니다.")
                    level = self.current.special_index or 0
                    spot_entries = self.project.underground.spot_entries_at(level, index)
                    if spot_entries:
                        lines.append("이 방에는 NPC/이벤트가 있어 descriptor와 출입구가 잠겨 있습니다.")
                        for entry in spot_entries:
                            kind = "이벤트" if entry.table_kind == "event" else "NPC/상호작용"
                            local = (
                                f"로컬 C좌표 ({entry.local_x},{entry.local_y})"
                                if entry.template_cell is not None
                                else f"방 단위 값 ({entry.local_x:02X},{entry.local_y:02X})"
                            )
                            lines.append(
                                f"  {kind} {entry.source_scene} / 방 0x{entry.storage_index:02X} / "
                                f"{local} / 처리 0x{entry.handler_offset:04X}"
                            )
                    gate_entries = self.project.underground.progression_gate_entries_at(
                        level, index
                    )
                    if gate_entries:
                        lines.append("이 방은 통행 차단·강제 진행 게이트이므로 잠겨 있습니다.")
                        for gate in gate_entries:
                            lines.append(
                                f"  {gate.source_scene} / 처리 "
                                + ", ".join(f"0x{x:04X}" for x in gate.handler_offsets)
                                + " / " + gate.reason
                            )
                    scene_anchors = self.project.underground.scene_anchors_at(level, index)
                    if scene_anchors and not gate_entries:
                        lines.append("이 방은 일반 3×3 씬 창에 포함되지만, 창 전체는 잠금 대상이 아닙니다.")
            elif self.current.special_kind == "udg_template" and self.project:
                template_id = self.current.special_index or 0
                entries = self.project.underground.template_spot_entries_at(
                    template_id, index
                )
                if self.project.underground.template_is_fully_protected(template_id):
                    lines.append("NPC·방 단위 이벤트 또는 진행 게이트가 사용하는 모듈이므로 잠겨 있습니다.")
                elif entries:
                    lines.append("이벤트 트리거 위치이므로 이 셀은 잠겨 있습니다.")
                for entry in entries[:12]:
                    kind = "이벤트" if entry.table_kind == "event" else "NPC/상호작용"
                    lines.append(
                        f"  {kind} {entry.source_scene} / 방 0x{entry.storage_index:02X} / "
                        f"처리 0x{entry.handler_offset:04X}"
                    )
                if len(entries) > 12:
                    lines.append(f"  ... 외 {len(entries) - 12}건")
        self.info.configure(state="normal")
        self.info.delete("1.0", "end")
        self.info.insert("1.0", "\n".join(lines))
        self.info.configure(state="disabled")

    def _canvas_point(self, event) -> Optional[tuple[int, int]]:
        if not self.current or not self.tiles:
            return None
        if self.current.special_kind == "udg_layout":
            preview_cell = 40
        else:
            preview_cell = 32 if self._effective_ptr_mask() is not None else 16
        size = preview_cell * int(self.zoom.get())
        x = int(self.map_canvas.canvasx(event.x) // size)
        y = int(self.map_canvas.canvasy(event.y) // size)
        if 0 <= x < self.current.width and 0 <= y < self.current.height:
            self._update_info((x, y))
            return x, y
        return None

    def _prepare_base_map_edit(self) -> None:
        if self.dynamic_changes_var.get():
            self.dynamic_changes_var.set(False)
            self.status.config(text="편집을 위해 동적 MAP_CHANGE 미리보기를 껐습니다.")

    def _push_undo(self) -> None:
        state = bytes(self.tiles)
        if not self.undo_stack or self.undo_stack[-1] != state:
            self.undo_stack.append(state)
            if len(self.undo_stack) > 100:
                self.undo_stack.pop(0)
        self.redo_stack.clear()

    def _sync_udg_variant_from_selected(self) -> None:
        if not self.current or self.current.special_kind != "udg_layout":
            return
        variant = 0 if self.selected_code == 0xFF else self.selected_code & 0xC0
        self.udg_variant_var.set(UDG_VARIANT_NAMES.get(variant, "일반"))

    def _normalized_udg_paint(self, existing: int, selected: int) -> Optional[int]:
        """Return a safe descriptor without relocating script-linked markers."""
        old_variant = 0 if existing == 0xFF else existing & 0xC0
        if selected == 0xFF:
            if old_variant:
                self.status.config(text="특수 마커 셀은 빈 영역으로 지울 수 없습니다.")
                return None
            return 0xFF
        room_id = selected & 0x1F
        if not 0 <= room_id < UDG_TEMPLATE_COUNT:
            return None
        selected_variant = selected & 0xC0
        if old_variant:
            if room_id not in UDG_SPECIAL_TEMPLATE_IDS:
                self.status.config(text="특수 마커 셀은 방 모듈 09~12 중 하나로만 교체할 수 있습니다.")
                return None
            return room_id | old_variant
        if selected_variant:
            self.status.config(text="새 특수 마커를 만들거나 이동하는 기능은 안전을 위해 잠겨 있습니다.")
        return room_id

    def _set_tile(self, x: int, y: int, code: int) -> bool:
        if not self.current:
            return False
        index = y * self.current.width + x
        value = code
        if (
            self.current.special_kind in {"udg_layout", "udg_template"}
            and self.project
            and not self.project.underground.scene_metadata_complete
        ):
            self.status.config(
                text="SCENA NPC·이벤트 메타데이터 검증이 불완전하여 UDG 편집이 잠겨 있습니다."
            )
            return False
        if self.current.special_kind == "udg_layout":
            normalized = self._normalized_udg_paint(self.tiles[index], code)
            if normalized is None:
                return False
            value = normalized
            if self.project:
                level = self.current.special_index or 0
                protected = self.project.underground.protected_descriptors(level)
                if index in protected and value != protected[index]:
                    self.status.config(
                        text=("이 방은 NPC·이벤트·진행 게이트, ROOM 13/17 "
                              "출입구 또는 스크롤 민감 ROOM 0이라 변경할 수 없습니다.")
                    )
                    return False
        elif self.current.special_kind == "udg_template" and self.project:
            template_id = self.current.special_index or 0
            original = self.project.underground.template(template_id)
            if (
                self.project.underground.template_is_fully_protected(template_id)
                and code != original[index]
            ):
                self.status.config(
                    text="이 방 모듈은 NPC·방 단위 이벤트 또는 진행 게이트가 사용하므로 전체가 잠겨 있습니다."
                )
                return False
            if (
                index in self.project.underground.template_protected_cells(template_id)
                and code != original[index]
            ):
                self.status.config(
                    text="이 셀은 이벤트 트리거 보호 대상이므로 변경할 수 없습니다."
                )
                return False
        if self.tiles[index] != value:
            self.tiles[index] = value
            self.modified = True
            return True
        return False

    def _press(self, event) -> None:
        point = self._canvas_point(event)
        if point is None or not self.current:
            return
        x, y = point
        if not self.current.editable:
            return
        if self.tool.get() == "picker":
            self.selected_code = self.tiles[y * self.current.width + x]
            self._sync_udg_variant_from_selected()
            self._draw_palette_selection()
            self._update_info(point)
            return
        self._prepare_base_map_edit()
        self._push_undo()
        self.drag_start = point
        if self.tool.get() == "fill":
            self._flood(x, y)
        elif self.tool.get() == "pencil":
            self._set_tile(x, y, self.selected_code)
            self.last_painted = point
        self._request_redraw(palette=False)

    def _drag(self, event) -> None:
        if not self.current or not self.current.editable:
            return
        point = self._canvas_point(event)
        if point is None or self.tool.get() != "pencil" or point == self.last_painted:
            return
        self._set_tile(*point, self.selected_code)
        self.last_painted = point
        self._request_redraw(palette=False)

    def _release(self, event) -> None:
        if not self.current or not self.current.editable:
            self.drag_start = None
            self.last_painted = None
            return
        point = self._canvas_point(event)
        if point and self.drag_start and self.tool.get() == "rectangle":
            x0, y0 = self.drag_start
            x1, y1 = point
            for y in range(min(y0, y1), max(y0, y1) + 1):
                for x in range(min(x0, x1), max(x0, x1) + 1):
                    self._set_tile(x, y, self.selected_code)
            self._request_redraw(palette=False)
        self.drag_start = None
        self.last_painted = None

    def _pick(self, event) -> None:
        point = self._canvas_point(event)
        if point and self.current and self.current.editable:
            self.selected_code = self.tiles[point[1] * self.current.width + point[0]]
            self._sync_udg_variant_from_selected()
            self._draw_palette_selection()
            self._update_info(point)

    def _flood(self, x: int, y: int) -> None:
        if not self.current:
            return
        width, height = self.current.width, self.current.height
        target = self.tiles[y * width + x]
        if self.current.special_kind == "udg_layout":
            replacement = self._normalized_udg_paint(target, self.selected_code)
            if replacement is None or replacement == target:
                return
        elif target == self.selected_code:
            return
        queue = deque([(x, y)])
        visited = set()
        while queue:
            cx, cy = queue.popleft()
            if (cx, cy) in visited:
                continue
            visited.add((cx, cy))
            idx = cy * width + cx
            if self.tiles[idx] != target:
                continue
            self._set_tile(cx, cy, self.selected_code)
            if cx:
                queue.append((cx - 1, cy))
            if cx + 1 < width:
                queue.append((cx + 1, cy))
            if cy:
                queue.append((cx, cy - 1))
            if cy + 1 < height:
                queue.append((cx, cy + 1))

    def _palette_click(self, event) -> None:
        if self.current and self.current.special_kind == "udg_layout":
            x = int(self.palette_canvas.canvasx(event.x) // UDG_PALETTE_CELL)
            y = int(self.palette_canvas.canvasy(event.y) // UDG_PALETTE_CELL)
            slot = y * UDG_PALETTE_COLS + x
            if slot == UDG_EMPTY_PALETTE_INDEX:
                self.selected_code = 0xFF
                self.udg_variant_var.set("일반")
            elif 0 <= slot < UDG_TEMPLATE_COUNT:
                variant = UDG_VARIANT_LABELS.get(self.udg_variant_var.get(), 0)
                if variant and slot not in UDG_SPECIAL_TEMPLATE_IDS:
                    variant = 0
                    self.udg_variant_var.set("일반")
                    self.status.config(text="특수 속성은 방 모듈 09~12에서만 유효합니다.")
                self.selected_code = slot | variant
            else:
                return
        else:
            x = int(self.palette_canvas.canvasx(event.x) // 32)
            y = int(self.palette_canvas.canvasy(event.y) // 32)
            code = y * 16 + x
            if not 0 <= code < 256:
                return
            self.selected_code = code
        self._draw_palette_selection()
        self._update_info()

    def undo(self) -> None:
        if not self.undo_stack:
            return
        self.redo_stack.append(bytes(self.tiles))
        self.tiles[:] = self.undo_stack.pop()
        self.modified = True
        self._request_redraw(palette=False)

    def redo(self) -> None:
        if not self.redo_stack:
            return
        self.undo_stack.append(bytes(self.tiles))
        self.tiles[:] = self.redo_stack.pop()
        self.modified = True
        self._request_redraw(palette=False)

    def save_current(self) -> None:
        if not self.project or not self.current or not self.current.editable:
            return
        try:
            key = self.current.key
            self.project.save_map(self.current, bytes(self.tiles))
            self.records = {record.key: record for record in self.project.all_maps()}
            self.current = self.records[key]
            self.tiles = bytearray(self.current.tiles or b"")
            self.modified = False
            self.undo_stack.clear()
            self.redo_stack.clear()
            self.status.config(text=f"저장 완료: {self.current.archive_name} #{self.current.record_index:02d}")
            self.redraw()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def restore_current(self) -> None:
        if not self.project or not self.current:
            return
        if not self.current.editable:
            messagebox.showinfo(APP_NAME, "이 레코드는 읽기 전용입니다.")
            return
        if not messagebox.askyesno(APP_NAME, f"{self.current.archive_name}에서 Map Editor가 변경한 내용만 복원할까요?\n다른 패치는 유지됩니다."):
            return
        try:
            key = self.current.key
            self.project.restore(self.current)
            self.records = {record.key: record for record in self.project.all_maps()}
            self.load_record(self.records[key])
            self.status.config(text=f"복원 완료: {self.current.archive_name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def export_png(self) -> None:
        if not self.current or not self.tileset or not self.tiles:
            return
        default_name = f"ED2_{self.current.key.replace(':', '_')}.png"
        path = filedialog.asksaveasfilename(
            defaultextension=".png", initialfile=default_name,
            filetypes=(("PNG image", "*.png"),),
        )
        if not path:
            return
        try:
            output = Path(path)
            if self.current.special_kind == "udg_layout":
                width = UDG_LAYOUT_W * UDG_TEMPLATE_W * 32
                height = UDG_LAYOUT_H * UDG_TEMPLATE_H * 32
                write_png_rgb_rows(output, width, height, self._udg_full_map_rows())
            else:
                width, height, rgb, _cell = self._rgb_for_current()
                write_png_rgb_rows(output, width, height, rgb_rows(rgb, width, height))
            self.status.config(text=f"전체 맵 PNG 저장: {output} ({width}x{height})")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def simplify_all_udg(self) -> None:
        if not self.project:
            return
        if not self.project.underground.scene_metadata_complete:
            messagebox.showerror(
                APP_NAME,
                "SCENA NPC·이벤트 메타데이터를 완전히 검증하지 못해 "
                "지하동굴 자동 간소화를 실행할 수 없습니다.",
            )
            return
        if self.modified and not self._confirm_discard():
            return
        try:
            original_layouts = [
                self.project.underground.layout(level) for level in range(8)
            ]
            layouts = [
                _reviewed_or_generated_udg_layout(
                    level, layout,
                    self.project.underground.protected_descriptors(level),
                    self.project.underground.progression_gate_descriptors(level),
                    self.project.underground.scroll_domains(level),
                )
                for level, layout in enumerate(original_layouts)
            ]
            before_rooms = sum(udg_layout_statistics(layout)["rooms"] for layout in original_layouts)
            after_rooms = sum(udg_layout_statistics(layout)["rooms"] for layout in layouts)
            changed = [
                sum(first != second for first, second in zip(before, after))
                for before, after in zip(original_layouts, layouts)
            ]
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        changed_text = ", ".join(str(value) for value in changed)
        if not messagebox.askyesno(
            APP_NAME,
            "지하동굴 8개 층을 이벤트·스크롤 안전 기준으로 간소화할까요?\n\n"
            "- 일반 NPC·대화·이벤트 방의 descriptor와 출입구 보존\n"
            "- 일반 3×3 씬 창 전체는 고정하지 않음\n"
            "- 통행 차단·강제 진행 게이트의 분기 차단 구조 보존\n"
            "- 게이트를 우회하는 새 지름길 생성 금지\n"
            "- ROOM 13/17 맵 전환 출입구의 좌표·descriptor 보존\n"
            "- ROOM 0을 ROOM 3으로 치환하지 않고 내부 보행 구조 보존\n"
            "- 같은 통로 마스크라도 원본 방 모듈 ID를 우선 유지\n"
            "- 0x40/0x80/0xC0 특수 descriptor 보존\n"
            "- 기존 독립 구역 수와 주요 출입 지점 유지\n"
            "- ROOM 14로 전체를 덮지 않음\n"
            "- M_003.BZH 최초 백업(.bak) 자동 생성\n\n"
            f"전체 사용 방: {before_rooms} → {after_rooms}\n"
            f"층별 변경 셀: {changed_text}",
        ):
            return
        try:
            current_key = self.current.key if self.current else None
            self.project.save_udg_layouts(layouts)
            self.records = {record.key: record for record in self.project.all_maps()}
            if current_key and current_key in self.records:
                self.load_record(self.records[current_key])
            self.modified = False
            self.undo_stack.clear()
            self.redo_stack.clear()
            self.status.config(
                text=f"UDG 이벤트·스크롤 안전 간소화 완료: 사용 방 {before_rooms} → {after_rooms}"
            )
            messagebox.showinfo(
                APP_NAME,
                "지하동굴 8개 층을 이벤트·스크롤 안전 기준으로 간소화했습니다.\n"
                "일반 NPC·대화·이벤트 방은 그대로 유지하고, 일반 3×3 씬 창만 해제했습니다.\n"
                "진행 게이트 출입구와 우회 방지 분기 구조도 유지됩니다.",
            )
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def export_csv(self) -> None:
        if not self.current or not self.current.editable:
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"ED2_{self.current.key.replace(':', '_')}.csv", filetypes=(("CSV", "*.csv"),))
        if not path:
            return
        with Path(path).open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.writer(fp)
            for y in range(self.current.height):
                start = y * self.current.width
                writer.writerow(self.tiles[start:start + self.current.width])
        self.status.config(text=f"CSV 내보내기: {path}")

    def import_csv(self) -> None:
        if not self.current or not self.current.editable:
            return
        path = filedialog.askopenfilename(filetypes=(("CSV", "*.csv"),))
        if not path:
            return
        try:
            values = []
            with Path(path).open("r", newline="", encoding="utf-8-sig") as fp:
                for row in csv.reader(fp):
                    values.extend(int(item.strip(), 0) for item in row if item.strip())
            expected = self.current.width * self.current.height
            if len(values) != expected or any(not 0 <= value <= 255 for value in values):
                raise ValueError(
                    f"CSV must contain exactly {expected} values "
                    f"({self.current.width}x{self.current.height}) in range 0..255"
                )
            if self.current.special_kind == "udg_layout" and self.project:
                self.project.underground.validate_layout_edit(
                    self.current.special_index or 0, bytes(values)
                )
            elif self.current.special_kind == "udg_template" and self.project:
                self.project.underground.validate_template_edit(
                    self.current.special_index or 0, bytes(values)
                )
            self._push_undo()
            self.tiles[:] = bytes(values)
            self.modified = True
            self.redraw()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def validate_project(self) -> None:
        if not self.project:
            return
        result = self.project.validate()
        text = json.dumps(result, ensure_ascii=False, indent=2)
        messagebox.showinfo(APP_NAME, text)

    def _wheel(self, event, horizontal: bool) -> str:
        delta = -1 if event.delta > 0 else 1
        (self.map_canvas.xview_scroll if horizontal else self.map_canvas.yview_scroll)(delta * 3, "units")
        return "break"

    def _close(self) -> None:
        if self._confirm_discard():
            if self._redraw_after_id is not None:
                self.after_cancel(self._redraw_after_id)
                self._redraw_after_id = None
            if self._executor is not None:
                self._executor.shutdown(wait=False, cancel_futures=True)
                self._executor = None
            self._temp.cleanup()
            self.destroy()


def bundled_udg_preset_status(game_root: Path) -> dict[str, object]:
    project = MapProject(game_root)
    rows = []
    ok = True
    for level in range(8):
        current = project.underground.layout(level)
        preset = _bundled_udg_preset(level)
        if preset is None:
            rows.append({"level": level + 1, "status": "missing_preset"})
            ok = False
            continue
        retail = hashlib.sha256(current).hexdigest() == UDG_RETAIL_SHA256[level]
        applied = current == preset
        rows.append({
            "level": level + 1,
            "status": "applied" if applied else ("retail" if retail else "custom_or_unknown"),
            "rooms": udg_layout_statistics(current)["rooms"],
            "preset_rooms": udg_layout_statistics(preset)["rooms"],
        })
        ok = ok and applied
    return {"ok": ok, "floors": rows}


def apply_bundled_udg_preset(game_root: Path) -> dict[str, object]:
    project = MapProject(game_root)
    if not project.underground.scene_metadata_complete:
        raise ValueError("SCENA NPC/event metadata could not be verified completely")
    original_layouts = [project.underground.layout(level) for level in range(8)]
    layouts = []
    changed_cells = []
    for level, current in enumerate(original_layouts):
        preset = _bundled_udg_preset(level)
        if preset is None:
            raise FileNotFoundError(f"Bundled UDG floor {level + 1} preset is missing")
        digest = hashlib.sha256(current).hexdigest()
        if current != preset and digest != UDG_RETAIL_SHA256[level]:
            raise ValueError(
                f"UDG floor {level + 1} is neither the supported retail layout nor the bundled preset; "
                "refusing to overwrite a custom map"
            )
        target = _reviewed_or_generated_udg_layout(
            level, current,
            project.underground.protected_descriptors(level),
            project.underground.progression_gate_descriptors(level),
            project.underground.scroll_domains(level),
        )
        if target != preset:
            raise AssertionError(f"UDG floor {level + 1} did not resolve to the bundled preset")
        layouts.append(target)
        changed_cells.append(sum(a != b for a, b in zip(current, target)))
    if any(changed_cells):
        project.save_udg_layouts(layouts)
    check = MapProject(game_root)
    mismatches = [level + 1 for level in range(8) if check.underground.layout(level) != layouts[level]]
    validation = check.validate()
    if mismatches or not validation.get("ok", False):
        raise AssertionError(f"UDG preset verification failed: mismatches={mismatches}, validation={validation}")
    return {
        "changed_floors": sum(value > 0 for value in changed_cells),
        "changed_cells": changed_cells,
        "before_rooms": sum(udg_layout_statistics(layout)["rooms"] for layout in original_layouts),
        "after_rooms": sum(udg_layout_statistics(layout)["rooms"] for layout in layouts),
        "validation": validation,
    }


def main() -> int:
    multiprocessing.freeze_support()
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("game_root", nargs="?", type=Path)
    parser.add_argument("--validate", action="store_true")
    parser.add_argument("--apply-udg-preset", action="store_true", help="apply the bundled reviewed underground-cave preset")
    parser.add_argument("--check-udg-preset", action="store_true", help="check whether all eight bundled cave layouts are applied")
    args = parser.parse_args()
    if args.apply_udg_preset or args.check_udg_preset:
        if not args.game_root:
            parser.error("UDG preset action requires game_root")
        if args.apply_udg_preset and args.check_udg_preset:
            parser.error("choose only one UDG preset action")
        result = apply_bundled_udg_preset(args.game_root) if args.apply_udg_preset else bundled_udg_preset_status(args.game_root)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if (args.apply_udg_preset or result.get("ok", False)) else 1
    if args.validate:
        if not args.game_root:
            parser.error("--validate requires game_root")
        result = MapProject(args.game_root).validate()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 1
    Editor(args.game_root).mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
