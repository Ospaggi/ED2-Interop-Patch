#!/usr/bin/env python3
"""Shared ED2 map/scene formats.

Only Python standard library is used.  The code deliberately limits writes to
structures that can be parsed and round-tripped from the original Korean DOS
release.
"""
from __future__ import annotations

import json
import os
import shutil
import struct
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ed2_patch_journal import record_patch, selective_restore

MAP_W = 32
MAP_H = 32
MAP_CELLS = MAP_W * MAP_H
LARGE_CHUNK_W = 16
LARGE_CHUNK_H = 16
ARCHIVE_RECORDS = 40
ARCHIVE_HEADER = 80
GRAPHIC_TILE_COUNT = 128
GRAPHIC_TILE_STRIDE = 160
GRAPHIC_COLOR_BYTES = 128
GRAPHIC_MASK_BYTES = 32


JOURNAL_COMPONENT = "ed2_map_editor"

class FormatError(Exception):
    pass


def storage_to_screen_map(data: bytes, width: int, height: int) -> bytes:
    """Convert ED2's column-major map bytes to normal screen row-major order.

    ED2MAIN's ``SINGLE_UN_PACK`` consumes one complete source column before
    advancing to the next column.  The raw index is therefore ``x*height+y``.
    The editor deliberately exposes the conventional ``y*width+x`` layout so
    mouse coordinates, CSV files and the preview agree with the game screen.
    """
    if len(data) != width * height:
        raise ValueError(f"Expected {width * height} map bytes, got {len(data)}")
    out = bytearray(len(data))
    for y in range(height):
        for x in range(width):
            out[y * width + x] = data[x * height + y]
    return bytes(out)


def screen_to_storage_map(data: bytes, width: int, height: int) -> bytes:
    """Inverse of :func:`storage_to_screen_map`."""
    if len(data) != width * height:
        raise ValueError(f"Expected {width * height} map bytes, got {len(data)}")
    out = bytearray(len(data))
    for y in range(height):
        for x in range(width):
            out[x * height + y] = data[y * width + x]
    return bytes(out)


def u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def backup_once(path: Path) -> Path:
    backup = path.with_name(path.name + ".bak")
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        return backup
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


def atomic_write(path: Path, data: bytes, *, journal: bool = True) -> None:
    before = path.read_bytes() if path.exists() else b""
    backup_once(path)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
        if journal and before != data:
            try:
                record_patch(path, before, data, JOURNAL_COMPONENT)
            except Exception:
                atomic_write(path, before, journal=False)
                raise
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class _BzhInput:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def read8(self) -> int:
        if self.pos >= len(self.data):
            raise FormatError("Unexpected end of BZH stream")
        result = self.data[self.pos]
        self.pos += 1
        return result

    def read16(self) -> int:
        return self.read8() | (self.read8() << 8)


class _BzhWriter:
    def __init__(self):
        self.output = bytearray([0])
        self.control_pos = 0
        self.control_width = 8
        self.control_value = 0
        self.bit_index = 0

    def _flush(self) -> None:
        self.output[self.control_pos] = self.control_value & 0xFF
        if self.control_width == 16:
            self.output[self.control_pos + 1] = (self.control_value >> 8) & 0xFF

    def _new_word(self) -> None:
        self.control_pos = len(self.output)
        self.output.extend(b"\0\0")
        self.control_width = 16
        self.control_value = 0
        self.bit_index = 0

    def bit(self, value: int) -> None:
        if self.bit_index >= self.control_width:
            self._flush()
            self._new_word()
        if value:
            self.control_value |= 1 << self.bit_index
        self.bit_index += 1

    def byte(self, value: int) -> None:
        self.output.append(value & 0xFF)

    def finish(self) -> bytes:
        self._flush()
        return bytes(self.output)


def bzh_decompress(data: bytes) -> bytes:
    if len(data) < 4:
        raise FormatError("BZH file is too small")
    declared = data[0] | data[1] << 8 | data[2] << 16
    if declared != len(data) - 1:
        raise FormatError(f"BZH size mismatch: header={declared}, file={len(data)}")
    source = _BzhInput(data[3:])
    bitstream = source.read8()
    bits_left = 8
    output = bytearray()

    def bit() -> int:
        nonlocal bitstream, bits_left
        if bits_left == 0:
            bitstream = source.read16()
            bits_left = 16
        result = bitstream & 1
        bitstream >>= 1
        bits_left -= 1
        return result

    while source.pos < len(source.data):
        if bit() == 0:
            output.append(source.read8())
            continue
        extended = bit()
        high = 0
        if extended:
            for weight in (16, 8, 4, 2, 1):
                if bit():
                    high += weight
        distance = source.read8() + (high << 8)
        if extended and distance == 0:
            return bytes(output)
        if extended and distance == 1:
            long_count = bit()
            amount = 0
            for weight in (8, 4, 2, 1):
                if bit():
                    amount += weight
            if long_count:
                amount = (amount << 8) + source.read8()
            amount += 14
            output.extend([source.read8()] * amount)
            continue
        run = 2
        if bit() == 0:
            run += 1
            if bit() == 0:
                run += 1
                if bit() == 0:
                    run += 1
                    if bit() == 0:
                        if bit() == 0:
                            run = source.read8() + 14
                        else:
                            run += 1
                            for weight in (4, 2, 1):
                                if bit():
                                    run += weight
        if distance <= 0 or distance > len(output):
            raise FormatError(f"Invalid BZH distance {distance} at output {len(output)}")
        for _ in range(run):
            output.append(output[-distance])
    raise FormatError("BZH end marker missing")


def bzh_compress_literal(data: bytes) -> bytes:
    writer = _BzhWriter()
    for value in data:
        writer.bit(0)
        writer.byte(value)
    writer.bit(1)
    writer.bit(1)
    for _ in range(5):
        writer.bit(0)
    writer.byte(0)
    payload = writer.finish()
    declared = len(payload) + 2
    if declared > 0xFFFFFF:
        raise FormatError("BZH output exceeds 24-bit size field")
    return bytes((declared & 255, declared >> 8 & 255, declared >> 16 & 255)) + payload


def inner_rle_decode(data: bytes, max_output: int = 65535) -> tuple[bytes, int, bool]:
    out = bytearray()
    pos = 0
    while pos < len(data):
        control = data[pos]
        pos += 1
        if control == 0:
            return bytes(out), pos, True
        count = control & 0x7F
        if count == 0:
            return bytes(out), pos, False
        if control & 0x80:
            if pos >= len(data):
                return bytes(out), pos, False
            out.extend([data[pos]] * count)
            pos += 1
        else:
            if pos + count > len(data):
                return bytes(out), pos, False
            out.extend(data[pos:pos + count])
            pos += count
        if len(out) > max_output:
            return bytes(out), pos, False
    return bytes(out), pos, False


def inner_rle_encode(data: bytes) -> bytes:
    out = bytearray()
    literal = bytearray()

    def flush() -> None:
        nonlocal literal
        start = 0
        while start < len(literal):
            chunk = literal[start:start + 127]
            out.append(len(chunk))
            out.extend(chunk)
            start += len(chunk)
        literal = bytearray()

    pos = 0
    while pos < len(data):
        run = 1
        while pos + run < len(data) and data[pos + run] == data[pos] and run < 127:
            run += 1
        if run >= 3:
            flush()
            out.extend((0x80 | run, data[pos]))
            pos += run
        else:
            literal.append(data[pos])
            pos += 1
            if len(literal) == 127:
                flush()
    flush()
    out.append(0)
    return bytes(out)

@dataclass(frozen=True)
class MapChange:
    flag_index: int
    ptr_parity: int
    offset: int
    writes: tuple[tuple[int, int], ...]


def parse_map_change_script(data: bytes) -> list[MapChange]:
    """Parse MAP_CHANGE records following an inner-RLE map stream."""
    pos = 0
    result: list[MapChange] = []
    while pos < len(data):
        control = data[pos]
        pos += 1
        if control & 1:
            if pos != len(data):
                raise FormatError("Map-change script has bytes after terminator")
            return result
        count = ((control >> 1) & 3) + 1
        flag_hi = (control >> 3) & 3
        if pos + 3 + count > len(data):
            raise FormatError("Map-change record is truncated")
        flag_lo = data[pos]
        pos += 1
        packed = u16(data, pos)
        pos += 2
        low = packed & 0xFF
        high = packed >> 8
        offset = ((low & 0x0F) << 8) | high
        values = data[pos:pos + count]
        pos += count
        deltas = [0]
        if low & 0x40:
            deltas.append(1)
        if low & 0x20:
            deltas.append(65)
        if low & 0x10:
            deltas.append(64)
        if len(deltas) != count:
            raise FormatError("Map-change write count does not match direction bits")
        result.append(MapChange(
            flag_index=(flag_hi << 8) | flag_lo,
            ptr_parity=(low >> 7) & 1,
            offset=offset,
            writes=tuple(zip(deltas, values)),
        ))
    raise FormatError("Map-change script terminator is missing")


def apply_map_changes_xmajor(
    graphic_map: bytearray, scripts: list[tuple[bytes, int]], ptr_no: int, active_flags: set[int],
) -> None:
    """Apply ED2 MAP_CHANGE writes to a 64x64 x-major C-tile buffer."""
    if len(graphic_map) != 64 * 64:
        raise ValueError("Graphic map must be 64x64")
    for script, base in scripts:
        for change in parse_map_change_script(script):
            if change.flag_index not in active_flags or change.ptr_parity != (ptr_no & 1):
                continue
            for delta, value in change.writes:
                at = base + change.offset + delta
                if not 0 <= at < len(graphic_map):
                    raise FormatError(f"Map-change write outside map buffer: {at}")
                graphic_map[at] = value


def expand_metatile_map_xmajor(tiles: bytes, pointer_table: "PointerTable", ptr_no: int, map_mask: int) -> bytearray:
    """Expand a normal 32x32 screen-order map into ED2's 64x64 x-major C-tile buffer."""
    if len(tiles) != MAP_CELLS:
        raise ValueError("Map must contain 1024 tile codes")
    out = bytearray(64 * 64)
    for my in range(32):
        for mx in range(32):
            tl, tr, bl, br = pointer_table.graphic_codes(ptr_no, map_mask, tiles[my * 32 + mx])
            x = mx * 2
            y = my * 2
            out[x * 64 + y] = tl
            out[(x + 1) * 64 + y] = tr
            out[x * 64 + y + 1] = bl
            out[(x + 1) * 64 + y + 1] = br
    return out


@dataclass(frozen=True)
class NESegment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


def parse_ne_segments(data: bytes) -> list[NESegment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise FormatError("Not an MZ executable")
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise FormatError("Not a 16-bit NE module")
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    result = []
    for i in range(count):
        sector, length, flags, alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        result.append(NESegment(i + 1, sector << shift, 65536 if length == 0 else length, flags, alloc))
    return result


def parse_ne_export_ordinals(data: bytes) -> tuple[dict[int, tuple[int, int]], dict[int, str]]:
    ne = u32(data, 0x3C)
    entry = ne + u16(data, ne + 0x04)
    end = entry + u16(data, ne + 0x06)
    ordinal = 1
    entries: dict[int, tuple[int, int]] = {}
    pos = entry
    while pos < end:
        count, kind = data[pos], data[pos + 1]
        pos += 2
        if count == 0:
            break
        if kind == 0:
            ordinal += count
        elif kind == 0xFF:
            for _ in range(count):
                entries[ordinal] = (data[pos + 3], u16(data, pos + 4))
                ordinal += 1
                pos += 6
        else:
            for _ in range(count):
                entries[ordinal] = (kind, u16(data, pos + 1))
                ordinal += 1
                pos += 3

    def names_at(offset: int, size: Optional[int] = None) -> dict[int, str]:
        out: dict[int, str] = {}
        pos2 = offset
        limit = len(data) if size is None else min(len(data), offset + size)
        while pos2 < limit:
            length = data[pos2]
            pos2 += 1
            if length == 0:
                break
            name = data[pos2:pos2 + length].decode("latin1")
            pos2 += length
            ord_value = u16(data, pos2)
            pos2 += 2
            out[ord_value] = name
        return out

    names = names_at(ne + u16(data, ne + 0x26))
    names.update(names_at(u32(data, ne + 0x2C), u16(data, ne + 0x20)))
    return entries, names



@dataclass(frozen=True)
class NERelocation:
    segment: int
    source_type: int
    flags: int
    source_offset: int
    module: str
    ordinal: Optional[int]
    imported_name: Optional[str]


def _ne_import_tables(data: bytes) -> tuple[list[str], int]:
    ne = u32(data, 0x3C)
    imported = ne + u16(data, ne + 0x2A)
    module_refs = ne + u16(data, ne + 0x28)
    count = u16(data, ne + 0x1E)
    modules: list[str] = []
    for index in range(count):
        offset = u16(data, module_refs + index * 2)
        pos = imported + offset
        if pos >= len(data):
            raise FormatError("NE import module table is truncated")
        length = data[pos]
        modules.append(data[pos + 1:pos + 1 + length].decode("latin1"))
    return modules, imported


def parse_ne_relocations(data: bytes) -> list[NERelocation]:
    modules, imported_base = _ne_import_tables(data)

    def import_name(offset: int) -> str:
        pos = imported_base + offset
        if pos >= len(data):
            raise FormatError("NE imported-name table is truncated")
        length = data[pos]
        return data[pos + 1:pos + 1 + length].decode("latin1")

    result: list[NERelocation] = []
    for segment in parse_ne_segments(data):
        if not (segment.flags & 0x0100):
            continue
        pos = segment.file_offset + segment.length
        if pos + 2 > len(data):
            raise FormatError(f"Segment {segment.index}: relocation count is truncated")
        count = u16(data, pos)
        pos += 2
        for _ in range(count):
            if pos + 8 > len(data):
                raise FormatError(f"Segment {segment.index}: relocation table is truncated")
            source_type, flags, source, target1, target2 = struct.unpack_from("<BBHHH", data, pos)
            pos += 8
            target_kind = flags & 3
            module = modules[target1 - 1] if 0 < target1 <= len(modules) else f"module#{target1}"
            ordinal = target2 if target_kind == 1 else None
            name = import_name(target2) if target_kind == 2 else None
            result.append(NERelocation(segment.index, source_type, flags, source, module, ordinal, name))
    return result


SCENE_TYPE_LETTERS = "CDEFGHMTV"

def scene_name_from_sin(sin_no: int) -> str:
    type_index = (sin_no >> 12) & 0xF
    letter = SCENE_TYPE_LETTERS[type_index] if type_index < len(SCENE_TYPE_LETTERS) else "?"
    return f"{letter}_{sin_no & 0x0FFF:03X}.DLL"


@dataclass(frozen=True)
class TransitionRecord:
    source_scene: str
    call_segment: int
    call_source_offset: int
    record_segment: int
    record_offset: int
    mp_pny: int
    mp_pnx: int
    map_number: int
    map_mask: int
    ptr_no: int
    sin_no: int
    destination_scene: str
    bc_no: int
    bgm_no: int
    floor_chr_no: int
    town_no: int
    chr_nos: tuple[int, int, int, int, int, int, int, int]
    raw: bytes

    @property
    def map_kind(self) -> str:
        if self.destination_scene.startswith("F_"):
            return "large"
        if self.destination_scene.startswith("G_"):
            return "underground"
        return "standard"

    @property
    def map_key(self) -> str:
        if self.map_kind == "large":
            return f"large:{self.map_number:02d}:{self.map_mask:02d}"
        if self.map_kind == "underground":
            return f"special:udg-layout:{self.map_number}"
        return f"standard:{self.map_number:03d}"

    @property
    def record_file_description(self) -> str:
        return f"seg {self.record_segment}:0x{self.record_offset:04X}"


TRANSITION_FIELD_OFFSETS = {
    "mp_pny": (3, 1),
    "mp_pnx": (4, 1),
    "map_number": (5, 1),
    "map_mask": (6, 1),
    "sin_no": (12, 2),
    "bc_no": (15, 1),
    "bgm_no": (16, 1),
    "floor_chr_no": (17, 1),
    "town_no": (18, 1),
    "chr_no0": (26, 1),
    "chr_no1": (27, 1),
    "chr_no2": (28, 1),
    "chr_no3": (29, 1),
    "chr_no4": (30, 1),
    "chr_no5": (31, 1),
    "chr_no6": (32, 1),
    "chr_no7": (33, 1),
}


def extract_scene_transitions(
    path: Path, exe_ordinal_names: dict[int, str], data: Optional[bytes] = None,
) -> list[TransitionRecord]:
    data = path.read_bytes() if data is None else data
    segments = parse_ne_segments(data)
    relocations = parse_ne_relocations(data)
    seen: set[tuple[int, int]] = set()
    result: list[TransitionRecord] = []
    for relocation in relocations:
        if relocation.module.upper() != "ED2MAIN" or relocation.ordinal is None:
            continue
        target_name = exe_ordinal_names.get(relocation.ordinal, "")
        if target_name not in {"ENTER_PROG", "ENTER_PROG2"}:
            continue
        if not 1 <= relocation.segment <= len(segments):
            continue
        segment = segments[relocation.segment - 1]
        block = data[segment.file_offset:segment.file_offset + segment.length]
        source = relocation.source_offset
        # Borland call sequence: BB <record offset>; far call ENTER_PROG/2.
        if source < 4 or source > len(block) or block[source - 4] != 0xBB:
            continue
        record_offset = u16(block, source - 3)
        key = (segment.index, record_offset)
        if key in seen or record_offset + 34 > len(block):
            continue
        raw = bytes(block[record_offset:record_offset + 34])
        sin_no = u16(raw, 12)
        type_index = (sin_no >> 12) & 0xF
        if type_index >= len(SCENE_TYPE_LETTERS):
            continue
        map_number = raw[5]
        destination = scene_name_from_sin(sin_no)
        # Field maps are M_000 records 0..39; other scene classes use M_001..003.
        if destination.startswith("F_") and map_number > 39:
            continue
        if not destination.startswith("F_") and map_number > 119:
            continue
        seen.add(key)
        result.append(TransitionRecord(
            source_scene=path.name,
            call_segment=relocation.segment,
            call_source_offset=source,
            record_segment=segment.index,
            record_offset=record_offset,
            mp_pny=raw[3], mp_pnx=raw[4], map_number=map_number, map_mask=raw[6],
            ptr_no=raw[11], sin_no=sin_no, destination_scene=destination,
            bc_no=raw[15], bgm_no=raw[16], floor_chr_no=raw[17], town_no=raw[18],
            chr_nos=tuple(raw[26:34]), raw=raw,
        ))
    return sorted(result, key=lambda item: (item.record_segment, item.record_offset))

def parse_ne_exports(data: bytes) -> dict[str, tuple[int, int]]:
    entries, names = parse_ne_export_ordinals(data)
    return {name: entries[ordinal] for ordinal, name in names.items() if ordinal in entries}


def exe_scene_palette(exe_path: Path) -> list[tuple[int, int, int]]:
    """Return the base 16-color scene palette in normal RGB order.

    ST_SIN_PAL copies 48 bytes from ED2MAIN segment 85:0x39D8.  The
    engine stores each color as B, R, G nibbles, matching the PC-98 analog
    palette port order rather than conventional RGB byte order.
    """
    data = exe_path.read_bytes()
    segments = parse_ne_segments(data)
    if len(segments) < 85:
        raise FormatError("ED2MAIN.EXE does not contain expected segment 85")
    seg = segments[84]
    offset = seg.file_offset + 0x39D8
    raw = data[offset:offset + 48]
    if len(raw) != 48 or any(value > 15 for value in raw):
        raise FormatError("ED2 scene palette signature was not found")
    palette: list[tuple[int, int, int]] = []
    for index in range(0, 48, 3):
        blue, red, green = raw[index:index + 3]
        palette.append((red * 17, green * 17, blue * 17))
    return palette


@dataclass
class MapRecord:
    key: str
    map_id: int
    map_kind: str
    archive_number: int
    record_index: int
    archive_name: str
    tiles: Optional[bytearray]
    editable: bool
    description: str
    field_mp: Optional[int] = None
    field_mask: Optional[int] = None
    change_scripts: tuple[tuple[bytes, int], ...] = ()
    width: int = MAP_W
    height: int = MAP_H
    special_kind: Optional[str] = None
    special_index: Optional[int] = None


class _ArchiveBase:
    def __init__(self, path: Path, archive_number: int):
        self.path = path
        self.archive_number = archive_number
        self.decompressed = bzh_decompress(path.read_bytes())
        if len(self.decompressed) < ARCHIVE_HEADER:
            raise FormatError(f"{path.name}: archive too small")
        self.offsets = list(struct.unpack_from("<40H", self.decompressed, 0))
        if self.offsets[0] != ARCHIVE_HEADER:
            raise FormatError(f"{path.name}: invalid first record offset")
        if any(a >= b for a, b in zip(self.offsets, self.offsets[1:])):
            raise FormatError(f"{path.name}: non-increasing record offsets")
        if self.offsets[-1] >= len(self.decompressed):
            raise FormatError(f"{path.name}: record offset outside archive")
        self.records = []
        for index, start in enumerate(self.offsets):
            end = self.offsets[index + 1] if index < 39 else len(self.decompressed)
            self.records.append(bytes(self.decompressed[start:end]))

    def rebuild(self, replacement_index: int, replacement: bytes) -> bytes:
        records = list(self.records)
        records[replacement_index] = replacement
        output = bytearray(b"\0" * ARCHIVE_HEADER)
        offsets = []
        for record in records:
            offsets.append(len(output))
            if offsets[-1] > 0xFFFF:
                raise FormatError("Archive record offset exceeds 16-bit range")
            output.extend(record)
        if len(output) > 0xFFFF:
            raise FormatError("Decompressed archive exceeds 65535 bytes")
        struct.pack_into("<40H", output, 0, *offsets)
        return bzh_compress_literal(bytes(output))


class StandardArchive(_ArchiveBase):
    def get(self, index: int, map_id: int) -> MapRecord:
        decoded, used, terminated = inner_rle_decode(self.records[index], MAP_CELLS + 1)
        editable = terminated and len(decoded) == MAP_CELLS
        screen_tiles = storage_to_screen_map(decoded, MAP_W, MAP_H) if editable else None
        script = self.records[index][used:] if editable else b""
        if editable:
            parse_map_change_script(script)
        return MapRecord(
            key=f"standard:{map_id:03d}", map_id=map_id, map_kind="standard",
            archive_number=self.archive_number, record_index=index,
            archive_name=self.path.name, tiles=bytearray(screen_tiles) if screen_tiles is not None else None,
            editable=editable,
            description="표준 32×32 맵 (EXE 열 우선 저장 → 화면 좌표 변환)" if editable else "특수 레코드(읽기 전용)",
            change_scripts=((script, 0),) if editable else (),
        )

    def replace(self, index: int, tiles: bytes) -> bytes:
        if len(tiles) != MAP_CELLS:
            raise ValueError("Map must contain 1024 tile codes")
        _old, used, terminated = inner_rle_decode(self.records[index], MAP_CELLS + 1)
        if not terminated:
            raise FormatError("Standard map record has no RLE terminator")
        script = self.records[index][used:]
        parse_map_change_script(script)
        storage_tiles = screen_to_storage_map(tiles, MAP_W, MAP_H)
        encoded = self.rebuild(index, inner_rle_encode(storage_tiles) + script)
        check = StandardArchive.from_bytes(encoded, self.path, self.archive_number)
        record = check.get(index, (self.archive_number - 1) * 40 + index)
        if not record.editable or bytes(record.tiles or b"") != tiles or record.change_scripts != ((script, 0),):
            raise FormatError("Standard map round-trip failed")
        return encoded

    @classmethod
    def from_bytes(cls, encoded: bytes, path: Path, number: int) -> "StandardArchive":
        obj = cls.__new__(cls)
        obj.path, obj.archive_number = path, number
        obj.decompressed = bzh_decompress(encoded)
        obj.offsets = list(struct.unpack_from("<40H", obj.decompressed, 0))
        obj.records = []
        for i, start in enumerate(obj.offsets):
            end = obj.offsets[i + 1] if i < 39 else len(obj.decompressed)
            obj.records.append(bytes(obj.decompressed[start:end]))
        return obj


@dataclass
class LargeParts:
    chunks: list[bytes]
    scripts: list[bytes]
    sections: list[bytes]


def parse_large_record(raw: bytes) -> LargeParts:
    if len(raw) < 12:
        raise FormatError("Field record is too short")
    starts = list(struct.unpack_from("<4H", raw, 0))
    if starts[0] != 8 or any(a >= b for a, b in zip(starts, starts[1:])) or starts[-1] >= len(raw):
        raise FormatError(f"Invalid field chunk offsets: {starts}")
    chunks: list[bytes] = []
    scripts: list[bytes] = []
    sections: list[bytes] = []
    for i, section_start in enumerate(starts):
        section_end = starts[i + 1] if i < 3 else len(raw)
        section = raw[section_start:section_end]
        decoded, used, terminated = inner_rle_decode(section, 257)
        if not terminated or len(decoded) != 256:
            raise FormatError(f"Field chunk {i} does not decode to 16×16")
        script = section[used:]
        parse_map_change_script(script)
        chunks.append(decoded)
        scripts.append(script)
        sections.append(section)
    return LargeParts(chunks, scripts, sections)


def field_chunk_location(mp_num: int, map_mask: int) -> tuple[int, int]:
    """Return M_000 record/chunk selected by UN_PACK_SUB.

    MP_NUM wraps at 10 and is the vertical chunk coordinate. MAP_MASK wraps at
    16 and is the horizontal chunk coordinate. The archive is 5x8 records,
    each holding the four parity chunks TL, BL, TR, BR.
    """
    mp_num %= 10
    map_mask &= 0x0F
    record_index = (map_mask // 2) * 5 + (mp_num // 2)
    chunk_index = (map_mask & 1) * 2 + (mp_num & 1)
    return record_index, chunk_index


def join_field_chunks(chunks: list[bytes]) -> bytes:
    if len(chunks) != 4 or any(len(chunk) != 256 for chunk in chunks):
        raise ValueError("Four 16×16 field chunks are required")
    # Input order follows the four UN_PACK calls: TL, BL, TR, BR.
    screen_chunks = [storage_to_screen_map(chunk, 16, 16) for chunk in chunks]
    out = bytearray(MAP_CELLS)
    for y in range(32):
        for x in range(32):
            q = (2 if x >= 16 else 0) + (1 if y >= 16 else 0)
            out[y * 32 + x] = screen_chunks[q][(y & 15) * 16 + (x & 15)]
    return bytes(out)


def split_field_chunks(tiles: bytes) -> list[bytes]:
    if len(tiles) != MAP_CELLS:
        raise ValueError("Field map must contain 1024 tile codes")
    screen_chunks = [bytearray(256) for _ in range(4)]
    for y in range(32):
        for x in range(32):
            q = (2 if x >= 16 else 0) + (1 if y >= 16 else 0)
            screen_chunks[q][(y & 15) * 16 + (x & 15)] = tiles[y * 32 + x]
    return [screen_to_storage_map(bytes(chunk), 16, 16) for chunk in screen_chunks]


class LargeArchive(_ArchiveBase):
    def _parts(self) -> list[LargeParts]:
        return [parse_large_record(record) for record in self.records]

    def _chunk(self, parts: list[LargeParts], mp_num: int, map_mask: int) -> tuple[bytes, bytes]:
        record_index, chunk_index = field_chunk_location(mp_num, map_mask)
        part = parts[record_index]
        return part.chunks[chunk_index], part.scripts[chunk_index]

    def get(self, mp_num: int, map_mask: int) -> MapRecord:
        parts = self._parts()
        coords = [
            (mp_num, map_mask),
            ((mp_num + 1) % 10, map_mask),
            (mp_num, (map_mask + 1) & 0x0F),
            ((mp_num + 1) % 10, (map_mask + 1) & 0x0F),
        ]
        selected = [self._chunk(parts, a, b) for a, b in coords]
        chunks = [item[0] for item in selected]
        scripts = [item[1] for item in selected]
        bases = (0, 32, 2048, 2080)
        return MapRecord(
            key=f"large:{mp_num:02d}:{map_mask:02d}",
            map_id=mp_num * 16 + map_mask, map_kind="large",
            archive_number=0, record_index=field_chunk_location(mp_num, map_mask)[0],
            archive_name=self.path.name, tiles=bytearray(join_field_chunks(chunks)), editable=True,
            description="필드 32×32 창 (M_000 10×16 청크 그리드에서 EXE 방식으로 조립)",
            field_mp=mp_num, field_mask=map_mask,
            change_scripts=tuple((script, base) for script, base in zip(scripts, bases)),
        )

    @staticmethod
    def _build_record(part: LargeParts, changed: set[int]) -> bytes:
        body = bytearray(b"\0" * 8)
        starts: list[int] = []
        for index, (chunk, script, original_section) in enumerate(zip(part.chunks, part.scripts, part.sections)):
            starts.append(len(body))
            if index in changed:
                body.extend(inner_rle_encode(chunk))
                body.extend(script)
            else:
                body.extend(original_section)
        if any(value > 0xFFFF for value in starts) or len(body) > 0xFFFF:
            raise FormatError("Field record exceeds 16-bit offsets")
        struct.pack_into("<4H", body, 0, *starts)
        return bytes(body)

    def replace(self, mp_num: int, map_mask: int, tiles: bytes) -> bytes:
        parts = self._parts()
        chunks = split_field_chunks(tiles)
        coords = [
            (mp_num, map_mask),
            ((mp_num + 1) % 10, map_mask),
            (mp_num, (map_mask + 1) & 0x0F),
            ((mp_num + 1) % 10, (map_mask + 1) & 0x0F),
        ]
        touched: dict[int, set[int]] = defaultdict(set)
        for coord, chunk in zip(coords, chunks):
            record_index, chunk_index = field_chunk_location(*coord)
            parts[record_index].chunks[chunk_index] = chunk
            touched[record_index].add(chunk_index)
        records = [
            self._build_record(part, touched[index]) if index in touched else self.records[index]
            for index, part in enumerate(parts)
        ]
        output = bytearray(b"\0" * ARCHIVE_HEADER)
        offsets: list[int] = []
        for record in records:
            offsets.append(len(output))
            output.extend(record)
        if len(output) > 0xFFFF:
            raise FormatError("Decompressed field archive exceeds 65535 bytes")
        struct.pack_into("<40H", output, 0, *offsets)
        encoded = bzh_compress_literal(bytes(output))
        check = LargeArchive.from_bytes(encoded, self.path)
        record = check.get(mp_num, map_mask)
        if bytes(record.tiles or b"") != tiles:
            raise FormatError("Field map round-trip failed")
        return encoded

    @classmethod
    def from_bytes(cls, encoded: bytes, path: Path) -> "LargeArchive":
        obj = cls.__new__(cls)
        obj.path, obj.archive_number = path, 0
        obj.decompressed = bzh_decompress(encoded)
        obj.offsets = list(struct.unpack_from("<40H", obj.decompressed, 0))
        obj.records = []
        for i, start in enumerate(obj.offsets):
            end = obj.offsets[i + 1] if i < 39 else len(obj.decompressed)
            obj.records.append(bytes(obj.decompressed[start:end]))
        return obj


UDG_TEMPLATE_COUNT = 18
UDG_TEMPLATE_W = 10
UDG_TEMPLATE_H = 10
UDG_LAYOUT_COUNT = 8
UDG_LAYOUT_W = 16
UDG_LAYOUT_H = 16
UDG_LAYOUT_OFFSET = 0x1C00
UDG_TEMPLATE_PTR_OFFSET = 0x3D28
UDG_SPECIAL_ANCHOR_OFFSET = 0x3D4C
UDG_SPECIAL_TEMPLATE_IDS = frozenset((9, 10, 11, 12))
# Retail ROOM 13/17 are fixed cross-map entrance/exit terminals.  Their
# descriptor coordinates and base room IDs are gameplay-significant even
# though they do not carry the 0x80/0xC0 special-marker bits.
UDG_RETAIL_TERMINAL_TEMPLATE_IDS = frozenset((13, 17))
UDG_CHEST_VARIANT = 0x40
UDG_TRANSITION_A_VARIANT = 0x80
UDG_TRANSITION_B_VARIANT = 0xC0
UDG_VARIANTS = frozenset((0x00, 0x40, 0x80, 0xC0))
UDG_NORTH = 0x01
UDG_EAST = 0x02
UDG_SOUTH = 0x04
UDG_WEST = 0x08
UDG_ROOM_OPENINGS = {
    0: UDG_NORTH | UDG_SOUTH,
    1: UDG_EAST | UDG_SOUTH,
    2: UDG_NORTH | UDG_EAST,
    3: UDG_NORTH | UDG_SOUTH,
    4: UDG_SOUTH | UDG_WEST,
    5: UDG_NORTH | UDG_WEST,
    6: UDG_EAST | UDG_WEST,
    7: UDG_EAST | UDG_SOUTH | UDG_WEST,
    8: UDG_NORTH | UDG_EAST | UDG_WEST,
    9: UDG_SOUTH, 10: UDG_EAST, 11: UDG_WEST, 12: UDG_NORTH,
    13: UDG_NORTH,
    14: UDG_NORTH | UDG_EAST | UDG_SOUTH | UDG_WEST,
    15: UDG_NORTH | UDG_EAST | UDG_SOUTH,
    16: UDG_NORTH | UDG_SOUTH | UDG_WEST,
    17: UDG_SOUTH,
}


@dataclass(frozen=True)
class UDGChestEntry:
    level: int
    descriptor_index: int
    flag_index: int
    item_code: int
    source_scene: str


@dataclass(frozen=True)
class UDGSpotEntry:
    """One six-byte SINAL spot record from a G_*.DLL dungeon scene.

    ``descriptor_index`` is exposed in the editor's row-major order, while
    ``storage_index`` preserves the raw x-major room byte used by the DLL.
    The first SINAL table identifies scripted event/chest/transition spots.
    The optional second table identifies NPC/interaction rooms.
    """

    level: int
    descriptor_index: int
    storage_index: int
    trigger_type: int
    local_x: int
    local_y: int
    handler_offset: int
    source_scene: str
    table_kind: str

    @property
    def template_cell(self) -> Optional[tuple[int, int]]:
        """Return the exact 10x10 metatile cell when local C coordinates exist."""
        if self.local_x < 20 and self.local_y < 20:
            return self.local_x // 2, self.local_y // 2
        return None


@dataclass(frozen=True)
class UDGProgressionGate:
    """A story-critical dungeon room that controls passage or forced progress.

    These rooms are a stricter subset of the ordinary protected SINAL rooms.
    They are identified from imported ED2MAIN routines used by their handlers.
    A handler that changes key input state or loads a blocking actor is treated
    as a route gate.  The editor preserves its original branch cut in addition
    to the ordinary room/doorway lock.
    """

    level: int
    descriptor_index: int
    storage_index: int
    source_scene: str
    handler_offsets: tuple[int, ...]
    imported_routines: tuple[str, ...]
    reason: str


@dataclass(frozen=True)
class UDGScrollWindow:
    """One verified underground-dungeon scrolling context.

    ``origin_storage`` is ED2MAIN.UG_MAP_NO in the game's native x-major
    descriptor order (high nibble X, low nibble Y).  ``upper`` and ``lower``
    are the permitted Y origins used by UDG_TRANS.  The player normally
    occupies the center room, so stable scrolling uses world rows
    ``upper + 1`` through ``lower + 1``.
    """

    level: int
    origin_storage: int
    origin_descriptor: int
    current_descriptor: int
    upper: int
    lower: int
    source_scene: str
    destination_scene: str
    source_segment: int
    source_offset: int
    mp_pnx: int
    mp_pny: int


@dataclass(frozen=True)
class UDGScrollDomain:
    """One original connected cave section and its verified scroll area."""

    level: int
    component_cells: frozenset[int]
    safe_cells: frozenset[int]
    entry_cells: frozenset[int]
    seam_cells: frozenset[int]
    windows: tuple[UDGScrollWindow, ...]

    @property
    def verified(self) -> bool:
        return bool(self.windows)


@dataclass(frozen=True)
class UDGSceneAnchor:
    """A scene-code reference to an ED2MAIN ``UG_MAP_NO`` window.

    The game stores the 16x16 UDG table in x-major order.  ``storage_index``
    is that native value and ``descriptor_index`` is the editor's row-major
    coordinate.  ``UDG_UN_PACK`` assembles the 3x3 descriptor window beginning
    at this origin; keeping all nine descriptors byte-identical protects NPC
    placement, interaction checks and scripted event geometry.
    """

    level: int
    storage_index: int
    descriptor_index: int
    source_scene: str
    source_kind: str
    source_segment: int
    source_offset: int


def _udg_dynamic_al_constants(block: bytes, store_opcode_at: int) -> set[int]:
    """Recover compiler branch constants feeding ``mov [UG_MAP_NO], al``."""
    boundary = max(
        block.rfind(b"\xCB", 0, store_opcode_at),
        block.rfind(b"\xC3", 0, store_opcode_at),
    )
    region = block[boundary + 1:store_opcode_at]
    values: set[int] = set()
    for index, opcode in enumerate(region):
        if opcode == 0xB0 and index + 1 < len(region):
            tail = region[index + 2:index + 14]
            if 0xBE in tail and 0xEB in tail:
                values.add(region[index + 1])
        elif opcode == 0xB8 and index + 2 < len(region):
            tail = region[index + 3:index + 15]
            if 0xBB in tail and 0xBE in tail and 0xEB in tail:
                values.add(region[index + 1])
    return values


def _udg_lookup_table_values(block: bytes, address_word_at: int) -> list[tuple[int, int]]:
    """Decode Watcom's three-byte ``UG_MAP_NO`` event lookup tables."""
    window = block[address_word_at + 2:address_word_at + 26]
    try:
        mov_bx = window.index(0xBB)
    except ValueError:
        return []
    if mov_bx + 3 > len(window):
        return []
    table_offset = u16(window, mov_bx + 1)
    try:
        mov_cx = window.index(0xB9, mov_bx + 3)
    except ValueError:
        return []
    if mov_cx + 3 > len(window):
        return []
    count = u16(window, mov_cx + 1)
    if not 0 < count <= 64 or table_offset + count * 3 > len(block):
        return []
    if b"\x3A\x07" not in window[mov_cx + 3:]:
        return []
    return [
        (block[table_offset + row * 3], table_offset + row * 3)
        for row in range(count)
    ]


class UndergroundDungeonData:
    """ED2's underground-dungeon module sheets and 16x16 layout tables.

    ``UDG_MAKE_MAP`` does not treat M_002 records 0/1 as normal maps.  They
    are two raw 32x32 sheets containing eighteen 10x10 room modules.  The
    module start offsets are stored in ED2MAIN segment 85 at 0x3D28.

    ``UDG_UN_PACK`` indexes an eight-page 16x16 descriptor table in the
    decompressed M_003 stream.  The retail EXE uses offset 0x1C00; the live
    immediate is read from ``UDG_MAKE_MAP`` because editing an earlier M_003
    record can relocate the table.  The old editor split that continuous table
    at archive-record boundaries and consequently showed map IDs 107..119 as
    corrupt independent maps.
    """

    def __init__(self, exe_path: Path, archive2: StandardArchive, archive3: StandardArchive):
        self.exe_path = exe_path
        exe_data = exe_path.read_bytes()
        segments = parse_ne_segments(exe_data)
        if len(segments) < 86:
            raise FormatError("ED2MAIN map segments are missing")
        seg85 = segments[84]
        seg_data = exe_data[seg85.file_offset:seg85.file_offset + seg85.length]
        end = UDG_TEMPLATE_PTR_OFFSET + UDG_TEMPLATE_COUNT * 2
        if end > len(seg_data):
            raise FormatError("UDG template pointer table is truncated")
        self.template_offsets = list(struct.unpack_from(
            f"<{UDG_TEMPLATE_COUNT}H", seg_data, UDG_TEMPLATE_PTR_OFFSET
        ))
        anchor_end = UDG_SPECIAL_ANCHOR_OFFSET + 8
        if anchor_end > len(seg_data):
            raise FormatError("UDG special-room anchor table is truncated")
        # UDG_MAKE_MAP indexes this four-word table with template_id - 9.
        # Values are x-major offsets in the 64-wide expanded C-tile buffer.
        self.special_anchor_offsets = dict(zip(
            range(9, 13),
            struct.unpack_from("<4H", seg_data, UDG_SPECIAL_ANCHOR_OFFSET),
        ))
        self.archive2 = archive2
        self.archive3 = archive3
        self.sheets = (bytes(archive2.records[0]), bytes(archive2.records[1]))
        if any(len(sheet) != 32 * 32 for sheet in self.sheets):
            raise FormatError("M_002 UDG template sheets are not raw 32x32 records")

        for template_id, offset in enumerate(self.template_offsets):
            for row in range(UDG_TEMPLATE_H):
                start = offset + row * 32
                if start < 0 or start + UDG_TEMPLATE_W > len(archive2.decompressed):
                    raise FormatError(f"UDG template {template_id} points outside M_002")

        # UDG_MAKE_MAP contains ``add bx, imm16``.  The original immediate
        # is 0x1C00, but M_003 edits can change earlier record lengths.  Read
        # the live value from ED2MAIN so the editor also understands its own
        # safely relocated archives.
        exports = parse_ne_exports(exe_data)

        # Verify the exact UDG_TRANS state machine before enabling scroll-safe
        # editing.  The routine keeps a 3x3 room buffer.  Its high-nibble
        # coordinate scrolls freely inside the 16x16 page, while the low
        # nibble is bounded by UG_LMT_UPPER/UG_LMT_LOWER.
        scroll_location = exports.get("UDG_TRANS")
        if scroll_location is None:
            raise FormatError("UDG_TRANS export is missing")
        scroll_segment_no, scroll_offset = scroll_location
        if not 1 <= scroll_segment_no <= len(segments):
            raise FormatError("UDG_TRANS segment is invalid")
        scroll_segment = segments[scroll_segment_no - 1]
        scroll_code = exe_data[
            scroll_segment.file_offset:scroll_segment.file_offset + scroll_segment.length
        ]
        scroll_block = scroll_code[scroll_offset:scroll_offset + 0xC0]
        scroll_signatures = (
            b"\x8A\x36\x50\x20\x8B\x1E\x02\x22",
            b"\x2C\x10",
            b"\x04\x10\x3C\xE0",
            b"\x38\x06\x4E\x20",
            b"\x3A\x06\x4F\x20",
        )
        if not all(signature in scroll_block for signature in scroll_signatures):
            raise FormatError(
                "ED2MAIN UDG_TRANS scroll-limit signature is not recognized"
            )
        self.scroll_runtime_verified = True

        location = exports.get("UDG_MAKE_MAP")
        if location is None:
            raise FormatError("UDG_MAKE_MAP export is missing")
        udg_segment, udg_offset = location
        if not 1 <= udg_segment <= len(segments):
            raise FormatError("UDG_MAKE_MAP segment is invalid")
        code_segment = segments[udg_segment - 1]
        code = exe_data[
            code_segment.file_offset:code_segment.file_offset + code_segment.length
        ]
        search_start = udg_offset
        search_end = min(len(code), udg_offset + 64)
        add_at = code.find(b"\x81\xC3", search_start, search_end)
        if add_at < 0 or add_at + 4 > len(code):
            raise FormatError("UDG layout-base instruction was not found")
        self.layout_offset = u16(code, add_at + 2)
        self.layout_offset_patch_file = code_segment.file_offset + add_at + 2
        self.layout_prefix_length = self.layout_offset - archive3.offsets[27]
        if not 0 <= self.layout_prefix_length <= len(archive3.records[27]):
            raise FormatError("UDG layout offset is outside special record 107")

        table = archive3.decompressed[
            self.layout_offset:self.layout_offset + UDG_LAYOUT_COUNT * 256
        ]
        if len(table) != UDG_LAYOUT_COUNT * 256:
            raise FormatError("M_003 UDG layout table is truncated")
        self.layout_table = bytes(table)
        self.original_layout_table = bytes(table)
        valid_low = set(range(UDG_TEMPLATE_COUNT))
        for value in self.layout_table:
            self.validate_descriptor(value)

        self.special_marker_masks = tuple(
            tuple((value & 0xC0) if value != 0xFF else 0 for value in self.layout(level))
            for level in range(UDG_LAYOUT_COUNT)
        )
        self.chest_entries: tuple[tuple[UDGChestEntry, ...], ...] = tuple(
            tuple() for _ in range(UDG_LAYOUT_COUNT)
        )
        self.chest_scan_warnings: tuple[str, ...] = tuple()
        self.spot_entries: tuple[tuple[UDGSpotEntry, ...], ...] = tuple(
            tuple() for _ in range(UDG_LAYOUT_COUNT)
        )
        self.spot_scan_warnings: tuple[str, ...] = tuple()
        self.scene_anchors: tuple[tuple[UDGSceneAnchor, ...], ...] = tuple(
            tuple() for _ in range(UDG_LAYOUT_COUNT)
        )
        self.scene_protected_cells: tuple[frozenset[int], ...] = tuple(
            frozenset() for _ in range(UDG_LAYOUT_COUNT)
        )
        self.scene_protected_descriptors: tuple[dict[int, int], ...] = tuple(
            {} for _ in range(UDG_LAYOUT_COUNT)
        )
        self.scene_reference_warnings: tuple[str, ...] = tuple()
        self.progression_gates: tuple[tuple[UDGProgressionGate, ...], ...] = tuple(
            tuple() for _ in range(UDG_LAYOUT_COUNT)
        )
        self.progression_gate_warnings: tuple[str, ...] = tuple()
        self.scroll_windows: tuple[tuple[UDGScrollWindow, ...], ...] = tuple(
            tuple() for _ in range(UDG_LAYOUT_COUNT)
        )
        self.scroll_scan_warnings: tuple[str, ...] = tuple()
        self.scene_metadata_complete = False

    def scan_external_scene_metadata(
        self, scene_dir: Path, exe_ordinal_names: dict[int, str],
    ) -> None:
        """Resolve UDG treasure, event and NPC metadata from G_*.DLL scenes.

        The exported ``UDG_BOX_TBL`` arrays identify the dungeon floor without
        relying on the scene filename.  Once a scene is matched to a floor, the
        two six-byte SINAL tables at the beginning of the exported SINAL
        segment are decoded:

        ``type, room_index, local_x, local_y, handler_offset``

        The first table contains scripted event/chest/transition spots.  The
        optional second table contains NPC and interaction rooms.  Room indices
        use the same x-major order as the UDG descriptor table.  The editor
        locks every directly referenced descriptor.  It does not blanket-lock
        the complete UG_MAP_NO 3x3 window.  Exact local event cells are locked
        in the shared room template; NPC or room-level events lock that template.
        """
        chest_by_level: list[list[UDGChestEntry]] = [
            [] for _ in range(UDG_LAYOUT_COUNT)
        ]
        chest_warnings: list[str] = []
        spot_by_level: list[list[UDGSpotEntry]] = [
            [] for _ in range(UDG_LAYOUT_COUNT)
        ]
        spot_warnings: list[str] = []
        if not scene_dir.is_dir():
            self.chest_entries = tuple(tuple() for _ in range(UDG_LAYOUT_COUNT))
            self.chest_scan_warnings = tuple()
            self.spot_entries = tuple(tuple() for _ in range(UDG_LAYOUT_COUNT))
            self.spot_scan_warnings = tuple()
            self.scene_anchors = tuple(tuple() for _ in range(UDG_LAYOUT_COUNT))
            self.scene_protected_cells = tuple(
                frozenset() for _ in range(UDG_LAYOUT_COUNT)
            )
            self.scene_protected_descriptors = tuple(
                {} for _ in range(UDG_LAYOUT_COUNT)
            )
            self.scene_reference_warnings = tuple()
            self.progression_gates = tuple(
                tuple() for _ in range(UDG_LAYOUT_COUNT)
            )
            self.progression_gate_warnings = tuple()
            self.scroll_windows = tuple(
                tuple() for _ in range(UDG_LAYOUT_COUNT)
            )
            self.scroll_scan_warnings = tuple()
            self.scene_metadata_complete = False
            return

        # Associate each G scene with every dungeon floor that actually
        # enters it.  This is more complete than chest-table matching alone:
        # G_000 has no chest table, and G_240 is shared by floors 5 and 6.
        inbound_scene_levels: dict[str, set[int]] = defaultdict(set)
        all_udg_transitions: list[TransitionRecord] = []
        transition_file_data: dict[str, tuple[bytes, list[NESegment], list[NERelocation]]] = {}
        for source_path in sorted(scene_dir.glob("*.DLL")):
            try:
                source_data = source_path.read_bytes()
                transitions = extract_scene_transitions(
                    source_path, exe_ordinal_names, source_data
                )
                transition_file_data[source_path.name.upper()] = (
                    source_data, parse_ne_segments(source_data),
                    parse_ne_relocations(source_data),
                )
            except Exception:
                continue
            for transition in transitions:
                if (
                    transition.destination_scene.upper().startswith("G_")
                    and 0 <= transition.map_number < UDG_LAYOUT_COUNT
                    and (scene_dir / transition.destination_scene).is_file()
                ):
                    inbound_scene_levels[
                        transition.destination_scene.upper()
                    ].add(transition.map_number)
                    all_udg_transitions.append(transition)

        # Recover the runtime scroll window paired with each dungeon entry.
        # Watcom writes UG_MAP_NO and the packed UG_LIMIT word shortly before
        # ENTER_PROG/ENTER_PROG2.  UG_MAP_NO is native x-major: high nibble X,
        # low nibble Y.  UDG_TRANS bounds the low nibble with UG_LIMIT.
        scroll_by_level: list[list[UDGScrollWindow]] = [
            [] for _ in range(UDG_LAYOUT_COUNT)
        ]
        scroll_warnings: list[str] = []
        for transition in all_udg_transitions:
            cached = transition_file_data.get(transition.source_scene.upper())
            if cached is None:
                scroll_warnings.append(
                    f"{transition.source_scene}: transition file could not be parsed"
                )
                continue
            source_data, segments, relocations = cached
            if not 1 <= transition.call_segment <= len(segments):
                scroll_warnings.append(
                    f"{transition.source_scene}: invalid transition code segment"
                )
                continue
            segment = segments[transition.call_segment - 1]
            block = source_data[
                segment.file_offset:segment.file_offset + segment.length
            ]
            nearby: dict[str, NERelocation] = {}
            for global_name in ("UG_MAP_NO", "UG_LIMIT"):
                candidates = [
                    relocation for relocation in relocations
                    if relocation.segment == transition.call_segment
                    and relocation.module.upper() == "ED2MAIN"
                    and relocation.ordinal is not None
                    and exe_ordinal_names.get(relocation.ordinal, "") == global_name
                    and relocation.source_offset < transition.call_source_offset
                    and transition.call_source_offset - relocation.source_offset <= 192
                ]
                if candidates:
                    nearby[global_name] = max(
                        candidates, key=lambda item: item.source_offset
                    )
            if set(nearby) != {"UG_MAP_NO", "UG_LIMIT"}:
                scroll_warnings.append(
                    f"{transition.source_scene} seg {transition.call_segment}:"
                    f"0x{transition.call_source_offset:04X}: static scroll context not found"
                )
                continue
            map_reloc = nearby["UG_MAP_NO"]
            limit_reloc = nearby["UG_LIMIT"]
            if not (
                map_reloc.source_offset >= 2
                and block[map_reloc.source_offset - 2:map_reloc.source_offset] == b"\xC6\x06"
                and map_reloc.source_offset + 3 <= len(block)
                and limit_reloc.source_offset >= 2
                and block[limit_reloc.source_offset - 2:limit_reloc.source_offset] == b"\xC7\x06"
                and limit_reloc.source_offset + 4 <= len(block)
            ):
                scroll_warnings.append(
                    f"{transition.source_scene} seg {transition.call_segment}:"
                    f"0x{transition.call_source_offset:04X}: dynamic scroll context"
                )
                continue
            origin = block[map_reloc.source_offset + 2]
            packed_limit = u16(block, limit_reloc.source_offset + 2)
            upper, lower = packed_limit & 0xFF, packed_limit >> 8
            origin_x, origin_y = origin >> 4, origin & 0x0F
            if (
                origin_x > UDG_LAYOUT_W - 3
                or origin_y > UDG_LAYOUT_H - 3
                or upper > lower
                or lower > UDG_LAYOUT_H - 3
            ):
                scroll_warnings.append(
                    f"{transition.source_scene}: invalid UDG scroll window "
                    f"origin=0x{origin:02X}, limit={upper}..{lower}"
                )
                continue
            room_x = min(2, transition.mp_pnx // 20)
            room_y = min(2, transition.mp_pny // 20)
            current_x, current_y = origin_x + room_x, origin_y + room_y
            scroll_by_level[transition.map_number].append(UDGScrollWindow(
                level=transition.map_number,
                origin_storage=origin,
                origin_descriptor=origin_y * UDG_LAYOUT_W + origin_x,
                current_descriptor=current_y * UDG_LAYOUT_W + current_x,
                upper=upper, lower=lower,
                source_scene=transition.source_scene,
                destination_scene=transition.destination_scene,
                source_segment=transition.call_segment,
                source_offset=transition.call_source_offset,
                mp_pnx=transition.mp_pnx, mp_pny=transition.mp_pny,
            ))
        self.scroll_windows = tuple(
            tuple(sorted(entries, key=lambda item: (
                item.origin_storage, item.upper, item.lower, item.source_scene,
                item.source_segment, item.source_offset,
            )))
            for entries in scroll_by_level
        )
        self.scroll_scan_warnings = tuple(scroll_warnings)

        # G_*.DLL stores descriptor indices in the same x-major order as the
        # game table.  Keep matching in storage order, then convert exposed
        # entry coordinates to the editor's row-major index below.
        expected_positions = [
            {index for index, value in enumerate(
                self.layout_table[level * 256:(level + 1) * 256]
            ) if value != 0xFF and (value & 0xC0) == UDG_CHEST_VARIANT}
            for level in range(UDG_LAYOUT_COUNT)
        ]
        for path in sorted(scene_dir.glob("G_*.DLL")):
            if path.name.upper() == "G_000.DLL":
                continue
            try:
                data = path.read_bytes()
                segments = parse_ne_segments(data)
                assignments: dict[str, tuple[int, bytes, int]] = {}
                for relocation in parse_ne_relocations(data):
                    if relocation.module.upper() != "ED2MAIN" or relocation.ordinal is None:
                        continue
                    name = exe_ordinal_names.get(relocation.ordinal, "")
                    if name not in {"UDG_BOX_TBL", "UDG_BOX_LEN"}:
                        continue
                    segment = segments[relocation.segment - 1]
                    segment_data = data[
                        segment.file_offset:segment.file_offset + segment.length
                    ]
                    # Watcom emits C7 06 <relocated global> <local immediate>.
                    # The NE relocation points at the global-address word.
                    if relocation.source_offset < 2 or (
                        segment_data[relocation.source_offset - 2:relocation.source_offset] != b"\xC7\x06"
                    ):
                        continue
                    immediate_at = relocation.source_offset + 2
                    if immediate_at + 2 > len(segment_data):
                        continue
                    assignments[name] = (
                        relocation.segment, segment_data, u16(segment_data, immediate_at)
                    )
                if not {"UDG_BOX_TBL", "UDG_BOX_LEN"} <= assignments.keys():
                    continue
                table_segment, segment_data, table_offset = assignments["UDG_BOX_TBL"]
                len_segment, _len_data, count = assignments["UDG_BOX_LEN"]
                if count == 0:
                    continue
                if table_segment != len_segment:
                    chest_warnings.append(
                        f"{path.name}: UDG box table/length use different segments"
                    )
                    continue
                end = table_offset + count * 3
                if count > 64 or end > len(segment_data):
                    chest_warnings.append(
                        f"{path.name}: UDG box table is outside its segment"
                    )
                    continue
                raw_entries = [
                    tuple(segment_data[table_offset + i * 3:table_offset + i * 3 + 3])
                    for i in range(count)
                ]
                positions = {entry[0] for entry in raw_entries}
                if not positions:
                    continue
                matches = [
                    level for level, expected in enumerate(expected_positions)
                    if positions == expected
                ]
                if len(matches) != 1:
                    chest_warnings.append(
                        f"{path.name}: UDG box positions do not uniquely match a layout page"
                    )
                    continue
                level = matches[0]
                chest_by_level[level].extend(
                    UDGChestEntry(
                        level, self.layout_storage_to_screen_index(position),
                        flag, item, path.name
                    )
                    for position, flag, item in raw_entries
                )
            except Exception as exc:
                chest_warnings.append(f"{path.name}: UDG box-table scan failed: {exc}")

        self.chest_entries = tuple(
            tuple(sorted(entries, key=lambda item: (
                item.descriptor_index, item.source_scene, item.flag_index, item.item_code
            )))
            for entries in chest_by_level
        )
        self.chest_scan_warnings = tuple(chest_warnings)

        # Use both the complete treasure-marker match and real inbound scene
        # transitions.  A scene may legitimately belong to multiple floors.
        scene_to_levels: dict[str, set[int]] = {
            name: set(levels) for name, levels in inbound_scene_levels.items()
        }
        for level, entries in enumerate(self.chest_entries):
            for entry in entries:
                scene_to_levels.setdefault(entry.source_scene.upper(), set()).add(level)

        valid_spot_types = {0x02, 0x06, 0x80}
        for scene_name, levels in sorted(scene_to_levels.items()):
            path = scene_dir / scene_name
            try:
                data = path.read_bytes()
                segments = parse_ne_segments(data)
                sinal_location = parse_ne_exports(data).get("SINAL")
                if sinal_location is None:
                    spot_warnings.append(f"{path.name}: SINAL export is missing")
                    continue
                segment_number, sinal_offset = sinal_location
                if not 1 <= segment_number <= len(segments):
                    spot_warnings.append(f"{path.name}: SINAL segment is invalid")
                    continue
                segment = segments[segment_number - 1]
                segment_data = data[
                    segment.file_offset:segment.file_offset + segment.length
                ]
                if not 0 <= sinal_offset <= len(segment_data):
                    spot_warnings.append(f"{path.name}: SINAL offset is outside its segment")
                    continue

                position = 0
                parsed_tables: list[list[tuple[int, int, int, int, int]]] = []
                for _table_number in range(2):
                    records: list[tuple[int, int, int, int, int]] = []
                    terminated = False
                    while position < sinal_offset:
                        if segment_data[position] == 0xFF:
                            position += 1
                            terminated = True
                            break
                        if position + 6 > sinal_offset:
                            break
                        trigger_type = segment_data[position]
                        storage_index = segment_data[position + 1]
                        local_x = segment_data[position + 2]
                        local_y = segment_data[position + 3]
                        handler_offset = u16(segment_data, position + 4)
                        # Handler offsets must point at code at/after SINAL.
                        # This excludes similar-looking six-byte data records.
                        if (
                            trigger_type not in valid_spot_types
                            or not sinal_offset <= handler_offset < len(segment_data)
                        ):
                            break
                        records.append((
                            trigger_type, storage_index, local_x, local_y,
                            handler_offset,
                        ))
                        position += 6
                    if records:
                        parsed_tables.append(records)
                    if not terminated:
                        break

                if not parsed_tables:
                    spot_warnings.append(f"{path.name}: no valid SINAL spot table found")
                    continue

                layouts = {level: self.layout(level) for level in levels}
                for table_number, records in enumerate(parsed_tables):
                    table_kind = "event" if table_number == 0 else "npc"
                    for (
                        trigger_type, storage_index, local_x, local_y,
                        handler_offset,
                    ) in records:
                        descriptor_index = self.layout_storage_to_screen_index(
                            storage_index
                        )
                        valid_levels = [
                            level for level in sorted(levels)
                            if layouts[level][descriptor_index] != 0xFF
                        ]
                        if not valid_levels:
                            spot_warnings.append(
                                f"{path.name}: {table_kind} spot room "
                                f"0x{storage_index:02X} is empty on every associated floor"
                            )
                            continue
                        for level in valid_levels:
                            spot_by_level[level].append(
                                UDGSpotEntry(
                                    level=level,
                                    descriptor_index=descriptor_index,
                                    storage_index=storage_index,
                                    trigger_type=trigger_type,
                                    local_x=local_x,
                                    local_y=local_y,
                                    handler_offset=handler_offset,
                                    source_scene=path.name,
                                    table_kind=table_kind,
                                )
                            )
            except Exception as exc:
                spot_warnings.append(f"{path.name}: SINAL spot scan failed: {exc}")

        self.spot_entries = tuple(
            tuple(sorted(entries, key=lambda item: (
                item.descriptor_index, item.table_kind, item.source_scene,
                item.handler_offset, item.trigger_type, item.local_x, item.local_y,
            )))
            for entries in spot_by_level
        )
        self.spot_scan_warnings = tuple(spot_warnings)

        # Identify only story-critical passage gates.  Ordinary NPC/event
        # rooms are intentionally *not* protected: that was the source of the
        # over-conservative v0.5.0/v0.5.1 simplification.  The retail old-man
        # gate in G_200 imports both SET_KEY_DATA and SPRITE_LOAD from ED2MAIN;
        # these routines are strong evidence that the handler temporarily
        # controls movement and places/removes a blocking actor.
        gate_by_level: list[list[UDGProgressionGate]] = [
            [] for _ in range(UDG_LAYOUT_COUNT)
        ]
        gate_warnings: list[str] = []
        strong_gate_routines = {"SET_KEY_DATA", "SPRITE_LOAD"}
        entries_by_scene: dict[str, list[UDGSpotEntry]] = defaultdict(list)
        for entries in self.spot_entries:
            for entry in entries:
                entries_by_scene[entry.source_scene.upper()].append(entry)
        for scene_name, all_entries in sorted(entries_by_scene.items()):
            path = scene_dir / scene_name
            try:
                data = path.read_bytes()
                segments = parse_ne_segments(data)
                sinal_location = parse_ne_exports(data).get("SINAL")
                if sinal_location is None:
                    continue
                sinal_segment, _sinal_offset = sinal_location
                if not 1 <= sinal_segment <= len(segments):
                    continue
                segment_length = segments[sinal_segment - 1].length
                imports: list[tuple[int, str]] = []
                for relocation in parse_ne_relocations(data):
                    if (
                        relocation.segment == sinal_segment
                        and relocation.module.upper() == "ED2MAIN"
                        and relocation.ordinal is not None
                    ):
                        name = exe_ordinal_names.get(relocation.ordinal, "")
                        if name:
                            imports.append((relocation.source_offset, name))
                handler_offsets = sorted({
                    entry.handler_offset for entry in all_entries
                })
                grouped: dict[tuple[int, int], list[UDGSpotEntry]] = defaultdict(list)
                for entry in all_entries:
                    if entry.table_kind == "npc":
                        grouped[(entry.level, entry.descriptor_index)].append(entry)
                for (level, descriptor_index), entries in sorted(grouped.items()):
                    routines: set[str] = set()
                    offsets: list[int] = []
                    for entry in entries:
                        start = entry.handler_offset
                        end = min(
                            (value for value in handler_offsets if value > start),
                            default=segment_length,
                        )
                        offsets.append(start)
                        routines.update(
                            name for source, name in imports
                            if start <= source < end
                        )
                    matched = sorted(routines & strong_gate_routines)
                    if not matched:
                        continue
                    storage_index = entries[0].storage_index
                    gate_by_level[level].append(UDGProgressionGate(
                        level=level,
                        descriptor_index=descriptor_index,
                        storage_index=storage_index,
                        source_scene=scene_name,
                        handler_offsets=tuple(sorted(set(offsets))),
                        imported_routines=tuple(sorted(routines)),
                        reason=(
                            "blocking/forced-progress handler imports "
                            + ", ".join(matched)
                        ),
                    ))
            except Exception as exc:
                gate_warnings.append(
                    f"{scene_name}: progression-gate scan failed: {exc}"
                )
        self.progression_gates = tuple(
            tuple(sorted(entries, key=lambda item: (
                item.descriptor_index, item.source_scene, item.handler_offsets
            )))
            for entries in gate_by_level
        )
        self.progression_gate_warnings = tuple(gate_warnings)

        # SINAL records identify individual actors and triggers, but dungeon
        # scene code also selects a 3x3 room window through ED2MAIN.UG_MAP_NO.
        # UDG_UN_PACK consumes that complete window.  Protecting only the one
        # SINAL room can therefore leave an NPC/event scene surrounded by a
        # different room arrangement.  Recover every statically visible
        # UG_MAP_NO origin and lock all nine descriptors in its original 3x3
        # window.  The destination transition record supplies the floor; this
        # also handles G_240.DLL, which is shared by floors 5 and 6.
        scene_levels = inbound_scene_levels
        transition_scan_warnings: list[str] = []

        anchors_by_level: list[list[UDGSceneAnchor]] = [
            [] for _ in range(UDG_LAYOUT_COUNT)
        ]
        protected_cells_by_level: list[set[int]] = [
            set() for _ in range(UDG_LAYOUT_COUNT)
        ]
        scene_reference_warnings: list[str] = transition_scan_warnings
        seen_anchors: set[tuple[int, int, str, str, int, int]] = set()

        for path in sorted(scene_dir.glob("G_*.DLL")):
            levels = scene_levels.get(path.name.upper(), set())
            try:
                data = path.read_bytes()
                segments = parse_ne_segments(data)
                candidates: list[tuple[int, str, int, int]] = []
                for relocation in parse_ne_relocations(data):
                    if (
                        relocation.module.upper() != "ED2MAIN"
                        or relocation.ordinal is None
                        or exe_ordinal_names.get(relocation.ordinal, "")
                        != "UG_MAP_NO"
                    ):
                        continue
                    if not 1 <= relocation.segment <= len(segments):
                        scene_reference_warnings.append(
                            f"{path.name}: UG_MAP_NO relocation uses invalid segment "
                            f"{relocation.segment}"
                        )
                        continue
                    segment = segments[relocation.segment - 1]
                    block = data[
                        segment.file_offset:segment.file_offset + segment.length
                    ]
                    source = relocation.source_offset

                    # mov byte ptr [UG_MAP_NO], imm8
                    if (
                        source >= 2
                        and block[source - 2:source] == b"\xC6\x06"
                        and source + 3 <= len(block)
                    ):
                        candidates.append((
                            block[source + 2], "direct-write",
                            relocation.segment, source - 2,
                        ))
                    # cmp byte ptr [UG_MAP_NO], imm8
                    elif (
                        source >= 2
                        and block[source - 2:source] == b"\x80\x3E"
                        and source + 3 <= len(block)
                    ):
                        candidates.append((
                            block[source + 2], "direct-compare",
                            relocation.segment, source - 2,
                        ))
                    # mov [UG_MAP_NO], al; compiler branch stubs load the
                    # constant immediately before the shared store.
                    elif source >= 1 and block[source - 1] == 0xA2:
                        for value in sorted(
                            _udg_dynamic_al_constants(block, source - 1)
                        ):
                            candidates.append((
                                value, "branch-write",
                                relocation.segment, source - 1,
                            ))
                    # mov al,[UG_MAP_NO] followed by a compact 3-byte event
                    # dispatch table whose first byte is the room-window key.
                    elif source >= 1 and block[source - 1] == 0xA0:
                        for value, table_offset in _udg_lookup_table_values(
                            block, source
                        ):
                            candidates.append((
                                value, "event-table",
                                relocation.segment, table_offset,
                            ))

                if candidates and not levels:
                    scene_reference_warnings.append(
                        f"{path.name}: UG_MAP_NO references found but no inbound "
                        "dungeon-floor transition was found"
                    )
                    continue

                for storage_index, source_kind, segment_number, source_offset in candidates:
                    native_x, native_y = divmod(storage_index, UDG_LAYOUT_H)
                    if native_x > UDG_LAYOUT_W - 3 or native_y > UDG_LAYOUT_H - 3:
                        scene_reference_warnings.append(
                            f"{path.name}: UG_MAP_NO 0x{storage_index:02X} "
                            "does not fit a 3x3 room window"
                        )
                        continue
                    descriptor_index = self.layout_storage_to_screen_index(
                        storage_index
                    )
                    for level in sorted(levels):
                        key = (
                            level, storage_index, path.name.upper(), source_kind,
                            segment_number, source_offset,
                        )
                        if key in seen_anchors:
                            continue
                        seen_anchors.add(key)
                        anchors_by_level[level].append(UDGSceneAnchor(
                            level=level,
                            storage_index=storage_index,
                            descriptor_index=descriptor_index,
                            source_scene=path.name,
                            source_kind=source_kind,
                            source_segment=segment_number,
                            source_offset=source_offset,
                        ))
                        # Native layout storage is x-major.  Convert every
                        # member of the 3x3 window to the editor's row-major
                        # index before locking it.
                        for dx in range(3):
                            for dy in range(3):
                                native_cell = (
                                    (native_x + dx) * UDG_LAYOUT_H
                                    + native_y + dy
                                )
                                protected_cells_by_level[level].add(
                                    self.layout_storage_to_screen_index(native_cell)
                                )
            except Exception as exc:
                scene_reference_warnings.append(
                    f"{path.name}: UG_MAP_NO scene-window scan failed: {exc}"
                )

        self.scene_anchors = tuple(
            tuple(sorted(entries, key=lambda item: (
                item.descriptor_index, item.source_scene, item.source_kind,
                item.source_segment, item.source_offset,
            )))
            for entries in anchors_by_level
        )

        # Internal G-scene transitions often calculate UG_MAP_NO through AL
        # or a compact lookup table, so a literal write is not adjacent to the
        # ENTER_PROG call.  The anchor scanner above still recovers every
        # static origin.  Pair those origins with the verified UG_LIMIT used
        # when entering the same destination scene.  The center of the 3x3
        # window is the normal post-scroll player room.
        limits_by_scene_level: dict[tuple[str, int], set[tuple[int, int]]] = defaultdict(set)
        for level, windows in enumerate(self.scroll_windows):
            for window in windows:
                limits_by_scene_level[(
                    window.destination_scene.upper(), level
                )].add((window.upper, window.lower))
        augmented_scroll = [list(entries) for entries in self.scroll_windows]
        existing_scroll_keys = {
            (window.level, window.origin_storage, window.upper, window.lower,
             window.source_scene.upper(), window.source_segment, window.source_offset)
            for entries in augmented_scroll for window in entries
        }
        for level, anchors in enumerate(self.scene_anchors):
            for anchor in anchors:
                limits = limits_by_scene_level.get(
                    (anchor.source_scene.upper(), level), set()
                )
                origin_x = anchor.storage_index >> 4
                origin_y = anchor.storage_index & 0x0F
                for upper, lower in sorted(limits):
                    key = (
                        level, anchor.storage_index, upper, lower,
                        anchor.source_scene.upper(), anchor.source_segment,
                        anchor.source_offset,
                    )
                    if key in existing_scroll_keys:
                        continue
                    existing_scroll_keys.add(key)
                    augmented_scroll[level].append(UDGScrollWindow(
                        level=level, origin_storage=anchor.storage_index,
                        origin_descriptor=anchor.descriptor_index,
                        current_descriptor=(origin_y + 1) * UDG_LAYOUT_W + origin_x + 1,
                        upper=upper, lower=lower,
                        source_scene=anchor.source_scene,
                        destination_scene=anchor.source_scene,
                        source_segment=anchor.source_segment,
                        source_offset=anchor.source_offset,
                        mp_pnx=20, mp_pny=20,
                    ))
        self.scroll_windows = tuple(
            tuple(sorted(entries, key=lambda item: (
                item.origin_storage, item.upper, item.lower, item.source_scene,
                item.source_segment, item.source_offset,
            )))
            for entries in augmented_scroll
        )

        self.scene_protected_cells = tuple(
            frozenset(cells) for cells in protected_cells_by_level
        )
        self.scene_protected_descriptors = tuple(
            {
                index: self.layout(level)[index]
                for index in sorted(protected_cells_by_level[level])
            }
            for level in range(UDG_LAYOUT_COUNT)
        )
        self.scene_reference_warnings = tuple(scene_reference_warnings)
        critical_spot_warnings = tuple(
            warning for warning in self.spot_scan_warnings
            if "is empty on every associated floor" not in warning
        )
        expected_retail_gate_missing = (
            "G_200.DLL" in inbound_scene_levels
            and not any(
                gate.source_scene.upper() == "G_200.DLL"
                for entries in self.progression_gates for gate in entries
            )
        )
        # Direct SINAL rooms are mandatory protection metadata.  UG_MAP_NO
        # scene-window references remain informational and are not blanket
        # locks.  Parse failures or loss of the known retail progression gate
        # still lock UDG editing.
        self.scene_metadata_complete = not (
            critical_spot_warnings
            or self.progression_gate_warnings
            or expected_retail_gate_missing
            or not self.scroll_runtime_verified
            or any(not entries for entries in self.scroll_windows)
        )

    def chest_entries_at(self, level: int, descriptor_index: int) -> tuple[UDGChestEntry, ...]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return tuple()
        return tuple(
            entry for entry in self.chest_entries[level]
            if entry.descriptor_index == descriptor_index
        )

    def spot_entries_at(self, level: int, descriptor_index: int) -> tuple[UDGSpotEntry, ...]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return tuple()
        return tuple(
            entry for entry in self.spot_entries[level]
            if entry.descriptor_index == descriptor_index
        )

    def scene_anchors_at(
        self, level: int, descriptor_index: int,
    ) -> tuple[UDGSceneAnchor, ...]:
        """Return UG_MAP_NO origins whose 3x3 window includes a room cell."""
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return tuple()
        target_x, target_y = (
            descriptor_index % UDG_LAYOUT_W,
            descriptor_index // UDG_LAYOUT_W,
        )
        result: list[UDGSceneAnchor] = []
        for anchor in self.scene_anchors[level]:
            origin_x = anchor.descriptor_index % UDG_LAYOUT_W
            origin_y = anchor.descriptor_index // UDG_LAYOUT_W
            if origin_x <= target_x < origin_x + 3 and origin_y <= target_y < origin_y + 3:
                result.append(anchor)
        return tuple(result)

    @staticmethod
    def _layout_graph_for_scroll(descriptors: bytes) -> dict[int, set[int]]:
        graph: dict[int, set[int]] = {}
        directions = (
            (-1, 0, UDG_NORTH, UDG_SOUTH),
            (0, 1, UDG_EAST, UDG_WEST),
            (1, 0, UDG_SOUTH, UDG_NORTH),
            (0, -1, UDG_WEST, UDG_EAST),
        )
        for index, value in enumerate(descriptors):
            if value == 0xFF:
                continue
            mask = UDG_ROOM_OPENINGS[value & 0x1F]
            x, y = index % UDG_LAYOUT_W, index // UDG_LAYOUT_W
            graph[index] = set()
            for dy, dx, bit, opposite in directions:
                nx, ny = x + dx, y + dy
                if not (mask & bit) or not (
                    0 <= nx < UDG_LAYOUT_W and 0 <= ny < UDG_LAYOUT_H
                ):
                    continue
                other = ny * UDG_LAYOUT_W + nx
                other_value = descriptors[other]
                if (
                    other_value != 0xFF
                    and UDG_ROOM_OPENINGS[other_value & 0x1F] & opposite
                ):
                    graph[index].add(other)
        return graph

    def scroll_domains(self, level: int) -> tuple[UDGScrollDomain, ...]:
        """Map verified UDG_TRANS windows onto original connected sections.

        The domains are retained for diagnostics and for identifying retail
        ROOM 0 cells whose exact internal walkable geometry is required at
        scrolling boundaries.  They do not blanket-lock an entire 3x3 scene
        window or every room in an unverified component.
        """
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return tuple()
        layout = self.layout(level)
        graph = self._layout_graph_for_scroll(layout)
        components: list[set[int]] = []
        visited: set[int] = set()
        for start in graph:
            if start in visited:
                continue
            component = {start}
            visited.add(start)
            stack = [start]
            while stack:
                current = stack.pop()
                for other in graph[current]:
                    if other not in visited:
                        visited.add(other)
                        component.add(other)
                        stack.append(other)
            components.append(component)

        assigned: list[list[UDGScrollWindow]] = [[] for _ in components]
        for window in self.scroll_windows[level]:
            target: Optional[int] = None
            for number, component in enumerate(components):
                if window.current_descriptor in component:
                    target = number
                    break
            if target is None:
                origin_x = window.origin_storage >> 4
                origin_y = window.origin_storage & 0x0F
                entry_window = {
                    (origin_y + dy) * UDG_LAYOUT_W + origin_x + dx
                    for dx in range(3) for dy in range(3)
                }
                ranked = sorted(
                    (len(component & entry_window), -number, number)
                    for number, component in enumerate(components)
                )
                if ranked and ranked[-1][0] > 0:
                    target = ranked[-1][2]
            if target is not None:
                assigned[target].append(window)

        result: list[UDGScrollDomain] = []
        for component, windows in zip(components, assigned):
            safe: set[int] = set()
            entries: set[int] = set()
            seam_rows: set[int] = set()
            for window in windows:
                for y in range(window.upper + 1, window.lower + 2):
                    for x in range(1, UDG_LAYOUT_W - 1):
                        safe.add(y * UDG_LAYOUT_W + x)
                origin_x = window.origin_storage >> 4
                origin_y = window.origin_storage & 0x0F
                entries.update(
                    (origin_y + dy) * UDG_LAYOUT_W + origin_x + dx
                    for dx in range(3) for dy in range(3)
                )
                seam_rows.update((
                    window.upper, window.upper + 1,
                    window.lower + 1, window.lower + 2,
                ))
            seam = {
                index for index in component
                if (layout[index] & 0x1F) == 0
            }
            # ROOM 0 and ROOM 3 have the same coarse N/S graph mask but very
            # different internal walkable geometry.  Retail ROOM 0 positions
            # are scroll-sensitive and must not be normalized to ROOM 3.
            result.append(UDGScrollDomain(
                level=level, component_cells=frozenset(component),
                safe_cells=frozenset(safe), entry_cells=frozenset(entries),
                seam_cells=frozenset(seam), windows=tuple(windows),
            ))
        return tuple(result)

    def scroll_safe_edit_cells(self, level: int) -> frozenset[int]:
        cells: set[int] = set()
        for domain in self.scroll_domains(level):
            if domain.verified:
                cells.update(domain.safe_cells)
                cells.update(domain.entry_cells)
        return frozenset(cells)

    def scroll_sensitive_indices(self, level: int) -> frozenset[int]:
        """Return rooms whose exact descriptor is needed for scrolling."""
        cells: set[int] = set()
        for domain in self.scroll_domains(level):
            cells.update(domain.seam_cells)
        return frozenset(cells)

    def scroll_sensitive_descriptors(self, level: int) -> dict[int, int]:
        layout = self.layout(level)
        return {index: layout[index] for index in self.scroll_sensitive_indices(level)}

    def progression_gate_entries_at(
        self, level: int, descriptor_index: int,
    ) -> tuple[UDGProgressionGate, ...]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return tuple()
        return tuple(
            entry for entry in self.progression_gates[level]
            if entry.descriptor_index == descriptor_index
        )

    def progression_gate_indices(self, level: int) -> frozenset[int]:
        """Return only rooms that gate movement or forced story progress."""
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return frozenset()
        return frozenset(
            entry.descriptor_index for entry in self.progression_gates[level]
        )

    def progression_gate_descriptors(self, level: int) -> dict[int, int]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return {}
        layout = self.layout(level)
        return {
            index: layout[index]
            for index in self.progression_gate_indices(level)
        }

    def spot_descriptor_indices(self, level: int) -> frozenset[int]:
        """Return non-empty rooms directly referenced by either SINAL table."""
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return frozenset()
        layout = self.layout(level)
        return frozenset(
            entry.descriptor_index
            for entry in self.spot_entries[level]
            if layout[entry.descriptor_index] != 0xFF
        )

    def spot_descriptors(self, level: int) -> dict[int, int]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return {}
        layout = self.layout(level)
        return {
            index: layout[index]
            for index in self.spot_descriptor_indices(level)
        }

    def retail_terminal_indices(self, level: int) -> frozenset[int]:
        """Return fixed cross-map entrance/exit ROOM 13/17 descriptors.

        These ordinary-looking one-way rooms are used as dungeon boundary
        terminals.  Replacing them with another dead-end room preserves graph
        connectivity but changes the actual map-transfer tile, so both their
        coordinates and complete descriptor bytes must remain unchanged.
        """
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return frozenset()
        layout = self.layout(level)
        return frozenset(
            index for index, value in enumerate(layout)
            if value != 0xFF
            and (value & 0x1F) in UDG_RETAIL_TERMINAL_TEMPLATE_IDS
        )

    def retail_terminal_descriptors(self, level: int) -> dict[int, int]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return {}
        layout = self.layout(level)
        return {
            index: layout[index]
            for index in self.retail_terminal_indices(level)
        }

    def protected_descriptor_indices(self, level: int) -> frozenset[int]:
        """Protect gameplay rooms, fixed exits and scroll-sensitive seams."""
        return frozenset(
            set(self.spot_descriptor_indices(level))
            | set(self.progression_gate_indices(level))
            | set(self.retail_terminal_indices(level))
            | set(self.scroll_sensitive_indices(level))
        )

    def protected_descriptors(self, level: int) -> dict[int, int]:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            return {}
        layout = self.layout(level)
        return {
            index: layout[index]
            for index in self.protected_descriptor_indices(level)
        }

    def template_spot_entries(self, template_id: int) -> tuple[UDGSpotEntry, ...]:
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            return tuple()
        result: list[UDGSpotEntry] = []
        layouts = [self.layout(level) for level in range(UDG_LAYOUT_COUNT)]
        for level, entries in enumerate(self.spot_entries):
            layout = layouts[level]
            for entry in entries:
                value = layout[entry.descriptor_index]
                if value != 0xFF and (value & 0x1F) == template_id:
                    result.append(entry)
        return tuple(result)

    def template_scene_anchors(
        self, template_id: int,
    ) -> tuple[UDGSceneAnchor, ...]:
        """Return scene windows that use a shared room-template module."""
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            return tuple()
        result: dict[tuple[int, str, int, str], UDGSceneAnchor] = {}
        for level in range(UDG_LAYOUT_COUNT):
            layout = self.layout(level)
            for cell in self.scene_protected_cells[level]:
                value = layout[cell]
                if value == 0xFF or (value & 0x1F) != template_id:
                    continue
                for anchor in self.scene_anchors_at(level, cell):
                    key = (
                        level, anchor.source_scene, anchor.storage_index,
                        anchor.source_kind,
                    )
                    result[key] = anchor
        return tuple(sorted(result.values(), key=lambda item: (
            item.level, item.source_scene, item.descriptor_index,
            item.source_kind, item.source_offset,
        )))

    def template_progression_gates(
        self, template_id: int,
    ) -> tuple[UDGProgressionGate, ...]:
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            return tuple()
        result: list[UDGProgressionGate] = []
        for level, entries in enumerate(self.progression_gates):
            layout = self.layout(level)
            for entry in entries:
                value = layout[entry.descriptor_index]
                if value != 0xFF and (value & 0x1F) == template_id:
                    result.append(entry)
        return tuple(sorted(result, key=lambda item: (
            item.level, item.descriptor_index, item.source_scene
        )))

    def template_is_fully_protected(self, template_id: int) -> bool:
        """Lock modules whose actor/event position cannot be narrowed safely."""
        if self.template_progression_gates(template_id):
            return True
        return any(
            entry.table_kind == "npc" or entry.template_cell is None
            for entry in self.template_spot_entries(template_id)
        )

    def template_protected_cells(
        self, template_id: int,
    ) -> dict[int, tuple[UDGSpotEntry, ...]]:
        """Return exact event-trigger cells for a partially editable module."""
        if self.template_is_fully_protected(template_id):
            return {}
        grouped: dict[int, list[UDGSpotEntry]] = defaultdict(list)
        for entry in self.template_spot_entries(template_id):
            cell = entry.template_cell
            if cell is None:
                continue
            x, y = cell
            grouped[y * UDG_TEMPLATE_W + x].append(entry)
        return {
            index: tuple(sorted(entries, key=lambda item: (
                item.source_scene, item.handler_offset, item.trigger_type
            )))
            for index, entries in grouped.items()
        }

    def template_spot_entries_at(
        self, template_id: int, cell_index: int,
    ) -> tuple[UDGSpotEntry, ...]:
        entries = self.template_spot_entries(template_id)
        if self.template_is_fully_protected(template_id):
            return entries
        return tuple(
            entry for entry in entries
            if entry.template_cell is not None
            and entry.template_cell[1] * UDG_TEMPLATE_W + entry.template_cell[0]
            == cell_index
        )

    def template_usage(self, template_id: int) -> int:
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            return 0
        return sum(
            1 for value in self.layout_table
            if value != 0xFF and (value & 0x1F) == template_id
        )

    def patched_exe(self, new_layout_offset: int) -> bytes:
        if not 0 <= new_layout_offset <= 0xFFFF:
            raise FormatError("UDG layout offset exceeds 16-bit range")
        data = bytearray(self.exe_path.read_bytes())
        if self.layout_offset_patch_file + 2 > len(data):
            raise FormatError("UDG EXE patch location is outside ED2MAIN.EXE")
        struct.pack_into("<H", data, self.layout_offset_patch_file, new_layout_offset)
        return bytes(data)

    @staticmethod
    def _xmajor_to_rowmajor(data: bytes, width: int, height: int) -> bytes:
        """Convert the game's x-major grid into normal screen row-major order."""
        if len(data) != width * height:
            raise FormatError("Grid size does not match its dimensions")
        return bytes(data[x * height + y] for y in range(height) for x in range(width))

    @staticmethod
    def _rowmajor_to_xmajor(data: bytes, width: int, height: int) -> bytes:
        """Convert editable screen row-major order back to the game's x-major order."""
        if len(data) != width * height:
            raise FormatError("Grid size does not match its dimensions")
        output = bytearray(width * height)
        for y in range(height):
            for x in range(width):
                output[x * height + y] = data[y * width + x]
        return bytes(output)

    @staticmethod
    def layout_storage_to_screen_index(index: int) -> int:
        """Translate a DLL/EXE x-major descriptor index into the editor index."""
        x, y = divmod(index, UDG_LAYOUT_H)
        return y * UDG_LAYOUT_W + x

    @staticmethod
    def layout_screen_to_storage_index(index: int) -> int:
        """Translate an editor row-major descriptor index into the game index."""
        y, x = divmod(index, UDG_LAYOUT_W)
        return x * UDG_LAYOUT_H + y

    def template(self, template_id: int) -> bytes:
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            raise ValueError("UDG template id must be 0..17")
        offset = self.template_offsets[template_id]
        source = self.archive2.decompressed
        # UDG_MAKE_MAP walks a 32-high source column before advancing X.
        # Extract the 10x10 module from x-major sheet storage, then expose it
        # to the editor in ordinary y*width+x order.
        raw = bytes(
            source[offset + x * 32 + y]
            for x in range(UDG_TEMPLATE_W)
            for y in range(UDG_TEMPLATE_H)
        )
        return self._xmajor_to_rowmajor(raw, UDG_TEMPLATE_W, UDG_TEMPLATE_H)

    def layout(self, level: int) -> bytes:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            raise ValueError("UDG level must be 0..7")
        start = level * UDG_LAYOUT_W * UDG_LAYOUT_H
        raw = self.layout_table[start:start + UDG_LAYOUT_W * UDG_LAYOUT_H]
        # UDG_UN_PACK addresses descriptors as x*16+y.  Convert once at the
        # format boundary so every GUI, CSV and PNG path uses screen order.
        return self._xmajor_to_rowmajor(raw, UDG_LAYOUT_W, UDG_LAYOUT_H)

    @staticmethod
    def validate_descriptor(value: int) -> None:
        if not 0 <= value <= 0xFF:
            raise FormatError(f"UDG descriptor is outside byte range: {value}")
        if value == 0xFF:
            return
        if value & 0x20:
            raise FormatError(f"UDG descriptor uses reserved bit 0x20: 0x{value:02X}")
        template_id = value & 0x1F
        variant = value & 0xC0
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            raise FormatError(f"Unknown UDG room template: 0x{value:02X}")
        if variant not in UDG_VARIANTS:
            raise FormatError(f"Unknown UDG special variant: 0x{value:02X}")
        if variant and template_id not in UDG_SPECIAL_TEMPLATE_IDS:
            raise FormatError(
                f"UDG special marker 0x{variant:02X} requires room template 9..12"
            )

    def validate_layout_edit(self, level: int, data: bytes) -> None:
        if not 0 <= level < UDG_LAYOUT_COUNT:
            raise ValueError("UDG level must be 0..7")
        if len(data) != UDG_LAYOUT_W * UDG_LAYOUT_H:
            raise FormatError("UDG layout must contain exactly 256 descriptors")
        for value in data:
            self.validate_descriptor(value)

        if not self.scene_metadata_complete:
            raise FormatError(
                "SCENA NPC/event metadata could not be verified completely; "
                "UDG editing is locked to prevent scene corruption"
            )

        # The high two bits are not merely graphics.  0x40 positions are
        # cross-referenced by UDG_BOX_TBL entries in G_*.DLL, while 0x80 and
        # 0xC0 positions are used as scripted transition landmarks.  Moving
        # them without rewriting every corresponding scene DLL would leave
        # chest state, treasure contents, or transitions attached to the old
        # room index.  Keep those marker coordinates fixed; the base room ID
        # at the marker may still be changed among templates 9..12.
        expected = self.special_marker_masks[level]
        actual = tuple((value & 0xC0) if value != 0xFF else 0 for value in data)
        if actual != expected:
            changed = [
                index for index, (before, after) in enumerate(zip(expected, actual))
                if before != after
            ]
            preview = ", ".join(f"{index:02X}" for index in changed[:12])
            if len(changed) > 12:
                preview += ", ..."
            raise FormatError(
                "UDG special marker positions cannot be moved safely. "
                f"Changed descriptor indices: {preview}"
            )

        # Direct SINAL rooms and retail ROOM 13/17 entrance/exit terminals
        # are fixed exactly.  This protects ordinary NPC/dialogue/event
        # locations and cross-map transfer tiles without locking unrelated
        # cells from each UG_MAP_NO 3x3 scene window.
        protected = self.protected_descriptors(level)
        changed_spots = [
            index for index, original in protected.items()
            if data[index] != original
        ]
        if changed_spots:
            preview = ", ".join(f"{index:02X}" for index in changed_spots[:12])
            if len(changed_spots) > 12:
                preview += ", ..."
            raise FormatError(
                "UDG NPC/event-linked rooms, fixed exits and scroll-sensitive "
                "rooms cannot be moved, removed or changed. "
                f"Changed descriptor indices: {preview}"
            )

    def special_anchor_cell(self, template_id: int) -> Optional[tuple[int, int]]:
        offset = self.special_anchor_offsets.get(template_id)
        if offset is None:
            return None
        # The expanded room is 20x20 C tiles inside a 64-wide x-major map.
        c_x, c_y = divmod(offset, 64)
        return c_x // 2, c_y // 2

    @staticmethod
    def descriptor_parts(value: int) -> tuple[Optional[int], int]:
        if value == 0xFF:
            return None, 0
        return value & 0x1F, value & 0xC0

    def validate_template_edit(self, template_id: int, tiles: bytes) -> None:
        if not 0 <= template_id < UDG_TEMPLATE_COUNT:
            raise ValueError("UDG template id must be 0..17")
        if len(tiles) != UDG_TEMPLATE_W * UDG_TEMPLATE_H:
            raise FormatError("UDG room template must contain exactly 100 map codes")
        if not self.scene_metadata_complete:
            raise FormatError(
                "SCENA NPC/event metadata could not be verified completely; "
                "UDG room-template editing is locked"
            )

        original_template = self.template(template_id)
        if self.template_is_fully_protected(template_id):
            if tiles != original_template:
                sources = sorted(
                    {entry.source_scene for entry in self.template_spot_entries(template_id)}
                    | {anchor.source_scene for anchor in self.template_scene_anchors(template_id)}
                )
                raise FormatError(
                    f"UDG room template {template_id:02d} is used by an NPC/event "
                    "or a scripted 3x3 scene window and is fully locked"
                    + (f" ({', '.join(sources)})" if sources else "")
                )
        else:
            changed_cells = [
                index for index in self.template_protected_cells(template_id)
                if tiles[index] != original_template[index]
            ]
            if changed_cells:
                preview = ", ".join(
                    f"({index % UDG_TEMPLATE_W},{index // UDG_TEMPLATE_W})"
                    for index in changed_cells[:12]
                )
                if len(changed_cells) > 12:
                    preview += ", ..."
                raise FormatError(
                    f"UDG room template {template_id:02d} contains event-trigger "
                    f"cells that cannot be changed: {preview}"
                )

    def replace_template(self, template_id: int, tiles: bytes) -> bytes:
        self.validate_template_edit(template_id, tiles)
        output = bytearray(self.archive2.decompressed)
        offset = self.template_offsets[template_id]
        raw = self._rowmajor_to_xmajor(tiles, UDG_TEMPLATE_W, UDG_TEMPLATE_H)
        for x in range(UDG_TEMPLATE_W):
            source = x * UDG_TEMPLATE_H
            target = offset + x * 32
            output[target:target + UDG_TEMPLATE_H] = raw[source:source + UDG_TEMPLATE_H]
        encoded = bzh_compress_literal(bytes(output))
        check2 = StandardArchive.from_bytes(encoded, self.archive2.path, 2)
        check = UndergroundDungeonData(self.exe_path, check2, self.archive3)
        if check.template(template_id) != tiles:
            raise FormatError("UDG room template round-trip failed")
        for other in range(UDG_TEMPLATE_COUNT):
            if other != template_id and check.template(other) != self.template(other):
                raise FormatError(f"UDG room template {other} changed unexpectedly")
        return encoded

    def replace_layout(self, level: int, descriptors: bytes) -> bytes:
        self.validate_layout_edit(level, descriptors)
        output = bytearray(self.archive3.decompressed)
        start = self.layout_offset + level * UDG_LAYOUT_W * UDG_LAYOUT_H
        raw = self._rowmajor_to_xmajor(descriptors, UDG_LAYOUT_W, UDG_LAYOUT_H)
        output[start:start + UDG_LAYOUT_W * UDG_LAYOUT_H] = raw
        encoded = bzh_compress_literal(bytes(output))
        check3 = StandardArchive.from_bytes(encoded, self.archive3.path, 3)
        check = UndergroundDungeonData(self.exe_path, self.archive2, check3)
        if check.layout_offset != self.layout_offset:
            raise FormatError("UDG layout edit unexpectedly relocated the table")
        if check.layout(level) != descriptors:
            raise FormatError("UDG layout round-trip failed")
        for other in range(UDG_LAYOUT_COUNT):
            if other != level and check.layout(other) != self.layout(other):
                raise FormatError(f"UDG layout level {other + 1} changed unexpectedly")
        return encoded

    def replace_layouts(self, layouts: list[bytes] | tuple[bytes, ...]) -> bytes:
        """Replace all eight UDG descriptor pages in one atomic archive build."""
        if len(layouts) != UDG_LAYOUT_COUNT:
            raise FormatError(f"Expected {UDG_LAYOUT_COUNT} UDG layouts")
        normalized = tuple(bytes(layout) for layout in layouts)
        for level, descriptors in enumerate(normalized):
            self.validate_layout_edit(level, descriptors)
        output = bytearray(self.archive3.decompressed)
        for level, descriptors in enumerate(normalized):
            start = self.layout_offset + level * UDG_LAYOUT_W * UDG_LAYOUT_H
            raw = self._rowmajor_to_xmajor(descriptors, UDG_LAYOUT_W, UDG_LAYOUT_H)
            output[start:start + UDG_LAYOUT_W * UDG_LAYOUT_H] = raw
        encoded = bzh_compress_literal(bytes(output))
        check3 = StandardArchive.from_bytes(encoded, self.archive3.path, 3)
        check = UndergroundDungeonData(self.exe_path, self.archive2, check3)
        if check.layout_offset != self.layout_offset:
            raise FormatError("UDG all-floor edit unexpectedly relocated the table")
        for level, descriptors in enumerate(normalized):
            if check.layout(level) != descriptors:
                raise FormatError(f"UDG layout level {level + 1} round-trip failed")
        return encoded

    def special_records(self) -> list[MapRecord]:
        result = [
            MapRecord(
                key=f"special:udg-template:{template_id:02d}", map_id=40 + template_id,
                map_kind="special", archive_number=2, record_index=template_id // 9,
                archive_name="M_002.BZH", tiles=bytearray(self.template(template_id)),
                editable=True,
                description=(f"지하동굴 10×10 방 모듈 {template_id:02d} "
                             "(M_002 원시 시트의 고정 영역)"),
                width=UDG_TEMPLATE_W, height=UDG_TEMPLATE_H,
                special_kind="udg_template", special_index=template_id,
            )
            for template_id in range(UDG_TEMPLATE_COUNT)
        ]
        result.extend(
            MapRecord(
                key=f"special:udg-layout:{level}", map_id=107 + level,
                map_kind="special", archive_number=3, record_index=27,
                archive_name="M_003.BZH", tiles=bytearray(self.layout(level)),
                editable=True,
                description=(f"지하동굴 미로 구조 {level + 1}/8 "
                             "(16x16 방 모듈 descriptor)"),
                width=UDG_LAYOUT_W, height=UDG_LAYOUT_H,
                special_kind="udg_layout", special_index=level,
            )
            for level in range(UDG_LAYOUT_COUNT)
        )
        return result


class TileSet:
    def __init__(self, path: Path, palette: list[tuple[int, int, int]]):
        self.path = path
        self.palette = palette
        data = bzh_decompress(path.read_bytes())
        expected = GRAPHIC_TILE_COUNT * GRAPHIC_TILE_STRIDE
        if len(data) != expected:
            raise FormatError(f"{path.name}: expected {expected} bytes, got {len(data)}")
        self.data = data
        self.tiles: list[list[int]] = []
        self.masks: list[bytes] = []
        self.rgb_tiles: list[bytes] = []
        for index in range(GRAPHIC_TILE_COUNT):
            start = index * GRAPHIC_TILE_STRIDE
            record = data[start:start + GRAPHIC_TILE_STRIDE]
            pixels = self._decode(record[:GRAPHIC_COLOR_BYTES])
            self.tiles.append(pixels)
            self.masks.append(record[GRAPHIC_COLOR_BYTES:])
            rgb = bytearray(16 * 16 * 3)
            for pixel_index, palette_index in enumerate(pixels):
                rgb[pixel_index * 3:pixel_index * 3 + 3] = bytes(self.palette[palette_index])
            self.rgb_tiles.append(bytes(rgb))

    @staticmethod
    def _decode(color_planes: bytes) -> list[int]:
        if len(color_planes) != GRAPHIC_COLOR_BYTES:
            raise FormatError("Tile color-plane record must be 128 bytes")
        pixels: list[int] = []
        # PC-98 color planes are B, R, G, I.  Their bit significance is the
        # native palette index order 1, 2, 4, 8.
        for y in range(16):
            for x in range(16):
                byte_index = y * 2 + x // 8
                bit = 7 - (x & 7)
                value = 0
                for plane in range(4):
                    value |= ((color_planes[plane * 32 + byte_index] >> bit) & 1) << plane
                pixels.append(value)
        return pixels

    def pixels_for_code(self, code: int) -> list[int]:
        # Map cells use seven graphic-index bits.  Bit 7 is an engine
        # attribute/collision flag and does not select another graphic tile.
        return self.tiles[code & 0x7F]

    def rgb_for_code(self, code: int) -> bytes:
        return self.rgb_tiles[code & 0x7F]

    def mask_for_code(self, code: int) -> bytes:
        return self.masks[code & 0x7F]


class PointerTable:
    """P_000.BZH map-code to four C-tile references.

    The table contains 45 banks of 512 bytes. Each bank has 128 entries.
    ED2MAIN copies the first word vertically in its x-major 64×64 map buffer,
    then the second word into the next x column.  The resulting screen order
    is TL, TR, BL, BR after normalizing the stored TL, BL, TR, BR bytes.
    """

    def __init__(self, path: Path):
        self.path = path
        self.data = bzh_decompress(path.read_bytes())
        if len(self.data) != 45 * 512:
            raise FormatError(f"{path.name}: expected 23040 bytes, got {len(self.data)}")

    def graphic_codes(self, ptr_no: int, map_mask: int, map_code: int) -> tuple[int, int, int, int]:
        if not 0 <= ptr_no < 45:
            raise ValueError("PTR_NO must be 0..44")
        map_code &= 0xFF
        high_bit = map_code >> 7
        if high_bit == (map_mask & 0xFF):
            index = map_code & 0x7F
        else:
            index = (map_mask - 2) & 0x7F
        offset = ptr_no * 512 + index * 4
        raw = self.data[offset:offset + 4]
        if len(raw) != 4:
            raise FormatError("P_000 entry is truncated")
        # P_000 stores the left column first: TL, BL, TR, BR.
        # The map renderer consumes row-major screen order: TL, TR, BL, BR.
        # Treating the raw bytes as row-major swaps the upper-right and
        # lower-left quarters, which visibly breaks stairs and other
        # directional metatiles.
        return raw[0], raw[2], raw[1], raw[3]



class MapProject:
    def __init__(self, root: Path):
        self.root = root
        self.map_dir = root / "MAP"
        self.exe = root / "ED2MAIN.EXE"
        if not self.map_dir.is_dir() or not self.exe.is_file():
            raise FormatError("Select a folder containing ED2MAIN.EXE and MAP")
        self.palette = exe_scene_palette(self.exe)
        self.pointer_table = PointerTable(self.map_dir / "P_000.BZH")
        self.large = LargeArchive(self.map_dir / "M_000.BZH", 0)
        self.standard = {
            number: StandardArchive(self.map_dir / f"M_{number:03d}.BZH", number)
            for number in (1, 2, 3)
        }
        self.scene_dir = root / "SCENA"
        _entries, self.exe_ordinal_names = parse_ne_export_ordinals(self.exe.read_bytes())
        self._refresh_underground()
        self.tile_paths = sorted(self.map_dir.glob("C_*.BZH"))
        self.tile_names = [path.name for path in self.tile_paths]
        self._tile_cache: dict[str, TileSet] = {}
        self.transitions: list[TransitionRecord] = []
        self.underground_transitions: list[TransitionRecord] = []
        self.auto_map_tilesets: dict[str, str] = {}
        self.auto_map_scenes: dict[str, list[str]] = {}
        self.auto_map_profiles: dict[str, dict[int, int]] = {}
        self.transitions_by_map: dict[str, list[TransitionRecord]] = {}
        self._scan_scene_transitions()
        self.links_path = root / ".ed2_scene_links.json"
        self.links = self._load_links()

    def _refresh_underground(self) -> None:
        self.underground = UndergroundDungeonData(
            self.exe, self.standard[2], self.standard[3]
        )
        if hasattr(self, "scene_dir") and hasattr(self, "exe_ordinal_names"):
            self.underground.scan_external_scene_metadata(
                self.scene_dir, self.exe_ordinal_names
            )

    def _scan_scene_transitions(self) -> None:
        if not self.scene_dir.is_dir():
            return
        counts: dict[str, Counter[int]] = defaultdict(Counter)
        scenes: dict[str, set[str]] = defaultdict(set)
        transitions: list[TransitionRecord] = []
        for path in sorted(self.scene_dir.glob("*.DLL")):
            try:
                found = extract_scene_transitions(path, self.exe_ordinal_names)
            except Exception:
                continue
            transitions.extend(found)
            for item in found:
                counts[item.map_key][item.bc_no] += 1
                scenes[item.map_key].add(item.destination_scene)
        self.transitions = transitions
        self.underground_transitions = sorted(
            (item for item in transitions if item.map_kind == "underground"),
            key=lambda item: (
                item.bc_no, item.ptr_no, item.map_mask, item.source_scene,
                item.destination_scene, item.record_segment, item.record_offset,
            ),
        )
        grouped: dict[str, list[TransitionRecord]] = defaultdict(list)
        for item in transitions:
            grouped[item.map_key].append(item)
        self.transitions_by_map = {
            key: sorted(value, key=lambda item: (
                item.source_scene, item.destination_scene, item.bc_no, item.ptr_no, item.map_mask,
                item.bgm_no, item.record_segment, item.record_offset,
            ))
            for key, value in grouped.items()
        }
        for key, counter in counts.items():
            self.auto_map_profiles[key] = dict(sorted(counter.items()))
            for bc_no, _count in counter.most_common():
                name = f"C_{bc_no:03d}.BZH"
                if name in self.tile_names:
                    self.auto_map_tilesets[key] = name
                    break
        self.auto_map_scenes = {key: sorted(value) for key, value in scenes.items()}

    def _load_links(self) -> dict:
        if self.links_path.is_file():
            try:
                value = json.loads(self.links_path.read_text(encoding="utf-8"))
                if isinstance(value, dict):
                    value.setdefault("maps", {})
                    value.setdefault("scenes", {})
                    # v0.2 stored map-level tile overrides while the tile
                    # record stride and palette order were still wrong.
                    # Ignore only those obsolete map overrides; preserve the
                    # independently maintained scene profiles.
                    if int(value.get("format_version", 0) or 0) < 4:
                        cleaned = {}
                        for key, entry in value.get("maps", {}).items():
                            if isinstance(entry, dict):
                                rest = {k: v for k, v in entry.items() if k not in {"tileset", "context"}}
                                if rest:
                                    cleaned[key] = rest
                        value["maps"] = cleaned
                    # v0.4.1 changes field keys from record numbers to MP_NUM/MAP_MASK origins.
                    value["maps"] = {k: v for k, v in value.get("maps", {}).items() if not k.startswith("large:") or k.count(":") == 2}
                    # v0.4.6 displayed UDG data with C_000/PTR 0 because G_*.DLL
                    # transitions were misclassified as ordinary maps.  Discard only
                    # obsolete UDG render overrides when upgrading to the corrected
                    # context model; unrelated user links remain intact.
                    if int(value.get("format_version", 0) or 0) < 5:
                        for key in list(value.get("maps", {})):
                            if key.startswith("special:udg-"):
                                entry = value["maps"].get(key)
                                if isinstance(entry, dict):
                                    entry.pop("tileset", None)
                                    entry.pop("context", None)
                                    if not entry:
                                        del value["maps"][key]
                    value["format_version"] = 5
                    return value
            except Exception:
                pass
        return {"format_version": 5, "maps": {}, "scenes": {}}

    def save_links(self) -> None:
        self.links["format_version"] = 5
        self.links_path.write_text(json.dumps(self.links, ensure_ascii=False, indent=2), encoding="utf-8")

    def all_maps(self) -> list[MapRecord]:
        # M_000 is not 40 independent maps. FIELD UN_PACK treats it as a
        # wrapped 10x16 chunk grid and loads a 2x2 chunk window from MP_NUM
        # and MAP_MASK. Expose only origins actually referenced by scene DLLs.
        field_origins = sorted({
            (item.map_number, item.map_mask)
            for item in self.transitions if item.map_kind == "large"
        })
        result = [self.large.get(mp_num, map_mask) for mp_num, map_mask in field_origins]
        for map_id in range(120):
            number = 1 + map_id // 40
            record = self.standard[number].get(map_id % 40, map_id)
            if record.editable:
                result.append(record)
        # The fifteen formerly "corrupt" records are two module sheets plus
        # one continuous UDG table.  Expose their actual logical structures.
        result.extend(self.underground.special_records())
        return result


    @staticmethod
    def _visual_contexts(items: list[TransitionRecord]) -> list[TransitionRecord]:
        """Return one representative per BC/PTR/MASK profile, most-used first.

        UDG layouts are entered by many G_*.DLL transitions, but the renderer only
        depends on BC_NO, PTR_NO and MAP_MASK.  Showing every duplicate transition
        obscured the real choices and previously left special data on C_000/PTR 0.
        """
        if not items:
            return []
        counts = Counter((item.bc_no, item.ptr_no, item.map_mask) for item in items)
        representatives: dict[tuple[int, int, int], TransitionRecord] = {}
        for item in sorted(items, key=lambda value: (
            value.source_scene, value.destination_scene, value.record_segment,
            value.record_offset, value.bgm_no, value.mp_pny, value.mp_pnx,
        )):
            representatives.setdefault((item.bc_no, item.ptr_no, item.map_mask), item)
        ordered = sorted(
            counts,
            key=lambda profile: (-counts[profile], profile[0], profile[1], profile[2]),
        )
        return [representatives[profile] for profile in ordered]

    def transition_contexts(self, key: str) -> list[TransitionRecord]:
        if key.startswith("special:udg-template:"):
            return self._visual_contexts(self.underground_transitions)
        items = list(self.transitions_by_map.get(key, []))
        if key.startswith("special:udg-layout:"):
            return self._visual_contexts(items)
        return items

    @staticmethod
    def transition_context_id(item: TransitionRecord) -> str:
        return (f"{item.source_scene}|{item.record_segment}:{item.record_offset:04X}|"
                f"{item.destination_scene}|{item.bc_no}|{item.ptr_no}|{item.map_mask}")

    @staticmethod
    def transition_context_label(item: TransitionRecord) -> str:
        return (f"{item.source_scene} → {item.destination_scene} | "
                f"BC {item.bc_no:03d} | PTR {item.ptr_no:02d} | MASK {item.map_mask:02X} | "
                f"BGM {item.bgm_no:03d} | 진입 {item.mp_pny},{item.mp_pnx} | {item.record_file_description}")

    def remembered_context(self, key: str) -> Optional[TransitionRecord]:
        contexts = self.transition_contexts(key)
        if not contexts:
            return None
        wanted = self.links.get("maps", {}).get(key, {}).get("context")
        if isinstance(wanted, str):
            for item in contexts:
                if self.transition_context_id(item) == wanted:
                    return item
        return contexts[0]

    def remember_context(self, key: str, item: TransitionRecord) -> None:
        self.links.setdefault("maps", {}).setdefault(key, {})["context"] = self.transition_context_id(item)
        self.save_links()

    def tileset(self, name: str) -> TileSet:
        if name not in self.tile_names:
            raise FormatError(f"Tileset not found: {name}")
        if name not in self._tile_cache:
            self._tile_cache[name] = TileSet(self.map_dir / name, self.palette)
        return self._tile_cache[name]

    def remembered_tileset(self, key: str) -> str:
        value = self.links.get("maps", {}).get(key, {}).get("tileset")
        if value in self.tile_names:
            return value
        context = self.remembered_context(key)
        if context is not None:
            candidate = f"C_{context.bc_no:03d}.BZH"
            if candidate in self.tile_names:
                return candidate
        automatic = self.auto_map_tilesets.get(key)
        if automatic in self.tile_names:
            return automatic
        # Retail UDG data is rendered through actual G-scene profiles.  When
        # SCENA is unavailable, C_002/PTR 44 is the dominant retail fallback.
        if key.startswith("special:udg-") and "C_002.BZH" in self.tile_names:
            return "C_002.BZH"
        return self.tile_names[0]

    def tileset_source(self, key: str) -> str:
        value = self.links.get("maps", {}).get(key, {}).get("tileset")
        if value in self.tile_names:
            return "사용자 지정"
        context = self.remembered_context(key)
        if context is not None:
            profiles = self.auto_map_profiles.get(key, {})
            detail = ", ".join(f"BC {bc}: {count}회" for bc, count in sorted(profiles.items()))
            return ("선택된 실제 씬 전환: " + self.transition_context_label(context)
                    + (f" / 전체 후보 {detail}" if detail else ""))
        return "기본값(씬 전환 연결 없음)"

    def remember_tileset(self, key: str, name: str) -> None:
        self.links.setdefault("maps", {}).setdefault(key, {})["tileset"] = name
        self.save_links()

    def clear_tileset_override(self, key: str) -> None:
        maps = self.links.setdefault("maps", {})
        if key in maps and "tileset" in maps[key]:
            del maps[key]["tileset"]
            if not maps[key]:
                del maps[key]
            self.save_links()

    def scenes_for_map(self, key: str) -> list[str]:
        names = set(self.auto_map_scenes.get(key, []))
        names.update(name for name, value in self.links.get("scenes", {}).items() if value.get("map_key") == key)
        return sorted(names)

    def save_map(self, record: MapRecord, tiles: bytes) -> None:
        if not record.editable:
            raise FormatError("This map record is read-only")
        if record.map_kind == "special":
            if record.special_index is None:
                raise FormatError("UDG special record index is missing")
            if record.special_kind == "udg_template":
                encoded = self.underground.replace_template(record.special_index, tiles)
                atomic_write(self.standard[2].path, encoded)
                self.standard[2] = StandardArchive(self.standard[2].path, 2)
                self._refresh_underground()
                return
            if record.special_kind == "udg_layout":
                encoded = self.underground.replace_layout(record.special_index, tiles)
                atomic_write(self.standard[3].path, encoded)
                self.standard[3] = StandardArchive(self.standard[3].path, 3)
                self._refresh_underground()
                return
            raise FormatError("Unknown UDG special record type")
        if record.map_kind == "large":
            if record.field_mp is None or record.field_mask is None:
                raise FormatError("Field origin is missing")
            encoded = self.large.replace(record.field_mp, record.field_mask, tiles)
            atomic_write(self.large.path, encoded)
            self.large = LargeArchive(self.large.path, 0)
        else:
            archive = self.standard[record.archive_number]
            encoded = archive.replace(record.record_index, tiles)
            if record.archive_number == 3:
                check = StandardArchive.from_bytes(encoded, archive.path, 3)
                new_layout_offset = check.offsets[27] + self.underground.layout_prefix_length
                old_table = self.underground.layout_table
                candidate = check.decompressed[
                    new_layout_offset:new_layout_offset + len(old_table)
                ]
                if candidate != old_table:
                    raise FormatError("M_003 save would alter the underground layout table")
                patched_exe = self.underground.patched_exe(new_layout_offset)
                old_map = archive.path.read_bytes()
                old_exe = self.exe.read_bytes()
                try:
                    atomic_write(archive.path, encoded)
                    if new_layout_offset != self.underground.layout_offset:
                        atomic_write(self.exe, patched_exe)
                except Exception:
                    atomic_write(archive.path, old_map)
                    atomic_write(self.exe, old_exe)
                    raise
            else:
                atomic_write(archive.path, encoded)
            self.standard[record.archive_number] = StandardArchive(
                archive.path, record.archive_number
            )
            if record.archive_number in (2, 3):
                self._refresh_underground()

    def save_udg_layouts(self, layouts: list[bytes] | tuple[bytes, ...]) -> None:
        """Save all eight underground floors with one backup and one write."""
        encoded = self.underground.replace_layouts(layouts)
        path = self.standard[3].path
        atomic_write(path, encoded)
        self.standard[3] = StandardArchive(path, 3)
        self._refresh_underground()

    def restore(self, record: MapRecord) -> None:
        path = self.map_dir / record.archive_name
        old_map = path.read_bytes()
        old_exe = self.exe.read_bytes()
        try:
            selective_restore(path, JOURNAL_COMPONENT)
            if record.archive_number == 3:
                try:
                    selective_restore(self.exe, JOURNAL_COMPONENT)
                except FileNotFoundError:
                    pass
            if record.map_kind == "large":
                self.large = LargeArchive(path, 0)
            else:
                self.standard[record.archive_number] = StandardArchive(path, record.archive_number)
                if record.archive_number in (2, 3):
                    self._refresh_underground()
        except Exception:
            # Restore the pre-attempt state without creating another journal.
            atomic_write(path, old_map, journal=False)
            atomic_write(self.exe, old_exe, journal=False)
            if record.map_kind == "large":
                self.large = LargeArchive(path, 0)
            else:
                self.standard[record.archive_number] = StandardArchive(path, record.archive_number)
                if record.archive_number in (2, 3):
                    self._refresh_underground()
            raise

    def validate(self) -> dict:
        errors: list[str] = []
        warnings: list[str] = []
        large_ok = 0
        standard_ok = 0
        special = 0
        for record in self.all_maps():
            if record.editable:
                if record.map_kind == "large":
                    large_ok += 1
                    try:
                        if record.field_mp is None or record.field_mask is None:
                            raise FormatError("Field origin is missing")
                        fresh = self.large.get(record.field_mp, record.field_mask)
                        if bytes(fresh.tiles or b"") != bytes(record.tiles or b""):
                            errors.append(f"{record.key}: field chunk assembly failed")
                        for script, _base in record.change_scripts:
                            parse_map_change_script(script)
                    except Exception as exc:
                        errors.append(f"{record.key}: {exc}")
                elif record.map_kind == "standard":
                    standard_ok += 1
                    archive = self.standard[record.archive_number]
                    storage, _used, term = inner_rle_decode(
                        archive.records[record.record_index], MAP_CELLS + 1
                    )
                    if not term or len(storage) != MAP_CELLS:
                        errors.append(f"{record.key}: storage RLE decode failed")
                    elif screen_to_storage_map(
                        bytes(record.tiles or b""), MAP_W, MAP_H
                    ) != storage:
                        errors.append(f"{record.key}: standard-map screen/storage conversion failed")
                elif record.special_kind == "udg_template":
                    special += 1
                    if len(record.tiles or b"") != UDG_TEMPLATE_W * UDG_TEMPLATE_H:
                        errors.append(f"{record.key}: UDG template size mismatch")
                    elif bytes(record.tiles or b"") != self.underground.template(record.special_index or 0):
                        errors.append(f"{record.key}: UDG template decode mismatch")
                elif record.special_kind == "udg_layout":
                    special += 1
                    if len(record.tiles or b"") != UDG_LAYOUT_W * UDG_LAYOUT_H:
                        errors.append(f"{record.key}: UDG layout size mismatch")
                    else:
                        try:
                            self.underground.validate_layout_edit(
                                record.special_index or 0, bytes(record.tiles or b"")
                            )
                        except Exception as exc:
                            errors.append(f"{record.key}: {exc}")
            else:
                special += 1
        for name in self.tile_names:
            try:
                self.tileset(name)
            except Exception as exc:
                errors.append(f"{name}: {exc}")
        if special:
            warnings.append(
                f"{special} underground room/layout records are editable; "
                "special markers, direct SINAL NPC/event rooms and progression gates remain locked"
            )
        warnings.extend(self.underground.chest_scan_warnings)
        warnings.extend(self.underground.spot_scan_warnings)
        warnings.extend(self.underground.scene_reference_warnings)
        warnings.extend(self.underground.progression_gate_warnings)
        unresolved = sorted({item.bc_no for item in self.transitions if f"C_{item.bc_no:03d}.BZH" not in self.tile_names})
        if unresolved:
            warnings.append("Scene transitions reference missing tilesets: " + ", ".join(map(str, unresolved)))
        return {
            "ok": not errors,
            "field_windows": large_ok,
            "standard_maps": standard_ok,
            "special_records": special,
            "tilesets": len(self.tile_names),
            "scene_transitions": len(self.transitions),
            "auto_linked_maps": len(self.auto_map_tilesets),
            "palette": self.palette,
            "errors": errors,
            "warnings": warnings,
        }
