#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, struct, tempfile
from pathlib import Path

VERSION='0.5.37'
HARDSTOP=bytes.fromhex('B4 01 CD 40 90')   # MOV AH,01h / INT 40h / NOP

# Every confirmed direct immediate BGM fade/transition command in the supplied
# Korean DOS ED2 game binaries.  The original subcommand varies (0401/0402/0403),
# but all are replaced with the same raw-VGM-safe immediate hard stop.
#
# relpath, NE segment, offset, original bytes, description
TARGETS=(
    ('ED2MAIN.EXE',      86, 0x23D8, bytes.fromhex('B8 03 04 CD 40'), 'EXIT_PROG2 game-exit transition'),
    ('ED2MAIN.EXE',      86, 0x2429, bytes.fromhex('B8 01 04 CD 40'), 'internal event fade #1'),
    ('ED2MAIN.EXE',      86, 0x3592, bytes.fromhex('B8 01 04 CD 40'), 'internal event fade #2'),
    ('ED2MAIN.EXE',      86, 0x383A, bytes.fromhex('B8 03 04 CD 40'), 'LOAD_BGM_SET common different-BGM transition'),
    ('ED2MAIN.EXE',      86, 0x4A7C, bytes.fromhex('B8 01 04 CD 40'), 'Settings BGM OFF'),
    ('MON/M_501.DLL',     3, 0x041E, bytes.fromhex('B8 01 04 CD 40'), 'monster/event fade'),
    ('SCENA/T_543.DLL',   3, 0x07FD, bytes.fromhex('B8 01 04 CD 40'), 'Kubera-area sleep fade'),
    ('SCENA/T_240.DLL',   3, 0x0852, bytes.fromhex('B8 01 04 CD 40'), 'Siel-area sleep/inn fade'),
    ('SCENA/C_600.DLL',   3, 0x0473, bytes.fromhex('B8 02 04 CD 40'), 'Grostos cannon transition'),
    ('SCENA/C_203.DLL',   3, 0x0A52, bytes.fromhex('B8 03 04 CD 40'), 'C_203 event transition'),
)


# Chapter transition routines are deliberately NOT hard-stopped.  The 0401 call
# is part of the transition sequence immediately before SIN_CHAP/TITLE_DATA are
# rewritten and control jumps to the next chapter.  v0.5.36 treated these five
# sites as generic fades and could hang during chapter changes (observed 2->3).
CHAPTER_TRANSITIONS=(
    ('SCENA/V_000.DLL', 3, 0x04B9, bytes.fromhex('B8 01 04 CD 40'), 'prologue -> chapter 1'),
    ('SCENA/V_100.DLL', 3, 0x040E, bytes.fromhex('B8 01 04 CD 40'), 'chapter 1 -> chapter 2'),
    ('SCENA/V_200.DLL', 3, 0x0779, bytes.fromhex('B8 01 04 CD 40'), 'chapter 2 -> chapter 3'),
    ('SCENA/V_300.DLL', 3, 0x04B0, bytes.fromhex('B8 01 04 CD 40'), 'chapter 3 -> chapter 4'),
    ('SCENA/V_400.DLL', 3, 0x1384, bytes.fromhex('B8 01 04 CD 40'), 'chapter 4 -> final chapter'),
)

# ED2END.EXE is absent from the clean stock archive used for the base analysis,
# but is present in newer all-in-one/localized builds.  When it exists, it carries
# the same BGM control code at the same NE86 offsets and must be patched too.
OPTIONAL_TARGETS=(
    ('ED2END.EXE',       86, 0x23D8, bytes.fromhex('B8 03 04 CD 40'), 'ED2END EXIT_PROG2 game-exit transition'),
    ('ED2END.EXE',       86, 0x2429, bytes.fromhex('B8 01 04 CD 40'), 'ED2END internal event fade #1'),
    ('ED2END.EXE',       86, 0x3592, bytes.fromhex('B8 01 04 CD 40'), 'ED2END internal event fade #2'),
    ('ED2END.EXE',       86, 0x383A, bytes.fromhex('B8 03 04 CD 40'), 'ED2END LOAD_BGM_SET common transition'),
    ('ED2END.EXE',       86, 0x4A7C, bytes.fromhex('B8 01 04 CD 40'), 'ED2END Settings/option fade'),
)


def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.v0532.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def find_ci(parent:Path,name:str,directory=False)->Path:
    p=parent/name
    if p.exists() and p.is_dir()==directory:return p
    for q in parent.iterdir():
        if q.name.lower()==name.lower() and q.is_dir()==directory:return q
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')


def resolve_rel(root:Path,rel:str)->Path:
    p=root
    parts=Path(rel).parts
    for i,part in enumerate(parts):
        p=find_ci(p,part,directory=(i<len(parts)-1))
    return p

def resolve_rel_optional(root:Path,rel:str):
    try:return resolve_rel(root,rel)
    except FileNotFoundError:return None


def looks(root:Path)->bool:
    try:
        find_ci(root,'ED2MAIN.EXE'); find_ci(root,'GKEY.EXE')
        find_ci(root,'BGM',True); find_ci(root,'SCENA',True); find_ci(root,'MON',True)
        return True
    except Exception:return False


def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r):raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen:continue
            seen.add(k)
            if looks(r):return r
    raise FileNotFoundError('ED2MAIN.EXE / GKEY.EXE / BGM / SCENA / MON이 함께 있는 게임 폴더를 찾지 못했습니다.')


def seg_info(b:bytes,index:int):
    if len(b)<0x40 or b[:2]!=b'MZ':raise RuntimeError('MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE':raise RuntimeError('16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c)
    if not 1<=index<=count:raise RuntimeError(f'NE segment {index}가 없습니다.')
    table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    sector,length,flags,alloc=struct.unpack_from('<HHHH',b,table+(index-1)*8)
    base=sector<<shift; seglen=65536 if length==0 else length
    return base,seglen


def classify(path:Path,seg:int,off:int,orig:bytes):
    b=path.read_bytes(); base,seglen=seg_info(b,seg)
    if off+5>seglen:raise RuntimeError(f'{path.name} NE{seg}:{off:04X}가 segment 범위를 벗어납니다.')
    fo=base+off; cur=b[fo:fo+5]
    if cur==orig:return 'original',b,fo
    if cur==HARDSTOP:return 'patched',b,fo
    return 'unsupported',b,fo


def preflight(root=None):
    r=auto_root(root); out=[]
    for rel,seg,off,orig,desc in TARGETS:
        p=resolve_rel(r,rel); state,b,fo=classify(p,seg,off,orig)
        if state=='unsupported':
            got=b[fo:fo+5].hex(' ')
            raise RuntimeError(f'{rel} BGM 제어 코드가 지원 형태가 아닙니다. NE{seg}:{off:04X} file=0x{fo:X}: {got}')
        out.append((rel,p,seg,off,orig,fo,state,desc))
    for rel,seg,off,orig,desc in OPTIONAL_TARGETS:
        p=resolve_rel_optional(r,rel)
        if p is None:continue
        state,b,fo=classify(p,seg,off,orig)
        if state=='unsupported':
            got=b[fo:fo+5].hex(' ')
            raise RuntimeError(f'{rel} BGM 제어 코드가 지원 형태가 아닙니다. NE{seg}:{off:04X} file=0x{fo:X}: {got}')
        out.append((rel,p,seg,off,orig,fo,state,desc))
    return r,out


def preflight_chapter_transitions(root:Path):
    out=[]
    for rel,seg,off,orig,desc in CHAPTER_TRANSITIONS:
        p=resolve_rel(root,rel); state,b,fo=classify(p,seg,off,orig)
        if state=='unsupported':
            got=b[fo:fo+5].hex(' ')
            raise RuntimeError(f'{rel} chapter transition code가 지원 형태가 아닙니다. NE{seg}:{off:04X} file=0x{fo:X}: {got}')
        out.append((rel,p,seg,off,orig,fo,state,desc))
    return out


def allowed_transition_hits(root:Path):
    return {(rel.replace('\\','/').lower(), fo, orig[1]) for rel,p,seg,off,orig,fo,state,desc in preflight_chapter_transitions(root)}


def iter_game_binaries(root:Path):
    """Yield only binaries that belong to the live ED2 game tree.

    ED2 executable modules relevant to this audit are the root-level EXE/DLL
    files plus the direct DLL children of SCENA and MON.  Restrict the audit to
    those live module locations instead of recursively inspecting unrelated
    directories under the game root.
    """
    seen=set()
    candidates=[]
    for p in root.iterdir():
        if p.is_file() and p.suffix.upper() in ('.EXE','.DLL'):
            candidates.append(p)
    for dirname in ('SCENA','MON'):
        try:
            d=find_ci(root,dirname,True)
        except FileNotFoundError:
            continue
        for p in d.iterdir():
            if p.is_file() and p.suffix.upper() in ('.EXE','.DLL'):
                candidates.append(p)
    for p in sorted(candidates,key=lambda q:str(q.relative_to(root)).lower()):
        key=str(p.resolve()).lower()
        if key in seen:continue
        seen.add(key)
        yield p


def scan_immediate_04xx(root:Path):
    """Audit exact MOV AX,04xx / INT40 sequences in live game EXE/DLL files."""
    hits=[]
    for p in iter_game_binaries(root):
        b=p.read_bytes()
        for i in range(len(b)-4):
            if b[i]==0xB8 and b[i+2]==0x04 and b[i+3:i+5]==b'\xCD\x40':
                hits.append((str(p.relative_to(root)).replace('\\','/'),i,b[i+1]))
    return hits


def apply(root=None):
    r,items=preflight(root); chapter=preflight_chapter_transitions(r); changed=[]; migrated=[]
    try:
        # First migrate v0.5.36 chapter hard-stops back to the stock 0401
        # transition service.  These calls are part of chapter state changes.
        for rel,p,seg,off,orig,fo,state,desc in chapter:
            if state=='original':continue
            b=bytearray(p.read_bytes()); b[fo:fo+5]=orig; atomic(p,bytes(b)); migrated.append((p,fo,orig))
        for rel,p,seg,off,orig,fo,state,desc in items:
            if state=='patched':continue
            b=bytearray(p.read_bytes()); b[fo:fo+5]=HARDSTOP; atomic(p,bytes(b)); changed.append((p,fo,orig))
        _,verify=preflight(r)
        bad=[x for x in verify if x[6]!='patched']
        if bad:raise RuntimeError('적용 후 일부 일반 BGM fade/transition site가 hard-stop 상태가 아닙니다.')
        chapter_verify=preflight_chapter_transitions(r)
        bad_ch=[x for x in chapter_verify if x[6]!='original']
        if bad_ch:raise RuntimeError('적용 후 일부 장 전환 site가 원본 AX=0401 상태가 아닙니다.')
        allowed=allowed_transition_hits(r)
        leftovers=[x for x in scan_immediate_04xx(r) if x[2] in (1,2,3) and (x[0].lower(),x[1],x[2]) not in allowed]
        if leftovers:
            msg='; '.join(f'{rel}@0x{fo:X}=04{sub:02X}' for rel,fo,sub in leftovers[:12])
            raise RuntimeError('미처리 일반 BGM fade/transition 명령이 남아 있습니다: '+msg)
    except Exception:
        for p,fo,orig in reversed(changed):
            try:
                b=bytearray(p.read_bytes())
                if b[fo:fo+5]==HARDSTOP:b[fo:fo+5]=orig; atomic(p,bytes(b))
            except Exception:pass
        for p,fo,orig in reversed(migrated):
            try:
                b=bytearray(p.read_bytes())
                if b[fo:fo+5]==orig:b[fo:fo+5]=HARDSTOP; atomic(p,bytes(b))
            except Exception:pass
        raise
    print(f'v{VERSION} global BGM hard-stop audit 적용 완료.')
    print(f'- 일반 hard-stop 관리 site: {len(items)}곳')
    print(f'- 이번 실행에서 새 hard-stop: {len(changed)}곳')
    print(f'- 장 전환 원본 0401 보호: {len(chapter)}곳 / v0.5.36 hard-stop에서 복구 {len(migrated)}곳')
    print('- V_000~V_400 장 전환 5곳을 제외한 직접 0401/0402/0403 잔존 검사: 0곳')


def restore(root=None):
    r,items=preflight(root); chapter=preflight_chapter_transitions(r); changed=0
    for rel,p,seg,off,orig,fo,state,desc in items:
        if state=='original':continue
        b=bytearray(p.read_bytes());b[fo:fo+5]=orig;atomic(p,bytes(b));changed+=1
    for rel,p,seg,off,orig,fo,state,desc in chapter:
        if state=='original':continue
        b=bytearray(p.read_bytes());b[fo:fo+5]=orig;atomic(p,bytes(b));changed+=1
    print(f'v{VERSION} BGM 제어 대상 {changed}곳을 원래 0401/0402/0403 명령으로 복원했습니다.')


def status(root=None):
    r,items=preflight(root); chapter=preflight_chapter_transitions(r)
    print(f'=== v{VERSION} global BGM hard-stop audit ===')
    patched=0
    for rel,p,seg,off,orig,fo,state,desc in items:
        patched += state=='patched'
        print(f'- {rel} NE{seg}:{off:04X} file=0x{fo:X}: {state} ({desc})')
    print('--- protected chapter transitions: stock AX=0401 required ---')
    for rel,p,seg,off,orig,fo,state,desc in chapter:
        print(f'- {rel} NE{seg}:{off:04X} file=0x{fo:X}: {state} ({desc})')
    allowed=allowed_transition_hits(r)
    leftovers=[x for x in scan_immediate_04xx(r) if x[2] in (1,2,3) and (x[0].lower(),x[1],x[2]) not in allowed]
    print(f'- managed hard-stop sites: {patched}/{len(items)}')
    print(f'- protected chapter-transition sites: {sum(x[6]=="original" for x in chapter)}/{len(chapter)}')
    print(f'- remaining unapproved direct AX=0401/0402/0403 sites: {len(leftovers)}')
    for rel,fo,sub in leftovers:
        print(f'  * {rel} file=0x{fo:X}: AX=040{sub:02X} / INT40')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['apply','restore','status']);ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args();root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:
        print();print(f'[ERROR] {type(e).__name__}: {e}');print('패치를 중단했습니다. 위 오류를 그대로 알려 주세요.');return 1
if __name__=='__main__':raise SystemExit(main())
