#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import os
import struct
import sys
from collections import OrderedDict
from pathlib import Path

APP_NAME = "ED2 Raw OPL Converter"
VERSION = "0.1.5"

VGM_SAMPLE_RATE = 44100
YM3812_CLOCK = 3579545
PHYSICAL_HZ = 128
TPB = 16
BPM = 240
CARRIER_MAGIC = 0x5647
STREAM_START = 0x006B
MAX_MUSIC_BUFFER = 130000


class FormatError(RuntimeError):
    pass


# YM3812 operator layout used by the TL (0x40) register bank.
# Gain is applied only to operators that contribute directly to the output.
MOD_SLOT_BY_CH = (0, 1, 2, 8, 9, 10, 16, 17, 18)
CAR_SLOT_BY_CH = (3, 4, 5, 11, 12, 13, 19, 20, 21)
VALID_SLOTS = frozenset(MOD_SLOT_BY_CH + CAR_SLOT_BY_CH)
SLOT_INFO = {slot: (ch, False) for ch, slot in enumerate(MOD_SLOT_BY_CH)}
SLOT_INFO.update({slot: (ch, True) for ch, slot in enumerate(CAR_SLOT_BY_CH)})
TL_STEP_DB = 0.75


def quantize_gain_db(gain_db: float) -> tuple[int, float]:
    if not math.isfinite(gain_db):
        raise ValueError("Gain must be a finite dB value")
    # Keep the UI/CLI range deliberately sane. The chip itself can only move
    # 0..63 TL steps, i.e. 47.25 dB of attenuation. Positive gain may saturate
    # at TL=0 when the source has no remaining headroom.
    if gain_db < -48.0 or gain_db > 24.0:
        raise ValueError("Gain must be between -48.0 dB and +24.0 dB")
    steps_f = gain_db / TL_STEP_DB
    steps = int(math.floor(steps_f + 0.5)) if steps_f >= 0 else -int(math.floor(-steps_f + 0.5))
    return steps, steps * TL_STEP_DB


def _slot_is_output(slot: int, connections: list[int], rhythm: bool) -> bool:
    info = SLOT_INFO.get(slot)
    if info is None:
        return False
    ch, is_carrier = info
    if is_carrier:
        return True
    # In additive mode both melodic operators reach the output. In OPL rhythm
    # mode the HH (ch7 mod) and TOM (ch8 mod) operators are independent audible
    # percussion voices and therefore need the same gain treatment.
    if rhythm and ch in (7, 8):
        return True
    return bool(connections[ch] & 1)


def _gain_tl_value(value: int, steps: int) -> tuple[int, bool]:
    ksl = value & 0xC0
    tl = value & 0x3F
    wanted = tl - steps
    new_tl = max(0, min(63, wanted))
    return ksl | new_tl, new_tl != wanted


def apply_opl_gain(
    writes: list[tuple[int, int, int, int]], gain_db: float
) -> tuple[list[tuple[int, int, int, int]], dict[str, object]]:
    steps, effective_db = quantize_gain_db(gain_db)
    if steps == 0:
        return list(writes), {
            "gain_db_requested": gain_db,
            "gain_db_effective": effective_db,
            "gain_tl_steps": steps,
            "gain_adjusted_tl_writes": 0,
            "gain_synthetic_tl_writes": 0,
            "gain_saturated_tl_writes": 0,
        }

    connections = [0] * 9
    rhythm = False
    last_tl: dict[int, int] = {}
    out: list[tuple[int, int, int, int]] = []
    adjusted = 0
    synthetic = 0
    saturated = 0

    def rendered(slot: int, raw_value: int) -> int:
        nonlocal saturated
        if _slot_is_output(slot, connections, rhythm):
            value, sat = _gain_tl_value(raw_value, steps)
            saturated += int(sat)
            return value
        return raw_value

    def emit_role_refresh(sample: int, pos: int, slots: list[int], before_roles: dict[int, bool]) -> None:
        nonlocal synthetic
        for slot in slots:
            if slot not in last_tl:
                continue
            after = _slot_is_output(slot, connections, rhythm)
            if after == before_roles.get(slot, after):
                continue
            out.append((sample, 0x40 + slot, rendered(slot, last_tl[slot]), pos))
            synthetic += 1

    for sample, reg, value, pos in writes:
        # TL write: preserve KSL and move only the 6-bit attenuation field.
        if 0x40 <= reg <= 0x55 and (reg - 0x40) in VALID_SLOTS:
            slot = reg - 0x40
            last_tl[slot] = value
            if _slot_is_output(slot, connections, rhythm):
                new_value, sat = _gain_tl_value(value, steps)
                adjusted += 1
                saturated += int(sat)
                out.append((sample, reg, new_value, pos))
            else:
                out.append((sample, reg, value, pos))
            continue

        # Connection change can make the modulator audible (additive) or turn
        # it back into a timbre-only modulator. Re-emit its original TL after
        # C0 so the selected gain follows the new signal path immediately.
        if 0xC0 <= reg <= 0xC8:
            ch = reg - 0xC0
            mod_slot = MOD_SLOT_BY_CH[ch]
            before = {mod_slot: _slot_is_output(mod_slot, connections, rhythm)}
            out.append((sample, reg, value, pos))
            connections[ch] = value & 1
            emit_role_refresh(sample, pos, [mod_slot], before)
            continue

        # Rhythm enable/disable changes ch7/ch8 modulators into/out of the
        # independently audible HH/TOM voices. Refresh those TL values.
        if reg == 0xBD:
            slots = [MOD_SLOT_BY_CH[7], MOD_SLOT_BY_CH[8]]
            before = {slot: _slot_is_output(slot, connections, rhythm) for slot in slots}
            out.append((sample, reg, value, pos))
            rhythm = bool(value & 0x20)
            emit_role_refresh(sample, pos, slots, before)
            continue

        out.append((sample, reg, value, pos))

    return out, {
        "gain_db_requested": gain_db,
        "gain_db_effective": effective_db,
        "gain_tl_steps": steps,
        "gain_adjusted_tl_writes": adjusted,
        "gain_synthetic_tl_writes": synthetic,
        "gain_saturated_tl_writes": saturated,
    }


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def read_vgm_source(path: Path) -> bytes:
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    if raw[:4] != b"Vgm ":
        raise FormatError(f"VGM signature not found: {path.name}")
    return raw


def parse_vgm(path: Path) -> dict[str, object]:
    data = read_vgm_source(path)
    if len(data) < 0x80:
        raise FormatError(f"VGM is too short: {path.name}")

    version = u32(data, 0x08)
    ym3812_clock = u32(data, 0x50) & 0x3FFFFFFF
    if ym3812_clock != YM3812_CLOCK:
        raise FormatError(
            f"{path.name}: YM3812 clock is {ym3812_clock}; "
            f"this engine format expects {YM3812_CLOCK} Hz"
        )

    data_rel = u32(data, 0x34) if version >= 0x150 else 0
    pos = 0x34 + data_rel if data_rel else 0x40
    total_header = u32(data, 0x18)
    loop_rel = u32(data, 0x1C)
    loop_abs = 0x1C + loop_rel if loop_rel else None

    sample = 0
    writes: list[tuple[int, int, int, int]] = []
    loop_sample: int | None = None
    commands: set[int] = set()
    boundaries: set[int] = set()
    end_sample: int | None = None

    while pos < len(data):
        boundaries.add(pos)
        if loop_abs is not None and pos == loop_abs:
            loop_sample = sample

        cmd_pos = pos
        cmd = data[pos]
        commands.add(cmd)
        pos += 1

        if cmd == 0x5A:  # YM3812 write
            if pos + 2 > len(data):
                raise FormatError(f"{path.name}: truncated YM3812 write at 0x{cmd_pos:X}")
            reg, value = data[pos], data[pos + 1]
            pos += 2
            writes.append((sample, reg, value, cmd_pos))
        elif cmd == 0x61:
            if pos + 2 > len(data):
                raise FormatError(f"{path.name}: truncated wait at 0x{cmd_pos:X}")
            sample += u16(data, pos)
            pos += 2
        elif cmd == 0x62:
            sample += 735
        elif cmd == 0x63:
            sample += 882
        elif 0x70 <= cmd <= 0x7F:
            sample += (cmd & 0x0F) + 1
        elif cmd == 0x66:
            end_sample = sample
            break
        else:
            raise FormatError(
                f"{path.name}: unsupported VGM command 0x{cmd:02X} at 0x{cmd_pos:X}. "
                "The current ED2 raw-OPL engine accepts YM3812 writes and wait commands only."
            )

    if end_sample is None:
        raise FormatError(f"{path.name}: VGM end command 0x66 was not found")
    if total_header and total_header != end_sample:
        raise FormatError(
            f"{path.name}: header total samples {total_header} != parsed {end_sample}"
        )
    if loop_abs is not None:
        if loop_abs not in boundaries:
            raise FormatError(f"{path.name}: loop offset is not on a command boundary")
        if loop_sample is None:
            raise FormatError(f"{path.name}: VGM loop point could not be resolved")

    return {
        "data": data,
        "version": version,
        "clock": ym3812_clock,
        "writes": writes,
        "loop_abs": loop_abs,
        "loop_sample": loop_sample,
        "end_sample": end_sample,
        "commands": sorted(commands),
    }


def tick_floor(samples: int) -> int:
    return (samples * PHYSICAL_HZ) // VGM_SAMPLE_RATE


def _is_audible_start_write(reg: int, value: int) -> bool:
    """Return True for a write that can begin an audible OPL voice."""
    if 0xB0 <= reg <= 0xB8:
        return bool(value & 0x20)
    if reg == 0xBD:
        return bool(value & 0x1F)
    return False


def _startup_preroll_plan(vgm: dict[str, object]) -> dict[str, object]:
    """Move the first audible tick-0 trigger behind a silent init IRQ."""
    writes = vgm["writes"]
    assert isinstance(writes, list)

    tick0_indices = [
        i for i, (sample, _reg, _value, _pos) in enumerate(writes)
        if tick_floor(sample) == 0
    ]
    if not tick0_indices:
        return {
            "enabled": False,
            "split_index": None,
            "preinit_writes": 0,
            "audible_tick0_writes": 0,
            "reason": "no_tick0_writes",
        }

    tick0_samples = {writes[i][0] for i in tick0_indices}
    if tick0_samples != {0}:
        return {
            "enabled": False,
            "split_index": None,
            "preinit_writes": len(tick0_indices),
            "audible_tick0_writes": 0,
            "reason": "tick0_contains_real_subtick_waits",
        }

    loop_sample = vgm["loop_sample"]
    if isinstance(loop_sample, int) and tick_floor(loop_sample) == 0:
        return {
            "enabled": False,
            "split_index": None,
            "preinit_writes": 0,
            "audible_tick0_writes": len(tick0_indices),
            "reason": "loop_begins_in_tick0",
        }

    first_trigger = None
    for i in tick0_indices:
        _sample, reg, value, _pos = writes[i]
        if _is_audible_start_write(reg, value):
            first_trigger = i
            break

    if first_trigger is None:
        return {
            "enabled": False,
            "split_index": None,
            "preinit_writes": len(tick0_indices),
            "audible_tick0_writes": 0,
            "reason": "no_audible_trigger_in_tick0",
        }

    first_tick0 = tick0_indices[0]
    preinit = first_trigger - first_tick0
    tail = tick0_indices[-1] - first_trigger + 1
    if preinit <= 0:
        return {
            "enabled": False,
            "split_index": None,
            "preinit_writes": 0,
            "audible_tick0_writes": len(tick0_indices),
            "reason": "first_tick0_write_is_audible",
        }

    return {
        "enabled": True,
        "split_index": first_trigger,
        "preinit_writes": preinit,
        "audible_tick0_writes": tail,
        "reason": "silent_init_then_audible_start",
    }


def compile_compact(vgm: dict[str, object]) -> tuple[bytes, int, dict[str, object]]:
    writes = vgm["writes"]
    assert isinstance(writes, list)

    plan = _startup_preroll_plan(vgm)
    preroll = bool(plan["enabled"])
    split_index = plan["split_index"]

    groups: OrderedDict[int, list[tuple[int, int, int, int]]] = OrderedDict()
    for i, (sample, reg, value, pos) in enumerate(writes):
        tick = tick_floor(sample)
        if preroll and isinstance(split_index, int) and i >= split_index:
            tick += 1
        groups.setdefault(tick, []).append((reg, value, pos, sample))

    loop_sample = vgm["loop_sample"]
    loop_abs = vgm["loop_abs"]
    end_sample = vgm["end_sample"]
    assert isinstance(end_sample, int)

    loop_tick = tick_floor(loop_sample) if isinstance(loop_sample, int) else None
    if preroll and loop_tick is not None:
        loop_tick += 1
    end_tick = tick_floor(end_sample) + (1 if preroll else 0)

    ticks = set(groups)
    if loop_tick is not None:
        ticks.add(loop_tick)

    logical: list[tuple[int, str, list[tuple[int, int, int, int]]]] = []
    for tick in sorted(ticks):
        pairs = groups.get(tick, [])
        if loop_tick is not None and tick == loop_tick:
            assert isinstance(loop_abs, int)
            pre = [x for x in pairs if x[2] < loop_abs]
            post = [x for x in pairs if x[2] >= loop_abs]
            for n in range(0, len(pre), 254):
                logical.append((tick, "writes", pre[n:n + 254]))
            logical.append((tick, "boundary", []))
            for n in range(0, len(post), 254):
                logical.append((tick, "writes", post[n:n + 254]))
        else:
            for n in range(0, len(pairs), 254):
                logical.append((tick, "writes", pairs[n:n + 254]))

    logical.append((end_tick, "end", []))

    out = bytearray()
    prev = 0
    loop_resume = 0
    max_count = 0
    filler_records = 0
    record_count = 0

    for tick, kind, pairs in logical:
        gap = tick - prev
        while gap > 127:
            out += bytes((127, 0))
            record_count += 1
            prev += 127
            gap = tick - prev
            filler_records += 1

        out.append(gap)
        if kind == "boundary":
            out.append(0)
            loop_resume = len(out)
        elif kind == "end":
            out.append(255)
        else:
            max_count = max(max_count, len(pairs))
            out.append(len(pairs))
            for reg, value, _pos, _sample in pairs:
                out += bytes((reg, value))
        record_count += 1
        prev = tick

    if loop_resume > 0xFFFF:
        raise FormatError("Loop resume offset exceeds uint16 range")

    return bytes(out), loop_resume, {
        "loop_tick": loop_tick,
        "end_tick": end_tick,
        "max_writes_per_record": max_count,
        "wait_filler_records": filler_records,
        "record_count": record_count,
        "startup_preroll_enabled": preroll,
        "startup_preroll_ticks": 1 if preroll else 0,
        "startup_preinit_writes": plan["preinit_writes"],
        "startup_audible_tick0_writes": plan["audible_tick0_writes"],
        "startup_preroll_reason": plan["reason"],
        "startup_split_write_index": split_index,
    }

def decode_stream(stream: bytes, start: int = 0) -> tuple[list[tuple[int, int, int]], int, int, int]:
    pos = start
    tick = 0
    writes: list[tuple[int, int, int]] = []
    records = 0
    while True:
        if pos + 2 > len(stream):
            raise FormatError("Compact stream is truncated")
        delta = stream[pos]
        count = stream[pos + 1]
        pos += 2
        tick += delta
        records += 1
        if count == 255:
            return writes, tick, pos, records
        need = count * 2
        if pos + need > len(stream):
            raise FormatError("Compact OPL pair list is truncated")
        for _ in range(count):
            writes.append((tick, stream[pos], stream[pos + 1]))
            pos += 2


def build_carrier(vgm_path: Path, gain_db: float = 0.0) -> tuple[bytes, bytes, dict[str, object]]:
    vgm = parse_vgm(vgm_path)
    original_writes = vgm["writes"]
    assert isinstance(original_writes, list)
    gained_writes, gain_meta = apply_opl_gain(original_writes, gain_db)
    effective_vgm = dict(vgm)
    effective_vgm["writes"] = gained_writes
    stream, loop_resume, compact_meta = compile_compact(effective_vgm)

    loop_field = loop_resume + 1
    if not 1 <= loop_field <= 0xFFFF:
        raise FormatError(f"{vgm_path.name}: loop metadata field overflow")

    end_sample = vgm["end_sample"]
    loop_abs = vgm["loop_abs"]
    assert isinstance(end_sample, int)

    header = bytearray(97)
    header[0] = 9

    if loop_abs is None:
        carrier_ticks = max(1, min(65535, (end_sample * 64 + 44099) // 44100 + (1 if compact_meta["startup_preroll_enabled"] else 0)))
    else:
        carrier_ticks = 65535

    struct.pack_into("<H", header, 1, carrier_ticks)
    struct.pack_into("<H", header, 1 + 10 * 2, loop_field)
    struct.pack_into("<HHHH", header, 89, TPB, CARRIER_MAGIC, BPM, 1)

    prefix = bytearray(header)
    prefix += struct.pack("<HH", 0, 100)
    prefix += bytes((0,)) + struct.pack("<H", carrier_ticks)
    prefix += bytes((0,)) + struct.pack("<H", loop_field)
    if len(prefix) != STREAM_START:
        raise AssertionError(f"Internal carrier prefix size error: {len(prefix)}")

    carrier = bytes(prefix) + stream
    if len(carrier) >= MAX_MUSIC_BUFFER:
        raise FormatError(
            f"{vgm_path.name}: output carrier is {len(carrier)} bytes; "
            f"GKEY music buffer limit is {MAX_MUSIC_BUFFER - 1} bytes"
        )

    validate_carrier(carrier, effective_vgm, loop_resume)

    loop_sample = vgm["loop_sample"]
    writes = vgm["writes"]
    assert isinstance(writes, list)

    meta: dict[str, object] = {
        "tool": APP_NAME,
        "tool_version": VERSION,
        "engine_format": "ED2 VGM BGM Engine v0.5.30-compatible compact raw OPL carrier",
        "source": str(vgm_path),
        "source_name": vgm_path.name,
        "source_sha256": sha256_file(vgm_path),
        "source_uncompressed_bytes": len(vgm["data"]),
        "source_ym3812_writes": len(writes),
        "output_ym3812_writes": len(gained_writes),
        "source_seconds": round(end_sample / VGM_SAMPLE_RATE, 9),
        "source_loop_seconds": None if loop_sample is None else round(loop_sample / VGM_SAMPLE_RATE, 9),
        "physical_hz": PHYSICAL_HZ,
        "quantum_ms": 1000.0 / PHYSICAL_HZ,
        "compact_stream_offset": STREAM_START,
        "compact_bytes": len(stream),
        "carrier_bytes": len(carrier),
        "loop_resume_offset_in_stream": loop_resume,
        "loop_field_in_carrier": loop_field,
        "carrier_logical_ticks": carrier_ticks,
        **gain_meta,
        **compact_meta,
    }
    return carrier, stream, meta


def validate_carrier(carrier: bytes, vgm: dict[str, object], loop_resume: int) -> None:
    if carrier[0] != 9 or u16(carrier, 1) == 0:
        raise FormatError("Carrier header basic fields are invalid")
    if (
        u16(carrier, 89) != TPB
        or u16(carrier, 91) != CARRIER_MAGIC
        or u16(carrier, 93) != BPM
        or u16(carrier, 95) != 1
    ):
        raise FormatError("Carrier timing/magic fields are invalid")
    if carrier[97:101] != struct.pack("<HH", 0, 100):
        raise FormatError("Carrier tempo event is invalid")
    if carrier[101] != 0 or u16(carrier, 102) != u16(carrier, 1):
        raise FormatError("Carrier voice0 timer rest is invalid")
    loop_field = u16(carrier, 21)
    if carrier[104] != 0 or u16(carrier, 105) != loop_field:
        raise FormatError("Carrier voice10 metadata rest is invalid")

    stream = carrier[STREAM_START:]
    pos = 0
    while True:
        if pos + 2 > len(stream):
            raise FormatError("Compact stream truncated while validating deltas")
        delta = stream[pos]
        count = stream[pos + 1]
        pos += 2
        if delta > 127:
            raise FormatError(f"Compact delta {delta} exceeds signed-safe maximum 127")
        if count == 255:
            break
        pos += count * 2
        if pos > len(stream):
            raise FormatError("Compact stream pair list exceeds file length")

    got, _end_tick, _end_pos, _records = decode_stream(stream, 0)
    source_writes = vgm["writes"]
    assert isinstance(source_writes, list)
    src_pairs = [(reg, value) for _sample, reg, value, _pos in source_writes]
    if [(reg, value) for _tick, reg, value in got] != src_pairs:
        raise FormatError("First-pass OPL register sequence differs from source VGM")

    plan = _startup_preroll_plan(vgm)
    split_index = plan["split_index"]
    for i, ((tick, reg, value), (sample, src_reg, src_value, _pos)) in enumerate(zip(got, source_writes)):
        if (reg, value) != (src_reg, src_value):
            raise FormatError("Compact OPL sequence mismatch")
        expected_tick = tick_floor(sample)
        if plan["enabled"] and isinstance(split_index, int) and i >= split_index:
            expected_tick += 1
        if tick != expected_tick:
            raise FormatError(
                f"Compact startup/timing mismatch at write {i}: got tick {tick}, expected {expected_tick}"
            )

    loop_abs = vgm["loop_abs"]
    if loop_abs is None:
        if loop_resume != 0:
            raise FormatError("One-shot VGM unexpectedly contains a compact loop pointer")
        return

    if loop_resume <= 0 or loop_resume >= len(stream):
        raise FormatError("Compact loop pointer is invalid")

    loop_got, loop_end_tick, _loop_end_pos, _loop_records = decode_stream(stream, loop_resume)
    loop_src_full = [x for x in source_writes if x[3] >= loop_abs]
    loop_src_pairs = [(reg, value) for _sample, reg, value, _pos in loop_src_full]
    if [(reg, value) for _tick, reg, value in loop_got] != loop_src_pairs:
        raise FormatError("Compact loop OPL sequence differs from VGM loop sequence")

    loop_sample = vgm["loop_sample"]
    end_sample = vgm["end_sample"]
    assert isinstance(loop_sample, int) and isinstance(end_sample, int)
    base_tick = tick_floor(loop_sample)
    for (tick, reg, value), (sample, src_reg, src_value, _pos) in zip(loop_got, loop_src_full):
        if (reg, value) != (src_reg, src_value) or tick != tick_floor(sample) - base_tick:
            raise FormatError("Compact loop timing differs from quantized VGM loop timing")
    if loop_end_tick != tick_floor(end_sample) - base_tick:
        raise FormatError("Compact loop end timing differs from quantized VGM loop duration")


def normalize_target_name(text: str) -> str:
    name = text.strip()
    if not name:
        raise ValueError("Output name is empty")
    if name.lower().endswith(".mus"):
        name = name[:-4]
    if any(ch in name for ch in '<>:"/\\|?*'):
        raise ValueError("Output name contains an invalid filename character")
    return name


def convert_file(
    source: Path,
    output_mus: Path,
    *,
    write_rawopl: bool = False,
    write_report: bool = True,
    gain_db: float = 0.0,
) -> dict[str, object]:
    carrier, stream, meta = build_carrier(source, gain_db=gain_db)
    output_mus.parent.mkdir(parents=True, exist_ok=True)
    output_mus.write_bytes(carrier)

    raw_path = output_mus.with_suffix(".RAWOPL")
    report_path = output_mus.with_suffix(".rawopl.json")
    if write_rawopl:
        raw_path.write_bytes(stream)
        meta["rawopl_output"] = str(raw_path)
    if write_report:
        meta["mus_output"] = str(output_mus)
        report_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    return meta


def default_output_for(source: Path, target_name: str | None = None) -> Path:
    if target_name:
        return source.with_name(normalize_target_name(target_name) + ".MUS")
    return source.with_suffix(".MUS")


def cli(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        description="Convert YM3812 VGM/VGZ to the compact raw-OPL carrier MUS used by ED2 VGM BGM Engine v0.5.30."
    )
    parser.add_argument("sources", nargs="*", help="input .vgm/.vgz file(s)")
    parser.add_argument("-o", "--output", help="output MUS path (single input only)")
    parser.add_argument("--target", help="output basename, e.g. DS2_03 (single input only)")
    parser.add_argument("--rawopl", action="store_true", help="also write the exact compact stream as .RAWOPL")
    parser.add_argument("--gain-db", type=float, default=0.0, help="OPL output gain in dB, quantized to 0.75 dB steps (range -48..+24; default 0)")
    parser.add_argument("--no-report", action="store_true", help="do not write .rawopl.json report")
    parser.add_argument("--inspect", action="store_true", help="print conversion report without writing files")
    parser.add_argument("--gui", action="store_true", help="open GUI")
    args = parser.parse_args(argv)

    if args.gui or not args.sources:
        return run_gui()

    if (args.output or args.target) and len(args.sources) != 1:
        parser.error("--output/--target can only be used with one input")

    rc = 0
    for src_text in args.sources:
        try:
            src = Path(src_text).expanduser().resolve()
            carrier, stream, meta = build_carrier(src, gain_db=args.gain_db)
            if args.inspect:
                print(json.dumps(meta, ensure_ascii=False, indent=2))
                continue

            if args.output:
                out = Path(args.output).expanduser().resolve()
            else:
                out = default_output_for(src, args.target)

            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(carrier)
            if args.rawopl:
                out.with_suffix(".RAWOPL").write_bytes(stream)
            if not args.no_report:
                meta["mus_output"] = str(out)
                if args.rawopl:
                    meta["rawopl_output"] = str(out.with_suffix(".RAWOPL"))
                out.with_suffix(".rawopl.json").write_text(
                    json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                )
            print(f"[OK] {src.name} -> {out.name}  ({len(carrier)} bytes, {len(stream)} raw OPL bytes)")
        except Exception as exc:
            rc = 1
            print(f"[ERROR] {src_text}: {type(exc).__name__}: {exc}", file=sys.stderr)
    return rc


def run_gui() -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except Exception as exc:
        print(f"Tkinter GUI is unavailable: {exc}", file=sys.stderr)
        return 1

    root = tk.Tk()
    root.title(f"{APP_NAME} v{VERSION}")
    root.geometry("760x500")

    source_var = tk.StringVar()
    output_var = tk.StringVar()
    raw_var = tk.BooleanVar(value=True)
    report_var = tk.BooleanVar(value=True)
    gain_var = tk.StringVar(value="0.0")
    status_var = tk.StringVar(value="Select a YM3812 VGM/VGZ file.")

    frame = ttk.Frame(root, padding=12)
    frame.pack(fill="both", expand=True)
    frame.columnconfigure(1, weight=1)
    frame.rowconfigure(8, weight=1)

    ttk.Label(frame, text="VGM / VGZ source").grid(row=0, column=0, sticky="w")
    ttk.Entry(frame, textvariable=source_var).grid(row=0, column=1, sticky="ew", padx=6)

    def choose_source() -> None:
        name = filedialog.askopenfilename(
            title="Select YM3812 VGM/VGZ",
            filetypes=[("VGM music", "*.vgm *.vgz"), ("All files", "*.*")],
        )
        if name:
            source_var.set(name)
            output_var.set(str(Path(name).with_suffix(".MUS")))
            analyze()

    ttk.Button(frame, text="Browse...", command=choose_source).grid(row=0, column=2, sticky="ew")

    ttk.Label(frame, text="Output carrier MUS").grid(row=1, column=0, sticky="w", pady=(8, 0))
    ttk.Entry(frame, textvariable=output_var).grid(row=1, column=1, sticky="ew", padx=6, pady=(8, 0))

    def choose_output() -> None:
        name = filedialog.asksaveasfilename(
            title="Save ED2 raw-OPL carrier MUS",
            defaultextension=".MUS",
            filetypes=[("ED2 MUS", "*.MUS"), ("All files", "*.*")],
        )
        if name:
            output_var.set(name)

    ttk.Button(frame, text="Browse...", command=choose_output).grid(row=1, column=2, sticky="ew", pady=(8, 0))

    ttk.Label(frame, text="Gain (dB)").grid(row=2, column=0, sticky="w", pady=(10, 0))
    ttk.Entry(frame, textvariable=gain_var, width=12).grid(row=2, column=1, sticky="w", padx=6, pady=(10, 0))
    ttk.Label(frame, text="0 = original, + = louder, - = quieter; YM3812 TL step = 0.75 dB").grid(row=2, column=2, sticky="w", pady=(10, 0))

    ttk.Checkbutton(frame, text="Also write .RAWOPL compact stream", variable=raw_var).grid(
        row=3, column=1, sticky="w", pady=(6, 0)
    )
    ttk.Checkbutton(frame, text="Write .rawopl.json report", variable=report_var).grid(
        row=4, column=1, sticky="w"
    )

    info = tk.Text(frame, height=15, wrap="word")
    info.grid(row=8, column=0, columnspan=3, sticky="nsew", pady=(12, 8))
    info.insert("1.0", "This converter emits the exact compact raw-OPL carrier format used by ED2 VGM BGM Engine v0.5.30.\n")
    info.configure(state="disabled")

    def set_info(text: str) -> None:
        info.configure(state="normal")
        info.delete("1.0", "end")
        info.insert("1.0", text)
        info.configure(state="disabled")

    def analyze() -> None:
        text = source_var.get().strip()
        if not text:
            return
        try:
            gain_db = float(gain_var.get().strip())
            _carrier, _stream, meta = build_carrier(Path(text), gain_db=gain_db)
            lines = [
                f"Source: {meta['source_name']}",
                f"Duration: {meta['source_seconds']:.3f} sec",
                f"Loop: {meta['source_loop_seconds'] if meta['source_loop_seconds'] is not None else 'none'}",
                f"YM3812 writes: {meta['source_ym3812_writes']} source / {meta['output_ym3812_writes']} output",
                f"Gain: requested {meta['gain_db_requested']:+.2f} dB / effective {meta['gain_db_effective']:+.2f} dB ({meta['gain_tl_steps']:+d} TL steps)",
                f"Gain TL writes: {meta['gain_adjusted_tl_writes']} adjusted + {meta['gain_synthetic_tl_writes']} path-refresh / {meta['gain_saturated_tl_writes']} saturated",
                f"Compact raw OPL: {meta['compact_bytes']} bytes",
                f"Carrier MUS: {meta['carrier_bytes']} bytes",
                f"Loop resume offset: {meta['loop_resume_offset_in_stream']}",
                f"Max writes/record: {meta['max_writes_per_record']}",
                "",
                "Timing is quantized to the engine's fixed 128 Hz scheduler (7.8125 ms quantum).",
                "Only YM3812 command 0x5A plus standard VGM waits are accepted, matching the current engine compiler.",
            ]
            set_info("\n".join(lines))
            status_var.set("VGM analysis OK.")
        except Exception as exc:
            set_info(f"ERROR\n\n{type(exc).__name__}: {exc}")
            status_var.set("Analysis failed.")

    def convert() -> None:
        src_text = source_var.get().strip()
        out_text = output_var.get().strip()
        if not src_text or not out_text:
            messagebox.showerror(APP_NAME, "Choose a source and output file.")
            return
        try:
            gain_db = float(gain_var.get().strip())
            meta = convert_file(
                Path(src_text), Path(out_text),
                write_rawopl=raw_var.get(), write_report=report_var.get(), gain_db=gain_db,
            )
            analyze()
            status_var.set(f"Converted: {Path(out_text).name}")
            messagebox.showinfo(
                APP_NAME,
                f"Conversion complete.\n\n{Path(out_text).name}\n"
                f"Carrier: {meta['carrier_bytes']} bytes\nRaw OPL: {meta['compact_bytes']} bytes\n"
                f"Gain: {meta['gain_db_effective']:+.2f} dB",
            )
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"{type(exc).__name__}: {exc}")
            status_var.set("Conversion failed.")

    buttons = ttk.Frame(frame)
    buttons.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(12, 0))
    ttk.Button(buttons, text="Analyze", command=analyze).pack(side="left")
    ttk.Button(buttons, text="Convert", command=convert).pack(side="left", padx=6)

    ttk.Label(frame, textvariable=status_var).grid(row=9, column=0, columnspan=3, sticky="w")

    root.mainloop()
    return 0


def main() -> int:
    return cli(sys.argv[1:])


if __name__ == "__main__":
    raise SystemExit(main())
