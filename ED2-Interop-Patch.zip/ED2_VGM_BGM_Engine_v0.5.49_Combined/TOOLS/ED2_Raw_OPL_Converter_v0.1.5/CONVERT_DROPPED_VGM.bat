@echo off
setlocal
if "%~1"=="" (
  echo Drag one or more .VGM/.VGZ files onto this BAT file.
  pause
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0ed2_raw_opl_converter.py" --rawopl %*
) else (
  python "%~dp0ed2_raw_opl_converter.py" --rawopl %*
)
if errorlevel 1 pause
