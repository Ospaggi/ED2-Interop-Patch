@echo off
if "%~1"=="" (
  echo Drag a YM3812 VGM/VGZ file onto this BAT.
  pause
  exit /b 1
)
python "%~dp0ed2_raw_opl_converter.py" "%~1" --target DS2_25 --rawopl
if errorlevel 1 goto error
echo.
echo Created DS2_25.MUS next to the source file.
echo Copy it to the game's BGM folder, replacing BGM\DS2_25.MUS.
pause
exit /b 0
:error
pause
exit /b 1
