@echo off
setlocal
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0ed2_raw_opl_converter.py" --gui
) else (
  python "%~dp0ed2_raw_opl_converter.py" --gui
)
if errorlevel 1 pause
