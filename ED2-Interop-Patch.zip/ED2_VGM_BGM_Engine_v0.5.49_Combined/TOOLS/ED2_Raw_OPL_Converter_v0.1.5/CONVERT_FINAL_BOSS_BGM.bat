@echo off
if "%~1"=="" (
  echo Drag and drop the final boss VGM/VGZ onto this file.
  pause
  exit /b 1
)
python "%~dp0ed2_raw_opl_converter.py" "%~1" --target DS2_27 --gain-db -0.75
pause
