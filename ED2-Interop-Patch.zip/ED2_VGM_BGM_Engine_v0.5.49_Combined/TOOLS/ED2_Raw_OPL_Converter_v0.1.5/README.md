# ED2 Raw OPL Converter v0.1.5

YM3812 VGM/VGZ를 ED2 VGM BGM Engine이 사용하는 `DS2_xx.MUS` carrier로 변환합니다.

## GUI

```text
RUN_GUI.bat
```

## CLI

```text
python ed2_raw_opl_converter.py song.vgz --target DS2_03 --rawopl
python ed2_raw_opl_converter.py song.vgz -o BGM\DS2_03.MUS --gain-db -3 --rawopl
```

Gain 범위는 `-48.0 dB ~ +24.0 dB`이며 YM3812 Total Level을 조정합니다.

출력:

- `.MUS`: 게임용 carrier
- `.RAWOPL`: 분석용 raw OPL stream
- `.rawopl.json`: 변환/루프/Gain 메타데이터
