#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, struct, tempfile
from pathlib import Path

VERSION='0.5.15'
SEG_INDEX=86

# ---------------------------------------------------------------------------
# Proven original ED2MAIN flow, NE segment 86
# ---------------------------------------------------------------------------
# 381D cmp BGM_INIT_FLAG,0
# 3822 jne 382F          ; original same-BGM path -> AH=02/INT40
# 3824 ... AH=00/INT40   ; first start
# 382D jmp 3833
# 382F mov ah,02
# 3831 int 40
# 3833 mov al,00
# 3835 jmp 3841
# 3841 mov [LOAD_BGM_FLAG],al
# 3844 retf
#
# v0.5.12 introduced the JNE displacement change 382F -> 3833.
# v0.5.13 retains that same-BGM bypass, but Settings -> BGM ON now targets
# the existing BGM_START export at 38C4 instead of the 382F resume tail.
SAME_BRANCH_OFF=0x3822
SAME_BRANCH_ORIG=bytes.fromhex('75 0B')
SAME_BRANCH_PATCH=bytes.fromhex('75 0F')
SAME_HELPER_OFF=0x382F
SAME_HELPER_ORIG=bytes.fromhex('B4 02 CD 40 B0 00 EB 0A')
SAME_HELPER_OLD_NOP=bytes.fromhex('90 90 90 90 B0 00 EB 0A')
SAME_CONTEXT_OFF=0x3817
SAME_CONTEXT_PREFIX=bytes.fromhex(
    '38 06 D6 3E 75 1A 80 3E D8 3E 00'
)
SAME_CONTEXT_SUFFIX=bytes.fromhex(
    'C6 06 D8 3E 01 B4 00 CD 40 EB 04'
)
COMMON_RETURN=bytes.fromhex('B0 00 EB 0A')  # 3833..3836
FLAG_RETURN=bytes.fromhex('A2 AE 95 CB')    # 3841..3844

# Settings BGM option.  OFF originally sends AX=0401, which is not a hard
# scheduler stop and therefore cannot silence raw-VGM OPL state.  Use the same
# AH=01 / INT 40h stop service that LOAD_BGM_SET already uses while BGM is
# disabled.  This path stops the GKEY music scheduler and clears active OPL
# voices before the option handler returns.
SETTINGS_OFF_OFF=0x4A7C
SETTINGS_OFF_ORIG=bytes.fromhex('B8 01 04 CD 40')
SETTINGS_OFF_PATCH=bytes.fromhex('B4 01 CD 40 90')
SETTINGS_OFF_JMP_OFF=0x4A81
SETTINGS_OFF_JMP=bytes.fromhex('E9 64 FF')

# Settings BGM ON. Keep the original FAR CALL instruction and its fixup
# source word exactly where the NE loader expects it.
OPTION_OFF=0x4A84
OPTION_ORIG=bytes.fromhex('A0 0D 20 9A FF FF 00 00')
OPTION_V510=bytes.fromhex('52 90 90 9A FF FF 00 00')
OPTION_V511=bytes.fromhex('A0 0D 20 B4 02 CD 40 90')
OPTION_JMP_OFF=0x4A8C
OPTION_JMP=bytes.fromhex('E9 59 FF')

# Internal-pointer relocation for the FAR CALL operand at 86:4A88.
RELOC_INDEX=492
RELOC_COUNT=1630
RELOC_SRC=0x4A88
RELOC_V511_DUP_SRC=0x357C
TARGET_LOAD_BGM=(86,0x37F5)
TARGET_V510_BAD=(86,0x5585)
TARGET_RESUME=(86,0x382F)
TARGET_BGM_START=(86,0x38C4)
NEIGHBOR_491=(3,0,0x4A6A,86,0x3287)
NEIGHBOR_493=(3,0,0x4A9E,86,0x7083)


def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def sha_bytes(b): return hashlib.sha256(b).hexdigest()

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.v0512.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def find_ci(parent:Path,name:str,directory=False)->Path:
    p=parent/name
    if p.exists() and p.is_dir()==directory:return p
    for q in parent.iterdir():
        if q.name.lower()==name.lower() and q.is_dir()==directory:return q
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')

def looks(root:Path)->bool:
    try: find_ci(root,'ED2MAIN.EXE'); find_ci(root,'GKEY.EXE'); find_ci(root,'BGM',True); return True
    except Exception:return False

def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r):raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen:continue
            seen.add(k)
            if looks(r):return r
    raise FileNotFoundError('ED2MAIN.EXE / GKEY.EXE / BGM이 함께 있는 게임 폴더를 찾지 못했습니다.')

def segment_info(b:bytes,index:int=SEG_INDEX):
    if len(b)<0x40 or b[:2]!=b'MZ':raise RuntimeError('ED2MAIN.EXE가 MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE':raise RuntimeError('ED2MAIN.EXE가 16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c)
    if not 1<=index<=count:raise RuntimeError(f'NE segment {index}가 없습니다.')
    table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    sector,length,flags,alloc=struct.unpack_from('<HHHH',b,table+(index-1)*8)
    base=sector<<shift; seglen=65536 if length==0 else length
    return base,seglen,flags

def reloc_table(b:bytes):
    base,seglen,_=segment_info(b)
    roff=base+seglen
    if roff+2>len(b):raise RuntimeError('NE86 relocation table가 없습니다.')
    count=u16(b,roff)
    if count!=RELOC_COUNT:raise RuntimeError(f'NE86 relocation 개수가 예상과 다릅니다: {count}')
    if roff+2+count*8>len(b):raise RuntimeError('NE86 relocation table가 잘렸습니다.')
    return roff,count

def reloc_at(b:bytes,index:int):
    roff,count=reloc_table(b)
    if not 0<=index<count:raise RuntimeError('relocation index 범위 오류')
    p=roff+2+index*8
    return p,struct.unpack_from('<BBHHH',b,p)

def all_relocs(b:bytes):
    roff,count=reloc_table(b)
    return [struct.unpack_from('<BBHHH',b,roff+2+i*8) for i in range(count)]

def validate_identity(b:bytes):
    base,seglen,_=segment_info(b)
    if 0x4A8F>seglen:raise RuntimeError('NE86 길이가 지원 버전과 다릅니다.')
    if b[base+SAME_CONTEXT_OFF:base+SAME_CONTEXT_OFF+len(SAME_CONTEXT_PREFIX)]!=SAME_CONTEXT_PREFIX:
        raise RuntimeError('LOAD_BGM 앞부분이 지원 코드와 다릅니다.')
    if b[base+0x3824:base+0x3824+len(SAME_CONTEXT_SUFFIX)]!=SAME_CONTEXT_SUFFIX:
        raise RuntimeError('LOAD_BGM 초기 시작 경로가 지원 코드와 다릅니다.')
    if b[base+0x3833:base+0x3833+len(COMMON_RETURN)]!=COMMON_RETURN:
        raise RuntimeError('LOAD_BGM 공통 반환 경로가 지원 코드와 다릅니다.')
    if b[base+0x3841:base+0x3841+len(FLAG_RETURN)]!=FLAG_RETURN:
        raise RuntimeError('LOAD_BGM flag/RETF 경로가 지원 코드와 다릅니다.')
    if b[base+SETTINGS_OFF_JMP_OFF:base+SETTINGS_OFF_JMP_OFF+3]!=SETTINGS_OFF_JMP:
        raise RuntimeError('BGM OFF 옵션 분기 후속 코드가 지원 버전과 다릅니다.')
    if b[base+OPTION_JMP_OFF:base+OPTION_JMP_OFF+3]!=OPTION_JMP:
        raise RuntimeError('BGM ON 옵션 분기 후속 코드가 지원 버전과 다릅니다.')
    _,r491=reloc_at(b,491); p,r492=reloc_at(b,RELOC_INDEX); _,r493=reloc_at(b,493)
    if r491!=NEIGHBOR_491 or r493!=NEIGHBOR_493:
        raise RuntimeError('ED2MAIN NE86 relocation #492 주변 배열이 지원 버전과 다릅니다.')
    if r492[0]!=3 or r492[1]!=0 or r492[3]!=86:
        raise RuntimeError('BGM 옵션 FAR CALL relocation의 type/flags/target segment가 예상과 다릅니다.')
    return base,p,r492

def classify(b:bytes):
    try:
        base,rp,r=validate_identity(b)
        branch=b[base+SAME_BRANCH_OFF:base+SAME_BRANCH_OFF+2]
        helper=b[base+SAME_HELPER_OFF:base+SAME_HELPER_OFF+8]
        off=b[base+SETTINGS_OFF_OFF:base+SETTINGS_OFF_OFF+5]
        opt=b[base+OPTION_OFF:base+OPTION_OFF+8]
        src,tgt=r[2],(r[3],r[4])

        if (branch==SAME_BRANCH_PATCH and helper==SAME_HELPER_ORIG and
            off==SETTINGS_OFF_PATCH and opt==OPTION_ORIG and src==RELOC_SRC and tgt==TARGET_BGM_START):
            return 'v0.5.15-fixed',(base,rp)

        # Supported pre-patch and known historical states.  These combinations
        # are normalized to the one safe final state; unrelated layouts abort.
        branch_ok=branch in (SAME_BRANCH_ORIG,SAME_BRANCH_PATCH)
        helper_ok=helper in (SAME_HELPER_ORIG,SAME_HELPER_OLD_NOP)
        off_ok=off in (SETTINGS_OFF_ORIG,SETTINGS_OFF_PATCH)
        opt_ok=opt in (OPTION_ORIG,OPTION_V510,OPTION_V511)
        reloc_ok=(src,tgt) in {
            (RELOC_SRC,TARGET_LOAD_BGM),
            (RELOC_SRC,TARGET_V510_BAD),
            (RELOC_SRC,TARGET_RESUME),
            (RELOC_SRC,TARGET_BGM_START),
            (RELOC_V511_DUP_SRC,TARGET_LOAD_BGM),
        }
        if not (branch_ok and helper_ok and off_ok and opt_ok and reloc_ok):
            return 'unsupported',None

        # Tight coupling checks identify the two broken historical variants.
        if opt==OPTION_V510 and (src,tgt)!=(RELOC_SRC,TARGET_V510_BAD): return 'unsupported',None
        if opt==OPTION_V511 and (src,tgt)!=(RELOC_V511_DUP_SRC,TARGET_LOAD_BGM): return 'unsupported',None
        if src==RELOC_V511_DUP_SRC and opt!=OPTION_V511:return 'unsupported',None
        return 'known-prior-state',(base,rp)
    except Exception:
        return 'unsupported',None

def relocation_sources_unique(b:bytes):
    rs=all_relocs(b); seen={}; dup=[]
    for i,r in enumerate(rs):
        src=r[2]
        if src in seen:dup.append((seen[src],i,src))
        else:seen[src]=i
    return dup

def apply_bytes(b:bytes)->bytes:
    state,loc=classify(b)
    if state=='unsupported':
        raise RuntimeError('ED2MAIN BGM 제어 코드/NE relocation이 지원 형태가 아닙니다. 아무 파일도 수정하지 않았습니다.')
    if state=='v0.5.15-fixed': return b
    base,rp=loc
    x=bytearray(b)

    # 1) Restore the original AH=02/INT40 tail.  Old v0.5.3a+ NOP patches are removed.
    x[base+SAME_HELPER_OFF:base+SAME_HELPER_OFF+8]=SAME_HELPER_ORIG
    # 2) Same-BGM normal path now skips 382F and lands on MOV AL,0 at 3833.
    x[base+SAME_BRANCH_OFF:base+SAME_BRANCH_OFF+2]=SAME_BRANCH_PATCH
    # 3) Settings BGM OFF: use GKEY's real hard-stop service (AH=01 / INT 40h).
    #    This is the same service LOAD_BGM_SET already uses while BGM is disabled.
    x[base+SETTINGS_OFF_OFF:base+SETTINGS_OFF_OFF+5]=SETTINGS_OFF_PATCH
    # 4) Restore the Settings BGM ON FAR CALL instruction exactly.
    x[base+OPTION_OFF:base+OPTION_OFF+8]=OPTION_ORIG
    # 5) Preserve the original unique relocation source, changing target only to
    #    the existing BGM_START export.  BGM_START issues AH=00 / INT 40h and
    #    resets the music clock, so the compact VGM handler reinitializes too.
    struct.pack_into('<BBHHH',x,rp,3,0,RELOC_SRC,TARGET_BGM_START[0],TARGET_BGM_START[1])
    nb=bytes(x)

    nstate,_=classify(nb)
    if nstate!='v0.5.15-fixed':raise RuntimeError(f'내부 적용 검증 실패: {nstate}')
    # This is the invariant v0.5.11 violated: no duplicate fixup-chain heads.
    dup=relocation_sources_unique(nb)
    if dup:raise RuntimeError(f'적용 후 NE86 relocation source 중복이 있습니다: {dup[:4]}')
    if nb[base+RELOC_SRC:base+RELOC_SRC+2]!=b'\xff\xff':
        raise RuntimeError('적용 후 FAR CALL fixup source word가 FFFF가 아닙니다.')
    return nb

def restore_bytes(b:bytes)->bytes:
    state,loc=classify(b)
    if state=='unsupported':
        raise RuntimeError('ED2MAIN BGM 제어 코드/NE relocation이 지원 형태가 아니어서 안전하게 복원할 수 없습니다.')
    base,rp=loc
    x=bytearray(b)
    x[base+SAME_BRANCH_OFF:base+SAME_BRANCH_OFF+2]=SAME_BRANCH_ORIG
    x[base+SAME_HELPER_OFF:base+SAME_HELPER_OFF+8]=SAME_HELPER_ORIG
    x[base+SETTINGS_OFF_OFF:base+SETTINGS_OFF_OFF+5]=SETTINGS_OFF_ORIG
    x[base+OPTION_OFF:base+OPTION_OFF+8]=OPTION_ORIG
    struct.pack_into('<BBHHH',x,rp,3,0,RELOC_SRC,TARGET_LOAD_BGM[0],TARGET_LOAD_BGM[1])
    nb=bytes(x)
    # Validate exact relevant original state, without requiring a whole-file hash
    # (Korean/localization patches elsewhere in ED2MAIN are preserved).
    base2,rp2,r2=validate_identity(nb)
    if nb[base2+SAME_BRANCH_OFF:base2+SAME_BRANCH_OFF+2]!=SAME_BRANCH_ORIG:raise RuntimeError('복원 branch 검증 실패')
    if nb[base2+SAME_HELPER_OFF:base2+SAME_HELPER_OFF+8]!=SAME_HELPER_ORIG:raise RuntimeError('복원 helper 검증 실패')
    if nb[base2+SETTINGS_OFF_OFF:base2+SETTINGS_OFF_OFF+5]!=SETTINGS_OFF_ORIG:raise RuntimeError('복원 BGM OFF 검증 실패')
    if nb[base2+OPTION_OFF:base2+OPTION_OFF+8]!=OPTION_ORIG:raise RuntimeError('복원 option 검증 실패')
    if r2!=(3,0,RELOC_SRC,TARGET_LOAD_BGM[0],TARGET_LOAD_BGM[1]):raise RuntimeError('복원 relocation 검증 실패')
    if relocation_sources_unique(nb):raise RuntimeError('복원 후 relocation source 중복이 남았습니다.')
    return nb

def apply(root=None):
    r=auto_root(root);p=find_ci(r,'ED2MAIN.EXE');b=p.read_bytes();state,_=classify(b)
    if state=='unsupported':raise RuntimeError('ED2MAIN BGM 제어 preflight 실패. 아무 파일도 수정하지 않았습니다.')
    nb=apply_bytes(b)
    if nb==b:
        print('v0.5.15 ED2MAIN BGM control fix가 이미 적용되어 있습니다.');return
    atomic(p,nb)
    if classify(p.read_bytes())[0]!='v0.5.15-fixed':raise RuntimeError('디스크 적용 후 검증 실패')
    print('v0.5.15 ED2MAIN BGM control fix 적용 완료.')
    print('- same-BGM: JNE 382F -> 3833 (1-byte displacement change)')
    print('- Settings BGM OFF: AX=0401 -> hard stop AH=01 / INT 40h')
    print('- Settings BGM ON: original FAR CALL/stack preserved; relocation source 4A88 preserved')
    print('- FAR CALL target only: 86:37F5/382F -> existing BGM_START 86:38C4')
    print('- v0.5.10 5585 stack bug / v0.5.11 duplicate relocation bug 제거')

def restore(root=None):
    r=auto_root(root);p=find_ci(r,'ED2MAIN.EXE');b=p.read_bytes();nb=restore_bytes(b)
    if nb==b:
        print('ED2MAIN BGM control은 이미 원래 상태입니다.');return
    atomic(p,nb);print('ED2MAIN BGM control을 원래 코드/relocation으로 복원했습니다.')

def status(root=None):
    r=auto_root(root);p=find_ci(r,'ED2MAIN.EXE');b=p.read_bytes();state,loc=classify(b)
    print('ED2MAIN BGM control:',state)
    if loc:
        base,rp=loc
        print(f'- same branch 86:{SAME_BRANCH_OFF:04X}:',b[base+SAME_BRANCH_OFF:base+SAME_BRANCH_OFF+2].hex(' '))
        print(f'- resume tail  86:{SAME_HELPER_OFF:04X}:',b[base+SAME_HELPER_OFF:base+SAME_HELPER_OFF+8].hex(' '))
        print(f'- option OFF   86:{SETTINGS_OFF_OFF:04X}:',b[base+SETTINGS_OFF_OFF:base+SETTINGS_OFF_OFF+5].hex(' '))
        print(f'- option code  86:{OPTION_OFF:04X}:',b[base+OPTION_OFF:base+OPTION_OFF+8].hex(' '))
        _,rr=reloc_at(b,RELOC_INDEX)
        print(f'- relocation #492: source 86:{rr[2]:04X} -> seg#{rr[3]}:{rr[4]:04X}')
        print('- duplicate relocation sources:',relocation_sources_unique(b)[:8] or '(none)')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['apply','restore','status']);ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args();root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:
        print();print(f'[ERROR] {type(e).__name__}: {e}');print('패치를 중단했습니다. 위 오류를 그대로 알려 주세요.');return 1
if __name__=='__main__':raise SystemExit(main())
