#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, struct, tempfile
from pathlib import Path

VERSION='0.5.37'
ORIG=bytes.fromhex('B8 01 04 CD 40')      # MOV AX,0401h / INT 40h (stock MUS fade-out)
PATCH=bytes.fromhex('B4 01 CD 40 90')     # MOV AH,01h / INT 40h / NOP (hard BGM stop)

# Gameplay-only AX=0401/INT40 BGM fade-out sites outside the Settings option.
# ED2END.EXE is intentionally OUT OF SCOPE and is never opened or modified here.
# The Settings site ED2MAIN seg86:4A7C is owned by patch_ed2main_bgm_control.py.
# Locations are NE segment:offset so unrelated localized text/file offsets do not matter.
TARGETS=(
    ('ED2MAIN.EXE', 86, 0x2429, 'ED2MAIN internal event fade #1'),
    ('ED2MAIN.EXE', 86, 0x3592, 'ED2MAIN internal event fade #2'),
    ('MON/M_501.DLL', 3, 0x041E, 'monster/event fade'),
    ('SCENA/T_240.DLL', 3, 0x0852, 'Siel-area sleep/inn fade'),
    ('SCENA/T_543.DLL', 3, 0x07FD, 'Kubera-area sleep fade'),
)

# These five AX=0401 calls are not generic fades.  They are embedded in the
# chapter-advance routines; immediately afterwards the game writes SIN_CHAP,
# copies the 30-byte TITLE_DATA, and jumps into the next chapter.  v0.5.36
# incorrectly hard-stopped them.  Preserve/migrate them back to stock 0401.
CHAPTER_TRANSITIONS=(
    ('SCENA/V_000.DLL', 3, 0x04B9, 'prologue -> chapter 1 transition'),
    ('SCENA/V_100.DLL', 3, 0x040E, 'chapter 1 -> chapter 2 transition'),
    ('SCENA/V_200.DLL', 3, 0x0779, 'chapter 2 -> chapter 3 transition'),
    ('SCENA/V_300.DLL', 3, 0x04B0, 'chapter 3 -> chapter 4 transition'),
    ('SCENA/V_400.DLL', 3, 0x1384, 'chapter 4 -> final chapter transition'),
)


def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.v0515.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def find_ci(parent:Path,name:str,directory=False)->Path:
    p=parent/name
    if p.exists() and p.is_dir()==directory:return p
    for q in parent.iterdir():
        if q.name.lower()==name.lower() and q.is_dir()==directory:return q
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')


def resolve_rel(root:Path,rel:str)->Path:
    p=root
    parts=Path(rel).parts
    for i,part in enumerate(parts):
        p=find_ci(p,part,directory=(i<len(parts)-1))
    return p


def looks(root:Path)->bool:
    try:
        find_ci(root,'ED2MAIN.EXE'); find_ci(root,'GKEY.EXE')
        find_ci(root,'BGM',True); find_ci(root,'SCENA',True); find_ci(root,'MON',True)
        return True
    except Exception:return False


def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r):raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen:continue
            seen.add(k)
            if looks(r):return r
    raise FileNotFoundError('ED2MAIN.EXE / GKEY.EXE / BGM / SCENA / MON이 함께 있는 게임 폴더를 찾지 못했습니다.')


def seg_info(b:bytes,index:int):
    if len(b)<0x40 or b[:2]!=b'MZ':raise RuntimeError('MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE':raise RuntimeError('16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c)
    if not 1<=index<=count:raise RuntimeError(f'NE segment {index}가 없습니다.')
    table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    sector,length,flags,alloc=struct.unpack_from('<HHHH',b,table+(index-1)*8)
    base=sector<<shift; seglen=65536 if length==0 else length
    return base,seglen


def target_file_offset(b:bytes,seg:int,off:int)->int:
    base,seglen=seg_info(b,seg)
    if off+len(ORIG)>seglen:raise RuntimeError(f'NE seg{seg}:{off:04X}가 segment 범위를 벗어납니다.')
    return base+off


def classify_target(path:Path,seg:int,off:int):
    b=path.read_bytes(); fo=target_file_offset(b,seg,off); cur=b[fo:fo+5]
    if cur==ORIG:return 'original',b,fo
    if cur==PATCH:return 'patched',b,fo
    return 'unsupported',b,fo


def preflight(root=None):
    r=auto_root(root); out=[]
    for rel,seg,off,desc in TARGETS:
        p=resolve_rel(r,rel); state,b,fo=classify_target(p,seg,off)
        if state=='unsupported':
            got=b[fo:fo+5].hex(' ')
            raise RuntimeError(f'{rel} BGM fade code가 지원 형태가 아닙니다. NE {seg}:{off:04X} (file 0x{fo:X}): {got}')
        out.append((rel,p,seg,off,fo,state,desc))
    return r,out


def preflight_chapter_transitions(root:Path):
    out=[]
    for rel,seg,off,desc in CHAPTER_TRANSITIONS:
        p=resolve_rel(root,rel); state,b,fo=classify_target(p,seg,off)
        if state=='unsupported':
            got=b[fo:fo+5].hex(' ')
            raise RuntimeError(f'{rel} chapter transition code가 지원 형태가 아닙니다. NE {seg}:{off:04X} (file 0x{fo:X}): {got}')
        out.append((rel,p,seg,off,fo,state,desc))
    return out


def apply(root=None):
    r,items=preflight(root); chapter=preflight_chapter_transitions(r); changed=[]; migrated=[]
    try:
        # Repair v0.5.36 installations first: chapter transitions must retain
        # stock AX=0401/INT40 semantics even though other gameplay fades stop.
        for rel,p,seg,off,fo,state,desc in chapter:
            if state=='original':continue
            b=bytearray(p.read_bytes()); b[fo:fo+5]=ORIG; atomic(p,bytes(b)); migrated.append((p,fo))
        for rel,p,seg,off,fo,state,desc in items:
            if state=='patched':continue
            b=bytearray(p.read_bytes()); b[fo:fo+5]=PATCH; atomic(p,bytes(b)); changed.append((p,fo))
        for rel,p,seg,off,fo,_state,desc in items:
            st,_,_=classify_target(p,seg,off)
            if st!='patched':raise RuntimeError(f'{rel} 디스크 적용 검증 실패: {st}')
        for rel,p,seg,off,fo,_state,desc in chapter:
            st,_,_=classify_target(p,seg,off)
            if st!='original':raise RuntimeError(f'{rel} 장 전환 0401 복원 검증 실패: {st}')
    except Exception:
        for p,fo in reversed(changed):
            try:
                b=bytearray(p.read_bytes())
                if b[fo:fo+5]==PATCH:b[fo:fo+5]=ORIG; atomic(p,bytes(b))
            except Exception:pass
        for p,fo in reversed(migrated):
            try:
                b=bytearray(p.read_bytes())
                if b[fo:fo+5]==ORIG:b[fo:fo+5]=PATCH; atomic(p,bytes(b))
            except Exception:pass
        raise
    print(f'v{VERSION} gameplay BGM fade-out hard-stop fix 적용 완료. (ED2END.EXE 제외)')
    print(f'- 일반 fade hard-stop: {len(items)}곳 / 새 변경 {len(changed)}곳')
    print(f'- 장 전환 원본 0401 유지: {len(chapter)}곳 / v0.5.36에서 복구 {len(migrated)}곳')
    print('- V_000/V_100/V_200/V_300/V_400은 장 상태·TITLE_DATA 전환 루틴이므로 hard-stop 대상에서 제외합니다.')


def restore(root=None):
    r,items=preflight(root); chapter=preflight_chapter_transitions(r)
    changed=0
    for rel,p,seg,off,fo,state,desc in items:
        if state=='original':continue
        b=bytearray(p.read_bytes()); b[fo:fo+5]=ORIG; atomic(p,bytes(b)); changed+=1
    for rel,p,seg,off,fo,state,desc in chapter:
        if state=='original':continue
        b=bytearray(p.read_bytes()); b[fo:fo+5]=ORIG; atomic(p,bytes(b)); changed+=1
    print(f'본편 이벤트 BGM 제어 {changed}곳을 원래 AX=0401 명령으로 복원했습니다. ED2END.EXE는 대상이 아닙니다.')


def status(root=None):
    r,items=preflight(root); chapter=preflight_chapter_transitions(r)
    print(f'=== v{VERSION} gameplay BGM fade-out status (ED2END.EXE excluded) ===')
    for rel,p,seg,off,fo,state,desc in items:
        print(f'- {rel} NE{seg}:{off:04X} file=0x{fo:X}: {state} ({desc})')
    print('--- chapter-transition exceptions: stock AX=0401 required ---')
    for rel,p,seg,off,fo,state,desc in chapter:
        print(f'- {rel} NE{seg}:{off:04X} file=0x{fo:X}: {state} ({desc})')
    print(f'- managed hard-stop fade sites here: {len(items)}')
    print(f'- protected chapter-transition sites: {len(chapter)}')
    print('- Settings ED2MAIN NE86:4A7C is managed by BGM control patch.')
    print('- ED2END.EXE is intentionally excluded from preflight/apply/status/restore.')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['apply','restore','status']);ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args();root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:
        print();print(f'[ERROR] {type(e).__name__}: {e}');print('패치를 중단했습니다. 위 오류를 그대로 알려 주세요.');return 1
if __name__=='__main__':raise SystemExit(main())
