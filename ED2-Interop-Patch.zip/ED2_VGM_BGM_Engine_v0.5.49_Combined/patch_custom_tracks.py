#!/usr/bin/env python3
from __future__ import annotations

import os
import argparse, hashlib, json, os, shutil, tempfile
from pathlib import Path

VERSION = '0.5.47'
BACKUP = Path('ED2_BACKUP') / 'VGM_BGM_Engine' / 'Custom_Tracks'
MANIFEST = 'manifest.json'
HERE = Path(__file__).resolve().parent
BUNDLED = {
    6: HERE / 'CUSTOM_BGM' / 'DS2_06.MUS',
    26: HERE / 'CUSTOM_BGM' / 'DS2_26.MUS',
    27: HERE / 'CUSTOM_BGM' / 'DS2_27.MUS',
    29: HERE / 'CUSTOM_BGM' / 'DS2_29.MUS',
    30: HERE / 'CUSTOM_BGM' / 'DS2_30.MUS',
    31: HERE / 'CUSTOM_BGM' / 'DS2_31.MUS',
}
FORCE_SLOTS = {6, 26, 27, 29}

EXPECTED_SHA = {
    6: '1c8fc19509b72dd71deb9200d6cddf035123870466c12d5bfdf681ddf4d50e83',
    26: '4f6ce122638489cf63fcdeba23d79d8ebcff517f135817c0db4938d5083d202f',
    27: '4ec4a4900eae65685990e48f954f89e84bff39e7676c49c5a832c34483931e6b',
    29: '508a5a2c3fb0c5f80b34434e34c9dae1a6c57244978e36950c86228bab0ccc80',
    30: 'ebb8fa0f0c55b008a5248395dba1fec7c90dbb5cc6b02c2ea8eb51fa5be23956',
    31: '003fff84b32039f6af1626e3d96b3c15ec7de685bc8fd9f1319e05177b2c92a1',
}

LEGACY_BUNDLED_SHA = {30: {'8c6108b9bf1ace3e89fd402d0089e618c06068648142c15009d88e6e276c638f'}}


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + '.tracks527.', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def find_ci(parent: Path, name: str, directory: bool = False) -> Path:
    direct = parent / name
    if direct.exists() and direct.is_dir() == directory:
        return direct
    for p in parent.iterdir():
        if p.name.lower() == name.lower() and p.is_dir() == directory:
            return p
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')


def looks(root: Path) -> bool:
    try:
        find_ci(root, 'ED2MAIN.EXE')
        find_ci(root, 'BGM', True)
        return True
    except Exception:
        return False


def auto_root(explicit=None) -> Path:
    if explicit not in (None, '', '.', 'auto'):
        r = Path(explicit).expanduser().resolve()
        if not looks(r): raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen = set()
    for start in [HERE, Path.cwd().resolve()]:
        for r in (start, *start.parents):
            key = str(r).lower()
            if key in seen: continue
            seen.add(key)
            if looks(r): return r
    raise FileNotFoundError('ED2MAIN.EXE와 BGM 폴더가 함께 있는 게임 폴더를 찾지 못했습니다.')


def paths(root=None):
    r = auto_root(root); bgm = find_ci(r, 'BGM', True)
    return r, bgm, r / BACKUP


def verify_bundle() -> None:
    for slot, src in BUNDLED.items():
        if not src.is_file():
            raise RuntimeError(f'번들 DS2_{slot:02d}.MUS가 없습니다: {src}')
        got = sha_file(src)
        if got != EXPECTED_SHA[slot]:
            raise RuntimeError(f'번들 DS2_{slot:02d}.MUS SHA 불일치: {got}')


def load_manifest(bdir: Path):
    p = bdir / MANIFEST
    if not p.is_file(): return None
    return json.loads(p.read_text(encoding='utf-8'))


def write_manifest(bdir: Path, m: dict) -> None:
    bdir.mkdir(parents=True, exist_ok=True)
    (bdir / MANIFEST).write_text(json.dumps(m, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def apply(root=None) -> None:
    verify_bundle()
    r, bgm, bdir = paths(root)
    aio_no_backup = os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP') == '1'
    m = None if aio_no_backup else load_manifest(bdir)
    if m is None:
        m = {'version': VERSION, 'slots': {}}
        if not aio_no_backup: bdir.mkdir(parents=True, exist_ok=True)
    slots = m.setdefault('slots', {})
    newly_managed = []
    # v0.5.30 keeps the v0.5.27 backup directory. P15 is no longer a custom
    # override (v0.5.29 policy): the VGM core owns P15 at 0 dB. Retire the
    # legacy v0.5.28 P15 custom-manifest entry only when the core P15 is present.
    legacy15 = slots.get('15')
    p15 = bgm / 'DS2_15.MUS'
    core15 = '50a12e8716274ac988dddc77c9337cd70c9f709b53e5b6565358b0ff835d87fa'
    if legacy15 is not None and p15.exists() and sha_file(p15) == core15:
        slots.pop('15', None)
        old15 = bdir / 'DS2_15.MUS.before'
        if not aio_no_backup and old15.exists(): old15.unlink()
    for slot in sorted(BUNDLED):
        key = str(slot)
        if key not in slots:
            dst = bgm / f'DS2_{slot:02d}.MUS'
            info = {'existed_before': dst.exists(), 'before_sha256': sha_file(dst) if dst.exists() else None}
            if dst.exists():
                if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
                    info['backup_source'] = 'aio_transaction'
                else:
                    shutil.copy2(dst, bdir / f'DS2_{slot:02d}.MUS.before')
            slots[key] = info
            newly_managed.append(slot)
    changed = []
    preserved = []
    for slot, src in BUNDLED.items():
        dst = bgm / f'DS2_{slot:02d}.MUS'
        got = sha_file(dst) if dst.exists() else None
        # P06, P26 and P27 are rebuilt by the core step on every combined apply, so always
        # install their final user-supplied gain-adjusted carriers. P30/P31 may be user-edited
        # after installation and remain non-destructive on reapply.
        if slot not in FORCE_SLOTS and slot not in newly_managed and got is not None and got != EXPECTED_SHA[slot]:
            # Upgrade a previously bundled carrier when its exact legacy SHA is known;
            # preserve arbitrary user-edited P30/P31 files on reapply.
            if got not in LEGACY_BUNDLED_SHA.get(slot, set()):
                preserved.append(dst.name)
                continue
        data = src.read_bytes()
        if got != EXPECTED_SHA[slot]:
            atomic(dst, data); changed.append(dst.name)
    m['version'] = VERSION
    m['bundled_sha256'] = {str(k): v for k, v in EXPECTED_SHA.items()}
    if not aio_no_backup: write_manifest(bdir, m)
    print('Custom track pack v0.5.47 applied.')
    print('DS2_06 = Surprise.vgm, gain -2.25 dB')
    print('DS2_25 = Grostos Castle 2.vgz (generated by VGM core)')
    print("DS2_26 = Soldier's Flute.vgm custom, gain 0 dB")
    print('DS2_27 = Battle with the Emperor.vgm, gain -0.75 dB')
    print('DS2_29 = TITLE.vgm, gain -3.0 dB')
    print('DS2_30 = Cannon.vgm')
    print('DS2_31 = throne.vgm')
    if changed: print('installed:', ', '.join(changed))
    if preserved: print('reapply preserved user-modified:', ', '.join(preserved))

def restore(root=None) -> None:
    verify_bundle()
    r, bgm, bdir = paths(root)
    m = load_manifest(bdir)
    if m is None:
        print('Custom track pack backup manifest가 없습니다. 변경하지 않았습니다.')
        return
    kept = []
    restored = []
    for slot in sorted(BUNDLED):
        dst = bgm / f'DS2_{slot:02d}.MUS'
        info = m.get('slots', {}).get(str(slot), {})
        if dst.exists() and sha_file(dst) != EXPECTED_SHA[slot]:
            kept.append(dst.name)
            continue
        if info.get('existed_before'):
            src = bdir / f'DS2_{slot:02d}.MUS.before'
            if not src.is_file():
                raise RuntimeError(f'복원 백업이 없습니다: {src}')
            atomic(dst, src.read_bytes()); restored.append(dst.name)
        else:
            if dst.exists(): dst.unlink()
            restored.append(dst.name + ' removed')
    if not kept:
        shutil.rmtree(bdir, ignore_errors=True)
    print('Custom track pack restore 완료.')
    if restored: print('restored:', ', '.join(restored))
    if kept: print('user-modified track preserved:', ', '.join(kept))


def status(root=None) -> bool:
    verify_bundle()
    r, bgm, bdir = paths(root)
    print('=== Custom tracks v0.5.47 ===')
    print('P06: Surprise.vgm (-2.25 dB)')
    print('P25: Grostos Castle 2.vgz (generated by VGM core)')
    print("P26: Soldier's Flute.vgm custom (0 dB)")
    print('P27: Battle with the Emperor.vgm (-0.75 dB)')
    print('P29: TITLE.vgm (-3.0 dB)')
    ready = True
    for slot, expected in EXPECTED_SHA.items():
        dst = bgm / f'DS2_{slot:02d}.MUS'
        got = sha_file(dst) if dst.exists() else None
        ok = got == expected
        print(f'P{slot:02d}:', 'bundled' if ok else ('present-custom' if got else 'missing'), got or '')
        ready = ready and dst.exists()
    print('backup manifest:', 'present' if (bdir / MANIFEST).is_file() else 'missing')
    print('ready:', ready)
    return ready


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('action', choices=['apply','restore','status']); ap.add_argument('game_root', nargs='?', default='auto')
    a = ap.parse_args(); root = None if a.game_root == 'auto' else a.game_root
    try:
        {'apply': apply, 'restore': restore, 'status': status}[a.action](root); return 0
    except Exception as e:
        print(); print(f'[ERROR] {type(e).__name__}: {e}'); return 1

if __name__ == '__main__': raise SystemExit(main())
