@echo off
python patch_combined.py apply auto
if errorlevel 1 goto error
echo.
echo v0.5.37 Combined patch applied.
pause
exit /b 0
:error
pause
exit /b 1
