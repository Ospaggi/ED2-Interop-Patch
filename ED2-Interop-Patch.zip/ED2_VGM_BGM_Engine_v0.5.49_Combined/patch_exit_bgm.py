#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, struct, tempfile
from pathlib import Path

VERSION='0.5.31'
SEG_INDEX=86
EXIT_PROG_OFF=0x23B2
EXIT_PROG2_OFF=0x23D8
ORIG=bytes.fromhex('B8 03 04 CD 40')      # MOV AX,0403h / INT 40h
PATCH=bytes.fromhex('B4 01 CD 40 90')     # MOV AH,01h / INT 40h / NOP
CALL_SITE_OFF=0x23BC
CALL_SITE=bytes.fromhex('0E E8 18 00')    # PUSH CS / CALL 23D8
POST_CONTEXT=bytes.fromhex('9A FF FF 00 00 B8 00 08 CD 41')


def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.v0531.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def find_ci(parent:Path,name:str,directory=False)->Path:
    p=parent/name
    if p.exists() and p.is_dir()==directory:return p
    for q in parent.iterdir():
        if q.name.lower()==name.lower() and q.is_dir()==directory:return q
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')


def looks(root:Path)->bool:
    try:
        find_ci(root,'ED2MAIN.EXE'); find_ci(root,'GKEY.EXE'); find_ci(root,'BGM',True)
        return True
    except Exception:return False


def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r):raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen:continue
            seen.add(k)
            if looks(r):return r
    raise FileNotFoundError('ED2MAIN.EXE / GKEY.EXE / BGM이 함께 있는 게임 폴더를 찾지 못했습니다.')


def seg_info(b:bytes,index:int):
    if len(b)<0x40 or b[:2]!=b'MZ':raise RuntimeError('MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE':raise RuntimeError('16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c)
    if not 1<=index<=count:raise RuntimeError(f'NE segment {index}가 없습니다.')
    table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    sector,length,flags,alloc=struct.unpack_from('<HHHH',b,table+(index-1)*8)
    base=sector<<shift; seglen=65536 if length==0 else length
    return base,seglen


def classify_bytes(b:bytes):
    base,seglen=seg_info(b,SEG_INDEX)
    if EXIT_PROG2_OFF+len(POST_CONTEXT)+5>seglen:
        raise RuntimeError('ED2MAIN NE86 길이가 지원 버전과 다릅니다.')
    if b[base+CALL_SITE_OFF:base+CALL_SITE_OFF+len(CALL_SITE)]!=CALL_SITE:
        got=b[base+CALL_SITE_OFF:base+CALL_SITE_OFF+len(CALL_SITE)].hex(' ')
        raise RuntimeError(f'EXIT_PROG -> EXIT_PROG2 호출부가 예상과 다릅니다: {got}')
    if b[base+EXIT_PROG2_OFF+5:base+EXIT_PROG2_OFF+5+len(POST_CONTEXT)]!=POST_CONTEXT:
        got=b[base+EXIT_PROG2_OFF+5:base+EXIT_PROG2_OFF+5+len(POST_CONTEXT)].hex(' ')
        raise RuntimeError(f'EXIT_PROG2 후속 정리 코드가 예상과 다릅니다: {got}')
    cur=b[base+EXIT_PROG2_OFF:base+EXIT_PROG2_OFF+5]
    if cur==ORIG:return 'original',base
    if cur==PATCH:return 'patched',base
    return 'unsupported',base


def preflight(root=None):
    r=auto_root(root); p=find_ci(r,'ED2MAIN.EXE'); b=p.read_bytes(); st,base=classify_bytes(b)
    if st=='unsupported':
        got=b[base+EXIT_PROG2_OFF:base+EXIT_PROG2_OFF+5].hex(' ')
        raise RuntimeError(f'게임 종료 BGM 명령이 지원 형태가 아닙니다. NE86:{EXIT_PROG2_OFF:04X}: {got}')
    return r,p,st,base


def apply(root=None):
    r,p,st,base=preflight(root)
    if st=='patched':
        print(f'v{VERSION} game-exit BGM hard-stop fix가 이미 적용되어 있습니다.')
        return
    b=bytearray(p.read_bytes()); b[base+EXIT_PROG2_OFF:base+EXIT_PROG2_OFF+5]=PATCH; atomic(p,bytes(b))
    st2,_=classify_bytes(p.read_bytes())
    if st2!='patched':raise RuntimeError(f'적용 후 검증 실패: {st2}')
    print(f'v{VERSION} game-exit BGM hard-stop fix 적용 완료.')
    print(f'- ED2MAIN EXIT_PROG2 NE86:{EXIT_PROG2_OFF:04X}')
    print('- AX=0403 / INT40 -> AH=01 / INT40 (즉시 정지)')
    print('- 이후 종료 정리와 DOS INT21/4C00 흐름은 그대로 유지합니다.')


def restore(root=None):
    r,p,st,base=preflight(root)
    if st=='original':
        print('게임 종료 BGM 명령이 이미 원본 AX=0403 상태입니다.')
        return
    b=bytearray(p.read_bytes()); b[base+EXIT_PROG2_OFF:base+EXIT_PROG2_OFF+5]=ORIG; atomic(p,bytes(b))
    st2,_=classify_bytes(p.read_bytes())
    if st2!='original':raise RuntimeError(f'복원 후 검증 실패: {st2}')
    print('게임 종료 BGM 명령을 원래 AX=0403 / INT40으로 복원했습니다.')


def status(root=None):
    r,p,st,base=preflight(root)
    print(f'=== v{VERSION} game-exit BGM status ===')
    print(f'- ED2MAIN NE86:{EXIT_PROG2_OFF:04X}: {st}')
    print('- patched = 게임 종료 시 BGM 즉시 정지')
    print('- original = 원본 AX=0403 종료 전환/페이드')


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['apply','restore','status']); ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args(); root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:
        print();print(f'[ERROR] {type(e).__name__}: {e}');print('패치를 중단했습니다. 위 오류를 그대로 알려 주세요.');return 1
if __name__=='__main__':raise SystemExit(main())
