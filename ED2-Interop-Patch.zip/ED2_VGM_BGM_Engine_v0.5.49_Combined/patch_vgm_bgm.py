#!/usr/bin/env python3
from __future__ import annotations

import os
import argparse, gzip, hashlib, json, os, shutil, struct, tempfile
from collections import OrderedDict
from pathlib import Path
from ed2_backup_layout import legacy_paths

VERSION = '0.5.18'
BACKUP = Path('ED2_BACKUP') / 'VGM_BGM_Engine' / 'Core'
EXPECTED_GKEY_SHA = '6cfd9f216d4e7507098a6ff913d2f2c75baa53e5f26d6b73d3ea7790228d4c68'
EXPECTED_GKEY_SIZE = 188412
EXPECTED_RELOCS = 985

# Physical BGM files replaced by this engine. Opening DS2_01_1/DS2_01_2 and ending P28 are excluded.
TARGETS = list(range(2, 28)) + [29]
SLIME_TARGET = 3

ORIGINAL_SHA = {
 'GKEY.EXE': '6cfd9f216d4e7507098a6ff913d2f2c75baa53e5f26d6b73d3ea7790228d4c68',
 'BGM/DS2_02.MUS': '86475d42e61132a665d1256bdbc4d9878f0380ac2d1825d8e97f073eb544ee8d',
 'BGM/DS2_03.MUS': '62981586bac2e0412cb2f07e22077045a603885b885990302b3adab77daf1a7d',
 'BGM/DS2_04.MUS': '24ac8376be8c66e649f3104d7efc85752cf3f2546924d7083c4601afd2043dd9',
 'BGM/DS2_05.MUS': '7bcd70fa168dad86d988ae4e97ad0547784295dfba7dc8419e1aedec86b9819e',
 'BGM/DS2_06.MUS': 'cb63d5d5603b3cd7918beb66ca6ed423b9b7c9918e48bceae9c4614e1b4d0d5b',
 'BGM/DS2_07.MUS': 'eecec73b449dbd2799f0b34b1e3fb12057349e642416056714d13b252f3dadd0',
 'BGM/DS2_08.MUS': '559c2bb128ad69c24758a589a06b7546c3996c9386251d088a0740b350268375',
 'BGM/DS2_09.MUS': '00e34b829acd0edbb88da7a61f7bd7cf157dfa5aef9dbffd46924045245b34cd',
 'BGM/DS2_10.MUS': '5103315fa89b22d70d4bf1b90ad6268fb2c80442dac1a39f125f7e6d8d04fe7e',
 'BGM/DS2_11.MUS': '13622274dcb9091db504d9ffa872b56ee98ba44e2e3cd5709a0916e8b86fb9af',
 'BGM/DS2_12.MUS': 'f087d79590057a9a9691be483b6aa518c1ce70a0aa996224a4f7d46876e2af2f',
 'BGM/DS2_13.MUS': '08bc4ac2b079db2ec0d2289c7cf4b6ca729bf9337a512193c06b9b2b4f3bd5e0',
 'BGM/DS2_14.MUS': '090978c8557974b3464652c2ebd9aed9a0970c629f1fbf9b49f66eb08c0dce5e',
 'BGM/DS2_15.MUS': '5f589571300261d4ed9322a143a25cc0f0631e4ba80e17fe4348e018f0e7339f',
 'BGM/DS2_16.MUS': '18e6f45c19ea2bf2f346eef090a8acbb5e506ed4b061c92e3af722611384cce2',
 'BGM/DS2_17.MUS': '8fbb0f0bd3d0c2b6f16f47f607928b12f149660ed4b9e5ee2aa25d138ab63a91',
 'BGM/DS2_18.MUS': '81c45435a4a72decf3fc746a83c9b2d114c7e1b03f8ba350ca75d11c6cc7a16a',
 'BGM/DS2_19.MUS': '0f2f36378b8466434dfb3f250e0f7fe87496905c4f73b41baac39ddbc75d2c6a',
 'BGM/DS2_20.MUS': 'a08930256c884fad9ea276c4398d3ccd9e9ab878a0ccf287caeb7e5ea763b8fd',
 'BGM/DS2_21.MUS': '51e08b9642609c08053a415f173cb47c61af03a517952e8836080b8d9965e713',
 'BGM/DS2_22.MUS': '9b90b79deb26e69e6cacbb6290f2d5f71bed1ee62b22dba9ee3a0dfc8e7c4625',
 'BGM/DS2_23.MUS': '9fde2c7394679cc6232843129c86d5af04522c956695d15032996c39c507ee68',
 'BGM/DS2_24.MUS': 'b071d7e1ec097e9480e7635e4ce2eebf46b9bbaafa9780873fea58542a5dfb7e',
 'BGM/DS2_25.MUS': '07bdf7a38ac6aa9dfa8fadebdbc6fe1744444ca512123d0f9e922bbb632fa954',
 'BGM/DS2_26.MUS': '99d5067136f229f3b2a82724eb4e4dcc56e1b0801034b34d482cd2af7163b8b6',
 'BGM/DS2_27.MUS': 'b1ef25f09f3e610b29031c585479bbb03c904add7f30600d9c7955e6c3e17b0c',
 'BGM/DS2_29.MUS': '3461b0aed1c012b283fdaed3c99fdf21eb3fe08412153d3cbca7cf95b2e7a2a9',
}

# Source number N maps directly to physical P=N-1.
SOURCE_NAMES = {
 2:'03 Peace.vgz', 3:'04 Slime Bullying.vgz', 4:'05 Ship.vgz', 5:'06 Castle.vgz',
 6:'07 Surprise.vgz', 7:'08 Field.vgz', 8:'09 Battle.vgz', 9:'10 Game Over.vgz',
 10:'11 Underground Castle.vgz', 11:"12 Selios' Departure.vgz", 12:'13 Town.vgz',
 13:'14 Stopper.vgz', 14:'15 Inside the Cave.vgz', 15:'16 Underground Cave.vgz',
 16:'17 Underground Town.vgz', 17:'18 Wrath of the Emperor.vgz', 18:'19 Gail I.vgz',
 19:'20 Grostos Castle.vgz', 20:'21 Barbara.vgz', 21:'22 Resistance Hunting.vgz',
 22:'23 Underground Ruined Town.vgz', 23:'24 Meeting.vgz', 24:'25 Sortie.vgz',
 25:'Grostos Castle 2.vgz', 26:"27 Soldier's Flute.vgz",
 27:'28 Battle with the Emperor.vgz', 29:'30 Utility.vgz',
}

OLD_BACKUPS = [
 '_ED2_GKEY_OPL_LATE_MUTE_V043_BACKUP', '_ED2_GKEY_OPL_FULL_MUTE_V042_BACKUP',
 '_ED2_GKEY_OPL_SINGLE_WRITE_V041_BACKUP', '_ED2_GKEY_PITCH_WRAPPER_V040_BACKUP',
 '_ED2_RAW_OPL_GKEY_BGM3_SLIME_V034_BACKUP', '_ED2_RAW_OPL_GKEY_BGM3_SLIME_V033_BACKUP',
 '_ED2_RAW_OPL_GKEY_BGM3_SLIME_V032_BACKUP', '_ED2_RAW_OPL_GKEY_BGM3_INPLACE_V031_BACKUP',
 '_ED2_RAW_OPL_GKEY_BGM3_TEST_V030_BACKUP',
]

# GKEY patch locations are image-linear offsets (after MZ header).
HOOK_LINEAR = 0xD3A7
HOOK_ORIGINAL = bytes.fromhex('80 3E B2 1C 00')
HOOK_PATCH = bytes.fromhex('E8 70 4A 90 90')  # CALL C7E:563A, then two NOPs
TRAMP_LINEAR = 0x11E1A
TRAMP = bytes.fromhex('5B 0E 53 8C C8 2D DE 08 50 6A 02 CB')
HANDLER_LINEAR = 0x3A02
HANDLER_CAPACITY = 255
HANDLER = (Path(__file__).resolve().parent/'source'/'VGM_COMPACT_HANDLER.BIN').read_bytes()

# GKEY's stock song-loop restart path calls BEB:0810, which writes 0 to almost
# every YM3812 register before restarting the MUS parser.  That is correct for
# stock MUS, but destructive for a custom raw-VGM carrier whose loop point may
# not rewrite every instrument/TL register.  Keep the stock restart bookkeeping
# while suppressing only that full OPL reset for carriers with magic 5647h.
#
# D93A originally contains a relocatable FAR CALL:
#   9A 10 08 EB 0B    lcall 0BEB:0810
# The segment word at D93D is an MZ relocation source.  We replace only the
# first three bytes with a near CALL to a helper and intentionally leave the
# relocated segment word in place as inert data.  The helper advances its saved
# return IP by two bytes, so execution resumes at D93F.  For stock MUS it uses
# that still-relocated word to reproduce the original far call; for custom VGM
# it returns immediately.  Relocation count/table/source therefore stay intact.
LOOP_RESET_CALL_LINEAR = 0xD93A
LOOP_RESET_ORIGINAL = bytes.fromhex('9A 10 08 EB 0B')
LOOP_RESET_PATCH_HEAD = bytes.fromhex('E8 E9 44')  # C7E:115A -> C7E:5646
LOOP_RESET_RELOC_LINEAR = 0xD93D
LOOP_GUARD_LINEAR = TRAMP_LINEAR + len(TRAMP)      # image-linear 11E26 / C7E:5646
LOOP_GUARD = bytes.fromhex(
    '55 89 E5 83 46 02 02 5D '      # saved near-return IP += 2; preserve BP
    '50 06 8C D8 83 E8 07 8E C0 '   # ES = DS - 7 = current carrier header
    '26 81 3E 5B 00 47 56 07 58 '   # magic 5647h? restore ES/AX
    '74 0E '                         # custom carrier: skip destructive reset
    '0E 68 6F 56 '                   # stock: synthetic far-call return C7E:566F
    '2E FF 36 5D 11 '                # push relocated target segment at CS:115D
    '68 10 08 CB C3 C3'              # target 0810; RETF; after/skip RET
)

CARRIER_MAGIC = 0x5647
STREAM_START = 0x006B
PHYSICAL_HZ = 128
TPB = 16
BPM = 240
YM3812_CLOCK = 3579545
MAX_MUSIC_BUFFER = 130000


def sha_bytes(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def sha(p:Path)->str: return sha_bytes(p.read_bytes())
def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def find_ci(parent:Path,name:str,directory=False)->Path:
    direct=parent/name
    if direct.exists() and direct.is_dir()==directory: return direct
    for p in parent.iterdir():
        if p.name.lower()==name.lower() and p.is_dir()==directory: return p
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')

def looks_like_root(root:Path)->bool:
    try:
        find_ci(root,'ED2MAIN.EXE'); find_ci(root,'GKEY.EXE'); find_ci(root,'BGM',True); return True
    except Exception: return False

def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks_like_root(r): raise FileNotFoundError(f'게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen: continue
            seen.add(k)
            if looks_like_root(r): return r
    raise FileNotFoundError('ED2MAIN.EXE / GKEY.EXE / BGM이 함께 있는 게임 폴더를 찾지 못했습니다.')

def game_paths(root=None):
    r=auto_root(root); bgm=find_ci(r,'BGM',True)
    out={'root':r,'gkey':find_ci(r,'GKEY.EXE'),'bgm':bgm}
    for i in TARGETS: out[i]=find_ci(bgm,f'DS2_{i:02d}.MUS')
    return out

def mz_info(b:bytes):
    if len(b)<0x40 or b[:2]!=b'MZ': raise RuntimeError('GKEY.EXE가 MZ 파일이 아닙니다.')
    return u16(b,8)*16,u16(b,6),u16(b,0x18)

def reloc_entries(b:bytes):
    hdr,count,lf=mz_info(b)
    return [struct.unpack_from('<HH',b,lf+i*4) for i in range(count)]

def file_off(b:bytes,linear:int)->int: return mz_info(b)[0]+linear

def patch_gkey(original:bytes)->bytes:
    if len(HANDLER)!=HANDLER_CAPACITY:
        raise RuntimeError(f'내장 VGM handler 크기가 {len(HANDLER)} bytes입니다. 정확히 255여야 합니다.')
    if len(original)!=EXPECTED_GKEY_SIZE or sha_bytes(original)!=EXPECTED_GKEY_SHA:
        raise RuntimeError('지원하는 원본 GKEY.EXE가 아닙니다.')
    hdr,count,lf=mz_info(original)
    if count!=EXPECTED_RELOCS: raise RuntimeError(f'GKEY relocation 개수가 예상과 다릅니다: {count}')
    rels=reloc_entries(original)
    ho=file_off(original,HOOK_LINEAR); to=file_off(original,TRAMP_LINEAR); co=file_off(original,HANDLER_LINEAR)
    lo=file_off(original,LOOP_RESET_CALL_LINEAR); go=file_off(original,LOOP_GUARD_LINEAR)
    if original[ho:ho+5]!=HOOK_ORIGINAL: raise RuntimeError('GKEY D3A7 원본 바이트가 예상과 다릅니다.')
    if original[lo:lo+5]!=LOOP_RESET_ORIGINAL: raise RuntimeError('GKEY D93A OPL reset 호출 바이트가 예상과 다릅니다.')
    if any(original[to:to+len(TRAMP)]): raise RuntimeError('GKEY trampoline 정렬 패딩이 비어 있지 않습니다.')
    if any(original[go:go+len(LOOP_GUARD)]): raise RuntimeError('GKEY loop-reset guard code cave가 비어 있지 않습니다.')
    if any(original[co:co+HANDLER_CAPACITY]): raise RuntimeError('GKEY 03A0:0002 검증 code cave가 비어 있지 않습니다.')
    rel_linear={seg*16+off for off,seg in rels}
    if LOOP_RESET_RELOC_LINEAR not in rel_linear:
        raise RuntimeError('GKEY D93D 원본 FAR CALL segment relocation을 찾지 못했습니다.')
    if any(LOOP_GUARD_LINEAR <= x < LOOP_GUARD_LINEAR+len(LOOP_GUARD) for x in rel_linear):
        raise RuntimeError('GKEY loop-reset guard code cave에 기존 relocation이 있습니다.')
    b=bytearray(original)
    b[ho:ho+5]=HOOK_PATCH
    b[to:to+len(TRAMP)]=TRAMP
    b[go:go+len(LOOP_GUARD)]=LOOP_GUARD
    # Preserve bytes D93D..D93E exactly: they are still the original relocated
    # 0BEBh segment word and are consumed as data by LOOP_GUARD on stock MUS.
    b[lo:lo+3]=LOOP_RESET_PATCH_HEAD
    b[co:co+len(HANDLER)]=HANDLER
    result=bytes(b)
    if len(result)!=len(original): raise RuntimeError('GKEY 파일 크기가 변했습니다.')
    if mz_info(result)!=(hdr,count,lf): raise RuntimeError('GKEY MZ 구조가 변했습니다.')
    if reloc_entries(result)!=rels: raise RuntimeError('GKEY relocation table이 변했습니다.')
    if result[2:0x1c]!=original[2:0x1c]: raise RuntimeError('GKEY load/stack header가 변했습니다.')
    if result[lo+3:lo+5] != original[lo+3:lo+5]:
        raise RuntimeError('GKEY D93D relocated segment word가 변했습니다.')
    if result[go:go+len(LOOP_GUARD)] != LOOP_GUARD:
        raise RuntimeError('GKEY custom loop-reset guard 설치 검증 실패')
    return result

def is_patched_gkey(b:bytes)->bool:
    if len(b)!=EXPECTED_GKEY_SIZE: return False
    try:
        lo=file_off(b,LOOP_RESET_CALL_LINEAR); go=file_off(b,LOOP_GUARD_LINEAR)
        rel_linear={seg*16+off for off,seg in reloc_entries(b)}
        return (b[file_off(b,HOOK_LINEAR):file_off(b,HOOK_LINEAR)+5]==HOOK_PATCH and
                b[file_off(b,TRAMP_LINEAR):file_off(b,TRAMP_LINEAR)+len(TRAMP)]==TRAMP and
                b[file_off(b,HANDLER_LINEAR):file_off(b,HANDLER_LINEAR)+len(HANDLER)]==HANDLER and
                b[lo:lo+3]==LOOP_RESET_PATCH_HEAD and
                b[lo+3:lo+5]==LOOP_RESET_ORIGINAL[3:5] and
                b[go:go+len(LOOP_GUARD)]==LOOP_GUARD and
                LOOP_RESET_RELOC_LINEAR in rel_linear)
    except Exception: return False


def read_vgm_source(path:Path)->bytes:
    raw=path.read_bytes()
    if raw[:2]==b'\x1f\x8b': raw=gzip.decompress(raw)
    if raw[:4]!=b'Vgm ': raise RuntimeError(f'VGM signature가 아닙니다: {path.name}')
    return raw

def parse_vgm(path:Path):
    d=read_vgm_source(path)
    if len(d)<0x80: raise RuntimeError(f'VGM이 너무 짧습니다: {path.name}')
    version=u32(d,8)
    clock=u32(d,0x50)&0x3fffffff
    if clock!=YM3812_CLOCK: raise RuntimeError(f'{path.name}: YM3812 clock={clock}, expected {YM3812_CLOCK}')
    data_rel=u32(d,0x34) if version>=0x150 else 0
    pos=0x34+data_rel if data_rel else 0x40
    total_header=u32(d,0x18)
    loop_rel=u32(d,0x1c)
    loop_abs=0x1c+loop_rel if loop_rel else None
    sample=0; writes=[]; loop_sample=None; commands=set(); boundaries=set(); end_sample=None
    while pos < len(d):
        boundaries.add(pos)
        if loop_abs is not None and pos==loop_abs: loop_sample=sample
        cmd_pos=pos; c=d[pos]; commands.add(c); pos+=1
        if c==0x5a:
            if pos+2>len(d): raise RuntimeError(f'{path.name}: truncated 5A')
            reg,val=d[pos],d[pos+1]; pos+=2
            writes.append((sample,reg,val,cmd_pos))
        elif c==0x61:
            if pos+2>len(d): raise RuntimeError(f'{path.name}: truncated 61')
            sample += u16(d,pos); pos+=2
        elif c==0x62: sample += 735
        elif c==0x63: sample += 882
        elif 0x70<=c<=0x7f: sample += (c&0x0f)+1
        elif c==0x66:
            end_sample=sample; break
        else:
            raise RuntimeError(f'{path.name}: 지원하지 않는 VGM command 0x{c:02X} at 0x{cmd_pos:X}')
    if end_sample is None: raise RuntimeError(f'{path.name}: VGM end command 66h가 없습니다.')
    if total_header and total_header!=end_sample:
        raise RuntimeError(f'{path.name}: header total samples {total_header} != parsed {end_sample}')
    if loop_abs is not None:
        if loop_abs not in boundaries: raise RuntimeError(f'{path.name}: loop offset가 command boundary가 아닙니다.')
        if loop_sample is None: raise RuntimeError(f'{path.name}: loop offset를 재생 데이터에서 찾지 못했습니다.')
    return {'data':d,'version':version,'clock':clock,'writes':writes,'loop_abs':loop_abs,
            'loop_sample':loop_sample,'end_sample':end_sample,'commands':sorted(commands)}

def tick_floor(samples:int)->int: return (samples*PHYSICAL_HZ)//44100

def _is_audible_start_write(reg:int,val:int)->bool:
    if 0xB0<=reg<=0xB8: return bool(val&0x20)
    if reg==0xBD: return bool(val&0x1F)
    return False

def _startup_preroll_plan(vgm):
    writes=vgm['writes']
    tick0=[i for i,(sample,_reg,_val,_pos) in enumerate(writes) if tick_floor(sample)==0]
    if not tick0:
        return {'enabled':False,'split_index':None,'preinit_writes':0,'audible_tick0_writes':0,'reason':'no_tick0_writes'}
    if {writes[i][0] for i in tick0}!={0}:
        return {'enabled':False,'split_index':None,'preinit_writes':len(tick0),'audible_tick0_writes':0,'reason':'tick0_contains_real_subtick_waits'}
    if vgm['loop_sample'] is not None and tick_floor(vgm['loop_sample'])==0:
        return {'enabled':False,'split_index':None,'preinit_writes':0,'audible_tick0_writes':len(tick0),'reason':'loop_begins_in_tick0'}
    first=None
    for i in tick0:
        _sample,reg,val,_pos=writes[i]
        if _is_audible_start_write(reg,val):
            first=i; break
    if first is None:
        return {'enabled':False,'split_index':None,'preinit_writes':len(tick0),'audible_tick0_writes':0,'reason':'no_audible_trigger_in_tick0'}
    preinit=first-tick0[0]
    if preinit<=0:
        return {'enabled':False,'split_index':None,'preinit_writes':0,'audible_tick0_writes':len(tick0),'reason':'first_tick0_write_is_audible'}
    return {'enabled':True,'split_index':first,'preinit_writes':preinit,
            'audible_tick0_writes':tick0[-1]-first+1,'reason':'silent_init_then_audible_start'}

def compile_compact(vgm):
    plan=_startup_preroll_plan(vgm)
    preroll=plan['enabled']; split=plan['split_index']
    groups=OrderedDict()
    for i,(sample,reg,val,pos) in enumerate(vgm['writes']):
        tick=tick_floor(sample)
        if preroll and split is not None and i>=split: tick+=1
        groups.setdefault(tick,[]).append((reg,val,pos,sample))
    loop_tick=tick_floor(vgm['loop_sample']) if vgm['loop_sample'] is not None else None
    if preroll and loop_tick is not None: loop_tick+=1
    end_tick=tick_floor(vgm['end_sample'])+(1 if preroll else 0)
    ticks=set(groups)
    if loop_tick is not None: ticks.add(loop_tick)
    logical=[]
    for tick in sorted(ticks):
        pairs=groups.get(tick,[])
        if loop_tick is not None and tick==loop_tick:
            pre=[x for x in pairs if x[2] < vgm['loop_abs']]
            post=[x for x in pairs if x[2] >= vgm['loop_abs']]
            for n in range(0,len(pre),254): logical.append((tick,'writes',pre[n:n+254]))
            logical.append((tick,'boundary',[]))
            for n in range(0,len(post),254): logical.append((tick,'writes',post[n:n+254]))
        else:
            for n in range(0,len(pairs),254): logical.append((tick,'writes',pairs[n:n+254]))
    logical.append((end_tick,'end',[]))
    out=bytearray(); prev=0; loop_resume=0; max_count=0; filler=0; records=0
    for tick,kind,pairs in logical:
        gap=tick-prev
        while gap>127:
            out += bytes((127,0)); prev+=127; gap=tick-prev; filler+=1; records+=1
        out.append(gap)
        if kind=='boundary':
            out.append(0); loop_resume=len(out)
        elif kind=='end': out.append(255)
        else:
            max_count=max(max_count,len(pairs)); out.append(len(pairs))
            for reg,val,_pos,_sample in pairs: out += bytes((reg,val))
        prev=tick; records+=1
    if loop_resume>0xffff: raise RuntimeError('loop resume offset가 uint16 범위를 넘었습니다.')
    return bytes(out),loop_resume,{
        'loop_tick':loop_tick,'end_tick':end_tick,'max_count':max_count,'fillers':filler,'records':records,
        'startup_preroll_enabled':preroll,'startup_preroll_ticks':1 if preroll else 0,
        'startup_preinit_writes':plan['preinit_writes'],'startup_audible_tick0_writes':plan['audible_tick0_writes'],
        'startup_preroll_reason':plan['reason'],'startup_split_write_index':split,
    }

def build_carrier(vgm_path:Path,physical_id:int):
    vgm=parse_vgm(vgm_path); stream,loop_resume,cm=compile_compact(vgm)
    loop_field=loop_resume+1
    if not 1<=loop_field<=65535: raise RuntimeError(f'{vgm_path.name}: loop field overflow')
    h=bytearray(97); h[0]=9
    if vgm['loop_abs'] is None:
        carrier_ticks=max(1,min(65535,(vgm['end_sample']*64 + 44099)//44100 + (1 if cm['startup_preroll_enabled'] else 0)))
    else:
        carrier_ticks=65535
    struct.pack_into('<H',h,1,carrier_ticks)
    struct.pack_into('<H',h,1+10*2,loop_field)
    struct.pack_into('<HHHH',h,89,TPB,CARRIER_MAGIC,BPM,1)
    prefix=bytearray(h)
    prefix += struct.pack('<HH',0,100)
    prefix += bytes((0,))+struct.pack('<H',carrier_ticks)
    prefix += bytes((0,))+struct.pack('<H',loop_field)
    if len(prefix)!=STREAM_START: raise RuntimeError(f'carrier prefix size internal error: {len(prefix)}')
    carrier=bytes(prefix)+stream
    if len(carrier)>=MAX_MUSIC_BUFFER:
        raise RuntimeError(f'{vgm_path.name}: carrier {len(carrier)} >= GKEY music buffer {MAX_MUSIC_BUFFER}')
    validate_carrier(carrier,vgm,loop_resume)
    return carrier, {
        'physical_id':physical_id,'source':vgm_path.name,'source_sha256':sha(vgm_path),
        'source_uncompressed_bytes':len(vgm['data']),'source_writes':len(vgm['writes']),
        'source_seconds':vgm['end_sample']/44100.0,'source_loop_seconds':None if vgm['loop_sample'] is None else vgm['loop_sample']/44100.0,
        'compact_bytes':len(stream),'carrier_bytes':len(carrier),'loop_resume_offset':loop_resume,'carrier_logical_ticks':carrier_ticks,
        'loop_tick':cm['loop_tick'],'end_tick':cm['end_tick'],'max_writes_per_record':cm['max_count'],'wait_fillers':cm['fillers'],
        'startup_preroll_enabled':cm['startup_preroll_enabled'],'startup_preroll_ticks':cm['startup_preroll_ticks'],
        'startup_preinit_writes':cm['startup_preinit_writes'],'startup_audible_tick0_writes':cm['startup_audible_tick0_writes'],
        'startup_preroll_reason':cm['startup_preroll_reason'],
    }


def decode_stream(stream:bytes,start=0):
    pos=start; tick=0; writes=[]; records=0
    while True:
        if pos+2>len(stream): raise RuntimeError('compact stream truncated')
        delta=stream[pos]; count=stream[pos+1]; pos+=2; tick+=delta; records+=1
        if count==255: return writes,tick,pos,records
        need=count*2
        if pos+need>len(stream): raise RuntimeError('compact pair list truncated')
        for _ in range(count):
            writes.append((tick,stream[pos],stream[pos+1])); pos+=2

def validate_carrier(carrier:bytes,vgm,loop_resume:int):
    if carrier[0]!=9 or u16(carrier,1)==0: raise RuntimeError('carrier header basic fields invalid')
    if u16(carrier,89)!=TPB or u16(carrier,91)!=CARRIER_MAGIC or u16(carrier,93)!=BPM or u16(carrier,95)!=1:
        raise RuntimeError('carrier timing/magic invalid')
    if carrier[97:101]!=struct.pack('<HH',0,100): raise RuntimeError('carrier tempo event invalid')
    if carrier[101]!=0 or u16(carrier,102)!=u16(carrier,1): raise RuntimeError('carrier voice0 rest invalid')
    lf=u16(carrier,21)
    if carrier[104]!=0 or u16(carrier,105)!=lf: raise RuntimeError('carrier voice10 parser rest invalid')
    stream=carrier[STREAM_START:]
    # v0.5.10+ handler uses a signed DEC/JG countdown; every compact delta must be <=127.
    pos_chk=0
    while True:
        if pos_chk+2>len(stream): raise RuntimeError('compact stream truncated during delta-range validation')
        delta_chk=stream[pos_chk]; count_chk=stream[pos_chk+1]; pos_chk+=2
        if delta_chk>127: raise RuntimeError(f'compact delta {delta_chk} exceeds v0.5.9 signed-safe maximum 127')
        if count_chk==255: break
        pos_chk += count_chk*2
    got,_,_,_=decode_stream(stream,0)
    src=[(r,v) for _s,r,v,_p in vgm['writes']]
    if [(r,v) for _t,r,v in got]!=src: raise RuntimeError('compact first-pass OPL sequence differs from source VGM')
    plan=_startup_preroll_plan(vgm); split=plan['split_index']
    for i,((tick,r,v),(sample,sr,sv,_p)) in enumerate(zip(got,vgm['writes'])):
        if (r,v)!=(sr,sv): raise RuntimeError('compact sequence mismatch')
        expected=tick_floor(sample)
        if plan['enabled'] and split is not None and i>=split: expected+=1
        if tick!=expected:
            raise RuntimeError(f'compact startup/timing mismatch at write {i}: got {tick}, expected {expected}')
    if vgm['loop_abs'] is None:
        if loop_resume!=0: raise RuntimeError('one-shot VGM unexpectedly has loop pointer')
    else:
        if loop_resume<=0 or loop_resume>=len(stream): raise RuntimeError('invalid compact loop pointer')
        loop_got,loop_end_tick,_,_=decode_stream(stream,loop_resume)
        loop_src_full=[(s,r,v,p) for s,r,v,p in vgm['writes'] if p>=vgm['loop_abs']]
        loop_src=[(r,v) for _s,r,v,_p in loop_src_full]
        if [(r,v) for _t,r,v in loop_got]!=loop_src: raise RuntimeError('compact loop OPL sequence differs from VGM loop sequence')
        # Relative loop timing must also survive quantization exactly.
        base_tick=tick_floor(vgm['loop_sample'])
        for (t,r,v),(s,sr,sv,_p) in zip(loop_got,loop_src_full):
            if (r,v)!=(sr,sv) or t != tick_floor(s)-base_tick:
                raise RuntimeError('compact loop timing differs from quantized VGM loop timing')
        if loop_end_tick != tick_floor(vgm['end_sample'])-base_tick:
            raise RuntimeError('compact loop end timing differs from quantized VGM loop duration')


def source_dir()->Path: return Path(__file__).resolve().parent/'VGM_SOURCE'
def compile_target(i:int):
    name=SOURCE_NAMES[i]; p=source_dir()/name
    if not p.is_file(): raise FileNotFoundError(f'VGM source missing: {p}')
    return build_carrier(p,i)

def valid_backup(bdir:Path):
    m=bdir/'manifest.json'
    if not m.is_file(): return None
    try: o=json.loads(m.read_text(encoding='utf-8'))
    except Exception: return None
    for rel,h in o.get('files',{}).items():
        q=bdir/rel
        if not q.is_file() or sha(q)!=h: return None
    return o

def restore_own_backup(p)->bool:
    b=p['root']/BACKUP; o=valid_backup(b)
    if not o: return False
    for rel,h in ORIGINAL_SHA.items():
        q=b/rel
        if not q.is_file() or sha(q)!=h: return False
    shutil.copy2(b/'GKEY.EXE',p['gkey'])
    for i in TARGETS: shutil.copy2(b/f'BGM/DS2_{i:02d}.MUS',p[i])
    return True

def restore_old_backup(p,bdir:Path)->bool:
    o=valid_backup(bdir)
    if not o: return False
    g=bdir/'GKEY.EXE'; m=bdir/'BGM/DS2_03.MUS'
    if not g.is_file() or sha(g)!=ORIGINAL_SHA['GKEY.EXE']: return False
    if not m.is_file() or sha(m)!=ORIGINAL_SHA['BGM/DS2_03.MUS']: return False
    shutil.copy2(g,p['gkey']); shutil.copy2(m,p[3]); return True

def baseline_all(p)->bool:
    if sha(p['gkey'])!=ORIGINAL_SHA['GKEY.EXE']: return False
    return all(sha(p[i])==ORIGINAL_SHA[f'BGM/DS2_{i:02d}.MUS'] for i in TARGETS)

def normalize(p):
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        if baseline_all(p):
            return None
        raise RuntimeError('올인원 stock-only 모드에서는 정확한 ED2(8) GKEY/BGM만 허용합니다.')
    if baseline_all(p): return None
    if restore_own_backup(p): return BACKUP
    aio_tx = restore_aio_backup(p)
    if aio_tx is not None: return f"AIO:{aio_tx}"
    for bdir in legacy_paths(p['root'], OLD_BACKUPS):
        if restore_old_backup(p,bdir):
            if baseline_all(p): return bdir.name
            break
    raise RuntimeError('현재 GKEY/BGM이 지원 원본과 다르고 검증된 원본 백업도 찾지 못했습니다. 아무 파일도 수정하지 않았습니다.')

def ensure_backup(p):
    if os.environ.get("ED2_AIO_NO_COMPONENT_BACKUP") == "1":
        return
    b=p['root']/BACKUP
    if valid_backup(b):
        if not restore_own_backup(p): raise RuntimeError('v0.5.0 백업이 손상되었거나 지원 원본이 아닙니다.')
        return b
    if not baseline_all(p): raise RuntimeError('백업 생성 전 전체 대상 BGM/GKEY가 원본이 아닙니다.')
    (b/'BGM').mkdir(parents=True,exist_ok=True)
    shutil.copy2(p['gkey'],b/'GKEY.EXE')
    for i in TARGETS: shutil.copy2(p[i],b/f'BGM/DS2_{i:02d}.MUS')
    manifest={'version':VERSION,'files':ORIGINAL_SHA}
    (b/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return b

def apply(root,mode):
    p=game_paths(root); migrated=normalize(p); ensure_backup(p)
    patched=patch_gkey(p['gkey'].read_bytes())
    todo=[SLIME_TARGET] if mode=='slime' else TARGETS
    built={}; report=[]
    for i in todo:
        carrier,meta=compile_target(i); built[i]=carrier; report.append(meta)
    # All validation/build completes before modifying live files.
    atomic(p['gkey'],patched)
    for i,data in built.items(): atomic(p[i],data)
    (p['root']/f'ED2_VGM_BGM_{mode.upper()}_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'ED2 VGM BGM Engine v{VERSION} 적용 완료: {mode}')
    print('GKEY size/relocation/PIT/IRQ flow는 유지하며, custom carrier의 stock-loop OPL full-reset만 조건부 차단합니다.')
    print('GKEY fade/OFF 상태(word [1C1E] != 0)에서는 VGM cursor를 동결하고, 정상 상태로 복귀하면 현재 VGM을 처음부터 재초기화합니다.')
    print('물리 timer: 128 Hz. 첫 physical IRQ는 silent OPL pre-init, 다음 IRQ부터 audible key-on을 시작합니다.')
    print('INS, ED2MAIN, Opening DS2_01_1/DS2_01_2, Ending P28은 수정하지 않았습니다.')
    if migrated: print('이전 시험 패치에서 정상 원본으로 자동 복원:',migrated)
    if mode=='slime': print('현재는 P03 = Slime Bullying 한 곡만 VGM 엔진입니다.')
    else: print('현재는 P02~P27 + P29, 총 27곡이 VGM 엔진입니다.')

def restore(root):
    p=game_paths(root)
    if restore_own_backup(p):
        print('v0.5.0 적용 전 원본 GKEY + 본편 대상 MUS 27개를 복원했습니다.'); return
    for bdir in legacy_paths(p['root'], OLD_BACKUPS):
        if restore_old_backup(p,bdir):
            print('이전 시험의 검증된 원본 GKEY/DS2_03으로 복원했습니다:',bdir.name); return
    raise RuntimeError('검증된 원본 백업을 찾지 못했습니다. 아무 파일도 수정하지 않았습니다.')

def status(root):
    p=game_paths(root); g=p['gkey'].read_bytes()
    print('game root:',p['root'])
    print('GKEY sha256:',sha(p['gkey']))
    print(f'GKEY v{VERSION} hook:',is_patched_gkey(g))
    if is_patched_gkey(g): print('custom loop OPL-reset guard: True (stock MUS reset preserved)')
    custom=[]
    for i in TARGETS:
        b=p[i].read_bytes()
        if len(b)>=STREAM_START and u16(b,91)==CARRIER_MAGIC and u16(b,89)==TPB and u16(b,93)==BPM: custom.append(i)
    print('VGM carrier physical slots:',','.join(f'P{i:02d}' for i in custom) if custom else '(none)')
    print('backup:',(p['root']/BACKUP/'manifest.json').is_file())

def compile_report():
    rows=[]
    for i in TARGETS:
        _carrier,meta=compile_target(i); rows.append(meta)
    print(json.dumps(rows,ensure_ascii=False,indent=2))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('action',choices=['apply-slime','apply-all','restore','status','compile-report'])
    ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args(); root=None if a.game_root=='auto' else a.game_root
    try:
        if a.action=='apply-slime': apply(root,'slime')
        elif a.action=='apply-all': apply(root,'all')
        elif a.action=='restore': restore(root)
        elif a.action=='status': status(root)
        else: compile_report()
        return 0
    except Exception as exc:
        print(); print(f'[ERROR] {type(exc).__name__}: {exc}')
        print('패치를 중단했습니다. 위 오류를 그대로 알려 주세요.')
        return 1
if __name__=='__main__': raise SystemExit(main())
