# ED2 VGM BGM Engine v0.5.49 Combined

한국 DOS판 영웅전설 II에서 YM3812 VGM 기반 BGM을 재생하기 위한 통합 패치 구성요소입니다.

- 사용자 지정 VGM carrier 재생
- 곡별 루프 정보 유지
- 일반 BGM 정지 시 hard-stop 정책
- 전투/장면별 전용 음악 매핑
- 전사의 피리 및 최종전 구성요소와 hook 영역을 분리

일반 사용자는 AIO의 `vgm_bgm` 구성요소로 적용하는 것을 권장합니다. 직접 VGM을 `DS2_xx.MUS`로 변환하려면 `TOOLS/ED2_Raw_OPL_Converter_v0.1.5`를 사용하십시오.

## Music source mode

`patch_music_source_mode.py`는 두 BGM 소스 모드를 제공합니다.

```text
python patch_music_source_mode.py custom C:\ED2
python patch_music_source_mode.py original C:\ED2 --stock-files-root C:\ED2_STOCK_BACKUP\GAME_FILES
python patch_music_source_mode.py status-original C:\ED2
```

`original`은 순정 GKEY/MUS와 순정 곡 매핑을 사용하면서 hard-stop/BGM 제어 수정은 유지합니다. 이미 VGM carrier로 교체된 MUS를 순정으로 되돌리려면 검증된 순정 백업이 필요합니다.
