@echo off
python patch_combined.py status auto
pause
