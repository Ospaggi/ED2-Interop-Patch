@echo off
python patch_combined.py restore auto
if errorlevel 1 goto error
echo.
echo Original audio/BGM control restored.
pause
exit /b 0
:error
pause
exit /b 1
