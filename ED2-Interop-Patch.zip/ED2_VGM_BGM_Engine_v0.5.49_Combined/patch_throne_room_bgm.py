#!/usr/bin/env python3
from __future__ import annotations

import os
import argparse, hashlib, json, os, shutil, struct, tempfile
from pathlib import Path

VERSION = '0.5.26'
BACKUP = Path('ED2_BACKUP') / 'VGM_BGM_Engine' / 'Throne_Room_BGM31'
MANIFEST = 'manifest.json'

# ED2MAIN logical -> physical BGM table: L00..L31, uint16 entries.
MAP_SEG = 12
MAP_OFF = 0x11AE
MAP_COUNT = 32
THRONE_LOGICAL = 15
THRONE_STOCK_PHYSICAL = 27
THRONE_CUSTOM_PHYSICAL = 31
BATTLE_LOGICAL = 16
BATTLE_PHYSICAL = 27

# Throne-room entry proof. This transition is not modified; it is only
# verified so remapping L15 cannot silently target the wrong scene.
C634_SEG = 3
C634_RECORD_OFF = 0x0015
REC_LEN = 34
REC_MAP_OFF = 5
REC_SIN_OFF = 12
REC_BC_OFF = 15
REC_BGM_OFF = 16
REC_TOWN_OFF = 18
EXPECTED_DEST_SIN = 0x0734  # C_734.DLL
EXPECTED_MAP = 5
EXPECTED_BC = 19
EXPECTED_BGM = THRONE_LOGICAL
EXPECTED_TOWN = 49          # ED2MAIN area name: 옥좌의방

# C_734 explicitly reloads L16 before the Godwin II combat sequence.
# 0721: B0 10       mov al,10h (L16)
# 0723: 9A ....     far call LOAD_BGM (relocation source 0724)
C734_SEG = 3
C734_BATTLE_MOV_OFF = 0x0721
C734_BATTLE_MOV = bytes.fromhex('B0 10')


def u16(b,o): return struct.unpack_from('<H', b, o)[0]
def u32(b,o): return struct.unpack_from('<I', b, o)[0]
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p:Path): return sha_bytes(p.read_bytes())


def atomic(path:Path, data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.throne526.', dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def find_ci(parent:Path,name:str,directory=False)->Path:
    direct=parent/name
    if direct.exists() and direct.is_dir()==directory: return direct
    for p in parent.iterdir():
        if p.name.lower()==name.lower() and p.is_dir()==directory: return p
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')


def looks(root:Path)->bool:
    try:
        find_ci(root,'ED2MAIN.EXE'); bgm=find_ci(root,'BGM',True); scena=find_ci(root,'SCENA',True)
        find_ci(bgm,'DS2_27.MUS'); find_ci(bgm,'DS2_27.INS'); find_ci(scena,'C_634.DLL'); find_ci(scena,'C_734.DLL')
        return True
    except Exception: return False


def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r): raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent, Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen: continue
            seen.add(k)
            if looks(r): return r
    raise FileNotFoundError('ED2MAIN.EXE / BGM / SCENA/C_634.DLL / C_734.DLL이 함께 있는 게임 폴더를 찾지 못했습니다.')


def paths(root=None):
    r=auto_root(root); bgm=find_ci(r,'BGM',True); scena=find_ci(r,'SCENA',True)
    return {
        'root':r, 'ed2':find_ci(r,'ED2MAIN.EXE'), 'bgm':bgm,
        'p27m':find_ci(bgm,'DS2_27.MUS'), 'p27i':find_ci(bgm,'DS2_27.INS'),
        'p31m':bgm/'DS2_31.MUS', 'p31i':bgm/'DS2_31.INS',
        'c634':find_ci(scena,'C_634.DLL'), 'c734':find_ci(scena,'C_734.DLL'),
        'backup':r/BACKUP,
    }


def ne_segments(b:bytes):
    if len(b)<0x40 or b[:2]!=b'MZ': raise RuntimeError('MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE': raise RuntimeError('16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c); table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    out=[]
    for i in range(count):
        ep=table+i*8; sector,length,flags,alloc=struct.unpack_from('<HHHH',b,ep)
        out.append({'index':i+1,'base':sector<<shift,'length':65536 if length==0 else length,'flags':flags,'alloc':alloc})
    return out


def seg(b:bytes,index:int):
    ss=ne_segments(b)
    if not 1<=index<=len(ss): raise RuntimeError(f'NE segment {index}가 없습니다.')
    return ss[index-1]


def map_file_offset(b:bytes,logical:int)->int:
    if not 0<=logical<MAP_COUNT: raise RuntimeError('BGM logical ID 범위 오류')
    s=seg(b,MAP_SEG); off=MAP_OFF+logical*2
    if off+2>s['length']: raise RuntimeError('BGM mapping table이 segment 범위를 벗어났습니다.')
    return s['base']+off


def map_value(b:bytes,logical:int)->int: return u16(b,map_file_offset(b,logical))


def code_at(b:bytes,seg_index:int,off:int,n:int)->bytes:
    s=seg(b,seg_index)
    if off+n>s['length']: raise RuntimeError(f'segment {seg_index}:{off:04X} 범위 오류')
    return b[s['base']+off:s['base']+off+n]


def verify_scene_anchors(c634:bytes,c734:bytes):
    rec=code_at(c634,C634_SEG,C634_RECORD_OFF,REC_LEN)
    values={
        'map':rec[REC_MAP_OFF], 'sin':u16(rec,REC_SIN_OFF), 'bc':rec[REC_BC_OFF],
        'bgm':rec[REC_BGM_OFF], 'town':rec[REC_TOWN_OFF],
    }
    expected={'map':EXPECTED_MAP,'sin':EXPECTED_DEST_SIN,'bc':EXPECTED_BC,'bgm':EXPECTED_BGM,'town':EXPECTED_TOWN}
    if values!=expected:
        raise RuntimeError(f'C_634 옥좌의 방 전환 레코드가 예상과 다릅니다: {values}, expected {expected}')
    if code_at(c734,C734_SEG,C734_BATTLE_MOV_OFF,2)!=C734_BATTLE_MOV:
        raise RuntimeError('C_734 최종전 LOAD_BGM(L16) 앵커가 예상과 다릅니다.')
    return values


def load_manifest(bdir:Path):
    p=bdir/MANIFEST
    if not p.is_file(): return None
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: raise RuntimeError(f'{p}를 읽을 수 없습니다: {e}')


def write_manifest(bdir:Path,m:dict):
    bdir.mkdir(parents=True,exist_ok=True)
    (bdir/MANIFEST).write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def preflight(root=None):
    p=paths(root); eb=p['ed2'].read_bytes(); c634=p['c634'].read_bytes(); c734=p['c734'].read_bytes()
    verify_scene_anchors(c634,c734)
    l15=map_value(eb,THRONE_LOGICAL); l16=map_value(eb,BATTLE_LOGICAL)
    if l15 not in (THRONE_STOCK_PHYSICAL,THRONE_CUSTOM_PHYSICAL):
        raise RuntimeError(f'ED2MAIN L15 mapping 지원 불가: P{l15}')
    if l16!=BATTLE_PHYSICAL:
        raise RuntimeError(f'ED2MAIN L16은 P27이어야 합니다. 현재 P{l16}')
    if p['p27m'].stat().st_size==0 or p['p27i'].stat().st_size==0:
        raise RuntimeError('DS2_27.MUS/INS가 비어 있습니다.')
    return p


def apply(root=None):
    p=preflight(root); eb=p['ed2'].read_bytes(); aio_no_backup=os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP')=='1'; existing=None if aio_no_backup else load_manifest(p['backup'])
    if existing is None:
        m={
            'version':VERSION,
            'original_ed2main_sha256':sha_bytes(eb),
            'original_l15_physical':map_value(eb,THRONE_LOGICAL),
            'l16_physical':map_value(eb,BATTLE_LOGICAL),
            'created_ds2_31_mus':False,
            'created_ds2_31_ins':False,
        }
    else:
        m=existing

    # Create a safe stock-equivalent placeholder only when the new slot does not exist.
    # P27 is already the raw-VGM Battle with the Emperor carrier after the VGM core step,
    # so an untouched installation behaves exactly as before until the user replaces P31.
    if not p['p31m'].exists():
        shutil.copy2(p['p27m'],p['p31m']); m['created_ds2_31_mus']=True; m['placeholder_mus_sha']=sha_file(p['p31m'])
    if not p['p31i'].exists():
        shutil.copy2(p['p27i'],p['p31i']); m['created_ds2_31_ins']=True; m['placeholder_ins_sha']=sha_file(p['p31i'])

    if map_value(eb,THRONE_LOGICAL)==THRONE_STOCK_PHYSICAL:
        x=bytearray(eb); struct.pack_into('<H',x,map_file_offset(eb,THRONE_LOGICAL),THRONE_CUSTOM_PHYSICAL); atomic(p['ed2'],bytes(x)); m['map_changed']=True
    else:
        m.setdefault('map_changed',False)
    m['applied_ed2main_sha256']=sha_file(p['ed2'])
    m['ds2_31_mus_sha256_at_apply']=sha_file(p['p31m'])
    m['ds2_31_ins_sha256_at_apply']=sha_file(p['p31i'])
    if not aio_no_backup: write_manifest(p['backup'],m)
    print('옥좌의 방 전용 BGM 적용 완료.')
    print('L15 -> P31 -> BGM/DS2_31.MUS')
    print('L16 -> P27 유지 (Battle with the Emperor)')


def restore(root=None):
    p=paths(root); m=load_manifest(p['backup'])
    if m is None:
        print('옥좌의 방 패치 backup manifest가 없습니다. 변경하지 않았습니다.')
        return
    eb=p['ed2'].read_bytes()
    if m.get('map_changed') and map_value(eb,THRONE_LOGICAL)==THRONE_CUSTOM_PHYSICAL:
        x=bytearray(eb); struct.pack_into('<H',x,map_file_offset(eb,THRONE_LOGICAL),int(m.get('original_l15_physical',THRONE_STOCK_PHYSICAL))); atomic(p['ed2'],bytes(x))
    removed=[]
    for path,ckey,hkey in [(p['p31m'],'created_ds2_31_mus','placeholder_mus_sha'),(p['p31i'],'created_ds2_31_ins','placeholder_ins_sha')]:
        if m.get(ckey) and path.exists() and m.get(hkey) and sha_file(path)==m[hkey]:
            path.unlink(); removed.append(path.name)
    if removed: print('변경되지 않은 placeholder 삭제:',', '.join(removed))
    # Keep the backup if user custom P31 remains, otherwise remove it.
    custom_remains=(p['p31m'].exists() and m.get('created_ds2_31_mus')) or (p['p31i'].exists() and m.get('created_ds2_31_ins'))
    if not custom_remains:
        shutil.rmtree(p['backup'],ignore_errors=True)
    print('옥좌의 방 BGM mapping 복원 완료. 사용자 변경 DS2_31은 보존합니다.')


def status(root=None):
    p=preflight(root); eb=p['ed2'].read_bytes(); m=load_manifest(p['backup'])
    l15=map_value(eb,THRONE_LOGICAL); l16=map_value(eb,BATTLE_LOGICAL)
    print('=== Throne room BGM v0.5.26 ===')
    print('C_634 -> C_734: town49 / L15 (옥좌의방)')
    print(f'L15 -> P{l15}')
    print(f'L16 -> P{l16} (final battle)')
    print('DS2_31.MUS:', 'present' if p['p31m'].exists() else 'missing', sha_file(p['p31m']) if p['p31m'].exists() else '')
    print('DS2_31.INS:', 'present' if p['p31i'].exists() else 'missing', sha_file(p['p31i']) if p['p31i'].exists() else '')
    print('backup manifest:', 'present' if m else 'missing')
    ready=(l15==THRONE_CUSTOM_PHYSICAL and l16==BATTLE_PHYSICAL and p['p31m'].is_file() and p['p31i'].is_file())
    print('ready:', ready)
    return ready


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['apply','restore','status']); ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args(); root=None if a.game_root=='auto' else a.game_root
    try:
        {'apply':apply,'restore':restore,'status':status}[a.action](root); return 0
    except Exception as e:
        print(); print(f'[ERROR] {type(e).__name__}: {e}'); return 1
if __name__=='__main__': raise SystemExit(main())
