#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, struct, tempfile
from pathlib import Path

VERSION = '0.5.35'
SEG_INDEX = 86
STOCK_SEG_LEN = 0xB844
RELOC_COUNT = 1630

# Fixed code-cave layout. These two slots are owned by the VGM/flute patches.
# Text Patch R31 independently reserves NE86:0300 for the stun-status helper;
# keep ownership disjoint and avoid segment growth.
BATTLE_CAVE_OFF = 0x0100
FLUTE_CAVE_OFF = 0x0200

# The battle wrapper contains a near CALL back to LOAD_BGM_SET.  The old
# append-at-end form lived at 86:B844, so its relative displacement was 7F9Bh.
# When v0.5.33 moved the byte blob to 86:0100 without rebasing that CALL, the
# same bytes jumped to 86:80B7 and corrupted the common battle-return path.
# Keep both encodings explicit so old installs can be detected and repaired.
BATTLE_WRAPPER_FIXED = bytes.fromhex(
    '9C 50 53 51 52 56 57 55 1E 06 '
    'B4 01 CD 40 '
    '07 1F 5D 5F 5E 5A 59 5B 58 9D '
    '0E E8 DF 36 CB'
)
BATTLE_WRAPPER_TAIL = bytes.fromhex(
    '9C 50 53 51 52 56 57 55 1E 06 '
    'B4 01 CD 40 '
    '07 1F 5D 5F 5E 5A 59 5B 58 9D '
    '0E E8 9B 7F CB'
)
# v0.5.33/v0.5.34 accidentally wrote the tail encoding at the fixed slot.
BATTLE_WRAPPER_BROKEN_FIXED = BATTLE_WRAPPER_TAIL
BATTLE_WRAPPER = BATTLE_WRAPPER_FIXED
# Soldier's Flute wrappers are known only so an older append-at-end layout can
# be migrated without breaking that independent patch.
FLUTE_WRAPPER = bytes.fromhex(
    '9C '
    '80 3E 47 20 00 74 1F '
    '80 3E D6 3E 12 75 18 '
    '50 51 52 '
    'B9 C9 01 '
    'BA DA 03 '
    'EC A8 08 75 FB '
    'EC A8 08 74 FB '
    'E2 F4 '
    '5A 59 58 9D CB'
)
OLD_FLUTE_WRAPPER = bytes.fromhex(
    '9C '
    '80 3E 47 20 00 74 17 '
    '80 3E D6 3E 12 75 10 '
    '50 51 52 '
    'B4 86 B9 74 00 BA D0 BA CD 15 '
    '5A 59 58 9D CB'
)

BATTLE_RELOC_INDEX = 168
BATTLE_RELOC_SRC = 0x351D
FLUTE_RELOC_SRC = 0x820E
TARGET_LOAD_BGM_SET = (86, 0x37FB)
TARGET_BATTLE_CAVE = (86, BATTLE_CAVE_OFF)
ENTRY_PREFIX = bytes.fromhex('A0 0D 20 9A FF FF 00 00')
NEIGHBOR_167 = (3, 0, 0x3509, 86, 0x4DEA)
NEIGHBOR_169 = (3, 0, 0x3524, 86, 0x941C)


def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.battleend.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def find_ci(parent:Path,name:str,directory=False)->Path:
    p=parent/name
    if p.exists() and p.is_dir()==directory:return p
    for q in parent.iterdir():
        if q.name.lower()==name.lower() and q.is_dir()==directory:return q
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')

def looks(root:Path)->bool:
    try: find_ci(root,'ED2MAIN.EXE'); find_ci(root,'GKEY.EXE'); return True
    except Exception:return False

def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r):raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen:continue
            seen.add(k)
            if looks(r):return r
    raise FileNotFoundError('ED2MAIN.EXE / GKEY.EXE가 함께 있는 게임 폴더를 찾지 못했습니다.')

def ne_info(b:bytes):
    if len(b)<0x40 or b[:2]!=b'MZ':raise RuntimeError('ED2MAIN.EXE가 MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE':raise RuntimeError('ED2MAIN.EXE가 16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c)
    if count < SEG_INDEX+1:raise RuntimeError('ED2MAIN.EXE의 NE segment 수가 예상보다 적습니다.')
    table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    return ne,table,shift,count

def segment_record(b:bytes,index:int=SEG_INDEX):
    ne,table,shift,count=ne_info(b)
    p=table+(index-1)*8
    sec,length,flags,alloc=struct.unpack_from('<HHHH',b,p)
    return p,sec<<shift,(0x10000 if length==0 else length),flags,alloc

def next_segment_base(b:bytes): return segment_record(b,SEG_INDEX+1)[1]

def reloc_layout(b:bytes):
    sp,base,seglen,flags,alloc=segment_record(b)
    if not (flags & 0x0100):raise RuntimeError('NE86에 relocation table flag가 없습니다.')
    roff=base+seglen
    if roff+2>len(b):raise RuntimeError('NE86 relocation table가 없습니다.')
    count=u16(b,roff)
    if count!=RELOC_COUNT:raise RuntimeError(f'NE86 relocation 개수가 예상과 다릅니다: {count}')
    rend=roff+2+count*8; nxt=next_segment_base(b)
    if rend>nxt:raise RuntimeError('NE86 relocation table가 다음 segment와 겹칩니다.')
    return sp,base,seglen,flags,alloc,roff,count,rend,nxt

def reloc_at_from_layout(b:bytes,roff:int,index:int):
    p=roff+2+index*8
    return p,struct.unpack_from('<BBHHH',b,p)

def find_reloc_index_by_source(b:bytes,roff:int,src:int):
    hits=[]
    for i in range(RELOC_COUNT):
        p=roff+2+i*8; r=struct.unpack_from('<BBHHH',b,p)
        if r[2]==src:hits.append((i,p,r))
    if len(hits)!=1:raise RuntimeError(f'NE86 relocation source {src:04X} 특정 실패: {len(hits)}')
    return hits[0]

def bytes_at(b:bytes,base:int,off:int,n:int): return b[base+off:base+off+n]

def is_zero_slot(b:bytes,base:int,off:int,n:int): return bytes_at(b,base,off,n)==b'\0'*n

def wrapper_kind_at(b:bytes,base:int,off:int):
    if off<0:return None
    if bytes_at(b,base,off,len(BATTLE_WRAPPER_FIXED))==BATTLE_WRAPPER_FIXED:return 'battle_fixed'
    if bytes_at(b,base,off,len(BATTLE_WRAPPER_TAIL))==BATTLE_WRAPPER_TAIL:return 'battle_tail'
    if bytes_at(b,base,off,len(FLUTE_WRAPPER))==FLUTE_WRAPPER:return 'flute'
    if bytes_at(b,base,off,len(OLD_FLUTE_WRAPPER))==OLD_FLUTE_WRAPPER:return 'flute_old'
    return None

def fixed_battle_near_target(b:bytes,base:int):
    # E8 rel16 starts at 86:0119 and returns to 86:011C.
    if bytes_at(b,base,BATTLE_CAVE_OFF+0x19,1)!=b'\xE8':return None
    disp=struct.unpack_from('<h',b,base+BATTLE_CAVE_OFF+0x1A)[0]
    return (BATTLE_CAVE_OFF+0x1C+disp)&0xFFFF

def tail_is_only_known_wrappers(b:bytes,base:int,seglen:int):
    if seglen<STOCK_SEG_LEN:return False
    pos=STOCK_SEG_LEN
    while pos<seglen:
        kind=wrapper_kind_at(b,base,pos)
        if kind=='battle_tail': pos+=len(BATTLE_WRAPPER_TAIL)
        elif kind=='flute': pos+=len(FLUTE_WRAPPER)
        elif kind=='flute_old': pos+=len(OLD_FLUTE_WRAPPER)
        else:return False
    return pos==seglen

def validate_common(b:bytes):
    sp,base,seglen,flags,alloc,roff,count,rend,nxt=reloc_layout(b)
    if seglen<STOCK_SEG_LEN:raise RuntimeError(f'NE86 길이가 예상보다 짧습니다: {seglen:04X}')
    if b[base+0x3519:base+0x3519+len(ENTRY_PREFIX)]!=ENTRY_PREFIX:
        raise RuntimeError('END_OF_BATTLE 86:3519 코드가 지원 형태와 다릅니다.')
    _,r167=reloc_at_from_layout(b,roff,167); p168,r168=reloc_at_from_layout(b,roff,BATTLE_RELOC_INDEX); _,r169=reloc_at_from_layout(b,roff,169)
    if r167!=NEIGHBOR_167 or r169!=NEIGHBOR_169:raise RuntimeError('END_OF_BATTLE relocation 주변 배열이 지원 버전과 다릅니다.')
    if r168[0]!=3 or r168[1]!=0 or r168[2]!=BATTLE_RELOC_SRC or r168[3]!=86:
        raise RuntimeError('END_OF_BATTLE LOAD_BGM_SET relocation 형식이 예상과 다릅니다.')
    fi,fp,fr=find_reloc_index_by_source(b,roff,FLUTE_RELOC_SRC)
    return sp,base,seglen,flags,alloc,roff,count,rend,nxt,p168,r168,fi,fp,fr

def battle_state(b:bytes):
    try:
        *common,p168,r168,fi,fp,fr=validate_common(b)
        base=common[1]
        tgt=(r168[3],r168[4])
        if tgt==TARGET_LOAD_BGM_SET:return 'unpatched'
        if tgt==TARGET_BATTLE_CAVE:
            slot=bytes_at(b,base,BATTLE_CAVE_OFF,len(BATTLE_WRAPPER_FIXED))
            if slot==BATTLE_WRAPPER_FIXED and fixed_battle_near_target(b,base)==TARGET_LOAD_BGM_SET[1]:return 'fixed'
            if slot==BATTLE_WRAPPER_BROKEN_FIXED:return 'broken-fixed-v0533-v0534'
            return 'unsupported'
        if r168[3]==86 and wrapper_kind_at(b,base,r168[4])=='battle_tail':return 'legacy-tail'
        return 'unsupported'
    except Exception:return 'unsupported'

def preflight(root=None):
    r=auto_root(root); p=find_ci(r,'ED2MAIN.EXE'); b=p.read_bytes()
    state=battle_state(b)
    if state=='unsupported':raise RuntimeError('ED2MAIN 전투 종료 BGM preflight 실패')
    sp,base,seglen,flags,alloc,roff,count,rend,nxt,p168,r168,fi,fp,fr=validate_common(b)
    slot=bytes_at(b,base,BATTLE_CAVE_OFF,len(BATTLE_WRAPPER_FIXED))
    if slot not in (b'\0'*len(BATTLE_WRAPPER_FIXED),BATTLE_WRAPPER_FIXED,BATTLE_WRAPPER_BROKEN_FIXED):
        raise RuntimeError('NE86:0100 battle wrapper 고정 슬롯이 다른 코드에 사용 중입니다.')
    # If an independent flute patch is present, its reserved slot must also be safe
    # before we migrate an old tail layout.
    fk=wrapper_kind_at(b,base,fr[4]) if fr[3]==86 else None
    if fk in ('flute','flute_old'):
        fw=FLUTE_WRAPPER if fk=='flute' else OLD_FLUTE_WRAPPER
        fslot=bytes_at(b,base,FLUTE_CAVE_OFF,len(fw))
        if fslot not in (b'\0'*len(fw),fw):raise RuntimeError('NE86:0200 flute wrapper 고정 슬롯이 다른 코드에 사용 중입니다.')
    return state

def _rewrite_layout(b:bytes, *, battle_target_to_cave:bool, restore_battle:bool=False):
    sp,base,seglen,flags,alloc,roff,count,rend,nxt,p168,r168,fi,fp,fr=validate_common(b)
    relblob=bytearray(b[roff:rend])
    x=bytearray(b)

    # Detect/migrate an independently installed legacy flute wrapper. Preserve its
    # exact version; this patch changes only its location, never its behavior.
    flute_kind=None; flute_legacy_off=None
    if fr[3]==86:
        if (fr[3],fr[4])==(86,FLUTE_CAVE_OFF) and wrapper_kind_at(b,base,FLUTE_CAVE_OFF) in ('flute','flute_old'):
            flute_kind=wrapper_kind_at(b,base,FLUTE_CAVE_OFF)
        else:
            k=wrapper_kind_at(b,base,fr[4])
            if k in ('flute','flute_old'):
                flute_kind=k; flute_legacy_off=fr[4]
    if flute_kind:
        fw=FLUTE_WRAPPER if flute_kind=='flute' else OLD_FLUTE_WRAPPER
        slot=bytes_at(b,base,FLUTE_CAVE_OFF,len(fw))
        if slot not in (b'\0'*len(fw),fw):raise RuntimeError('NE86:0200 flute 고정 슬롯 충돌')
        x[base+FLUTE_CAVE_OFF:base+FLUTE_CAVE_OFF+len(fw)]=fw
        rp=2+fi*8
        struct.pack_into('<BBHHH',relblob,rp,3,0,FLUTE_RELOC_SRC,86,FLUTE_CAVE_OFF)

    # Battle wrapper fixed slot.
    if restore_battle:
        rp=2+BATTLE_RELOC_INDEX*8
        struct.pack_into('<BBHHH',relblob,rp,3,0,BATTLE_RELOC_SRC,86,TARGET_LOAD_BGM_SET[1])
        slot=bytes_at(b,base,BATTLE_CAVE_OFF,len(BATTLE_WRAPPER_FIXED))
        if slot in (BATTLE_WRAPPER_FIXED,BATTLE_WRAPPER_BROKEN_FIXED):
            x[base+BATTLE_CAVE_OFF:base+BATTLE_CAVE_OFF+len(BATTLE_WRAPPER_FIXED)]=b'\0'*len(BATTLE_WRAPPER_FIXED)
    elif battle_target_to_cave:
        slot=bytes_at(b,base,BATTLE_CAVE_OFF,len(BATTLE_WRAPPER_FIXED))
        if slot not in (b'\0'*len(BATTLE_WRAPPER_FIXED),BATTLE_WRAPPER_FIXED,BATTLE_WRAPPER_BROKEN_FIXED):raise RuntimeError('NE86:0100 battle 고정 슬롯 충돌')
        x[base+BATTLE_CAVE_OFF:base+BATTLE_CAVE_OFF+len(BATTLE_WRAPPER_FIXED)]=BATTLE_WRAPPER_FIXED
        rp=2+BATTLE_RELOC_INDEX*8
        struct.pack_into('<BBHHH',relblob,rp,3,0,BATTLE_RELOC_SRC,86,BATTLE_CAVE_OFF)

    # If the old extension contains only the two known wrappers, compact NE86 back
    # to its stock length and restore the relocation table to the stock position.
    compact=(seglen>STOCK_SEG_LEN and tail_is_only_known_wrappers(b,base,seglen))
    newlen=STOCK_SEG_LEN if compact else seglen
    newroff=base+newlen; newrend=newroff+len(relblob)
    if newrend>nxt:raise RuntimeError('NE86 relocation table 배치 공간 부족')
    x[newroff:newrend]=relblob
    if newroff!=roff:
        x[newrend:nxt]=b'\0'*(nxt-newrend)
        struct.pack_into('<H',x,sp+2,newlen)
        if alloc!=0:struct.pack_into('<H',x,sp+6,newlen)
    else:
        x[roff:rend]=relblob
    return bytes(x),compact,flute_kind

def apply_bytes(b:bytes):
    st=battle_state(b)
    if st=='unsupported':raise RuntimeError('ED2MAIN 전투 종료 BGM 코드/NE layout이 지원 형태가 아닙니다.')
    nb,compacted,fk=_rewrite_layout(b,battle_target_to_cave=True)
    if battle_state(nb)!='fixed':raise RuntimeError('전투 종료 고정 슬롯 적용 후 검증 실패')
    return nb,st,compacted,fk

def restore_bytes(b:bytes):
    st=battle_state(b)
    if st=='unsupported':raise RuntimeError('ED2MAIN 전투 종료 BGM 패치를 안전하게 복원할 수 없습니다.')
    if st=='unpatched':return b,False,None
    nb,compacted,fk=_rewrite_layout(b,battle_target_to_cave=False,restore_battle=True)
    if battle_state(nb)!='unpatched':raise RuntimeError('전투 종료 패치 복원 검증 실패')
    return nb,compacted,fk

def apply(root=None):
    r=auto_root(root);p=find_ci(r,'ED2MAIN.EXE');b=p.read_bytes();preflight(r)
    nb,old,compacted,fk=apply_bytes(b)
    if nb==b:
        print('전투 종료 BGM hard-stop fix가 이미 고정 슬롯 방식으로 적용되어 있습니다.');return
    atomic(p,nb)
    print('전투 종료 BGM hard-stop fix 적용 완료.')
    print(f'- battle wrapper: NE86:{BATTLE_CAVE_OFF:04X} 고정 슬롯 (segment 확장 없음)')
    print(f'- FAR CALL relocation 86:{BATTLE_RELOC_SRC:04X} -> 86:{BATTLE_CAVE_OFF:04X}')
    if old=='legacy-tail':print('- 기존 NE86 끝 append 방식 battle wrapper를 고정 슬롯으로 이동')
    if old=='broken-fixed-v0533-v0534':print('- v0.5.33/v0.5.34의 잘못된 86:0100 near CALL을 자동 복구')
    if fk:print(f'- 기존 Soldier\'s Flute item wrapper도 NE86:{FLUTE_CAVE_OFF:04X}로 분리 유지')
    if compacted:print(f'- 알려진 legacy wrapper tail 제거: NE86 length -> {STOCK_SEG_LEN:04X}')
    print('- 원래 LOAD_BGM_SET 및 필드 BGM 실제 시작 시점은 유지합니다.')

def restore(root=None):
    r=auto_root(root);p=find_ci(r,'ED2MAIN.EXE');b=p.read_bytes();nb,compacted,fk=restore_bytes(b)
    if nb==b:
        print('전투 종료 BGM 코드는 이미 원래 호출 상태입니다.');return
    atomic(p,nb)
    print('전투 종료 BGM hard-stop relocation/86:0100 wrapper를 복원했습니다.')
    if fk:print('- 독립 Soldier\'s Flute wrapper는 86:0200 고정 슬롯에 보존했습니다.')
    if compacted:print('- legacy NE86 tail도 정리했습니다.')

def status(root=None):
    r=auto_root(root);p=find_ci(r,'ED2MAIN.EXE');b=p.read_bytes();st=battle_state(b)
    print('Battle-end BGM stop:',st)
    if st!='unsupported':
        sp,base,seglen,flags,alloc,roff,count,rend,nxt,p168,r168,fi,fp,fr=validate_common(b)
        print(f'- NE86 length: {seglen:04X} (stock {STOCK_SEG_LEN:04X})')
        print(f'- battle relocation: 86:{r168[2]:04X} -> seg#{r168[3]}:{r168[4]:04X}')
        slot=bytes_at(b,base,BATTLE_CAVE_OFF,len(BATTLE_WRAPPER_FIXED))
        if slot==BATTLE_WRAPPER_FIXED:
            print(f'- battle fixed slot 86:{BATTLE_CAVE_OFF:04X}: installed, near target 86:{fixed_battle_near_target(b,base):04X}')
        elif slot==BATTLE_WRAPPER_BROKEN_FIXED:
            print(f'- battle fixed slot 86:{BATTLE_CAVE_OFF:04X}: BROKEN v0.5.33/v0.5.34, near target 86:{fixed_battle_near_target(b,base):04X}')
        else:
            print(f'- battle fixed slot 86:{BATTLE_CAVE_OFF:04X}: empty')
        fk=wrapper_kind_at(b,base,FLUTE_CAVE_OFF)
        print(f'- flute reserved slot 86:{FLUTE_CAVE_OFF:04X}:', fk or 'empty')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['apply','restore','status']);ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args();root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:
        print();print(f'[ERROR] {type(e).__name__}: {e}');print('패치를 중단했습니다. 위 오류를 그대로 알려 주세요.');return 1
if __name__=='__main__':raise SystemExit(main())
