@echo off
python patch_combined.py %*
