from pathlib import Path

BACKUP_ROOT = Path("ED2_BACKUP")
VGM_ROOT = BACKUP_ROOT / "VGM_BGM_Engine"

def component_dir(root: Path, name: str) -> Path:
    return Path(root) / VGM_ROOT / name

def legacy_paths(root: Path, names):
    root = Path(root)
    out = []
    for name in names:
        out.append(root / name)
        out.append(root / BACKUP_ROOT / "LEGACY" / name)
    return out
