# v1.4.70 구성요소 / AIO 적용 순서

최종전 관련 Presentation/Runtime 구성요소는 `ED2_Final_Battle_Fix_v0.19.0` 하나로 통합되었습니다.

기본 전체 적용의 주요 순서:
1. 대사 / UI 텍스트
2. 오프닝 / 엔딩
3. 지하동굴 / 심볼 밀도
4. 초기 장비 / 아이템 / 상점
5. 버그 수정 / 마법 재충전 / M_504 복원
6. 몬스터 밸런스 / 문구 / EXP / 레벨 EXP
7. 안정성·QoL
8. VGM 또는 원본 BGM / SFX / 전사의 피리
9. Late Skill / 복원 아이템 드롭 정책 / R18 최종 레이아웃
10. **Final Battle Fix v0.19.0 presentation 단계**
11. 장 제목 / 요슈아 지도 / 직접 엔딩
12. **Final Battle Fix v0.19.0 runtime 단계 — 최종 전투 상태 확정**
13. 최종 manifest 검증

Final Battle Fix의 runtime 단계는 완성 게임 DLL을 배포하지 않습니다. 지원 source SHA와 32개 hunk의 old bytes를 검증한 뒤 기존 `M_500/M_501/M_502/C_734`를 직접 수정합니다.

`baselines.json`의 current는 v1.4.70 / 1049 files이며 v1.4.69를 지원되는 previous baseline으로 유지합니다.
