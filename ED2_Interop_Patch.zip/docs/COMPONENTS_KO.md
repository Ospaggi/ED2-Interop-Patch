# v1.4.73 구성요소 / AIO 적용 순서

v1.4.73은 v1.4.72의 선택형 구성요소 모델을 유지합니다.

주요 소유권:
- `전체 대사 교정 및 표시 보정`: 기존 대사 패치 + R20 FINAL SCENA 최종분
- `UI·텍스트·전투 표시 수정`: 기존 UI/공통 전투 문구 패치 + R20 FINAL ED2MAIN 최종분
- `몬스터 전투·특수행동 문구 수정`: 기존 Monster Text 누적 패치 + v16 TEST2 최종분
- `Map Transition QoL TEST8 PAIR10 NOWAIT`: 독립 선택 구성요소
- `Direct Ending`: 모든 ED2MAIN writer가 끝난 뒤 선택된 경우 최종 ED2MAIN으로 ED2END 재동기화

R20 FINAL과 Monster Text v16 TEST2는 사용자에게 별도 체크박스로 노출하지 않습니다.
선택된 기존 구성요소의 일부로 순차 실행되며, 다른 구성요소를 암묵적으로 활성화하지 않습니다.

기본 전체 적용의 후단 owner 순서:
1. v1.4.72 기존 구성요소
2. R20 FINAL SCENA owner (`dialogue` 선택 시)
3. R20 FINAL ED2MAIN owner (`text` 선택 시)
4. Monster Text v16 TEST2 (`monster_text` 선택 시)
5. Map Transition QoL (`map_transition` 선택 시)
6. Direct Ending 최종 재동기화 (`direct_ending` 선택 시)
