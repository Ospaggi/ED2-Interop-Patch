# v1.4.72 개발 / 검증 규칙

- 사용자 실제 DOSBox 결과를 정적 검사보다 우선합니다.
- SAVE는 검색·수정·백업·manifest 대상에서 제외합니다.
- ED2.SWP는 generation 판정에서 무시합니다.
- unknown/mixed DLL/EXE에는 강제 적용하지 않습니다.
- 신규 helper/NE 변경은 segment length, minalloc, relocation table과 다음 segment 경계를 확인합니다.

## Text & Dialogue R20 final owner
`ED2_Text_and_Dialogue_v5.0R20`이 v1.4.72 기본 전체 설치의 최종 대사/전투 표시 owner입니다.
기존 `ED2_Text_and_Dialogue_v5.0R19_Combined`는 순정 및 과거 정식판을 v1.4.71 canonical 상태까지 올리기 위한 migration backend로 유지합니다.
R20은 모든 기존 구성요소, Direct Ending, Final Battle runtime이 끝난 뒤 마지막에 적용합니다.

## Direct Ending
R20은 ED2MAIN/ED2END의 공통 전투 렌더러를 함께 수정합니다. AIO는 R20 적용 뒤 `ED2END_PATCH.json`의 source/output SHA도 최종 이미지로 동기화합니다.

## Final Battle writer
`ED2_Final_Battle_Fix_v0.19.0`을 그대로 유지합니다. AIO에서는 presentation과 runtime을 기존 순서대로 적용하고, 그 뒤 R20이 text/dialogue 범위만 최종 소유합니다.

## 정식 검증 기준
- 사용자 제공 순정 1041-file baseline 인식
- 순정 → v1.4.72 current exact target 수렴
- v1.4.71R1 → v1.4.72 exact target 수렴
- immediate reapply changed 0
- R20 target 158개 exact SHA verify
- ZIP CRC / 내부 SHA256SUMS
- SAVE/ED2.SWP 비대상 확인
