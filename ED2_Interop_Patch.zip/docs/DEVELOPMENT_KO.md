# v1.4.71 개발 / 검증 규칙

- 사용자 실제 DOSBox 결과를 정적 검사보다 우선합니다.
- SAVE는 검색·수정·백업·manifest 대상에서 제외합니다.
- unknown/mixed DLL에는 강제 적용하지 않습니다.
- 신규 helper/NE 변경은 segment length, minalloc, relocation table과 다음 segment 경계를 확인합니다.


## Text & Dialogue R19 owner
`ED2_Text_and_Dialogue_v5.0R19_Combined`가 v1.4.71의 공통 조사와 동적 이름+호칭 띄어쓰기 최종 owner입니다.
R18의 레이아웃 writer/validator는 migration 및 보존 검증으로 유지하고, R19 delta를 마지막에 적용합니다.
ED2MAIN 변경 뒤에는 Direct Ending owner가 `ED2END.EXE`를 다시 생성해야 합니다.

## Final Battle writer
`ED2_Final_Battle_Fix_v0.19.0`이 최종전 presentation과 runtime을 함께 소유합니다.
AIO 내부에서는 대사/레이아웃 상호운용 때문에 presentation 단계와 runtime 단계를 나누어 호출하지만, 배포 컴포넌트는 하나입니다.

Runtime은 완성 DLL을 복사하지 않고 exact source SHA + 32개 검증 hunk로 기존 파일을 수정합니다.
대상은 `MON/M_500.DLL`, `MON/M_501.DLL`, `MON/M_502.DLL`, `SCENA/C_734.DLL`입니다.

## 정식 검증 기준
- 사용자 제공 순정 1041/1041 exact
- 순정 → current 1049/1049
- immediate previous → current 1049/1049
- current reapply changed 0
- ZIP CRC / 재해제
- SAVE/ED2.SWP 비대상 확인
