#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, os, sys, tempfile
from dataclasses import dataclass
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'scene_editor'))
from ed2_ne_slot import parse_segments, patch_message_slot_0f, message_redirect_matches, allocate_tail, u16

VERSION = "v5.0R19"
BASELINE = "ED2 Interop Patch Pack v1.4.70 -> v1.4.71"

@dataclass(frozen=True)
class SceneSpec:
    dll: str
    seg: int
    off: int
    editable: int
    suffix: bytes
    token: bytes
    old_text: str
    new_text: str

# Active opcode-10 runtime concatenations verified against the current scene source.
# Bare personal-name + 님 (아트라스님/프레이아님/대도적 게일님) is intentional.
SCENE_SPECS = (
    SceneSpec('C_002.DLL',3,0x0CD8,34,bytes.fromhex('FFC0CE'),bytes.fromhex('10C90F'),'왕자님, 페리시아님께도 떠나기 전에',' 왕자님, 페리시아님께도 떠나기 전에'),
    SceneSpec('T_000.DLL',3,0x0351,8,b'',bytes.fromhex('10F20B'),'왕자님,',' 왕자님,'),
    SceneSpec('C_820.DLL',3,0x0652,4,bytes.fromhex('05'),bytes.fromhex('10D607'),'씨!!',' 씨!!'),
    SceneSpec('C_820.DLL',3,0x0777,31,b'',bytes.fromhex('10D607'),'씨는 히스토라의 마스터와 나레사',' 씨는 히스토라의 마스터와 나레사'),
)

ED2MAIN_SEG = 85
ESCAPE_OFF = 0x2700
ESCAPE_EDITABLE = 14
ESCAPE_SUFFIX = b'\x07'
ESCAPE_OLD = '은 도망쳤다.  '.encode('cp949')
ESCAPE_NEW = '^는 도망쳤다. '.encode('cp949')

SPELL_OFF = 0x3DB9
SPELL_EDITABLE = 36
SPELL_SUFFIX = b'\x0A'
SPELL_OLD = bytes.fromhex('B4C2200602BFA1B0D420061EC0DAB1E2C0DABD C5041FBFA1B0D42004061032C3061032C3'.replace(' ',''))
SPELL_HEAD_OLD = SPELL_OLD[:3]
SPELL_HEAD_NEW = '^는 '.encode('cp949')

# v1.4.70 R18 dynamic protagonist title fix must remain present.
T140_DLL='T_140.DLL'; T140_SEG=3; T140_OFF=0x0778; T140_EDITABLE=11
T140_GOOD=' 왕자입니다.'.encode('cp949')


def sha256(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()


def atomic_write(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.r19.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def scene_spec_state(data:bytes, sp:SceneSpec)->str:
    s=parse_segments(data)[sp.seg-1]; base=s.file_offset
    if data[base+sp.off-3:base+sp.off] != sp.token:
        return 'unexpected-token'
    old=sp.old_text.encode('cp949'); new=sp.new_text.encode('cp949')
    raw=data[base+sp.off:base+sp.off+sp.editable+len(sp.suffix)]
    pending = raw == old + b'\xFF'*(sp.editable-len(old)) + sp.suffix if len(old)<=sp.editable else False
    if len(new)<=sp.editable:
        fixed = raw == new + b'\xFF'*(sp.editable-len(new)) + sp.suffix
    else:
        fixed = message_redirect_matches(data,sp.seg,sp.off,sp.editable,new,sp.suffix)
    if fixed: return 'fixed'
    if pending: return 'pending'
    return 'unexpected'


def ed2main_state(data:bytes)->dict:
    s=parse_segments(data)[ED2MAIN_SEG-1]; base=s.file_offset
    eraw=data[base+ESCAPE_OFF:base+ESCAPE_OFF+ESCAPE_EDITABLE+1]
    if eraw == ESCAPE_NEW+ESCAPE_SUFFIX: escape='fixed'
    elif eraw == ESCAPE_OLD+ESCAPE_SUFFIX: escape='pending'
    else: escape='unexpected'
    raw=data[base+SPELL_OFF:base+SPELL_OFF+SPELL_EDITABLE+1]
    spell='unexpected'
    if raw==SPELL_OLD+SPELL_SUFFIX:
        spell='pending'
    elif raw[:1]==b'\x0F' and raw[3:]==SPELL_OLD[3:]+SPELL_SUFFIX:
        ptr=u16(raw,1)
        payload=SPELL_HEAD_NEW+b'\x0F'+(SPELL_OFF+3).to_bytes(2,'little')
        if ptr+len(payload)<=s.length and data[base+ptr:base+ptr+len(payload)]==payload:
            spell='fixed'
    return {'escape_particle':escape,'spell_subject_particle':spell,'segment85_length':s.length}


def inspect_root(root:Path, include_ed2main:bool=True, include_scena:bool=True)->dict:
    root=root.resolve(); rows=[]; compatible=True; pending=False; result={}
    if include_ed2main:
        ep=root/'ED2MAIN.EXE'
        if not ep.is_file():
            return {'ok':False,'compatible':False,'error':'ED2MAIN.EXE missing'}
        est=ed2main_state(ep.read_bytes()); result['ed2main']=est
        for v in (est['escape_particle'],est['spell_subject_particle']):
            if v=='pending': pending=True
            elif v!='fixed': compatible=False
    if include_scena:
        for sp in SCENE_SPECS:
            p=root/'SCENA'/sp.dll
            if not p.is_file():
                rows.append({'dll':sp.dll,'offset':f'0x{sp.off:04X}','state':'missing'}); compatible=False; continue
            st=scene_spec_state(p.read_bytes(),sp)
            if st=='pending': pending=True
            elif st!='fixed': compatible=False
            rows.append({'dll':sp.dll,'offset':f'0x{sp.off:04X}','state':st,'old':sp.old_text,'new':sp.new_text})
        t=root/'SCENA'/T140_DLL
        t140=False
        if t.is_file():
            t140=message_redirect_matches(t.read_bytes(),T140_SEG,T140_OFF,T140_EDITABLE,T140_GOOD,b'')
        if not t140: compatible=False
        result['dynamic_title_rows']=rows
        result['t140_existing_fix_preserved']=t140
    result.update({'ok':compatible and not pending,'compatible':compatible,'has_pending':pending})
    return result


def patch_all_in_memory(root:Path, include_ed2main:bool=True, include_scena:bool=True):
    pre=inspect_root(root,include_ed2main,include_scena)
    if not pre.get('compatible'):
        raise RuntimeError('R19 preflight rejected unknown/custom target state: '+json.dumps(pre,ensure_ascii=False))
    outputs={}; details=[]
    if include_ed2main:
        p=root/'ED2MAIN.EXE'; before=p.read_bytes(); out=before
        old_offsets=tuple(x.file_offset for x in parse_segments(before))
        st=ed2main_state(out)
        if st['escape_particle']=='pending':
            s=parse_segments(out)[ED2MAIN_SEG-1]; pos=s.file_offset+ESCAPE_OFF
            b=bytearray(out); b[pos:pos+ESCAPE_EDITABLE]=ESCAPE_NEW; out=bytes(b)
        st=ed2main_state(out)
        if st['spell_subject_particle']=='pending':
            payload=SPELL_HEAD_NEW+b'\x0F'+(SPELL_OFF+3).to_bytes(2,'little')
            alloc=allocate_tail(out,ED2MAIN_SEG,[payload])
            b=bytearray(alloc.data); s85=parse_segments(b)[ED2MAIN_SEG-1]
            pos=s85.file_offset+SPELL_OFF
            if bytes(b[pos:pos+3])!=SPELL_HEAD_OLD: raise RuntimeError('spell prefix changed before redirect')
            b[pos:pos+3]=b'\x0F'+alloc.segment_offsets[0].to_bytes(2,'little')
            out=bytes(b)
        post=ed2main_state(out)
        if post['escape_particle']!='fixed' or post['spell_subject_particle']!='fixed':
            raise RuntimeError('ED2MAIN postcondition failed')
        if len(out)!=len(before): raise RuntimeError('ED2MAIN file size changed')
        if tuple(x.file_offset for x in parse_segments(out))!=old_offsets:
            raise RuntimeError('ED2MAIN NE segment file offsets changed')
        if out!=before: outputs[p]=out
        details.append({'path':'ED2MAIN.EXE','before_sha256':sha256(before),'after_sha256':sha256(out),'changed':out!=before,'state':post})
    if include_scena:
        byfile={}
        for sp in SCENE_SPECS: byfile.setdefault(sp.dll,[]).append(sp)
        for dll,specs in byfile.items():
            p=root/'SCENA'/dll; before=p.read_bytes(); out=before
            old_offsets=tuple(x.file_offset for x in parse_segments(before))
            for sp in specs:
                st=scene_spec_state(out,sp)
                if st=='pending':
                    out=patch_message_slot_0f(out,sp.seg,sp.off,sp.editable,sp.new_text.encode('cp949'),sp.suffix).data
                elif st!='fixed':
                    raise RuntimeError(f'{dll} 0x{sp.off:04X} changed during in-memory patch')
            for sp in specs:
                if scene_spec_state(out,sp)!='fixed': raise RuntimeError(f'{dll} 0x{sp.off:04X} postcondition failed')
            if len(out)!=len(before): raise RuntimeError(f'{dll} file size changed')
            if tuple(x.file_offset for x in parse_segments(out))!=old_offsets:
                raise RuntimeError(f'{dll} NE segment file offsets changed')
            if out!=before: outputs[p]=out
            details.append({'path':'SCENA/'+dll,'before_sha256':sha256(before),'after_sha256':sha256(out),'changed':out!=before,
                            'sites':[{'offset':f'0x{x.off:04X}','state':scene_spec_state(out,x)} for x in specs]})
    return pre,outputs,details


def apply(root:Path,check=False,include_ed2main=True,include_scena=True):
    root=root.resolve()
    if check:
        st=inspect_root(root,include_ed2main,include_scena)
        print(json.dumps({'version':VERSION,'baseline':BASELINE,'scope':{'ed2main':include_ed2main,'scena':include_scena},**st},ensure_ascii=False,indent=2))
        return 0 if st.get('ok') else 2
    pre,outputs,details=patch_all_in_memory(root,include_ed2main,include_scena)
    for path,data in outputs.items(): atomic_write(path,data)
    post=inspect_root(root,include_ed2main,include_scena)
    if not post.get('ok'): raise RuntimeError('R19 disk postcondition failed: '+json.dumps(post,ensure_ascii=False))
    report={'ok':True,'version':VERSION,'baseline':BASELINE,'scope':{'ed2main':include_ed2main,'scena':include_scena},'changed_files':len(outputs),'preflight':pre,'post':post,'files':details}
    print(json.dumps(report,ensure_ascii=False,indent=2)); return 0


def main():
    ap=argparse.ArgumentParser(description='ED2 Text & Dialogue v5.0R19: common battle particle + dynamic title spacing fix')
    ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true')
    g=ap.add_mutually_exclusive_group()
    g.add_argument('--scena-only',action='store_true')
    g.add_argument('--ed2main-only',action='store_true')
    a=ap.parse_args()
    include_ed2main=not a.scena_only
    include_scena=not a.ed2main_only
    try:return apply(a.root,a.check,include_ed2main,include_scena)
    except Exception as e: print('ERROR:',e,file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
