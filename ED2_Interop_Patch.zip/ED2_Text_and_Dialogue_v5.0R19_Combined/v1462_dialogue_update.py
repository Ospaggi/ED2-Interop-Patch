#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, os, tempfile
from scene_editor.ed2_ne_slot import message_redirect_matches, patch_message_slot_0f

VERSION='1.4.62'
FILE='C_600.DLL'; SEG=3; OFF=0x01B8; EDITABLE=12
OLD='곧 올 거야.'.encode('cp949')
NEW='이제 곧 올 거야.'.encode('cp949')
FILL=0xFF

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.v1462.tmp',dir=str(path.parent)); os.close(fd)
    try:
        Path(tmp).write_bytes(data); os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def state(path:Path):
    if not path.is_file(): return {'state':'missing'}
    b=path.read_bytes()
    if message_redirect_matches(b,SEG,OFF,EDITABLE,NEW,b'',fill=FILL):
        return {'state':'fixed','redirected':True}
    # Direct form is impossible for NEW but accept it defensively.
    try:
        from scene_editor.ed2_ne_slot import parse_segments
        seg=parse_segments(b)[SEG-1]; cur=b[seg.file_offset+OFF:seg.file_offset+OFF+EDITABLE]
    except Exception as e:
        return {'state':'unexpected','error':str(e)}
    oldslot=OLD+bytes([FILL])*(EDITABLE-len(OLD))
    if cur==oldslot: return {'state':'pending','current_hex':cur.hex()}
    return {'state':'unexpected','current_hex':cur.hex()}

def main():
    ap=argparse.ArgumentParser(description='ED2 v1.4.62 C_600 Rayisia source-faithful dialogue update')
    ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    root=a.root.resolve(); path=root/'SCENA'/FILE
    before=state(path)
    if a.check:
        ok=before.get('state')=='fixed'
        print(json.dumps({'ok':ok,'version':VERSION,'file':FILE,'offset':'0x01B8','text':'이제 곧 올 거야.','state':before},ensure_ascii=False,indent=2))
        return 0 if ok else 2
    if before.get('state')=='fixed':
        print(json.dumps({'ok':True,'version':VERSION,'changed':False,'state':before},ensure_ascii=False,indent=2)); return 0
    if before.get('state')!='pending':
        print(json.dumps({'ok':False,'version':VERSION,'state':before},ensure_ascii=False,indent=2)); return 2
    b=path.read_bytes()
    out=patch_message_slot_0f(b,SEG,OFF,EDITABLE,NEW,b'',fill=FILL)
    atomic(path,out.data)
    after=state(path); ok=after.get('state')=='fixed'
    print(json.dumps({'ok':ok,'version':VERSION,'changed':out.changed,'redirected':out.redirected,'tail_pointer':out.pointer,'consumed_padding':out.consumed_padding,'state':after},ensure_ascii=False,indent=2))
    return 0 if ok else 2
if __name__=='__main__': raise SystemExit(main())
