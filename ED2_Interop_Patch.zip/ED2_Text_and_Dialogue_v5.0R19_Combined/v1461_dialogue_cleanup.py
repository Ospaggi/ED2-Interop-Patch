#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse,json,os,struct,tempfile
VERSION="1.4.61"
def u16(b,o): return struct.unpack_from("<H",b,o)[0]
def u32(b,o): return struct.unpack_from("<I",b,o)[0]
def seg_base(data,index=3):
 ne=u32(data,0x3c); table=ne+u16(data,ne+0x22); shift=u16(data,ne+0x32); return u16(data,table+(index-1)*8)<<shift
def cp(s): return s.encode("cp949")
SITES=[]
def add(fn,off,old,new,reason):
 assert len(old)==len(new); SITES.append((fn,off,old,new,reason))
add('T_112.DLL',0x0929,bytes.fromhex('beeebcad20bfc0bcbcbfe42e2001bfa9b1e420b8c5c7a5bcd2c0d4b4cfb4d92e20c7d120c0e5bfa12031303001476f6c64c0ceb5a5bfe42effffff'),bytes.fromhex('beeebcad20bfc0bcbcbfe42e01bfa9b1e420b8c5c7a5bcd2c0d4b4cfb4d92e01c7d120c0e5bfa12031303020476f6c64c0ceb5a5bfe42effffffff'),'랄파 항 매표소 장별 개행 통일')
add('T_116.DLL',0x0582,bytes.fromhex('beeebcad20bfc0bcbcbfe42e01bfa9b1e420b8c5c7a5bcd2c0d4b4cfb4d92e20c7d120c0e5bfa12031303001476f6c64c0ceb5a5bfe42effffffff'),bytes.fromhex('beeebcad20bfc0bcbcbfe42e01bfa9b1e420b8c5c7a5bcd2c0d4b4cfb4d92e01c7d120c0e5bfa12031303020476f6c64c0ceb5a5bfe42effffffff'),'랄파 항 매표소 장별 개행 통일')
add('C_203.DLL',0x06EE,bytes.fromhex('ff'),bytes.fromhex('01'),'세리스 습격: 들어왔습니다./성까지 문장 경계 복원')
add('T_010.DLL',0x01D6,bytes.fromhex('ff'),bytes.fromhex('01'),'크루즈 지진 대사 문장 경계 복원')
add('T_211.DLL',0x0138,bytes.fromhex('ff'),bytes.fromhex('01'),'병사 사과 대사 문장 경계 복원')
add('T_041.DLL',0x0168,bytes.fromhex('b0c5b1e2b5b520b8f3bdbac5cdb0a120b3aac5b8b3aa20c5ab20bcd2b5bfc0ccc1f6ff'),bytes.fromhex('b0c5b1e2b5b520b8f3bdbac5cdb0a120b3aac5b8b3aa20bcd2b5bfc0ccc1f62e01ffff'),'소동이지. 온점 추가 및 다음 문장 명시 개행')
add('T_543.DLL',0x04CD,bytes.fromhex('c8b2c1a620c6f3c7cfb2b220b0c5bfaac7cfb8e92c20b1d720b4ebb0a1b8a601b4c0b2b820bac1b6f32eff'),bytes.fromhex('c8b2c1a620c6f3c7cfb2b220b0c5bfaac7d120b4ebb0a1b8a601b8f6c0b8b7ce20b4c0b2b820bac1b6f32e'),'카자줌 일반 대사 자연화')
add('T_410.DLL',0x07A2,bytes.fromhex('476f6c64c0ceb5a5ffff'),bytes.fromhex('20476f6c64c0ceb5a52c'),'매각 확인문 100 Gold 표기/쉼표 통일')
add('T_412.DLL',0x0441,bytes.fromhex('20476f6c64c0ceb5a52e2e2eff'),bytes.fromhex('20476f6c64c0ceb5a52cffffff'),'매각 확인문 100 Gold 표기/쉼표 통일')
add('T_414.DLL',0x0314,bytes.fromhex('476f6c64c0ceb5a5ffff'),bytes.fromhex('20476f6c64c0ceb5a52c'),'매각 확인문 100 Gold 표기/쉼표 통일')
add('T_416.DLL',0x02FF,bytes.fromhex('476f6c64c0ceb5a5ffff'),bytes.fromhex('20476f6c64c0ceb5a52c'),'매각 확인문 100 Gold 표기/쉼표 통일')

def atomic(path,data):
 fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.v1461.tmp',dir=str(path.parent))
 try:
  with os.fdopen(fd,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
  os.replace(tmp,path)
 except Exception:
  try: os.unlink(tmp)
  except OSError: pass
  raise
def classify(root):
 out=[]
 for fn,off,old,new,reason in SITES:
  p=root/'SCENA'/fn
  if not p.is_file(): out.append({'file':fn,'offset':f'0x{off:04X}','state':'missing','reason':reason}); continue
  b=p.read_bytes(); pos=seg_base(b)+off; cur=b[pos:pos+len(old)]
  state='fixed' if cur==new else ('pending' if cur==old else 'unexpected')
  out.append({'file':fn,'offset':f'0x{off:04X}','state':state,'reason':reason,'current_hex':cur.hex(),'old_hex':old.hex(),'new_hex':new.hex()})
 return out
def main():
 ap=argparse.ArgumentParser(description='ED2 v1.4.61 dialogue/punctuation cleanup')
 ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args(); root=a.root.resolve()
 rows=classify(root); bad=[x for x in rows if x['state'] in ('unexpected','missing')]
 if bad: print(json.dumps({'ok':False,'version':VERSION,'sites':rows},ensure_ascii=False,indent=2)); return 2
 pending=[x for x in rows if x['state']=='pending']
 if a.check:
  print(json.dumps({'ok':not pending,'version':VERSION,'pending_sites':len(pending),'sites':rows},ensure_ascii=False,indent=2)); return 0 if not pending else 2
 by={}
 for fn,off,old,new,reason in SITES: by.setdefault(fn,[]).append((off,old,new,reason))
 changed=0; files=[]
 for fn,rs in by.items():
  p=root/'SCENA'/fn; data=bytearray(p.read_bytes()); local=0; base=seg_base(data)
  for off,old,new,reason in rs:
   pos=base+off; cur=bytes(data[pos:pos+len(old)])
   if cur==new: continue
   if cur!=old: raise RuntimeError(f'{fn} seg3:0x{off:04X} guard mismatch')
   data[pos:pos+len(old)]=new; changed+=1; local+=1
  if local: atomic(p,bytes(data)); files.append(fn)
 after=classify(root); ok=all(x['state']=='fixed' for x in after)
 print(json.dumps({'ok':ok,'version':VERSION,'changed_sites':changed,'changed_files':files,'sites':after},ensure_ascii=False,indent=2)); return 0 if ok else 2
if __name__=='__main__': raise SystemExit(main())
