#!/usr/bin/env python3
from pathlib import Path
import argparse,csv,json,re,struct,sys,tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'scene_editor'))
from ed2_ne_slot import parse_segments,message_redirect_matches
from ed2_scene_editor import SceneProject

def segbytes(path:Path,index:int=3):
    b=path.read_bytes(); s=parse_segments(b)[index-1]; return b,s,b[s.file_offset:s.file_offset+s.length]

def audit(root:Path):
    scena=root/'SCENA'
    # Literal/global term checks.
    all_scena=[p.read_bytes() for p in scena.glob('*.DLL')]
    priest_bad=sum(b.count('사제  바바라'.encode('cp949')) for b in all_scena)
    priest_good=sum(b.count('사제 바바라'.encode('cp949')) for b in all_scena)
    parker_bad=sum(b.count('파카'.encode('cp949')) for b in all_scena)
    parker_good=sum(b.count('파커'.encode('cp949')) for b in all_scena)

    # C_203 Seris Castle attack message: three explicit lines, with the word
    # boundary between 태우고 and 국왕 physically present rather than relying
    # on FF/no-op concatenation.
    b,s,seg=segbytes(scena/'C_203.DLL')
    c203=(
        seg[0x0743:0x0743+len('소니아님은 벌써 사람을 배에'.encode('cp949'))]=='소니아님은 벌써 사람을 배에'.encode('cp949') and
        seg[0x075E]==0x01 and
        seg[0x075F:0x075F+len('태우고 국왕 폐하를 기다리고'.encode('cp949'))]=='태우고 국왕 폐하를 기다리고'.encode('cp949') and
        seg[0x077A]==0x01 and
        seg[0x077B:0x077B+len('계십니다.'.encode('cp949'))]=='계십니다.'.encode('cp949')
    )

    # T_212 Erion: dynamic 왕자 prefix + three grammatical lines.
    b,s,seg=segbytes(scena/'T_212.DLL')
    first=', 이건 제 감입니다만'.encode('cp949')
    first_ok=seg[0x0125:0x0125+len(first)]==first and seg[0x0143]==0x01
    second='전 세계의 용의 알이'.encode('cp949')
    second_ok=message_redirect_matches(b,3,0x0144,9,second,b'\x01')
    third='이런 상태인 것 같습니다.'.encode('cp949')
    third_ok=seg[0x014E:0x014E+len(third)]==third

    # Prologue end title is 16 cells, centered in the 34-cell line: 9 spaces.
    b,s,seg=segbytes(scena/'V_000.DLL')
    hero=b' '*9+'영웅들의 전설 II'.encode('cp949')
    hero_ok=message_redirect_matches(b,3,0x087D,19,hero,bytes.fromhex('0F 0B 00'))

    # Whole-scene dialogue export: interior Hangul double-spaces are invalid
    # except the fixed-width chapter labels and the legacy chapter-3 card text.
    with tempfile.NamedTemporaryFile(suffix='.csv',delete=False) as f: tmp=Path(f.name)
    try:
        proj=SceneProject(root); proj.export_strings_csv(tmp,dialogues_only=False); validation=proj.validate()
        rows=list(csv.DictReader(tmp.open(encoding='utf-8-sig',newline='')))
    finally:
        tmp.unlink(missing_ok=True)
    allowed={
      ('V_000.DLL','0x0012'),('V_100.DLL','0x0029'),('V_200.DLL','0x002A'),
      ('V_300.DLL','0x0023'),('V_400.DLL','0x002B'),('V_300.DLL','0x08B5')
    }
    double=[]
    for r in rows:
        t=r.get('source_text','')
        if re.search(r'[가-힣] {2,}[가-힣]',t) and (r['dll'],r['offset']) not in allowed:
            double.append({'dll':r['dll'],'offset':r['offset'],'text':t})
    out={
      'ok': bool(validation.get('ok')) and priest_bad==0 and priest_good>=1 and parker_bad==0 and parker_good>=1 and c203 and first_ok and second_ok and third_ok and hero_ok and not double,
      'priest_barbara':{'double_space_count':priest_bad,'normal_count':priest_good},
      'parker':{'paka_count':parker_bad,'parker_count':parker_good},
      'seris_attack_spacing':c203,
      'erion_dragon_egg_rewrap':{'first_line':first_ok,'second_line_redirect':second_ok,'third_line':third_ok},
      'heroes_legend_ii_centered_9_spaces':hero_ok,
      'unexpected_hangul_double_space_count':len(double),
      'unexpected_hangul_double_space_examples':double[:20],
      'scene_validation':validation,
    }
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);a=ap.parse_args();r=audit(a.root.resolve());print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['ok'] else 2
if __name__=='__main__': raise SystemExit(main())
