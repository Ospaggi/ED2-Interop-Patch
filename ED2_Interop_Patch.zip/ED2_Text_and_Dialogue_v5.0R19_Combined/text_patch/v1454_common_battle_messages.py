#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
from ed2_ne_slot import parse_segments, patch_message_slot_0f, message_redirect_matches

SEGMENT=85
PARALYSIS_REL=0x2768
CONFUSION_PERSIST_REL=0x27C0

def _state(data:bytes)->dict:
    seg=parse_segments(data)[SEGMENT-1]; base=seg.file_offset
    paralysis='^는 마비되어 버렸다!!'.encode('cp949')
    confusion='^는 혼란에 빠져있다!!'.encode('cp949')
    rows={
      'paralysis': bytes(data[base+PARALYSIS_REL:base+PARALYSIS_REL+len(paralysis)])==paralysis,
      'confusion_persistent': bytes(data[base+CONFUSION_PERSIST_REL:base+CONFUSION_PERSIST_REL+len(confusion)])==confusion,
      'confusion_inflicted': message_redirect_matches(data,SEGMENT,0x3891,15,'^는 혼란에 빠졌다!!'.encode('cp949'),b'\x0A'),
      'no_effect': message_redirect_matches(data,SEGMENT,0x3E61,18,'에겐 효과가 없었다.'.encode('cp949'),b'\x0A'),
      'cast': message_redirect_matches(data,SEGMENT,0x3E9E,11,'^를 시전했다.'.encode('cp949'),b'\x07'),
    }
    return {'ok':all(rows.values()),'segment85_file_offset':seg.file_offset,'segment85_length':seg.length,'checks':rows}

def apply(path:Path):
    d=bytearray(path.read_bytes()); seg=parse_segments(d)[SEGMENT-1]; base=seg.file_offset
    old='^는 마비되고 말았다!!'.encode('cp949'); new='^는 마비되어 버렸다!!'.encode('cp949')
    pos=base+PARALYSIS_REL; cur=bytes(d[pos:pos+21])
    if cur==old:d[pos:pos+21]=new
    elif cur!=new:raise RuntimeError('마비 메시지 상태 불명')
    old='^는 혼란스러워한다!!'.encode('cp949')+b'\xFF';new='^는 혼란에 빠져있다!!'.encode('cp949')
    pos=base+CONFUSION_PERSIST_REL;cur=bytes(d[pos:pos+21])
    if cur==old:d[pos:pos+21]=new
    elif cur!=new:raise RuntimeError('혼란 지속 메시지 상태 불명')
    d=bytearray(patch_message_slot_0f(d,SEGMENT,0x3891,15,'^는 혼란에 빠졌다!!'.encode('cp949'),b'\x0A').data)
    d=bytearray(patch_message_slot_0f(d,SEGMENT,0x3E61,18,'에겐 효과가 없었다.'.encode('cp949'),b'\x0A').data)
    d=bytearray(patch_message_slot_0f(d,SEGMENT,0x3E9E,11,'^를 시전했다.'.encode('cp949'),b'\x07').data)
    st=_state(bytes(d))
    if not st['ok']:raise RuntimeError('공통 전투 메시지 적용 후 검증 실패: '+json.dumps(st,ensure_ascii=False))
    path.write_bytes(d);print(json.dumps(st,ensure_ascii=False));return st

def main():
    ap=argparse.ArgumentParser(description='ED2 v1.4.56 common battle message patch/audit')
    ap.add_argument('path',type=Path);ap.add_argument('--check',action='store_true');a=ap.parse_args()
    if a.check:
        st=_state(a.path.read_bytes());print(json.dumps(st,ensure_ascii=False));return 0 if st['ok'] else 2
    apply(a.path);return 0
if __name__=='__main__':raise SystemExit(main())
