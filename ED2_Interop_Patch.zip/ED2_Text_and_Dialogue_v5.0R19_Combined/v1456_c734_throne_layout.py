#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'scene_editor'))
from ed2_scene_editor import SceneProject

# Meaning-unit line breaks previously verified in the throne room.  Each rule
# changes one ordinary half-width space to 01h, preserving size and all NE
# relocation/control structure.  The text itself is unchanged.
RULES=(
 ('godwin_intro','제국의','황제'),
 ('godwin_praise','왔군.','그 점'),
 ('godwin_sindy','데려와도','내 상대'),
 ('sindy_dragon','아버님께','자주 찾아'),
 ('transformation','때문이군.','변신 주문'),
)

def _pairs():
    out=[]
    for name,a,b in RULES:
        left=a.encode('cp949');right=b.encode('cp949')
        out.append((name,left+b' '+right,left+b'\x01'+right))
    return out

def state(path:Path):
    data=path.read_bytes();rows=[];ok=True
    for name,before,after in _pairs():
        cb=data.count(before);ca=data.count(after)
        good=(cb==0 and ca==1);ok &= good
        rows.append({'name':name,'space_form':cb,'linebreak_form':ca,'ok':good})
    return {'ok':ok,'rules':rows}

def normalize(path:Path):
    data=bytearray(path.read_bytes());changed=0
    for name,before,after in _pairs():
        ca=bytes(data).count(after);cb=bytes(data).count(before)
        if ca==1 and cb==0:
            pos=bytes(data).find(after);data[pos:pos+len(after)]=before;changed+=1
        elif cb==1 and ca==0:pass
        else:raise RuntimeError(f'{name}: 지원하지 않는 C_734 줄바꿈 상태 space={cb} break={ca}')
    if changed:path.write_bytes(data)
    return changed

def apply(path:Path,root:Path|None=None):
    data=bytearray(path.read_bytes());changed=0
    for name,before,after in _pairs():
        cb=bytes(data).count(before);ca=bytes(data).count(after)
        if cb==1 and ca==0:
            pos=bytes(data).find(before);data[pos:pos+len(before)]=after;changed+=1
        elif ca==1 and cb==0:pass
        else:raise RuntimeError(f'{name}: 지원하지 않는 C_734 줄바꿈 상태 space={cb} break={ca}')
    if changed:path.write_bytes(data)
    report=state(path);report['changed_breaks']=changed
    if root is not None:
        val=SceneProject(root).validate();report['scene_validation']=val;report['ok']=report['ok'] and bool(val.get('ok'))
    if not report['ok']:raise RuntimeError('C_734 옥좌 줄바꿈 검증 실패: '+json.dumps(report,ensure_ascii=False))
    return report

def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);g=ap.add_mutually_exclusive_group();g.add_argument('--check',action='store_true');g.add_argument('--normalize',action='store_true');a=ap.parse_args()
    root=a.root.resolve();path=root/'SCENA/C_734.DLL'
    if a.normalize:r={'ok':True,'normalized_breaks':normalize(path)}
    elif a.check:r=state(path)
    else:r=apply(path,root)
    print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r.get('ok') else 2
if __name__=='__main__':raise SystemExit(main())
