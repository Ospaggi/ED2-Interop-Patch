#!/usr/bin/env python3
from pathlib import Path
import argparse,os,subprocess,sys,tempfile,csv,json
HERE=Path(__file__).resolve().parent

def run(cmd,env=None):
    e=os.environ.copy();e['PYTHONUTF8']='1';e.update(env or {});r=subprocess.run(cmd,env=e)
    if r.returncode:raise SystemExit(r.returncode)

def compat(root,args):return run([sys.executable,str(HERE/'internal/r54_compat_tools.py'),str(root),*args])


def import_r54_extras(root):
    """Apply R54 logical dialogue still outside the R15 287-file stock rebuild.

    Currently this is C_010.DLL (3 rows).  No complete DLL payload is used.
    """
    wanted={'C_010.DLL'}
    src=list(csv.DictReader((HERE/'data/dialogue_current.csv').open(encoding='utf-8-sig',newline='')))
    rows=[r for r in src if r.get('dll') in wanted]
    if not rows:return 0
    sys.path.insert(0,str(HERE/'scene_editor'));from ed2_scene_editor import SceneProject
    fields=list(rows[0].keys())
    with tempfile.NamedTemporaryFile('w',suffix='.csv',delete=False,encoding='utf-8-sig',newline='') as f:
        tmp=Path(f.name);w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    try:return SceneProject(root).import_strings_csv(tmp,dialogues_only=False)
    finally:tmp.unlink(missing_ok=True)

def repair_c734(root):
    # Scene Editor CSV metadata describes the unbroken logical source slot.
    # Normalize our five presentation-only 01h bytes to spaces, import the
    # current R15 text, then restore the verified throne-room line breaks.
    layout=HERE/'v1456_c734_throne_layout.py'
    run([sys.executable,str(layout),str(root),'--normalize'])
    sys.path.insert(0,str(HERE/'scene_editor'));from ed2_scene_editor import SceneProject
    p=SceneProject(root);n=p.import_strings_csv(HERE/'data/c734_dialogue.csv',dialogues_only=False);v=p.validate()
    run([sys.executable,str(layout),str(root)])
    v2=SceneProject(root).validate()
    print(json.dumps({'mode':'repair-c734','rows_changed':n,'validation':v2},ensure_ascii=False));return 0 if v2.get('ok') else 2

def semantic_check(root):
    """Interop-safe dialogue verification after later components have also touched SCENA."""
    import hashlib
    sys.path.insert(0,str(HERE/'scene_editor'));from ed2_scene_editor import SceneProject
    v=SceneProject(root).validate()
    spec=json.loads((HERE/'data/manifest.json').read_text(encoding='utf-8'))
    still_stock=[]
    for e in spec['scene_files']:
        if e['stock_sha256']==e['final_sha256']:continue
        fp=root/'SCENA'/e['file']
        if fp.is_file() and hashlib.sha256(fp.read_bytes()).hexdigest()==e['stock_sha256']:
            still_stock.append(e['file'])
    c734=(root/'SCENA/C_734.DLL').read_bytes()
    c734_ok=('자, 덤벼라.'.encode('cp949') in c734 and '어디서든 덤벼라.'.encode('cp949') not in c734)
    shop={}
    for fn,good,bad in [('T_112.DLL',bytes.fromhex('F3 1E 09'),bytes.fromhex('F3 1E B0')),('T_114.DLL',bytes.fromhex('F3 F9 09'),bytes.fromhex('F3 F9 B0'))]:
        b=(root/'SCENA'/fn).read_bytes();shop[fn]={'good':b.count(good),'broken':b.count(bad)}
    shop_ok=all(x['good']>=1 and x['broken']==0 for x in shop.values())
    # v1.4.56 presentation regressions are separate from semantic text hashes:
    # exact-34 auto-wrap + explicit 01h, and the five C_734 throne-room breaks.
    layout34=subprocess.run([sys.executable,str(HERE/'v1456_dialogue_34cell_fix.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    throne=subprocess.run([sys.executable,str(HERE/'v1456_c734_throne_layout.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    layout34_report=json.loads(layout34.stdout) if layout34.stdout.strip() else {'ok':False,'stderr':layout34.stderr}
    throne_report=json.loads(throne.stdout) if throne.stdout.strip() else {'ok':False,'stderr':throne.stderr}
    v1460_report={'status':'superseded-by-v1.4.70-R18/v1.4.71-R19','required':False}
    v1461=subprocess.run([sys.executable,str(HERE/'v1461_dialogue_cleanup.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    v1461_report=json.loads(v1461.stdout) if v1461.stdout.strip() else {'ok':False,'stderr':v1461.stderr}
    v1462=subprocess.run([sys.executable,str(HERE/'v1462_dialogue_update.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    v1462_report=json.loads(v1462.stdout) if v1462.stdout.strip() else {'ok':False,'stderr':v1462.stderr}
    v1470=subprocess.run([sys.executable,str(HERE/'v1470_dialogue_linebreak_audit.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    title1470=subprocess.run([sys.executable,str(HERE/'v1470_dynamic_title_spacing_fix.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    v1470_report=json.loads(v1470.stdout) if v1470.stdout.strip() else {'ok':False,'stderr':v1470.stderr}
    title1470_report=json.loads(title1470.stdout) if title1470.stdout.strip() else {'ok':False,'stderr':title1470.stderr}
    v1471=subprocess.run([sys.executable,str(HERE/'v1471_common_particle_title_spacing_fix.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    v1471_report=json.loads(v1471.stdout) if v1471.stdout.strip() else {'ok':False,'stderr':v1471.stderr}
    result={'ok':bool(v.get('ok')) and not still_stock and c734_ok and shop_ok and layout34.returncode==0 and throne.returncode==0 and v1461.returncode==0 and v1462.returncode==0 and v1470.returncode==0 and title1470.returncode==0 and v1471.returncode==0,
            'scene_validation':v,'managed_files_still_exact_stock':still_stock,
            'c734_current_dialogue':c734_ok,'silence_f3':shop,
            'layout_34cell':layout34_report,'throne_room_layout':throne_report,'v1460_dialogue_layout':v1460_report,'v1461_dialogue_cleanup':v1461_report,'v1462_dialogue_update':v1462_report,'v1470_dialogue_linebreak_audit':v1470_report,'v1470_dynamic_title_spacing':title1470_report,'v1471_common_particle_title_spacing':v1471_report}
    print(json.dumps(result,ensure_ascii=False));return 0 if result['ok'] else 2

def main():
    ap=argparse.ArgumentParser(description='ED2 Text & Dialogue v5.0R19 — v1.4.71 common particle/title-spacing + R18 dialogue audit — stock-only source/delta patch')
    ap.add_argument('path',nargs='?',default='.');ap.add_argument('--scena-only',action='store_true');ap.add_argument('--check',action='store_true')
    ap.add_argument('--repair-c734',action='store_true');ap.add_argument('--verify-runtime',action='store_true');ap.add_argument('--repair-sell-shop',action='store_true');ap.add_argument('--verify-sell-shop',action='store_true')
    ap.add_argument('--no-backup',action='store_true');ap.add_argument('--with-chapter',action='store_true');ap.add_argument('--defer-r19',action='store_true')
    a=ap.parse_args();root=Path(a.path).resolve()
    if a.repair_c734:return repair_c734(root)
    if a.verify_runtime:return compat(root,['--verify-runtime'])
    if a.repair_sell_shop:return compat(root,['--repair-sell-shop'])
    if a.verify_sell_shop:return compat(root,['--verify-sell-shop'])
    if a.check:return semantic_check(root)
    # Recognize current and previous overlays before the stock/R15 delta applier.
    pre62=subprocess.run([sys.executable,str(HERE/'v1462_dialogue_update.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    if pre62.returncode!=0:
        pre61=subprocess.run([sys.executable,str(HERE/'v1461_dialogue_cleanup.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
        if pre61.returncode!=0:
            pre60=subprocess.run([sys.executable,str(HERE/'v1460_dialogue_layout_fix.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
            if pre60.returncode!=0:
                run([sys.executable,str(HERE/'apply_v5r15_scena.py'),str(root)])
                run([sys.executable,str(HERE/'v1460_dialogue_layout_fix.py'),str(root)])
            run([sys.executable,str(HERE/'v1461_dialogue_cleanup.py'),str(root)])
        run([sys.executable,str(HERE/'v1462_dialogue_update.py'),str(root)])
    run([sys.executable,str(HERE/'v1470_dialogue_linebreak_audit.py'),str(root)])
    run([sys.executable,str(HERE/'v1470_dynamic_title_spacing_fix.py'),str(root)])
    if not a.scena_only:
        run([sys.executable,str(HERE/'text_patch/patch_ed2_text.py'),str(root)],{'ED2_TEXT_SKIP_SCENA':'1'})
        run([sys.executable,str(HERE/'text_patch/v1454_common_battle_messages.py'),str(root/'ED2MAIN.EXE')])
        if not a.defer_r19:
            run([sys.executable,str(HERE/'v1471_common_particle_title_spacing_fix.py'),str(root)])
    elif not a.defer_r19:
        run([sys.executable,str(HERE/'v1471_common_particle_title_spacing_fix.py'),str(root),'--scena-only'])
    if a.defer_r19:
        print('Text & Dialogue R18 migration 적용 완료; R19 final delta는 AIO 최종 owner 단계로 연기합니다.')
    else:
        print('Text & Dialogue v5.0R19 + v1.4.71 공통 조사/동적 호칭 수정 적용 완료.')
    return 0
if __name__=='__main__':raise SystemExit(main())
