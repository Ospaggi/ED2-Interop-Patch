#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,sys,tempfile
from pathlib import Path,PurePosixPath
HERE=Path(__file__).resolve().parent
SPEC=json.loads((HERE/'r20_final_spec.json').read_text(encoding='utf-8'))
VERSION=SPEC['version']
TARGET_STATE='r20_final'
BASE_STATE='v1.4.72'
class PatchError(RuntimeError):pass

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def is_root(p:Path)->bool:return (p/'ED2MAIN.EXE').is_file() and (p/'ED2END.EXE').is_file() and (p/'SCENA').is_dir() and (p/'MON').is_dir()
def resolve_root(arg):
    if arg is not None:
        p=arg.expanduser().resolve()
        if p.is_file() and p.name.upper()=='ED2MAIN.EXE':p=p.parent
        if is_root(p):return p
        raise PatchError(f'지정한 경로가 ED2 게임 루트가 아닙니다: {p}')
    for p in [Path.cwd().resolve(),*Path.cwd().resolve().parents]:
        if is_root(p):return p
    raise PatchError('ED2 게임 루트를 지정하십시오.')
def gp(root:Path,rel:str)->Path:
    parts=PurePosixPath(rel).parts
    if not parts or any(x in ('','.','..') for x in parts):raise PatchError(f'잘못된 경로: {rel}')
    if parts[0].upper()=='SAVE' or parts[-1].upper()=='ED2.SWP':raise PatchError(f'금지된 대상: {rel}')
    p=root.joinpath(*parts).resolve()
    try:p.relative_to(root.resolve())
    except ValueError:raise PatchError(f'루트 밖 경로: {rel}')
    return p
def apply_hunks(data:bytes,hs:list[dict],reverse=False)->bytes:
    out=bytearray(data)
    for h in hs:
        off=int(h['offset']);old=bytes.fromhex(h['new'] if reverse else h['old']);new=bytes.fromhex(h['old'] if reverse else h['new'])
        if len(old)!=len(new):raise PatchError('내부 hunk 길이 오류')
        if off<0 or off+len(old)>len(out):raise PatchError(f'hunk 범위 오류 @0x{off:X}')
        if bytes(out[off:off+len(old)])!=old:raise PatchError(f'hunk precondition 실패 @0x{off:X}')
        out[off:off+len(old)]=new
    return bytes(out)
def atomic_write(p:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=p.name+'.',suffix='.r20tmp',dir=str(p.parent))
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,p)
    except Exception:
        try:os.unlink(tmp)
        except OSError:pass
        raise
def preflight(root:Path):
    prepared={};states={}
    for rel,fs in SPEC['files'].items():
        p=gp(root,rel)
        if not p.is_file():raise PatchError(f'{rel}: 파일이 없습니다')
        old=p.read_bytes()
        if len(old)!=fs['size']:raise PatchError(f'{rel}: 파일 크기가 예상과 다릅니다')
        h=sha(old)
        if h==fs['base_sha256']:
            target=apply_hunks(old,fs['hunks'])
            if sha(target)!=fs['target_sha256']:raise PatchError(f'{rel}: target SHA 생성 실패')
            states[rel]='base';prepared[rel]=(p,old,target)
        elif h==fs['target_sha256']:
            base=apply_hunks(old,fs['hunks'],True)
            if sha(base)!=fs['base_sha256']:raise PatchError(f'{rel}: reverse SHA 생성 실패')
            states[rel]='target';prepared[rel]=(p,old,base)
        else:raise PatchError(f'{rel}: 지원되지 않는/custom SHA-256 {h}')
    ss=set(states.values())
    if ss=={'base'}:overall=BASE_STATE
    elif ss=={'target'}:overall=TARGET_STATE
    else:overall='mixed'
    return overall,prepared,states
def rollback(written):
    failed=[]
    for p,before in reversed(written):
        try:atomic_write(p,before)
        except Exception:failed.append(str(p))
    return failed
def transaction(rows):
    written=[]
    try:
        for p,before,after in rows:
            atomic_write(p,after);written.append((p,before))
        return written
    except Exception as e:
        failed=rollback(written)
        if failed:raise PatchError(f'패치 실패 + rollback 실패: {failed[:5]}') from e
        raise PatchError('패치 중 오류가 발생하여 이번 실행 변경을 모두 롤백했습니다.') from e

def main():
    ap=argparse.ArgumentParser(description='ED2 Text & Dialogue v5.0R20 FINAL exact-hunk updater for v1.4.73 integration')
    ap.add_argument('game_root',nargs='?',type=Path)
    act=ap.add_mutually_exclusive_group();act.add_argument('--apply',action='store_true');act.add_argument('--verify',action='store_true');act.add_argument('--restore',action='store_true')
    a=ap.parse_args()
    try:
        root=resolve_root(a.game_root);state,prepared,states=preflight(root)
        if state=='mixed':raise PatchError('v1.4.72와 TEST17이 섞인 중간 상태입니다. writes=0')
        if a.verify or (not a.apply and not a.restore):
            rep={'ok':state==TARGET_STATE,'version':VERSION,'state':state,'target_files':len(prepared),'writes':0}
            print(json.dumps(rep,ensure_ascii=False,indent=2));return 0 if state==TARGET_STATE else 3
        if a.apply:
            if state==TARGET_STATE:
                print(json.dumps({'ok':True,'version':VERSION,'state':TARGET_STATE,'action':'already_applied','writes':0},ensure_ascii=False,indent=2));return 0
            rows=[(p,old,new) for p,old,new in prepared.values()]
            written=transaction(rows)
            try:
                post,_,_=preflight(root)
                if post!=TARGET_STATE:raise PatchError(f'postflight 실패: {post}')
            except Exception:
                failed=rollback(written)
                if failed:raise PatchError(f'postflight 실패 + rollback 실패: {failed[:5]}')
                raise
            print(json.dumps({'ok':True,'version':VERSION,'state':TARGET_STATE,'action':'applied','writes':len(rows)},ensure_ascii=False,indent=2));return 0
        if a.restore:
            if state==BASE_STATE:
                print(json.dumps({'ok':True,'version':VERSION,'state':BASE_STATE,'action':'already_restored','writes':0},ensure_ascii=False,indent=2));return 0
            rows=[(p,old,base) for p,old,base in prepared.values()]
            written=transaction(rows)
            try:
                post,_,_=preflight(root)
                if post!=BASE_STATE:raise PatchError(f'restore postflight 실패: {post}')
            except Exception:
                failed=rollback(written)
                if failed:raise PatchError(f'restore postflight 실패 + rollback 실패: {failed[:5]}')
                raise
            print(json.dumps({'ok':True,'version':VERSION,'state':BASE_STATE,'action':'restored','writes':len(rows)},ensure_ascii=False,indent=2));return 0
    except Exception as e:
        print(f'[ERROR] {e}',file=sys.stderr)
        print(json.dumps({'ok':False,'version':VERSION,'error':str(e),'writes':0},ensure_ascii=False,indent=2),file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
