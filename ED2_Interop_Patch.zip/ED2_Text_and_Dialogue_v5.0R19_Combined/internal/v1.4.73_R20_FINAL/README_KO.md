# ED2 Text & Dialogue v5.0R20 FINAL

사용자 플레이 승인을 받은 STAGE34 TEST17을 v1.4.73용 R20 FINAL로 승격한 구성요소입니다.

- 최종전 의미 텍스트는 동결했습니다.
- 최종전 외 PC-98 전체 대사 및 수동 correction을 의미 감사했습니다.
- 이 구성요소의 독립 소유 범위는 SCENA 254개 + ED2MAIN/ED2END의 R20 공통 전투 텍스트 영역입니다.
- Monster Text v16 TEST2와 동일한 16개 MON DLL은 이 spec에서 제거하여 이중 적용을 방지했습니다.
- SAVE와 ED2.SWP는 대상이 아닙니다.
