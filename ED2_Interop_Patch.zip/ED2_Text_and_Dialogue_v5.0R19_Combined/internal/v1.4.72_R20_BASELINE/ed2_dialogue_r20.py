#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,shutil,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
SPEC=json.loads((HERE/'r20_spec.json').read_text(encoding='utf-8'))
VERSION='v5.0R20'
def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def is_root(p:Path)->bool:return (p/'ED2MAIN.EXE').is_file() and (p/'ED2END.EXE').is_file() and (p/'SCENA').is_dir() and (p/'SCENA'/'C_002.DLL').is_file()
def resolve_root(arg):
    if arg is not None:
        p=arg.expanduser().resolve()
        if is_root(p):return p
        raise RuntimeError(f'지정한 경로가 ED2 게임 루트가 아닙니다: {p}')
    cand=[]
    for seed in [Path.cwd().resolve(),HERE.resolve()]:
      for p in [seed,*seed.parents]:
        if is_root(p) and p not in cand:cand.append(p)
    if len(cand)==1:return cand[0]
    if not cand:raise RuntimeError('ED2 게임 루트를 찾지 못했습니다. 게임 폴더를 APPLY_R20_TEST5_STAGE15.bat 위로 드래그하십시오.')
    raise RuntimeError('ED2 게임 루트 후보가 여러 개입니다. 임의 선택하지 않습니다:\n  '+'\n  '.join(map(str,cand)))
def apply_hunks(data,hs):
    out=bytearray(data)
    for h in hs:
      off=int(h['offset']);old=bytes.fromhex(h['old']);new=bytes.fromhex(h['new'])
      if len(old)!=len(new):raise RuntimeError('내부 패치 정의 길이 오류')
      if bytes(out[off:off+len(old)])!=old:raise RuntimeError(f'내부 hunk precondition 실패 @0x{off:X}')
      out[off:off+len(old)]=new
    return bytes(out)
def report_path():return HERE/'R20_LAST_REPORT.json'
def main():
    ap=argparse.ArgumentParser(description='ED2 Text & Dialogue v5.0R20')
    ap.add_argument('game_root',nargs='?',type=Path);ap.add_argument('--apply',action='store_true');ap.add_argument('--verify',action='store_true');ap.add_argument('--no-backup',action='store_true');a=ap.parse_args()
    try:root=resolve_root(a.game_root)
    except Exception as e:print(f'오류: {e}',file=sys.stderr);return 2
    prepared={};states={}
    try:
      for rel,fs in SPEC['files'].items():
        p=root/Path(rel)
        if not p.is_file():raise RuntimeError(f'{rel}: 파일이 없습니다')
        old=p.read_bytes()
        if len(old)!=fs['size']:raise RuntimeError(f'{rel}: 파일 크기가 예상과 다릅니다')
        h=sha(old)
        if h==fs['target_sha256']:new=old;state='target'
        elif h in fs['variants']:
          v=fs['variants'][h];new=apply_hunks(old,v['hunks']);state='+'.join(v['labels'])
          if sha(new)!=fs['target_sha256']:raise RuntimeError(f'{rel}: 최종 SHA 검증 실패')
        else:raise RuntimeError(f'{rel}: 지원되지 않는/custom SHA-256 {h}')
        prepared[rel]=(p,old,new);states[rel]=state
    except Exception as e:
      rep={'ok':False,'version':VERSION,'root':str(root),'phase':'preflight','error':str(e),'writes':0};report_path().write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8');print(f'오류: {e}',file=sys.stderr);return 1
    pending=[rel for rel,(p,old,new) in prepared.items() if old!=new]
    if a.verify and not a.apply:
      rep={'ok':not pending,'version':VERSION,'root':str(root),'target_files':len(prepared),'pending':pending,'states':states,'writes':0};report_path().write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
      print(f'[R20] 최종 상태: {len(prepared)-len(pending)}/{len(prepared)}')
      if pending:print('[R20] 적용 필요:',', '.join(pending));return 3
      print('[R20] VERIFY PASS');return 0
    if not a.apply:print('적용: --apply / 확인: --verify');return 0
    backup=root/'ED2_R20_BACKUP'
    if not a.no_backup:
      for rel in pending:
        src=prepared[rel][0];dst=backup/Path(rel);dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():shutil.copy2(src,dst)
    for rel in pending:
      p,old,new=prepared[rel];tmp=p.with_name(p.name+'.r20tmp');tmp.write_bytes(new);tmp.replace(p)
    try:
      for rel,fs in SPEC['files'].items():
        if sha((root/Path(rel)).read_bytes())!=fs['target_sha256']:raise RuntimeError(f'{rel}: postflight SHA 불일치')
    except Exception as e:
      rep={'ok':False,'version':VERSION,'root':str(root),'phase':'postflight','error':str(e),'writes':len(pending)};report_path().write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8');print(f'오류: {e}',file=sys.stderr);return 1
    rep={'ok':True,'version':VERSION,'root':str(root),'changed_files':len(pending),'target_files':len(prepared),'states_before':states,'writes':len(pending)};report_path().write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'[R20] 적용 완료: {len(pending)}개 파일 변경 / 누적 대상 {len(prepared)}개 검증')
    print('[R20] Text & Dialogue v5.0R20 최종 상태입니다.')
    return 0
if __name__=='__main__':raise SystemExit(main())
