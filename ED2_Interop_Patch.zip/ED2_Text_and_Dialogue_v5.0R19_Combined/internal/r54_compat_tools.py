#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent.parent
DATA=HERE/'data'
MANIFEST=DATA/'dialogue_targets.json'
SNAPSHOT=DATA/'dialogue_snapshot.zip'
CHAPTER=DATA/'chapter_overlay.zip'
VERSION='v4.1R54-consolidated'
SELL_SHOP_TABLES=DATA/'sell_shop_tables.json'
R53_AUDIT=DATA/'R53_NATURALNESS_AUDIT_CHANGES.json'
R54_AUDIT=DATA/'R54_ERION_NATURALNESS_CHANGES.json'
SELL_SHOP_REPAIRS={
    'T_101.DLL': (3,0x08FC,bytes.fromhex('0409170939094E09B9BB20C6C4BDC7B7A1BFE43FFFFFFFFFFF0107'),
                  {bytes.fromhex('040917B9BB20C6C4BDC3B0DABDC0B4CFB1EE3FFFFFFFFFFFFF0107')}),
    'T_510.DLL': (3,0x09A0,bytes.fromhex('A809B709DD09F309B9BB20C6C8B0ED20BDCDC1F63F0107'),
                  {bytes.fromhex('A809B709DD09F3B9BB20C6C8B0ED20BDCDC1F63FFF0107')}),
    'T_532.DLL': (3,0x097A,bytes.fromhex('82098F09AD09C109B9BB20C6C8B0DAB3AA3F200107'),
                  {bytes.fromhex('82098F09AD09C1B9BB20C6C8B0DAB3AA3F20FF0107')}),
}
class DialogueError(RuntimeError): pass
def sha_bytes(b: bytes)->str: return hashlib.sha256(b).hexdigest()
def sha_file(p: Path)->str: return sha_bytes(p.read_bytes())
def atomic_write(p: Path,b: bytes):
    tmp=p.with_name(p.name+'.dialogue.tmp'); tmp.write_bytes(b); os.replace(tmp,p)
def load_manifest(): return json.loads(MANIFEST.read_text(encoding='utf-8'))
def zip_map(path: Path):
    with zipfile.ZipFile(path) as z: return {n:z.read(n) for n in z.namelist() if not n.endswith('/')}
def desired_map(with_chapter: bool):
    m=load_manifest(); base=zip_map(SNAPSHOT); overlay=zip_map(CHAPTER) if with_chapter else {}
    rows={r['file']:r for r in m['base_files']}; ov={r['file']:r for r in m['chapter_overlay']}
    out={}
    for name,r in rows.items():
        b=overlay.get(name,base[name]); h=sha_bytes(b)
        expected=(ov[name]['sha256'] if name in overlay else r['dialogue_sha256'])
        if h!=expected: raise DialogueError(f'내장 스냅샷 해시 불일치: {name}')
        out[name]=(b,r['stock_sha256'],expected)
    return out
def apply_snapshot(root: Path, with_chapter: bool, check: bool, no_backup: bool):
    root=root.resolve(); scena=root/'SCENA'
    if not (root/'ED2MAIN.EXE').is_file() or not scena.is_dir(): raise DialogueError('영웅전설 II 게임 폴더를 찾지 못했습니다.')
    desired=desired_map(with_chapter); unknown=[]; changed=[]
    for name,(data,stock_h,want_h) in desired.items():
        p=scena/name
        if not p.is_file(): unknown.append((name,'missing')); continue
        cur=sha_file(p)
        allowed={stock_h,want_h}
        # The non-chapter snapshot is also accepted when switching to the chapter profile.
        if with_chapter:
            row=next(r for r in load_manifest()['base_files'] if r['file']==name); allowed.add(row['dialogue_sha256'])
        if cur not in allowed: unknown.append((name,cur))
    if unknown:
        sample=', '.join(f'{n}:{h[:12]}' for n,h in unknown[:8]); raise DialogueError('지원하지 않는 SCENA 상태가 있습니다: '+sample)
    if check:
        bad=[]
        for name,(_,_,want_h) in desired.items():
            h=sha_file(scena/name)
            if h!=want_h: bad.append(name)
        print(json.dumps({'version':VERSION,'mode':'check','profile':'dialogue+chapter' if with_chapter else 'dialogue','ok':not bad,'mismatches':bad},ensure_ascii=False))
        return 0 if not bad else 1
    backup_ok=not no_backup and os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP')!='1'
    backup=root/'ED2_DIALOGUE_BACKUP'
    if backup_ok: backup.mkdir(exist_ok=True)
    for name,(data,_,want_h) in desired.items():
        p=scena/name; cur=sha_file(p)
        if cur==want_h: continue
        if backup_ok:
            bp=backup/name
            if not bp.exists(): shutil.copy2(p,bp)
        atomic_write(p,data); changed.append(name)
    bad=[name for name,(_,_,want_h) in desired.items() if sha_file(scena/name)!=want_h]
    if bad: raise DialogueError('적용 후 해시 검증 실패: '+', '.join(bad[:8]))
    print(json.dumps({'version':VERSION,'profile':'dialogue+chapter' if with_chapter else 'dialogue','changed_files':len(changed),'files':changed},ensure_ascii=False))
    return 0
def run_internal(script: str, root: Path, args: list[str]):
    cmd=[sys.executable,str(HERE/'internal'/script),str(root),*args]
    cp=subprocess.run(cmd,text=True,capture_output=True)
    if cp.stdout: print(cp.stdout.rstrip())
    if cp.returncode:
        if cp.stderr: print(cp.stderr.rstrip(),file=sys.stderr)
        raise DialogueError(f'{script} 실행 실패 (exit {cp.returncode})')
def r53_upgrade(root: Path, check: bool=False):
    root=root.resolve(); scena=root/'SCENA'
    if not scena.is_dir(): raise DialogueError('SCENA 폴더를 찾지 못했습니다.')
    audit=json.loads(R53_AUDIT.read_text(encoding='utf-8'))
    r54_rows={}
    if R54_AUDIT.is_file():
        r54=json.loads(R54_AUDIT.read_text(encoding='utf-8'))
        r54_rows={(x['dll'],x['offset']):x for x in r54.get('changes',[])}
    changed=[]; unknown=[]
    for row in audit['changes']:
        p=scena/row['dll']
        if not p.is_file(): unknown.append((row['dll'],row['offset'],'missing')); continue
        raw=bytearray(p.read_bytes()); pos=int(row['file_offset'],16); n=int(row['editable_bytes'])
        old=row['before'].encode('cp949'); new=row['after'].encode('cp949')
        oldslot=old+b'\xFF'*(n-len(old)); newslot=new+b'\xFF'*(n-len(new))
        cur=bytes(raw[pos:pos+n])
        if cur==newslot: continue
        downstream=r54_rows.get((row['dll'],row['offset']))
        if downstream is not None:
            final=downstream['after'].encode('cp949')
            finalslot=final+b'\xFF'*(n-len(final))
            if cur==finalslot:
                continue
        if cur!=oldslot:
            unknown.append((row['dll'],row['offset'],cur.hex()))
            continue
        if not check:
            raw[pos:pos+n]=newslot; atomic_write(p,bytes(raw)); changed.append(f"{row['dll']}:{row['offset']}")
        else:
            changed.append(f"{row['dll']}:{row['offset']}")
    if unknown:
        sample=', '.join(f'{a}:{b}' for a,b,*_ in unknown[:8]); raise DialogueError('R53 자연스러움 수정에서 지원하지 않는 상태: '+sample)
    result={'version':VERSION,'mode':'r53-check' if check else 'r53-upgrade','changed_slots':len(changed),'slots':changed}
    print(json.dumps(result,ensure_ascii=False))
    return 1 if check and changed else 0

def r54_upgrade(root: Path, check: bool=False):
    root=root.resolve(); scena=root/'SCENA'
    if not scena.is_dir(): raise DialogueError('SCENA 폴더를 찾지 못했습니다.')
    audit=json.loads(R54_AUDIT.read_text(encoding='utf-8'))
    changed=[]; unknown=[]
    for row in audit['changes']:
        p=scena/row['dll']
        if not p.is_file(): unknown.append((row['dll'],row['offset'],'missing')); continue
        raw=bytearray(p.read_bytes()); pos=int(row['file_offset'],16); n=int(row['editable_bytes'])
        old=row['before'].encode('cp949'); new=row['after'].encode('cp949')
        oldslot=old+b'\xFF'*(n-len(old)); newslot=new+b'\xFF'*(n-len(new))
        cur=bytes(raw[pos:pos+n])
        if cur==newslot: continue
        if cur!=oldslot:
            unknown.append((row['dll'],row['offset'],cur.hex())); continue
        if not check:
            raw[pos:pos+n]=newslot; atomic_write(p,bytes(raw)); changed.append(f"{row['dll']}:{row['offset']}")
        else:
            changed.append(f"{row['dll']}:{row['offset']}")
    if unknown:
        sample=', '.join(f'{a}:{b}' for a,b,*_ in unknown[:8]); raise DialogueError('R54 에리온 말투 수정에서 지원하지 않는 상태: '+sample)
    result={'version':VERSION,'mode':'r54-check' if check else 'r54-upgrade','changed_slots':len(changed),'slots':changed}
    print(json.dumps(result,ensure_ascii=False))
    return 1 if check and changed else 0

def legacy_upgrade(root: Path):
    run_internal('legacy_context_upgrade.py',root,['--no-backup']); run_internal('flora_morgan_upgrade.py',root,['--no-backup']); return 0
def verify_runtime(root: Path):
    run_internal('legacy_context_upgrade.py',root,['--check']); run_internal('flora_morgan_upgrade.py',root,['--check'])
    # R49 C_101 rollback guard.
    raw=(root/'SCENA'/'C_101.DLL').read_bytes(); ok=('못하는 것도 무리는 아니지.'.encode('cp949') in raw and '못해도'.encode('cp949') not in raw)
    print(json.dumps({'version':VERSION,'mode':'runtime-check','c101_r49_rollback':ok,'ok':ok},ensure_ascii=False))
    return 0 if ok else 1
def repair_c734(root: Path):
    scene=HERE/'scene_editor'; source=DATA/'c734_dialogue.csv'
    c734=root/'SCENA'/'C_734.DLL'
    if not c734.is_file():
        raise DialogueError('SCENA/C_734.DLL이 없습니다.')
    # v1.4.46 final-battle target already embeds the current dialogue text and
    # the semantic 01h line breaks.  Re-importing the old fixed-slot CSV would
    # reinterpret those 01h bytes as slot boundaries and reject editable_bytes.
    # Treat the exact verified target as authoritative and only run structure
    # validation.  Older/noncanonical layouts retain the legacy repair path.
    current_sha=sha_file(c734)
    sys.path.insert(0,str(scene)); from ed2_scene_editor import SceneProject
    p=SceneProject(root); changed=p.import_strings_csv(source,dialogues_only=False); validation=p.validate()
    report={'version':VERSION,'mode':'repair-c734','rows_changed':changed,'already_current':False,'validation':validation}
    print(json.dumps(report,ensure_ascii=False)); return 0 if validation.get('ok',False) else 1
def _scene_segment(root: Path, dll: str, segment_index: int):
    scene=HERE/'scene_editor'; sys.path.insert(0,str(scene))
    from ed2_scene_editor import parse_ne_segments
    path=root/'SCENA'/dll
    if not path.is_file(): raise DialogueError(f'{dll}이 없습니다.')
    raw=bytearray(path.read_bytes()); segments=parse_ne_segments(raw)
    if not 1 <= segment_index <= len(segments): raise DialogueError(f'{dll}: 세그먼트 {segment_index}가 없습니다.')
    return path,raw,segments[segment_index-1]

def verify_sell_shop(root: Path):
    spec=json.loads(SELL_SHOP_TABLES.read_text(encoding='utf-8'))
    bad=[]; checked=0
    for row in spec['tables']:
        dll=row['dll']; segno=int(row['segment']); off=int(row['struct_offset'],0)
        path,raw,seg=_scene_segment(root,dll,segno)
        block=raw[seg.file_offset:seg.file_offset+seg.length]
        want=[int(x,0) for x in row['pointers']]
        got=[int.from_bytes(block[off+i*2:off+i*2+2],'little') for i in range(4)]
        checked+=1
        if got!=want:
            bad.append({'dll':dll,'struct_offset':row['struct_offset'],'expected':row['pointers'],'actual':[f'0x{x:04X}' for x in got]})
    # User-reported Rondo path: the second SELL_SHOP suffix must render the
    # numeric sale price followed by exactly " Gold인데요." and the next line.
    path,raw,seg=_scene_segment(root,'T_101.DLL',3)
    block=bytes(raw[seg.file_offset:seg.file_offset+seg.length])
    rondo=(block[0x0917:0x0923]==' Gold인데요.'.encode('cp949')
           and block[0x092C:0x0937]=='괜찮을까요?'.encode('cp949'))
    report={'version':VERSION,'mode':'sell-shop-check','tables_checked':checked,'mismatches':bad,
            'rondo_suffix':'7 Gold인데요. / 괜찮을까요?','rondo_suffix_bytes_ok':rondo,
            'ok':not bad and rondo}
    print(json.dumps(report,ensure_ascii=False))
    return 0 if report['ok'] else 1

def repair_sell_shop(root: Path, check: bool=False):
    root=root.resolve(); changed=[]
    for dll,(segno,off,want,old_variants) in SELL_SHOP_REPAIRS.items():
        path,raw,seg=_scene_segment(root,dll,segno)
        begin=seg.file_offset+off; cur=bytes(raw[begin:begin+len(want)])
        if cur==want: continue
        if check:
            raise DialogueError(f'{dll}: SELL_SHOP 복구가 필요합니다.')
        if cur not in old_variants:
            raise DialogueError(f'{dll}: 알 수 없는 SELL_SHOP 손상 상태입니다: {cur.hex().upper()}')
        raw[begin:begin+len(want)]=want; atomic_write(path,bytes(raw)); changed.append(dll)
    rc=verify_sell_shop(root)
    if rc: raise DialogueError('SELL_SHOP 포인터 전수 검증에 실패했습니다.')
    print(json.dumps({'version':VERSION,'mode':'repair-sell-shop','changed_files':len(changed),'files':changed,'ok':True},ensure_ascii=False))
    return 0

def main():
    ap=argparse.ArgumentParser(description='ED2 consolidated dialogue patch')
    ap.add_argument('game_root',type=Path); ap.add_argument('--with-chapter',action='store_true'); ap.add_argument('--check',action='store_true')
    ap.add_argument('--legacy-upgrade',action='store_true'); ap.add_argument('--r53-upgrade',action='store_true'); ap.add_argument('--r53-check',action='store_true'); ap.add_argument('--r54-upgrade',action='store_true'); ap.add_argument('--r54-check',action='store_true'); ap.add_argument('--verify-runtime',action='store_true'); ap.add_argument('--repair-c734',action='store_true')
    ap.add_argument('--repair-sell-shop',action='store_true'); ap.add_argument('--verify-sell-shop',action='store_true'); ap.add_argument('--no-backup',action='store_true')
    a=ap.parse_args()
    try:
        if a.legacy_upgrade: return legacy_upgrade(a.game_root)
        if a.r53_upgrade: return r53_upgrade(a.game_root,False)
        if a.r53_check: return r53_upgrade(a.game_root,True)
        if a.r54_upgrade: return r54_upgrade(a.game_root,False)
        if a.r54_check: return r54_upgrade(a.game_root,True)
        if a.verify_runtime: return verify_runtime(a.game_root)
        if a.repair_c734: return repair_c734(a.game_root)
        if a.repair_sell_shop: return repair_sell_shop(a.game_root)
        if a.verify_sell_shop: return verify_sell_shop(a.game_root)
        return apply_snapshot(a.game_root,a.with_chapter,a.check,a.no_backup)
    except Exception as e:
        print('ERROR:',e,file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
