#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib,struct,zlib
MAGIC=b'ED2R15D1'
class DeltaError(RuntimeError): pass

def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()

def read_archive(path:Path)->dict[str,dict]:
    b=path.read_bytes(); p=0
    if b[:len(MAGIC)]!=MAGIC: raise DeltaError('잘못된 ED2 delta magic')
    p=len(MAGIC)
    if p+2>len(b):raise DeltaError('잘린 ED2 delta header')
    cnt=struct.unpack_from('<H',b,p)[0];p+=2;out={}
    for _ in range(cnt):
        if p>=len(b):raise DeltaError('잘린 ED2 delta entry')
        nl=b[p];p+=1;name=b[p:p+nl].decode('ascii');p+=nl
        ss,ts=struct.unpack_from('<II',b,p);p+=8
        sh=b[p:p+32].hex();p+=32;th=b[p:p+32].hex();p+=32
        cl=struct.unpack_from('<I',b,p)[0];p+=4;comp=b[p:p+cl];p+=cl
        raw=zlib.decompress(comp);q=0;rc=struct.unpack_from('<I',raw,q)[0];q+=4;runs=[]
        for _i in range(rc):
            off,ln=struct.unpack_from('<II',raw,q);q+=8;data=raw[q:q+ln];q+=ln
            if len(data)!=ln:raise DeltaError(f'{name}: 잘린 run')
            runs.append((off,data))
        if q!=len(raw):raise DeltaError(f'{name}: trailing delta data')
        out[name]={'file':name,'source_size':ss,'target_size':ts,'source_sha256':sh,'target_sha256':th,'runs':runs}
    if p!=len(b):raise DeltaError('ED2 delta archive trailing bytes')
    return out

def apply_bytes(source:bytes,e:dict)->bytes:
    if len(source)!=e['source_size'] or sha(source)!=e['source_sha256']:
        raise DeltaError(f"{e['file']}: delta 원본 SHA/크기 불일치")
    target_size=e['target_size']; out=bytearray(source[:target_size])
    if len(out)<target_size:out.extend(b'\0'*(target_size-len(out)))
    for off,data in e['runs']:
        end=off+len(data)
        if end>target_size:raise DeltaError(f"{e['file']}: run 범위 초과")
        out[off:end]=data
    result=bytes(out)
    if sha(result)!=e['target_sha256']:
        raise DeltaError(f"{e['file']}: delta 결과 SHA 불일치")
    return result

def apply_named(source:bytes,archive:Path,name:str)->bytes:
    e=read_archive(archive).get(name)
    if e is None:raise DeltaError(f'delta entry 없음: {name}')
    return apply_bytes(source,e)
