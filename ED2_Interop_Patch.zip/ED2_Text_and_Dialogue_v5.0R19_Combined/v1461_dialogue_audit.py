#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
HERE=Path(__file__).resolve().parent
def run(p,root):
 r=subprocess.run([sys.executable,str(HERE/p),str(root),'--check'] if 'cleanup' in p or 'layout_fix' in p else [sys.executable,str(HERE/p),str(root)],capture_output=True,text=True,encoding='utf-8'); return r
def main():
 root=Path(sys.argv[1]).resolve(); a=run('v1460_dialogue_audit.py',root); b=run('v1461_dialogue_cleanup.py',root)
 checks={'v1460_audit':a.returncode==0,'v1461_cleanup':b.returncode==0}
 # exact visible regression strings
 samples={}
 for fn,need,bad in [('C_203.DLL','들어왔습니다.'.encode('cp949')+b'\x01'+'성까지 오는 것도'.encode('cp949'),'들어왔습니다.성까지'.encode('cp949')),('T_543.DLL','황제 폐하께 거역한 대가를'.encode('cp949'), '황제 폐하께 거역하면, 그 대가를'.encode('cp949'))]:
  raw=(root/'SCENA'/fn).read_bytes(); samples[fn]=need in raw and bad not in raw
 ok=all(checks.values()) and all(samples.values()); print(json.dumps({'ok':ok,'version':'1.4.61','checks':checks,'samples':samples},ensure_ascii=False,indent=2)); return 0 if ok else 2
if __name__=='__main__': raise SystemExit(main())
