#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, os, struct, tempfile, hashlib

VERSION='1.4.60'

def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def seg_base(data:bytes,index:int=3)->int:
    if data[:2]!=b'MZ': raise RuntimeError('MZ 헤더가 없습니다')
    ne=u32(data,0x3C)
    if data[ne:ne+2]!=b'NE': raise RuntimeError('NE 헤더가 없습니다')
    count=u16(data,ne+0x1C); table=ne+u16(data,ne+0x22); shift=u16(data,ne+0x32)
    if not 1<=index<=count: raise RuntimeError('세그먼트 번호 오류')
    sector=u16(data,table+(index-1)*8)
    return sector<<shift

def cp(s): return s.encode('cp949')

# (file, segment, offset, old, new, reason)
SITES=[]
def add(fn,off,old,new,reason,seg=3):
    assert len(old)==len(new),(fn,reason,len(old),len(new))
    SITES.append((fn,seg,off,old,new,reason))

# Prologue title: remove the v1.4.59 double redirect and restore the clean
# v1.4.52-style 9-space centered path.
add('V_000.DLL',0x0002,bytes.fromhex('2020202020200F7D080F4308FF'),bytes.fromhex('2020202020202020200F7D08FF'),'영웅들의 전설 II 원본 슬롯 단일 redirect 복원')
add('V_000.DLL',0x087D,bytes.fromhex('202020202020202020BFB5BFF5B5E90F9308FF'),cp('영웅들의 전설 II')+bytes.fromhex('0F0F00'),'영웅들의 전설 II 전체 tail payload 복원')

# Gale: explicit semantic line breaks, with first line kept below 34 cells.
gale_old=cp('몇 사람을 시켜 물건을 팔게 했는데,그게 어찌나 돈이 되던지...')+b'\xFF'*5
gale_new=cp('몇 사람을 시켜서 물건을 팔았는데,')+b'\x01'+cp('그게 어찌나 돈이 되던지...')+b'\x01'+b'\xFF'*4
add('V_200.DLL',0x0360,gale_old,gale_new,'게일 대사 어절 분리/34셀 충돌 수정')

# High-confidence speaker-name orphan rows. 01h -> ASCII space keeps the name
# and the first short sentence on one line; dynamic item-name cases are excluded.
for fn,off,label in [
 ('C_201.DLL',0x00B4,'에리온 국왕'),
 ('T_100.DLL',0x0312,'다발'),
 ('T_100.DLL',0x0957,'도구상'),
 ('T_204.DLL',0x0B14,'여자'),
 ('T_208.DLL',0x06A6,'여자'),
 ('T_20C.DLL',0x06D9,'여자'),
 ('T_502.DLL',0x0239,'사내'),
 ('T_503.DLL',0x0882,'레이시아'),
 ('T_521.DLL',0x085A,'시장'),
 ('V_300.DLL',0x0173,'가드'),
]: add(fn,off,b'\x01',b' ',f'{label} 이름 단독행 병합')

# T_503: do not split 없/어요. across rows.
add('T_503.DLL',0x0A76,
    cp('아니지만 바위가 너무 커서 방법이')+b'\x01'+cp('없')+bytes.fromhex('0F090DFF'),
    cp('아니지만 바위가 너무 커서')+b'\x01'+cp('방법이 없')+bytes.fromhex('0F090DFF'),
    '레이시아 대사 없/어요 어절 분리 수정')

# V_300: combine the short vocative and rebalance the sentence.
add('V_300.DLL',0x0174,
    cp('대장,')+b'\x01'+cp('레지스탕스들은 모두 잡았습니다.'),
    cp('대장, 레지스탕스들은 모두')+b'\x01'+cp('잡았습니다.'),
    '대장 호격 단독행/후속 문장 재배치')

# The three 교육담당 라우엘 item-give screens are intentionally not altered:
# the visible item name is dynamic, so a fixed merge can exceed 34 cells.
DYNAMIC_EXCLUSIONS=['C_006.DLL','C_00A.DLL','C_00E.DLL']

def replace_atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.v1460.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def classify(root:Path):
    byfile={}
    for fn,seg,off,old,new,reason in SITES: byfile.setdefault(fn,[]).append((seg,off,old,new,reason))
    report=[]
    for fn,rows in byfile.items():
        p=root/'SCENA'/fn
        if not p.is_file(): report.append({'file':fn,'state':'missing'}); continue
        data=p.read_bytes(); states=[]
        for seg,off,old,new,reason in rows:
            base=seg_base(data,seg); cur=data[base+off:base+off+len(old)]
            if cur==new: st='fixed'
            elif cur==old: st='pending'
            else: st='unexpected'
            states.append({'segment':seg,'offset':f'0x{off:04X}','reason':reason,'state':st,'current_hex':cur.hex(),'old_hex':old.hex(),'new_hex':new.hex()})
        if any(x['state']=='unexpected' for x in states): state='unexpected'
        elif all(x['state']=='fixed' for x in states): state='fixed'
        elif all(x['state'] in ('fixed','pending') for x in states): state='pending'
        else: state='mixed'
        report.append({'file':fn,'state':state,'sites':states})
    return report

def apply(root:Path,check=False):
    root=root.resolve(); scena=root/'SCENA'
    if not scena.is_dir(): raise RuntimeError('SCENA 폴더가 없습니다')
    before=classify(root)
    unexpected=[s for f in before for s in f.get('sites',[]) if s['state']=='unexpected']
    if unexpected:
        raise RuntimeError('v1.4.60 레이아웃 대상 바이트가 예상과 다릅니다: '+json.dumps(unexpected[:5],ensure_ascii=False))
    if check:
        pending=sum(s['state']=='pending' for f in before for s in f.get('sites',[]))
        out={'ok':pending==0,'version':VERSION,'pending_sites':pending,'files':before,'dynamic_name_exclusions':DYNAMIC_EXCLUSIONS}
        print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['ok'] else 2
    byfile={}
    for fn,seg,off,old,new,reason in SITES: byfile.setdefault(fn,[]).append((seg,off,old,new,reason))
    changed=0; changed_files=[]
    for fn,rows in byfile.items():
        p=root/'SCENA'/fn; data=bytearray(p.read_bytes()); local=0
        for seg,off,old,new,reason in rows:
            base=seg_base(data,seg); pos=base+off; cur=bytes(data[pos:pos+len(old)])
            if cur==new: continue
            if cur!=old: raise RuntimeError(f'{fn} seg{seg}:0x{off:04X} guard mismatch')
            data[pos:pos+len(old)]=new; local+=1; changed+=1
        if local: replace_atomic(p,bytes(data)); changed_files.append(fn)
    after=classify(root)
    pending=sum(s['state']=='pending' for f in after for s in f.get('sites',[]))
    bad=sum(s['state']=='unexpected' for f in after for s in f.get('sites',[]))
    out={'ok':pending==0 and bad==0,'version':VERSION,'changed_sites':changed,'changed_files':changed_files,'pending_sites':pending,'unexpected_sites':bad,'dynamic_name_exclusions':DYNAMIC_EXCLUSIONS}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['ok'] else 2

def main():
    ap=argparse.ArgumentParser(description='ED2 v1.4.60 dialogue layout final pass')
    ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true')
    a=ap.parse_args(); return apply(a.root,a.check)
if __name__=='__main__': raise SystemExit(main())
