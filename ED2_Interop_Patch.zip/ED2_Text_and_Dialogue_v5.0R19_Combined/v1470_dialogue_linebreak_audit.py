#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, os, tempfile

HERE=Path(__file__).resolve().parent
SPEC_PATH=HERE/'data'/'V1470_DIALOGUE_LAYOUT_HUNKS.json'
VERSION='1.4.70'

def sha256(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

def replace_atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.v1470.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def load_spec():
    return json.loads(SPEC_PATH.read_text(encoding='utf-8'))

def classify_file(root:Path,entry:dict):
    p=root/'SCENA'/entry['file']
    if not p.is_file(): return {'file':entry['file'],'state':'missing'}
    data=p.read_bytes(); h=sha256(data)
    if h==entry['target_sha256']:
        return {'file':entry['file'],'state':'fixed','sha256':h}
    if h==entry['source_sha256']:
        return {'file':entry['file'],'state':'pending','sha256':h}
    # Intermediate AIO states can differ elsewhere in the same DLL because
    # later components have not run yet.  Accept such a variant only when
    # every audited byte is exactly source/target; any third value fails closed.
    sites=[]
    for hunk in entry['hunks']:
        off=int(hunk['offset']); old=bytes.fromhex(hunk['old_hex']); new=bytes.fromhex(hunk['new_hex'])
        cur=data[off:off+len(old)]
        st='fixed' if cur==new else ('pending' if cur==old else 'unexpected')
        sites.append({'offset':f'0x{off:06X}','state':st,'current_hex':cur.hex(),'old_hex':old.hex(),'new_hex':new.hex()})
    if any(x['state']=='unexpected' for x in sites): state='unexpected'
    elif all(x['state']=='fixed' for x in sites): state='compatible-fixed'
    elif all(x['state'] in ('fixed','pending') for x in sites): state='compatible-pending'
    else: state='unexpected'
    return {'file':entry['file'],'state':state,'sha256':h,'sites':sites}

def classify(root:Path,spec:dict):
    return [classify_file(root,e) for e in spec['files']]

def verify_elista(root:Path)->bool:
    p=root/'SCENA'/'T_000.DLL'
    if not p.is_file(): return False
    b=p.read_bytes()
    a='그러지 말고, 잠깐만이라도'.encode('cp949')
    z='밖에 나가게'.encode('cp949')
    c='해 주면 안 돼?'.encode('cp949')
    return a+b'\x01'+z+b'\xff\x20'+c in b

def apply(root:Path,check:bool=False):
    root=root.resolve(); spec=load_spec()
    if not (root/'SCENA').is_dir(): raise RuntimeError('SCENA 폴더가 없습니다.')
    before=classify(root,spec)
    bad=[x for x in before if x['state'] not in ('fixed','pending','compatible-fixed','compatible-pending')]
    if bad:
        raise RuntimeError('v1.4.70 대사 줄바꿈 입력 상태가 예상과 다릅니다: '+json.dumps(bad[:4],ensure_ascii=False))
    if check:
        pending=sum(x['state'] in ('pending','compatible-pending') for x in before)
        out={'ok':pending==0 and verify_elista(root),'version':VERSION,'files':len(before),'pending_files':pending,'elista_two_line':verify_elista(root),'states':before}
        print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['ok'] else 2
    changed_files=[]; changed_bytes=0
    for entry,state in zip(spec['files'],before):
        if state['state'] in ('fixed','compatible-fixed'): continue
        p=root/'SCENA'/entry['file']; data=bytearray(p.read_bytes())
        exact_source=(sha256(bytes(data))==entry['source_sha256'])
        local=0
        for hunk in entry['hunks']:
            off=int(hunk['offset']); old=bytes.fromhex(hunk['old_hex']); new=bytes.fromhex(hunk['new_hex'])
            cur=bytes(data[off:off+len(old)])
            if cur!=old: raise RuntimeError(f"{entry['file']}@0x{off:06X}: guard mismatch")
            # This release is display-only: never alter text/control operands beyond 01/20/FF layout bytes.
            if any(x not in (0x01,0x20,0xFF) for x in old+new):
                raise RuntimeError(f"{entry['file']}@0x{off:06X}: non-layout hunk rejected")
            data[off:off+len(old)]=new; local+=len(old)
        if exact_source and sha256(bytes(data))!=entry['target_sha256']:
            raise RuntimeError(f"{entry['file']}: target SHA-256 mismatch after patch")
        replace_atomic(p,bytes(data)); changed_files.append(entry['file']); changed_bytes+=local
    after=classify(root,spec)
    ok=all(x['state'] in ('fixed','compatible-fixed') for x in after) and verify_elista(root)
    out={'ok':ok,'version':VERSION,'changed_files':changed_files,'changed_file_count':len(changed_files),'changed_bytes':changed_bytes,'elista_two_line':verify_elista(root)}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if ok else 2

def main():
    ap=argparse.ArgumentParser(description='ED2 v1.4.70 dialogue line-break full audit overlay')
    ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true')
    a=ap.parse_args(); return apply(a.root,a.check)
if __name__=='__main__': raise SystemExit(main())
