@echo off
py -3 "%~dp0apply_combined.py" "%~1"
pause
