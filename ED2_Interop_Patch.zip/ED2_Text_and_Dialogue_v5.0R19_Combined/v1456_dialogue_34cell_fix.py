#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'scene_editor'))
from ed2_scene_editor import SceneProject,load_scene,split_dialogue_payload

LEGACY_ALLOW={('T_302.DLL',3,0x00B1,'이건 모레스톤 공화국의 리셀행이야.')}
EXPECTED_NEW_COLLISIONS=239

def cells(text:str)->int:
    return sum(1 if ord(ch)<128 else 2 for ch in text)

def scan(root:Path):
    p=SceneProject(root);hits=[]
    for path in p.paths:
        scene=load_scene(path,p.exe_ord_names);data=path.read_bytes()
        for e in scene.dialogues:
            visible,_editable,_suffix=split_dialogue_payload(e)
            pos=e.file_offset+e.capacity
            if cells(visible)==34 and pos<len(data) and data[pos]==0x01:
                hits.append((path.name,e.segment,e.offset,e.file_offset,e.capacity,pos,visible))
    return p,hits

def apply(root:Path):
    project,hits=scan(root)
    extra=[h for h in hits if (h[0],h[1],h[2],h[6]) not in LEGACY_ALLOW]
    if len(extra) not in (0,EXPECTED_NEW_COLLISIONS):
        raise RuntimeError(f'34셀+01h 후보 수가 예상과 다릅니다: {len(extra)} (expected 0 or {EXPECTED_NEW_COLLISIONS})')
    changed=0;files=set()
    if extra:
        byfile={}
        for h in extra:byfile.setdefault(h[0],[]).append(h)
        for fn,rows in byfile.items():
            path=root/'SCENA'/fn;data=bytearray(path.read_bytes())
            for _fn,_seg,_off,_fo,_cap,pos,_text in rows:
                if data[pos]!=0x01:raise RuntimeError(f'{fn}@0x{pos:X}: expected 01h')
                data[pos]=0xFF;changed+=1
            path.write_bytes(data);files.add(fn)
    p2,remain=scan(root)
    unexpected=[h for h in remain if (h[0],h[1],h[2],h[6]) not in LEGACY_ALLOW]
    allow=[h for h in remain if (h[0],h[1],h[2],h[6]) in LEGACY_ALLOW]
    val=p2.validate()
    report={'ok':not unexpected and len(allow)==1 and bool(val.get('ok')),
            'changed_controls':changed,'changed_files':len(files),
            'remaining_exact34_plus_01':len(remain),'legacy_allow_remaining':len(allow),
            'unexpected_remaining':len(unexpected),'scene_validation':val}
    if not report['ok']:raise RuntimeError('34셀 중복 개행 적용 후 검증 실패: '+json.dumps(report,ensure_ascii=False))
    return report

def check(root:Path):
    p,hits=scan(root);unexpected=[h for h in hits if (h[0],h[1],h[2],h[6]) not in LEGACY_ALLOW];allow=[h for h in hits if (h[0],h[1],h[2],h[6]) in LEGACY_ALLOW];val=p.validate()
    return {'ok':not unexpected and len(allow)==1 and bool(val.get('ok')),
            'remaining_exact34_plus_01':len(hits),'legacy_allow_remaining':len(allow),
            'unexpected_remaining':len(unexpected),'unexpected_examples':[{'dll':h[0],'segment':h[1],'offset':f'0x{h[2]:04X}','text':h[6]} for h in unexpected[:12]],
            'scene_validation':val}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('--check',action='store_true');a=ap.parse_args()
    r=check(a.root.resolve()) if a.check else apply(a.root.resolve());print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
