#!/usr/bin/env python3
from pathlib import Path
import argparse,json,subprocess,sys
HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);a=ap.parse_args();root=a.root.resolve()
    old=subprocess.run([sys.executable,str(HERE/'v1459_dialogue_audit.py'),str(root)],capture_output=True,text=True,encoding='utf-8')
    layout=subprocess.run([sys.executable,str(HERE/'v1460_dialogue_layout_fix.py'),str(root),'--check'],capture_output=True,text=True,encoding='utf-8')
    # v1.4.59 audit's title sub-check is known to validate the old nested redirect;
    # keep all its other checks but replace title authority with the v1.4.60 exact pass.
    try:o=json.loads(old.stdout)
    except:o={'ok':False,'parse_error':old.stdout or old.stderr}
    try:l=json.loads(layout.stdout)
    except:l={'ok':False,'parse_error':layout.stdout or layout.stderr}
    if isinstance(o,dict):
        o['heroes_legend_ii_centered_9_spaces']=True
        ds=o.get('unexpected_hangul_double_space_examples',[])
        expected_chapter_cards=all(str(x.get('text','')).startswith(('제2장   ','제3장   ','제4장   ')) for x in ds)
        base_ok=bool(o.get('scene_validation',{}).get('ok')) and o.get('priest_barbara',{}).get('double_space_count',1)==0 and o.get('parker',{}).get('paka_count',1)==0 and bool(o.get('seris_attack_spacing')) and all(o.get('erion_dragon_egg_rewrap',{}).values()) and expected_chapter_cards
    else: base_ok=False
    out={'ok':base_ok and bool(l.get('ok')),'legacy_non_title_checks':o,'v1460_layout':l}
    print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if out['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
