#!/usr/bin/env python3
"""ED2 v5.0R15 v1.4.50-rebased-enhanced SCENA delta applier.

No complete game DLL is shipped.  data/scena_v5r15.ed2delta contains only
verified byte-range deltas from the exact Korean DOS stock SCENA to R15.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys,tempfile
HERE=Path(__file__).resolve().parent;DATA=HERE/'data';MAN=DATA/'manifest.json';DELTA=DATA/'scena_v5r15.ed2delta'
sys.path.insert(0,str(HERE/'internal'));from ed2_delta import read_archive,apply_bytes

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def replace(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.r15.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try:os.unlink(tmp)
        except OSError:pass
        raise

def main():
    ap=argparse.ArgumentParser(description='ED2 Text & Dialogue v5.0R15 stock-only SCENA delta')
    ap.add_argument('root',type=Path);ap.add_argument('--check',action='store_true');a=ap.parse_args()
    root=a.root.resolve();spec=json.loads(MAN.read_text(encoding='utf-8'));arc=read_archive(DELTA)
    if not (root/'ED2MAIN.EXE').is_file() or not (root/'SCENA').is_dir():raise RuntimeError('게임 폴더가 아닙니다.')
    states=[]
    for e in spec['scene_files']:
        p=root/'SCENA'/e['file'];
        if not p.is_file():raise RuntimeError('SCENA 누락: '+e['file'])
        h=sha(p);z=p.stat().st_size
        stock_ok=(h==e['stock_sha256'] and z==e['stock_size'])
        final_ok=(h==e['final_sha256'] and z==e['final_size'])
        if stock_ok and final_ok:s='both'
        elif final_ok:s='final'
        elif stock_ok:s='stock'
        else:s='other'
        states.append((e,p,s))
    if a.check:
        bad=[e['file'] for e,p,s in states if s not in ('final','both')];print(json.dumps({'ok':not bad,'managed_files':len(states),'mismatches':bad},ensure_ascii=False));return 0 if not bad else 2
    if all(s in ('final','both') for e,p,s in states) and any(s=='final' for e,p,s in states):print(json.dumps({'ok':True,'changed_files':0,'managed_files':len(states)},ensure_ascii=False));return 0
    bad=[e['file'] for e,p,s in states if s not in ('stock','both')]
    if bad:raise RuntimeError('v1.4.50-rebased-enhanced R15은 정확한 순정 SCENA 일괄 상태에서만 최초 적용합니다: '+', '.join(bad[:12]))
    originals={p:p.read_bytes() for e,p,s in states};written=[]
    try:
        for e,p,s in states:
            de=arc.get(e['file'])
            if de is None:raise RuntimeError('delta 누락: '+e['file'])
            out=apply_bytes(originals[p],de);replace(p,out);written.append(p)
    except Exception:
        for p in reversed(written):replace(p,originals[p])
        raise
    # v1.4.56 presentation pass: remove the 239 R15-only cases where an
    # exact 34-cell line is immediately followed by explicit 01h.  The engine
    # already auto-wraps at column 34, so keeping 01h produces a blank/double
    # line advance.  The one v1.4.52 baseline case in T_302 is preserved.
    import subprocess
    layout_tool=HERE/'v1456_dialogue_34cell_fix.py'
    try:
        rr=subprocess.run([sys.executable,str(layout_tool),str(root)],capture_output=True,text=True,encoding='utf-8')
        if rr.returncode:
            raise RuntimeError('v1.4.50-rebased-enhanced 34셀 레이아웃 패스 실패: '+(rr.stderr or rr.stdout))
        bad=[]
        for e,fp,_s in states:
            if sha(fp)!=e['final_sha256'] or fp.stat().st_size!=e['final_size']:bad.append(e['file'])
        if bad:raise RuntimeError('R15+v1.4.56 layout 최종 검증 실패: '+', '.join(bad[:12]))
    except Exception:
        for fp,data in originals.items():replace(fp,data)
        raise
    print(json.dumps({'ok':True,'changed_files':len(written),'managed_files':len(states),'format':'ED2R15D1','layout_34cell':json.loads(rr.stdout)},ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
