@echo off
cd /d "%~dp0"
py -3 ed2_scene_editor.py
if errorlevel 1 python ed2_scene_editor.py
