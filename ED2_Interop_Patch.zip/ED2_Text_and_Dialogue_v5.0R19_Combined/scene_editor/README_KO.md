# ED2 Scene Editor v0.5.7 — 상점 Gold 제어 보호

이 버전은 기존 v0.5.6을 기준으로, SCENA 대사 편집 과정에서 상점 구매 제어가 손상되는 회귀를 차단합니다.

## 왜 추가했나

R52 랄파 사일레스 구매 장면에서 정상 `F3 1E 09` / `F3 F9 09`가 각각 `F3 1E B0` / `F3 F9 B0`로 손상된 사례가 있었습니다. 이 경우 구매 후 메시지가 깨지고 Gold가 0이 되는 런타임 문제가 발생했습니다.

## v0.5.7 보호 규칙

- 검증된 DISP_MESS 대사 스트림 안의 `F2` / `F3`를 상점 Gold 제어로 추적합니다.
- `F2/F3`의 16비트 포인터는 현재 세그먼트 안의 4바이트 값을 완전히 가리켜야 합니다.
- 같은 구매 흐름에서 `F2 -> F3` 쌍이 보이면 두 포인터가 같아야 합니다.
- 저장 전에 모든 기존 `F2/F3`의 위치, opcode, operand, 대상 4바이트 가격값을 스냅샷합니다.
- 저장 후보에서 이 중 하나라도 달라지면 **파일을 쓰기 전에 저장을 거부**합니다.
- 따라서 포인터가 세그먼트 밖으로 깨지는 경우뿐 아니라, 우연히 다른 유효 주소로 바뀌는 경우도 차단합니다.
- 가격 데이터 4바이트 자체가 바뀌는 경우도 차단합니다.

보호기는 문자열 직접 편집, 대사/문자열 CSV 적용, 씬 변수, 씬 전환, 사용자 알고리즘 추가/수정, ALGO Export 연결/복원 등 Scene Editor의 SCENA 저장 경로에 적용됩니다.

`--validate` 결과에는 다음 항목이 추가됩니다.

- `shop_money_control_sites`
- `shop_money_control_issue_count`
- `shop_money_control_issues`

## 회귀 테스트

```bat
python test_control_guard.py
```

정상 합성 샘플, R52형 `09 -> B0` 포인터 손상, 세그먼트 안의 다른 주소로 바뀐 포인터, 4바이트 가격값 변조를 모두 검사합니다.

## 실행

기존과 동일합니다.

```bat
run_scene_editor.bat
```

또는:

```bat
python ed2_scene_editor.py "C:\ED2"
python ed2_scene_editor.py "C:\ED2" --validate
```

Python 3.10 이상을 권장합니다.
