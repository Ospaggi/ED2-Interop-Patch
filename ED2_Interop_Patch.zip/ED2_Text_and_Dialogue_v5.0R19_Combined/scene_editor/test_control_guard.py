#!/usr/bin/env python3
"""Regression tests for ED2 Scene Editor v0.5.7 shop-money guard.

Uses synthetic segment/message data only; no game files are bundled.
"""
from pathlib import Path

from ed2_formats import NESegment, FormatError
from ed2_scene_editor import (
    SceneModule,
    StringEntry,
    audit_message_control_operands,
    audit_shop_money_controls,
    assert_shop_money_controls_unchanged,
    collect_shop_money_control_sites,
)


def make_scene(f3_high: int = 0x00) -> SceneModule:
    # Minimal valid MZ/NE container with one 0x40-byte data segment at 0x100.
    # Verified message starts at segment offset 0x10:
    #   F2 1E 00   [display/check 200 Gold]
    #   ASCII text
    #   F3 1E 00   [deduct same 200 Gold]
    # 0x1E stores C8 00 00 00 = 200.
    import struct

    data = bytearray(b"\x00" * 0x140)
    data[0:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, 0x40)
    data[0x40:0x42] = b"NE"
    struct.pack_into("<H", data, 0x40 + 0x1C, 1)       # segment count
    struct.pack_into("<H", data, 0x40 + 0x22, 0x40)    # segment table rel offset
    struct.pack_into("<H", data, 0x40 + 0x32, 4)       # sector shift
    # segment table at 0x80 -> file offset 0x10 << 4 = 0x100
    struct.pack_into("<HHHH", data, 0x80, 0x10, 0x40, 0x0001, 0x40)

    base = 0x100
    data[base + 0x10:base + 0x13] = bytes((0xF2, 0x1E, 0x00))
    data[base + 0x13:base + 0x18] = b"BUY? "
    data[base + 0x18:base + 0x1B] = bytes((0xF3, 0x1E, f3_high))
    data[base + 0x1B] = 0x06
    data[base + 0x1E:base + 0x22] = (200).to_bytes(4, "little")
    segments = __import__("ed2_formats").parse_ne_segments(bytes(data))
    segment = segments[0]
    entry = StringEntry(
        segment=1,
        offset=0x18,
        file_offset=segment.file_offset + 0x18,
        capacity=3,
        text="BUY",
        raw=b"BUY",
        kind="대사",
        call_segment=1,
        call_offset=0,
        message_pointer=0x10,
    )
    return SceneModule(
        path=Path("SYNTH.DLL"), data=bytes(data), segments=segments,
        exports={}, relocations=[], assignments=[], references={},
        strings=[entry], dialogues=[entry], transitions=[],
    )


def main() -> int:
    healthy = make_scene()
    sites = collect_shop_money_control_sites(healthy)
    assert len(sites) == 2
    assert [site.opcode for site in sites] == [0xF2, 0xF3]
    assert all(site.target == 0x001E for site in sites)
    assert all(site.value_bytes == b"\xC8\x00\x00\x00" for site in sites)
    assert audit_message_control_operands(healthy) == []
    assert audit_shop_money_controls(healthy) == []
    assert_shop_money_controls_unchanged(healthy, healthy.data)

    # R52-class corruption: high byte of F3 pointer is overwritten.
    corrupted = bytearray(healthy.data)
    corrupted[0x100 + 0x1A] = 0xB0
    try:
        assert_shop_money_controls_unchanged(healthy, bytes(corrupted))
    except FormatError as exc:
        assert "상점 Gold 제어 변경" in str(exc)
    else:
        raise AssertionError("F3 pointer corruption was not blocked")

    # Even a still-in-segment pointer change is blocked because normal scene
    # editing must never rewrite a shop-money pointer.
    wrong_valid = bytearray(healthy.data)
    wrong_valid[0x100 + 0x19:0x100 + 0x1B] = (0x0022).to_bytes(2, "little")
    try:
        assert_shop_money_controls_unchanged(healthy, bytes(wrong_valid))
    except FormatError:
        pass
    else:
        raise AssertionError("valid-range F3 pointer change was not blocked")

    # Price data itself is protected too.
    price_changed = bytearray(healthy.data)
    price_changed[0x100 + 0x1E:0x100 + 0x22] = (0).to_bytes(4, "little")
    try:
        assert_shop_money_controls_unchanged(healthy, bytes(price_changed))
    except FormatError as exc:
        assert "상점 가격 데이터 변경" in str(exc)
    else:
        raise AssertionError("price data corruption was not blocked")

    print("PASS: ED2 Scene Editor v0.5.7 shop-money guard regression tests")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
