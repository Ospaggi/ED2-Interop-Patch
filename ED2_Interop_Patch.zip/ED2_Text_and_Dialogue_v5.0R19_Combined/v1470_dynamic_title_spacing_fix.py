#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, os, sys, tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'scene_editor'))
from ed2_ne_slot import patch_message_slot_0f, message_redirect_matches, parse_segments, tail_layout

VERSION='1.4.70'
DLL='T_140.DLL'; SEG=3; OFF=0x0778; EDITABLE=11
TOKEN_OFF=0x0774; TOKEN=bytes.fromhex('FF10240E')
BAD='왕자입니다.'.encode('cp949')
GOOD=' 왕자입니다.'.encode('cp949')

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def seginfo(data:bytes): return parse_segments(data)[SEG-1]
def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.v1470-title.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def state(root:Path):
    p=root/'SCENA'/DLL
    if not p.is_file(): return {'state':'missing'}
    b=p.read_bytes(); s=seginfo(b); base=s.file_offset
    token=b[base+TOKEN_OFF:base+TOKEN_OFF+4]
    good=message_redirect_matches(b,SEG,OFF,EDITABLE,GOOD,b'')
    raw=b[base+OFF:base+OFF+EDITABLE]
    bad=(raw==BAD)
    st='fixed' if token==TOKEN and good else ('pending' if token==TOKEN and bad else 'unexpected')
    return {'state':st,'sha256':sha(b),'token':token.hex(),'slot_hex':raw.hex(),
            'good_redirect':good,'seg3_length':s.length,'tail_padding':tail_layout(b,SEG).available_padding}

def apply(root:Path,check:bool=False):
    root=root.resolve(); before=state(root)
    if check:
        out={'ok':before['state']=='fixed','version':VERSION,'dynamic_title_spacing':before}
        print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['ok'] else 2
    if before['state']=='fixed':
        print(json.dumps({'ok':True,'version':VERSION,'changed':False,'dynamic_title_spacing':before},ensure_ascii=False,indent=2)); return 0
    if before['state']!='pending':
        raise RuntimeError('T_140 동적 왕자 호칭 입력 상태가 예상과 다릅니다: '+json.dumps(before,ensure_ascii=False))
    p=root/'SCENA'/DLL; b=p.read_bytes(); old_len=len(b); old_segs=[(x.file_offset,x.length,x.flags,x.min_alloc) for x in parse_segments(b)]
    r=patch_message_slot_0f(b,SEG,OFF,EDITABLE,GOOD,b'')
    outb=r.data
    if len(outb)!=old_len: raise RuntimeError('T_140 파일 크기가 변경되었습니다.')
    new_segs=[(x.file_offset,x.length,x.flags,x.min_alloc) for x in parse_segments(outb)]
    # Only seg3 logical length/minalloc may grow into existing alignment padding; all later file offsets stay fixed.
    if len(old_segs)!=len(new_segs) or any(old_segs[i][0]!=new_segs[i][0] for i in range(len(old_segs))):
        raise RuntimeError('T_140 NE segment file offsets changed')
    if not message_redirect_matches(outb,SEG,OFF,EDITABLE,GOOD,b''):
        raise RuntimeError('T_140 동적 왕자 호칭 redirect 사후 검증 실패')
    atomic(p,outb); after=state(root)
    if after['state']!='fixed': raise RuntimeError('T_140 동적 왕자 호칭 postcondition 실패')
    report={'ok':True,'version':VERSION,'changed':True,'redirected':r.redirected,'redirect_pointer':r.pointer,
            'padding_consumed':r.consumed_padding,'before':before,'after':after}
    print(json.dumps(report,ensure_ascii=False,indent=2)); return 0

def main():
    ap=argparse.ArgumentParser(description='ED2 v1.4.70 dynamic protagonist-title spacing repair')
    ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    try:return apply(a.root,a.check)
    except Exception as e: print('ERROR:',e,file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
