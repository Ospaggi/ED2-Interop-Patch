@echo off
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 ed2_ending_launcher.py
) else (
  python ed2_ending_launcher.py
)
pause
