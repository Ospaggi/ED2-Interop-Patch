#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path, PurePosixPath

APP_NAME='ED2 All-In-One Patcher'
VERSION='1.4.73'
HERE=Path(__file__).resolve().parent
PACK=HERE.parent
TARGET=json.loads((HERE/'target_manifest_v1.4.73.json').read_text(encoding='utf-8'))
MAP_SPEC=json.loads((HERE/'map_transition_aio_v1473_spec.json').read_text(encoding='utf-8'))
R20_SPEC=json.loads((PACK/'ED2_Text_and_Dialogue_v5.0R19_Combined'/'internal'/'v1.4.73_R20_FINAL'/'r20_final_spec.json').read_text(encoding='utf-8'))
MON_SPEC=json.loads((PACK/'ED2_Monster_Text_Tool_v0.2.14'/'internal'/'v16_TEST2'/'monster_text_v16_test2_spec.json').read_text(encoding='utf-8'))
REPORT_NAME='ED2_ALL_IN_ONE_REPORT.json'
PATCHED_EXPORT_BASENAME='ED2_PATCHED_FILES'

class PatchError(RuntimeError): pass

def _load_legacy():
    spec=importlib.util.spec_from_file_location('ed2_v1472_engine', HERE/'legacy_v1472_engine.py')
    if spec is None or spec.loader is None: raise PatchError('v1.4.72 내부 엔진을 불러오지 못했습니다.')
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
LEGACY=_load_legacy()

def sha(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
    return h.hexdigest()

def valid_root(root:Path)->Path:
    return LEGACY.validate_game_root(root)

def gp(root:Path,rel:str)->Path:
    pp=PurePosixPath(rel)
    if not pp.parts or any(x in ('','.','..') for x in pp.parts): raise PatchError(f'잘못된 경로: {rel}')
    if pp.parts[0].upper()=='SAVE' or pp.name.upper()=='ED2.SWP': raise PatchError(f'금지된 대상: {rel}')
    p=root.joinpath(*pp.parts).resolve();p.relative_to(root.resolve());return p

def exact_target(root:Path):
    bad=[]
    for rel,exp in TARGET['files'].items():
        if rel.upper()=='ED2.CNF': continue
        p=gp(root,rel)
        if not p.is_file() or p.stat().st_size!=int(exp['size']) or sha(p)!=exp['sha256']:
            if len(bad)<12: bad.append(rel)
    return not bad,bad

def _snapshot(root:Path, rels:set[str]):
    td=Path(tempfile.mkdtemp(prefix='.ed2_v1473_outer_',dir=str(root.parent)))
    manifest={}
    for rel in sorted(rels):
        p=gp(root,rel)
        if p.is_file():
            manifest[rel]=True;dst=td/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
        else: manifest[rel]=False
    return td,manifest

def _restore_snapshot(root:Path,td:Path,manifest:dict[str,bool]):
    for rel,existed in manifest.items():
        p=gp(root,rel)
        if existed:
            p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(td/rel,p)
        elif p.exists(): p.unlink()
    shutil.rmtree(td,ignore_errors=True)

def _all_owned_paths():
    rels=set(TARGET['files'])
    rels.update(R20_SPEC['files'])
    for e in MON_SPEC['files'].values(): rels.add(e['relative_path'])
    rels.update({'ED2MAIN.EXE','ED2END.EXE','ENDING.BAT'})
    return rels

def is_distributable_game_file(rel: str) -> bool:
    pp=PurePosixPath(rel)
    if not pp.parts or pp.parts[0].upper()=='SAVE': return False
    name=pp.name
    upper=name.upper()
    suffix=Path(name).suffix.upper()
    # ED2.CNF is machine-local configuration (DataDir / Port / IRQ / DMA).
    # Never copy another user's whole configuration through a distributable overlay.
    # Direct AIO patching may still update MixingRate in-place on that user's own CNF.
    if rel==REPORT_NAME or upper in {'ED2.SWP','ED2.CNF'}: return False
    if suffix in {'.SWP','.TMP','.LOG','.JSON','.SHA256','.PYC'}: return False
    if '__PYCACHE__' in {x.upper() for x in pp.parts}: return False
    return True

def next_patched_export_path(root: Path) -> Path:
    base=root.parent/f'{PATCHED_EXPORT_BASENAME}_v{VERSION}'
    candidate=base; n=2
    while candidate.exists():
        candidate=root.parent/f'{PATCHED_EXPORT_BASENAME}_v{VERSION}_{n}'
        n+=1
    return candidate

def prepare_patched_export(root: Path, rels: list[str]) -> tuple[Path,Path]:
    final=next_patched_export_path(root)
    temp=Path(tempfile.mkdtemp(prefix=f'.{PATCHED_EXPORT_BASENAME}_',dir=str(root.parent)))
    try:
        for rel in rels:
            src=gp(root,rel)
            if not src.is_file(): raise PatchError(f'배포용으로 복사할 변경 파일이 없습니다: {rel}')
            dst=temp.joinpath(*PurePosixPath(rel).parts);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        return final,temp
    except Exception:
        shutil.rmtree(temp,ignore_errors=True)
        raise

def current_stock_delta_paths(root: Path) -> list[str]:
    """Return a standalone overlay for the *current* game state versus exact stock.

    This is intentionally not the current transaction's changed-file list.  A v1.4.72 ->
    v1.4.73 update may write only the release delta, but a distributable folder must also
    contain the already-installed v1.4.72 bytes so it can be copied onto a clean stock game.
    Only known official game paths are considered; machine-local ED2.CNF and transient files
    are filtered by is_distributable_game_file().
    """
    stock=LEGACY._manifest_rows(LEGACY.STOCK_BASELINE_MANIFEST)
    known=set(stock) | set(TARGET['files'])
    rels=[]
    for rel in sorted(known):
        if not is_distributable_game_file(rel):
            continue
        p=gp(root,rel)
        old=stock.get(rel)
        if old is None:
            # Official new files (ED2END, P30/P31, restored M_504, etc.).
            if p.is_file():
                rels.append(rel)
            continue
        if not p.is_file():
            raise PatchError(f'배포용 상태 검사 실패: 순정 기준 파일이 없습니다: {rel}')
        if p.stat().st_size!=int(old['size']) or sha(p)!=str(old['sha256']):
            rels.append(rel)
    return rels

def _stage_changed_export(root: Path, changed_rels: list[str], create_export: bool):
    # changed_rels is kept for reporting the transaction itself.  Distribution output is
    # always the complete current-state overlay versus stock so it is safe to copy onto stock.
    rels=current_stock_delta_paths(root)
    if not create_export: return rels,None,None
    final,temp=prepare_patched_export(root,rels)
    return rels,final,temp

def official_distributable_paths() -> list[str]:
    # target_manifest_v1.4.73 contains the complete official stock -> v1.4.73 changed-file set.
    return sorted(rel for rel in TARGET['files'] if is_distributable_game_file(rel))

def rebuild_patched_export(root: Path, progress=print):
    root=valid_root(root)
    rels=official_distributable_paths();bad=[]
    for rel in rels:
        exp=TARGET['files'][rel];q=gp(root,rel)
        if not q.is_file(): bad.append(f'{rel}: missing');continue
        if q.stat().st_size!=int(exp['size']): bad.append(f'{rel}: size mismatch');continue
        if sha(q)!=str(exp['sha256']): bad.append(f'{rel}: patched bytes mismatch')
    if bad:
        raise PatchError('현재 게임이 공식 전체 패치 상태와 일치하지 않아 배포 파일을 다시 만들 수 없습니다.\n'+'\n'.join(bad[:20]))
    rels=current_stock_delta_paths(root)
    progress(f'공식 패치 변경 파일 {len(rels)}개를 배포용 폴더로 다시 만듭니다.')
    final,temp=prepare_patched_export(root,rels)
    try: os.replace(temp,final)
    except Exception:
        shutil.rmtree(temp,ignore_errors=True);raise
    progress(f'배포용 파일을 만들었습니다: {final}')
    return {'tool':f'{APP_NAME} v{VERSION}','patched_files_output':str(final),'patched_files_count':len(rels),'ok':True}

def apply_hunk_spec(root:Path, spec:dict, label:str):
    planned=[];states=[]
    for rel,fs in spec['files'].items():
        p=gp(root,rel)
        if not p.is_file() or p.stat().st_size!=int(fs['size']): raise PatchError(f'{label}: {rel} 크기/파일 상태가 예상과 다릅니다. writes=0')
        raw=p.read_bytes(); modes=[]
        for h in fs['hunks']:
            off=int(h['offset']);old=bytes.fromhex(h['old']);new=bytes.fromhex(h['new']);cur=raw[off:off+len(old)]
            if cur==old:modes.append('old')
            elif cur==new:modes.append('new')
            else: raise PatchError(f'{label}: {rel} hunk precondition 실패 @0x{off:X}. writes=0')
        mode='new' if modes and all(x=='new' for x in modes) else 'old' if modes and all(x=='old' for x in modes) else 'mixed'
        if mode=='mixed':raise PatchError(f'{label}: {rel} old/new가 섞여 있습니다. writes=0')
        states.append(mode)
        if mode=='old':
            out=bytearray(raw)
            for h in fs['hunks']:
                off=int(h['offset']);old=bytes.fromhex(h['old']);new=bytes.fromhex(h['new'])
                if bytes(out[off:off+len(old)])!=old:raise PatchError(f'{label}: 내부 preflight 실패')
                out[off:off+len(old)]=new
            planned.append((p,bytes(out)))
    if 'old' in states and 'new' in states: raise PatchError(f'{label}: 구성요소가 부분 적용된 mixed 상태입니다. writes=0')
    for p,b in planned:
        tmp=p.with_name(p.name+'.v1473tmp');tmp.write_bytes(b);os.replace(tmp,p)
    return len(planned)

def verify_hunk_spec(root:Path,spec:dict,label:str):
    for rel,fs in spec['files'].items():
        raw=gp(root,rel).read_bytes()
        for h in fs['hunks']:
            off=int(h['offset']);new=bytes.fromhex(h['new'])
            if raw[off:off+len(new)]!=new:raise PatchError(f'{label} 검증 실패: {rel} @0x{off:X}')

def apply_map(root:Path):
    p=root/'ED2MAIN.EXE'
    if not p.is_file() or p.stat().st_size!=MAP_SPEC['size']:raise PatchError('Map Transition: ED2MAIN 크기 불일치')
    raw=p.read_bytes();modes=[]
    for h in MAP_SPEC['hunks']:
        off=h['offset'];old=bytes.fromhex(h['old']);new=bytes.fromhex(h['new']);cur=raw[off:off+len(old)]
        if cur==old:modes.append('old')
        elif cur==new:modes.append('new')
        else:raise PatchError(f'Map Transition precondition 실패 @0x{off:X}. writes=0')
    if all(x=='new' for x in modes):return 0
    if not all(x=='old' for x in modes):raise PatchError('Map Transition mixed 상태. writes=0')
    out=bytearray(raw)
    for h in MAP_SPEC['hunks']:
        off=h['offset'];old=bytes.fromhex(h['old']);new=bytes.fromhex(h['new']);out[off:off+len(old)]=new
    tmp=p.with_name(p.name+'.v1473maptmp');tmp.write_bytes(out);os.replace(tmp,p);return 1

def verify_map(root:Path):
    raw=(root/'ED2MAIN.EXE').read_bytes()
    for h in MAP_SPEC['hunks']:
        off=h['offset'];new=bytes.fromhex(h['new'])
        if raw[off:off+len(new)]!=new:raise PatchError(f'Map Transition 검증 실패 @0x{off:X}')

def verify_direct_ending_relation(root:Path):
    a=(root/'ED2MAIN.EXE').read_bytes();b=(root/'ED2END.EXE').read_bytes()
    if len(a)!=len(b):raise PatchError('Direct Ending 검증 실패: ED2MAIN/ED2END 크기 불일치')
    diff=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
    expected=[0x1612A2,0x1612A4,0x1612A5]
    if diff!=expected or b[0x1612A2]!=0x05 or b[0x1612A4:0x1612A6]!=bytes.fromhex('2801'):
        raise PatchError('Direct Ending 검증 실패: 최종 relocation 3-byte 관계 불일치')

def run_monster(root:Path):
    tool=PACK/'ED2_Monster_Text_Tool_v0.2.14'/'internal'/'v16_TEST2'/'ed2_monster_text_review_v16_test2.py'
    out=LEGACY.run_command([sys.executable,str(tool),str(root)])
    # Component report is diagnostic metadata, not a game file; keep the game root clean.
    (root/'MONSTER_TEXT_V16_TEST2_LAST_REPORT.json').unlink(missing_ok=True)
    return out

def verify_monster(root:Path):
    tool=PACK/'ED2_Monster_Text_Tool_v0.2.14'/'internal'/'v16_TEST2'/'ed2_monster_text_review_v16_test2.py'
    out=LEGACY.run_command([sys.executable,str(tool),str(root),'--verify'])
    (root/'MONSTER_TEXT_V16_TEST2_LAST_REPORT.json').unlink(missing_ok=True)
    return out


# v1.4.73 keeps the v1.4.72 selectable component model.
# R20 FINAL and Monster Text v16 TEST2 are integrated into their existing
# legacy checkboxes; only Map Transition QoL remains a separate component.
EXTRA_COMPONENTS = (
    ("map_transition", "맵 전환 속도·카메라 데드존 개선", True),
)
EXTRA_KEYS = {x[0] for x in EXTRA_COMPONENTS}
LEGACY_NONMUSIC = tuple(c for c in LEGACY.COMPONENTS if c.key not in {"vgm_bgm", "original_bgm"})
LEGACY_KEYS = {c.key for c in LEGACY.COMPONENTS}
DEFAULT_LEGACY_NONMUSIC = {c.key for c in LEGACY_NONMUSIC if c.default}
DEFAULT_EXTRA = {k for k,_label,default in EXTRA_COMPONENTS if default}
DEPENDENCIES = {}

R20_SCENA_SPEC = {**R20_SPEC, "files": {k:v for k,v in R20_SPEC["files"].items() if k.startswith("SCENA/")}}
R20_TEXT_SPEC = {**R20_SPEC, "files": {k:v for k,v in R20_SPEC["files"].items() if k == "ED2MAIN.EXE"}}

def _default_selected_nonmusic() -> set[str]:
    return set(DEFAULT_LEGACY_NONMUSIC) | set(DEFAULT_EXTRA)


def _full_selected(music_mode: str = "vgm") -> set[str]:
    s = _default_selected_nonmusic()
    s.add("original_bgm" if music_mode == "original" else "vgm_bgm")
    return s


def _normalize_selected(selected_keys: list[str] | set[str], music_mode: str | None = None) -> tuple[list[str], str]:
    selected = set(selected_keys)
    unknown = selected - (LEGACY_KEYS | EXTRA_KEYS)
    if unknown:
        raise PatchError("알 수 없는 구성 요소: " + ", ".join(sorted(unknown)))
    if "vgm_bgm" in selected and "original_bgm" in selected:
        raise PatchError("교체 VGM BGM과 원본 BGM은 동시에 선택할 수 없습니다.")
    if music_mode is None:
        music_mode = "original" if "original_bgm" in selected else "vgm" if "vgm_bgm" in selected else "unchanged"
    else:
        selected.discard("vgm_bgm"); selected.discard("original_bgm")
        if music_mode == "original": selected.add("original_bgm")
        elif music_mode == "vgm": selected.add("vgm_bgm")
        elif music_mode != "unchanged": raise PatchError(f"알 수 없는 BGM 모드: {music_mode}")
    for key,deps in DEPENDENCIES.items():
        if key in selected:
            missing = deps - selected
            if missing:
                raise PatchError(f"{key} 선택에는 다음 선행 구성 요소가 필요합니다: " + ", ".join(sorted(missing)))
    if not selected:
        raise PatchError("적용할 패치를 하나 이상 선택해야 합니다.")
    # Canonical/user-visible flow: keep the v1.4.72 component order and insert
    # Map Transition immediately after the existing Additional QoL component.
    ordered = []
    for c in LEGACY.COMPONENTS:
        if c.key in selected:
            ordered.append(c.key)
        if c.key == "additional_qol" and "map_transition" in selected:
            ordered.append("map_transition")
    return ordered, music_mode


def _r20_spec_for(selected: set[str]) -> dict:
    # R20 owns ED2END only when the Direct Ending component itself is selected.
    # This keeps partial installs from creating or mutating ED2END unexpectedly.
    if "direct_ending" in selected:
        return R20_SPEC
    return {**R20_SPEC, "files": {k:v for k,v in R20_SPEC["files"].items() if k != "ED2END.EXE"}}


def _state_manifest_matches(root: Path, report: dict, selected: list[str], music_mode: str) -> bool:
    if report.get("release") != VERSION or report.get("selected_components") != selected or report.get("music_mode") != music_mode:
        return False
    rows = report.get("state_manifest")
    if not isinstance(rows, dict) or not rows:
        return False
    for rel, expected in rows.items():
        try: p = gp(root, rel)
        except Exception: return False
        if not p.is_file() or sha(p) != expected:
            return False
    return True


def _load_report(root: Path) -> dict | None:
    p = root / REPORT_NAME
    if not p.is_file(): return None
    try:
        v = json.loads(p.read_text(encoding="utf-8"))
        return v if isinstance(v, dict) else None
    except Exception:
        return None


def _verify_release_extras(root: Path, selected: set[str]) -> None:
    if "dialogue" in selected:
        verify_hunk_spec(root, R20_SCENA_SPEC, "전체 대사 교정")
    if "text" in selected:
        verify_hunk_spec(root, R20_TEXT_SPEC, "UI·텍스트·전투 표시 수정")
    if "monster_text" in selected:
        verify_monster(root)
    if "map_transition" in selected:
        verify_map(root)
    if "direct_ending" in selected:
        verify_direct_ending_relation(root)

def apply_selected(root: Path, selected_keys: list[str] | set[str], music_mode: str = "vgm",
                   create_backup: bool = True, progress=print, create_export: bool = True):
    root = valid_root(root)
    selected, music_mode = _normalize_selected(selected_keys, music_mode)
    selected_set = set(selected)

    # Full official target is manifest-verifiable without replaying any component.
    if selected_set == _full_selected("vgm"):
        ok,_bad = exact_target(root)
        if ok:
            progress("이미 v1.4.73 전체 선택 최신 상태입니다. 변경 없이 완료합니다.")
            return {"status":"already-current", "release":VERSION, "selected_components":selected,
                    "music_mode":music_mode, "changed_files":0, "writes":0,
                    "patched_files_count":0,"patched_files_output":None,"patched_files_exported":False}

    # Partial-install idempotence: verify the exact files changed by the previous
    # identical selection.  This avoids asking the v1.4.72 detector to understand
    # R20/Map bytes it did not know about.
    previous = _load_report(root)
    if previous and _state_manifest_matches(root, previous, selected, music_mode):
        _verify_release_extras(root, selected_set)
        progress("같은 구성 요소 조합이 이미 정상 적용되어 있습니다. writes=0")
        return {"status":"already-current-partial", "release":VERSION,
                "selected_components":selected, "music_mode":music_mode,
                "changed_files":0, "writes":0,
                "patched_files_count":0,"patched_files_output":None,"patched_files_exported":False}

    # v1.4.73 music-source switch fast path.  Once a v1.4.73 selection is known
    # good, changing only the BGM source must not be routed back through the
    # v1.4.72 generation detector, because R20/Map bytes are intentionally newer.
    # Preserve all installed non-music components and switch only the carrier
    # layer; Direct Ending is regenerated because ED2MAIN is a music owner too.
    prev_selected = set(previous.get("selected_components", [])) if isinstance(previous, dict) else set()
    prev_mode = previous.get("music_mode") if isinstance(previous, dict) else None
    exact_now, _exact_bad = exact_target(root)
    previous_known = bool(
        previous and prev_mode in {"vgm", "original"}
        and _state_manifest_matches(root, previous, list(previous.get("selected_components", [])), str(prev_mode))
    )
    requested_nonmusic = selected_set - {"vgm_bgm", "original_bgm"}
    installed_nonmusic = (
        (_full_selected("vgm") - {"vgm_bgm", "original_bgm"}) if exact_now
        else (prev_selected - {"vgm_bgm", "original_bgm"}) if previous_known
        else set()
    )
    current_mode = "vgm" if exact_now else (str(prev_mode) if previous_known else None)
    if (music_mode in {"vgm", "original"} and current_mode in {"vgm", "original"}
            and music_mode != current_mode and requested_nonmusic <= installed_nonmusic):
        tx, manifest = _snapshot(root, _all_owned_paths())
        before_hash = {rel:(sha(gp(root,rel)) if gp(root,rel).is_file() else None) for rel in manifest}
        try:
            progress('BGM을 변경합니다.')
            if music_mode == "original":
                LEGACY.apply_original_bgm(root); LEGACY.verify_original_bgm(root)
            else:
                LEGACY.apply_vgm_bgm(root); LEGACY.verify_vgm_bgm(root)
            ending_installed = "direct_ending" in installed_nonmusic or "direct_ending" in requested_nonmusic
            if ending_installed:
                LEGACY.apply_direct_ending(root); verify_direct_ending_relation(root)
            _verify_release_extras(root, requested_nonmusic)
            after_hash = {rel:(sha(gp(root,rel)) if gp(root,rel).is_file() else None) for rel in manifest}
            changed_rels = [rel for rel in before_hash if before_hash[rel] != after_hash[rel]]
            state_manifest = {rel:after_hash[rel] for rel in changed_rels if after_hash[rel] is not None}
            distributable,export_path,export_temp=_stage_changed_export(root,changed_rels,create_export)
            report = {
                "tool": f"{APP_NAME} v{VERSION}", "release": VERSION, "status": "ok",
                "selected_components": selected, "music_mode": music_mode,
                "changed_files": len(changed_rels), "writes": len(changed_rels),
                "state_manifest": state_manifest, "mode_switch_only": True,
                "patched_files_count":len(distributable),
                "patched_files_output":str(export_path) if export_path else None,
                "patched_files_exported":bool(create_export),
                "no_bundled_patched_game_files": True, "save_untouched": True, "ed2_swp_ignored": True,
            }
            (root/REPORT_NAME).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
            if export_temp is not None and export_path is not None: os.replace(export_temp,export_path)
            shutil.rmtree(tx, ignore_errors=True)
            progress(f"BGM 소스 전환 완료: 변경 파일 {len(changed_rels)}개.")
            return report
        except Exception:
            progress("BGM 소스 전환 오류로 이번 실행 변경을 되돌립니다.")
            _restore_snapshot(root, tx, manifest)
            raise

    tx, manifest = _snapshot(root, _all_owned_paths())
    before_hash = {rel:(sha(gp(root,rel)) if gp(root,rel).is_file() else None) for rel in manifest}
    try:
        legacy_selected = [c.key for c in LEGACY.COMPONENTS if c.key in selected_set]
        if legacy_selected:
            # legacy apply_all itself preserves the v1.4.72 component order.
            LEGACY.apply_all(root, legacy_selected, progress,
                             create_export=False, create_permanent_backup=create_backup)

        # v1.4.73 final revisions are part of the existing component ownership.
        # They are still executed after the legacy pass so older component writers
        # cannot overwrite the approved final bytes.
        if "dialogue" in selected_set:
            apply_hunk_spec(root, R20_SCENA_SPEC, "전체 대사 교정")
            verify_hunk_spec(root, R20_SCENA_SPEC, "전체 대사 교정")

        if "text" in selected_set:
            apply_hunk_spec(root, R20_TEXT_SPEC, "UI·텍스트·전투 표시 수정")
            verify_hunk_spec(root, R20_TEXT_SPEC, "UI·텍스트·전투 표시 수정")

        if "monster_text" in selected_set:
            run_monster(root); verify_monster(root)

        if "map_transition" in selected_set:
            apply_map(root); verify_map(root)

        # Direct Ending is created in the legacy ordered pass. R20 text/Map may
        # then change ED2MAIN, so mirror the final ED2MAIN at the very end.
        if "direct_ending" in selected_set and ({"text", "map_transition"} & selected_set):
            LEGACY.apply_direct_ending(root)
        if "direct_ending" in selected_set:
            verify_direct_ending_relation(root)

        after_hash = {rel:(sha(gp(root,rel)) if gp(root,rel).is_file() else None) for rel in manifest}
        changed_rels = [rel for rel in before_hash if before_hash[rel] != after_hash[rel]]
        state_manifest = {rel:after_hash[rel] for rel in changed_rels if after_hash[rel] is not None}

        # The exact official target is required only for the default full VGM profile.
        if selected_set == _full_selected("vgm"):
            ok,bad = exact_target(root)
            if not ok: raise PatchError("v1.4.73 exact target 검증 실패: " + ", ".join(bad))

        distributable,export_path,export_temp=_stage_changed_export(root,changed_rels,create_export)
        report = {
            "tool": f"{APP_NAME} v{VERSION}", "release": VERSION, "status": "ok",
            "selected_components": selected, "music_mode": music_mode,
            "changed_files": len(changed_rels), "writes": len(changed_rels),
            "state_manifest": state_manifest,
            "patched_files_count":len(distributable),
            "patched_files_output":str(export_path) if export_path else None,
            "patched_files_exported":bool(create_export),
            "no_bundled_patched_game_files": True,
            "save_untouched": True, "ed2_swp_ignored": True,
        }
        (root/REPORT_NAME).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        if export_temp is not None and export_path is not None: os.replace(export_temp,export_path)
        shutil.rmtree(tx, ignore_errors=True)
        progress(f"완료: 변경 파일 {len(changed_rels)}개.")
        return report
    except Exception:
        progress("오류가 발생해 이번 실행의 게임 파일 변경을 시작 전 상태로 되돌립니다.")
        _restore_snapshot(root, tx, manifest)
        raise


def verify_selected(root: Path, selected_keys: list[str] | set[str], music_mode: str = "vgm"):
    root = valid_root(root)
    selected, music_mode = _normalize_selected(selected_keys, music_mode)
    selected_set = set(selected)
    if selected_set == _full_selected("vgm"):
        ok,bad = exact_target(root)
        if not ok: raise PatchError("v1.4.73 전체 선택 target 아님: " + ", ".join(bad))
        _verify_release_extras(root, selected_set)
        return {"ok":True, "release":VERSION, "selected_components":selected, "music_mode":music_mode, "writes":0}
    report = _load_report(root)
    if not report or not _state_manifest_matches(root, report, selected, music_mode):
        raise PatchError("현재 게임 상태가 이 선택 조합의 마지막 정상 적용 상태와 일치하지 않습니다.")
    _verify_release_extras(root, selected_set)
    return {"ok":True, "release":VERSION, "selected_components":selected, "music_mode":music_mode, "writes":0}


def restore_stock(root:Path,progress=print):
    rep=LEGACY.restore_stock_backup(root,progress);rep['tool']=f'{APP_NAME} v{VERSION}';return rep


def _component_label(key: str) -> str:
    for c in LEGACY.COMPONENTS:
        if c.key == key: return c.label
    for k,label,_d in EXTRA_COMPONENTS:
        if k == key: return label
    return key


class GUI:
    def __init__(self,initial:Path|None=None):
        import tkinter as tk
        from tkinter import filedialog,messagebox,ttk
        self.tk,self.ttk=tk,ttk;self.filedialog,self.messagebox=filedialog,messagebox
        self.root=tk.Tk();self.root.title(f'{APP_NAME} v{VERSION}')
        sw=max(640,self.root.winfo_screenwidth());sh=max(480,self.root.winfo_screenheight())
        w=min(920,max(740,sw-80));h=min(760,max(520,sh-120));self.root.geometry(f'{w}x{h}');self.root.minsize(740,520)
        self.path_var=tk.StringVar(value=str(initial or ''))
        self.vars={c.key:tk.BooleanVar(value=c.default) for c in LEGACY_NONMUSIC}
        for k,_l,d in EXTRA_COMPONENTS:self.vars[k]=tk.BooleanVar(value=d)
        self.music_mode_var=tk.StringVar(value='vgm');self.backup_var=tk.BooleanVar(value=True);self.export_var=tk.BooleanVar(value=True)
        host=ttk.Frame(self.root);host.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(host,highlightthickness=0,borderwidth=0);vs=ttk.Scrollbar(host,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vs.set);self.canvas.pack(side='left',fill='both',expand=True);vs.pack(side='right',fill='y')
        outer=ttk.Frame(self.canvas,padding=12);win=self.canvas.create_window((0,0),window=outer,anchor='nw')
        outer.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')));self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(win,width=e.width))
        row=ttk.Frame(outer);row.pack(fill='x');ttk.Entry(row,textvariable=self.path_var).pack(side='left',fill='x',expand=True);ttk.Button(row,text='게임 폴더 선택',command=self.choose).pack(side='left',padx=(8,0))

        box=ttk.LabelFrame(outer,text='적용할 구성 요소',padding=10);box.pack(fill='x',pady=12)
        display_labels = {
            'dialogue': '전체 대사 교정 및 표시 보정',
            'text': 'UI·텍스트·전투 표시 수정',
            'monster_text': '몬스터 전투·특수행동 문구 수정',
        }
        extra_by_key = {k:(label,d) for k,label,d in EXTRA_COMPONENTS}
        for c in LEGACY_NONMUSIC:
            ttk.Checkbutton(box,text=display_labels.get(c.key,c.label),variable=self.vars[c.key],command=lambda k=c.key:self.on_toggle(k)).pack(anchor='w',pady=2)
            # Map Transition is an ordinary component in the original patch flow,
            # not a detached "additional QoL" section.
            if c.key == 'additional_qol' and 'map_transition' in extra_by_key:
                label,_d = extra_by_key['map_transition']
                ttk.Checkbutton(box,text=label,variable=self.vars['map_transition'],command=lambda:self.on_toggle('map_transition')).pack(anchor='w',pady=2)
        quick=ttk.Frame(box);quick.pack(fill='x',pady=(8,0))
        ttk.Button(quick,text='전체 선택',command=self.select_all).pack(side='left')
        ttk.Button(quick,text='전체 해제',command=self.clear_all).pack(side='left',padx=(6,0))

        music=ttk.LabelFrame(outer,text='BGM 모드',padding=10);music.pack(fill='x',pady=(0,12))
        ttk.Radiobutton(music,text='교체 VGM BGM (기본)',value='vgm',variable=self.music_mode_var).pack(anchor='w',pady=2)
        ttk.Radiobutton(music,text='원본 BGM',value='original',variable=self.music_mode_var).pack(anchor='w',pady=2)

        opt=ttk.LabelFrame(outer,text='백업 / 배포 옵션',padding=10);opt.pack(fill='x',pady=(0,12))
        ttk.Checkbutton(opt,text='순정 상태에서 최초 적용 시 순정 백업 만들기',variable=self.backup_var).pack(anchor='w',pady=2)
        ttk.Checkbutton(opt,text='패치 완료 후 배포용 변경 파일 폴더 만들기',variable=self.export_var).pack(anchor='w',pady=2)
        self.log=tk.Text(outer,height=15,wrap='word',state='disabled');self.log.pack(fill='both',expand=True,pady=10)
        buttons=ttk.Frame(outer);buttons.pack(fill='x',pady=(0,4))
        ttk.Button(buttons,text='선택 패치 한번에 적용',command=self.do_apply).pack(side='left')
        ttk.Button(buttons,text='선택 상태 검증',command=self.do_verify).pack(side='left',padx=(8,0))
        ttk.Button(buttons,text='순정 복원',command=self.do_restore).pack(side='left',padx=(8,0))
        ttk.Button(buttons,text='배포 파일 다시 만들기',command=self.do_rebuild_export).pack(side='left',padx=(8,0))
        ttk.Button(buttons,text='닫기',command=self.root.destroy).pack(side='right')
        def wheel(e):
            if e.widget is self.log:return
            d=getattr(e,'delta',0);amt=-3 if d>0 else 3
            if getattr(e,'num',None)==4:amt=-3
            elif getattr(e,'num',None)==5:amt=3
            self.canvas.yview_scroll(amt,'units')
        self.root.bind_all('<MouseWheel>',wheel,add='+');self.root.bind_all('<Button-4>',wheel,add='+');self.root.bind_all('<Button-5>',wheel,add='+')

    def choose(self):
        v=self.filedialog.askdirectory(title='영웅전설 II 게임 폴더 선택')
        if v:self.path_var.set(v)
    def append(self,s):
        self.log.configure(state='normal');self.log.insert('end',str(s)+'\n');self.log.see('end');self.log.configure(state='disabled');self.root.update_idletasks()
    def select_all(self):
        for v in self.vars.values():v.set(True)
    def clear_all(self):
        for v in self.vars.values():v.set(False)
    def on_toggle(self,key):
        # Enabling a release-layer item enables its visible prerequisites.
        if self.vars[key].get() and key in DEPENDENCIES:
            for dep in DEPENDENCIES[key]: self.vars[dep].set(True)
        # Disabling a prerequisite visibly disables dependent release layers.
        if not self.vars[key].get():
            for child,deps in DEPENDENCIES.items():
                if key in deps and child in self.vars:self.vars[child].set(False)
    def selected(self):
        out=[c.key for c in LEGACY_NONMUSIC if self.vars[c.key].get()]
        out += [k for k,_l,_d in EXTRA_COMPONENTS if self.vars[k].get()]
        return out
    def do_apply(self):
        try:
            root=Path(self.path_var.get());mode=self.music_mode_var.get();sel=self.selected()
            normalized,_=_normalize_selected(sel,mode)
            labels=[_component_label(k) for k in normalized if k not in {'vgm_bgm','original_bgm'}]
            q='선택한 패치를 적용할까요?\n\n'+'\n'.join('- '+x for x in labels)+f"\n\nBGM: {'원본 BGM' if mode=='original' else '교체 VGM'}"
            if not self.messagebox.askyesno(APP_NAME,q):return
            rep=apply_selected(root,sel,mode,self.backup_var.get(),self.append,create_export=self.export_var.get())
            export_line=(f"\n배포용 파일: {rep.get('patched_files_count',0)}개\n{rep.get('patched_files_output')}" if rep.get('patched_files_exported') else '')
            self.messagebox.showinfo(APP_NAME,f"적용 완료\n변경 파일: {rep['changed_files']}개{export_line}")
        except Exception as e:self.append('오류: '+str(e));self.messagebox.showerror(APP_NAME,str(e))
    def do_verify(self):
        try:
            rep=verify_selected(Path(self.path_var.get()),self.selected(),self.music_mode_var.get());self.append(json.dumps(rep,ensure_ascii=False));self.messagebox.showinfo(APP_NAME,'선택한 패치 상태가 정상입니다.')
        except Exception as e:self.append('검증 실패: '+str(e));self.messagebox.showerror(APP_NAME,str(e))
    def do_restore(self):
        try:
            root=Path(self.path_var.get())
            if not self.messagebox.askyesno(APP_NAME,'순정 백업으로 패치 소유 게임 파일을 복원할까요?\nSAVE 데이터는 건드리지 않습니다.'):return
            rep=restore_stock(root,self.append);self.messagebox.showinfo(APP_NAME,f"순정 복원 완료\n복원 파일: {rep['restored_files']}개")
        except Exception as e:self.append('복원 실패: '+str(e));self.messagebox.showerror(APP_NAME,str(e))
    def do_rebuild_export(self):
        try:
            root=Path(self.path_var.get())
            if not self.messagebox.askyesno(APP_NAME,'현재 전체 패치 상태에서 배포용 변경 파일 폴더를 다시 만들까요?'):return
            rep=rebuild_patched_export(root,self.append)
            self.messagebox.showinfo(APP_NAME,f"배포용 파일을 다시 만들었습니다.\n파일: {rep['patched_files_count']}개\n\n{rep['patched_files_output']}")
        except Exception as e:self.append('배포 파일 생성 실패: '+str(e));self.messagebox.showerror(APP_NAME,str(e))
    def run(self):self.root.mainloop()


def main():
    ap=argparse.ArgumentParser(description=f'{APP_NAME} v{VERSION}')
    ap.add_argument('game_root',nargs='?',type=Path)
    act=ap.add_mutually_exclusive_group();act.add_argument('--apply-all',action='store_true');act.add_argument('--apply-selected',action='store_true');act.add_argument('--verify',action='store_true');act.add_argument('--restore',action='store_true');act.add_argument('--rebuild-export',action='store_true')
    ap.add_argument('--components',default='');ap.add_argument('--original-bgm',action='store_true');ap.add_argument('--no-gui',action='store_true');ap.add_argument('--no-backup',action='store_true');ap.add_argument('--no-export',action='store_true')
    a=ap.parse_args();mode='original' if a.original_bgm else 'vgm'
    try:
        if not a.no_gui and not (a.apply_all or a.apply_selected or a.verify or a.restore or a.rebuild_export):GUI(a.game_root).run();return 0
        if a.game_root is None:raise PatchError('CLI 모드에서는 게임 폴더 경로가 필요합니다.')
        if a.restore:print(json.dumps(restore_stock(a.game_root),ensure_ascii=False,indent=2));return 0
        if a.rebuild_export:print(json.dumps(rebuild_patched_export(a.game_root),ensure_ascii=False,indent=2));return 0
        if a.components:
            selected=[x.strip() for x in a.components.split(',') if x.strip()]
        else:
            selected=sorted(_default_selected_nonmusic())
        if a.verify:print(json.dumps(verify_selected(a.game_root,selected,mode),ensure_ascii=False,indent=2));return 0
        print(json.dumps(apply_selected(a.game_root,selected,mode,not a.no_backup,print,create_export=not a.no_export),ensure_ascii=False,indent=2));return 0
    except Exception as e:print('[ERROR]',e,file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
