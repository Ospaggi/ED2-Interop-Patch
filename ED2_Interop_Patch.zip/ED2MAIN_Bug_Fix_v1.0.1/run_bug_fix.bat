@echo off
setlocal
cd /d "%~dp0"
py -3 ed2main_bug_fix.py %*
if errorlevel 1 python ed2main_bug_fix.py %*
endlocal
