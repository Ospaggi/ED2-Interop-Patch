#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, struct, tempfile
from pathlib import Path

VERSION='0.2.0'
SEG=3
# v0.2.0: keep ordinary late-game enemies at the v1.4.62 12.5% scaling,
# but halve the added attack contribution for the three boss encounters that
# became too bursty relative to their already-raised ATK/DEF values.
SPECS={
 'M_400.DLL': dict(off=0x03B2, reloc=0x03B6, ordinal=304, base=400, divisor=16, label='디겐스 계열 특수기'),
 'M_402.DLL': dict(off=0x02E3, reloc=0x02E7, ordinal=40,  base=120, divisor=8,  label='슬래시 병사 특수기'),
 'M_500.DLL': dict(off=0x0288, reloc=0x028C, ordinal=304, base=300, divisor=16, label='고드윈 1차전 특수기'),
 'M_501.DLL': dict(off=0x03DA, reloc=0x03DE, ordinal=40,  base=300, divisor=16, label='고드윈 최종전 특수기'),
 'M_511.DLL': dict(off=0x0238, reloc=0x023C, ordinal=40,  base=125, divisor=8,  label='사일런트 로드 특수기'),
 'M_518.DLL': dict(off=0x0291, reloc=0x0295, ordinal=40,  base=500, divisor=8,  label='블랙 나이츠 특수기'),
}
LEGACY_DIVISOR=8

def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def ne_info(b):
    if len(b)<0x40 or b[:2]!=b'MZ': raise RuntimeError('MZ 아님')
    ne=u32(b,0x3c)
    if b[ne:ne+2]!=b'NE': raise RuntimeError('NE 아님')
    return ne, ne+u16(b,ne+0x22), u16(b,ne+0x32), u16(b,ne+0x1c)
def segment(b,index):
    ne,table,shift,count=ne_info(b)
    if not 1<=index<=count: raise RuntimeError('segment 범위')
    p=table+(index-1)*8; sec,length,flags,alloc=struct.unpack_from('<HHHH',b,p)
    return p,sec<<shift,(0x10000 if length==0 else length),flags,alloc
def next_base(b,index): return segment(b,index+1)[1]
def relocs(b,index):
    _,base,length,flags,_=segment(b,index)
    if not flags&0x100: raise RuntimeError('relocation 없음')
    roff=base+length; cnt=u16(b,roff); end=roff+2+cnt*8
    if end>next_base(b,index): raise RuntimeError('relocation overlap')
    return [struct.unpack_from('<BBHHH',b,roff+2+i*8) for i in range(cnt)]
def decode_name(raw):
    f=raw[48:64]; f=f.split(b'\x06',1)[0].split(b'\0',1)[0]
    try:return f.decode('cp949').strip()
    except:return ''
def is_mon(raw):
    return len(raw)==64 and 0x06 in raw[48:64] and u16(raw,4)>0 and u16(raw,4)==u16(raw,6) and bool(decode_name(raw))
def monster_records(b):
    best=[]
    ne,table,shift,count=ne_info(b)
    for si in range(1,count+1):
        _,base,length,_,_=segment(b,si); rows=[]
        for slot in range(4):
            pos=base+slot*64
            if pos+64>base+length: break
            raw=b[pos:pos+64]
            if not is_mon(raw): break
            rows.append({'slot':slot,'name':decode_name(raw),'attack':u16(raw,0x0A)})
        if len(rows)>len(best): best=rows
    if not best: raise RuntimeError('monster table 탐지 실패')
    return best
def damages(b,spec):
    rows=monster_records(b); attack=max(r['attack'] for r in rows)
    new=min(0xFFFF,spec['base']+(attack//spec['divisor']))
    legacy=min(0xFFFF,spec['base']+(attack//LEGACY_DIVISOR))
    return new,legacy,attack,rows
def exact_reloc_ok(b,src,ordinal):
    hits=[r for r in relocs(b,SEG) if r[2]==src]
    return len(hits)==1 and hits[0][0]==3 and hits[0][1]==1 and hits[0][3]==1 and hits[0][4]==ordinal

def inspect(path,spec):
    if not path.is_file(): return {'file':path.name,'state':'missing'}
    b=path.read_bytes(); _,base,length,_,_=segment(b,SEG)
    off=spec['off']
    if off+3>length:return {'file':path.name,'state':'unsupported','reason':'site outside seg3'}
    cur=b[base+off:base+off+3]
    if cur[:1]!=b'\xBA':return {'file':path.name,'state':'unsupported','reason':'damage opcode differs','current_hex':cur.hex()}
    if not exact_reloc_ok(b,spec['reloc'],spec['ordinal']):return {'file':path.name,'state':'unsupported','reason':'damage-call relocation differs'}
    exp,legacy,attack,rows=damages(b,spec); val=u16(cur,1)
    if val==exp:
        state='fixed'
    elif val==spec['base']:
        state='pending'
    elif spec['divisor']!=LEGACY_DIVISOR and val==legacy:
        state='legacy-v1.4.62'
    else:
        state='unexpected'
    return {
        'file':path.name,'state':state,'site':f"seg3:0x{off:04X}",'base_damage':spec['base'],
        'attack_reference':attack,'divisor':spec['divisor'],'scaled_damage':exp,
        'legacy_v1_4_62_damage':legacy,'current_damage':val,
        'formula':f"base + max_monster_attack // {spec['divisor']}",'monsters':rows,
        'damage_call_ordinal':spec['ordinal'],'label':spec['label']
    }
def atomic(path,data):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.skill.tmp',dir=str(path.parent)); os.close(fd)
    try: Path(tmp).write_bytes(data); os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def main():
    ap=argparse.ArgumentParser(description='ED2 late-game fixed-damage skill scaling')
    ap.add_argument('root',type=Path); ap.add_argument('--apply',action='store_true'); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    root=a.root.resolve(); rows=[inspect(root/'MON'/fn,spec) for fn,spec in SPECS.items()]
    bad=[r for r in rows if r['state'] in ('missing','unsupported','unexpected')]
    if bad:
        print(json.dumps({'ok':False,'version':VERSION,'skills':rows},ensure_ascii=False,indent=2)); return 2
    if a.check or not a.apply:
        pending=[r for r in rows if r['state']!='fixed']; ok=not pending
        print(json.dumps({'ok':ok,'version':VERSION,'pending':len(pending),'boss_policy':'M_400/M_500/M_501: base + attack/16; others: base + attack/8','skills':rows},ensure_ascii=False,indent=2)); return 0 if ok else 2
    changed=[]
    for fn,spec in SPECS.items():
        path=root/'MON'/fn; r=inspect(path,spec)
        if r['state']=='fixed': continue
        if r['state'] not in ('pending','legacy-v1.4.62'): raise RuntimeError(f'{fn}: unsupported state')
        b=bytearray(path.read_bytes()); _,base,_,_,_=segment(b,SEG)
        struct.pack_into('<H',b,base+spec['off']+1,r['scaled_damage']); atomic(path,bytes(b)); changed.append(fn)
    after=[inspect(root/'MON'/fn,spec) for fn,spec in SPECS.items()]; ok=all(r['state']=='fixed' for r in after)
    print(json.dumps({'ok':ok,'version':VERSION,'changed_files':changed,'boss_policy':'보스 3종은 공격력 6.25% 가산, 일반 후반 적은 12.5% 가산 유지','skills':after},ensure_ascii=False,indent=2)); return 0 if ok else 2
if __name__=='__main__': raise SystemExit(main())
