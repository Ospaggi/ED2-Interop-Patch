@echo off
cd /d "%~dp0"
py -3 ed2_additional_qol.py
if errorlevel 1 python ed2_additional_qol.py
