#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
import struct
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = "0.1.0"
HARDSTOP = bytes.fromhex("B4 01 CD 40 90")


def load(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"module load failed: {filename}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


core = load("ed2_music_mode_core", "patch_vgm_bgm.py")
ctl = load("ed2_music_mode_ctl", "patch_ed2main_bgm_control.py")
fade = load("ed2_music_mode_fade", "patch_fadeout_bgm.py")
cannon = load("ed2_music_mode_cannon", "patch_c600_cannon_bgm.py")
battle = load("ed2_music_mode_battle", "patch_battle_end_bgm.py")
throne = load("ed2_music_mode_throne", "patch_throne_room_bgm.py")
exitbgm = load("ed2_music_mode_exit", "patch_exit_bgm.py")
allstop = load("ed2_music_mode_allstop", "patch_all_bgm_hardstop.py")
tracks = load("ed2_music_mode_tracks", "patch_custom_tracks.py")
waitsync = load("ed2_music_mode_waitsync", "patch_wait_bgm_sync.py")
combined = load("ed2_music_mode_combined", "patch_combined.py")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".musicmode.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _stock_asset_root(stock_files_root: str | Path | None) -> Path | None:
    if stock_files_root in (None, "", "auto"):
        return None
    p = Path(stock_files_root).expanduser().resolve()
    if not p.is_dir():
        raise FileNotFoundError(f"순정 백업 GAME_FILES 폴더를 찾지 못했습니다: {p}")
    return p


def _verify_stock_asset_source(files_root: Path) -> None:
    bad: list[str] = []
    for rel, expected in core.ORIGINAL_SHA.items():
        p = files_root / rel
        if not p.is_file():
            bad.append(f"{rel}: missing")
            continue
        got = sha_file(p)
        if got != expected:
            bad.append(f"{rel}: {got[:12]} != {expected[:12]}")
    if bad:
        raise RuntimeError("순정 BGM 백업 검증 실패:\n" + "\n".join(bad[:20]))


def _restore_stock_music_assets(root: Path, stock_files_root: Path | None) -> int:
    paths = core.game_paths(root)
    if core.baseline_all(paths):
        return 0
    if stock_files_root is None:
        raise RuntimeError(
            "현재 게임의 GKEY/BGM은 교체 음악 상태입니다.\n"
            "원본 음악으로 되돌리려면 최초 패치 전에 만든 *_STOCK_BACKUP/GAME_FILES가 필요합니다."
        )
    _verify_stock_asset_source(stock_files_root)
    changed = 0
    for rel, expected in core.ORIGINAL_SHA.items():
        src = stock_files_root / rel
        dst = root / rel
        data = src.read_bytes()
        if sha_bytes(data) != expected:
            raise RuntimeError(f"순정 백업 SHA 검증 실패: {rel}")
        if not dst.is_file() or sha_file(dst) != expected:
            atomic(dst, data)
            changed += 1
    if not core.baseline_all(core.game_paths(root)):
        raise RuntimeError("순정 GKEY/BGM 복원 후 검증에 실패했습니다.")
    return changed


def _normalize_cannon_mapping(root: Path) -> int:
    r, bgm, ed, c600, p21m, p21i, p30m, p30i = cannon.paths(root)
    changed = 0

    cb = c600.read_bytes()
    s3, _ = cannon.segment_info(cb, cannon.C600_SEG3)
    play = cannon.code_bytes_at(cb, cannon.C600_SEG3, cannon.PLAY_MOV_OFF, 2)
    expected_stock = bytes((0xB0, cannon.PLAY_ORIGINAL_LOGICAL))
    expected_custom = bytes((0xB0, cannon.PLAY_CUSTOM_LOGICAL))
    if play == expected_custom:
        x = bytearray(cb)
        x[s3["base"] + cannon.PLAY_IMM_OFF] = cannon.PLAY_ORIGINAL_LOGICAL
        atomic(c600, bytes(x))
        changed += 1
    elif play != expected_stock:
        # Legacy layouts are normalized by the component's own guarded restore.
        cannon.restore(root)
        changed += 1

    eb = ed.read_bytes()
    x = bytearray(eb)
    dirty = False
    l29 = cannon.map_value(eb, cannon.CUSTOM_LOGICAL)
    if l29 == cannon.CUSTOM_PHYSICAL:
        struct.pack_into("<H", x, cannon.map_file_offset(eb, cannon.CUSTOM_LOGICAL), cannon.ORIGINAL_L29_PHYSICAL)
        dirty = True
    elif l29 != cannon.ORIGINAL_L29_PHYSICAL:
        raise RuntimeError(f"ED2MAIN L29 mapping 지원 불가: P{l29}")

    l25 = cannon.map_value(eb, cannon.OLD_517_LOGICAL)
    if l25 == cannon.OLD_517_CUSTOM:
        struct.pack_into("<H", x, cannon.map_file_offset(eb, cannon.OLD_517_LOGICAL), cannon.OLD_517_ORIGINAL)
        dirty = True
    elif l25 != cannon.OLD_517_ORIGINAL:
        raise RuntimeError(f"ED2MAIN L25 mapping 지원 불가: P{l25}")

    bad = cannon.bad518_word_value(eb)
    if bad == cannon.BAD_518_WORD_PATCHED:
        struct.pack_into("<H", x, cannon.bad518_word_offset(eb), cannon.BAD_518_WORD_ORIGINAL)
        dirty = True
    elif bad != cannon.BAD_518_WORD_ORIGINAL:
        raise RuntimeError(f"ED2MAIN v0.5.18 word 지원 불가: {bad}")
    if dirty:
        atomic(ed, bytes(x))
        changed += 1
    return changed


def _normalize_throne_mapping(root: Path) -> int:
    p = throne.paths(root)
    eb = p["ed2"].read_bytes()
    l15 = throne.map_value(eb, throne.THRONE_LOGICAL)
    l16 = throne.map_value(eb, throne.BATTLE_LOGICAL)
    if l16 != throne.BATTLE_PHYSICAL:
        raise RuntimeError(f"최종전 L16 mapping 지원 불가: P{l16}")
    if l15 == throne.THRONE_STOCK_PHYSICAL:
        return 0
    if l15 != throne.THRONE_CUSTOM_PHYSICAL:
        raise RuntimeError(f"옥좌의 방 L15 mapping 지원 불가: P{l15}")
    x = bytearray(eb)
    struct.pack_into("<H", x, throne.map_file_offset(eb, throne.THRONE_LOGICAL), throne.THRONE_STOCK_PHYSICAL)
    atomic(p["ed2"], bytes(x))
    return 1


def _remove_unused_official_custom_slots(root: Path) -> list[str]:
    """Remove only exact bundled P30/P31 custom files; preserve arbitrary user files."""
    removed: list[str] = []
    bgm = root / "BGM"
    for slot in (30, 31):
        mus = bgm / f"DS2_{slot:02d}.MUS"
        expected = tracks.EXPECTED_SHA.get(slot)
        if mus.is_file() and expected and sha_file(mus) == expected:
            mus.unlink()
            removed.append(mus.name)
    # The official pack creates P30/P31 INS as stock-equivalent placeholders.
    # Delete them only when they match the exact official-current files.  If a
    # user edited either file, leave it untouched; stock mapping never selects it.
    known_ins = {
        30: "6b9701d1e5120e5428f8c70797604085fb432d7c2e604211c1faef1241067578",
        31: "6af98acdb1c6c9fd0eeb4243ac6957a5ffc31ae416d62047df7ff6dbbdca3054",
    }
    for slot, expected in known_ins.items():
        ins = bgm / f"DS2_{slot:02d}.INS"
        if ins.is_file() and sha_file(ins) == expected:
            ins.unlink()
            removed.append(ins.name)
    return removed


def _core_carrier_bytes() -> dict[int, bytes]:
    return {i: core.compile_target(i)[0] for i in core.TARGETS}


def _core_vgz_state(root: Path) -> tuple[bool, list[str]]:
    """Return whether GKEY + all managed tracks are the core original-VGZ carriers."""
    p = core.game_paths(root)
    errors: list[str] = []
    try:
        if not core.is_patched_gkey(p['gkey'].read_bytes()):
            errors.append('GKEY is not VGM-carrier engine')
    except Exception as exc:
        errors.append(f'GKEY audit failed: {exc}')
    for i, expected in _core_carrier_bytes().items():
        q = p[i]
        if not q.is_file() or q.read_bytes() != expected:
            errors.append(f'P{i:02d} is not original-VGZ carrier')
    return not errors, errors


def _install_original_vgz_carriers(root: Path, stock_files_root: Path | None) -> int:
    """Install the numbered/original VGZ carriers without the user custom-track layer.

    Supported inputs are exact stock GKEY/MUS, the exact core-VGZ carrier set, or the
    official custom-VGM set whose modified slots can be recognized byte-for-byte.
    Unknown music data is rejected before any write.
    """
    p = core.game_paths(root)
    expected = _core_carrier_bytes()
    if core.baseline_all(p):
        core.apply(root, 'all')
        return 1 + len(core.TARGETS)

    g = p['gkey'].read_bytes()
    if core.is_patched_gkey(g):
        custom_hashes = {int(k): v for k, v in tracks.EXPECTED_SHA.items() if int(k) in core.TARGETS}
        planned: list[tuple[Path, bytes]] = []
        for i, want in expected.items():
            q = p[i]
            if not q.is_file():
                raise RuntimeError(f'원본 VGZ Carrier 전환 실패: P{i:02d} missing')
            cur = q.read_bytes()
            if cur == want:
                continue
            got = sha_file(q)
            if custom_hashes.get(i) == got:
                planned.append((q, want))
                continue
            raise RuntimeError(
                f'원본 VGZ Carrier 전환 실패: P{i:02d}가 지원되는 core/custom carrier가 아닙니다. writes=0'
            )
        for q, data in planned:
            atomic(q, data)
        return len(planned)

    # Last supported route: restore exact stock music assets from the AIO stock
    # backup and build all carriers from the bundled original VGZ sources.
    if stock_files_root is not None:
        _restore_stock_music_assets(root, stock_files_root)
        core.apply(root, 'all')
        return 1 + len(core.TARGETS)
    raise RuntimeError(
        '현재 GKEY/BGM이 순정 또는 지원 VGM Carrier 상태가 아닙니다. '
        '원본 VGZ Carrier로 전환하려면 검증된 순정 백업이 필요합니다.'
    )


def apply_original(root: str | Path | None = None, stock_files_root: str | Path | None = None) -> dict[str, object]:
    """Use the VGM carrier engine with the original VGZ set, not stock MUS.

    This deliberately excludes the user-added/custom replacement layer (P06 custom
    Surprise, P26 custom flute, P27 custom final-boss, P29 TITLE, P30 Cannon,
    P31 throne).  Existing control/hard-stop fixes remain enabled.
    """
    r = core.game_paths(root)['root']
    stock_root = _stock_asset_root(stock_files_root)

    # Normalize the two extra custom-song mappings before auditing the common
    # BGM-control layer.  P27 remains the original final-battle VGZ carrier.
    cannon_changes = _normalize_cannon_mapping(r)
    throne_changes = _normalize_throne_mapping(r)
    removed = _remove_unused_official_custom_slots(r)
    carrier_changes = _install_original_vgz_carriers(r, stock_root)

    # Keep every non-composition BGM behavior fix.  Unlike the old "original"
    # mode this is still a compact VGM carrier configuration.
    ctl.apply(r)
    fade.apply(r)
    battle.apply(r)
    exitbgm.apply(r)
    allstop.apply(r)
    # P26 is an original VGZ one-shot carrier.  Synchronize WAIT_BGM to the
    # carrier header dynamically (currently 486 ticks), not the custom 436 ticks.
    wait_result = waitsync.apply(r)

    st = status_original(r)
    if not st['ok']:
        raise RuntimeError('원본 VGZ Carrier 모드 최종 검증 실패: ' + ', '.join(st['errors']))
    print('원본 BGM (원본 VGZ Carrier) 모드 적용 완료.')
    print('- VGM Carrier 엔진: 유지')
    print('- P02~P27 + P29: bundled original VGZ source')
    print('- 사용자 추가 교체곡 P06/P26/P27/P29 및 전용 P30/P31: 미사용')
    print('- BGM hard-stop / 전투 종료 / 설정 ON-OFF 제어 수정: 유지')
    return {
        'mode': 'original_vgz_carrier',
        'carrier_changes': carrier_changes,
        'cannon_mapping_changes': cannon_changes,
        'throne_mapping_changes': throne_changes,
        'unused_official_custom_files_removed': removed,
        'wait_bgm_ticks': wait_result.get('ticks'),
        'ok': True,
    }

def _apply_custom_layer_on_core(root: Path) -> None:
    """Apply only the user custom-song layer when core original-VGZ carriers exist."""
    # Original-VGZ mode keeps the common global hard-stop at C_600 while using
    # the original L17 song.  The cannon custom-song component expects the
    # original fade instruction as its guarded precondition, so normalize just
    # that command before switching L17 -> custom L29/P30.
    c600 = root / 'SCENA' / 'C_600.DLL'
    cb = c600.read_bytes()
    s3, _ = cannon.segment_info(cb, cannon.C600_SEG3)
    stop = cannon.code_bytes_at(cb, cannon.C600_SEG3, cannon.STOP_OFF, 5)
    play = cannon.code_bytes_at(cb, cannon.C600_SEG3, cannon.PLAY_MOV_OFF, 2)
    if stop == HARDSTOP and play == bytes((0xB0, cannon.PLAY_ORIGINAL_LOGICAL)):
        x = bytearray(cb)
        x[s3['base'] + cannon.STOP_OFF:s3['base'] + cannon.STOP_OFF + 5] = cannon.STOP_ORIGINAL
        atomic(c600, bytes(x))
    elif play != bytes((0xB0, cannon.PLAY_CUSTOM_LOGICAL)) and stop != cannon.STOP_ORIGINAL:
        raise RuntimeError('C_600 custom-song 전환 precondition 실패. writes=0')

    ctl.apply(root)
    fade.apply(root)
    cannon.apply(root)
    battle.apply(root)
    throne.apply(root)
    tracks.apply(root)
    waitsync.apply(root)
    exitbgm.apply(root)
    allstop.apply(root)


def apply_custom(root: str | Path | None = None) -> dict[str, object]:
    r = core.game_paths(root)['root']
    base_ok, _ = _core_vgz_state(r)
    if base_ok:
        _apply_custom_layer_on_core(r)
        return {'mode': 'custom_vgm', 'from': 'original_vgz_carrier', 'ok': True}

    # Original-music mode may retain a global C_600 hard-stop with the original
    # L17 selection.  Normalize only the stop instruction before the historical
    # combined installer performs its guarded transition.
    c600 = r / 'SCENA' / 'C_600.DLL'
    cb = c600.read_bytes()
    s3, _ = cannon.segment_info(cb, cannon.C600_SEG3)
    stop = cannon.code_bytes_at(cb, cannon.C600_SEG3, cannon.STOP_OFF, 5)
    play = cannon.code_bytes_at(cb, cannon.C600_SEG3, cannon.PLAY_MOV_OFF, 2)
    if stop == HARDSTOP and play == bytes((0xB0, cannon.PLAY_ORIGINAL_LOGICAL)):
        x = bytearray(cb)
        x[s3['base'] + cannon.STOP_OFF:s3['base'] + cannon.STOP_OFF + 5] = cannon.STOP_ORIGINAL
        atomic(c600, bytes(x))
    combined.apply(r)
    return {'mode': 'custom_vgm', 'ok': True}

def status_original(root: str | Path | None = None) -> dict[str, object]:
    r = core.game_paths(root)['root']
    errors: list[str] = []
    base_ok, base_errors = _core_vgz_state(r)
    if not base_ok:
        errors.extend(base_errors)

    eb = (r / 'ED2MAIN.EXE').read_bytes()
    if cannon.map_value(eb, cannon.CUSTOM_LOGICAL) != cannon.ORIGINAL_L29_PHYSICAL:
        errors.append('L29 is not original mapping')
    if cannon.map_value(eb, cannon.OLD_517_LOGICAL) != cannon.OLD_517_ORIGINAL:
        errors.append('L25 mapping is not original')
    if cannon.bad518_word_value(eb) != cannon.BAD_518_WORD_ORIGINAL:
        errors.append('legacy cannon mapping word remains')
    if throne.map_value(eb, throne.THRONE_LOGICAL) != throne.THRONE_STOCK_PHYSICAL:
        errors.append('throne L15 is not original mapping')
    if throne.map_value(eb, throne.BATTLE_LOGICAL) != throne.BATTLE_PHYSICAL:
        errors.append('final battle L16 mapping changed')

    cb = (r / 'SCENA' / 'C_600.DLL').read_bytes()
    play = cannon.code_bytes_at(cb, cannon.C600_SEG3, cannon.PLAY_MOV_OFF, 2)
    if play != bytes((0xB0, cannon.PLAY_ORIGINAL_LOGICAL)):
        errors.append('C_600 LOAD_BGM is not original L17')

    cstate, _ = ctl.classify(eb)
    if cstate != 'v0.5.15-fixed':
        errors.append('BGM control fix missing')
    try:
        bstate = battle.battle_state(eb)
    except Exception:
        bstate = 'unsupported'
    if bstate != 'fixed':
        errors.append('battle-end hard-stop fix missing')

    try:
        _, items = allstop.preflight(r)
        chapter = allstop.preflight_chapter_transitions(r)
        if not all(x[6] == 'patched' for x in items):
            errors.append('global hard-stop sites incomplete')
        if not all(x[6] == 'original' for x in chapter):
            errors.append('chapter transition 0401 policy changed')
    except Exception as exc:
        errors.append(f'global hard-stop audit failed: {exc}')

    try:
        ws = waitsync.status(r)
        expected_ticks = waitsync.carrier_ticks(r)
        if ws.get('state') != 'patched' or int(ws.get('carrier_ticks') or -1) != expected_ticks:
            errors.append('VGM WAIT_BGM sync is not matched to original P26 carrier')
    except Exception as exc:
        errors.append(f'WAIT_BGM sync status failed: {exc}')

    # P30/P31 are custom-only additions and must not be selected by mappings in
    # original-VGZ mode. Exact bundled files are removed by apply_original.
    return {
        'mode': 'original_vgz_carrier',
        'ok': not errors,
        'errors': errors,
        'vgm_carrier_files': len(core.TARGETS),
        'gkey_vgm_engine': core.is_patched_gkey(core.game_paths(r)['gkey'].read_bytes()),
        'p26_ticks': (waitsync.carrier_ticks(r) if base_ok else None),
        'l15_physical': throne.map_value(eb, throne.THRONE_LOGICAL),
        'l16_physical': throne.map_value(eb, throne.BATTLE_LOGICAL),
        'l29_physical': cannon.map_value(eb, cannon.CUSTOM_LOGICAL),
        'battle_end': bstate,
        'bgm_control': cstate,
    }

def main() -> int:
    ap = argparse.ArgumentParser(description="ED2 music source mode switch")
    ap.add_argument("action", choices=["custom", "original", "status-original"])
    ap.add_argument("game_root", nargs="?", default="auto")
    ap.add_argument("--stock-files-root", help="AIO *_STOCK_BACKUP/GAME_FILES path")
    a = ap.parse_args()
    root = None if a.game_root == "auto" else a.game_root
    try:
        if a.action == "custom":
            result = apply_custom(root)
        elif a.action == "original":
            result = apply_original(root, a.stock_files_root)
        else:
            result = status_original(root)
        import json
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 1
    except Exception as exc:
        print(f"[ERROR] {type(exc).__name__}: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
