#!/usr/bin/env python3
from __future__ import annotations

import os
import argparse, hashlib, json, os, shutil, struct, tempfile
from pathlib import Path

VERSION = '0.5.23'
BACKUP = Path('ED2_BACKUP') / 'VGM_BGM_Engine' / 'C600_Cannon_BGM30'
OLD_522_BACKUP = '_ED2_C600_CANNON_BGM30_V0522_BACKUP'
OLD_521_BACKUP = '_ED2_C600_CANNON_BGM30_V0521_BACKUP'
OLD_520_BACKUP = '_ED2_C600_CANNON_BGM30_V0520_BACKUP'
OLD_519_BACKUP = '_ED2_C600_CANNON_BGM30_V0519_BACKUP'
OLD_518_BACKUP = '_ED2_C600_CANNON_BGM30_V0518_BACKUP'
OLD_517_BACKUP = '_ED2_CANNON_BGM30_V0517_BACKUP'

# ED2MAIN logical -> physical BGM table: exactly L00..L31 (32 uint16 entries).
MAP_SEG = 12
MAP_OFF = 0x11AE
MAP_COUNT = 32
CUSTOM_LOGICAL = 29
CUSTOM_PHYSICAL = 30
ORIGINAL_L29_PHYSICAL = 2

# Repair old experiments.
OLD_517_LOGICAL = 25
OLD_517_ORIGINAL = 21
OLD_517_CUSTOM = 30
BAD_518_L32_INDEX = 32
BAD_518_WORD_ORIGINAL = 0
BAD_518_WORD_PATCHED = 30

# C_600.DLL.
C600_SEG2 = 2
C600_SEG3 = 3
ORIG_SEG3_LEN = 0x06D2
# v1.4.62/R17 extends only the Rayisia message through a guarded local 0F tail.
# The cannon patch owns fixed code bytes later in the same segment and must preserve
# this dialogue tail instead of rejecting the longer segment.
DIALOGUE62_SEG3_LEN = 0x06DD
DIALOGUE62_SLOT_OFF = 0x01B8
DIALOGUE62_SLOT = bytes.fromhex('C0 CC C1 A6 20 B0 F0 20 0F D2 06 FF')
DIALOGUE62_TAIL = bytes.fromhex('BF C3 20 B0 C5 BE DF 2E 0F C4 01')
LOAD_BGM_ORDINAL = 91
DS_MZH_ORDINAL = 331
DISP_MESS_ORDINAL = 627

# v0.5.23 keeps the stock post-stop LOAD_BGM call but changes the stock fade stop
# into the same hard-stop form already runtime-proven by the v0.5.15 global fade patch.
# Original C_600 flow around the cannon:
#   0473: MOV AX,0402h / INT 40h        ; stop current music
#   0478..0498: screen-position/redraw delay loop
#   049A: MOV AL,11h
#   049C: CALL FAR ED2MAIN!LOAD_BGM     ; L17 -> P0 (silence)
# v0.5.23 changes two fixed-length sites:
#   0473: B8 02 04 CD 40 -> B4 01 CD 40 90 (immediate hard stop)
#   049B: 11h -> 1Dh (L17 -> L29/P30)
# Thus the order becomes hard stop -> screen transition -> L29/P30 -> cannon.
STOP_OFF = 0x0473
STOP_ORIGINAL = bytes.fromhex('B8 02 04 CD 40')
STOP_HARD = bytes.fromhex('B4 01 CD 40 90')
PLAY_MOV_OFF = 0x049A
PLAY_IMM_OFF = 0x049B
PLAY_ORIGINAL_LOGICAL = 0x11
PLAY_CUSTOM_LOGICAL = CUSTOM_LOGICAL
PLAY_RELOC_SOURCE = 0x049D

# v0.5.21 wrong ordering: DISP_MESS return SI==026C -> LOAD_BGM(L29),
# followed shortly by stock AX=0402 / INT40 which stops the new music.
V521_MESSAGE_CALL_OPCODE_OFF = 0x0455
V521_MESSAGE_RELOC_SOURCE = 0x0456
V521_NARESA_RETURN_SI = 0x026C
V521_WRAPPER3_OFF = ORIG_SEG3_LEN
V521_WRAPPER3 = bytes.fromhex(
    '9A FF FF 00 00 '
    '81 FE 6C 02 '
    '75 0F '
    '9C 60 1E 06 '
    'B0 1D '
    '9A FF FF 00 00 '
    '07 1F 61 9D '
    'CB'
)
V521_NEW_SEG3_LEN = ORIG_SEG3_LEN + len(V521_WRAPPER3)
V521_WRAPPER3_DISP_RELOC_SOURCE = V521_WRAPPER3_OFF + 1
V521_WRAPPER3_LOAD_RELOC_SOURCE = V521_WRAPPER3_OFF + 18

# v0.5.20 wrong-early prefire wrapper, removed on migration.
V520_PREFIRE_RELOC_SOURCE = 0x0424
V520_WRAPPER3_OFF = ORIG_SEG3_LEN
V520_WRAPPER3 = bytes.fromhex('9C 60 1E 06 B0 1D 9A FF FF 00 00 07 1F 61 9D 9A FF FF 00 00 CB')
V520_NEW_SEG3_LEN = ORIG_SEG3_LEN + len(V520_WRAPPER3)
V520_LOAD_RELOC_SOURCE = V520_WRAPPER3_OFF + 7
V520_DSMZH_RELOC_SOURCE = V520_WRAPPER3_OFF + 16

# v0.5.19 wrong data-segment wrapper, removed on migration.
V519_WRAPPER2_OFF = 0x00D3
V519_WRAPPER2 = bytes.fromhex('B0 1D 9A FF FF 00 00 9A FF FF 00 00 CB')
V519_WRAPPER2_ORIGINAL = b'\x00' * len(V519_WRAPPER2)
V519_LOAD_RELOC_SOURCE = V519_WRAPPER2_OFF + 3
V519_DSMZH_RELOC_SOURCE = V519_WRAPPER2_OFF + 8
V519_PREFIRE_RELOC_SOURCE = 0x0424

# v0.5.18 wrong late hook, removed on migration.
V518_HOOK_OFF = 0x0473
V518_HOOK_ORIGINAL = bytes.fromhex('B8 02 04 CD 40')
V518_STUB_OFF = 0x0288
V518_STUB_ORIGINAL = b'\x00' * 8
V518_STUB_PATCHED = bytes.fromhex('B0 20 9A FF FF 00 00 C3')
V518_HOOK_PATCHED = b'\xE8' + struct.pack('<h', V518_STUB_OFF - (V518_HOOK_OFF + 3)) + b'\x90\x90'
V518_RELOC_SOURCE = 0x028B

RELOC_SOURCE_FAR = 0x03
RELOC_FLAGS_INTERNAL = 0x00
RELOC_FLAGS_IMPORT_ORD = 0x01


def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p:Path): return sha_bytes(p.read_bytes())


def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.c600523.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def find_ci(parent:Path,name:str,directory=False)->Path:
    direct=parent/name
    if direct.exists() and direct.is_dir()==directory: return direct
    for p in parent.iterdir():
        if p.name.lower()==name.lower() and p.is_dir()==directory: return p
    raise FileNotFoundError(f'{parent} 안에서 {name}을 찾지 못했습니다.')


def looks(root:Path)->bool:
    try:
        find_ci(root,'ED2MAIN.EXE'); find_ci(root,'BGM',True)
        s=find_ci(root,'SCENA',True); find_ci(s,'C_600.DLL'); return True
    except Exception:return False


def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r): raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen: continue
            seen.add(k)
            if looks(r): return r
    raise FileNotFoundError('ED2MAIN.EXE / SCENA/C_600.DLL / BGM이 함께 있는 게임 폴더를 찾지 못했습니다.')


def ne_header_and_segments(b:bytes):
    if len(b)<0x40 or b[:2]!=b'MZ': raise RuntimeError('MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE': raise RuntimeError('16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c); table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    result=[]
    for i in range(count):
        ep=table+i*8
        sector,length,flags,alloc=struct.unpack_from('<HHHH',b,ep)
        result.append({'index':i+1,'entry':ep,'base':sector<<shift,
                       'length':65536 if length==0 else length,'length_raw':length,
                       'flags':flags,'alloc':alloc})
    return ne,result


def ne_segments(b:bytes): return ne_header_and_segments(b)[1]
def segment_info(b:bytes,index:int):
    segs=ne_segments(b)
    if not 1<=index<=len(segs): raise RuntimeError(f'NE segment {index}가 없습니다.')
    return segs[index-1],segs


def set_segment_size(x:bytearray, original:bytes, index:int, new_len:int):
    seg,_=segment_info(original,index)
    if not 0<new_len<65536: raise RuntimeError('segment length 범위 오류')
    struct.pack_into('<H',x,seg['entry']+2,new_len)
    if seg['alloc'] in (seg['length'], ORIG_SEG3_LEN, V520_NEW_SEG3_LEN, V521_NEW_SEG3_LEN):
        struct.pack_into('<H',x,seg['entry']+6,new_len)


def map_file_offset(b:bytes,logical:int)->int:
    if not 0<=logical<MAP_COUNT: raise RuntimeError(f'논리 BGM ID L{logical}는 L0..L31 밖입니다.')
    seg,_=segment_info(b,MAP_SEG); off=MAP_OFF+logical*2
    if off+2>seg['length']: raise RuntimeError('BGM mapping table이 segment 범위를 벗어났습니다.')
    return seg['base']+off

def map_value(b:bytes,logical:int)->int:return u16(b,map_file_offset(b,logical))
def bad518_word_offset(b:bytes)->int:
    seg,_=segment_info(b,MAP_SEG);off=MAP_OFF+BAD_518_L32_INDEX*2
    if off+2>seg['length']:raise RuntimeError('v0.5.18 손상 위치가 segment 범위를 벗어났습니다.')
    return seg['base']+off

def bad518_word_value(b:bytes)->int:return u16(b,bad518_word_offset(b))


def import_modules(b:bytes):
    ne=u32(b,0x3c); imported=ne+u16(b,ne+0x2a); module_refs=ne+u16(b,ne+0x28); count=u16(b,ne+0x1e)
    mods=[]
    for i in range(count):
        off=u16(b,module_refs+i*2);pos=imported+off;n=b[pos];mods.append(b[pos+1:pos+1+n].decode('latin1'))
    return mods

def ed2main_module_index(c600:bytes)->int:
    for i,name in enumerate(import_modules(c600),1):
        if name.upper()=='ED2MAIN':return i
    raise RuntimeError('C_600.DLL import table에서 ED2MAIN을 찾지 못했습니다.')


def reloc_layout(b:bytes,seg_index:int):
    seg,segs=segment_info(b,seg_index);rs=seg['base']+seg['length']
    if rs+2>len(b):raise RuntimeError(f'C_600 segment {seg_index} relocation count가 잘렸습니다.')
    count=u16(b,rs);rd=rs+2;re=rd+count*8
    next_base=min([s['base'] for s in segs if s['base']>seg['base']] or [len(b)])
    if re>next_base:raise RuntimeError(f'C_600 segment {seg_index} relocation table이 다음 segment와 겹칩니다.')
    return seg,count,rs,rd,re,next_base

def reloc_records(b:bytes,seg_index:int):
    _s,c,_rs,rd,_re,_nb=reloc_layout(b,seg_index)
    return [b[rd+i*8:rd+(i+1)*8] for i in range(c)]
def import_reloc(source:int,module_index:int,ordinal:int)->bytes:
    return struct.pack('<BBHHH',RELOC_SOURCE_FAR,RELOC_FLAGS_IMPORT_ORD,source,module_index,ordinal)
def internal_reloc(source:int,target_seg:int,target_off:int)->bytes:
    return struct.pack('<BBHHH',RELOC_SOURCE_FAR,RELOC_FLAGS_INTERNAL,source,target_seg,target_off)


def original_message_reloc(b:bytes):return import_reloc(V521_MESSAGE_RELOC_SOURCE,ed2main_module_index(b),DISP_MESS_ORDINAL)
def v521_message_reloc():return internal_reloc(V521_MESSAGE_RELOC_SOURCE,C600_SEG3,V521_WRAPPER3_OFF)
def v521_wrapper_relocs(b:bytes):
    m=ed2main_module_index(b)
    return import_reloc(V521_WRAPPER3_DISP_RELOC_SOURCE,m,DISP_MESS_ORDINAL),import_reloc(V521_WRAPPER3_LOAD_RELOC_SOURCE,m,LOAD_BGM_ORDINAL)
def play_load_reloc(b:bytes):
    return import_reloc(PLAY_RELOC_SOURCE,ed2main_module_index(b),LOAD_BGM_ORDINAL)

# old-version relocation helpers

def orig_prefire_reloc(b:bytes):return import_reloc(V520_PREFIRE_RELOC_SOURCE,ed2main_module_index(b),DS_MZH_ORDINAL)
def v519_prefire_reloc():return internal_reloc(V519_PREFIRE_RELOC_SOURCE,C600_SEG2,V519_WRAPPER2_OFF)
def v520_prefire_reloc():return internal_reloc(V520_PREFIRE_RELOC_SOURCE,C600_SEG3,V520_WRAPPER3_OFF)
def v518_reloc(b:bytes):return import_reloc(V518_RELOC_SOURCE,ed2main_module_index(b),LOAD_BGM_ORDINAL)
def v519_wrapper_relocs(b:bytes):
    m=ed2main_module_index(b);return import_reloc(V519_LOAD_RELOC_SOURCE,m,LOAD_BGM_ORDINAL),import_reloc(V519_DSMZH_RELOC_SOURCE,m,DS_MZH_ORDINAL)
def v520_wrapper_relocs(b:bytes):
    m=ed2main_module_index(b);return import_reloc(V520_LOAD_RELOC_SOURCE,m,LOAD_BGM_ORDINAL),import_reloc(V520_DSMZH_RELOC_SOURCE,m,DS_MZH_ORDINAL)


def code_bytes_at(b:bytes,seg:int,off:int,n:int)->bytes:
    s,_=segment_info(b,seg);return b[s['base']+off:s['base']+off+n]


def message_anchor_ok(b:bytes)->bool:
    # phrase bytes are localization-stable at control level: terminating 00h at 026B
    # and next block begins with 1Eh. Verify only the structural bytes.
    try:
        return code_bytes_at(b,C600_SEG3,0x026A,3)[1:] == b'\x00\x1E'
    except Exception:return False



def dialogue62_layout_ok(b:bytes)->bool:
    try:
        s3,_=segment_info(b,C600_SEG3)
        if s3['length']==ORIG_SEG3_LEN:
            return True
        if s3['length']!=DIALOGUE62_SEG3_LEN:
            return False
        slot=code_bytes_at(b,C600_SEG3,DIALOGUE62_SLOT_OFF,len(DIALOGUE62_SLOT))
        tail=code_bytes_at(b,C600_SEG3,ORIG_SEG3_LEN,len(DIALOGUE62_TAIL))
        return slot==DIALOGUE62_SLOT and tail==DIALOGUE62_TAIL
    except Exception:
        return False

def classify_c600(b:bytes)->str:
    try:
        s2,_=segment_info(b,C600_SEG2);s3,_=segment_info(b,C600_SEG3)
        stop=code_bytes_at(b,C600_SEG3,STOP_OFF,5)
        play=code_bytes_at(b,C600_SEG3,PLAY_MOV_OFF,2)
        st518=code_bytes_at(b,C600_SEG3,V518_STUB_OFF,8)
        wrap2=code_bytes_at(b,C600_SEG2,V519_WRAPPER2_OFF,len(V519_WRAPPER2))
        r2=reloc_records(b,C600_SEG2);r3=reloc_records(b,C600_SEG3)
        om=original_message_reloc(b);pm=v521_message_reloc();a521,b521=v521_wrapper_relocs(b)
        op=orig_prefire_reloc(b);p519=v519_prefire_reloc();p520=v520_prefire_reloc();old518=v518_reloc(b)
        w519a,w519b=v519_wrapper_relocs(b);w520a,w520b=v520_wrapper_relocs(b)
        pload=play_load_reloc(b)
        base_common=(stop==STOP_ORIGINAL and st518==V518_STUB_ORIGINAL and wrap2==V519_WRAPPER2_ORIGINAL)
        current_layout=dialogue62_layout_ok(b)
        if (current_layout and base_common and play==bytes((0xB0,PLAY_ORIGINAL_LOGICAL))
            and r3.count(op)==1 and r3.count(p519)==0 and r3.count(p520)==0 and r3.count(old518)==0
            and r3.count(om)==1 and r3.count(pm)==0 and r3.count(pload)==1
            and r2.count(w519a)==0 and r2.count(w519b)==0 and message_anchor_ok(b)): return 'original'
        if (s3['length']==ORIG_SEG3_LEN and stop==V518_HOOK_PATCHED and st518==V518_STUB_PATCHED
            and wrap2==V519_WRAPPER2_ORIGINAL and r3.count(op)==1 and r3.count(old518)==1 and r3.count(om)==1): return 'v0.5.18-wrong-late-hook'
        if (s3['length']==ORIG_SEG3_LEN and stop==STOP_ORIGINAL and wrap2==V519_WRAPPER2
            and r3.count(p519)==1 and r3.count(op)==0 and r2.count(w519a)==1 and r2.count(w519b)==1 and r3.count(om)==1): return 'v0.5.19-data-wrapper'
        if s3['length']==V520_NEW_SEG3_LEN and stop==STOP_ORIGINAL and wrap2==V519_WRAPPER2_ORIGINAL:
            wrapper=code_bytes_at(b,C600_SEG3,V520_WRAPPER3_OFF,len(V520_WRAPPER3))
            if (wrapper==V520_WRAPPER3 and r3.count(p520)==1 and r3.count(op)==0
                and r3.count(w520a)==1 and r3.count(w520b)==1 and r3.count(om)==1): return 'v0.5.20-early-prefire'
        if s3['length']==V521_NEW_SEG3_LEN and stop==STOP_ORIGINAL and wrap2==V519_WRAPPER2_ORIGINAL:
            wrapper=code_bytes_at(b,C600_SEG3,V521_WRAPPER3_OFF,len(V521_WRAPPER3))
            if (wrapper==V521_WRAPPER3 and r3.count(pm)==1 and r3.count(om)==0
                and r3.count(a521)==1 and r3.count(b521)==1 and r3.count(op)==1 and message_anchor_ok(b)):
                return 'v0.5.21-play-before-stop'
        if (current_layout and base_common and play==bytes((0xB0,PLAY_CUSTOM_LOGICAL))
            and r3.count(op)==1 and r3.count(om)==1 and r3.count(pload)==1 and message_anchor_ok(b)):
                return 'c600-stock-fade-then-p30-v0522'
        if (current_layout and stop==STOP_HARD and st518==V518_STUB_ORIGINAL and wrap2==V519_WRAPPER2_ORIGINAL
            and play==bytes((0xB0,PLAY_CUSTOM_LOGICAL)) and r3.count(op)==1 and r3.count(om)==1
            and r3.count(pload)==1 and message_anchor_ok(b)):
                return 'c600-hard-stop-then-p30-v0523'
        return f'unsupported-s3len{s3["length"]:04X}-wrap2{wrap2.hex()}-stop{stop.hex()}-play{play.hex()}'
    except Exception as e:return 'unsupported-parse-'+type(e).__name__+'-'+str(e)


def paths(root=None):
    r=auto_root(root);bgm=find_ci(r,'BGM',True);scena=find_ci(r,'SCENA',True)
    ed=find_ci(r,'ED2MAIN.EXE');c600=find_ci(scena,'C_600.DLL')
    p21m=find_ci(bgm,'DS2_21.MUS');p21i=find_ci(bgm,'DS2_21.INS')
    return r,bgm,ed,c600,p21m,p21i,bgm/'DS2_30.MUS',bgm/'DS2_30.INS'


def write_same_length_reloc_table(x:bytearray,original:bytes,seg_index:int,records:list[bytes]):
    _seg,_old,rs,rd,old_re,nb=reloc_layout(original,seg_index);new_re=rd+len(records)*8
    if new_re>nb:raise RuntimeError(f'C_600 segment{seg_index} relocation padding 부족')
    x[rs:max(old_re,new_re)]=b'\x00'*(max(old_re,new_re)-rs)
    struct.pack_into('<H',x,rs,len(records));pos=rd
    for r in records:x[pos:pos+8]=r;pos+=8


def normalize_v518(b:bytes)->bytes:
    if classify_c600(b)!='v0.5.18-wrong-late-hook':return b
    s3,*_=reloc_layout(b,C600_SEG3);x=bytearray(b)
    x[s3['base']+V518_HOOK_OFF:s3['base']+V518_HOOK_OFF+5]=V518_HOOK_ORIGINAL
    x[s3['base']+V518_STUB_OFF:s3['base']+V518_STUB_OFF+8]=V518_STUB_ORIGINAL
    rec=reloc_records(b,C600_SEG3);old=v518_reloc(b)
    if rec.count(old)!=1:raise RuntimeError('v0.5.18 relocation을 정확히 1개 찾지 못했습니다.')
    rec.remove(old);write_same_length_reloc_table(x,b,C600_SEG3,rec);out=bytes(x)
    if classify_c600(out)!='original':raise RuntimeError('v0.5.18 C_600 정상화 실패')
    return out


def normalize_v519(b:bytes)->bytes:
    if classify_c600(b)!='v0.5.19-data-wrapper':return b
    s2,*_=reloc_layout(b,C600_SEG2);x=bytearray(b)
    x[s2['base']+V519_WRAPPER2_OFF:s2['base']+V519_WRAPPER2_OFF+len(V519_WRAPPER2)]=V519_WRAPPER2_ORIGINAL
    r2=reloc_records(b,C600_SEG2);a,brel=v519_wrapper_relocs(b)
    if r2.count(a)!=1 or r2.count(brel)!=1:raise RuntimeError('v0.5.19 segment2 wrapper relocation 수 오류')
    r2.remove(a);r2.remove(brel);write_same_length_reloc_table(x,b,C600_SEG2,r2)
    tmp=bytes(x);r3=reloc_records(tmp,C600_SEG3);p=v519_prefire_reloc();o=orig_prefire_reloc(tmp)
    if r3.count(p)!=1 or r3.count(o)!=0:raise RuntimeError('v0.5.19 prefire relocation 상태 오류')
    r3[r3.index(p)]=o;write_same_length_reloc_table(x,tmp,C600_SEG3,r3);out=bytes(x)
    if classify_c600(out)!='original':raise RuntimeError('v0.5.19 C_600 정상화 실패: '+classify_c600(out))
    return out


def normalize_v520(b:bytes)->bytes:
    if classify_c600(b)!='v0.5.20-early-prefire':return b
    s3,c,rs,rd,re,nb=reloc_layout(b,C600_SEG3);r3=reloc_records(b,C600_SEG3)
    a,bb=v520_wrapper_relocs(b);p=v520_prefire_reloc();o=orig_prefire_reloc(b)
    if r3.count(a)!=1 or r3.count(bb)!=1 or r3.count(p)!=1 or r3.count(o)!=0:
        raise RuntimeError('v0.5.20 relocation 정상화 상태 오류')
    r3.remove(a);r3.remove(bb);r3[r3.index(p)]=o
    old_rs=s3['base']+ORIG_SEG3_LEN
    x=bytearray(b);x[old_rs:re]=b'\x00'*(re-old_rs)
    struct.pack_into('<H',x,old_rs,len(r3));pos=old_rs+2
    for r in r3:x[pos:pos+8]=r;pos+=8
    set_segment_size(x,b,C600_SEG3,ORIG_SEG3_LEN)
    out=bytes(x)
    if classify_c600(out)!='original':raise RuntimeError('v0.5.20 C_600 정상화 실패: '+classify_c600(out))
    return out



def normalize_v521(b:bytes)->bytes:
    if classify_c600(b)!='v0.5.21-play-before-stop':return b
    s3,c,rs,rd,re,nb=reloc_layout(b,C600_SEG3);r3=reloc_records(b,C600_SEG3)
    a,bb=v521_wrapper_relocs(b);pm=v521_message_reloc();om=original_message_reloc(b)
    if r3.count(a)!=1 or r3.count(bb)!=1 or r3.count(pm)!=1 or r3.count(om)!=0:
        raise RuntimeError('v0.5.21 relocation 정상화 상태 오류')
    r3.remove(a);r3.remove(bb);r3[r3.index(pm)]=om
    old_rs=s3['base']+ORIG_SEG3_LEN
    x=bytearray(b);x[old_rs:re]=b'\x00'*(re-old_rs)
    struct.pack_into('<H',x,old_rs,len(r3));pos=old_rs+2
    for r in r3:x[pos:pos+8]=r;pos+=8
    set_segment_size(x,b,C600_SEG3,ORIG_SEG3_LEN)
    out=bytes(x)
    if classify_c600(out)!='original':raise RuntimeError('v0.5.21 C_600 정상화 실패: '+classify_c600(out))
    return out

def patch_stop_and_stock_load(b:bytes)->bytes:
    state=classify_c600(b)
    if state not in ('original','c600-stock-fade-then-p30-v0522'):
        raise RuntimeError('C_600 hard-stop 적용 직전 상태 오류: '+state)
    s3,_=segment_info(b,C600_SEG3)
    x=bytearray(b)
    if state=='original':
        if code_bytes_at(b,C600_SEG3,STOP_OFF,5)!=STOP_ORIGINAL: raise RuntimeError('C_600 0473 원본 fade 정지 명령 불일치')
        if code_bytes_at(b,C600_SEG3,PLAY_MOV_OFF,2)!=bytes((0xB0,PLAY_ORIGINAL_LOGICAL)): raise RuntimeError('C_600 049A 원본 LOAD_BGM 번호 불일치')
        x[s3['base']+PLAY_IMM_OFF]=PLAY_CUSTOM_LOGICAL
    else:
        if code_bytes_at(b,C600_SEG3,STOP_OFF,5)!=STOP_ORIGINAL: raise RuntimeError('v0.5.22 0473 fade 정지 명령 불일치')
    if reloc_records(b,C600_SEG3).count(play_load_reloc(b))!=1: raise RuntimeError('C_600 049D LOAD_BGM relocation 불일치')
    x[s3['base']+STOP_OFF:s3['base']+STOP_OFF+5]=STOP_HARD
    out=bytes(x)
    if classify_c600(out)!='c600-hard-stop-then-p30-v0523': raise RuntimeError('v0.5.23 C_600 적용 검증 실패: '+classify_c600(out))
    return out


def restore_v0523(b:bytes)->bytes:
    if classify_c600(b)!='c600-hard-stop-then-p30-v0523': raise RuntimeError('v0.5.23 복원 직전 상태 오류')
    s3,_=segment_info(b,C600_SEG3);x=bytearray(b)
    x[s3['base']+STOP_OFF:s3['base']+STOP_OFF+5]=STOP_ORIGINAL
    x[s3['base']+PLAY_IMM_OFF]=PLAY_ORIGINAL_LOGICAL
    out=bytes(x)
    if classify_c600(out)!='original': raise RuntimeError('v0.5.23 C_600 복원 검증 실패: '+classify_c600(out))
    return out


def apply_c600(c600:Path):
    raw=c600.read_bytes();state=classify_c600(raw)
    if state=='c600-hard-stop-then-p30-v0523':return False
    if state=='v0.5.18-wrong-late-hook':raw=normalize_v518(raw)
    elif state=='v0.5.19-data-wrapper':raw=normalize_v519(raw)
    elif state=='v0.5.20-early-prefire':raw=normalize_v520(raw)
    elif state=='v0.5.21-play-before-stop':raw=normalize_v521(raw)
    state=classify_c600(raw)
    if state not in ('original','c600-stock-fade-then-p30-v0522'):raise RuntimeError(f'C_600 apply 직전 상태 오류: {state}')
    atomic(c600,patch_stop_and_stock_load(raw))
    if classify_c600(c600.read_bytes())!='c600-hard-stop-then-p30-v0523':raise RuntimeError('C_600 apply 후 검증 실패')
    return True


def restore_c600(c600:Path):
    b=c600.read_bytes();state=classify_c600(b)
    if state=='original':return False
    if state=='v0.5.18-wrong-late-hook':atomic(c600,normalize_v518(b));return True
    if state=='v0.5.19-data-wrapper':atomic(c600,normalize_v519(b));return True
    if state=='v0.5.20-early-prefire':atomic(c600,normalize_v520(b));return True
    if state=='v0.5.21-play-before-stop':atomic(c600,normalize_v521(b));return True
    if state=='c600-stock-fade-then-p30-v0522':
        s3,_=segment_info(b,C600_SEG3);x=bytearray(b);x[s3['base']+PLAY_IMM_OFF]=PLAY_ORIGINAL_LOGICAL;out=bytes(x)
        if classify_c600(out)!='original':raise RuntimeError('v0.5.22 복원 검증 실패')
        atomic(c600,out);return True
    if state!='c600-hard-stop-then-p30-v0523':raise RuntimeError(f'C_600 restore 직전 상태 오류: {state}')
    atomic(c600,restore_v0523(b));return True


def preflight(root=None):
    r,bgm,ed,c600,p21m,p21i,p30m,p30i=paths(root);eb=ed.read_bytes();cb=c600.read_bytes()
    l29=map_value(eb,CUSTOM_LOGICAL);l25=map_value(eb,OLD_517_LOGICAL);bad=bad518_word_value(eb);state=classify_c600(cb)
    if l29 not in (ORIGINAL_L29_PHYSICAL,CUSTOM_PHYSICAL):raise RuntimeError(f'ED2MAIN L29 mapping 지원 불가: P{l29}')
    if l25 not in (OLD_517_ORIGINAL,OLD_517_CUSTOM):raise RuntimeError(f'ED2MAIN L25 mapping 지원 불가: P{l25}')
    if bad not in (BAD_518_WORD_ORIGINAL,BAD_518_WORD_PATCHED):raise RuntimeError(f'ED2MAIN table 직후 word 지원 불가: {bad}')
    if state.startswith('unsupported'):raise RuntimeError(f'C_600.DLL 지원 상태가 아닙니다: {state}')
    if p21m.stat().st_size<97:raise RuntimeError('DS2_21.MUS가 비정상적으로 짧습니다.')
    if p21i.stat().st_size==0:raise RuntimeError('DS2_21.INS가 비어 있습니다.')
    return {'root':r,'l29':l29,'l25':l25,'bad518_word':bad,'c600_state':state,'p30_mus_exists':p30m.exists(),'p30_ins_exists':p30i.exists()}


def manifest_path(root:Path):return root/BACKUP/'manifest.json'
def load_manifest(root:Path):
    p=manifest_path(root)
    if not p.is_file():return None
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None
def write_manifest(root:Path,m:dict):
    d=root/BACKUP;d.mkdir(parents=True,exist_ok=True);manifest_path(root).write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def apply(root=None):
    pf=preflight(root);r,bgm,ed,c600,p21m,p21i,p30m,p30i=paths(pf['root']);aio_no_backup=os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP')=='1';m=None if aio_no_backup else load_manifest(r)
    if m is None:
        m={'version':VERSION,'ed2main_sha_before':sha_file(ed),'c600_sha_before':sha_file(c600),'c600_state_before':pf['c600_state'],
           'bad518_word_before':pf['bad518_word'],'ds2_30_mus_existed_before':p30m.exists(),'ds2_30_ins_existed_before':p30i.exists(),
           'ds2_30_mus_sha_before':sha_file(p30m) if p30m.exists() else None,'ds2_30_ins_sha_before':sha_file(p30i) if p30i.exists() else None}
    if not p30m.exists():shutil.copy2(p21m,p30m);m['created_ds2_30_mus']=True;m['placeholder_mus_sha']=sha_file(p30m)
    else:m.setdefault('created_ds2_30_mus',False)
    if not p30i.exists():shutil.copy2(p21i,p30i);m['created_ds2_30_ins']=True;m['placeholder_ins_sha']=sha_file(p30i)
    else:m.setdefault('created_ds2_30_ins',False)
    eb=ed.read_bytes();x=bytearray(eb)
    if map_value(eb,OLD_517_LOGICAL)==OLD_517_CUSTOM:struct.pack_into('<H',x,map_file_offset(eb,OLD_517_LOGICAL),OLD_517_ORIGINAL)
    if bad518_word_value(eb)==BAD_518_WORD_PATCHED:struct.pack_into('<H',x,bad518_word_offset(eb),BAD_518_WORD_ORIGINAL)
    if map_value(eb,CUSTOM_LOGICAL)==ORIGINAL_L29_PHYSICAL:struct.pack_into('<H',x,map_file_offset(eb,CUSTOM_LOGICAL),CUSTOM_PHYSICAL)
    atomic(ed,bytes(x))
    try:apply_c600(c600)
    except Exception:atomic(ed,eb);raise
    m.update({'ed2main_sha_after':sha_file(ed),'c600_sha_after':sha_file(c600),'l29_after':map_value(ed.read_bytes(),CUSTOM_LOGICAL),
              'l25_after':map_value(ed.read_bytes(),OLD_517_LOGICAL),'bad518_word_after':bad518_word_value(ed.read_bytes())})
    if not aio_no_backup: write_manifest(r,m)
    print(f'C_600 cannon BGM hard-stop-then-start v{VERSION} 적용 완료.')
    print('C_600 seg3:0473: AX=0402/INT40 fade -> AH=01/INT40 hard stop')
    print('C_600 seg3:049A LOAD_BGM immediate: L17 -> L29')
    print('ED2MAIN: L29 -> P30 / L25 -> P21 / v0.5.18 L32 word 복구')
    print('전용 음악: BGM/DS2_30.MUS')


def restore(root=None):
    r,bgm,ed,c600,p21m,p21i,p30m,p30i=paths(root);restore_c600(c600)
    eb=ed.read_bytes();x=bytearray(eb);l29=map_value(eb,CUSTOM_LOGICAL);l25=map_value(eb,OLD_517_LOGICAL);bad=bad518_word_value(eb)
    if l29==CUSTOM_PHYSICAL:struct.pack_into('<H',x,map_file_offset(eb,CUSTOM_LOGICAL),ORIGINAL_L29_PHYSICAL)
    elif l29!=ORIGINAL_L29_PHYSICAL:raise RuntimeError(f'ED2MAIN L29 restore 상태 오류: P{l29}')
    if l25==OLD_517_CUSTOM:struct.pack_into('<H',x,map_file_offset(eb,OLD_517_LOGICAL),OLD_517_ORIGINAL)
    elif l25!=OLD_517_ORIGINAL:raise RuntimeError(f'ED2MAIN L25 restore 상태 오류: P{l25}')
    if bad==BAD_518_WORD_PATCHED:struct.pack_into('<H',x,bad518_word_offset(eb),BAD_518_WORD_ORIGINAL)
    elif bad!=BAD_518_WORD_ORIGINAL:raise RuntimeError(f'ED2MAIN v0.5.18 word restore 상태 오류: {bad}')
    atomic(ed,bytes(x));m=load_manifest(r) or {};removed=[];preserved=[]
    for path,created_key,phkey in [(p30m,'created_ds2_30_mus','placeholder_mus_sha'),(p30i,'created_ds2_30_ins','placeholder_ins_sha')]:
        if not m.get(created_key) or not path.exists():continue
        ph=m.get(phkey)
        if ph and sha_file(path)==ph:path.unlink();removed.append(path.name)
        else:preserved.append(path.name)
    print('C_600 cannon BGM 복원 완료: 원래 seg3:0473 AX=0402/INT40 / L29 -> P2 / L25 -> P21')
    if removed:print('변경되지 않은 placeholder 삭제:',', '.join(removed))
    if preserved:print('사용자 수정 파일 보존:',', '.join(preserved))


def status(root=None):
    r,bgm,ed,c600,p21m,p21i,p30m,p30i=paths(root);eb=ed.read_bytes();cb=c600.read_bytes();state=classify_c600(cb);s3,_=segment_info(cb,C600_SEG3)
    print('=== C_600 cannon BGM hard-stop-then-start status v0.5.23 ===');print('game root:',r);print('C_600:',state);print('segment3 length:',hex(s3['length']))
    print('trigger: seg3:0473 hard stop, then stock seg3:049A LOAD_BGM changed L17 -> L29')
    print(f'L29 -> P{map_value(eb,CUSTOM_LOGICAL):02d} (custom must be P30)');print(f'L25 -> P{map_value(eb,OLD_517_LOGICAL):02d} (must remain P21)')
    print('v0.5.18 bad L32 word:',bad518_word_value(eb),'(must be 0)')
    print('DS2_30.MUS:','present' if p30m.exists() else 'missing',sha_file(p30m) if p30m.exists() else '')
    print('DS2_30.INS:','present' if p30i.exists() else 'missing',sha_file(p30i) if p30i.exists() else '')
    ready=(state=='c600-hard-stop-then-p30-v0523' and map_value(eb,CUSTOM_LOGICAL)==CUSTOM_PHYSICAL and map_value(eb,OLD_517_LOGICAL)==OLD_517_ORIGINAL
           and bad518_word_value(eb)==0 and p30m.exists() and p30i.exists())
    print('ready:',ready)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['apply','restore','status']);ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args();root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:print();print(f'[ERROR] {type(e).__name__}: {e}');return 1
if __name__=='__main__':raise SystemExit(main())
