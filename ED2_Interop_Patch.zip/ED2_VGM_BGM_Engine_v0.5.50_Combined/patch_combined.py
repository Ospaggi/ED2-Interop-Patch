#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent

def load(name,file):
    spec=importlib.util.spec_from_file_location(name,HERE/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
vgm=load('ed2_v0526_vgm','patch_vgm_bgm.py')
ctl=load('ed2_v0526_ctl','patch_ed2main_bgm_control.py')
fade=load('ed2_v0526_fade','patch_fadeout_bgm.py')
cannon=load('ed2_v0526_c600','patch_c600_cannon_bgm.py')
battle=load('ed2_v0535_battle','patch_battle_end_bgm.py')
throne=load('ed2_v0530_throne','patch_throne_room_bgm.py')
tracks=load('ed2_v0531_tracks','patch_custom_tracks.py')
exitbgm=load('ed2_v0531_exit','patch_exit_bgm.py')
allstop=load('ed2_v0538_allstop','patch_all_bgm_hardstop.py')
waitsync=load('ed2_v0550_waitsync','patch_wait_bgm_sync.py')

def root_of(explicit=None):return vgm.game_paths(explicit)['root']

def apply(root=None):
    r=root_of(root)
    ep=ctl.find_ci(r,'ED2MAIN.EXE'); state,_=ctl.classify(ep.read_bytes())
    if state=='unsupported':raise RuntimeError('ED2MAIN BGM control preflight 실패. 아무 파일도 수정하지 않았습니다.')
    fade.preflight(r); fade.preflight_chapter_transitions(r); cannon.preflight(r); battle.preflight(r); throne.preflight(r); exitbgm.preflight(r); allstop.preflight(r); allstop.preflight_chapter_transitions(r)
    print('통합 패치 v0.5.50 적용 시작:',r)
    print('1/9  VGM core (v0.5.18 runtime core; P25 = Grostos Castle 2)')
    vgm.apply(r,'all')
    try:
        print('2/9  BGM OFF/ON + same-BGM control fix')
        ctl.apply(r)
        print('3/9  gameplay BGM hard-stop fix (chapter transitions preserved)')
        fade.apply(r)
        print("4/9  C_600 Grostos Castle hard stop -> custom BGM: L29 -> P30")
        cannon.apply(r)
        print('5/9  normal battle-end BGM hard stop before field-BGM restore')
        battle.apply(r)
        print('6/9  throne room BGM split: L15 -> P31, final battle L16 -> P27 preserved')
        throne.apply(r)
        print("7/9  bundled custom tracks: P06=Surprise(-2.25 dB), P26=Soldier's Flute custom(0 dB), P27=Final Boss(-0.75 dB), P29=TITLE(-3.0 dB), P30=Cannon, P31=throne")
        tracks.apply(r)
        print('8/10 VGM one-shot WAIT_BGM sync: L12/P26 uses carrier clock')
        waitsync.apply(r)
        print('9/10 game exit: immediate BGM hard stop before DOS termination')
        exitbgm.apply(r)
        print('10/10 global BGM audit: chapter transitions keep stock 0401; other managed sites hard-stop')
        allstop.apply(r)
    except Exception:
        try:allstop.restore(r)
        except Exception as ee:print('[WARNING] global hard-stop rollback 실패:',ee)
        try:exitbgm.restore(r)
        except Exception as ee:print('[WARNING] game-exit rollback 실패:',ee)
        try:waitsync.restore(r)
        except Exception as ee:print('[WARNING] WAIT_BGM sync rollback 실패:',ee)
        try:tracks.restore(r)
        except Exception as ee:print('[WARNING] custom-track rollback 실패:',ee)
        try:throne.restore(r)
        except Exception as ee:print('[WARNING] throne-room rollback 실패:',ee)
        try:battle.restore(r)
        except Exception as ee:print('[WARNING] battle-end rollback 실패:',ee)
        try:cannon.restore(r)
        except Exception as ee:print('[WARNING] C_600 cannon rollback 실패:',ee)
        try:fade.restore(r)
        except Exception as ee:print('[WARNING] event rollback 실패:',ee)
        try:ctl.restore(r)
        except Exception as ee:print('[WARNING] ED2MAIN rollback 실패:',ee)
        try:vgm.restore(r)
        except Exception as ee:print('[WARNING] VGM rollback 실패:',ee)
        raise
    print('\n통합 적용 완료.')

def restore(root=None):
    r=root_of(root);print('통합 복원 시작:',r)
    allstop.restore(r);exitbgm.restore(r);waitsync.restore(r);tracks.restore(r);throne.restore(r);battle.restore(r);cannon.restore(r);fade.restore(r);ctl.restore(r);vgm.restore(r);print('통합 복원 완료.')

def status(root=None):
    r=root_of(root);print('=== v0.5.50 Combined status ===');vgm.status(r);print();ctl.status(r);print();fade.status(r);print();cannon.status(r);print();battle.status(r);print();throne.status(r);print();tracks.status(r);print();waitsync.status(r);print();exitbgm.status(r);print();allstop.status(r)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['apply','restore','status']);ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args();root=None if a.game_root=='auto' else a.game_root
    try:{'apply':apply,'restore':restore,'status':status}[a.action](root);return 0
    except Exception as e:
        print();print(f'[ERROR] {type(e).__name__}: {e}');print('통합 패치를 중단했습니다. 위 오류를 그대로 알려 주세요.');return 1
if __name__=='__main__':raise SystemExit(main())
