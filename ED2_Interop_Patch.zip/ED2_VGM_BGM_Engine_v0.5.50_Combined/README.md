# ED2 VGM BGM Engine v0.5.50 Combined

한국 DOS판 영웅전설 II에서 YM3812 VGM 기반 BGM을 재생하기 위한 통합 패치 구성요소입니다.

- 사용자 지정 VGM carrier 재생
- 곡별 루프 정보 유지
- 일반 BGM 정지 시 hard-stop 정책
- 전투/장면별 전용 음악 매핑
- 전사의 피리 및 최종전 구성요소와 hook 영역을 분리

일반 사용자는 AIO의 `vgm_bgm` 구성요소로 적용하는 것을 권장합니다. 직접 VGM을 `DS2_xx.MUS`로 변환하려면 `TOOLS/ED2_Raw_OPL_Converter_v0.1.5`를 사용하십시오.

## Music source mode

`patch_music_source_mode.py`는 두 BGM 소스 모드를 제공합니다.

```text
python patch_music_source_mode.py custom C:\ED2
python patch_music_source_mode.py original C:\ED2 --stock-files-root C:\ED2_STOCK_BACKUP\GAME_FILES
python patch_music_source_mode.py status-original C:\ED2
```

`original`은 순정 MUS를 사용하지 않습니다. GKEY의 VGM Carrier 엔진을 유지하고 P02~P27/P29를 번들 원본 VGZ 소스에서 다시 생성합니다. 사용자 추가 교체곡(P06 Surprise.vgm, P26 custom flute, P27 custom final-boss, P29 TITLE, P30 Cannon, P31 throne)은 사용하지 않으며 원래 곡 매핑과 hard-stop/BGM 제어 수정은 유지합니다. 지원되지 않는 음악 상태에서 복구가 필요한 경우에만 검증된 순정 백업을 사용할 수 있습니다.


## v0.5.50 WAIT_BGM one-shot sync

VGM Carrier의 one-shot 곡은 실제 carrier header의 song length와 WAIT_BGM을 동기화합니다. 커스텀 전사의 피리 P26은 436 ticks, 원본 VGZ 전사의 피리 P26은 486 ticks이며 모드 전환 시 자동으로 다시 계산합니다. 반복곡과 BGM OFF에는 대기를 추가하지 않습니다.
