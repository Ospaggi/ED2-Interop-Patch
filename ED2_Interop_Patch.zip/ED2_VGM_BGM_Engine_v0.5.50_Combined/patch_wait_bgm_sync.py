#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, struct, tempfile
from pathlib import Path

VERSION = '0.5.50'
SEG = 86
WAIT_OFF = 0x38E6
WAIT_STOCK = bytes.fromhex('1E 53 C5 1E A8 95 5B 1F CB')
CAVE_OFF = 0x0500
CAVE_MAX = 0x0080
BGM_ENABLED = 0x2047
CURRENT_BGM = 0x3ED6
BGM_WORK_PTR = 0x95A8
FLUTE_LOGICAL = 0x12
P26 = 'DS2_26.MUS'
CARRIER_MAGIC_OFF = 91
CARRIER_MAGIC = 0x5647
CARRIER_TICKS_OFF = 1
LOOP_FIELD_OFF = 21
ONE_SHOT_LOOP_FIELD = 1
BACKUP_DIR = Path('ED2_BACKUP') / 'VGM_WAIT_BGM_SYNC'
MANIFEST = 'manifest.json'

def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def sha(b): return hashlib.sha256(b).hexdigest()

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent)); os.close(fd)
    try: Path(tmp).write_bytes(data); os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def ne_seg(b:bytes,index:int):
    if len(b)<0x40 or b[:2]!=b'MZ': raise RuntimeError('ED2MAIN.EXE가 MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE': raise RuntimeError('ED2MAIN.EXE가 16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c); table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    if not 1<=index<=count: raise RuntimeError('NE86을 찾지 못했습니다.')
    p=table+(index-1)*8; sec,ln,flags,alloc=struct.unpack_from('<HHHH',b,p)
    return p,sec<<shift,(0x10000 if ln==0 else ln),flags,alloc

def carrier_ticks(root:Path)->int:
    p=root/'BGM'/P26
    if not p.is_file(): raise FileNotFoundError(f'BGM/{P26}이 없습니다.')
    b=p.read_bytes()
    if len(b)<95 or u16(b,CARRIER_MAGIC_OFF)!=CARRIER_MAGIC:
        raise RuntimeError(f'BGM/{P26}은 compact VGM carrier가 아닙니다.')
    if u16(b,LOOP_FIELD_OFF)!=ONE_SHOT_LOOP_FIELD:
        raise RuntimeError(f'BGM/{P26}이 one-shot carrier가 아닙니다.')
    ticks=u16(b,CARRIER_TICKS_OFF)
    if not 1<=ticks<0x8000: raise RuntimeError(f'BGM/{P26} carrier_ticks가 비정상입니다: {ticks}')
    return ticks

def build_helper(ticks:int)->bytes:
    # Preserve caller state.  ES retains the original ED2MAIN DGROUP while
    # LDS switches DS:BX to GKEY's shared BGM_WORK structure.
    b=bytearray(); labels={}; fix=[]
    def e(x): b.extend(x)
    def lab(n): labels[n]=len(b)
    def j8(op,n): e(bytes((op,0))); fix.append((len(b)-1,n))
    e(bytes.fromhex('9C 50 53 1E 06'))       # pushf,ax,bx,ds,es
    e(bytes.fromhex('8C D8 8E C0'))          # ES = original DS
    e(bytes.fromhex('80 3E 47 20 00')); j8(0x74,'done')
    e(bytes.fromhex('80 3E D6 3E 12')); j8(0x75,'done')
    e(bytes.fromhex('C5 1E A8 95'))          # DS:BX = BGM_WORK
    lab('loop')
    e(bytes.fromhex('26 80 3E 47 20 00')); j8(0x74,'done')
    e(bytes.fromhex('26 80 3E D6 3E 12')); j8(0x75,'done')
    e(bytes.fromhex('8B 47 02'))             # AX = BGM_WORK clock
    e(b'\x3D'+struct.pack('<H',ticks)); j8(0x72,'loop')
    lab('done')
    e(bytes.fromhex('07 1F 5B 58 9D CB'))
    for pos,n in fix:
        disp=labels[n]-(pos+1)
        if not -128<=disp<=127: raise AssertionError('WAIT_BGM helper rel8 overflow')
        b[pos]=disp&0xff
    return bytes(b)

def entry_for()->bytes:
    disp=(CAVE_OFF-(WAIT_OFF+3)) & 0xffff
    return b'\xE9'+struct.pack('<H',disp)+b'\x90'*6

def classify_bytes(b:bytes,ticks:int):
    _,base,seglen,_,_=ne_seg(b,SEG)
    if WAIT_OFF+len(WAIT_STOCK)>seglen or CAVE_OFF+CAVE_MAX>seglen: return 'unsupported'
    entry=bytes(b[base+WAIT_OFF:base+WAIT_OFF+9]); cave=bytes(b[base+CAVE_OFF:base+CAVE_OFF+CAVE_MAX])
    helper=build_helper(ticks)
    if entry==entry_for() and cave[:len(helper)]==helper and cave[len(helper):]==b'\0'*(CAVE_MAX-len(helper)):
        return 'patched'
    if entry==WAIT_STOCK and cave==b'\0'*CAVE_MAX:
        return 'disabled'
    return 'unsupported'

def patch_bytes(b:bytes,ticks:int)->bytes:
    state=classify_bytes(b,ticks)
    if state=='patched': return b
    _,base,_,_,_=ne_seg(b,SEG)
    # Accept a disabled slot or an older v0.5.50 helper whose only dynamic
    # field was carrier_ticks.  Never overwrite unrelated cave code.
    entry=bytes(b[base+WAIT_OFF:base+WAIT_OFF+9]); cave=bytes(b[base+CAVE_OFF:base+CAVE_OFF+CAVE_MAX])
    if entry!=WAIT_STOCK:
        # previous own entry is identical across tick changes
        if entry!=entry_for(): raise RuntimeError('WAIT_BGM entry가 지원하지 않는 상태입니다.')
        # Require recognizable own helper framing before replacing ticks.
        if not (cave.startswith(bytes.fromhex('9C 50 53 1E 06 8C D8 8E C0')) and cave[0x33:0x39]==bytes.fromhex('07 1F 5B 58 9D CB')):
            raise RuntimeError('NE86:0500이 다른 코드에 사용 중입니다.')
    elif cave!=b'\0'*CAVE_MAX:
        raise RuntimeError('NE86:0500 WAIT_BGM 예약 영역이 비어 있지 않습니다.')
    x=bytearray(b); h=build_helper(ticks)
    x[base+CAVE_OFF:base+CAVE_OFF+CAVE_MAX]=h+b'\0'*(CAVE_MAX-len(h))
    x[base+WAIT_OFF:base+WAIT_OFF+9]=entry_for()
    out=bytes(x)
    if classify_bytes(out,ticks)!='patched': raise RuntimeError('WAIT_BGM sync 적용 후 검증 실패')
    return out

def disable_bytes(b:bytes)->bytes:
    _,base,seglen,_,_=ne_seg(b,SEG)
    if WAIT_OFF+9>seglen or CAVE_OFF+CAVE_MAX>seglen: raise RuntimeError('NE86 layout unsupported')
    entry=bytes(b[base+WAIT_OFF:base+WAIT_OFF+9]); cave=bytes(b[base+CAVE_OFF:base+CAVE_OFF+CAVE_MAX])
    if entry==WAIT_STOCK and cave==b'\0'*CAVE_MAX: return b
    if entry!=entry_for() or not cave.startswith(bytes.fromhex('9C 50 53 1E 06 8C D8 8E C0')):
        raise RuntimeError('WAIT_BGM sync 소유 상태가 아니므로 비활성화하지 않습니다.')
    x=bytearray(b); x[base+WAIT_OFF:base+WAIT_OFF+9]=WAIT_STOCK; x[base+CAVE_OFF:base+CAVE_OFF+CAVE_MAX]=b'\0'*CAVE_MAX
    return bytes(x)

def root_of(x=None)->Path:
    r=Path(x or '.').resolve()
    if not (r/'ED2MAIN.EXE').is_file(): raise FileNotFoundError('ED2MAIN.EXE가 있는 게임 폴더를 지정하십시오.')
    return r

def _backup(root:Path,before:bytes):
    d=root/BACKUP_DIR; d.mkdir(parents=True,exist_ok=True); m=d/MANIFEST
    if not m.exists():
        (d/'ED2MAIN.EXE').write_bytes(before)
        m.write_text(json.dumps({'version':VERSION,'sha256':sha(before)},ensure_ascii=False,indent=2),encoding='utf-8')

def apply(root=None):
    r=root_of(root); ticks=carrier_ticks(r); p=r/'ED2MAIN.EXE'; before=p.read_bytes(); out=patch_bytes(before,ticks)
    if out!=before: _backup(r,before); atomic(p,out)
    print(f'VGM WAIT_BGM sync v{VERSION} 적용 완료: L12/P26 one-shot {ticks} ticks')
    return {'ok':True,'ticks':ticks,'state':classify_bytes(out,ticks)}

def disable(root=None):
    r=root_of(root); p=r/'ED2MAIN.EXE'; before=p.read_bytes(); out=disable_bytes(before)
    if out!=before: atomic(p,out)
    print('VGM WAIT_BGM sync 비활성화: 순정 WAIT_BGM no-op 복원')
    return {'ok':True,'state':'disabled'}

def restore(root=None):
    r=root_of(root); d=r/BACKUP_DIR; m=d/MANIFEST
    if not m.is_file() or not (d/'ED2MAIN.EXE').is_file(): raise FileNotFoundError('WAIT_BGM sync 백업이 없습니다.')
    meta=json.loads(m.read_text('utf-8')); b=(d/'ED2MAIN.EXE').read_bytes()
    if sha(b)!=meta['sha256']: raise RuntimeError('WAIT_BGM sync 백업 SHA 불일치')
    atomic(r/'ED2MAIN.EXE',b); print('WAIT_BGM sync 적용 직전 ED2MAIN으로 복원했습니다.')

def status(root=None):
    r=root_of(root)
    try: ticks=carrier_ticks(r)
    except Exception as e: ticks=None
    b=(r/'ED2MAIN.EXE').read_bytes()
    st=classify_bytes(b,ticks) if ticks is not None else ('disabled' if bytes(b[ne_seg(b,SEG)[1]+WAIT_OFF:ne_seg(b,SEG)[1]+WAIT_OFF+9])==WAIT_STOCK else 'unsupported')
    obj={'version':VERSION,'state':st,'carrier_ticks':ticks,'flute_logical':FLUTE_LOGICAL,'cave':'86:0500','wait_bgm':'86:38E6'}
    print(json.dumps(obj,ensure_ascii=False,indent=2)); return obj

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['apply','disable','restore','status']); ap.add_argument('game_root',nargs='?',default='.')
    a=ap.parse_args()
    try: {'apply':apply,'disable':disable,'restore':restore,'status':status}[a.action](a.game_root); return 0
    except Exception as e: print(f'[ERROR] {type(e).__name__}: {e}'); return 1
if __name__=='__main__': raise SystemExit(main())
