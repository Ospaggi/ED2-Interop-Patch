# ED2 Interop Patch Pack

한국 DOS판 **《Dragon Slayer: The Legend of Heroes II / 영웅전설 II》** 종합 개선 패치입니다.

현재 기준 버전은 **v1.4.69**입니다. v1.4.68의 최종 게임 payload는 유지하면서, 최종전 구성요소를 하나로 통합하고 실제 순정/구버전 설치 검증을 다시 완료한 정리 릴리스입니다.

## v1.4.69 핵심 변경

### Final Battle 구성요소 통합
- `ED2_Final_Battle_Presentation_Fix_v0.18.19_Sindy_Branch`와 `ED2_Final_Battle_Runtime_v1.0.0`을 **`ED2_Final_Battle_Fix_v0.19.0`** 하나로 통합했습니다.
- 기존 Runtime에 들어 있던 완성 `M_500.DLL`, `M_501.DLL`, `M_502.DLL`, `C_734.DLL` 배포 방식은 폐기했습니다.
- 이제 지원되는 원본/중간 DLL의 SHA와 기존 바이트를 검증한 뒤 **32개 검증 hunk만 직접 적용**합니다.
- unknown/mixed/custom 상태는 파일을 쓰기 전에 중단합니다.

### 최종전 확정값
- 신디: 완전 AI, 드래곤의 검, 갑옷/방패 없음, DEF **300**, 주문능력(INT2) **3000**
- 신디 화염의 브레스: 기존 30% 공식에 따라 **900**
- 고드윈 1차 평타 실효 ATT **1200**
- 고드윈 2차 평타 실효 ATT **1400**
- 고드윈 2차 연속공격 **175/타**, Late Skill **537**
- 가비: logical ATT **3000**, 3회 공격 실효 ATT **800**, SPD **120**
- 레이시아 물리 bridge와 전사의 피리/P26 성공 경로 유지

## 설치

권장 실행 파일:

```text
ED2_All_In_One_Patcher_v1.4.69\run_all_in_one.bat
```

Python 직접 실행:

```text
python ED2_All_In_One_Patcher_v1.4.69/ed2_all_in_one_patcher.py "C:\ED2" --apply-all --no-gui
```

정확한 순정 한국 DOS판과 지원되는 이전 정식판에서 적용할 수 있습니다.

## 검증
- 사용자 제공 실제 순정: **1041/1041 exact SHA**, missing 0, mismatch 0
- 실제 순정 → v1.4.69 전체 적용: **RC 0**, 최종 **1049/1049**, missing 0, mismatch 0
- v1.4.67 → v1.4.69 직접 업그레이드: **4개 파일 변경**, 최종 **1049/1049**
- 즉시 재적용: **changed_files 0 / already-current**
- Final Battle Fix 단독: source 4파일 → target 4파일 exact SHA, 재적용 PASS, 변조 입력 fail-closed

## 중요 정책
- **SAVE는 검색·수정·백업·manifest 대상이 아닙니다.**
- `ED2.SWP`는 generation 판정에서 무시합니다.
- 알 수 없는/custom 바이너리를 추측해서 덮어쓰지 않습니다.
- 정적 검증보다 실제 DOSBox 런타임 결과를 우선합니다.

## 주요 구성요소
- `ED2_All_In_One_Patcher_v1.4.69/`
- `ED2_Final_Battle_Fix_v0.19.0/`
- `ED2_Text_and_Dialogue_v5.0R17_Combined/`
- `ED2_VGM_BGM_Engine_v0.5.50_Combined/`
- `ED2_Soldiers_Flute_BGM_Fix_v0.3.7/`
- `ED2_Monster_Text_Tool_v0.2.14/`
- `ED2_Joshua_Scrollable_Underground_Map_v1.3.3/`
- `ED2_Late_Game_Skill_Scaling_v0.2.0/`

## 라이선스
프로젝트 소스와 문서는 루트 `LICENSE`의 MIT License를 따릅니다. 게임 원본 파일은 별도로 준비해야 합니다.
