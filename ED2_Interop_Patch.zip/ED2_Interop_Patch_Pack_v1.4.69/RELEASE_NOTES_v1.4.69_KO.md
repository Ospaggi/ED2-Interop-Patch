# ED2 Interop Patch Pack v1.4.69

## 변경 사항
- Final Battle Presentation v0.18.19 + Final Battle Runtime v1.0.0을 **ED2_Final_Battle_Fix_v0.19.0**으로 통합.
- Runtime에 번들되던 M_500/M_501/M_502/C_734 완성 DLL 4개 제거.
- 최종전 DLL은 exact source SHA + 32개 old-byte hunk를 확인한 뒤 직접 패치.
- AIO 공개 component key를 `final_battle_fix`로 정리.
- v1.4.68의 게임 payload와 최종 전투 수치는 그대로 유지.
- 사용자 제공 상세 변경점 TXT에 장 제목/요슈아 지도/후반 기술·최종전 항목을 간단히 보완.

## 실제 설치 검증
- 사용자 제공 순정 archive: 1041/1041 exact.
- 순정 → v1.4.69: RC 0, 1049/1049 current.
- v1.4.67 → v1.4.69: changed 4, 1049/1049 current.
- current 재적용: changed 0.
- Final Battle Fix 변조 입력: 쓰기 전 fail-closed.

## 정책
- SAVE 비대상.
- ED2.SWP generation 판정에서 무시.
- M_504.DLL은 한국 DOS판에서 빠진 실제 전투 모듈 복원이므로 유지.
