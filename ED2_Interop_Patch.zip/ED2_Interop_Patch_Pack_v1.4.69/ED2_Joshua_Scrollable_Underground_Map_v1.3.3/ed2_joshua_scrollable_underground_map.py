#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import struct
import sys
from dataclasses import dataclass
from pathlib import Path

VERSION = "1.3.3"
TARGET_NAME = "ED2MAIN.EXE"
SEGMENT_NO = 86

SCROLL_CAVE_START = 0x1000
SCROLL_HELPER_NAME = "scrollmap_helper.bin"
LEGACY_FULLMAP_NAME = "legacy_fullmap_helper_v1.0.0.bin"
SPEED_CAVE_START = 0x1200
SPEED_HELPER_NAME = "render_speed.bin"
LEGACY_RENDER_NAME = "legacy_render_fast_v1.5.0.bin"
LEGACY_ATOMIC_NAME = "legacy_atomic_map_v1.6.0.bin"
OLD_V131_SPEED = bytes.fromhex("51558b4efc368b2c83e57fd1e53e8b9e12b601d3368b6c4083e57fd1e53e8bae12b601d581fde84f734d2e8e063ab83e8a46010a0726880583c50883c3082e8e063cb83e8a46010a0726880583c50883c3082e8e063eb83e8a46010a0726880583c50883c3082e8e0640b83e8a46010a07268805e9860081fd0050725c1e2ea124b88ed881ed005081eb00502e8e063ab83e8a46010a0726880583c50883c3082e8e063cb83e8a46010a0726880583c50883c3082e8e063eb83e8a46010a0726880583c50883c3082e8e0640b83e8a46010a072688051feb245689ee2ea13ab80ee8a2932ea13cb80ee89a932ea13eb80ee892932ea140b80ee88a935e81c6800047497403e9fdfe5d59cb00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008b46fed1e889ca29c2f6c1017502f7da85d279030356fe89d0e91093")

# Stock ED2MAIN segment-86 addresses.
MG_YOSYUA_RELOC_SOURCE = 0x8235
MG_DISP_MAP = 0xA182
FIELD_UNPACK = 0x831B
MAP_MOVE_UNPACK_RELOC_SOURCE = 0xA219
MAP_EXIT_UNPACK_RELOC_SOURCE = 0xA22D

# Scroll helper entries at 86:1000 (same helper as stable v1.3.0).
JOSHUA_ENTRY = 0x1000
COORD_UPDATE_DISPATCH = 0x10D3
AUX_COORD_UPDATE_DISPATCH = 0x111A
MAP_UNPACK_DISPATCH = 0x1126

# Direct near-call patch sites in MG_DISP_MAP.
COORD_CALL_SITE = 0xA20C
AUX_COORD_CALL_SITE = 0xA213
ORIGINAL_COORD_CALL = bytes.fromhex("e8 78 01")
ORIGINAL_AUX_COORD_CALL = bytes.fromhex("e8 71 01")

# Exact original MG_YOSYUA body. Only existing relocation targets are redirected.
MG_YOSYUA_OFF = 0x8229
EXPECTED_MG_YOSYUA = bytes.fromhex(
    "bb 01 1e b4 03 cd 40 22 d2 75 05 ea ff ff 00 00 "
    "b0 23 9a ff ff 00 00 eb 00"
)

# v1.2.0 touched unrelated/status-path timing immediates. v1.3.x restores them.
JOSHUA_OPEN_DELAY_SITE = 0x8239
JOSHUA_OPEN_DELAY_ORIG = bytes.fromhex("b0 23")
JOSHUA_OPEN_DELAY_V12 = bytes.fromhex("b0 08")
JOSHUA_FX_DELAY_SITE = 0x80F2
JOSHUA_FX_DELAY_ORIG = bytes.fromhex("c6 06 43 3f 0a")
JOSHUA_FX_DELAY_V12 = bytes.fromhex("c6 06 43 3f 02")

# v1.3.0 reveal pacing patch: retain all rendering but bypass the periodic timer wait.
MAP_REVEAL_WAIT_BRANCH_SITE = 0xA637
MAP_REVEAL_WAIT_BRANCH_ORIG = bytes.fromhex("75 05")
MAP_REVEAL_WAIT_BRANCH_FAST = bytes.fromhex("eb 05")

# v1.4.0 migration state: center-out ordering was replaced in-place.
MAP_REVEAL_ORDER_SITE = 0xA646
MAP_REVEAL_ORDER_ORIG = bytes.fromhex(
    "8b 46 fe d1 e8 f7 c1 01 00 75 0c 03 46 fe 2b c1 73 0c "
    "03 46 fe eb 07 8b d1 92 2b c2 72 f4 3b 46 fe 72 03 2b 46 fe"
)
MAP_REVEAL_ORDER_NONE = bytes.fromhex("8b 46 fe 2b c1") + (b"\x90" * 33)

# v1.5.0 migration state: four A686 calls were replaced with one helper call.
LEGACY_RENDER_CAVE_START = 0x1200
LEGACY_RENDER_GROUP_SITE = 0xA607
LEGACY_RENDER_GROUP_ORIG = bytes.fromhex(
    "2e a1 3a b8 0e e8 77 00 2e a1 3c b8 0e e8 6f 00 "
    "2e a1 3e b8 0e e8 67 00 2e a1 40 b8 0e e8 5f 00"
)

# v1.6.0 migration state: hidden-page atomic map wrapper.
LEGACY_ATOMIC_CAVE_START = 0x1300
INITIAL_FLIP_RELOC_SOURCE = 0xA1D8
INITIAL_FLIP_TARGET_ORIG = 0x2F3C
INITIAL_FLIP_TARGET_ATOMIC = 0x1320
MAP_RENDER_CALL_SITE = 0xA1EB

# v1.3.1 introduced an unsafe whole-row renderer. v1.3.2 recognizes it only
# for migration/rollback. The stable v1.3.0 reveal-index path is restored.
REVEAL_CALL_SITE = 0xA5E0
REVEAL_ORIG_TARGET = 0xA646
REVEAL_FAST_TARGET = 0x1340
ROW_DISPATCH_SITE = 0xA5E3
ROW_FAST_TARGET = 0x1200
ROW_CONTINUE = 0xA632
ROW_DISPATCH_ORIG = bytes.fromhex("55 52 51 8b 4e fc 56")

SUPPORTED_BASE_SHA256 = {
    "9574c7e553ee4fd4d2fc5eea981a24ffe1fb0f1a22d14cf22b9d5b05b7b59ca5": "retail-stock",
    "83386cf8bf1786947ace729909b1669fa42d389db12f991b21392edb1ca5c92b": "interop-v1.4.52-current",
    "5e11bafd6f14c9e02970ef8ee5493416897694e2acac106b80b6fa1b2d85c033": "interop-v1.4.56-current-pre-joshua",
    "3a39ebde32d51386258d54ee6bb1ac461250073d7b0c77c39d3ac8e81bf9d8ab": "interop-v1.4.67-current-pre-joshua",
}


class PatchError(RuntimeError):
    pass


@dataclass(frozen=True)
class Segment:
    file_offset: int
    length: int
    flags: int
    min_alloc: int


def sha256(data: bytes | bytearray) -> str:
    return hashlib.sha256(bytes(data)).hexdigest()


def near_call_bytes(source: int, target: int) -> bytes:
    disp = (target - (source + 3)) & 0xFFFF
    return b"\xE8" + struct.pack("<H", disp)


def near_jmp_bytes(source: int, target: int) -> bytes:
    disp = (target - (source + 3)) & 0xFFFF
    return b"\xE9" + struct.pack("<H", disp)


NEW_COORD_CALL = near_call_bytes(COORD_CALL_SITE, COORD_UPDATE_DISPATCH)
NEW_AUX_COORD_CALL = near_call_bytes(AUX_COORD_CALL_SITE, AUX_COORD_UPDATE_DISPATCH)
ORIGINAL_REVEAL_CALL = near_call_bytes(REVEAL_CALL_SITE, REVEAL_ORIG_TARGET)
FAST_REVEAL_CALL = near_call_bytes(REVEAL_CALL_SITE, REVEAL_FAST_TARGET)
FAST_ROW_DISPATCH = (
    b"\x0E"
    + near_call_bytes(ROW_DISPATCH_SITE + 1, ROW_FAST_TARGET)
    + near_jmp_bytes(ROW_DISPATCH_SITE + 4, ROW_CONTINUE)
)
ORIGINAL_MAP_RENDER_CALL = near_call_bytes(MAP_RENDER_CALL_SITE, 0xA5BC)
ATOMIC_MAP_RENDER_CALL = near_call_bytes(MAP_RENDER_CALL_SITE, 0x1300)

# v1.5.0 exact patch bytes, used only to recognize and safely migrate that state.
LEGACY_RENDER_GROUP_FAST = (
    b"\x0E"
    + near_call_bytes(LEGACY_RENDER_GROUP_SITE + 1, LEGACY_RENDER_CAVE_START)
    + (b"\x90" * (len(LEGACY_RENDER_GROUP_ORIG) - 4))
)


def parse_segments(data: bytes | bytearray) -> list[Segment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise PatchError("ED2MAIN.EXE가 MZ 실행 파일이 아닙니다.")
    ne = struct.unpack_from("<I", data, 0x3C)[0]
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise PatchError("ED2MAIN.EXE가 16-bit NE 실행 파일이 아닙니다.")
    count = struct.unpack_from("<H", data, ne + 0x1C)[0]
    table = ne + struct.unpack_from("<H", data, ne + 0x22)[0]
    shift = struct.unpack_from("<H", data, ne + 0x32)[0]
    out: list[Segment] = []
    for i in range(count):
        sector, raw_len, flags, raw_alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        out.append(Segment(
            sector << shift,
            0x10000 if raw_len == 0 else raw_len,
            flags,
            0x10000 if raw_alloc == 0 else raw_alloc,
        ))
    return out


def relocation_records(data: bytes | bytearray, seg: Segment) -> list[tuple[int, int, int, int, int, int]]:
    if not (seg.flags & 0x0100):
        raise PatchError("ED2MAIN segment 86에 relocation table이 없습니다.")
    pos = seg.file_offset + seg.length
    if pos + 2 > len(data):
        raise PatchError("segment 86 relocation table이 잘렸습니다.")
    count = struct.unpack_from("<H", data, pos)[0]
    pos += 2
    rows = []
    for i in range(count):
        entry = pos + i * 8
        if entry + 8 > len(data):
            raise PatchError("segment 86 relocation record가 잘렸습니다.")
        source_type, flags, source, target1, target2 = struct.unpack_from("<BBHHH", data, entry)
        rows.append((entry, source_type, flags, source, target1, target2))
    return rows


def find_relocation(data: bytes | bytearray, seg: Segment, source: int) -> tuple[int, int]:
    hits = [row for row in relocation_records(data, seg) if row[3] == source]
    if len(hits) != 1:
        raise PatchError(f"relocation source 86:{source:04X}가 {len(hits)}개입니다.")
    entry, source_type, flags, _, target1, target2 = hits[0]
    if source_type != 0x03 or flags != 0x00 or target1 != SEGMENT_NO:
        raise PatchError(
            f"relocation 86:{source:04X} 형식이 지원 상태와 다릅니다: "
            f"type={source_type:02X}, flags={flags:02X}, target_segment={target1}"
        )
    return entry, target2


def load_helpers(script_dir: Path) -> tuple[bytes, bytes, bytes, bytes, bytes]:
    helper = (script_dir / SCROLL_HELPER_NAME).read_bytes()
    legacy_fullmap = (script_dir / LEGACY_FULLMAP_NAME).read_bytes()
    speed = (script_dir / SPEED_HELPER_NAME).read_bytes()
    legacy_render = (script_dir / LEGACY_RENDER_NAME).read_bytes()
    legacy_atomic = (script_dir / LEGACY_ATOMIC_NAME).read_bytes()
    if not helper or len(helper) > 0x700:
        raise PatchError(f"{SCROLL_HELPER_NAME} 크기가 비정상입니다: {len(helper)}")
    if not legacy_fullmap or len(legacy_fullmap) > len(helper):
        raise PatchError(f"{LEGACY_FULLMAP_NAME} 크기가 비정상입니다: {len(legacy_fullmap)}")
    if not speed or len(speed) > 0x500:
        raise PatchError(f"{SPEED_HELPER_NAME} 크기가 비정상입니다: {len(speed)}")
    if not legacy_render or len(legacy_render) > len(speed):
        raise PatchError(f"{LEGACY_RENDER_NAME} 크기가 비정상입니다: {len(legacy_render)}")
    if not legacy_atomic or (LEGACY_ATOMIC_CAVE_START - SPEED_CAVE_START + len(legacy_atomic)) > len(speed):
        raise PatchError(f"{LEGACY_ATOMIC_NAME} 크기가 비정상입니다: {len(legacy_atomic)}")
    if SPEED_CAVE_START + len(speed) > REVEAL_FAST_TARGET + 0x40:
        raise PatchError("render_speed.bin 배치가 예상 범위를 벗어났습니다.")
    return helper, legacy_fullmap, speed, legacy_render, legacy_atomic


def _legacy_speed_regions(speed_len: int, legacy_render: bytes, legacy_atomic: bytes) -> tuple[bytes, bytes, bytes]:
    zero = b"\x00" * speed_len
    v15 = bytearray(zero)
    v15[:len(legacy_render)] = legacy_render
    v16 = bytearray(v15)
    off = LEGACY_ATOMIC_CAVE_START - SPEED_CAVE_START
    v16[off:off + len(legacy_atomic)] = legacy_atomic
    return zero, bytes(v15), bytes(v16)


def structural_state(
    data: bytes | bytearray,
    helper: bytes,
    legacy_fullmap: bytes,
    speed: bytes,
    legacy_render: bytes,
    legacy_atomic: bytes,
) -> dict[str, object]:
    segs = parse_segments(data)
    if len(segs) < SEGMENT_NO:
        raise PatchError("ED2MAIN.EXE에 segment 86이 없습니다.")
    seg = segs[SEGMENT_NO - 1]
    if seg.length < 0xB844 or seg.min_alloc < 0xB844:
        raise PatchError(
            f"segment 86 geometry가 지원 상태보다 작습니다: len={seg.length:04X}, alloc={seg.min_alloc:04X}"
        )
    code = data[seg.file_offset:seg.file_offset + seg.length]

    mg = bytearray(code[MG_YOSYUA_OFF:MG_YOSYUA_OFF + len(EXPECTED_MG_YOSYUA)])
    rel_open = JOSHUA_OPEN_DELAY_SITE - MG_YOSYUA_OFF
    if bytes(mg[rel_open:rel_open + len(JOSHUA_OPEN_DELAY_V12)]) == JOSHUA_OPEN_DELAY_V12:
        mg[rel_open:rel_open + len(JOSHUA_OPEN_DELAY_ORIG)] = JOSHUA_OPEN_DELAY_ORIG
    if bytes(mg) != EXPECTED_MG_YOSYUA:
        raise PatchError("MG_YOSYUA 본체 바이트가 지원 상태와 다릅니다.")

    open_delay = bytes(code[JOSHUA_OPEN_DELAY_SITE:JOSHUA_OPEN_DELAY_SITE + len(JOSHUA_OPEN_DELAY_ORIG)])
    fx_delay = bytes(code[JOSHUA_FX_DELAY_SITE:JOSHUA_FX_DELAY_SITE + len(JOSHUA_FX_DELAY_ORIG)])
    if open_delay not in (JOSHUA_OPEN_DELAY_ORIG, JOSHUA_OPEN_DELAY_V12):
        raise PatchError("요슈아 시작 연출 대기 바이트가 지원 상태와 다릅니다.")
    if fx_delay not in (JOSHUA_FX_DELAY_ORIG, JOSHUA_FX_DELAY_V12):
        raise PatchError("요슈아 내부 연출 대기 바이트가 지원 상태와 다릅니다.")
    timing_state = (
        "v1.2-fast-wrong-path" if open_delay == JOSHUA_OPEN_DELAY_V12 and fx_delay == JOSHUA_FX_DELAY_V12
        else "stock" if open_delay == JOSHUA_OPEN_DELAY_ORIG and fx_delay == JOSHUA_FX_DELAY_ORIG
        else "mixed"
    )

    reveal_branch = bytes(code[MAP_REVEAL_WAIT_BRANCH_SITE:MAP_REVEAL_WAIT_BRANCH_SITE + 2])
    if reveal_branch not in (MAP_REVEAL_WAIT_BRANCH_ORIG, MAP_REVEAL_WAIT_BRANCH_FAST):
        raise PatchError("MG_DISP_MAP 지도 펼침 대기 분기 바이트가 지원 상태와 다릅니다.")
    reveal_wait_state = "fast" if reveal_branch == MAP_REVEAL_WAIT_BRANCH_FAST else "stock"

    reveal_order = bytes(code[MAP_REVEAL_ORDER_SITE:MAP_REVEAL_ORDER_SITE + len(MAP_REVEAL_ORDER_ORIG)])
    if reveal_order not in (MAP_REVEAL_ORDER_ORIG, MAP_REVEAL_ORDER_NONE):
        raise PatchError("MG_DISP_MAP 지도 펼침 순서 코드가 지원 상태와 다릅니다.")
    reveal_order_state = "none" if reveal_order == MAP_REVEAL_ORDER_NONE else "stock"

    legacy_render_group = bytes(code[LEGACY_RENDER_GROUP_SITE:LEGACY_RENDER_GROUP_SITE + len(LEGACY_RENDER_GROUP_ORIG)])
    if legacy_render_group not in (LEGACY_RENDER_GROUP_ORIG, LEGACY_RENDER_GROUP_FAST):
        raise PatchError("MG_DISP_MAP legacy 4-plane 렌더 패치 위치가 지원 상태와 다릅니다.")
    legacy_render_group_state = "fast4" if legacy_render_group == LEGACY_RENDER_GROUP_FAST else "stock"

    reveal_call = bytes(code[REVEAL_CALL_SITE:REVEAL_CALL_SITE + 3])
    if reveal_call not in (ORIGINAL_REVEAL_CALL, FAST_REVEAL_CALL):
        raise PatchError("MG_DISP_MAP reveal-index call이 지원 상태와 다릅니다.")
    row_dispatch = bytes(code[ROW_DISPATCH_SITE:ROW_DISPATCH_SITE + len(ROW_DISPATCH_ORIG)])
    if row_dispatch not in (ROW_DISPATCH_ORIG, FAST_ROW_DISPATCH):
        raise PatchError("MG_DISP_MAP row-render dispatch가 지원 상태와 다릅니다.")

    if SCROLL_CAVE_START + len(helper) > len(code) or SPEED_CAVE_START + len(speed) > len(code):
        raise PatchError("segment 86 helper cave가 너무 작습니다.")
    scroll_cave = bytes(code[SCROLL_CAVE_START:SCROLL_CAVE_START + len(helper)])
    scroll_zero = b"\x00" * len(helper)
    legacy_scroll = legacy_fullmap + b"\x00" * (len(helper) - len(legacy_fullmap))
    speed_cave = bytes(code[SPEED_CAVE_START:SPEED_CAVE_START + len(speed)])
    speed_zero, legacy_v15_speed, legacy_v16_speed = _legacy_speed_regions(len(speed), legacy_render, legacy_atomic)
    if speed_cave not in (speed_zero, legacy_v15_speed, legacy_v16_speed, speed, OLD_V131_SPEED):
        raise PatchError("segment 86 render-speed cave가 알 수 없는/custom 상태입니다.")

    y_entry, y_target = find_relocation(data, seg, MG_YOSYUA_RELOC_SOURCE)
    m_entry, m_target = find_relocation(data, seg, MAP_MOVE_UNPACK_RELOC_SOURCE)
    x_entry, x_target = find_relocation(data, seg, MAP_EXIT_UNPACK_RELOC_SOURCE)
    initial_flip_entry, initial_flip_target = find_relocation(data, seg, INITIAL_FLIP_RELOC_SOURCE)
    if initial_flip_target not in (INITIAL_FLIP_TARGET_ORIG, INITIAL_FLIP_TARGET_ATOMIC):
        raise PatchError("MG_DISP_MAP 초기 page-flip relocation이 지원 상태와 다릅니다.")

    map_render_call = bytes(code[MAP_RENDER_CALL_SITE:MAP_RENDER_CALL_SITE + 3])
    if map_render_call not in (ORIGINAL_MAP_RENDER_CALL, ATOMIC_MAP_RENDER_CALL):
        raise PatchError("MG_DISP_MAP render call이 지원 상태와 다릅니다.")
    coord = bytes(code[COORD_CALL_SITE:COORD_CALL_SITE + 3])
    aux = bytes(code[AUX_COORD_CALL_SITE:AUX_COORD_CALL_SITE + 3])

    common_scroll = (
        scroll_cave == helper
        and y_target == JOSHUA_ENTRY
        and m_target == MAP_UNPACK_DISPATCH
        and x_target == MAP_UNPACK_DISPATCH
        and coord == NEW_COORD_CALL
        and aux == NEW_AUX_COORD_CALL
    )
    legacy_display_stock = (
        reveal_order_state == "stock"
        and legacy_render_group_state == "stock"
        and initial_flip_target == INITIAL_FLIP_TARGET_ORIG
        and map_render_call == ORIGINAL_MAP_RENDER_CALL
        and reveal_call == ORIGINAL_REVEAL_CALL
        and row_dispatch == ROW_DISPATCH_ORIG
    )

    if (
        scroll_cave == scroll_zero and speed_cave == speed_zero
        and y_target == MG_DISP_MAP and m_target == FIELD_UNPACK and x_target == FIELD_UNPACK
        and coord == ORIGINAL_COORD_CALL and aux == ORIGINAL_AUX_COORD_CALL
        and timing_state == "stock" and reveal_wait_state == "stock" and legacy_display_stock
    ):
        state = "unpatched"
    elif (
        scroll_cave == legacy_scroll and speed_cave == speed_zero
        and y_target == JOSHUA_ENTRY and m_target == FIELD_UNPACK and x_target == FIELD_UNPACK
        and coord == ORIGINAL_COORD_CALL and aux == ORIGINAL_AUX_COORD_CALL
        and timing_state == "stock" and reveal_wait_state == "stock" and legacy_display_stock
    ):
        state = "legacy-v1.0.0"
    elif common_scroll and speed_cave == speed_zero and timing_state == "stock" and reveal_wait_state == "stock" and legacy_display_stock:
        state = "patched-v1.1.0"
    elif common_scroll and speed_cave == speed_zero and timing_state == "v1.2-fast-wrong-path" and reveal_wait_state == "stock" and legacy_display_stock:
        state = "patched-v1.2.0"
    elif common_scroll and speed_cave == speed_zero and timing_state == "stock" and reveal_wait_state == "fast" and legacy_display_stock:
        state = "patched-v1.3.0"
    elif (
        common_scroll and speed_cave == speed_zero and timing_state == "stock" and reveal_wait_state == "fast"
        and reveal_order_state == "none" and legacy_render_group_state == "stock"
        and initial_flip_target == INITIAL_FLIP_TARGET_ORIG and map_render_call == ORIGINAL_MAP_RENDER_CALL
        and reveal_call == ORIGINAL_REVEAL_CALL and row_dispatch == ROW_DISPATCH_ORIG
    ):
        state = "patched-v1.4.0"
    elif (
        common_scroll and speed_cave == legacy_v15_speed and timing_state == "stock" and reveal_wait_state == "fast"
        and reveal_order_state == "none" and legacy_render_group_state == "fast4"
        and initial_flip_target == INITIAL_FLIP_TARGET_ORIG and map_render_call == ORIGINAL_MAP_RENDER_CALL
        and reveal_call == ORIGINAL_REVEAL_CALL and row_dispatch == ROW_DISPATCH_ORIG
    ):
        state = "patched-v1.5.0"
    elif (
        common_scroll and speed_cave == legacy_v16_speed and timing_state == "stock" and reveal_wait_state == "fast"
        and reveal_order_state == "none" and legacy_render_group_state == "fast4"
        and initial_flip_target == INITIAL_FLIP_TARGET_ATOMIC and map_render_call == ATOMIC_MAP_RENDER_CALL
        and reveal_call == ORIGINAL_REVEAL_CALL and row_dispatch == ROW_DISPATCH_ORIG
    ):
        state = "patched-v1.6.0"
    elif (
        common_scroll and speed_cave == OLD_V131_SPEED and timing_state == "stock" and reveal_wait_state == "fast"
        and reveal_order_state == "stock" and legacy_render_group_state == "stock"
        and initial_flip_target == INITIAL_FLIP_TARGET_ORIG and map_render_call == ORIGINAL_MAP_RENDER_CALL
        and reveal_call == FAST_REVEAL_CALL and row_dispatch == FAST_ROW_DISPATCH
    ):
        state = "patched-v1.3.1-broken-render"
    elif (
        common_scroll and speed_cave == speed and timing_state == "stock" and reveal_wait_state == "fast"
        and reveal_order_state == "stock" and legacy_render_group_state == "fast4"
        and initial_flip_target == INITIAL_FLIP_TARGET_ORIG and map_render_call == ORIGINAL_MAP_RENDER_CALL
        and reveal_call == ORIGINAL_REVEAL_CALL and row_dispatch == ROW_DISPATCH_ORIG
    ):
        state = "patched-v1.3.2"
    else:
        state = "unknown"

    return {
        "state": state,
        "segment": seg,
        "y_entry": y_entry,
        "move_entry": m_entry,
        "exit_entry": x_entry,
        "initial_flip_entry": initial_flip_entry,
        "y_target": y_target,
        "move_target": m_target,
        "exit_target": x_target,
        "initial_flip_target": initial_flip_target,
        "coord_call": coord.hex(" "),
        "aux_coord_call": aux.hex(" "),
        "timing_state": timing_state,
        "reveal_wait_state": reveal_wait_state,
        "reveal_branch_bytes": reveal_branch.hex(" "),
        "reveal_order_state": reveal_order_state,
        "legacy_render_group_state": legacy_render_group_state,
        "reveal_call": reveal_call.hex(" "),
        "row_dispatch": row_dispatch.hex(" "),
        "map_render_call": map_render_call.hex(" "),
        "scroll_cave_sha256": sha256(scroll_cave),
        "speed_cave_sha256": sha256(speed_cave),
        "scroll_helper_size": len(helper),
        "speed_helper_size": len(speed),
    }


def normalize(
    data: bytes,
    helper: bytes,
    legacy_fullmap: bytes,
    speed: bytes,
    legacy_render: bytes,
    legacy_atomic: bytes,
) -> tuple[bytes, str, str, str]:
    info = structural_state(data, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    state = str(info["state"])
    if state == "unknown":
        raise PatchError("요슈아 지도 패치 위치가 알 수 없는/custom 상태입니다. 덮어쓰지 않습니다.")

    out = bytearray(data)
    seg: Segment = info["segment"]  # type: ignore[assignment]

    if state != "unpatched":
        out[seg.file_offset + SCROLL_CAVE_START:seg.file_offset + SCROLL_CAVE_START + len(helper)] = b"\x00" * len(helper)
        struct.pack_into("<H", out, int(info["y_entry"]) + 6, MG_DISP_MAP)
        struct.pack_into("<H", out, int(info["move_entry"]) + 6, FIELD_UNPACK)
        struct.pack_into("<H", out, int(info["exit_entry"]) + 6, FIELD_UNPACK)
        out[seg.file_offset + COORD_CALL_SITE:seg.file_offset + COORD_CALL_SITE + 3] = ORIGINAL_COORD_CALL
        out[seg.file_offset + AUX_COORD_CALL_SITE:seg.file_offset + AUX_COORD_CALL_SITE + 3] = ORIGINAL_AUX_COORD_CALL

    # Restore every display/timing variant from v1.2-v1.6/new to exact stock.
    out[seg.file_offset + JOSHUA_OPEN_DELAY_SITE:seg.file_offset + JOSHUA_OPEN_DELAY_SITE + len(JOSHUA_OPEN_DELAY_ORIG)] = JOSHUA_OPEN_DELAY_ORIG
    out[seg.file_offset + JOSHUA_FX_DELAY_SITE:seg.file_offset + JOSHUA_FX_DELAY_SITE + len(JOSHUA_FX_DELAY_ORIG)] = JOSHUA_FX_DELAY_ORIG
    out[seg.file_offset + MAP_REVEAL_WAIT_BRANCH_SITE:seg.file_offset + MAP_REVEAL_WAIT_BRANCH_SITE + 2] = MAP_REVEAL_WAIT_BRANCH_ORIG
    out[seg.file_offset + MAP_REVEAL_ORDER_SITE:seg.file_offset + MAP_REVEAL_ORDER_SITE + len(MAP_REVEAL_ORDER_ORIG)] = MAP_REVEAL_ORDER_ORIG
    out[seg.file_offset + LEGACY_RENDER_GROUP_SITE:seg.file_offset + LEGACY_RENDER_GROUP_SITE + len(LEGACY_RENDER_GROUP_ORIG)] = LEGACY_RENDER_GROUP_ORIG
    out[seg.file_offset + REVEAL_CALL_SITE:seg.file_offset + REVEAL_CALL_SITE + 3] = ORIGINAL_REVEAL_CALL
    out[seg.file_offset + ROW_DISPATCH_SITE:seg.file_offset + ROW_DISPATCH_SITE + len(ROW_DISPATCH_ORIG)] = ROW_DISPATCH_ORIG
    out[seg.file_offset + SPEED_CAVE_START:seg.file_offset + SPEED_CAVE_START + len(speed)] = b"\x00" * len(speed)
    struct.pack_into("<H", out, int(info["initial_flip_entry"]) + 6, INITIAL_FLIP_TARGET_ORIG)
    out[seg.file_offset + MAP_RENDER_CALL_SITE:seg.file_offset + MAP_RENDER_CALL_SITE + 3] = ORIGINAL_MAP_RENDER_CALL

    digest = sha256(out)
    label = SUPPORTED_BASE_SHA256.get(digest)
    if label is None:
        raise PatchError(
            "지원되는 정확한 ED2MAIN 기준선이 아닙니다.\n"
            f"normalized SHA-256: {digest}\n"
            "지원: 순정 한국 DOS판, Interop v1.4.52/v1.4.56 또는 Interop v1.4.67 current"
        )
    return bytes(out), digest, label, state


def inspect(
    path: Path,
    helper: bytes,
    legacy_fullmap: bytes,
    speed: bytes,
    legacy_render: bytes,
    legacy_atomic: bytes,
) -> dict[str, object]:
    data = path.read_bytes()
    _base, base_sha, label, incoming = normalize(data, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    info = structural_state(data, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    return {
        "tool": f"ED2 Joshua Scrollable Underground Map v{VERSION}",
        "target": str(path),
        "state": info["state"],
        "incoming_state": incoming,
        "base": label,
        "base_sha256": base_sha,
        "current_sha256": sha256(data),
        "scroll_helper_segment": f"86:{SCROLL_CAVE_START:04X}-{SCROLL_CAVE_START + len(helper) - 1:04X}",
        "speed_helper_segment": f"86:{SPEED_CAVE_START:04X}-{SPEED_CAVE_START + len(speed) - 1:04X}",
        "relocations": {
            f"86:{MG_YOSYUA_RELOC_SOURCE:04X}": f"86:{int(info['y_target']):04X}",
            f"86:{MAP_MOVE_UNPACK_RELOC_SOURCE:04X}": f"86:{int(info['move_target']):04X}",
            f"86:{MAP_EXIT_UNPACK_RELOC_SOURCE:04X}": f"86:{int(info['exit_target']):04X}",
        },
        "design": {
            "baseline": "v1.3.0 behavior: stock center-out reveal order + no periodic timer wait",
            "reveal_order": "exact v1.3.0 stock center-out row-index routine at 86:A646",
            "renderer": "v1.3.0 per-cell loop preserved; only the four consecutive A686 plane calls are replaced by the conservative v1.5.0 render4 helper at 86:1200",
            "boundary_fallback": "86:1200 helper falls back to stock A686 for cells whose four samples cross the 5000h source split",
            "scroll_logic": "v1.3.0 scroll helper unchanged byte-for-byte",
            "non_underground": "stock MG_DISP_MAP path preserved",
            "item_semantics": "Eye/Mirror consumption, HP/MP and MG_YOSYUA return semantics untouched",
            "migration": "exact v1.0.0-v1.6.0 and broken v1.3.1 states recognized; unsafe v1.3.1 row renderer is removed before applying v1.3.2",
        },
    }


def apply(
    path: Path,
    helper: bytes,
    legacy_fullmap: bytes,
    speed: bytes,
    legacy_render: bytes,
    legacy_atomic: bytes,
    make_backup: bool = True,
) -> dict[str, object]:
    before = path.read_bytes()
    base, base_sha, label, incoming = normalize(before, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    info = structural_state(before, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    if info["state"] == "patched-v1.3.2":
        return {"changed": False, **inspect(path, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)}

    seg: Segment = info["segment"]  # type: ignore[assignment]
    out = bytearray(base)
    out[seg.file_offset + SCROLL_CAVE_START:seg.file_offset + SCROLL_CAVE_START + len(helper)] = helper
    out[seg.file_offset + SPEED_CAVE_START:seg.file_offset + SPEED_CAVE_START + len(speed)] = speed

    struct.pack_into("<H", out, int(info["y_entry"]) + 6, JOSHUA_ENTRY)
    struct.pack_into("<H", out, int(info["move_entry"]) + 6, MAP_UNPACK_DISPATCH)
    struct.pack_into("<H", out, int(info["exit_entry"]) + 6, MAP_UNPACK_DISPATCH)
    out[seg.file_offset + COORD_CALL_SITE:seg.file_offset + COORD_CALL_SITE + 3] = NEW_COORD_CALL
    out[seg.file_offset + AUX_COORD_CALL_SITE:seg.file_offset + AUX_COORD_CALL_SITE + 3] = NEW_AUX_COORD_CALL

    # v1.3.0 behavior stays: stock timing values, center-out order, no periodic wait.
    out[seg.file_offset + JOSHUA_OPEN_DELAY_SITE:seg.file_offset + JOSHUA_OPEN_DELAY_SITE + len(JOSHUA_OPEN_DELAY_ORIG)] = JOSHUA_OPEN_DELAY_ORIG
    out[seg.file_offset + JOSHUA_FX_DELAY_SITE:seg.file_offset + JOSHUA_FX_DELAY_SITE + len(JOSHUA_FX_DELAY_ORIG)] = JOSHUA_FX_DELAY_ORIG
    out[seg.file_offset + MAP_REVEAL_WAIT_BRANCH_SITE:seg.file_offset + MAP_REVEAL_WAIT_BRANCH_SITE + 2] = MAP_REVEAL_WAIT_BRANCH_FAST
    out[seg.file_offset + MAP_REVEAL_ORDER_SITE:seg.file_offset + MAP_REVEAL_ORDER_SITE + len(MAP_REVEAL_ORDER_ORIG)] = MAP_REVEAL_ORDER_ORIG
    out[seg.file_offset + LEGACY_RENDER_GROUP_SITE:seg.file_offset + LEGACY_RENDER_GROUP_SITE + len(LEGACY_RENDER_GROUP_ORIG)] = LEGACY_RENDER_GROUP_FAST
    struct.pack_into("<H", out, int(info["initial_flip_entry"]) + 6, INITIAL_FLIP_TARGET_ORIG)
    out[seg.file_offset + MAP_RENDER_CALL_SITE:seg.file_offset + MAP_RENDER_CALL_SITE + 3] = ORIGINAL_MAP_RENDER_CALL

    # Keep the exact v1.3.0 reveal/order and per-cell loop.  Only collapse the
    # four consecutive plane-blend far calls into the conservative render4 helper.
    out[seg.file_offset + REVEAL_CALL_SITE:seg.file_offset + REVEAL_CALL_SITE + 3] = ORIGINAL_REVEAL_CALL
    out[seg.file_offset + ROW_DISPATCH_SITE:seg.file_offset + ROW_DISPATCH_SITE + len(ROW_DISPATCH_ORIG)] = ROW_DISPATCH_ORIG
    out[seg.file_offset + LEGACY_RENDER_GROUP_SITE:seg.file_offset + LEGACY_RENDER_GROUP_SITE + len(LEGACY_RENDER_GROUP_FAST)] = LEGACY_RENDER_GROUP_FAST

    if len(out) != len(before):
        raise PatchError("내부 오류: ED2MAIN 파일 크기가 변했습니다.")
    if parse_segments(out) != parse_segments(before):
        raise PatchError("내부 오류: NE segment geometry가 변했습니다.")
    if len(relocation_records(out, seg)) != len(relocation_records(before, seg)):
        raise PatchError("내부 오류: relocation count가 변했습니다.")

    if make_backup:
        backup = path.with_suffix(path.suffix + ".joshua_scroll_map.bak")
        if not backup.exists():
            shutil.copy2(path, backup)
    path.write_bytes(out)

    checked = inspect(path, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    if checked["state"] != "patched-v1.3.2":
        path.write_bytes(before)
        raise PatchError("적용 후 자체 검증에 실패하여 원본을 복구했습니다.")
    return {
        "changed": True,
        "migrated_from": incoming,
        "base": label,
        "base_sha256": base_sha,
        "before_sha256": sha256(before),
        "after_sha256": sha256(out),
        **checked,
    }


def restore(
    path: Path,
    helper: bytes,
    legacy_fullmap: bytes,
    speed: bytes,
    legacy_render: bytes,
    legacy_atomic: bytes,
) -> dict[str, object]:
    before = path.read_bytes()
    base, base_sha, label, incoming = normalize(before, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
    if before == base:
        return {"changed": False, **inspect(path, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)}
    path.write_bytes(base)
    return {
        "changed": True,
        "restored_from": incoming,
        "base": label,
        "base_sha256": base_sha,
        "before_sha256": sha256(before),
        "after_sha256": sha256(base),
        **inspect(path, helper, legacy_fullmap, speed, legacy_render, legacy_atomic),
    }


def choose_root() -> Path | None:
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk(); root.withdraw()
        picked = filedialog.askdirectory(title="영웅전설 II 게임 폴더 선택")
        root.destroy()
        return Path(picked) if picked else None
    except Exception:
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description="영웅전설 II 요슈아 지하 스크롤 지도 v1.3.0 기반 안전 고속 렌더 패치")
    parser.add_argument("game_dir", nargs="?", help="ED2MAIN.EXE가 있는 게임 폴더")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--apply", action="store_true", help="패치 적용 (기본)")
    mode.add_argument("--check", action="store_true", help="상태 확인")
    mode.add_argument("--restore", action="store_true", help="요슈아 스크롤 지도 패치 제거")
    parser.add_argument("--no-backup", action="store_true", help="적용 시 전용 백업을 만들지 않음")
    args = parser.parse_args()

    root = Path(args.game_dir) if args.game_dir else choose_root()
    if root is None:
        print("게임 폴더가 선택되지 않았습니다.", file=sys.stderr)
        return 2
    target = root / TARGET_NAME
    if not target.is_file():
        print(f"오류: {target}이 없습니다.", file=sys.stderr)
        return 2

    script_dir = Path(__file__).resolve().parent
    try:
        helper, legacy_fullmap, speed, legacy_render, legacy_atomic = load_helpers(script_dir)
        if args.check:
            result = inspect(target, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
        elif args.restore:
            result = restore(target, helper, legacy_fullmap, speed, legacy_render, legacy_atomic)
        else:
            result = apply(target, helper, legacy_fullmap, speed, legacy_render, legacy_atomic, make_backup=not args.no_backup)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, PatchError, struct.error) as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
