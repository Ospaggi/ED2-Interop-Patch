﻿@echo off
setlocal
if "%~1"=="" (
  echo Usage: apply_symbol_density.bat ^<ED2 game folder^>
  echo Example: apply_symbol_density.bat "C:\Games\ED2"
  exit /b 2
)
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0ed2_symbol_encounter_density.py" "%~1"
) else (
  python "%~dp0ed2_symbol_encounter_density.py" "%~1"
)
set RC=%errorlevel%
echo.
if not "%RC%"=="0" echo Patch failed. Exit code: %RC%
exit /b %RC%
