#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, struct, sys
from pathlib import Path

APP_NAME='ED2 Chapter Title Refresh'
VERSION='0.3.4'

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from ed2_ne_slot import patch_message_slot_0f, message_redirect_matches, parse_segments, tail_layout  # type: ignore

# Existing save-load title refresh. This is unrelated to chapter-end alignment.
HOOK_OFF=0xAC41
HOOK_ORIGINAL=bytes.fromhex('8B FB B9 00 02 F3 A5')
CAVE_START=0x1D18
CAVE_END=0x1E00
TITLE_DST=0x2080
TITLE_LEN=30
V_TITLES=(('V_000.DLL',0x0012),('V_100.DLL',0x0029),('V_200.DLL',0x002A),('V_300.DLL',0x0023),('V_400.DLL',0x002B))

# v1.4.56: HUD/save-load chapter label is deliberately rolled back to the
# exact v1.4.52 30-byte rows.  R15 changed the physical V_*.DLL title rows
# (including FF padding), which the save-load helper copied verbatim into
# TITLE_DATA and broke the upper-right chapter display/centering.  This table
# affects only the persistent HUD refresh helper; chapter-end cards below keep
# the current R15 wording/alignment.
CANONICAL_TITLE_ROWS=(
    '     서장  평화로운 나날      '.encode('cp949'),
    '       제1장  열린 나락       '.encode('cp949'),
    '     제2장  영웅들의 행방     '.encode('cp949'),
    '        제3장  용의 알        '.encode('cp949'),
    '     제4장  암흑의 지배자     '.encode('cp949'),
    '   종장   기도, 그리고 희망   '.encode('cp949'),
)
if any(len(x)!=TITLE_LEN for x in CANONICAL_TITLE_ROWS): raise AssertionError('canonical chapter title row size')

# Message renderer must remain vanilla. v0.2.0/v0.2.1 experimented with a
# global opcode-09 indent extension; v0.3.0 removes that design completely.
RENDER_HANDLER_OFF=0x89D2
RENDER_HANDLER_ORIGINAL=bytes.fromhex('AC 0E E8 D9 FC 8B 0E DE 96 CB')
RENDER_HELPER_OFF=0x18C0
RENDER_DISPATCH_SEG=85
RENDER_DISPATCH_OFF=0x3950
RENDER_DISPATCH_ORIGINAL=struct.pack('<H',RENDER_HANDLER_OFF)
RENDER_DISPATCH_V021=struct.pack('<H',RENDER_HELPER_OFF)
def _near_jump(site:int,target:int)->bytes:
    disp=(target-(site+3)) & 0xFFFF
    return b'\xE9'+struct.pack('<H',disp)
RENDER_HANDLER_V020=_near_jump(RENDER_HANDLER_OFF,RENDER_HELPER_OFF)+b'\x90'*(len(RENDER_HANDLER_ORIGINAL)-3)

# Chapter-end text is centered with ordinary half-width spaces only.
# The visible message line is 34 CP949 byte-cells wide. Korean glyphs occupy
# two cells and ASCII spaces one. No renderer extension/control opcode is needed.
CARD_WIDTH=34
CHAPTER_ENDS={
    'V_100.DLL': dict(title='제1장 열린 나락', indent=9,
                      original_title='제1장   열려진 나락', title_len=19, end_len=17,
                      old09_indent=7, previous_seg3_len=2026),
    'V_200.DLL': dict(title='제2장 영웅들의 행방', indent=7,
                      original_title='제2장   영웅들의 행방', title_len=21, end_len=16,
                      old09_indent=5, previous_seg3_len=3122),
    'V_300.DLL': dict(title='제3장  용의 알', previous_title='제3장 용의 알', dialogue_title='제3장 용의 알', indent=10,
                      original_title='제3장   용의 알', title_len=15, end_len=15,
                      old09_indent=8, previous_seg3_len=2214),
    'V_400.DLL': dict(title='제4장 암흑의 지배자', indent=7,
                      original_title='제4장   암흑의 지배자', title_len=21, end_len=17,
                      old09_indent=5, previous_seg3_len=5862),
}
PREVIOUS_TITLE_INDENTS={'V_100.DLL':7,'V_200.DLL':5,'V_300.DLL':8,'V_400.DLL':5}
PREVIOUS_SPACE_END_INDENT=14
END_INDENT=16

class PatchError(RuntimeError): pass

def parse_ne_segments(data: bytes):
    if data[:2]!=b'MZ': raise PatchError('MZ 실행 파일이 아닙니다.')
    ne=struct.unpack_from('<I',data,0x3C)[0]
    if data[ne:ne+2]!=b'NE': raise PatchError('NE 실행 파일이 아닙니다.')
    count=struct.unpack_from('<H',data,ne+0x1C)[0]
    off=ne+struct.unpack_from('<H',data,ne+0x22)[0]
    shift=struct.unpack_from('<H',data,ne+0x32)[0]
    out=[]
    for i in range(count):
        sec,size,flags,minalloc=struct.unpack_from('<HHHH',data,off+i*8)
        out.append((sec<<shift,size or 0x10000,flags,minalloc or 0x10000))
    return out

def title_rows(root: Path, main: bytes) -> list[bytes]:
    # One canonical table owns both the ED2MAIN save/load HUD helper and the
    # V_*.DLL chapter-name source rows read during chapter transitions.
    return list(CANONICAL_TITLE_ROWS)


def _v_source_row_state(root:Path)->dict:
    rows=[]; ok=True
    # table[0] is the prologue label. V_000..V_400 store chapter 1..final.
    for i,(fn,off) in enumerate(V_TITLES, start=1):
        p=root/'SCENA'/fn; data=p.read_bytes(); seg=parse_segments(data)[2]
        cur=bytes(data[seg.file_offset+off:seg.file_offset+off+TITLE_LEN])
        want=CANONICAL_TITLE_ROWS[i]
        good=cur==want; ok &= good
        rows.append({'dll':fn,'offset':f'0x{off:04X}','ok':good,
                     'current':cur.decode('cp949','replace'),'canonical':want.decode('cp949')})
    return {'ok':bool(ok),'rows':rows}


def _patch_v_source_rows(root:Path,backup:bool)->dict:
    changed=[]
    for i,(fn,off) in enumerate(V_TITLES, start=1):
        p=root/'SCENA'/fn; before=p.read_bytes(); data=bytearray(before); seg=parse_segments(before)[2]
        pos=seg.file_offset+off; want=CANONICAL_TITLE_ROWS[i]; cur=bytes(data[pos:pos+TITLE_LEN])
        if cur!=want:
            # These are dedicated 30-byte chapter-name rows in the stock/R15
            # SCENA layout.  Keep their size fixed; only normalize content.
            data[pos:pos+TITLE_LEN]=want
            if backup and not Path(str(p)+'.chapter_title.bak').exists(): shutil.copy2(p,Path(str(p)+'.chapter_title.bak'))
            p.write_bytes(bytes(data)); changed.append(fn)
    state=_v_source_row_state(root)
    if not state['ok']: raise PatchError('V_*.DLL 장 이름 정본 동기화 실패')
    return {'changed_files':changed,'state':state}

def helper_bytes(rows: list[bytes]) -> bytes:
    table=CAVE_START+0x30; code=bytearray()
    code += bytes.fromhex('89 DF B9 00 02 F3 A5 9C 81 FB 00 20 75 20 A0 41 20 3C 05 77 19 B3 1E F6 E3')
    code += b'\xBE'+struct.pack('<H',table)
    code += bytes.fromhex('01 C6 1E 06 1E 07 0E 1F BF 80 20 B9 0F 00 F3 A5 07 1F 9D C3')
    if len(code)!=0x30: raise AssertionError(len(code))
    blob=bytes(code)+b''.join(rows)
    if len(blob)>CAVE_END-CAVE_START: raise PatchError('코드 동굴 용량 초과')
    return blob+b'\0'*(CAVE_END-CAVE_START-len(blob))

def hook_bytes() -> bytes:
    disp=(CAVE_START-(HOOK_OFF+3)) & 0xFFFF
    return b'\xE8'+struct.pack('<H',disp)+b'\x90'*4

def _renderer_state(main:bytes)->dict:
    segs=parse_ne_segments(main); s85=segs[84]; s86=segs[85]
    data=main[s85[0]:s85[0]+s85[1]]; code=main[s86[0]:s86[0]+s86[1]]
    handler=bytes(code[RENDER_HANDLER_OFF:RENDER_HANDLER_OFF+len(RENDER_HANDLER_ORIGINAL)])
    dispatch=bytes(data[RENDER_DISPATCH_OFF:RENDER_DISPATCH_OFF+2])
    if handler==RENDER_HANDLER_ORIGINAL and dispatch==RENDER_DISPATCH_ORIGINAL: state='vanilla'
    elif handler==RENDER_HANDLER_V020 and dispatch==RENDER_DISPATCH_ORIGINAL: state='unsafe_v0.2.0'
    elif handler==RENDER_HANDLER_ORIGINAL and dispatch==RENDER_DISPATCH_V021: state='v0.2.1_indent'
    else: state='unknown'
    return {'state':state,'handler':handler.hex(' '),'dispatch':dispatch.hex(' ')}

def restore_vanilla_renderer(root:Path,backup:bool=True)->dict:
    p=root/'ED2MAIN.EXE'; before=p.read_bytes(); out=bytearray(before); segs=parse_ne_segments(before);s85=segs[84];s86=segs[85]
    dpos=s85[0]+RENDER_DISPATCH_OFF;hpos=s86[0]+RENDER_HANDLER_OFF
    state=_renderer_state(before)
    if state['state']=='unknown': raise PatchError('ED2MAIN 메시지 renderer가 지원하지 않는 상태입니다.')
    out[hpos:hpos+len(RENDER_HANDLER_ORIGINAL)]=RENDER_HANDLER_ORIGINAL
    out[dpos:dpos+2]=RENDER_DISPATCH_ORIGINAL
    after=bytes(out); diff=sum(a!=b for a,b in zip(before,after))
    if diff:
        if backup and not p.with_suffix('.EXE.bak').exists(): shutil.copy2(p,p.with_suffix('.EXE.bak'))
        p.write_bytes(after)
    return {'changed_bytes':diff,'state':_renderer_state(after)}

def _desired_title(spec:dict)->bytes:
    encoded=str(spec['title']).encode('cp949')
    # Keep the explicit per-title values auditable, but fail if they no longer
    # correspond to true centering in the 34-cell message line.
    expected=(CARD_WIDTH-len(encoded))//2
    if int(spec['indent'])!=expected:
        raise PatchError(f"장 종료 제목 중앙 정렬값 불일치: {spec['title']} indent={spec['indent']} expected={expected}")
    return b' '*int(spec['indent']) + encoded

def _previous_title_text(spec:dict)->str:
    return str(spec.get('previous_title', spec['title']))

def _previous_v032_title(fn:str,spec:dict)->bytes:
    return b' '*int(PREVIOUS_TITLE_INDENTS[fn]) + _previous_title_text(spec).encode('cp949')

def _previous_v033_title(spec:dict)->bytes:
    return b' '*int(spec['indent']) + _previous_title_text(spec).encode('cp949')

def _current_unaligned_title(spec:dict)->bytes:
    # R31~R41 dialogue normalization has already updated chapter-end wording
    # before this component runs in the AIO.  It intentionally keeps two
    # half-width spaces after the chapter number until the alignment pass.
    title=str(spec.get('dialogue_title', spec['title']))
    if '장 ' not in title:
        raise PatchError('장 종료 제목 형식이 예상과 다릅니다: '+title)
    return title.replace('장 ','장  ',1).encode('cp949')

def _original_end(spec:dict)->bytes:
    n=int(spec['end_len'])-len('끝'.encode('cp949'))
    return b' '*n+'끝'.encode('cp949')

def _desired_end()->bytes:
    return b' '*END_INDENT + '끝'.encode('cp949')

def _previous_space_end()->bytes:
    return b' '*PREVIOUS_SPACE_END_INDENT + '끝'.encode('cp949')

def _previous09_title(spec:dict)->bytes:
    raw=b'\x09'+bytes((0xF0+int(spec['old09_indent']),))+_previous_title_text(spec).encode('cp949')
    return raw+b'\xFF'*(int(spec['title_len'])-len(raw))

def _previous09_end(spec:dict)->bytes:
    raw=b'\x09\xFE'+'끝'.encode('cp949')
    return raw+b'\xFF'*(int(spec['end_len'])-len(raw))

def _card_offsets(data:bytes,fn:str,spec:dict)->tuple[int,int]:
    seg=parse_segments(data)[2]
    base=seg.file_offset
    if data[base]!=0x08: raise PatchError(f'{fn}: 장 종료 화면 시작 opcode 08을 찾지 못했습니다.')
    title_off=1; title_len=int(spec['title_len']); sep=title_off+title_len
    if data[base+sep:base+sep+2]!=b'\x01\x01': raise PatchError(f'{fn}: 제목 뒤 01 01 경계를 찾지 못했습니다.')
    end_off=sep+2; end_len=int(spec['end_len'])
    if data[base+end_off+end_len:base+end_off+end_len+2]!=b'\x01\x00': raise PatchError(f'{fn}: 끝 뒤 01 00 경계를 찾지 못했습니다.')
    return title_off,end_off

def _ensure_segment3_tail_room(data:bytes,needed:int)->tuple[bytes,int]:
    """Create one aligned sector of local padding before segment 4 when needed.

    V_300 segment 3 has no alignment padding left after existing message fixes.
    It is the penultimate segment, so shifting only segment 4 by one NE sector is
    enough and leaves all segment-relative offsets/relocations untouched.
    """
    layout=tail_layout(data,3)
    if layout.available_padding>=needed:
        return data,0
    segs=parse_segments(data)
    if len(segs)!=4 or segs[2].index!=3 or segs[3].index!=4:
        raise PatchError('SCENA segment 3 확장 구조가 예상과 다릅니다.')
    # NE alignment shift must be 9 (512-byte sectors) for these SCENA DLLs.
    ne=struct.unpack_from('<I',data,0x3C)[0];shift=struct.unpack_from('<H',data,ne+0x32)[0]
    if shift!=9: raise PatchError(f'SCENA NE alignment shift가 예상과 다릅니다: {shift}')
    table=ne+struct.unpack_from('<H',data,ne+0x22)[0]
    seg4_entry=table+3*8
    old_sector=struct.unpack_from('<H',data,seg4_entry)[0]
    old_off=old_sector<<shift
    if old_off!=segs[3].file_offset: raise PatchError('segment 4 file offset 검증 실패')
    out=bytearray(data);out[old_off:old_off]=b'\0'*(1<<shift)
    struct.pack_into('<H',out,seg4_entry,old_sector+1)
    result=bytes(out)
    v=parse_segments(result)
    if v[3].file_offset!=old_off+(1<<shift): raise PatchError('segment 4 이동 검증 실패')
    # Segment 4 content must move byte-identically.
    old4=data[old_off:old_off+segs[3].length]
    new4=result[v[3].file_offset:v[3].file_offset+v[3].length]
    if old4!=new4: raise PatchError('segment 4 이동 중 내용이 변경되었습니다.')
    if tail_layout(result,3).available_padding<needed: raise PatchError('segment 3 정렬 패딩 확보 실패')
    return result,1<<shift

def _slot_matches(data:bytes,offset:int,editable:int,encoded:bytes,suffix:bytes)->bool:
    seg=parse_segments(data)[2];base=seg.file_offset;cur=data[base+offset:base+offset+editable]
    if len(encoded)<=editable and cur==encoded+b'\xFF'*(editable-len(encoded)): return True
    return message_redirect_matches(data,3,offset,editable,encoded,suffix)

def normalize_space_aligned_for_v021(raw:bytes,fn:str)->bytes:
    """Return the pre-v0.3.0 (v0.2.1 card) byte image for hashing.

    This is a pure verifier normalizer. It removes only v0.3.0's local message
    tail allocations / V_300 alignment sector and restores the previous 09 F*
    card bytes. Other SCENA bytes are preserved verbatim.
    """
    if fn not in CHAPTER_ENDS: raise PatchError(f'지원하지 않는 장 종료 DLL: {fn}')
    spec=CHAPTER_ENDS[fn]; data=bytes(raw)
    to,eo=_card_offsets(data,fn,spec)
    if not _slot_matches(data,to,int(spec['title_len']),_desired_title(spec),b'\x01\x01'):
        raise PatchError(f'{fn}: 공백 정렬 제목 상태가 아닙니다.')
    if not _slot_matches(data,eo,int(spec['end_len']),_desired_end(),b'\x01\x00'):
        raise PatchError(f'{fn}: 공백 정렬 끝 상태가 아닙니다.')
    out=bytearray(data);segs=parse_segments(out);seg3=segs[2]
    prev_len=int(spec['previous_seg3_len'])
    if seg3.length<prev_len: raise PatchError(f'{fn}: segment 3 길이가 예상보다 짧습니다.')
    # Preserve relocation table byte-identically while moving it back to the
    # previous segment end.
    layout=tail_layout(out,3);reloc=bytes(out[layout.segment_end:layout.segment_end+layout.relocation_size])
    if layout.relocation_size:
        out[seg3.file_offset+prev_len:layout.next_segment_offset]=b'\0'*(layout.next_segment_offset-(seg3.file_offset+prev_len))
        out[seg3.file_offset+prev_len:seg3.file_offset+prev_len+len(reloc)]=reloc
    ne=struct.unpack_from('<I',out,0x3C)[0];table=ne+struct.unpack_from('<H',out,ne+0x22)[0]
    e3=table+2*8
    struct.pack_into('<H',out,e3+2,prev_len if prev_len!=0x10000 else 0)
    old_min=struct.unpack_from('<H',out,e3+6)[0]
    if old_min not in (0,prev_len): struct.pack_into('<H',out,e3+6,prev_len)
    # V_300 reserved one 512-byte sector before segment 4 because its segment-3
    # relocation table had already reached the next aligned sector.
    if fn=='V_300.DLL':
        cur=parse_segments(out);seg4=cur[3];shift=struct.unpack_from('<H',out,ne+0x32)[0];unit=1<<shift
        old4=seg4.file_offset-unit
        # The inserted sector must now be all padding after relocation compaction.
        if any(out[old4:seg4.file_offset]): raise PatchError('V_300 정렬용 확장 sector가 비어 있지 않습니다.')
        del out[old4:seg4.file_offset]
        e4=table+3*8;sec4=struct.unpack_from('<H',out,e4)[0];struct.pack_into('<H',out,e4,sec4-1)
    result=bytearray(out);segs2=parse_segments(result);base=segs2[2].file_offset
    to2,eo2=_card_offsets(result,fn,spec)
    result[base+to2:base+to2+int(spec['title_len'])]=_previous09_title(spec)
    result[base+eo2:base+eo2+int(spec['end_len'])]=_previous09_end(spec)
    return bytes(result)

def inspect_chapter_end(root:Path)->dict:
    rows=[];ok=True
    for fn,spec in CHAPTER_ENDS.items():
        p=root/'SCENA'/fn;data=p.read_bytes();to,eo=_card_offsets(data,fn,spec);seg=parse_segments(data)[2];base=seg.file_offset
        title=_desired_title(spec);end=_desired_end();
        applied_title=_slot_matches(data,to,int(spec['title_len']),title,b'\x01\x01')
        applied_end=_slot_matches(data,eo,int(spec['end_len']),end,b'\x01\x00')
        cur_title=bytes(data[base+to:base+to+int(spec['title_len'])]);cur_end=bytes(data[base+eo:base+eo+int(spec['end_len'])])
        original_title=(cur_title==str(spec['original_title']).encode('cp949'))
        current_unaligned=(
            cur_title==_current_unaligned_title(spec)+b'\xFF'*(int(spec['title_len'])-len(_current_unaligned_title(spec)))
            and cur_end==_original_end(spec)
        )
        # v1.4.56 R15 stock-rebuild state: V_100 already carries the corrected
        # chapter wording in the original physical title slot, but it has not
        # yet received the chapter-card centering redirect.  Accept this as a
        # legitimate pre-refresh state instead of treating it as unknown.
        r15_raw=str(spec['title']).encode('cp949')
        r15_current=(
            len(r15_raw)<=int(spec['title_len'])
            and cur_title==r15_raw+b'\xFF'*(int(spec['title_len'])-len(r15_raw))
            and cur_end==_original_end(spec)
        )
        previous09=(cur_title==_previous09_title(spec) and cur_end==_previous09_end(spec))
        previous_v033=(
            _slot_matches(data,to,int(spec['title_len']),_previous_v033_title(spec),b'\x01\x01')
            and _slot_matches(data,eo,int(spec['end_len']),_desired_end(),b'\x01\x00')
        )
        previous_v032=(
            _slot_matches(data,to,int(spec['title_len']),_previous_v032_title(fn,spec),b'\x01\x01')
            and _slot_matches(data,eo,int(spec['end_len']),_desired_end(),b'\x01\x00')
        )
        previous_space=(
            _slot_matches(data,to,int(spec['title_len']),_previous_v032_title(fn,spec),b'\x01\x01')
            and _slot_matches(data,eo,int(spec['end_len']),_previous_space_end(),b'\x01\x00')
        )
        state=(
            'applied' if applied_title and applied_end
            else 'previous_v0.3.3' if previous_v033
            else 'previous_v0.3.2' if previous_v032
            else 'previous_space' if previous_space
            else 'previous_indent' if previous09
            else 'dialogue_current' if current_unaligned
            else 'r15_current' if r15_current
            else 'original' if original_title and cur_end==_original_end(spec)
            else 'unknown'
        )
        ok &= state=='applied'
        rows.append({'dll':fn,'state':state,'title':spec['title'],'title_leading_spaces':spec['indent'],'end_leading_spaces':END_INDENT,
                     'segment3_length':seg.length,'title_redirected':len(title)>int(spec['title_len']),'end_redirected':len(end)>int(spec['end_len'])})
    return {'ok':ok,'rows':rows}

def patch_chapter_ends(root:Path,backup:bool=True)->dict:
    # Transactional across all four chapter DLLs: validate and build every
    # output in memory first, then commit only when all four postconditions pass.
    changed_files=0;changed_bytes=0;consumed=0
    states={r['dll']:r['state'] for r in inspect_chapter_end(root)['rows']}
    planned=[]
    for fn,spec in CHAPTER_ENDS.items():
        p=root/'SCENA'/fn;before=p.read_bytes();data=before
        state=states[fn]
        if state=='unknown':
            raise PatchError(f'{fn}: 지원하지 않는 장 종료 제목 상태입니다.')
        # Two extra leading spaces increase the out-of-line payload. If the
        # segment-3 relocation table has reached segment 4 (notably V_400 on
        # v0.3.2/current inputs), reserve one local NE sector before segment 4.
        # This moves only segment 4 byte-identically and never touches the global
        # message renderer.
        data,grown=_ensure_segment3_tail_room(data,32)
        to,eo=_card_offsets(data,fn,spec)
        r1=patch_message_slot_0f(data,3,to,int(spec['title_len']),_desired_title(spec),b'\x01\x01')
        r2=patch_message_slot_0f(r1.data,3,eo,int(spec['end_len']),_desired_end(),b'\x01\x00')
        after=r2.data
        # Strong per-file postcondition before any write.
        if not _slot_matches(after,to,int(spec['title_len']),_desired_title(spec),b'\x01\x01'):
            raise PatchError(f'{fn}: 중앙 정렬 제목 적용 후 검증 실패')
        if not _slot_matches(after,eo,int(spec['end_len']),_desired_end(),b'\x01\x00'):
            raise PatchError(f'{fn}: 끝 정렬 적용 후 검증 실패')
        diff=sum(a!=b for a,b in zip(before,after)) + abs(len(after)-len(before))
        planned.append((p,before,after,diff))
        consumed += int(r1.consumed_padding)+int(r2.consumed_padding)+grown
    for p,before,after,diff in planned:
        if after!=before:
            if backup and not p.with_suffix('.DLL.bak').exists(): shutil.copy2(p,p.with_suffix('.DLL.bak'))
            p.write_bytes(after);changed_files+=1;changed_bytes+=diff
    return {'changed_files':changed_files,'changed_bytes':changed_bytes,'consumed_alignment_padding':consumed}

def inspect(root:Path)->dict:
    root=root.resolve();p=root/'ED2MAIN.EXE';b=p.read_bytes();segs=parse_ne_segments(b);s86=segs[85];code=b[s86[0]:s86[0]+s86[1]]
    rows=title_rows(root,b);desired=helper_bytes(rows);hook=code[HOOK_OFF:HOOK_OFF+7];cave=code[CAVE_START:CAVE_END]
    refresh_state='applied' if hook==hook_bytes() and cave==desired else 'original' if hook==HOOK_ORIGINAL and set(cave)=={0} else 'unknown'
    cards=inspect_chapter_end(root);renderer=_renderer_state(b)
    vrows=_v_source_row_state(root)
    # Helper table rows 1..5 must be byte-identical to the transition source
    # rows.  This is the invariant that prevents the upper-right HUD corruption.
    helper_v_sync=(cave[0x30+TITLE_LEN:0x30+TITLE_LEN*6] == b''.join(CANONICAL_TITLE_ROWS[1:]))
    state='applied' if refresh_state=='applied' and cards['ok'] and renderer['state']=='vanilla' and vrows['ok'] and helper_v_sync else 'partial_or_unknown'
    return {'state':state,'refresh_state':refresh_state,'chapter_end_spaces':cards,'message_renderer':renderer,
            'chapter_name_source_rows':vrows,'helper_matches_v_rows':helper_v_sync,
            'hook':hook.hex(' '),'cave_matches':cave==desired,'alignment':'half-width spaces only; no global renderer extension'}

def apply(root:Path,backup=True):
    root=root.resolve()
    vsource=_patch_v_source_rows(root,backup)
    p=root/'ED2MAIN.EXE';before=p.read_bytes();segs=parse_ne_segments(before);s86=segs[85];code=bytearray(before[s86[0]:s86[0]+s86[1]])
    rows=title_rows(root,before);desired=helper_bytes(rows);hook=bytes(code[HOOK_OFF:HOOK_OFF+7]);cave=bytes(code[CAVE_START:CAVE_END])
    if hook not in (HOOK_ORIGINAL,hook_bytes()): raise PatchError('LOAD_SAVE_DATA hook가 지원하지 않는 상태입니다: '+hook.hex(' '))
    own_helper=hook==hook_bytes() and cave[:0x30]==desired[:0x30]
    if cave!=desired and any(cave) and not own_helper: raise PatchError('86:1D18~1DFF 코드 동굴이 다른 코드에 사용되고 있습니다.')
    code[HOOK_OFF:HOOK_OFF+7]=hook_bytes();code[CAVE_START:CAVE_END]=desired
    after=bytearray(before);after[s86[0]:s86[0]+s86[1]]=code
    if bytes(after)!=before:
        if backup and not p.with_suffix('.EXE.bak').exists(): shutil.copy2(p,p.with_suffix('.EXE.bak'))
        p.write_bytes(after)
    renderer=restore_vanilla_renderer(root,backup)
    cards=patch_chapter_ends(root,backup)
    result=inspect(root);result.update({'changed':before!=(root/'ED2MAIN.EXE').read_bytes() or bool(cards['changed_files']),
      'chapter_name_source_changed_files':vsource['changed_files'],
      'chapter_end_changed_files':cards['changed_files'],'chapter_end_changed_bytes':cards['changed_bytes'],
      'consumed_alignment_padding':cards['consumed_alignment_padding'],'renderer_restore_changed_bytes':renderer['changed_bytes']})
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('root');g=ap.add_mutually_exclusive_group();g.add_argument('--apply',action='store_true');g.add_argument('--check',action='store_true');ap.add_argument('--no-backup',action='store_true');a=ap.parse_args()
    try:
        r=inspect(Path(a.root)) if a.check else apply(Path(a.root),not a.no_backup)
        print(json.dumps(r,ensure_ascii=False,indent=2))
        if a.check and r['state']!='applied':return 2
        return 0
    except Exception as e:
        print(f'ERROR: {e}',file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
