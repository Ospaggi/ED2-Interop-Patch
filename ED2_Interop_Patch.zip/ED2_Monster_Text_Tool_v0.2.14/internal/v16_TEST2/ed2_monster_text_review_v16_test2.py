#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse,hashlib,json,os,sys,tempfile
HERE=Path(__file__).resolve().parent
SPEC=json.loads((HERE/'monster_text_v16_test2_spec.json').read_text(encoding='utf-8'))
REPORT='MONSTER_TEXT_V16_TEST2_LAST_REPORT.json'
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for ch in iter(lambda:f.read(1024*1024),b''):h.update(ch)
 return h.hexdigest()
def report(root,obj):
 try:(root/REPORT).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
 except Exception:pass
def main():
 ap=argparse.ArgumentParser(description='ED2 Monster Text Review v16 TEST2 exact-SHA patcher')
 ap.add_argument('root',nargs='?',default='.',help='ED2 game directory')
 ap.add_argument('--verify',action='store_true')
 a=ap.parse_args();root=Path(a.root).resolve();files=SPEC['files']
 if a.verify:
  bad=[]
  for fn,e in files.items():
   p=root/e['relative_path'];got=sha_file(p) if p.is_file() else None
   if got!=e['target_sha256']:bad.append({'file':e['relative_path'],'got':got,'expected':e['target_sha256']})
  o={'phase':'verify','ok':not bad,'files_verified':len(files)-len(bad),'target_files':len(files),'mismatches':bad,'writes':0};report(root,o)
  print(f"[Monster Text v16 TEST2] verify {'PASS' if not bad else 'FAIL'}: {len(files)-len(bad)}/{len(files)}")
  return 0 if not bad else 1
 states={};errors=[]
 # Fail-closed: identify every file before writing any file.
 for fn,e in files.items():
  p=root/e['relative_path']
  if not p.is_file():errors.append({'file':e['relative_path'],'error':'missing'});continue
  got=sha_file(p)
  if got==e['target_sha256']:states[fn]=('target',None);continue
  v=next((v for v in e['variants'] if v['sha256']==got),None)
  if v is None:errors.append({'file':e['relative_path'],'error':'unsupported_or_tampered','sha256':got})
  else:states[fn]=('variant',v)
 if errors:
  report(root,{'phase':'preflight','ok':False,'errors':errors,'writes':0})
  print('[Monster Text v16 TEST2] preflight FAIL: unsupported/tampered input; writes=0',file=sys.stderr);return 1
 planned={}
 for fn,e in files.items():
  state,v=states[fn]
  if state=='target':continue
  p=root/e['relative_path'];data=bytearray(p.read_bytes())
  if len(data)!=e['size']:errors.append({'file':e['relative_path'],'error':'size_changed'});continue
  local_error=False
  for h in v['hunks']:
   off=h['offset'];before=bytes.fromhex(h['before_hex']);after=bytes.fromhex(h['after_hex'])
   if bytes(data[off:off+len(before)])!=before:
    errors.append({'file':e['relative_path'],'error':'hunk_preimage_mismatch','offset':h['offset_hex'],'variant':v['label']});local_error=True;break
   data[off:off+len(before)]=after
  if not local_error and sha_bytes(bytes(data))!=e['target_sha256']:
   errors.append({'file':e['relative_path'],'error':'postimage_sha_mismatch','variant':v['label']});local_error=True
  if not local_error:planned[fn]=bytes(data)
 if errors:
  report(root,{'phase':'preflight_hunks','ok':False,'errors':errors,'writes':0})
  print('[Monster Text v16 TEST2] hunk preflight FAIL; writes=0',file=sys.stderr);return 1
 writes=0
 for fn,data in planned.items():
  p=root/files[fn]['relative_path'];fd,tmp=tempfile.mkstemp(prefix=p.name+'.',suffix='.tmp',dir=str(p.parent))
  try:
   with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
   os.replace(tmp,p);writes+=1
  finally:
   try:
    if os.path.exists(tmp):os.unlink(tmp)
   except Exception:pass
 bad=[]
 for fn,e in files.items():
  got=sha_file(root/e['relative_path'])
  if got!=e['target_sha256']:bad.append({'file':e['relative_path'],'got':got})
 o={'phase':'apply','ok':not bad,'changed_files':writes,'target_files':len(files),'mismatches':bad,'writes':writes};report(root,o)
 if bad:print('[Monster Text v16 TEST2] post-write verify FAIL',file=sys.stderr);return 1
 print(f'[Monster Text v16 TEST2] 적용 완료: {writes}개 파일 변경 / {len(files)}개 누적 대상 검증')
 return 0
if __name__=='__main__':raise SystemExit(main())
