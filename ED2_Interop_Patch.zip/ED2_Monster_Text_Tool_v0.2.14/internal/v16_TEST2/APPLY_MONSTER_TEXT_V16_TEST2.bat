@echo off
python ed2_monster_text_review_v16_test2.py ..
pause
