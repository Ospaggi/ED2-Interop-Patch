#!/usr/bin/env python3
"""Integrated reviewed-v15 installer.

Owns the ordinary reviewed-v15 CSV plus the four structurally special PC-98
reaudit streams and the relocated/expanded M_115 segment-3 text.  These used to
ship as separate v1.4.40 patch components; they now belong to Monster Text Tool.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

import ed2_monster_text_tool as base
import v14_special_reaudit as sp
import m115_full_text as m115

VERSION='0.2.14-v15-integrated'

# v1.4.47 adds two new M_500 0F messages. A fresh install and an
# incremental install can otherwise allocate the two tiny overflow tails in
# opposite order. Both layouts render correctly, but normalize them so every
# supported install path is byte-identical.
_M500_REDIRECT_FRESH = {
    0x3575: 0x74, 0x35C8: 0x7C,
    0x3874: 0xC5, 0x3875: 0xF5, 0x387A: 0x78,
    0x387C: 0xC7, 0x387D: 0xDF, 0x3882: 0xCA,
}
_M500_REDIRECT_CANON = {
    0x3575: 0x7C, 0x35C8: 0x74,
    0x3874: 0xC7, 0x3875: 0xDF, 0x387A: 0xCA,
    0x387C: 0xC5, 0x387D: 0xF5, 0x3882: 0x78,
}
_M500_MESSAGES = (
    (0x015E, 26, '황제 고드윈 2세와의 전투다.'),
    (0x01B8, 18, '^는 크게 날갯짓했다.'),
    (0x01CC, 25, '^는 화염의 숨결을 내뿜었다.'),
)

def _m500_messages_ok(data: bytes) -> bool:
    return all(base.message_redirect_matches(data, 3, off, cap, text.encode('cp949'))
               for off, cap, text in _M500_MESSAGES)

def normalize_m500_redirect_layout(root: Path, check_only: bool = False) -> dict:
    p = _mon_dir(root) / 'M_500.DLL'
    data = p.read_bytes()
    if not _m500_messages_ok(data):
        return {'ok': False, 'state': 'message-mismatch', 'changed': False}
    canon = all(pos < len(data) and data[pos] == val for pos, val in _M500_REDIRECT_CANON.items())
    if canon:
        return {'ok': True, 'state': 'canonical', 'changed': False}
    fresh = all(pos < len(data) and data[pos] == val for pos, val in _M500_REDIRECT_FRESH.items())
    if not fresh:
        return {'ok': False, 'state': 'unknown-layout', 'changed': False}
    if check_only:
        return {'ok': False, 'state': 'fresh-noncanonical', 'changed': False}
    out = bytearray(data)
    for pos, val in _M500_REDIRECT_CANON.items():
        out[pos] = val
    out = bytes(out)
    if not _m500_messages_ok(out):
        raise RuntimeError('M_500 0F redirect canonicalization postcondition 실패')
    sp.atomic_write(p, out)
    return {'ok': True, 'state': 'canonicalized', 'changed': True}



def _mon_dir(root:Path)->Path:
    p=root/'MON'
    return p if p.is_dir() else root/'mon'


def apply_specials(root:Path, check_only:bool=False)->dict:
    mon=_mon_dir(root)
    report={'files':{},'changed_files':0}
    # R1 semantic/structural specials first. M_115 is intentionally normalized
    # to the compact R1 body before the full-text relocated segment is built.
    special_after={}
    for name,fn in sp.PATCHERS.items():
        p=mon/name
        if not p.is_file(): raise RuntimeError(f'파일 없음: {p}')
        before=p.read_bytes(); after=fn(before)
        changed=after!=before
        detail=sp.inspect_one(name,after); detail['changed']=changed
        if not detail['ok']: raise RuntimeError(f'{name}: integrated special postcondition 실패')
        special_after[name]=(p,before,after)
        report['files'][name]=detail
    # Full M_115 segment relocation/expansion supersedes the compact R1 text.
    p,before,compact=special_after['M_115.DLL']
    expanded=m115.build(compact); detail=m115.inspect(expanded)
    if not detail.get('ok'): raise RuntimeError('M_115 integrated full-text postcondition 실패')
    special_after['M_115.DLL']=(p,before,expanded)
    report['files']['M_115.DLL']={**detail,'changed':expanded!=before}
    report['changed_files']=sum(1 for _n,(_p,b,a) in special_after.items() if a!=b)
    if not check_only:
        for _name,(p,_before,after) in special_after.items():
            if p.read_bytes()!=after:
                sp.atomic_write(p,after)
    return report


def inspect_final(root:Path)->dict:
    mon=_mon_dir(root); files={}; ok=True
    for name in sp.PATCHERS:
        p=mon/name; data=p.read_bytes()
        d=sp.inspect_one(name,data); files[name]=d; ok &= bool(d.get('ok'))
    m=m115.inspect((mon/'M_115.DLL').read_bytes()); files['M_115_full_text']=m; ok &= bool(m.get('ok'))
    return {'ok':ok,'files':files}


def main()->int:
    ap=argparse.ArgumentParser(description=f'ED2 Monster Text reviewed-v15 integrated v{VERSION}')
    ap.add_argument('game',type=Path)
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--apply',action='store_true'); mode.add_argument('--check',action='store_true')
    ap.add_argument('--no-backup',action='store_true')
    a=ap.parse_args(); root=a.game.resolve(); csv=Path(__file__).with_name('ED2_MONSTER_TEXTS_REVIEWED_v15.csv')
    if a.check:
        base_result=base.apply_csv(root,csv,check_only=True,make_backup=False)
        canon=normalize_m500_redirect_layout(root,check_only=True)
        final=inspect_final(root)
        out={'version':VERSION,'mode':'check','base':base_result,'m500_redirect_layout':canon,'specials':final,'ok':bool(final['ok']) and bool(canon.get('ok')) and base_result.get('changed_rows',0)==0}
        print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['ok'] else 1
    base_result=base.apply_csv(root,csv,check_only=False,make_backup=not a.no_backup)
    canon=normalize_m500_redirect_layout(root,check_only=False)
    if not canon.get('ok'):
        raise RuntimeError(f"M_500 0F redirect canonicalization 실패: {canon}")
    specials=apply_specials(root,check_only=False); final=inspect_final(root)
    out={'version':VERSION,'mode':'apply','base':base_result,'m500_redirect_layout':canon,'specials':specials,'final':final,'ok':bool(final['ok']) and bool(canon.get('ok'))}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['ok'] else 1
if __name__=='__main__': raise SystemExit(main())
