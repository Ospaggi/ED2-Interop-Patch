#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, struct, tempfile
from pathlib import Path

BAD_SHA = "6f6d364fbac00c829ebc7795c748fb8b9685e0c08479525a9cf092ec5d3c4b6d"
GOOD_SHA = "b150d14be375f88f696abb84bc694d6243acf74409542529777ca4bff5428ebf"
SEG = 3
EVENT_OFF = 0x0403
EVENT_SIG = bytes.fromhex("B0 12 9A FF FF 00 00 9A FF FF 00 00 B0 3C 9A")
WAIT_RELOC_SRC = 0x040B
WAIT_IMPORT = (3, 1, 0x040B, 1, 102)
WRAPPER = bytes.fromhex(
    "9C 50 51 52 B9 C9 01 BA DA 03 EC A8 08 75 FB EC A8 08 74 FB E2 F4 5A 59 58 9D CB"
)

class MigrationError(RuntimeError): pass

def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def u16(b,o): return struct.unpack_from('<H', b, o)[0]
def u32(b,o): return struct.unpack_from('<I', b, o)[0]

def segment_record(b: bytes, index: int):
    if len(b) < 0x40 or b[:2] != b'MZ': raise MigrationError('M_502.DLL is not MZ')
    ne=u32(b,0x3c)
    if ne+0x40 > len(b) or b[ne:ne+2] != b'NE': raise MigrationError('M_502.DLL is not 16-bit NE')
    count=u16(b,ne+0x1c); table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    if not 1 <= index <= count: raise MigrationError('NE segment index out of range')
    p=table+(index-1)*8
    sec,length,flags,alloc=struct.unpack_from('<HHHH',b,p)
    return p, sec<<shift, (0x10000 if length==0 else length), flags, alloc, count, table, shift

def next_segment_base(b: bytes, index: int) -> int:
    return segment_record(b,index+1)[1]

def migrate_bytes(b: bytes) -> bytes:
    h=sha(b)
    if h == GOOD_SHA: return b
    if h != BAD_SHA: raise MigrationError(f'unsupported M_502.DLL sha256: {h}')
    sp,base,seglen,flags,alloc,*_=segment_record(b,SEG)
    if not (flags & 0x0100): raise MigrationError('segment 3 has no relocation table')
    if b[base+EVENT_OFF:base+EVENT_OFF+len(EVENT_SIG)] != EVENT_SIG:
        raise MigrationError('Gabi event signature mismatch')
    roff=base+seglen
    cnt=u16(b,roff); rend=roff+2+cnt*8; nxt=next_segment_base(b,SEG)
    if rend > nxt: raise MigrationError('relocation table overlaps next segment')
    hits=[]
    for i in range(cnt):
        p=roff+2+i*8; r=struct.unpack_from('<BBHHH',b,p)
        if r[2] == WAIT_RELOC_SRC: hits.append((i,r))
    if len(hits) != 1: raise MigrationError(f'WAIT_BGM relocation count mismatch: {len(hits)}')
    idx,r=hits[0]
    wo=r[4]
    if not (r[0]==3 and r[1]==0 and r[3]==SEG): raise MigrationError('legacy relocation is not the exact internal redirect')
    if wo+len(WRAPPER) != seglen: raise MigrationError('legacy wrapper is not the exact segment tail')
    if b[base+wo:base+wo+len(WRAPPER)] != WRAPPER: raise MigrationError('legacy wrapper bytes differ')
    blob=bytearray(b[roff:rend])
    struct.pack_into('<BBHHH',blob,2+idx*8,*WAIT_IMPORT)
    newlen=wo; newroff=base+newlen; newrend=newroff+len(blob)
    if newrend > nxt: raise MigrationError('retail relocation placement overlaps next segment')
    x=bytearray(b)
    x[newroff:newrend]=blob
    x[newrend:nxt]=b'\0'*(nxt-newrend)
    struct.pack_into('<H',x,sp+2,newlen)
    if alloc: struct.pack_into('<H',x,sp+6,newlen)
    out=bytes(x)
    if sha(out) != GOOD_SHA: raise MigrationError(f'migration output sha mismatch: {sha(out)}')
    return out

def locate(root: Path) -> Path:
    p=root/'MON'/'M_502.DLL'
    if p.is_file(): return p
    if not (root/'MON').is_dir(): raise MigrationError('MON directory not found')
    hits=[x for x in (root/'MON').iterdir() if x.is_file() and x.name.lower()=='m_502.dll']
    if len(hits)!=1: raise MigrationError(f'M_502.DLL candidate count: {len(hits)}')
    return hits[0]

def atomic_write(path: Path, data: bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def main() -> int:
    ap=argparse.ArgumentParser(description='ED2 v1.4.62/v1.4.63 M_502 generation migration')
    ap.add_argument('game_root'); ap.add_argument('--apply',action='store_true'); ap.add_argument('--check',action='store_true')
    a=ap.parse_args(); p=locate(Path(a.game_root).resolve()); b=p.read_bytes(); h=sha(b)
    if a.check:
        print('state:', 'current-retail-wait' if h==GOOD_SHA else ('legacy-v1462-v1463-redirect' if h==BAD_SHA else 'unsupported'))
        print('sha256:',h); return 0 if h in (GOOD_SHA,BAD_SHA) else 1
    if not a.apply: ap.error('use --apply or --check')
    out=migrate_bytes(b)
    if out != b: atomic_write(p,out); print('M_502 generation migration: legacy redirect -> retail WAIT_BGM')
    else: print('M_502 generation migration: already retail WAIT_BGM')
    print('sha256:',sha(out)); return 0

if __name__=='__main__': raise SystemExit(main())
