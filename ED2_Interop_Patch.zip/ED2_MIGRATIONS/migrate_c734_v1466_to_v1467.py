#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, tempfile
from pathlib import Path

SOURCE_SHA = 'a9b7f3661a2bbcdf87d3f4ae1e6ebec4078bd885c110e1e5dc20c10b1702bc12'
TARGET_SHA = '0bc55b77dbb5903248e93ef9c468b473639f4524a9b61d049313043d8cb1f759'
DELTA = Path(__file__).resolve().parent / 'data' / 'c734_v1466_to_v1467.ed2delta'

class MigrationError(RuntimeError): pass

def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()

def atomic(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name+'.v1467.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def load_codec():
    root = Path(__file__).resolve().parent.parent
    codec = root / 'ED2_Text_and_Dialogue_v5.0R17_Combined' / 'internal' / 'ed2_delta.py'
    if not codec.is_file(): raise MigrationError(f'delta codec missing: {codec}')
    spec = importlib.util.spec_from_file_location('ed2_delta_v1467', codec)
    if spec is None or spec.loader is None: raise MigrationError('delta codec import failed')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def state(root: Path) -> dict[str, object]:
    p = root / 'SCENA' / 'C_734.DLL'
    if not p.is_file(): raise MigrationError(f'파일 없음: {p}')
    h = sha(p.read_bytes())
    return {'ok': h in (SOURCE_SHA, TARGET_SHA), 'state': 'target' if h == TARGET_SHA else ('v1.4.66' if h == SOURCE_SHA else 'unknown'), 'sha256': h}

def apply(root: Path) -> dict[str, object]:
    p = root / 'SCENA' / 'C_734.DLL'; before = p.read_bytes(); h = sha(before)
    if h == TARGET_SHA: return {'ok': True, 'changed': False, 'state': 'target', 'sha256': h}
    if h != SOURCE_SHA: raise MigrationError(f'C_734 v1.4.66 migration source mismatch: {h}')
    if not DELTA.is_file(): raise MigrationError(f'delta missing: {DELTA}')
    out = load_codec().apply_named(before, DELTA, 'C_734.DLL')
    if sha(out) != TARGET_SHA: raise MigrationError('C_734 migration target verification failed')
    atomic(p, out)
    return {'ok': True, 'changed': True, 'state': 'target', 'sha256': TARGET_SHA}

def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('root',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    try: r=state(a.root.resolve()) if a.check else apply(a.root.resolve())
    except Exception as e:
        print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False)); return 2
    print(json.dumps(r,ensure_ascii=False,indent=2)); return 0 if r.get('ok') else 2
if __name__=='__main__': raise SystemExit(main())
