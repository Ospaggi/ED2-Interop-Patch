@echo off
chcp 65001 >nul
py -3 "%~dp0ed2_stability_qol.py" %*
if errorlevel 1 pause
