#!/usr/bin/env python3
"""ED2 MON battle-message presentation fixes v0.2.8.

v0.2.8 extends v0.2.7 and accepts the reviewed-v14/R1-owned final streams; v0.2.7 extends v0.2.6, which merges the former standalone Kajasum battle-text repair into this
component and owns the handful of shifted MON streams that cannot safely be
edited by the broad Monster Text CSV pass.  The established v0.2.5 logic is
kept as an internal compatibility core.
"""
from __future__ import annotations
import argparse, importlib.util, os, stat, struct, sys, tempfile
from pathlib import Path

VERSION = "0.2.8"
HERE = Path(__file__).resolve().parent
CORE_PATH = HERE / "ed2_monster_text_presentation_fix_v025_core.py"

class ToolError(RuntimeError):
    pass

def _load_core():
    spec = importlib.util.spec_from_file_location("ed2_monster_text_presentation_v025_core", CORE_PATH)
    if spec is None or spec.loader is None:
        raise ToolError("v0.2.5 compatibility core를 불러올 수 없습니다")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

core = _load_core()
Segment = core.Segment
parse_segments = core.parse_segments
relocation_sources = core.relocation_sources


def atomic_preserve(path: Path, data: bytes) -> None:
    mode = stat.S_IMODE(path.stat().st_mode)
    made_write = False
    if not (mode & stat.S_IWUSR):
        try:
            os.chmod(path, mode | stat.S_IWUSR)
            made_write = True
        except OSError:
            pass
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".monpresent027.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        try: os.chmod(tmp, mode | stat.S_IWUSR)
        except OSError: pass
        os.replace(tmp, path)
        try: os.chmod(path, mode)
        except OSError: pass
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        if made_write:
            try: os.chmod(path, mode)
            except OSError: pass
        raise


def _mon_dir(root: Path) -> Path:
    mon = root / "MON"
    if not mon.is_dir(): mon = root / "mon"
    if not mon.is_dir(): raise ToolError("MON 폴더를 찾을 수 없습니다")
    return mon


# ---------------------------------------------------------------------------
# v0.2.8 compatibility: reviewed-v14/R1 owns four post-presentation streams.
# These helpers only recognize those exact final states; the v0.2.7 apply path
# remains unchanged for stock / older inputs.
# ---------------------------------------------------------------------------
def _cp949_split_boundaries(encoded: bytes, maximum: int) -> list[int]:
    maximum=min(maximum,len(encoded)); out=[]
    for pos in range(maximum,-1,-1):
        try:
            encoded[:pos].decode('cp949'); encoded[pos:].decode('cp949')
        except UnicodeDecodeError:
            continue
        out.append(pos)
    return out


def _redirect_descriptor(raw_editable: bytes, encoded: bytes, fill: int=0xFF):
    for pos in _cp949_split_boundaries(encoded,max(0,len(raw_editable)-3)):
        if raw_editable[:pos] != encoded[:pos]: continue
        if pos+3 > len(raw_editable) or raw_editable[pos] != 0x0F: continue
        if raw_editable[pos+3:] != bytes((fill,))*(len(raw_editable)-pos-3): continue
        return pos, struct.unpack_from('<H',raw_editable,pos+1)[0]
    return None


def _message_redirect_matches(data: bytes, segment_index: int, offset: int, editable: int, encoded: bytes, *, fill: int=0xFF) -> bool:
    segs=parse_segments(data)
    if not 1 <= segment_index <= len(segs) or editable < 3: return False
    seg=segs[segment_index-1]; base=seg.file_offset
    if offset < 0 or offset+editable > seg.length: return False
    raw=bytes(data[base+offset:base+offset+editable])
    desc=_redirect_descriptor(raw,bytes(encoded),fill)
    if desc is None: return False
    prefix_len,pointer=desc
    payload=bytes(encoded)[prefix_len:] + b'\x0F' + struct.pack('<H',offset+editable)
    return pointer+len(payload) <= seg.length and bytes(data[base+pointer:base+pointer+len(payload)]) == payload


def _r1_state(path: Path, dll: str) -> bool:
    data=path.read_bytes(); seg=parse_segments(data)[2]; base=seg.file_offset
    cp=lambda t:t.encode('cp949')
    if dll=='M_001.DLL':
        return _message_redirect_matches(data,3,0x017F,27,cp('^를 차가운 시선으로 바라보았다.'))
    if dll=='M_115.DLL':
        return (data[base+0x01D9:base+0x01D9+len(cp('앞으로 나섰다.'))] == cp('앞으로 나섰다.') and
                data[base+0x01ED:base+0x01ED+len(cp('머리가 갈라졌다.'))] == cp('머리가 갈라졌다.'))
    if dll=='M_400.DLL':
        return (_message_redirect_matches(data,3,0x01FD,25,cp('의 앞에 나서 주문을 받았다.')) and
                _message_redirect_matches(data,3,0x0224,23,cp('의 앞에 나서 검을 맞았다.')))
    if dll=='M_401.DLL':
        return (data[base+0x0278:base+0x0278+15] == cp('너희 따위에게 ')+b'\xFF' and
                data[base+0x028E:base+0x028E+23] == b'\x01'+cp('내가 쓰러질 순 없다!')+b'\xFF'*2 and
                data[base+0x02C2:base+0x02C2+3] == b'\xFF'*3 and
                data[base+0x02C5:base+0x02C5+8] == cp('우리는 ')+b'\xFF' and
                data[base+0x02CD:base+0x02CD+3] == bytes.fromhex('10 94 02'))
    return False

# ---------------------------------------------------------------------------
# Former ED2_Kajasm_Battle_Text_Fix_v0.1.1, now owned here.
# ---------------------------------------------------------------------------
KAJASM_DLL = "M_401.DLL"

def _find_relocs(data: bytes, seg: Segment):
    if not (seg.flags & 0x0100):
        raise ToolError("M_401 segment 3에 relocation table이 없습니다")
    pos = seg.file_offset + seg.length
    if pos + 2 > len(data): raise ToolError("M_401 relocation count가 잘렸습니다")
    count = struct.unpack_from("<H", data, pos)[0]
    if pos + 2 + count * 8 > len(data): raise ToolError("M_401 relocation table이 잘렸습니다")
    rows = []
    for i in range(count):
        q = pos + 2 + i * 8
        st, fl, src, t1, t2 = struct.unpack_from("<BBHHH", data, q)
        rows.append((i, q, st, fl, src, t1, t2))
    return rows


def _kajasm_payloads():
    wall = bytearray("그 정도의 화염으로는 이 벽을 깰 수 없다고.".encode("cp949"))
    br = len("그 정도의 화염으로는".encode("cp949"))
    if wall[br] != 0x20: raise AssertionError("Kajasm wall linebreak boundary mismatch")
    wall[br] = 0x01
    wall = bytes(wall) + b"\xff\xff\xff"
    phrase = b"\x01\xff" + "나는 쓰러지지 않는다.".encode("cp949")
    return {
        0x0218: wall,
        # Kajasum is the only speaker/monster for this fixed stream and ends
        # in a final consonant. Keep the already-correct '이 나타났다.' here;
        # generic dynamic selectors are used everywhere the name is dynamic.
        0x0250: "이 나타났다.".encode("cp949"),
        0x028E: phrase,
        0x02C5: "우리는 ".encode("cp949") + b"\xff",
        0x02D2: b"^" + "는 ".encode("cp949") + b"\x10\x00\x00\x0f\x00\x00",
        0x0209: b"\x02\x0f\xd2\x02\xff\xff\xff\xff\xff",
    }


def _find_kajasm_record(data: bytes):
    for text in ("카자줌", "카자즘"):
        raw = text.encode("cp949")
        start = 0
        while True:
            pos = data.find(raw, start)
            if pos < 0: break
            suffix = data[pos+len(raw):pos+len(raw)+3]
            if suffix in {b"\x06\x06\x06", b"\x06\x00\x00"}:
                return pos, raw, text, suffix
            start = pos + 1
    return -1, None, None, b""


def inspect_kajasm(path: Path) -> dict:
    if _r1_state(path, "M_401.DLL"):
        return {"ok":True,"checks":{"reviewed_v14_r1":True},"name":"카자줌","record_offset":None,"r1_owned":True}
    data = path.read_bytes(); segs = parse_segments(data)
    if len(segs) < 3: raise ToolError("M_401 segment 3이 없습니다")
    seg = segs[2]; checks = {}
    for off, payload in _kajasm_payloads().items():
        cur = data[seg.file_offset+off:seg.file_offset+off+len(payload)]
        checks[f"seg3:0x{off:04X}"] = cur == payload
    sub = "쓰러지지 않는다.".encode("cp949")
    checks["shared_0x0295"] = data[seg.file_offset+0x0295:seg.file_offset+0x0295+len(sub)] == sub
    rel = _find_relocs(data, seg)
    wanted = {(0x02D7,0x03B4),(0x02DA,0x03C1)}
    actual = {(src,t2) for _,_,st,fl,src,t1,t2 in rel if st==0x05 and fl==0x05 and t1==1 and t2 in {0x03B4,0x03C1}}
    checks["relocations"] = actual == wanted
    npos, name, found_name, suffix = _find_kajasm_record(data)
    checks["record_06_06"] = npos >= 0 and suffix == b"\x06\x06\x06"
    return {"ok": all(checks.values()), "checks": checks, "name": found_name, "record_offset": None if npos < 0 else npos}


def apply_kajasm(root: Path, *, check_only: bool=False) -> tuple[int,int,dict]:
    path = _mon_dir(root) / KAJASM_DLL
    if not path.is_file(): raise ToolError(f"파일 없음: {path}")
    detail = inspect_kajasm(path)
    if detail["ok"]: return 0,1,detail
    if check_only: raise ToolError("통합 카자줌 전투 문구 수정이 미적용 상태입니다")
    before = path.read_bytes(); segs = parse_segments(before); seg = segs[2]
    after = bytearray(before)
    npos, name, _found_name, suffix = _find_kajasm_record(before)
    if npos < 0 or name is None: raise ToolError("카자줌/카자즘 이름 레코드를 찾지 못했습니다")
    if suffix not in {b"\x06\x06\x06", b"\x06\x00\x00"}:
        raise ToolError(f"예상하지 못한 카자줌 레코드 suffix: {suffix.hex(' ')}")
    after[npos+len(name):npos+len(name)+3] = b"\x06\x06\x06"
    for off,payload in _kajasm_payloads().items():
        after[seg.file_offset+off:seg.file_offset+off+len(payload)] = payload
    found = {0x03B4:False,0x03C1:False}
    for _,q,st,fl,src,t1,t2 in _find_relocs(before,seg):
        if st==0x05 and fl==0x05 and t1==1 and t2 in found:
            accepted = {0x03B4:{0x020D,0x02D7},0x03C1:{0x0210,0x02DA}}[t2]
            if src not in accepted:
                raise ToolError(f"예상하지 못한 M_401 relocation: target={t2:04X} source={src:04X}")
            new_src = 0x02D7 if t2==0x03B4 else 0x02DA
            struct.pack_into("<H",after,q+2,new_src); found[t2]=True
    if not all(found.values()): raise ToolError(f"필수 M_401 relocation을 찾지 못했습니다: {found}")
    final = bytes(after)
    if len(final) != len(before): raise ToolError("M_401 파일 크기가 변경되었습니다")
    if [(s.file_offset,s.length,s.flags,s.min_alloc) for s in parse_segments(final)] != [(s.file_offset,s.length,s.flags,s.min_alloc) for s in segs]:
        raise ToolError("M_401 NE segment geometry가 변경되었습니다")
    atomic_preserve(path, final)
    detail = inspect_kajasm(path)
    if not detail["ok"]: raise ToolError("통합 카자줌 적용 후 검증 실패")
    return 1,0,detail


# ---------------------------------------------------------------------------
# v0.2.6-owned post-v12 stream upgrades.
# These are exact fixed-area transforms.  They only consume existing FF/00
# slack and adjust explicitly-audited near-pointer immediates; no segment or
# relocation geometry moves.
# ---------------------------------------------------------------------------
def H(s: str) -> bytes: return bytes.fromhex(s)

SPECIAL_STREAMS = [
    {"dll":"M_002.DLL","start":0x026B,"old":H("02BFCD200602B0A120B5C7BEFAB4D92E0A00000000"),"new":H("02BFCD2006025EB0A120B5C7BEFAB4D92E0A000000"),"ptrs":[]},
    {"dll":"M_106.DLL","start":0x01D6,"old":H("200602C0C720C6C8C0BB20C7AEBEFAB4D90A0000000000000000"),"new":H("200602C0C720C6C8C0BB20C7AEBEFAB4D92E0A00000000000000"),"ptrs":[]},
    {"dll":"M_115.DLL","start":0x01C6,"old":H("200602BFA1B0D4200602B4C2200904C0C701BED5BFA120B3AAC5B8B3B5B4D90A025EB4C220B8D3B8AEB0A120BAD0BFADC7DFB4D90A0000000000"),"new":H("200602BFA1B0D42006025EB4C2200904C0C701BED5BFA120B3AAC5B8B3B5B4D92E0A025EB4C220B8D3B8AEB0A120BAD0BFADC7DFB4D92E0A0000"),"ptrs":[(0x02CE,H("BEC801"),H("BEC801")),(0x0315,H("BEE601"),H("BEE801")),(0x03AE,H("BECF01"),H("BECF01"))]},
    {"dll":"M_202.DLL","start":0x0218,"old":H("200602C0C720B0A1BDBFC0BB01C1B6BFB4B4D90A00000000"),"new":H("200602C0C720B0A1BDBFC0BB01C1B6BFB4B4D92E0A000000"),"ptrs":[(0x02C7,H("BE1A02"),H("BE1A02"))]},
    {"dll":"M_207.DLL","start":0x01C0,"old":H("2006025EB4C220C3D6C8C4C0C720C8FBC0BB20B8F0B5CE20B8F0BEC60702BFA1B0D420B7B9BDBAB8A620BFDCBFFCB4D90A5EB4C220B5B5B8C1C3C6B4D90A0000"),"new":H("2006025EB4C220C3D6C8C4C0C720C8FBC0BB20B8F0B5CE20B8F0BEC60702BFA1B0D420B7B9BDBAB8A620BFDCBFFCB4D92E0A5EB4C220B5B5B8C1C3C6B4D92E0A"),"ptrs":[(0x02CF,H("BEF101"),H("BEF201")),(0x0303,H("BEC201"),H("BEC201"))]},
    # M_210's sentence-ending periods are already supplied by Monster v12
    # message_0f targets.  Only the hidden dynamic-name + fixed '가' boundary
    # is shifted here; two local BE targets move by one byte.
    {"dll":"M_210.DLL","start":0x01B0,"old":H("200F6E03FF02B0A101B4DEB7C10F8E03FF0A025EB4C220B5B6C0BB20C1DFC8AD0F9603FF0A025EB4C220B5B6C0BB20C1DFC8ADC7CFC1F620B8F80F9E03FF0A00"),"new":H("200F6E03FF025EB0A101B4DEB7C10F8E03FF0A025EB4C220B5B6C0BB20C1DFC8AD0F9603FF0A025EB4C220B5B6C0BB20C1DFC8ADC7CFC1F620B8F80F9E03FF0A"),"ptrs":[(0x0347,H("BEC201"),H("BEC301")),(0x0350,H("BED501"),H("BED601"))]},
    {"dll":"M_211.DLL","start":0x0212,"old":H("200602C0BB20B3EBB7C8B4D92EFFFFFFFFFFFFFFFFFFFFFFFF"),"new":H("2006025EC0BB20B3EBB7C8B4D92EFFFFFFFFFFFFFFFFFFFFFF"),"ptrs":[]},
    {"dll":"M_408.DLL","start":0x01A8,"old":H("200904B8A620C0E7C3CBC7DFB4D92E0A0905BFA1B0D420C0E7C3CBB4E7C7DF0F340302B4C220BFACBCD320B0F8B0DDC0BB20C7DFB4D92121075EB4C220B2BFB8AEB7CE20B0F8B0DDC7DFB4D92E0A0000"),"new":H("200904B8A620C0E7C3CBC7DFB4D92E0A0905BFA1B0D420C0E7C3CBB4E7C7DF0F3403025EB4C220BFACBCD320B0F8B0DDC0BB20C7DFB4D92121075EB4C220B2BFB8AEB7CE20B0F8B0DDC7DFB4D92E0A00"),"ptrs":[(0x027C,H("BEB801"),H("BEB801")),(0x02F9,H("BEE101"),H("BEE201"))]},
]


def _inspect_special(path: Path, spec: dict) -> dict:
    data = path.read_bytes(); seg = parse_segments(data)[2]; base = seg.file_offset
    cur = data[base+spec["start"]:base+spec["start"]+len(spec["new"])]
    rel = relocation_sources(data,seg); ptrs=[]; ok = cur == spec["new"]
    for off,_old,new in spec["ptrs"]:
        got=data[base+off:base+off+len(new)]
        overlap=any(off <= r < off+len(new) for r in rel)
        ptrs.append({"offset":f"0x{off:04X}","ok":got==new and not overlap,"bytes":got.hex()})
        ok = ok and got == new and not overlap
    return {"ok":ok,"stream":cur.hex(),"pointers":ptrs,"segment_length":seg.length,"segment_min_alloc":seg.min_alloc}


def apply_specials(root: Path, *, check_only: bool=False) -> tuple[int,int,dict]:
    mon=_mon_dir(root); changed=already=0; details={}
    for spec in SPECIAL_STREAMS:
        path=mon/spec["dll"]
        if not path.is_file(): raise ToolError(f"파일 없음: {path}")
        before=path.read_bytes(); segs=parse_segments(before); seg=segs[2]; base=seg.file_offset
        cur=before[base+spec["start"]:base+spec["start"]+len(spec["old"])]
        ptrvals=[before[base+off:base+off+len(old)] for off,old,_new in spec["ptrs"]]
        if cur == spec["new"] and all(v==new for v,(_o,_old,new) in zip(ptrvals,spec["ptrs"])):
            already += 1; details[spec["dll"]]=_inspect_special(path,spec); continue
        if cur != spec["old"]:
            raise ToolError(f"{spec['dll']} seg3:{spec['start']:04X}: v0.2.6 특수 스트림 상태 불일치: {cur.hex()}")
        rel=relocation_sources(before,seg)
        for val,(off,old,_new) in zip(ptrvals,spec["ptrs"]):
            if val != old: raise ToolError(f"{spec['dll']} seg3:{off:04X}: 특수 포인터 상태 불일치: {val.hex()}")
            if any(off <= r < off+len(old) for r in rel):
                raise ToolError(f"{spec['dll']} seg3:{off:04X}: 특수 포인터가 relocation source와 겹칩니다")
        if check_only: raise ToolError(f"{spec['dll']} v0.2.6 특수 전투 문구가 미적용 상태입니다")
        after=bytearray(before)
        after[base+spec["start"]:base+spec["start"]+len(spec["new"])] = spec["new"]
        for off,_old,new in spec["ptrs"]:
            after[base+off:base+off+len(new)] = new
        final=bytes(after)
        if len(final)!=len(before): raise ToolError(f"{spec['dll']}: file size changed")
        if [(s.file_offset,s.length,s.flags,s.min_alloc) for s in parse_segments(final)] != [(s.file_offset,s.length,s.flags,s.min_alloc) for s in segs]:
            raise ToolError(f"{spec['dll']}: NE geometry changed")
        # Relocation blob and every relocation record must remain identical.
        old_rel = core.relocation_blob(before,seg)
        new_seg=parse_segments(final)[2]
        if core.relocation_blob(final,new_seg) != old_rel:
            raise ToolError(f"{spec['dll']}: relocation table changed")
        atomic_preserve(path,final); changed += 1
        detail=_inspect_special(path,spec)
        if not detail["ok"]: raise ToolError(f"{spec['dll']}: v0.2.6 postcondition failed")
        details[spec["dll"]]=detail
    return changed,already,details



# ---------------------------------------------------------------------------
# v0.2.7: particle + literal-name boundary spacing.
# A 1Eh...04h literal field does not consume a visible blank.  These streams
# therefore rendered e.g. ``그로그 가드는번개의 지팡이를 사용했다.``.
# Shift only the payload inside existing FF padding; terminators and pointers
# stay at their original offsets.
# ---------------------------------------------------------------------------
LITERAL_BOUNDARY_SPECS = [
    {
        "dll":"M_127.DLL", "start":0x0191,
        "old": bytes.fromhex("02 5E B4 C2 1E B9 F8 B0 B3 C0 C7 20 C1 F6 C6 CE C0 CC 04 B8 A6 20 BB E7 BF EB C7 DF B4 D9 2E 20 C0 CC B1 D7 B3 AA 20 C8 BF B0 FA B0 A1 20 C0 D6 B4 D9 2E FF"),
        "new": bytes.fromhex("02 5E B4 C2 20 1E B9 F8 B0 B3 C0 C7 20 C1 F6 C6 CE C0 CC 04 B8 A6 20 BB E7 BF EB C7 DF B4 D9 2E 20 C0 CC B1 D7 B3 AA 20 C8 BF B0 FA B0 A1 20 C0 D6 B4 D9 2E"),
    },
    {
        "dll":"M_400.DLL", "start":0x01F0,
        "old": bytes.fromhex("02 5E B4 C2 1E B5 F0 B0 D5 BD BA 04 C0 C7 20 BE D5 BF A1 BC AD 20 C1 D6 B9 AE C0 BB 20 B9 DE BE D2 B4 D9 2E FF FF"),
        "new": bytes.fromhex("02 5E B4 C2 20 1E B5 F0 B0 D5 BD BA 04 C0 C7 20 BE D5 BF A1 BC AD 20 C1 D6 B9 AE C0 BB 20 B9 DE BE D2 B4 D9 2E FF"),
    },
    {
        "dll":"M_400.DLL", "start":0x0217,
        "old": bytes.fromhex("02 5E B4 C2 1E B5 F0 B0 D5 BD BA 04 C0 C7 20 BE D5 BF A1 BC AD 20 B0 CB C0 BB 20 B8 C2 BE D2 B4 D9 2E FF FF"),
        "new": bytes.fromhex("02 5E B4 C2 20 1E B5 F0 B0 D5 BD BA 04 C0 C7 20 BE D5 BF A1 BC AD 20 B0 CB C0 BB 20 B8 C2 BE D2 B4 D9 2E FF"),
    },
]

def _inspect_literal_boundary(path: Path, spec: dict) -> dict:
    data=path.read_bytes(); seg=parse_segments(data)[2]; base=seg.file_offset
    cur=data[base+spec["start"]:base+spec["start"]+len(spec["new"])]
    rel=relocation_sources(data,seg)
    overlap=any(spec["start"] <= r < spec["start"]+len(spec["new"]) for r in rel)
    return {"ok":cur==spec["new"] and not overlap, "start":f"0x{spec['start']:04X}",
            "stream":cur.hex(), "relocation_overlap":overlap}

def apply_literal_boundaries(root: Path, *, check_only: bool=False) -> tuple[int,int,list[dict]]:
    mon=_mon_dir(root); changed=already=0; details=[]
    for spec in LITERAL_BOUNDARY_SPECS:
        path=mon/spec["dll"]; before=path.read_bytes(); segs=parse_segments(before); seg=segs[2]; base=seg.file_offset
        cur=before[base+spec["start"]:base+spec["start"]+len(spec["old"])]
        rel=relocation_sources(before,seg)
        if any(spec["start"] <= r < spec["start"]+len(spec["old"]) for r in rel):
            raise ToolError(f"{spec['dll']} seg3:{spec['start']:04X}: literal spacing 영역이 relocation source와 겹칩니다")
        if cur==spec["new"]:
            already+=1; details.append({"dll":spec["dll"], **_inspect_literal_boundary(path,spec)}); continue
        if cur!=spec["old"]:
            raise ToolError(f"{spec['dll']} seg3:{spec['start']:04X}: literal spacing 상태 불일치: {cur.hex()}")
        if check_only: raise ToolError(f"{spec['dll']} literal-name 경계 공백이 미적용 상태입니다")
        after=bytearray(before); after[base+spec["start"]:base+spec["start"]+len(spec["new"])]=spec["new"]
        final=bytes(after)
        if len(final)!=len(before): raise ToolError(f"{spec['dll']}: literal spacing이 파일 크기를 변경했습니다")
        if [(s.file_offset,s.length,s.flags,s.min_alloc) for s in parse_segments(final)] != [(s.file_offset,s.length,s.flags,s.min_alloc) for s in segs]:
            raise ToolError(f"{spec['dll']}: literal spacing이 NE geometry를 변경했습니다")
        if core.relocation_blob(final,parse_segments(final)[2]) != core.relocation_blob(before,seg):
            raise ToolError(f"{spec['dll']}: literal spacing이 relocation table을 변경했습니다")
        atomic_preserve(path,final); changed+=1
        d=_inspect_literal_boundary(path,spec)
        if not d["ok"]: raise ToolError(f"{spec['dll']}: literal spacing postcondition 실패")
        details.append({"dll":spec["dll"], **d})
    return changed,already,details

def inspect_final(root: Path) -> dict:
    mon=_mon_dir(root); details={}; ok=True
    # Established v0.2.5 features that are unaffected by v0.2.6 stream upgrades.
    ed=core.inspect_dynamic_name_guard(root/"ED2MAIN.EXE")
    domi=core.inspect_domi_damage_boundary(mon/core.DOMI_DLL)
    red=core.inspect_red_slime_name_layout(mon/core.RED_SLIME_DLL)
    terms={}
    for spec in core.NAME_TERMINATOR_FIXES:
        # inspect helper signature in core accepts path/spec
        try:
            detail=core.inspect_hidden_suffix_terminator(mon/spec["dll"],spec)
        except AttributeError:
            detail=None
        if detail is not None: terms[spec["dll"]]=detail
    kaj=inspect_kajasm(mon/KAJASM_DLL)
    specs={}
    for spec in SPECIAL_STREAMS:
        if spec["dll"] == "M_115.DLL" and _r1_state(mon/spec["dll"], "M_115.DLL"):
            d={"ok":True,"reviewed_v14_r1":True}
        else:
            d=_inspect_special(mon/spec["dll"],spec)
        specs[spec["dll"]]=d; ok=ok and d["ok"]
    # Core linebreak OPS stay exact.
    linebreaks={}
    for dll,off,left,right in core.OPS:
        if dll == "M_325.DLL":
            # v14 uses the longer PC-98-faithful wording and moves the intentional
            # break after "달아날" to 01A4.  Older v12/v13 final states remain
            # accepted at 01A1 so base/finalize stays backward-compatible.
            data=(mon/dll).read_bytes(); seg=parse_segments(data)[2]; rel=relocation_sources(data,seg)
            b1=data[seg.file_offset+0x01A1:seg.file_offset+0x01A2]
            b4=data[seg.file_offset+0x01A4:seg.file_offset+0x01A5]
            use=0x01A4 if b4==b"\x01" else 0x01A1
            got=data[seg.file_offset+use:seg.file_offset+use+1]
            d={"ok":got==b"\x01" and use not in rel,"offset":f"0x{use:04X}","byte":got.hex(),"relocation_source":use in rel}
        else:
            d=core.inspect_one(mon/dll,off,left,right)
        linebreaks[dll]=d; ok=ok and d["ok"]
    # Dynamic spacing specs not superseded by a special v0.2.6 stream stay exact.
    superseded={s["dll"] for s in SPECIAL_STREAMS}
    if _r1_state(mon/"M_001.DLL", "M_001.DLL"):
        superseded.add("M_001.DLL")
    spacing={}
    for spec in core.DYNAMIC_MESSAGE_SPACING_SPECS:
        if spec["dll"] in superseded: continue
        d=core.inspect_dynamic_message_spacing(mon/spec["dll"],spec); spacing[spec["dll"]]=d; ok=ok and d["ok"]
    literal=[]
    for spec in LITERAL_BOUNDARY_SPECS:
        if spec["dll"] == "M_400.DLL" and _r1_state(mon/spec["dll"], "M_400.DLL"):
            d={"ok":True,"reviewed_v14_r1":True,"start":f"0x{spec['start']:04X}"}
        else:
            d=_inspect_literal_boundary(mon/spec["dll"],spec)
        literal.append({"dll":spec["dll"],**d}); ok=ok and d["ok"]
    ok=ok and ed["ok"] and domi["ok"] and red["ok"] and kaj["ok"]
    if terms: ok=ok and all(x.get("ok",False) for x in terms.values())
    return {"version":VERSION,"ok":ok,"dynamic_battle_name_preflight":ed,"domi_damage_boundary":domi,
            "red_slime_name_layout":red,"hidden_suffix_terminators":terms,"kajasm_merged":kaj,
            "special_streams":specs,"literal_name_spacing":literal,"linebreaks":linebreaks,"dynamic_spacing_unsuperseded":spacing}


def apply_base(root: Path, *, check_only: bool=False) -> dict:
    # A fully-final state is also a valid base state; do not feed v0.2.6 bytes
    # back into the older exact-state core.
    try:
        final=inspect_final(root)
        if final["ok"]:
            return {"version":VERSION,"phase":"base","ok":True,"changed":0,"already":1,"final_already":True}
    except Exception:
        pass
    if check_only:
        # v0.2.5 check is intentionally strict and non-mutating.
        base=core.apply(root,check_only=True)
        kaj=inspect_kajasm(_mon_dir(root)/KAJASM_DLL)
        if not kaj["ok"]: raise ToolError("통합 카자줌 base가 미적용 상태입니다")
        return {"version":VERSION,"phase":"base","ok":bool(base.get("ok")) and kaj["ok"],"changed":0,"already":base.get("already",0)+1}
    base=core.apply(root,check_only=False)
    kc,ka,kd=apply_kajasm(root,check_only=False)
    return {"version":VERSION,"phase":"base","ok":bool(base.get("ok")) and kd["ok"],"changed":base.get("changed",0)+kc,"already":base.get("already",0)+ka,"core":base,"kajasm_merged":kd}


def finalize(root: Path, *, check_only: bool=False) -> dict:
    try:
        final=inspect_final(root)
        if final["ok"]:
            return {"version":VERSION,"phase":"finalize","ok":True,"changed":0,"already":len(SPECIAL_STREAMS)+len(LITERAL_BOUNDARY_SPECS),"details":final}
    except Exception:
        final=None
    c,a,d=apply_specials(root,check_only=check_only)
    lc,la,ld=apply_literal_boundaries(root,check_only=check_only)
    final=inspect_final(root)
    if not final["ok"]: raise ToolError("v0.2.8 최종 Presentation postcondition 실패")
    return {"version":VERSION,"phase":"finalize","ok":True,"changed":c+lc,"already":a+la,
            "special_streams":d,"literal_name_spacing":ld,"details":final}


def main() -> int:
    ap=argparse.ArgumentParser(description=f"ED2 Monster Text Presentation Fix v{VERSION} (Kajasm merged + reviewed-v14/R1 compatibility)")
    ap.add_argument("game",type=Path)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--base",action="store_true",help="v0.2.5 compatibility core + merged Kajasum base")
    g.add_argument("--finalize",action="store_true",help="Monster v12 이후 v0.2.8 호환 조사/온점/경계 공백 적용")
    g.add_argument("--check",action="store_true",help="v0.2.8 최종 상태 검사")
    args=ap.parse_args(); root=args.game.expanduser().resolve()
    try:
        if args.base: r=apply_base(root,check_only=False)
        elif args.finalize: r=finalize(root,check_only=False)
        else:
            r=inspect_final(root)
            if not r["ok"]: raise ToolError("Monster Text Presentation v0.2.8 최종 상태가 아닙니다")
        print(r); return 0
    except Exception as e:
        print(f"ERROR: {e}"); return 1

if __name__=="__main__":
    raise SystemExit(main())
