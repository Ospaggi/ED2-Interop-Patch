@echo off
python ed2_joshua_scrollable_underground_map.py --check
pause
