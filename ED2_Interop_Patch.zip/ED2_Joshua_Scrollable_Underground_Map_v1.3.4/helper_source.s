.code16
.text
.global _start

.set MG_DISP_MAP, 0xA182
.set FIELD_UN_PACK, 0x831B
.set UDG_UN_PACK, 0xB494
.set ORIG_COORD_UPDATE, 0xA387

# DS globals (segment 85)
.set MP_NUM_WORD, 0x2002      # low=MP_NUM, high=MAP_MASK
.set MAP_KIND_FLAG, 0x200B
.set SIN_NO_HI, 0x200A
.set UG_MAP_NO, 0x2050
.set PLAYER_YX, 0x2202        # low=Y, high=X

_start:
joshua_entry:
    # Only G_*.DLL scenes are underground-dungeon scenes. Preserve caller AX
    # because stock MG_DISP_MAP itself preserves all general registers.
    push %ax
    movb SIN_NO_HI, %al
    andb $0xF0, %al
    cmpb $0x40, %al
    je .underground
    pop %ax
    jmp MG_DISP_MAP
.underground:
    pop %ax

    pusha
    push %ds
    push %es

    movb $1, %cs:mode_flag

    movw MP_NUM_WORD, %ax
    movw %ax, %cs:orig_mp_word
    movb MAP_KIND_FLAG, %al
    movb %al, %cs:orig_map_kind
    movb UG_MAP_NO, %al
    movb %al, %cs:orig_ug_map_no
    movw PLAYER_YX, %ax
    movw %ax, %cs:orig_player_yx

    # Save absolute player Y = originY*20 + localY.
    xorw %ax, %ax
    movb %cs:orig_ug_map_no, %al
    andb $0x0F, %al
    call mul20_ax
    xorw %dx, %dx
    movb %cs:orig_player_yx, %dl
    addw %dx, %ax
    movw %ax, %cs:world_y

    # Save absolute player X = originX*20 + localX.
    xorw %ax, %ax
    movb %cs:orig_ug_map_no, %al
    shrb $1, %al
    shrb $1, %al
    shrb $1, %al
    shrb $1, %al
    call mul20_ax
    xorw %dx, %dx
    movb %cs:orig_player_yx+1, %dl
    addw %dx, %ax
    movw %ax, %cs:world_x

    # Reuse MG_DISP_MAP's field-navigation pair as UDG origin Y/X.
    # Clamp to 0..13 so a 3x3 window never reads beyond the 16x16 layout.
    xorw %ax, %ax
    movb %cs:orig_ug_map_no, %al
    movb %al, %ah
    andb $0x0F, %al
    cmpb $13, %al
    jbe 1f
    movb $13, %al
1:
    andb $0xF0, %ah
    shrb $1, %ah
    shrb $1, %ah
    shrb $1, %ah
    shrb $1, %ah
    cmpb $13, %ah
    jbe 2f
    movb $13, %ah
2:
    movw %ax, MP_NUM_WORD

    # MG_DISP_MAP enables its directional input only when this flag == 1.
    movb $1, MAP_KIND_FLAG

    # Ensure the first view is rebuilt by the same dispatcher used on panning.
    push %cs
    call map_unpack_dispatch

    # MG_DISP_MAP ends with RETF.  push CS + near CALL supplies its far frame.
    push %cs
    call MG_DISP_MAP

    # Restore every gameplay-visible variable before returning to the item user.
    movb $0, %cs:mode_flag
    movw %cs:orig_mp_word, %ax
    movw %ax, MP_NUM_WORD
    movb %cs:orig_ug_map_no, %al
    movb %al, UG_MAP_NO
    movw %cs:orig_player_yx, %ax
    movw %ax, PLAYER_YX
    movb %cs:orig_map_kind, %al
    movb %al, MAP_KIND_FLAG

    # Reconstruct the original gameplay 3x3 buffer at the original origin.
    push %cs
    call UDG_UN_PACK

    pop %es
    pop %ds
    popa
    # MG_YOSYUA originally tail-jumps to MG_DISP_MAP, so return directly to
    # MG_YOSYUA's caller.  Do NOT fall through 86:8239.
    lret


# AX *= 20, AX input 0..15.
mul20_ax:
    movw %ax, %bx
    shlw $1, %ax
    shlw $1, %ax          # *4
    addw %bx, %ax         # *5
    shlw $1, %ax
    shlw $1, %ax          # *20
    ret

# Replacement for MG_DISP_MAP call at 86:A20C.
# DX points at the two-byte map-coordinate pair, BX at signed Y/X delta bytes.
coord_update_dispatch:
    cmpb $0, %cs:mode_flag
    je .coord_stock
    push %cx
    push %di
    movw %dx, %di

    # Y origin (low byte), clamp 0..13.
    movb (%bx), %cl
    testb %cl, %cl
    jz 3f
    js 4f
    cmpb $13, (%di)
    jae 3f
    incb (%di)
    jmp 3f
4:
    cmpb $0, (%di)
    je 3f
    decb (%di)
3:
    # X origin (high byte), clamp 0..13.
    movb 1(%bx), %cl
    testb %cl, %cl
    jz 5f
    js 6f
    cmpb $13, 1(%di)
    jae 5f
    incb 1(%di)
    jmp 5f
6:
    cmpb $0, 1(%di)
    je 5f
    decb 1(%di)
5:
    pop %di
    pop %cx
    lret
.coord_stock:
    jmp ORIG_COORD_UPDATE

# Replacement for MG_DISP_MAP call at 86:A213.
# Its 0x9800 pair exists only to model field wraparound.  UDG uses an exact
# 3x3 origin and recomputes the player marker, so keep this pair at zero.
aux_coord_update_dispatch:
    cmpb $0, %cs:mode_flag
    je .aux_stock
    lret
.aux_stock:
    jmp ORIG_COORD_UPDATE

# Replacement target for MG_DISP_MAP relocations at 86:A219 and 86:A22D.
# Non-UDG behavior tail-calls stock FIELD_UN_PACK unchanged.
map_unpack_dispatch:
    cmpb $0, %cs:mode_flag
    je .unpack_stock
    pusha

    movw MP_NUM_WORD, %ax
    movw %ax, %cs:view_origin_yx

    # Pack X/Y origin into native UG_MAP_NO: high nibble X, low nibble Y.
    movb %ah, %bl
    shlb $1, %bl
    shlb $1, %bl
    shlb $1, %bl
    shlb $1, %bl
    andb $0x0F, %al
    orb %al, %bl
    movb %bl, UG_MAP_NO

    # UDG_MAKE_MAP needs the real floor number in MP_NUM.
    movw %cs:orig_mp_word, %ax
    movw %ax, MP_NUM_WORD
    push %cs
    call UDG_UN_PACK
    movw %cs:view_origin_yx, %ax
    movw %ax, MP_NUM_WORD

    call update_player_marker
    popa
    lret
.unpack_stock:
    jmp FIELD_UN_PACK

# Re-map the real player into the current virtual 3x3 window.
# Outside-window coordinates are 0x80, which makes MG_DISP_MAP omit the marker.
update_player_marker:
    # local Y = worldY - originY*20
    xorw %ax, %ax
    movb %cs:view_origin_yx, %al
    call mul20_ax
    movw %cs:world_y, %dx
    subw %ax, %dx
    jc 7f
    cmpw $59, %dx
    ja 7f
    movb %dl, PLAYER_YX
    jmp 8f
7:
    movb $0x80, PLAYER_YX
8:
    # local X = worldX - originX*20
    xorw %ax, %ax
    movb %cs:view_origin_yx+1, %al
    call mul20_ax
    movw %cs:world_x, %dx
    subw %ax, %dx
    jc 9f
    cmpw $59, %dx
    ja 9f
    movb %dl, PLAYER_YX+1
    ret
9:
    movb $0x80, PLAYER_YX+1
    ret

.align 2
mode_flag:          .byte 0
orig_map_kind:      .byte 0
orig_ug_map_no:     .byte 0
                    .byte 0
orig_mp_word:       .word 0
orig_player_yx:     .word 0
world_y:            .word 0
world_x:            .word 0
view_origin_yx:     .word 0

# Exported patch-site offsets for the Python packer are recorded separately.
