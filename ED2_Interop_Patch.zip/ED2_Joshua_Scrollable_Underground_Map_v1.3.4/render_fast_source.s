.code16
.text
.global _start

.set ORIG_BLEND, 0x9486  # runtime A686 when cave is loaded at 1200h
.set SRC_SEG_HI, 0xB824
.set PLANE0, 0xB83A
.set PLANE1, 0xB83C
.set PLANE2, 0xB83E
.set PLANE3, 0xB840

# Safe replacement for the four consecutive A686 calls at 86:A607-A624.
# Contract matches the four stock calls together for every 16-bit SI value:
#   input: DS source segment, SI/BX source offsets, DI destination byte
#   output: SI += 32, BX += 32, ES = plane3 segment
# Boundary ranges that cross either the native 5000h split or 16-bit offset
# wrap are delegated to the stock A686 helper four times.
_start:
render4_fast_safe:
    cmpw $0x4FE8, %si
    jae .not_all_low

.all_low:
    movw %cs:PLANE0, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx

    movw %cs:PLANE1, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx

    movw %cs:PLANE2, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx

    movw %cs:PLANE3, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx
    lret

.not_all_low:
    cmpw $0x5000, %si
    jb .stock_fallback
    # Four +8 steps from FFE8h..FFFFh wrap to 0000h; stock A686 re-tests
    # the split on every plane call, so delegate this boundary too.
    cmpw $0xFFE8, %si
    jae .stock_fallback

.all_high:
    push %ds
    push %si
    push %bx
    movw %cs:SRC_SEG_HI, %ax
    movw %ax, %ds
    subw $0x5000, %si
    subw $0x5000, %bx

    movw %cs:PLANE0, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx

    movw %cs:PLANE1, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx

    movw %cs:PLANE2, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)
    addw $8, %si
    addw $8, %bx

    movw %cs:PLANE3, %ax
    movw %ax, %es
    movb 1(%si), %al
    orb (%bx), %al
    movb %al, %es:(%di)

    pop %bx
    pop %si
    addw $32, %si
    addw $32, %bx
    pop %ds
    lret

.stock_fallback:
    push %cs
    call ORIG_BLEND
    push %cs
    call ORIG_BLEND
    push %cs
    call ORIG_BLEND
    push %cs
    call ORIG_BLEND
    lret
