# ED2 Joshua Scrollable Underground Map v1.3.4

v1.3.1에서 발생한 지도 깨짐을 수정한 안전판입니다.

## 기준
- 동작 기준: v1.3.0
- 지하에서 방향키로 지도 이동: 유지
- 비지하 지역: 순정 MG_DISP_MAP 경로 유지
- 중앙→바깥 지도 펼침 순서: v1.3.0 원본 코드 그대로
- 주기적 강제 대기 제거: v1.3.0과 동일

## v1.3.1 지도 깨짐 수정
v1.3.1에서 추가한 다음 두 최적화는 전부 제거합니다.
- 86:A5E0 -> 86:1340 고속 reveal-index helper
- 86:A5E3 -> 86:1200 행 전체 렌더 우회

따라서 v1.3.1 설치 상태에 바로 v1.3.2를 적용하면 해당 코드를 자동 제거하고 안전한 상태로 이행합니다.

## 새 렌더 최적화
v1.3.0의 셀 단위 루프는 그대로 둡니다.
셀 하나를 그릴 때 연속으로 호출하던 A686 4회를 86:1200의 render4 helper 1회로 합칩니다.

안전 경계:
- 4FE8h~4FFFh: 5000h source split을 건드리므로 순정 A686 x4로 폴백
- FFE8h~FFFFh: 16-bit offset wrap을 건드리므로 순정 A686 x4로 폴백

주소 선택 의미론 검증은 SI 0..FFFFh 전체와 대표 BX 9종, 총 589,824 케이스에서 순정 A686 x4와 일치했습니다.

## 적용
`run_apply.bat`

이미 v1.3.1이 적용돼 있어도 먼저 복원할 필요가 없습니다.

## 확인
`run_check.bat`

## 복원
`run_restore.bat`

복원은 백업 파일에 의존하지 않고 지원 기준선으로 정규화합니다.

## 주의
이 환경에서는 DOSBox/실기 런타임 실행을 할 수 없었습니다. 바이너리 구조/마이그레이션/주소 의미론 검증은 수행했지만 실제 화면 최종 확인은 게임에서 필요합니다.


## v1.3.4

v1.4.67의 VGM WAIT_BGM sync가 추가된 ED2MAIN exact normalized baseline을 허용합니다. 지도 동작 바이트는 v1.3.2와 동일합니다.


## v1.3.4

- ED2 Interop Patch Pack v1.4.71의 순정 → 올인원 적용 중 생성되는 정확한 pre-Joshua ED2MAIN 기준선(`01278951083d3d877f1922e6ece90a71ca9f269a3327b595073a593bd3bbc2e4`)을 추가했습니다.
- Joshua 소유 영역의 구조 검증과 exact normalized SHA fail-closed 정책은 그대로 유지합니다.
