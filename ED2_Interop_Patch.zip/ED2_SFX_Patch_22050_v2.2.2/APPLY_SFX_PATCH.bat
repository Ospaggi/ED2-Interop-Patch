@echo off
setlocal
cd /d "%~dp0"
set "GAME=%~1"
if "%GAME%"=="" set "GAME=."
where py >nul 2>nul
if not errorlevel 1 (
  py -3 ed2_sfx_patch.py "%GAME%" --mixing-rate 22050
) else (
  python ed2_sfx_patch.py "%GAME%" --mixing-rate 22050
)
pause
