#!/usr/bin/env python3
# ED2 Map Transition QoL TEST8 PAIR10 NOWAIT + reduced camera deadzone
# Keep all 20 geometry calculations and all 10 PAIR10 display/copy states; remove every transition-local timer/VSync wait.
from pathlib import Path
import hashlib,struct,sys
BASE_SHA='03d7c3b63bd42856088bedd528e0341ca8b807f1dfa89f2a1cf35a31aa0063ec';TEST1_SHA='b62930cfaca447a7516915acbf01afdb73ec5a85f90932cea0e83d901b750f8d';TEST2_SHA='4e085d0548ab9b4d38b2c9d530588d0a225e53acd9c3f7dc5e397db51702d29f';TEST3_SHA='7d210be82622755a3482c6dd72887a220c7ef1866185a34f3973d5352f36d0cd';TEST4_SHA='b23d7ee325968fb493e2c8d37274261f3a98b629340371cb41e62246d0875584';TEST5_SHA='2e341b1296f62445e89eb71eb43d3b1883efdbfd9ca685adf9d7dd7e0a57e108';TEST6_SHA='13a085b12fbd73d10145808d2c72fbb8cb33fc41318c7348d215657747213e79';TEST7_SHA='574699bcc0c54443d7d6949f560f34d4ca939217c139b2b3e88a05a36fe63a8f';TARGET_SHA='2f24a98f26964be63c56a90389608ca205e1fa88916109db964c6e6a9f5011d4'
SEGNO=86;HELPER=0x0840;FAST_DISPLAY=0x085F;CAVE_START=0x0840;CAVE_END=0x0880;NEG_DSP_TEXT=0x2FD3;NEG_DSP_BANK=0x2EBE;COPY_PAGE=0x3384;RELOC_TEXT_SRC=0xAF0E;RELOC_BANK_SYNC_SRC=0xAF4A;RELOC_BANK_COPY_SRC=0xAF4F
PAIR_CODE=bytes.fromhex('490ee817a72b3ec43e0ee87126cb');QUAD_CODE=bytes.fromhex('490ee817a72b3ec43e490ee80ea72b3ec43e490ee805a72b3ec43e0ee85f26cb');TEST7_CAVE=bytes.fromhex('490ee817a72b3ec43ef6c10274050ee80d00cb0ee86726cb0000000000000050a1c63ea3c43ea0c33ea2c23e0ee89c253401faa2c33e8136c63ea00ffbe96526');TEST8_CAVE=bytes.fromhex('490ee817a72b3ec43e0ee81200cb000000000000000000000000000000000050a1c63ea3c43ea0c33ea2c23e0ee89c253401faa2c33e8136c63ea00ffbe96526')
OLD2_BANK=bytes.fromhex('2e80364e080175050ee87226cbcb00');OLD2_TEXT=bytes.fromhex('2e80366e080175050ee86727cbcb00');OLD3_BANK=bytes.fromhex('0ee8402b83f902760149cb');OLD3_TEXT=bytes.fromhex('5589e50ee86c27837e08027606fe4607ff4e085dcb');OLD4_BANK=bytes.fromhex('50a1c63ea3c43ea0c33ea2c23e0ee8bb253401faa2c33e8136c63ea00ffbe98426');OLD4_TEXT=bytes.fromhex('50a1c63ea3c43e35a00ffaa3c63efb58cb')
BYTE_PATCHES=[(27958, 5, 7), (27963, 14, 12), (27976, 6, 8), (27981, 15, 13), (45409, 5, 7), (45414, 14, 12), (45430, 6, 8), (45434, 15, 13)]
def sha(b):return hashlib.sha256(b).hexdigest()
def seg(d):
 ne=struct.unpack_from('<I',d,0x3c)[0];tab=ne+struct.unpack_from('<H',d,ne+0x22)[0];sh=struct.unpack_from('<H',d,ne+0x32)[0];o,l,_,_=struct.unpack_from('<HHHH',d,tab+(SEGNO-1)*8);return o<<sh,l or 0x10000
def relocs(d):
 sb,ln=seg(d);rp=sb+ln;n=struct.unpack_from('<H',d,rp)[0];out=[]
 for i in range(n):
  e=rp+2+i*8;typ,fl,src,t1,t2=struct.unpack_from('<BBHHH',d,e);out.append((e,typ,fl,src,t1,t2))
 return out
def getrel(d,src):
 h=[r for r in relocs(d) if r[3]==src]
 if len(h)!=1:raise RuntimeError(f'relocation {src:04X} count={len(h)}')
 return h[0]
def setrel(d,src,exp,new):
 r=getrel(d,src)
 if r[1:]!=(3,0,src,SEGNO,exp):raise RuntimeError(f'relocation gate {src:04X}')
 struct.pack_into('<H',d,r[0]+6,new)
def cave(d,sb,k):
 if k in ('base','test1'):
  if any(d[sb+CAVE_START:sb+CAVE_END]):raise RuntimeError('helper cave not empty')
 elif k=='test2':
  if d[sb+0x0840:sb+0x0840+len(OLD2_BANK)]!=OLD2_BANK or d[sb+0x0860:sb+0x0860+len(OLD2_TEXT)]!=OLD2_TEXT:raise RuntimeError('TEST2 cave gate')
 elif k=='test3':
  if d[sb+0x0840:sb+0x0840+len(OLD3_BANK)]!=OLD3_BANK or d[sb+0x0860:sb+0x0860+len(OLD3_TEXT)]!=OLD3_TEXT:raise RuntimeError('TEST3 cave gate')
 elif k=='test4':
  if d[sb+0x0840:sb+0x0840+len(OLD4_BANK)]!=OLD4_BANK or d[sb+0x0868:sb+0x0868+len(OLD4_TEXT)]!=OLD4_TEXT:raise RuntimeError('TEST4 cave gate')
 elif k=='test5':
  if d[sb+HELPER:sb+HELPER+len(PAIR_CODE)]!=PAIR_CODE or any(d[sb+HELPER+len(PAIR_CODE):sb+CAVE_END]):raise RuntimeError('TEST5 helper gate')
 elif k=='test6':
  if d[sb+HELPER:sb+HELPER+len(QUAD_CODE)]!=QUAD_CODE or any(d[sb+HELPER+len(QUAD_CODE):sb+CAVE_END]):raise RuntimeError('TEST6 helper gate')
 elif k=='test7':
  if d[sb+CAVE_START:sb+CAVE_END]!=TEST7_CAVE:raise RuntimeError('TEST7 helper gate')
def normalize_relocs(d,k):
 ex={'base':NEG_DSP_BANK,'test1':NEG_DSP_BANK,'test2':0x0840,'test3':NEG_DSP_BANK,'test4':0x0840,'test5':HELPER,'test6':HELPER,'test7':HELPER}[k]
 r=getrel(d,RELOC_BANK_SYNC_SRC)
 if r[5]!=ex:raise RuntimeError('bank sync variant gate')
 if ex!=NEG_DSP_BANK:setrel(d,RELOC_BANK_SYNC_SRC,ex,NEG_DSP_BANK)
 ex={'base':NEG_DSP_TEXT,'test1':NEG_DSP_TEXT,'test2':0x0860,'test3':0x0860,'test4':0x0868,'test5':NEG_DSP_TEXT,'test6':NEG_DSP_TEXT,'test7':NEG_DSP_TEXT}[k]
 r=getrel(d,RELOC_TEXT_SRC)
 if r[5]!=ex:raise RuntimeError('text variant gate')
 if ex!=NEG_DSP_TEXT:setrel(d,RELOC_TEXT_SRC,ex,NEG_DSP_TEXT)
 ex={'base':COPY_PAGE,'test1':COPY_PAGE,'test2':COPY_PAGE,'test3':0x0840,'test4':COPY_PAGE,'test5':COPY_PAGE,'test6':COPY_PAGE,'test7':COPY_PAGE}[k]
 r=getrel(d,RELOC_BANK_COPY_SRC)
 if r[5]!=ex:raise RuntimeError('copy variant gate')
 if ex!=COPY_PAGE:setrel(d,RELOC_BANK_COPY_SRC,ex,COPY_PAGE)
def apply(raw,k):
 d=bytearray(raw);sb,_=seg(d);cave(d,sb,k)
 if k=='test1':
  if d[sb+0x19DB:sb+0x19DD]!=b'\x90\x90':raise RuntimeError('TEST1 movement gate')
  d[sb+0x19DB:sb+0x19DD]=b'\x00\xC0'
  if any(d[sb+o]!=new for o,old,new in BYTE_PATCHES):raise RuntimeError('TEST1 deadzone gate')
 else:
  if d[sb+0x19DB:sb+0x19DD]!=b'\x00\xC0':raise RuntimeError('movement wait gate')
  for o,old,new in BYTE_PATCHES:
   exp=old if k=='base' else new
   if d[sb+o]!=exp:raise RuntimeError(f'deadzone gate {o:04X}')
   if k=='base':d[sb+o]=new
 normalize_relocs(d,k)
 d[sb+CAVE_START:sb+CAVE_END]=TEST8_CAVE
 setrel(d,RELOC_BANK_SYNC_SRC,NEG_DSP_BANK,HELPER)
 return bytes(d)
def main():
 root=Path(sys.argv[1] if len(sys.argv)>1 else '.');p=root/'ED2MAIN.EXE'
 if not p.is_file():print('ERROR: ED2MAIN.EXE not found',file=sys.stderr);return 1
 raw=p.read_bytes();h=sha(raw)
 try:
  if h==TARGET_SHA:print('Already TEST8 PAIR10 NOWAIT. writes=0');return 0
  if h==BASE_SHA:out=apply(raw,'base');src='v1.4.72'
  elif h==TEST1_SHA:out=apply(raw,'test1');src='TEST1'
  elif h==TEST2_SHA:out=apply(raw,'test2');src='TEST2 (buggy)'
  elif h==TEST3_SHA:out=apply(raw,'test3');src='TEST3 (buggy)'
  elif h==TEST4_SHA:out=apply(raw,'test4');src='TEST4 TURBO'
  elif h==TEST5_SHA:out=apply(raw,'test5');src='TEST5 PAIR10'
  elif h==TEST6_SHA:out=apply(raw,'test6');src='TEST6 QUAD5'
  elif h==TEST7_SHA:out=apply(raw,'test7');src='TEST7 PAIR10 FAST'
  else:print('ERROR: unsupported/tampered ED2MAIN.EXE; writes=0',file=sys.stderr);print('SHA-256:',h,file=sys.stderr);return 1
 except Exception as e:print('ERROR:',e,'writes=0',file=sys.stderr);return 1
 if sha(out)!=TARGET_SHA:print('ERROR: target SHA mismatch; writes=0',file=sys.stderr);return 1
 tmp=p.with_suffix('.EXE.tmp');tmp.write_bytes(out);tmp.replace(p);print(f'Applied TEST8 PAIR10 NOWAIT from {src}. writes=1');print('SHA-256:',TARGET_SHA);return 0
if __name__=='__main__':raise SystemExit(main())
