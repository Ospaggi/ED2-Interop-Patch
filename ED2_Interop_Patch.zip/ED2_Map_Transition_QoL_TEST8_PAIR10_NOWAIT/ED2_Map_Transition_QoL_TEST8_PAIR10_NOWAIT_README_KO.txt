ED2 Map Transition QoL TEST8 PAIR10 NOWAIT

목표:
- TEST5/7의 부드러운 10회 표시 구조 유지
- 원래 20회의 도형 계산 유지
- 전환 루틴 내부 timer/VSync busy-wait는 0회
- 매 표시마다 페이지 갱신/COPY_PAGE는 그대로 유지
- 일반 이동/스크롤 대기는 v1.4.72 그대로
- 필드/마을 카메라 데드존은 9타일 -> 5타일 유지

TEST2/TEST3/TEST4/TEST6/TEST7 등 이전 시험판을 적용했다면 Python 패처 사용을 권장합니다.
이 파일은 실제 DOSBox 플레이 검증 전 정식 릴리스가 아닙니다.
