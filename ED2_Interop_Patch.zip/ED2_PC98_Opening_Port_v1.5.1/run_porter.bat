@echo off
cd /d "%~dp0"
py -3 ed2_pc98_opening_port.py
if errorlevel 1 python ed2_pc98_opening_port.py
