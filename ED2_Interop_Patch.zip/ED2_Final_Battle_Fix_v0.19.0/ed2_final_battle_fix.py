#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, tempfile
from pathlib import Path
import ed2_final_battle_presentation_fix as presentation

APP_NAME = "ED2 Final Battle Fix"
VERSION = "0.19.0"
HERE = Path(__file__).resolve().parent
HUNKS_PATH = HERE / "runtime_hunks.json"

class PatchError(RuntimeError):
    pass

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def atomic_write(path: Path, data: bytes, backup_suffix: str | None = None) -> None:
    if backup_suffix:
        bak = Path(str(path) + backup_suffix)
        if not bak.exists():
            shutil.copy2(path, bak)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    os.close(fd)
    try:
        Path(tmp).write_bytes(data)
        os.replace(tmp, path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def load_hunks() -> dict:
    d=json.loads(HUNKS_PATH.read_text(encoding="utf-8"))
    if d.get("schema") != 1:
        raise PatchError("runtime_hunks.json schema mismatch")
    return d

def validate_root(root: Path) -> Path:
    return presentation.validate_root(Path(root))

def runtime_state(root: Path) -> dict:
    root=validate_root(root)
    d=load_hunks()
    files={}
    for rel,row in d["files"].items():
        p=root/rel
        if not p.is_file():
            files[rel]={"state":"missing","sha256":None}
            continue
        raw=p.read_bytes()
        h=sha256_bytes(raw)
        if h==row["target_sha256"]: state="target"
        elif h==row["source_sha256"]: state="source"
        else: state="unknown"
        files[rel]={"state":state,"sha256":h,"size":len(raw)}
    states={v["state"] for v in files.values()}
    cohort="target" if states=={"target"} else "source" if states=={"source"} else "mixed-or-unknown"
    return {"cohort":cohort,"files":files}

def verify_runtime(root: Path) -> dict:
    root=validate_root(root)
    st=runtime_state(root)
    if st["cohort"]!="target":
        raise PatchError("Final Battle runtime target SHA mismatch")
    return {"ok":True,"version":VERSION,"runtime":st}

def apply_runtime(root: Path, make_backup: bool=True) -> dict:
    root=validate_root(root)
    d=load_hunks()
    st=runtime_state(root)
    if st["cohort"]=="target":
        return verify_runtime(root)
    if st["cohort"]!="source":
        raise PatchError("지원되는 exact v1.4.67 Final Battle source 상태가 아닙니다. 혼합/커스텀 DLL에는 강제 적용하지 않습니다.")
    prepared={}
    for rel,row in d["files"].items():
        p=root/rel
        raw=p.read_bytes()
        if len(raw)!=row["size"] or sha256_bytes(raw)!=row["source_sha256"]:
            raise PatchError(f"source SHA mismatch: {rel}")
        out=bytearray(raw)
        for h in row["hunks"]:
            off=int(h["offset"]); old=bytes.fromhex(h["old"]); new=bytes.fromhex(h["new"])
            if len(old)!=len(new):
                raise PatchError(f"hunk length mismatch: {rel}@0x{off:X}")
            if bytes(out[off:off+len(old)])!=old:
                raise PatchError(f"hunk source mismatch: {rel}@0x{off:X}")
            out[off:off+len(new)]=new
        final=bytes(out)
        if sha256_bytes(final)!=row["target_sha256"]:
            raise PatchError(f"target SHA mismatch after patch: {rel}")
        prepared[rel]=final
    before={rel:(root/rel).read_bytes() for rel in d["files"]}
    try:
        for rel,raw in prepared.items():
            atomic_write(root/rel,raw,".final_battle_fix.bak" if make_backup else None)
        return verify_runtime(root)
    except Exception:
        for rel,raw in before.items():
            atomic_write(root/rel,raw,None)
        raise

def apply_presentation(root: Path, make_backup: bool=True, pre_dialogue: bool=False) -> dict:
    return presentation.apply_patch(root, make_backup, pre_dialogue=pre_dialogue)

def inspect_presentation(root: Path) -> dict:
    return presentation.inspect_patch(root)

def apply_full(root: Path, make_backup: bool=True, pre_dialogue: bool=False) -> dict:
    root=validate_root(root)
    st=runtime_state(root)
    if st["cohort"]=="target":
        return {"presentation":"already-final","runtime":verify_runtime(root)}
    pres=apply_presentation(root,make_backup,pre_dialogue=pre_dialogue)
    if pre_dialogue:
        return {"presentation":pres,"runtime":"deferred"}
    run=apply_runtime(root,make_backup)
    return {"presentation":pres,"runtime":run}

def main() -> int:
    ap=argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    ap.add_argument("root",type=Path)
    g=ap.add_mutually_exclusive_group()
    g.add_argument("--apply",action="store_true")
    g.add_argument("--check",action="store_true")
    mode=ap.add_mutually_exclusive_group()
    mode.add_argument("--presentation-only",action="store_true")
    mode.add_argument("--runtime-only",action="store_true")
    ap.add_argument("--pre-dialogue",action="store_true")
    ap.add_argument("--no-backup",action="store_true")
    a=ap.parse_args()
    try:
        make_backup=not a.no_backup
        if a.presentation_only:
            result=inspect_presentation(a.root) if a.check else apply_presentation(a.root,make_backup,a.pre_dialogue)
        elif a.runtime_only:
            result=verify_runtime(a.root) if a.check else apply_runtime(a.root,make_backup)
        else:
            result=verify_runtime(a.root) if a.check else apply_full(a.root,make_backup,a.pre_dialogue)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except Exception as exc:
        print("ERROR:",exc)
        return 1

if __name__=="__main__":
    raise SystemExit(main())
