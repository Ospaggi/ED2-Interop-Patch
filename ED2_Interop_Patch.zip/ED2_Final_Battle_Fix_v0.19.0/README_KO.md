# ED2 Final Battle Fix v0.19.0

최종전 관련 기존 두 구성요소를 하나로 통합한 버전입니다.

통합 대상:
- `ED2_Final_Battle_Presentation_Fix_v0.18.19_Sindy_Branch`
- `ED2_Final_Battle_Runtime_v1.0.0`

Presentation 코어는 검증된 v0.18.19 로직을 내부 단계로 유지합니다.
Runtime 단계는 더 이상 완성 `M_500/M_501/M_502/C_734.DLL`을 배포하지 않습니다.

공식 v1.4.67 최종전 source SHA를 확인한 뒤 `runtime_hunks.json`의
**32개 검증 hunk**만 실제 게임 DLL에 직접 적용합니다.

- 입력 4파일이 모두 exact source일 때만 쓰기 허용
- 각 hunk의 old bytes 재검증
- 최종 SHA를 메모리에서 먼저 검증한 뒤 실제 파일 쓰기
- unknown/mixed 상태는 쓰기 전에 중단
- AIO에서는 전체 트랜잭션 롤백을 사용하므로 component backup 비활성화

## v0.19.0 최종값
- 신디: 완전 AI 구조 유지
- 드래곤의 검 / 갑옷 없음 / 방패 없음
- DEF 300 / 주문능력(INT2) 3000
- 화염의 브레스: 기존 30% 공식 → 900
- 고드윈 1차 평타 실효 ATT 1200
- 고드윈 2차 평타 실효 ATT 1400
- 고드윈 2차 연속공격 175/타
- Late Skill 537 유지
- 가비 logical ATT 3000 / 3연타 실효 ATT 800 / SPD 120
- 레이시아 물리 bridge 및 가비전 피리 이벤트 성공 경로 유지

## 실행
전체 적용:
`python ed2_final_battle_fix.py <게임폴더> --apply`

확인:
`python ed2_final_battle_fix.py <게임폴더> --check`

AIO 내부 단계:
- `--presentation-only`
- `--runtime-only`

SAVE는 검색·수정·백업 대상이 아닙니다.
