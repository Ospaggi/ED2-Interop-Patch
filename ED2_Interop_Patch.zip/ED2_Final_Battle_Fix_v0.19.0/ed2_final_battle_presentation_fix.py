#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
import struct
import sys
import tempfile
from pathlib import Path

APP_NAME = "ED2 Final Battle Presentation Fix"
VERSION = "0.18.19"
CORE_FILE = Path(__file__).with_name("ed2_final_battle_presentation_fix_v0140_core.py")
_spec = importlib.util.spec_from_file_location("ed2_fb_v0140_core", CORE_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError("v0.14.0 core load failed")
v140 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v140)

core = v140.core
PatchError = v140.PatchError
sha256 = v140.sha256
atomic_write = v140.atomic_write

# ---------------------------------------------------------------------------
# M_501 final Godwin battle data
# ---------------------------------------------------------------------------
M501_SEGMENT = 3
M501_HP = 9999
M501_NAME = "고드윈"
M501_NAME_BYTES = M501_NAME.encode("cp949") + b"\x06"
M501_NAME_FIELD = M501_NAME_BYTES + b"\x00" * (16 - len(M501_NAME_BYTES))
assert len(M501_NAME_FIELD) == 16

M501_HP_CUR = 0x0004
M501_HP_MAX = 0x0006
M501_NAME_OFF = 0x0030
M501_TITLE_OFF = 0x0056
# v0.18.5: the stray-glyph bug exists only in the special quote scene.  Restore
# the original Korean DOS composition exactly: literal "황제 " + 0F pointer to
# the stock actor-name slot at 0030h + 05h + 06h.  Do not rewrite the general
# skill strings or renderer paths.
M501_TITLE = "황제 ".encode("cp949") + bytes.fromhex("0F 30 00 05 06")
M501_TITLE_LEN = len(M501_TITLE)
M501_TITLE_FIELD = M501_TITLE + b"\x00\x00"
assert M501_TITLE_LEN == 10 and len(M501_TITLE_FIELD) == 12

# PC-98: 「この私の本当の力を思い知るがいい。」
# Exact 36-byte in-place replacement for the Korean stock sentence.
M501_QUOTE_OFF = 0x00D4
M501_QUOTE_OLD = "이제, 나의 진정한 힘을 보여 주겠다. ".encode("cp949")
M501_QUOTE_V01810 = "이 몸의 진정한 힘을 똑똑히 깨달아라.".encode("cp949")
# 34-cell battle quote window: replace the inter-phrase space with 01h so the
# wording remains unchanged but renders as 19 cells / 16 cells instead of 36.
M501_QUOTE_NEW = "이 몸의 진정한 힘을".encode("cp949") + b"\x01" + "똑똑히 깨달아라.".encode("cp949")
assert len(M501_QUOTE_OLD) == len(M501_QUOTE_V01810) == len(M501_QUOTE_NEW) == 36

# v0.18.4: rollback v0.18.2/v0.18.3 skill-message rewrite completely.
# The user's runtime reports show that touching these message/render paths causes
# battle-presentation corruption. Keep the original M_501 skill streams and calls
# byte-for-byte, and fix only the dynamic actor name source by restoring stock
# "고드윈" in the monster name field. Fixed speaker/title slots remain literal
# "황제 고드윈".
M501_SKILL_REGION_START = 0x0062
M501_SKILL_REGION_END = 0x00C1
M501_SKILL_REGION_STOCK = bytes.fromhex(
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 "
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 "
    "86 C0 C7 20 B0 A1 BD BF C0 CC 20 B9 F8 C2 BD BF B4 B4 D9 21 21 07 "
    "02 C0 C7 20 BF AC BC D3 20 B0 F8 B0 DD 21 21 07 "
    "02 B4 C2 20 B4 EB B1 E2 B8 A6 20 C2 F5 BE EE 20 B0 A1 B8 A3 B4 C2 20 C6 C4 B5 87"
)
assert len(M501_SKILL_REGION_STOCK) == 95

# v0.18.7: the Korean retail third Godwin skill is malformed in place.
# 03:00A6 begins with actor-name control 02h, but the final Hangul byte is
# B5 87 instead of the CP949 bytes for "동" (B5 BF), and there is no 07h
# message terminator before the live 00C1 control stream.  Relocate only this
# one message into the verified 30-byte zero pad at 0062..007F.
M501_SKILL3_FIXED_OFF = 0x0062
M501_SKILL3_FIXED_TEXT = "은 대기를 찢는 파동을 냈다.".encode("cp949")
M501_SKILL3_FIXED = b"\x02" + M501_SKILL3_FIXED_TEXT + b"\x07"
M501_SKILL3_PAD_LEN = 0x001E
assert len(M501_SKILL3_FIXED) == 29 and M501_SKILL3_PAD_LEN == 30
M501_SKILL3_FIELD = M501_SKILL3_FIXED + b"\x00"
assert len(M501_SKILL3_FIELD) == M501_SKILL3_PAD_LEN
M501_SKILL_REGION_FIXED = bytearray(M501_SKILL_REGION_STOCK)
M501_SKILL_REGION_FIXED[:M501_SKILL3_PAD_LEN] = M501_SKILL3_FIELD
M501_SKILL_REGION_FIXED = bytes(M501_SKILL_REGION_FIXED)
M501_SKILL3_SI_FIXED = bytes.fromhex("BE 62 00")
M501_POST_SKILL_CONTROL_OFF = 0x00C1
M501_POST_SKILL_CONTROL = bytes.fromhex("1E 10 56 00 04")
M501_SKILL1_SI = 0x025A
M501_SKILL3_SI = 0x02D1
M501_SKILL2_SI = 0x0349
M501_SKILL_SI_STOCK = {
    M501_SKILL1_SI: bytes.fromhex("BE 81 00"),
    M501_SKILL3_SI: bytes.fromhex("BE A6 00"),
    M501_SKILL2_SI: bytes.fromhex("BE 96 00"),
}
M501_SKILL1_CALL_RELOC = 0x025E
M501_MESSAGE_MODULE = 1
M501_SKILL1_ORDINAL_STOCK = 615
M501_SKILL1_ORDINAL_V018X = 599

# Exact v0.18.2/v0.18.3 literal region signature. Used only to recognize and
# undo our own previous experimental state; unknown/custom M_501 binaries are
# not normalized speculatively.
_M501_V018X_TEXTS = (
    "황제 고드윈의 가슴이 빛났다!!",
    "황제 고드윈의 연속 공격!!",
    "황제 고드윈은 대기를 찢는 파동을 쐈다.",
)
M501_SKILL_REGION_V018X = b"".join(t.encode("cp949") + b"\x07" for t in _M501_V018X_TEXTS)
assert len(M501_SKILL_REGION_V018X) == 95
M501_SKILL_SI_V018X = {
    M501_SKILL1_SI: bytes.fromhex("BE 62 00"),
    M501_SKILL3_SI: bytes.fromhex("BE 9A 00"),
    M501_SKILL2_SI: bytes.fromhex("BE 80 00"),
}

# v0.18.8: fix the continuous-attack target selector without touching the
# successful v0.18.7 skill-3/string fix.  Retail calls the shared CHOICE_TEKI
# routine once per hit.  That routine derives its side from mutable current-actor
# state, so after a hit/status update a later iteration can select the monster
# side and make Godwin hit himself.  The local attack summary and alive check are
# player-slot-only, so select PL_DATA_1..4 directly here.
M501_MULTI_TARGET_CALL_OFF = 0x0367
M501_MULTI_TARGET_RELOC_SOURCE = 0x0368
M501_MULTI_TARGET_RETRY_DISP_OFF = 0x0371
M501_MULTI_TARGET_RETRY_STOCK = 0xF5  # JE 0367h
M501_MULTI_TARGET_RETRY_FIXED = 0xF0  # JE 0362h: rerun RANDOM for dead targets
M501_PL_DATA1_RELOC_SOURCE = 0x030C
M501_PL_DATA1_ORDINAL = 748
M501_MULTI_TARGET_HELPER_OFF = 0x00A6
M501_MULTI_TARGET_HELPER = bytes.fromhex(
    "24 03 "          # and al,03h
    "30 E4 "          # xor ah,ah
    "B1 06 "          # mov cl,06h
    "D3 E0 "          # shl ax,cl  -> 0/40/80/C0h
    "2E 8B 3E 0C 03 " # mov di,cs:[030Ch] (loader-relocated PL_DATA_1 immediate)
    "03 F8 "          # add di,ax
    "CB"              # retf
)
assert len(M501_MULTI_TARGET_HELPER) == 16
M501_MULTI_TARGET_TRAMPOLINE = (
    b"\x0E\xE8" +
    struct.pack("<H", (M501_MULTI_TARGET_HELPER_OFF - (M501_MULTI_TARGET_CALL_OFF + 4)) & 0xFFFF) +
    b"\x90"
)
assert len(M501_MULTI_TARGET_TRAMPOLINE) == 5

# v0.18.17: defense-in-depth isolation for the M_501 Godwin AI.  C_734 owns
# Sindy's guest/auto state, but if the battle dispatcher ever hands a player-side
# PL_DATA record to M_501, never let that record enter Godwin's monster-only
# skill stream (including "가슴이 빛났다!").  The verified 01E3..021F zero pad
# is local to M_501 and requires no relocation rows.
M501_ACTOR_GUARD_CALL_OFF = 0x0229
M501_ACTOR_GUARD_STOCK = bytes.fromhex("F6 45 2F 01 74 72")
M501_ACTOR_GUARD_HELPER_OFF = 0x01E3
M501_ACTOR_GUARD_HELPER = bytes.fromhex(
    "F6 05 04 "          # test byte ptr [di],04h  (monster-side record)
    "74 0C "             # jz 01F4h -> RETF for player/guest records
    "F6 45 2F 01 "       # original action-flag test
    "75 03 "             # jne 01F1h -> continue at 022Fh
    "E9 B0 00 "          # jmp 02A1h (original flag-clear branch)
    "E9 3B 00 "          # jmp 022Fh
    "CB"                  # retf
)
assert len(M501_ACTOR_GUARD_HELPER) == 18
M501_ACTOR_GUARD_TRAMPOLINE = (
    b"\xE9" +
    struct.pack("<H", (M501_ACTOR_GUARD_HELPER_OFF - (M501_ACTOR_GUARD_CALL_OFF + 3)) & 0xFFFF) +
    b"\x90\x90\x90"
)
assert len(M501_ACTOR_GUARD_TRAMPOLINE) == 6

# PC-98 M_501: 「の胸が光った !!」.  Keep the fixed 0081..0095 slot size;
# only the Korean wording changes, followed by 07h and two zero pad bytes.
M501_SKILL1_TEXT_OFF = 0x0081
M501_SKILL1_FIELD_LEN = 0x0096 - M501_SKILL1_TEXT_OFF
M501_SKILL1_OLD = "의 가슴이 번쩍였다!!".encode("cp949") + b"\x07"
M501_SKILL1_NEW_TEXT = "의 가슴이 빛났다!!"
M501_SKILL1_NEW = M501_SKILL1_NEW_TEXT.encode("cp949") + b"\x07"
M501_SKILL1_FIELD = M501_SKILL1_NEW + b"\x00" * (M501_SKILL1_FIELD_LEN - len(M501_SKILL1_NEW))
assert len(M501_SKILL1_OLD) == M501_SKILL1_FIELD_LEN == 21
assert len(M501_SKILL1_FIELD) == M501_SKILL1_FIELD_LEN

# PC-98 M_501: 「に合計」 + dynamic damage number + 「のダメージ !!」.
# Korean stock has no blank between 합계 and the dynamic 06h number, so it
# renders like `합계200`.  Keep the verified 21-byte fixed field and make the
# assembled Korean message `<target>에게 합계 200 대미지!`.
M501_TOTAL_DAMAGE_OFF = 0x0041
M501_TOTAL_DAMAGE_LEN = 21
M501_TOTAL_DAMAGE_OLD = (
    b"\x02" + "에게 합계".encode("cp949") + b"\x06" + "의 피해!!".encode("cp949") + b"\x07"
)
M501_TOTAL_DAMAGE_NEW = (
    b"\x02" + "에게 합계 ".encode("cp949") + b"\x06" + " 대미지!".encode("cp949") + b"\x07"
)
assert len(M501_TOTAL_DAMAGE_OLD) == M501_TOTAL_DAMAGE_LEN
assert len(M501_TOTAL_DAMAGE_NEW) == M501_TOTAL_DAMAGE_LEN

# v0.18.14: interoperate with both ED2 v1.4.62 and v1.4.63 late-game skill scaling.
# M_501's special attack at 03DAh remains owned by the independent scaling
# component. This presentation patch accepts historical fixed 300, the v1.4.62
# value (300 + current Godwin attack // 8), and the rebalanced v1.4.63 value
# (300 + current Godwin attack // 16), preserving whichever supported value was
# present on entry.
M501_V1462_DAMAGE_OFF = 0x03DA
M501_V1462_DAMAGE_RELOC = 0x03DE
M501_V1462_DAMAGE_ORDINAL = 40
M501_V1462_DAMAGE_BASE = 300
M501_ATTACK_OFF = 0x000A

def _m501_v1462_damage_state(data: bytes | bytearray, seg: dict[str, int], base: int) -> dict[str, object]:
    site = bytes(data[base + M501_V1462_DAMAGE_OFF:base + M501_V1462_DAMAGE_OFF + 3])
    reloc_ok = core.reloc_matches(
        data, seg, M501_V1462_DAMAGE_RELOC, 3, 1, 1, M501_V1462_DAMAGE_ORDINAL
    )
    if len(site) != 3 or site[:1] != b"\xBA" or not reloc_ok:
        return {
            "state": "unsupported",
            "site_hex": site.hex(" "),
            "relocation_ok": reloc_ok,
        }
    attack = struct.unpack_from("<H", data, base + M501_ATTACK_OFF)[0]
    current = struct.unpack_from("<H", site, 1)[0]
    expected_1462 = min(0xFFFF, M501_V1462_DAMAGE_BASE + attack // 8)
    expected_1463 = min(0xFFFF, M501_V1462_DAMAGE_BASE + attack // 16)
    if current == M501_V1462_DAMAGE_BASE:
        state = "stock-fixed-300"
    elif current == expected_1463:
        state = "scaled-v1.4.63"
    elif current == expected_1462:
        state = "scaled-v1.4.62"
    else:
        state = "unexpected"
    return {
        "state": state,
        "current_damage": current,
        "base_damage": M501_V1462_DAMAGE_BASE,
        "godwin_attack": attack,
        "v1_4_62_expected_damage": expected_1462,
        "v1_4_63_expected_damage": expected_1463,
        "supported_formulas": [
            "300 + current Godwin attack // 8",
            "300 + current Godwin attack // 16",
        ],
        "relocation_ok": reloc_ok,
        "site_hex": site.hex(" "),
    }

M501_SKILL_REGION_V0188 = bytearray(M501_SKILL_REGION_FIXED)
_i = M501_SKILL1_TEXT_OFF - M501_SKILL_REGION_START
M501_SKILL_REGION_V0188[_i:_i + M501_SKILL1_FIELD_LEN] = M501_SKILL1_FIELD
_i = M501_MULTI_TARGET_HELPER_OFF - M501_SKILL_REGION_START
M501_SKILL_REGION_V0188[_i:_i + len(M501_MULTI_TARGET_HELPER)] = M501_MULTI_TARGET_HELPER
M501_SKILL_REGION_V0188 = bytes(M501_SKILL_REGION_V0188)

# ---------------------------------------------------------------------------
# C_734 Sindy ally data / AI and FE999 explosion hook
# ---------------------------------------------------------------------------
C734_SEGMENT = 3
SINDY_TEMPLATE = 0x0212
SINDY_TEMPLATE_LEN = 36
SINDY_LEVEL = 99
SINDY_HP = 9999
SINDY_BASE_ATTACK = 720
SINDY_WEAPON_ATTACK = 480
SINDY_ATTACK = 1200
SINDY_INT2 = 1667
SINDY_WEAPON = 15
SINDY_WEAPON_NAME = "드래곤의 검"
SINDY_DEFENSE = 500
SINDY_AGILITY = 70

# v0.18.17: keep Sindy automatic at the dispatcher boundary, but never place
# helper code inside a fixed scene/string-tail address or an active in-line code
# block.  The helper is appended after the *current* segment payload and the NE
# relocation table is moved forward inside the verified gap before segment 4.
# This remains safe when the Scene Editor later appends more R17 strings: the
# helper becomes ordinary preserved segment payload and its near JMP target stays
# fixed.
SINDY_AI_OFF = 0x0A8F
SINDY_AI_STOCK = bytes.fromhex("80 3D 03 74 03 E9 C8 00")
SINDY_AI_V018X = bytes.fromhex("80 7D 01 03 75 F9 90 90")
SINDY_AI_V0187 = bytes.fromhex("8A 05 24 7F 3C 03 75 F7")
SINDY_PL_DATA4_RELOC_SOURCE = 0x0A17
SINDY_PL_DATA4_ORDINAL = 747
SINDY_AI_FIXED = bytes.fromhex("2E 3B 3E 17 0A 75 F8 90")
SINDY_STATE_RESTORE_IMM_OFF = 0x0A27
SINDY_STATE_RESTORE_OLD = 0x03
SINDY_STATE_RESTORE_V01818 = 0x83
SINDY_STATE_RESTORE_NEW = 0x03

def _jmp16(target: int, next_ip: int) -> bytes:
    return b"\xE9" + struct.pack("<H", (target - next_ip) & 0xFFFF)

# Known-bad v0.18.15 fixed tail trampoline.  It is recognized only for safe
# migration; the 0D40h payload itself is never trusted as live dialogue data.
SINDY_RUNTIME_HELPER_V01815_OFF = 0x0D40
SINDY_RUNTIME_HELPER_V01815_PRE_LEN = 0x0D37  # exact R17 payload before v0.18.15 padded to 0D40h
SINDY_RUNTIME_HELPER_V01815 = bytes.fromhex(
    "2e 3b 3e 17 0a 75 20 8a 05 24 7f 3c 03 75 18 80 0d 80 "
    "c7 45 10 6c 07 c7 45 12 f4 01 c6 45 16 46 c6 45 19 0f "
    "e9 30 fd e9 24 fd"
)
SINDY_RUNTIME_HELPER_V01815_END = SINDY_RUNTIME_HELPER_V01815_OFF + len(SINDY_RUNTIME_HELPER_V01815)
SINDY_AI_BRANCH_V01815 = _jmp16(SINDY_RUNTIME_HELPER_V01815_OFF, SINDY_AI_OFF + 3) + b"\x90" * 5
assert SINDY_RUNTIME_HELPER_V01815_END == 0x0D6A

# Exact PL_DATA_4 has already been proven by the gate at 0A8F.  0A97h is reached
# only for Sindy (non-Sindy DI returns through 0A8Eh), so the hook can normalize
# state and reassert final runtime combat values without another import fixup.
SINDY_ACTION_HOOK_OFF = 0x0A97
SINDY_ACTION_HOOK_STOCK = bytes.fromhex("83 C4 04")  # add sp,4
SINDY_RUNTIME_HELPER_ALIGN = 2
SINDY_RUNTIME_HELPER_MIN_OFF = 0x0CCE  # strictly after v0.14 owned code/helpers

def _align_up(value: int, align: int) -> int:
    return (int(value) + align - 1) // align * align

def _build_sindy_runtime_helper(helper_off: int) -> bytes:
    h = bytearray()
    h += bytes.fromhex("80 25 7F")  # state 83h -> 03h before common action/message code
    h += b"\xC7\x45\x0A" + struct.pack("<H", SINDY_INT2)
    h += b"\xC7\x45\x10" + struct.pack("<H", SINDY_ATTACK)
    h += b"\xC7\x45\x12" + struct.pack("<H", SINDY_DEFENSE)
    h += bytes((0xC6, 0x45, 0x16, SINDY_AGILITY))
    h += bytes((0xC6, 0x45, 0x19, SINDY_WEAPON))
    h += SINDY_ACTION_HOOK_STOCK  # original add sp,4
    h += _jmp16(0x0A9A, helper_off + len(h) + 3)
    return bytes(h)

SINDY_RUNTIME_HELPER_LEN = len(_build_sindy_runtime_helper(0))
assert SINDY_RUNTIME_HELPER_LEN == 32

# Exact v0.18.18 runtime helper, accepted only for direct upgrade.  Its shape is
# identical; only the old final ATT immediate differs (1600 instead of 1200).
def _build_sindy_runtime_helper_v01818(helper_off: int) -> bytes:
    h = bytearray()
    h += bytes.fromhex("80 25 7F")
    h += b"\xC7\x45\x0A" + struct.pack("<H", 1667)
    h += b"\xC7\x45\x10" + struct.pack("<H", 1600)
    h += b"\xC7\x45\x12" + struct.pack("<H", 500)
    h += bytes((0xC6, 0x45, 0x16, 70))
    h += bytes((0xC6, 0x45, 0x19, 15))
    h += SINDY_ACTION_HOOK_STOCK
    h += _jmp16(0x0A9A, helper_off + len(h) + 3)
    return bytes(h)

# Phase 2 enters at 0891h with AL==2 and stock jumps directly to 0721h,
# skipping the 36-byte Sindy template copy at 0872h.  Redirect only that
# exact phase-2 branch to an appended helper.  The helper reuses the already
# relocated PL_DATA_4 immediate stored in the original `BF imm16` at 0875h,
# so no new NE relocation row is introduced.
SINDY_PHASE2_BRANCH_OFF = 0x0891
SINDY_PHASE2_BRANCH_STOCK = bytes.fromhex("3C 02 75 03 E9 89 FE")
SINDY_PHASE2_PL_DATA4_IMM_SOURCE = 0x0876
SINDY_PHASE2_COPY_RETURN = 0x0721
SINDY_PHASE2_HELPER_ALIGN = 2

def _build_sindy_phase2_helper(helper_off: int) -> bytes:
    h = bytearray()
    h += bytes.fromhex("BE 12 02")             # SI = local Sindy template
    h += bytes.fromhex("2E 8B 3E 76 08")       # DI = relocated PL_DATA_4 offset encoded at CS:0876
    h += bytes.fromhex("B9 24 00 F3 A4")       # copy 36 bytes, same as phase 1
    h += _jmp16(SINDY_PHASE2_COPY_RETURN, helper_off + len(h) + 3)
    return bytes(h)

SINDY_PHASE2_HELPER_LEN = len(_build_sindy_phase2_helper(0))
assert SINDY_PHASE2_HELPER_LEN == 16

def _phase2_hook_for(helper_off: int) -> bytes:
    return bytes.fromhex("3C 02 75 03") + _jmp16(helper_off, SINDY_PHASE2_BRANCH_OFF + 7)

def _phase2_helper_target(hook: bytes) -> int | None:
    if hook == SINDY_PHASE2_BRANCH_STOCK:
        return None
    if len(hook) == 7 and hook[:4] == bytes.fromhex("3C 02 75 03") and hook[4] == 0xE9:
        disp = struct.unpack_from("<h", hook, 5)[0]
        return (SINDY_PHASE2_BRANCH_OFF + 7 + disp) & 0xFFFF
    return None

def _action_hook_for(helper_off: int) -> bytes:
    return _jmp16(helper_off, SINDY_ACTION_HOOK_OFF + 3)

def _helper_target_from_action_hook(hook: bytes) -> int | None:
    if hook == SINDY_ACTION_HOOK_STOCK:
        return None
    if len(hook) == 3 and hook[0] == 0xE9:
        disp = struct.unpack_from("<h", hook, 1)[0]
        return (SINDY_ACTION_HOOK_OFF + 3 + disp) & 0xFFFF
    return None

def _strip_exact_v01815_r17_helper(data: bytearray) -> bytearray:
    """Canonicalize the exact v1.4.64/R17 v0.18.15 tail to its pre-helper length.

    v0.18.15 extended seg3 from 0D37h to 0D6Ah, filled 0D37..0D3F
    with NOP, wrote its 42-byte helper at 0D40h, and moved the existing
    relocation table.  When all of those signatures match exactly we can
    losslessly reverse only that owned extension.  This makes an upgrade from
    the released v1.4.64 converge to the same bytes as a fresh v0.18.18 install.
    """
    _, _, segs = core.ne_info(data)
    seg = segs[C734_SEGMENT - 1]
    base = seg["off"]
    if seg["len"] != SINDY_RUNTIME_HELPER_V01815_END:
        return data
    if bytes(data[base + SINDY_RUNTIME_HELPER_V01815_OFF:base + SINDY_RUNTIME_HELPER_V01815_END]) != SINDY_RUNTIME_HELPER_V01815:
        return data
    if bytes(data[base + SINDY_RUNTIME_HELPER_V01815_PRE_LEN:base + SINDY_RUNTIME_HELPER_V01815_OFF]) != b"\x90" * (SINDY_RUNTIME_HELPER_V01815_OFF - SINDY_RUNTIME_HELPER_V01815_PRE_LEN):
        raise PatchError("C_734 v0.18.15 pre-helper padding differs")
    rows = core.relocation_records(data, seg)
    old_rs = base + seg["len"]
    old_reloc_end = old_rs + 2 + len(rows) * 8
    nextoff = core.next_segment_offset(segs, seg)
    table = bytes(data[old_rs:old_reloc_end])
    newlen = SINDY_RUNTIME_HELPER_V01815_PRE_LEN
    new_rs = base + newlen
    new_reloc_end = new_rs + len(table)
    if new_reloc_end > nextoff:
        raise PatchError("C_734 v0.18.15 canonical relocation overlap")
    data[new_rs:new_reloc_end] = table
    data[new_reloc_end:nextoff] = b"\x00" * (nextoff - new_reloc_end)
    struct.pack_into("<H", data, seg["entry"] + 2, newlen)
    if seg["alloc"]:
        struct.pack_into("<H", data, seg["entry"] + 6, newlen)
    _, _, segs2 = core.ne_info(data)
    seg2 = segs2[C734_SEGMENT - 1]
    if seg2["len"] != newlen or bytes(data[base + newlen:base + newlen + len(table)]) != table:
        raise PatchError("C_734 v0.18.15 canonicalization verification failed")
    return data


def _append_sindy_runtime_helper(data: bytearray) -> tuple[bytearray, int]:
    """Append the helper after current seg3 payload and move relocations safely.

    No file insertion and no other segment offset changes are needed: C_734 has
    a verified alignment gap before segment 4.  Existing relocation rows are
    copied byte-for-byte, so R17 out-of-line dialogue redirects are preserved.
    """
    _, _, segs = core.ne_info(data)
    seg = segs[C734_SEGMENT - 1]
    base = seg["off"]
    oldlen = seg["len"]
    rows = core.relocation_records(data, seg)
    nextoff = core.next_segment_offset(segs, seg)
    old_rs = base + oldlen
    old_reloc_end = old_rs + 2 + len(rows) * 8
    helper_off = _align_up(oldlen, SINDY_RUNTIME_HELPER_ALIGN)
    if helper_off < SINDY_RUNTIME_HELPER_MIN_OFF:
        helper_off = _align_up(SINDY_RUNTIME_HELPER_MIN_OFF, SINDY_RUNTIME_HELPER_ALIGN)
    helper = _build_sindy_runtime_helper(helper_off)
    newlen = helper_off + len(helper)
    new_rs = base + newlen
    table = bytes(data[old_rs:old_reloc_end])
    new_reloc_end = new_rs + len(table)
    if new_reloc_end > nextoff:
        raise PatchError(
            f"C_734 Sindy helper needs {new_reloc_end-nextoff} more bytes before segment 4"
        )
    # Only consume previously unused inter-segment padding beyond the old
    # relocation table.  Nonzero bytes there indicate an unknown/custom layout.
    extra_gap_start = max(old_reloc_end, base + helper_off)
    if any(data[extra_gap_start:new_reloc_end]):
        raise PatchError("C_734 inter-segment padding is not empty; refusing helper append")
    # Save table first because helper/padding overwrites the old table position.
    if helper_off > oldlen:
        data[base + oldlen:base + helper_off] = b"\x90" * (helper_off - oldlen)
    data[base + helper_off:base + helper_off + len(helper)] = helper
    data[new_rs:new_reloc_end] = table
    data[new_reloc_end:nextoff] = b"\x00" * (nextoff - new_reloc_end)
    struct.pack_into("<H", data, seg["entry"] + 2, newlen)
    if seg["alloc"]:
        struct.pack_into("<H", data, seg["entry"] + 6, newlen)
    # Reparse and verify that every existing relocation row survived byte-identical.
    _, _, segs2 = core.ne_info(data)
    seg2 = segs2[C734_SEGMENT - 1]
    if seg2["len"] != newlen or seg2["alloc"] != newlen:
        raise PatchError("C_734 segment length/minalloc update failed")
    if bytes(data[base + newlen:base + newlen + len(table)]) != table:
        raise PatchError("C_734 relocation table move failed")
    return data, helper_off

def _append_raw_seg3_helper(data: bytearray, payload_builder, align: int = 2) -> tuple[bytearray, int]:
    """Append a relocation-free helper after current seg3 payload.

    Existing relocation bytes are moved byte-identically; the helper may not
    contain absolute imported addresses.  This is used for the phase-2 Sindy
    reset helper, which reuses the already relocated PL_DATA_4 operand at 0876h.
    """
    _, _, segs = core.ne_info(data)
    seg = segs[C734_SEGMENT - 1]
    base = seg["off"]
    oldlen = seg["len"]
    rows = core.relocation_records(data, seg)
    old_rs = base + oldlen
    old_reloc_end = old_rs + 2 + len(rows) * 8
    nextoff = core.next_segment_offset(segs, seg)
    helper_off = _align_up(oldlen, align)
    helper = payload_builder(helper_off)
    newlen = helper_off + len(helper)
    table = bytes(data[old_rs:old_reloc_end])
    new_rs = base + newlen
    new_reloc_end = new_rs + len(table)
    if new_reloc_end > nextoff:
        raise PatchError("C_734 phase-2 helper overlaps segment 4")
    extra_gap_start = max(old_reloc_end, base + helper_off)
    if any(data[extra_gap_start:new_reloc_end]):
        raise PatchError("C_734 phase-2 helper padding is not empty")
    if helper_off > oldlen:
        data[base + oldlen:base + helper_off] = b"\x90" * (helper_off - oldlen)
    data[base + helper_off:base + helper_off + len(helper)] = helper
    data[new_rs:new_reloc_end] = table
    data[new_reloc_end:nextoff] = b"\x00" * (nextoff - new_reloc_end)
    struct.pack_into("<H", data, seg["entry"] + 2, newlen)
    if seg["alloc"]:
        struct.pack_into("<H", data, seg["entry"] + 6, newlen)
    _, _, segs2 = core.ne_info(data)
    seg2 = segs2[C734_SEGMENT - 1]
    if seg2["len"] != newlen or bytes(data[base + newlen:base + newlen + len(table)]) != table:
        raise PatchError("C_734 phase-2 helper append verification failed")
    return data, helper_off

# Framna (magic 12) uses Sindy's PLY_INT2 with MAGIC_BAIRITU=30.
# In the exact C_734 item-magic path (USE_ITEM_FLAG=2), CALC_MAG_KOKA writes
# floor(INT2 * 30 / 100) to MAGIC_KOKA_NUM.  MG_BURAMUNA then routes that
# value through SET_DAMMEGE; the 0x32 magic flags make CALC_MAG_DAMMEGE keep
# DX unchanged for this branch.  SET_DAMMEGE subtracts DX directly from HP.
# INT2=1667 therefore gives exactly 500 damage on either valid Godwin target.
SINDY_BREATH_MAGIC_ID = 12
SINDY_BREATH_MAGIC_RATIO = 30
SINDY_BREATH_DAMAGE = (SINDY_INT2 * SINDY_BREATH_MAGIC_RATIO) // 100
assert SINDY_BREATH_DAMAGE == 500

# PC-98 C_734: 「は大きくはばたいた。」 and
# 「皇帝 ゴドウィン２世を倒した。」.  Both fit their existing Korean slots.
C734_WING_MSG_OFF = 0x02DA
C734_WING_OLD_TEXT = "는 크게 날개를 쳤다."
C734_WING_NEW_TEXT = "는 크게 날갯짓했다."
C734_WING_FIELD_LEN = 21
C734_WING_OLD = C734_WING_OLD_TEXT.encode("cp949") + b"\x07"
C734_WING_NEW = C734_WING_NEW_TEXT.encode("cp949") + b"\x07" + b"\x00"
assert len(C734_WING_OLD) == len(C734_WING_NEW) == C734_WING_FIELD_LEN
C734_BATTLE_MSG_OFF = 0x02F0
C734_BATTLE_OLD_STOCK = "황제 고드윈2세를 무찔렀다. ".encode("cp949") + b"\x07"
C734_BATTLE_OLD_CURRENT = "황제 고드윈 2세를 무찔렀다.".encode("cp949") + b"\x07"
C734_BATTLE_NEW_TEXT = "황제 고드윈 2세를 격파했다."
C734_BATTLE_NEW = C734_BATTLE_NEW_TEXT.encode("cp949") + b"\x07"
assert len(C734_BATTLE_OLD_STOCK) == len(C734_BATTLE_OLD_CURRENT) == len(C734_BATTLE_NEW) == 28

# ALGO_06 has two legitimate Sindy actions.  The branch at 0AD2 enters the
# stock fire-breath path: message "화염을 내뿜었다", ITEM_MAGIC=0Ch (Framna),
# CALC_MAG_KOKA, then EXEC_MAGIC_SUB.  PC-98 C_734 uses the same Framna path.
# v0.16.0 incorrectly NOPed this jump; v0.17.0 keeps it restored.
SINDY_FIRE_BREATH_BRANCH_OFF = 0x0AD2
SINDY_FIRE_BREATH_BRANCH = bytes.fromhex("EB 37")  # JMP 0B0Bh
SINDY_V0160_WRONG_NOP = bytes.fromhex("90 90")

ALGO09_WRAPPER = 0x05DB
FE999_HELPER = 0x0CBE
FE999_HELPER_END = 0x0CC9
EXPLOSION_ENTRY = 0x0B74
FE999_ID = 0x63


def _near(target: int, next_ip: int) -> bytes:
    return struct.pack("<H", (target - next_ip) & 0xFFFF)


# PUSH CS / CALL near helper / RETF.  The helper plays FE999 once, then jumps
# into the original explosion sequence at 0B74.
ALGO09_WRAPPER_NEW = b"\x0E\xE8" + _near(FE999_HELPER, ALGO09_WRAPPER + 4) + b"\xCB"
assert len(ALGO09_WRAPPER_NEW) == 5
FE999_HELPER_BYTES = (
    b"\xBB\x01" + bytes((FE999_ID,)) +  # mov bx,6301h (effect 63h, variant 1)
    b"\xB4\x03" +                       # mov ah,03h
    b"\xCD\x40" +                       # int 40h
    b"\xE9" + _near(EXPLOSION_ENTRY, FE999_HELPER + 10) +
    b"\x90"
)
assert len(FE999_HELPER_BYTES) == FE999_HELPER_END - FE999_HELPER == 11


def _seg3(data: bytes | bytearray) -> tuple[dict[str, int], int]:
    _, _, segs = core.ne_info(data)
    seg = segs[C734_SEGMENT - 1]
    return seg, seg["off"]


def _m501_seg3(data: bytes | bytearray) -> tuple[dict[str, int], int]:
    _, _, segs = core.ne_info(data)
    seg = segs[M501_SEGMENT - 1]
    return seg, seg["off"]


def _sindy_values(data: bytes | bytearray) -> dict[str, int]:
    seg, base = _seg3(data)
    if SINDY_TEMPLATE + SINDY_TEMPLATE_LEN > seg["len"]:
        raise PatchError("C_734 Sindy template is outside segment 3")
    p = base + SINDY_TEMPLATE
    return {
        "state": data[p + 0x00],
        "slot": data[p + 0x01],
        "level": data[p + 0x03],
        "hp": struct.unpack_from("<H", data, p + 0x04)[0],
        "max_hp": struct.unpack_from("<H", data, p + 0x06)[0],
        "int2": struct.unpack_from("<H", data, p + 0x0A)[0],
        "attack": struct.unpack_from("<H", data, p + 0x10)[0],
        "defense": struct.unpack_from("<H", data, p + 0x12)[0],
        "int": data[p + 0x15],
        "agility": data[p + 0x16],
        "luck": data[p + 0x17],
        "weapon": data[p + 0x19],
    }


def inspect_m501(data: bytes) -> dict[str, object]:
    try:
        seg, base = _m501_seg3(data)
        hp = struct.unpack_from("<H", data, base + M501_HP_CUR)[0]
        max_hp = struct.unpack_from("<H", data, base + M501_HP_MAX)[0]
        name_field = bytes(data[base + M501_NAME_OFF:base + M501_NAME_OFF + 16])
        title = bytes(data[base + M501_TITLE_OFF:base + M501_TITLE_OFF + len(M501_TITLE_FIELD)])
        quote = bytes(data[base + M501_QUOTE_OFF:base + M501_QUOTE_OFF + len(M501_QUOTE_NEW)])
        total_damage_field = bytes(data[base + M501_TOTAL_DAMAGE_OFF:base + M501_TOTAL_DAMAGE_OFF + M501_TOTAL_DAMAGE_LEN])
        skill_region = bytes(data[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END])
        post_control = bytes(data[base + M501_POST_SKILL_CONTROL_OFF:base + M501_POST_SKILL_CONTROL_OFF + 5])
        skill_si = {off: bytes(data[base + off:base + off + 3]) for off in M501_SKILL_SI_STOCK}
        rel = core.reloc_one(data, seg, M501_SKILL1_CALL_RELOC)
        skill_renderer_stock = (
            rel[1] == 3 and (rel[2] & 7) == 1 and
            rel[4] == M501_MESSAGE_MODULE and rel[5] == M501_SKILL1_ORDINAL_STOCK
        )
        rows = core.relocation_records(data, seg)
        sources = [r[3] for r in rows]
        multi_trampoline = bytes(data[base + M501_MULTI_TARGET_CALL_OFF:base + M501_MULTI_TARGET_CALL_OFF + 5])
        multi_retry = data[base + M501_MULTI_TARGET_RETRY_DISP_OFF]
        multi_helper = bytes(data[base + M501_MULTI_TARGET_HELPER_OFF:base + M501_MULTI_TARGET_HELPER_OFF + len(M501_MULTI_TARGET_HELPER)])
        pl_data1_ref_ok = core.reloc_matches(data, seg, M501_PL_DATA1_RELOC_SOURCE, 5, 5, 1, M501_PL_DATA1_ORDINAL)
        self_target_fixed = (
            multi_trampoline == M501_MULTI_TARGET_TRAMPOLINE and
            multi_retry == M501_MULTI_TARGET_RETRY_FIXED and
            multi_helper == M501_MULTI_TARGET_HELPER and
            M501_MULTI_TARGET_RELOC_SOURCE not in sources and
            pl_data1_ref_ok
        )
        actor_guard_trampoline = bytes(data[base + M501_ACTOR_GUARD_CALL_OFF:base + M501_ACTOR_GUARD_CALL_OFF + len(M501_ACTOR_GUARD_TRAMPOLINE)])
        actor_guard_helper = bytes(data[base + M501_ACTOR_GUARD_HELPER_OFF:base + M501_ACTOR_GUARD_HELPER_OFF + len(M501_ACTOR_GUARD_HELPER)])
        actor_guard_fixed = (
            actor_guard_trampoline == M501_ACTOR_GUARD_TRAMPOLINE and
            actor_guard_helper == M501_ACTOR_GUARD_HELPER
        )
        skill_fixed = (
            skill_region == M501_SKILL_REGION_V0188 and
            post_control == M501_POST_SKILL_CONTROL and
            skill_si[M501_SKILL1_SI] == M501_SKILL_SI_STOCK[M501_SKILL1_SI] and
            skill_si[M501_SKILL2_SI] == M501_SKILL_SI_STOCK[M501_SKILL2_SI] and
            skill_si[M501_SKILL3_SI] == M501_SKILL3_SI_FIXED and
            skill_renderer_stock
        )
        core_state = core.inspect_m501_bytes(data)
        code_ok = bool(core_state.get("original"))
        scaling = _m501_v1462_damage_state(data, seg, base)
        scaling_ok = scaling.get("state") in ("stock-fixed-300", "scaled-v1.4.62", "scaled-v1.4.63")
        patched = (
            hp == M501_HP and max_hp == M501_HP and
            name_field == M501_NAME_FIELD and title == M501_TITLE_FIELD and
            quote == M501_QUOTE_NEW and total_damage_field == M501_TOTAL_DAMAGE_NEW and
            code_ok and skill_fixed and self_target_fixed and actor_guard_fixed and scaling_ok
        )
        return {
            "supported": bool(core_state.get("supported")) or patched,
            "patched": patched,
            "godwin_hp": hp,
            "godwin_max_hp": max_hp,
            "godwin_dynamic_actor_name": M501_NAME if name_field == M501_NAME_FIELD else name_field.rstrip(b"\0").decode("cp949", "replace"),
            "godwin_quote_speaker_stream_stock": title == M501_TITLE_FIELD,
            "godwin_quote_pc98_faithful": quote == M501_QUOTE_NEW,
            "godwin_skill3_terminated_and_relocated": skill_fixed,
            "godwin_skill1_pc98_chest_message": bytes(data[base + M501_SKILL1_TEXT_OFF:base + M501_SKILL1_TEXT_OFF + M501_SKILL1_FIELD_LEN]) == M501_SKILL1_FIELD,
            "godwin_continuous_attack_player_slots_only": self_target_fixed,
            "godwin_continuous_attack_choice_teki_reloc_removed": M501_MULTI_TARGET_RELOC_SOURCE not in sources,
            "godwin_continuous_attack_retry_rerolls": multi_retry == M501_MULTI_TARGET_RETRY_FIXED,
            "godwin_continuous_attack_total_spacing": total_damage_field == M501_TOTAL_DAMAGE_NEW,
            "godwin_continuous_attack_total_field_hex": total_damage_field.hex(" "),
            "godwin_ai_monster_side_only": actor_guard_fixed,
            "sindy_blocked_from_godwin_skill_stream": actor_guard_fixed,
            "late_skill_scaling_interop": scaling,
            "late_skill_scaling_preserved": scaling_ok,
            "skill_renderer_import_ordinal": rel[5],
            "skill_region_sha256": sha256(skill_region),
            "legacy_wrong_transform_removed": code_ok,
            "segment_length": seg["len"],
            "segment_minalloc": seg["alloc"],
            "relocation_count": len(rows),
            "sha256": sha256(data),
        }
    except Exception as exc:
        return {"supported": False, "patched": False, "error": str(exc), "sha256": sha256(data)}


def _rollback_v018x_skill_rewrite(before: bytes) -> bytes:
    """Undo only our v0.18.2/v0.18.3 M_501 skill experiment.

    This is deliberately signature-gated. Unknown/custom skill streams are left
    alone and will be rejected later rather than guessed at.
    """
    d = bytearray(before)
    seg, base = _m501_seg3(d)
    region = bytes(d[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END])
    si = {off: bytes(d[base + off:base + off + 3]) for off in M501_SKILL_SI_STOCK}
    rel = core.reloc_one(d, seg, M501_SKILL1_CALL_RELOC)
    rel_ord = rel[5]
    is_v018x = (
        region == M501_SKILL_REGION_V018X and
        all(si[k] == v for k, v in M501_SKILL_SI_V018X.items()) and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_V018X
    )
    is_stock = (
        region == M501_SKILL_REGION_STOCK and
        all(si[k] == v for k, v in M501_SKILL_SI_STOCK.items()) and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_STOCK
    )
    is_v0187 = (
        region == M501_SKILL_REGION_FIXED and
        si[M501_SKILL1_SI] == M501_SKILL_SI_STOCK[M501_SKILL1_SI] and
        si[M501_SKILL2_SI] == M501_SKILL_SI_STOCK[M501_SKILL2_SI] and
        si[M501_SKILL3_SI] == M501_SKILL3_SI_FIXED and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_STOCK
    )
    is_v0188 = (
        region == M501_SKILL_REGION_V0188 and
        si[M501_SKILL1_SI] == M501_SKILL_SI_STOCK[M501_SKILL1_SI] and
        si[M501_SKILL2_SI] == M501_SKILL_SI_STOCK[M501_SKILL2_SI] and
        si[M501_SKILL3_SI] == M501_SKILL3_SI_FIXED and
        rel[4] == M501_MESSAGE_MODULE and rel_ord == M501_SKILL1_ORDINAL_STOCK
    )
    if is_stock or is_v0187 or is_v0188:
        return before
    if not is_v018x:
        raise PatchError(
            "M_501 skill stream is neither stock/v0.18.1 nor the exact v0.18.2/v0.18.3 experimental state"
        )
    d[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END] = M501_SKILL_REGION_STOCK
    d[base + M501_POST_SKILL_CONTROL_OFF:base + M501_POST_SKILL_CONTROL_OFF + 5] = M501_POST_SKILL_CONTROL
    for off, raw in M501_SKILL_SI_STOCK.items():
        d[base + off:base + off + 3] = raw
    core.set_reloc_target(d, seg, M501_SKILL1_CALL_RELOC, 1, M501_MESSAGE_MODULE, M501_SKILL1_ORDINAL_STOCK)
    return bytes(d)

def patch_m501(before: bytes) -> bytes:
    initial = inspect_m501(before)
    if initial.get("patched"):
        return before

    # Preserve the independent v1.4.62 late-skill-scaling owner exactly.
    pre_seg, pre_base = _m501_seg3(before)
    scaling_before = _m501_v1462_damage_state(before, pre_seg, pre_base)
    if scaling_before.get("state") not in ("stock-fixed-300", "scaled-v1.4.62", "scaled-v1.4.63"):
        raise PatchError(f"M_501 late-skill-scaling site is unsupported: {scaling_before}")
    damage_site_before = bytes(
        before[pre_base + M501_V1462_DAMAGE_OFF:pre_base + M501_V1462_DAMAGE_OFF + 3]
    )

    # First undo only the v0.18.2/v0.18.3 skill experiment if present. This is
    # the user-requested rollback: no skill strings, renderers or control streams
    # remain modified by the final-battle component.
    normalized = _rollback_v018x_skill_rewrite(before)

    # Then remove the much older v1.0.63 experimental transform if needed.
    try:
        d = bytearray(core.restore_m501_bytes(normalized))
    except Exception as exc:
        raise PatchError(f"M_501 base state is unsupported: {exc}") from exc

    seg, base = _m501_seg3(d)
    damage_site_after_normalize = bytes(
        d[base + M501_V1462_DAMAGE_OFF:base + M501_V1462_DAMAGE_OFF + 3]
    )
    if damage_site_after_normalize != damage_site_before:
        raise PatchError(
            "M_501 late-skill-scaling owner changed during presentation normalization: "
            f"{damage_site_before.hex(' ')} -> {damage_site_after_normalize.hex(' ')}"
        )
    # Reassert stock skill bytes after legacy normalization. No-growth/no-relayout.
    d[base + M501_SKILL_REGION_START:base + M501_SKILL_REGION_END] = M501_SKILL_REGION_STOCK
    d[base + M501_POST_SKILL_CONTROL_OFF:base + M501_POST_SKILL_CONTROL_OFF + 5] = M501_POST_SKILL_CONTROL
    for off, raw in M501_SKILL_SI_STOCK.items():
        d[base + off:base + off + 3] = raw
    core.set_reloc_target(d, seg, M501_SKILL1_CALL_RELOC, 1, M501_MESSAGE_MODULE, M501_SKILL1_ORDINAL_STOCK)

    # Fix only the malformed third skill without moving any live stream.  The
    # stock 00A6 bytes stay untouched; only the verified zero pad and the one
    # MOV SI immediate used by skill 3 change.
    pad = bytes(d[base + M501_SKILL3_FIXED_OFF:base + M501_SKILL3_FIXED_OFF + M501_SKILL3_PAD_LEN])
    if pad not in (b"\x00" * M501_SKILL3_PAD_LEN, M501_SKILL3_FIELD):
        raise PatchError(f"M_501 0062..007F is not the verified skill-3 pad: {pad.hex(' ')}")
    d[base + M501_SKILL3_FIXED_OFF:base + M501_SKILL3_FIXED_OFF + M501_SKILL3_PAD_LEN] = M501_SKILL3_FIELD
    d[base + M501_SKILL3_SI:base + M501_SKILL3_SI + 3] = M501_SKILL3_SI_FIXED

    # PC-98-faithful skill-1 wording, in the original fixed slot.
    old_skill1 = bytes(d[base + M501_SKILL1_TEXT_OFF:base + M501_SKILL1_TEXT_OFF + M501_SKILL1_FIELD_LEN])
    if old_skill1 not in (M501_SKILL1_OLD, M501_SKILL1_FIELD):
        raise PatchError(f"M_501 skill-1 message signature differs: {old_skill1.hex(' ')}")
    d[base + M501_SKILL1_TEXT_OFF:base + M501_SKILL1_TEXT_OFF + M501_SKILL1_FIELD_LEN] = M501_SKILL1_FIELD

    # Continuous-attack total damage display: preserve the 21-byte slot while
    # adding the missing blank before the dynamic number and using the natural
    # Korean `대미지` suffix.
    old_total = bytes(d[base + M501_TOTAL_DAMAGE_OFF:base + M501_TOTAL_DAMAGE_OFF + M501_TOTAL_DAMAGE_LEN])
    if old_total not in (M501_TOTAL_DAMAGE_OLD, M501_TOTAL_DAMAGE_NEW):
        raise PatchError(f"M_501 total-damage message signature differs: {old_total.hex(' ')}")
    d[base + M501_TOTAL_DAMAGE_OFF:base + M501_TOTAL_DAMAGE_OFF + M501_TOTAL_DAMAGE_LEN] = M501_TOTAL_DAMAGE_NEW

    # Continuous attack must never call the side-sensitive shared CHOICE_TEKI.
    # Reuse the now-unreferenced malformed old skill-3 bytes as a tiny selector
    # helper.  A dead target retries at RANDOM (0362h), not at the helper, so a
    # different player slot is selected on each retry.
    d[base + M501_MULTI_TARGET_HELPER_OFF:base + M501_MULTI_TARGET_HELPER_OFF + len(M501_MULTI_TARGET_HELPER)] = M501_MULTI_TARGET_HELPER
    old_call = bytes(d[base + M501_MULTI_TARGET_CALL_OFF:base + M501_MULTI_TARGET_CALL_OFF + 5])
    sources = {r[3] for r in core.relocation_records(d, seg)}
    if M501_MULTI_TARGET_RELOC_SOURCE in sources:
        if old_call != b"\x9A\xFF\xFF\x00\x00":
            raise PatchError(f"M_501 continuous-attack CHOICE_TEKI call differs: {old_call.hex(' ')}")
        d[base + M501_MULTI_TARGET_CALL_OFF:base + M501_MULTI_TARGET_CALL_OFF + 5] = M501_MULTI_TARGET_TRAMPOLINE
        core.remove_reloc_sources(d, seg, {M501_MULTI_TARGET_RELOC_SOURCE})
    elif old_call != M501_MULTI_TARGET_TRAMPOLINE:
        raise PatchError("M_501 continuous-attack relocation is absent but trampoline is not present")
    retry = d[base + M501_MULTI_TARGET_RETRY_DISP_OFF]
    if retry not in (M501_MULTI_TARGET_RETRY_STOCK, M501_MULTI_TARGET_RETRY_FIXED):
        raise PatchError(f"M_501 continuous-attack retry differs: {retry:02X}")
    d[base + M501_MULTI_TARGET_RETRY_DISP_OFF] = M501_MULTI_TARGET_RETRY_FIXED

    # Monster-only actor guard.  Accept either the retail action-flag test or
    # our exact v0.18.15 trampoline; never overwrite an unknown transform.
    old_guard = bytes(d[base + M501_ACTOR_GUARD_CALL_OFF:base + M501_ACTOR_GUARD_CALL_OFF + len(M501_ACTOR_GUARD_STOCK)])
    old_helper = bytes(d[base + M501_ACTOR_GUARD_HELPER_OFF:base + M501_ACTOR_GUARD_HELPER_OFF + len(M501_ACTOR_GUARD_HELPER)])
    if old_guard == M501_ACTOR_GUARD_STOCK:
        if old_helper != b"\x00" * len(M501_ACTOR_GUARD_HELPER):
            raise PatchError(f"M_501 actor-guard pad is not empty: {old_helper.hex(' ')}")
        d[base + M501_ACTOR_GUARD_HELPER_OFF:base + M501_ACTOR_GUARD_HELPER_OFF + len(M501_ACTOR_GUARD_HELPER)] = M501_ACTOR_GUARD_HELPER
        d[base + M501_ACTOR_GUARD_CALL_OFF:base + M501_ACTOR_GUARD_CALL_OFF + len(M501_ACTOR_GUARD_TRAMPOLINE)] = M501_ACTOR_GUARD_TRAMPOLINE
    elif old_guard == M501_ACTOR_GUARD_TRAMPOLINE:
        if old_helper != M501_ACTOR_GUARD_HELPER:
            raise PatchError("M_501 actor-guard trampoline exists but helper differs")
    else:
        raise PatchError(f"M_501 actor-guard entry differs: {old_guard.hex(' ')}")

    struct.pack_into("<H", d, base + M501_HP_CUR, M501_HP)
    struct.pack_into("<H", d, base + M501_HP_MAX, M501_HP)
    # Critical minimal fix: dynamic skill-name path gets the stock actor name.
    # Do NOT inject the expanded title into this buffer.
    d[base + M501_NAME_OFF:base + M501_NAME_OFF + 16] = M501_NAME_FIELD
    # Restore the stock quote-only speaker composition and replace only the quote
    # sentence itself.  The next control/data streams are untouched.
    d[base + M501_TITLE_OFF:base + M501_TITLE_OFF + len(M501_TITLE_FIELD)] = M501_TITLE_FIELD
    old_quote = bytes(d[base + M501_QUOTE_OFF:base + M501_QUOTE_OFF + len(M501_QUOTE_NEW)])
    if old_quote not in (M501_QUOTE_OLD, M501_QUOTE_V01810, M501_QUOTE_NEW):
        raise PatchError(f"M_501 quote signature differs: {old_quote.hex(' ')}")
    d[base + M501_QUOTE_OFF:base + M501_QUOTE_OFF + len(M501_QUOTE_NEW)] = M501_QUOTE_NEW

    damage_site_final = bytes(
        d[base + M501_V1462_DAMAGE_OFF:base + M501_V1462_DAMAGE_OFF + 3]
    )
    if damage_site_final != damage_site_before:
        raise PatchError(
            "M_501 late-skill-scaling value was not preserved: "
            f"{damage_site_before.hex(' ')} -> {damage_site_final.hex(' ')}"
        )
    out = bytes(d)
    st = inspect_m501(out)
    if not st.get("patched"):
        raise PatchError(f"M_501 v0.18.15 verification failed: {st}")
    return out

def _inspect_v014_dynamic(data: bytes) -> dict[str, object]:
    """Recognize the v0.14 presentation code inside a later tail-expanded segment.

    Scene Editor v0.5.x may append out-of-line message fragments to C_734 and add
    relocation rows.  Those additions do not move the original 0000..0CDD code,
    so validate the required code and relocation sources instead of demanding the
    historical exact segment length/relocation count.
    """
    try:
        _, _, segs = core.ne_info(data)
        seg = segs[C734_SEGMENT - 1]
        base = seg["off"]
        rows = core.relocation_records(data, seg)
        nextoff = core.next_segment_offset(segs, seg)
        rend = base + seg["len"] + 2 + len(rows) * 8
        reveal_ok = core._reveal_state(data, seg)[1]
        timing_ok = core._timing_state(data, seg)[1]
        final_ok = bytes(data[base + v140.FINAL_START:base + v140.FINAL_END]) == v140.FINAL
        pre_ok = bytes(data[base + v140.PRE_HELPER:base + v140.PRE_HELPER_END]) == v140.v130.C734_V074_PRE_HELPER
        post_ok = bytes(data[base + v140.POST_HELPER:base + v140.POST_HELPER_END]) == v140.v130.C734_V074_POST_HELPER
        zero_ok = bytes(data[base + 0x057E:base + 0x059C]) == b"\0" * 30
        rel_ok = all(core.reloc_matches(data, seg, src, *exp) for src, exp in v140.EXPECTED.items())
        sources = [r[3] for r in rows]
        rel_ok = rel_ok and all(src not in sources for src in v140.RETIRED) and len(sources) == len(set(sources))
        structure_ok = (
            seg["len"] >= v140.SEG_LEN and seg["alloc"] == seg["len"] and rend <= nextoff
        )
        ok = bool(reveal_ok and timing_ok and final_ok and pre_ok and post_ok and zero_ok and rel_ok and structure_ok)
        return {
            "patched": ok,
            "tail_expanded": seg["len"] > v140.SEG_LEN,
            "field_scene_restored": bool(reveal_ok and timing_ok),
            "relocations_ok": rel_ok,
            "segment_structure_ok": structure_ok,
            "segment_length": seg["len"],
            "segment_minalloc": seg["alloc"],
            "relocation_count": len(rows),
            "relocation_table_end": rend,
            "next_segment_offset": nextoff,
        }
    except Exception as exc:
        return {"patched": False, "error": str(exc)}


def inspect_c734(data: bytes) -> dict[str, object]:
    try:
        base_state = _inspect_v014_dynamic(data)
        seg, base = _seg3(data)
        vals = _sindy_values(data)
        ai = bytes(data[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8])
        state_restore = data[base + SINDY_STATE_RESTORE_IMM_OFF]
        action_hook = bytes(data[base + SINDY_ACTION_HOOK_OFF:base + SINDY_ACTION_HOOK_OFF + 3])
        runtime_helper_off = _helper_target_from_action_hook(action_hook)
        runtime_helper_ok = False
        runtime_helper = b""
        if (runtime_helper_off is not None and
                runtime_helper_off >= SINDY_RUNTIME_HELPER_MIN_OFF and
                runtime_helper_off + SINDY_RUNTIME_HELPER_LEN <= seg["len"]):
            runtime_helper = bytes(data[base + runtime_helper_off:base + runtime_helper_off + SINDY_RUNTIME_HELPER_LEN])
            runtime_helper_ok = runtime_helper == _build_sindy_runtime_helper(runtime_helper_off)
        fire_branch = bytes(data[base + SINDY_FIRE_BREATH_BRANCH_OFF:base + SINDY_FIRE_BREATH_BRANCH_OFF + 2])
        wrapper = bytes(data[base + ALGO09_WRAPPER:base + ALGO09_WRAPPER + 5])
        helper = bytes(data[base + FE999_HELPER:base + FE999_HELPER_END])
        sindy_ok = (
            vals["state"] == 0x03 and vals["slot"] == 0x03 and
            vals["level"] == SINDY_LEVEL and vals["hp"] == SINDY_HP and vals["max_hp"] == SINDY_HP and
            vals["int2"] == SINDY_INT2 and vals["attack"] == SINDY_BASE_ATTACK and vals["defense"] == SINDY_DEFENSE and vals["agility"] == SINDY_AGILITY and
            vals["weapon"] == SINDY_WEAPON
        )
        ai_ok = ai == SINDY_AI_FIXED
        state_restore_ok = state_restore == SINDY_STATE_RESTORE_NEW
        action_helper_ok = runtime_helper_ok
        phase2_hook = bytes(data[base + SINDY_PHASE2_BRANCH_OFF:base + SINDY_PHASE2_BRANCH_OFF + 7])
        phase2_helper_off = _phase2_helper_target(phase2_hook)
        phase2_helper_ok = False
        if (phase2_helper_off is not None and phase2_helper_off + SINDY_PHASE2_HELPER_LEN <= seg["len"]):
            phase2_helper_ok = bytes(data[base + phase2_helper_off:base + phase2_helper_off + SINDY_PHASE2_HELPER_LEN]) == _build_sindy_phase2_helper(phase2_helper_off)
        # The existing PL_DATA_4 relocations are intentionally reused.  0A17h
        # gates Sindy's AI, while 0876h supplies the destination offset for the
        # phase-2 template reset helper without adding a relocation row.

        # the runtime helper as its exact actor identity source.
        pl_data4_ref_ok = (core.reloc_matches(data, seg, SINDY_PL_DATA4_RELOC_SOURCE, 5, 5, 1, SINDY_PL_DATA4_ORDINAL) and
                           core.reloc_matches(data, seg, SINDY_PHASE2_PL_DATA4_IMM_SOURCE, 5, 5, 1, SINDY_PL_DATA4_ORDINAL))
        fire_breath_ok = fire_branch == SINDY_FIRE_BREATH_BRANCH
        fe_ok = wrapper == ALGO09_WRAPPER_NEW and helper == FE999_HELPER_BYTES
        patched = bool(base_state.get("patched") and sindy_ok and ai_ok and state_restore_ok and action_helper_ok and phase2_helper_ok and pl_data4_ref_ok and fire_breath_ok and fe_ok)
        return {
            "supported": patched,
            "patched": patched,
            "v0_14_base": bool(base_state.get("patched")),
            "tail_expanded_by_scene_text": bool(base_state.get("tail_expanded")),
            "sindy": vals,
            "sindy_template_ok": sindy_ok,
            "sindy_base_attack_before_equipment": SINDY_BASE_ATTACK,
            "sindy_weapon_attack_bonus": SINDY_WEAPON_ATTACK,
            "sindy_attack_target": SINDY_ATTACK,
            "sindy_weapon_item_id": SINDY_WEAPON,
            "sindy_weapon_name": SINDY_WEAPON_NAME,
            "sindy_auto_control_exact_pl_data4_gate": ai_ok,
            "sindy_auto_flag_restored_to_03_after_dispatch": state_restore_ok,
            "sindy_runtime_stats_reasserted_each_ai_turn": action_helper_ok,
            "sindy_action_state_normalized_to_03": action_helper_ok,
            "sindy_phase1_phase2_shared_pl_data4": phase2_helper_ok,
            "sindy_phase2_template_reset": phase2_helper_ok,
            "sindy_phase2_helper_offset": phase2_helper_off,
            "sindy_phase2_helper_length": SINDY_PHASE2_HELPER_LEN if phase2_helper_off is not None else 0,
            "pl_data4_relocation_preserved": pl_data4_ref_ok,
            "sindy_fire_breath_enabled": fire_breath_ok,
            "sindy_fire_breath_branch": fire_branch.hex(" "),
            "sindy_fire_breath_magic_id": SINDY_BREATH_MAGIC_ID,
            "sindy_fire_breath_int2": SINDY_INT2,
            "sindy_fire_breath_magic_ratio_percent": SINDY_BREATH_MAGIC_RATIO,
            "sindy_fire_breath_damage_formula": "floor(PLY_INT2 * 30 / 100)",
            "sindy_fire_breath_damage_m500": SINDY_BREATH_DAMAGE,
            "sindy_fire_breath_damage_m501": SINDY_BREATH_DAMAGE,
            "sindy_appended_runtime_helper_ok": action_helper_ok,
            "sindy_runtime_helper_offset": runtime_helper_off,
            "sindy_runtime_helper_length": SINDY_RUNTIME_HELPER_LEN if runtime_helper_off is not None else 0,
            "sindy_in_code_helpers_ok": action_helper_ok,  # compatibility key: means helper is safely out-of-line
            "fe999_at_explosion_start": fe_ok,
            "fe999_effect_id": FE999_ID,
            "segment_length": seg["len"],
            "segment_minalloc": seg["alloc"],
            "relocation_count": base_state.get("relocation_count"),
            "relocations_ok": base_state.get("relocations_ok"),
            "sha256": sha256(data),
        }
    except Exception as exc:
        return {"supported": False, "patched": False, "error": str(exc), "sha256": sha256(data)}


def patch_c734(before: bytes) -> bytes:
    if inspect_c734(before).get("patched"):
        return before
    # AIO v1.4.62 already contains the v0.14 presentation core plus R17
    # out-of-line scene text.  Preserve that tail/relocation layer directly
    # instead of forcing the older exact-length v0.14 normalizer.
    if _inspect_v014_dynamic(before).get("patched"):
        d = bytearray(before)
    else:
        # Normalize older historical final-battle presentation states to v0.14.
        d = bytearray(v140.patch_c734(before))
    seg, base = _seg3(d)
    old_ai_for_migration = bytes(d[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8])
    if old_ai_for_migration == SINDY_AI_BRANCH_V01815:
        d = _strip_exact_v01815_r17_helper(d)
        seg, base = _seg3(d)

    # Sindy combat template: keep Lv99/HP9999/LUCK, set base ATT so the
    # Dragon Sword (+480) rebuild lands at 1200.  Fire Breath uses magic ID 12
    # (MG_BURAMUNA) and this C_734 path deals floor(INT2 * 30 / 100), so
    # INT2=1667 yields a 500-damage breath in both Godwin battles.
    p = base + SINDY_TEMPLATE
    if d[p] not in (0x83, 0x03) or d[p + 1] != 0x03 or d[p + 3] != 99:
        raise PatchError("C_734 Sindy template signature does not match")
    d[p] = 0x03
    struct.pack_into("<H", d, p + 0x04, SINDY_HP)
    struct.pack_into("<H", d, p + 0x06, SINDY_HP)
    struct.pack_into("<H", d, p + 0x0A, SINDY_INT2)
    struct.pack_into("<H", d, p + 0x10, SINDY_BASE_ATTACK)
    struct.pack_into("<H", d, p + 0x12, SINDY_DEFENSE)
    d[p + 0x16] = SINDY_AGILITY
    d[p + 0x19] = SINDY_WEAPON

    # v0.18.17: use 83h only transiently inside the existing dispatcher call and restore
    # PL_DATA_4 to the normal ally state 03h immediately afterwards.  Automatic
    # action selection is still protected by the exact PL_DATA_4 AI gate.
    old_state_restore = d[base + SINDY_STATE_RESTORE_IMM_OFF]
    if old_state_restore not in (SINDY_STATE_RESTORE_OLD, SINDY_STATE_RESTORE_V01818, SINDY_STATE_RESTORE_NEW):
        raise PatchError(f"C_734 Sindy state restore immediate differs: 0x{old_state_restore:02X}")
    d[base + SINDY_STATE_RESTORE_IMM_OFF] = SINDY_STATE_RESTORE_NEW

    # v0.18.15 used a fixed 0D40h helper and kept state 83h through the
    # common action/message path.  Its helper bytes can remain as unreachable
    # legacy payload: replace only the branch that reaches them, then install
    # the v0.18.19 action helper after the *current* segment payload.  This
    # gives exact v1.4.64 installs a direct, lossless migration path without
    # shrinking the segment or reconstructing Scene Editor-owned tail bytes.
    old_ai = bytes(d[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8])
    if old_ai not in (SINDY_AI_STOCK, SINDY_AI_V018X, SINDY_AI_V0187, SINDY_AI_FIXED, SINDY_AI_BRANCH_V01815):
        raise PatchError(f"C_734 ALGO_06 signature differs: {old_ai.hex(' ')}")
    if not core.reloc_matches(d, seg, SINDY_PL_DATA4_RELOC_SOURCE, 5, 5, 1, SINDY_PL_DATA4_ORDINAL):
        raise PatchError("C_734 PL_DATA_4 relocation at 0A17h differs")

    # 0A97h is on the Sindy-only side of the exact PL_DATA_4 gate.  Keep the
    # original instruction signature as the only supported source, then append
    # the helper after the current segment payload and move the relocation table.
    old_action_hook = bytes(d[base + SINDY_ACTION_HOOK_OFF:base + SINDY_ACTION_HOOK_OFF + 3])
    runtime_helper_off = _helper_target_from_action_hook(old_action_hook)
    if old_action_hook == SINDY_ACTION_HOOK_STOCK:
        d, runtime_helper_off = _append_sindy_runtime_helper(d)
        seg, base = _seg3(d)
        d[base + SINDY_ACTION_HOOK_OFF:base + SINDY_ACTION_HOOK_OFF + 3] = _action_hook_for(runtime_helper_off)
    elif runtime_helper_off is not None and runtime_helper_off + SINDY_RUNTIME_HELPER_LEN <= seg["len"]:
        live = bytes(d[base + runtime_helper_off:base + runtime_helper_off + SINDY_RUNTIME_HELPER_LEN])
        if live not in (_build_sindy_runtime_helper_v01818(runtime_helper_off), _build_sindy_runtime_helper(runtime_helper_off)):
            raise PatchError(f"C_734 Sindy action helper differs at 0x{runtime_helper_off:04X}")
        d[base + runtime_helper_off:base + runtime_helper_off + SINDY_RUNTIME_HELPER_LEN] = _build_sindy_runtime_helper(runtime_helper_off)
    else:
        raise PatchError(f"C_734 Sindy action hook differs: {old_action_hook.hex(' ')}")
    seg, base = _seg3(d)
    d[base + SINDY_AI_OFF:base + SINDY_AI_OFF + 8] = SINDY_AI_FIXED

    # Phase 2 used to jump straight to 0721h and therefore inherited whatever
    # mutable PL_DATA_4 state phase 1 left behind.  Copy the same 36-byte Sindy
    # template again before entering the stock phase-2 path.
    old_phase2_hook = bytes(d[base + SINDY_PHASE2_BRANCH_OFF:base + SINDY_PHASE2_BRANCH_OFF + 7])
    phase2_helper_off = _phase2_helper_target(old_phase2_hook)
    if old_phase2_hook == SINDY_PHASE2_BRANCH_STOCK:
        d, phase2_helper_off = _append_raw_seg3_helper(d, _build_sindy_phase2_helper, SINDY_PHASE2_HELPER_ALIGN)
        seg, base = _seg3(d)
        d[base + SINDY_PHASE2_BRANCH_OFF:base + SINDY_PHASE2_BRANCH_OFF + 7] = _phase2_hook_for(phase2_helper_off)
    elif phase2_helper_off is not None and phase2_helper_off + SINDY_PHASE2_HELPER_LEN <= seg["len"]:
        if bytes(d[base + phase2_helper_off:base + phase2_helper_off + SINDY_PHASE2_HELPER_LEN]) != _build_sindy_phase2_helper(phase2_helper_off):
            raise PatchError("C_734 phase-2 reset helper differs")
    else:
        raise PatchError(f"C_734 phase-2 branch differs: {old_phase2_hook.hex(' ')}")

    # Restore Sindy's stock fire-breath branch.  v0.16.0 replaced EB 37 with
    # NOP NOP by mistake.  Accept both states for migration, then force EB 37.
    old_fire_branch = bytes(d[base + SINDY_FIRE_BREATH_BRANCH_OFF:base + SINDY_FIRE_BREATH_BRANCH_OFF + 2])
    if old_fire_branch not in (SINDY_FIRE_BREATH_BRANCH, SINDY_V0160_WRONG_NOP):
        raise PatchError(f"C_734 Sindy fire-breath branch differs: {old_fire_branch.hex(' ')}")
    d[base + SINDY_FIRE_BREATH_BRANCH_OFF:base + SINDY_FIRE_BREATH_BRANCH_OFF + 2] = SINDY_FIRE_BREATH_BRANCH

    # Play FE999 exactly once immediately before the existing Godwin explosion
    # visual loop.  v0.14 left CBE..CC8 as verified free/NOP space.
    existing_helper = bytes(d[base + FE999_HELPER:base + FE999_HELPER_END])
    if existing_helper not in (b"\x90" * 11, FE999_HELPER_BYTES):
        raise PatchError(f"C_734 FE999 helper slot is not free: {existing_helper.hex(' ')}")
    d[base + FE999_HELPER:base + FE999_HELPER_END] = FE999_HELPER_BYTES
    d[base + ALGO09_WRAPPER:base + ALGO09_WRAPPER + 5] = ALGO09_WRAPPER_NEW

    out = bytes(d)
    st = inspect_c734(out)
    if not st.get("patched"):
        raise PatchError(f"C_734 v0.18.19 branch verification failed: {st}")
    return out


def _scene_interop_paths() -> tuple[Path, Path] | None:
    """Locate the consolidated dialogue owner's scene editor and data directory."""
    bundle = Path(__file__).resolve().parent.parent
    packs = sorted(
        [p for pattern in ("ED2_Text_and_Dialogue_v*_Combined", "ED2_Text_and_Dialogue_Revision_Pack_v*")
         for p in bundle.glob(pattern) if p.is_dir()],
        key=lambda p: p.name, reverse=True,
    )
    for text_pack in packs:
        scene_dir = text_pack / "scene_editor"
        data_dir = text_pack / "data"
        if (scene_dir / "ed2_scene_editor.py").is_file() and (data_dir / "c734_dialogue.csv").is_file():
            return scene_dir, data_dir
    return None

def _reapply_c734_scene_text(root: Path, scene_dir: Path, csv_dir: Path) -> int:
    """Reapply only C_734 v4 text after the final-battle core is normalized."""
    # Use a unique module name/search path so the final-battle compatibility
    # cores cannot shadow the Scene Editor's helper modules.
    old_path = list(sys.path)
    try:
        sys.path.insert(0, str(scene_dir))
        from ed2_scene_editor import SceneProject
        # The consolidated dialogue pack stores only the verified C_734 rows
        # needed after final-battle canonicalization.
        candidates = [csv_dir / "c734_dialogue.csv"]
        errors = []
        for source in candidates:
            if not source.is_file():
                continue
            import csv
            with source.open("r", newline="", encoding="utf-8-sig") as fp:
                rd = csv.DictReader(fp)
                fields = rd.fieldnames
                rows = [row for row in rd if row.get("dll") == "C_734.DLL"]
            if not rows or not fields:
                continue
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding="utf-8-sig", newline="") as tf:
                    wr = csv.DictWriter(tf, fieldnames=fields)
                    wr.writeheader(); wr.writerows(rows)
                    tmp_path = Path(tf.name)
                project = SceneProject(root)
                return project.import_strings_csv(tmp_path, dialogues_only=False)
            except Exception as exc:
                errors.append(f"{source.name}: {exc}")
            finally:
                if tmp_path is not None:
                    tmp_path.unlink(missing_ok=True)
        raise PatchError("C_734 v4 text reapply failed: " + " | ".join(errors))
    finally:
        sys.path[:] = old_path


def _reapply_current_r17_throne_layout(root: Path, csv_dir: Path) -> int:
    """Reapply the current R17 throne-room presentation layer after Scene Editor import.

    c734_dialogue.csv owns logical text, while v1456_c734_throne_layout.py owns
    five verified meaning-unit 01h line breaks.  Scene Editor import currently
    reconstructs those five sites as ordinary spaces, so Final Battle must
    restore the presentation owner before returning the file to AIO.
    """
    tool = csv_dir.parent / "v1456_c734_throne_layout.py"
    if not tool.is_file():
        raise PatchError(f"C_734 R17 throne layout tool missing: {tool}")
    import importlib.util
    name = f"ed2_c734_throne_layout_{id(root)}"
    spec = importlib.util.spec_from_file_location(name, tool)
    if spec is None or spec.loader is None:
        raise PatchError(f"C_734 R17 throne layout import failed: {tool}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    report = mod.apply(root / "SCENA" / "C_734.DLL", None)
    if not report.get("ok"):
        raise PatchError("C_734 R17 throne layout verification failed")
    return int(report.get("changed_breaks", 0))


# Known C_734 presentation bytes (legacy and v1.4.46 semantic reflow sites).  These are owned by the
# dialogue-linebreak layer, not by Scene Editor itself.  During AIO's
# pre-dialogue final-battle normalization they must be temporarily restored
# to spaces so selective_restore() does not mistake our own stacked change
# for an unknown third-party edit.
_C734_LINEBREAK_FILE_OFFSETS = (0x37BE, 0x37C3, 0x37E7, 0x37EF, 0x3813, 0x3878, 0x387D, 0x3886, 0x38BE, 0x38C7, 0x3902, 0x390E)

def _normalize_c734_linebreak_for_pre_dialogue(path: Path) -> list[int]:
    data = bytearray(path.read_bytes())
    changed = []
    for off in _C734_LINEBREAK_FILE_OFFSETS:
        if off < len(data) and data[off] == 0x01:
            data[off] = 0x20
            changed.append(off)
    if changed:
        atomic_write(path, bytes(data), None)
    return changed

def _patch_c734_with_scene_interop(root: Path, make_backup: bool, pre_dialogue: bool = False) -> tuple[bytes, bytes, bool]:
    cp = root / "SCENA" / "C_734.DLL"
    original = cp.read_bytes()
    if inspect_c734(original).get("patched"):
        return original, original, False
    try:
        patched = patch_c734(original)
        return original, patched, False
    except Exception as first_exc:
        paths = _scene_interop_paths()
        journal = Path(str(cp) + ".ed2_scene_editor.journal.json")
        if paths is None:
            raise first_exc
        scene_dir, csv_dir = paths
        # Preserve the user's pre-v0.18 file as the standalone backup.
        if make_backup:
            bak = Path(str(cp) + ".final_battle_presentation.bak")
            if not bak.exists():
                shutil.copy2(cp, bak)

        # Preferred legacy interop: restore the Scene Editor-owned layer.
        restored = None
        if journal.is_file():
            if pre_dialogue:
                _normalize_c734_linebreak_for_pre_dialogue(cp)
            old_path = list(sys.path)
            try:
                sys.path.insert(0, str(scene_dir))
                from ed2_patch_journal import selective_restore
                selective_restore(cp, "ed2_scene_editor")
                restored = cp.read_bytes()
            finally:
                sys.path[:] = old_path

        # v1.4.56 source-only interop: Text & Dialogue no longer ships a
        # complete C_734.DLL or final_scena.  If the live file is the exact
        # R15 delta target, apply the tiny verified reverse delta to recover
        # stock C_734 in memory, patch the battle core, then reinsert only the
        # current logical R15 dialogue through Scene Editor below.
        if restored is None:
            rev = csv_dir / "c734_r15_to_stock.ed2delta"
            codec_dir = csv_dir.parent / "internal"
            if not rev.is_file() or not (codec_dir / "ed2_delta.py").is_file():
                raise first_exc
            old_path = list(sys.path)
            try:
                sys.path.insert(0, str(codec_dir))
                from ed2_delta import apply_named
                restored = apply_named(original, rev, "C_734.DLL")
            except Exception as delta_exc:
                raise PatchError(f"C_734 R15 reverse-delta interop failed: {delta_exc}") from first_exc
            finally:
                sys.path[:] = old_path

        core_patched = patch_c734(restored)
        atomic_write(cp, core_patched, None)
        if pre_dialogue:
            # Do not reinsert an old dialogue generation here.  The AIO calls
            # this mode only immediately before its current dialogue pass.
            st = inspect_c734(core_patched)
            if not st.get("patched"):
                raise PatchError(f"C_734 pre-dialogue normalization verification failed: {st}")
            return original, core_patched, True
        _reapply_c734_scene_text(root, scene_dir, csv_dir)
        _reapply_current_r17_throne_layout(root, csv_dir)
        final = cp.read_bytes()
        st = inspect_c734(final)
        if not st.get("patched"):
            raise PatchError(f"C_734 v4 interop verification failed: {st}")
        return original, final, True


def validate_root(root: Path) -> Path:
    return v140.validate_root(Path(root))


def repair_ed2main(root: Path, make_backup: bool = True):
    return v140.repair_ed2main(Path(root), make_backup)


def inspect_patch(root: Path) -> dict[str, object]:
    root = validate_root(root)
    e = core.inspect_ed2main_bytes((root / "ED2MAIN.EXE").read_bytes())
    m = inspect_m501((root / "MON" / "M_501.DLL").read_bytes())
    c = inspect_c734((root / "SCENA" / "C_734.DLL").read_bytes())
    return {
        "tool_version": VERSION,
        "ed2main": e,
        "m501": m,
        "c734": c,
        "ok": bool(e.get("stable") and m.get("patched") and c.get("patched")),
    }


def apply_patch(root: Path, make_backup: bool = True, pre_dialogue: bool = False) -> dict[str, object]:
    root = validate_root(root)
    er = repair_ed2main(root, make_backup)

    mp = root / "MON" / "M_501.DLL"
    mb = mp.read_bytes()
    ma = patch_m501(mb)
    if ma != mb:
        atomic_write(mp, ma, ".final_battle_presentation.bak" if make_backup else None)

    cp = root / "SCENA" / "C_734.DLL"
    # v1.4.56: no prebuilt whole-DLL target. Patch the live C_734 and
    # reapply only verified logical R15 dialogue through Scene Editor.
    cb, ca, scene_rebased = _patch_c734_with_scene_interop(root, make_backup, pre_dialogue=pre_dialogue)
    if ca != cb and not scene_rebased:
        atomic_write(cp, ca, ".final_battle_presentation.bak" if make_backup else None)

    st = inspect_patch(root)
    if not st["ok"]:
        raise PatchError("final verification failed")
    return {
        "ed2main_repair": er,
        "m501_changed": ma != mb,
        "c734_changed": ca != cb,
        "c734_scene_text_rebased": scene_rebased,
        "state": st,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    ap.add_argument("root", type=Path)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--apply", action="store_true")
    g.add_argument("--check", action="store_true")
    g.add_argument("--repair-ed2main-only", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--pre-dialogue", action="store_true", help="AIO-only: normalize C_734 core before the current dialogue pass")
    args = ap.parse_args()
    try:
        if args.repair_ed2main_only:
            result = repair_ed2main(args.root, not args.no_backup)
        elif args.check:
            result = inspect_patch(args.root)
        else:
            result = apply_patch(args.root, not args.no_backup, pre_dialogue=args.pre_dialogue)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print("ERROR:", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
