#!/usr/bin/env python3
"""Transactional all-in-one installer for the interoperable ED2 patch pack."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

APP_NAME = "ED2 All-In-One Patcher"
VERSION = "1.4.71"
MANIFEST_NAME = "transaction.json"
REPORT_NAME = "ED2_ALL_IN_ONE_REPORT.json"
PATCHED_EXPORT_BASENAME = "ED2_PATCHED_FILES"
STOCK_BACKUP_SUFFIX = "_STOCK_BACKUP"
STOCK_BACKUP_MANIFEST_NAME = "ED2_STOCK_BACKUP_MANIFEST.json"
STOCK_BACKUP_FILES_DIR = "GAME_FILES"
BASELINE_BUNDLE = "baselines.json"
STOCK_BASELINE_MANIFEST = "stock"
TARGET_FINAL_MANIFEST = "current"
PREVIOUS_TARGET_MANIFESTS = (("previous:1.4.70", "1.4.70"), ("previous:1.4.69", "1.4.69"), ("previous:1.4.68", "1.4.68"), ("previous:1.4.67", "1.4.67"), ("previous:1.4.66", "1.4.66"), ("previous:1.4.65", "1.4.65"), ("previous:1.4.64", "1.4.64"), ("previous:1.4.63", "1.4.63"), ("previous:1.4.62", "1.4.62"), ("previous:1.4.61", "1.4.61"), ("previous:1.4.60", "1.4.60"), ("previous:1.4.59", "1.4.59"))

# Files outside patch ownership must not decide patch generation. SAVE is already
# absent from manifests; ED2.CNF may legitimately change after installation.
# ED2.SWP and transient SWP/TMP/LOG files are completely ignored: they are not
# generation evidence, patch targets, or distributable output.
STATE_IGNORED_PATHS = {"ED2.CNF"}
TRANSIENT_IGNORED_NAMES = {"ED2.SWP"}
TRANSIENT_IGNORED_SUFFIXES = {".SWP", ".TMP", ".LOG"}

def _is_state_ignored_path(rel: str) -> bool:
    """Return True for files that never participate in patch-generation state."""
    rel_norm = str(rel).replace("\\", "/")
    name = Path(rel_norm).name.upper()
    suffix = Path(rel_norm).suffix.upper()
    return (
        rel_norm in STATE_IGNORED_PATHS
        or name in TRANSIENT_IGNORED_NAMES
        or suffix in TRANSIENT_IGNORED_SUFFIXES
    )

class PatchError(RuntimeError):
    pass


def sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()




def _make_writable(path: Path) -> int | None:
    """Clear only filesystem write-protection long enough for a patch-owned overwrite."""
    if not path.exists():
        return None
    mode = path.stat().st_mode
    try:
        path.chmod(mode | stat.S_IWRITE)
    except OSError:
        pass
    return mode


def _force_unlink(path: Path) -> None:
    if not path.exists():
        return
    _make_writable(path)
    path.unlink(missing_ok=True)


def _copy2_overwrite(source: Path, target: Path) -> None:
    """shutil.copy2 that can overwrite a Windows/DOS read-only target."""
    if target.exists():
        _make_writable(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _replace_overwrite(source: Path, target: Path) -> None:
    """os.replace that first clears a read-only destination when necessary."""
    if target.exists():
        _make_writable(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    os.replace(source, target)


def validate_game_root(root: Path) -> Path:
    root = root.expanduser().resolve()
    required = ["ED2MAIN.EXE", "OPENING.EXE", "ENDING.DLL", "STAFF.DLL"]
    missing = [name for name in required if not (root / name).is_file()]
    for directory in ("SCENA", "MON", "GRP", "MAP"):
        if not (root / directory).is_dir():
            missing.append(directory + "/")
    if missing:
        raise PatchError("영웅전설 II 게임 폴더가 아닙니다. 누락: " + ", ".join(missing))
    return root


def bundle_root() -> Path:
    """Return the component bundle root in full-pack or self-contained AIO layout."""
    here = Path(__file__).resolve().parent
    # Full Interop Pack: this script lives in ED2_All_In_One_Patcher_vX.Y.Z/
    # and the component directories are siblings one level above.
    parent = here.parent
    if (parent / "ED2_BALANCE_USER_CSV").is_dir():
        return parent
    # Self-contained AIO: the script and component directories share one root.
    if (here / "ED2_BALANCE_USER_CSV").is_dir():
        return here
    return parent


def run_command(command: list[str], cwd: Path | None = None, extra_env: dict[str, str] | None = None) -> str:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    # The all-in-one transaction already owns rollback safety. Component-level
    # .bak/backup copies are redundant and can dominate I/O on large installs.
    env["ED2_AIO_NO_COMPONENT_BACKUP"] = "1"
    env["ED2_AIO_NO_COMPONENT_JOURNAL"] = "1"
    if extra_env:
        env.update(extra_env)
    result = subprocess.run(
        command, cwd=str(cwd) if cwd else None, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace",
    )
    output = result.stdout.rstrip()
    if result.returncode != 0:
        raise PatchError(
            f"구성 요소 실행 실패 (exit {result.returncode})\n"
            f"명령: {' '.join(command)}\n\n{output}"
        )
    return output


@dataclass(frozen=True)
class Component:
    key: str
    label: str
    default: bool
    apply: Callable[[Path], str]


def apply_text(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "text_patch" / "patch_ed2_text.py"
    base = run_command([sys.executable, str(tool), str(stage)], extra_env={"ED2_TEXT_SKIP_SCENA": "1"})
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    magic_csv = bundle_root() / "ED2_MAGIC_SETTINGS" / "ED2_MAGIC_NAMES.csv"
    code = r"""
from pathlib import Path
import csv, json, sys
sys.path.insert(0, sys.argv[1])
from ed2_mod_studio import load_magics, patch_magic
exe = Path(sys.argv[2]) / "ED2MAIN.EXE"
with Path(sys.argv[3]).open("r", newline="", encoding="utf-8-sig") as fp:
    rows = list(csv.DictReader(fp))
for row in rows:
    magic_id = int(str(row["magic_id"]).strip(), 0)
    patch_magic(exe, magic_id, {"name": str(row["name"]).strip()}, False)
current = {m.magic_id: m.name for m in load_magics(exe)}
bad = [r for r in rows if current.get(int(r["magic_id"], 0)) != str(r["name"]).strip()]
print(json.dumps({"magic_name_rows": len(rows), "mismatches": bad}, ensure_ascii=False))
raise SystemExit(0 if not bad else 1)
"""
    names = run_command([sys.executable, "-c", code, str(mod_dir), str(stage), str(magic_csv)])
    common = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "text_patch" / "v1454_common_battle_messages.py"
    common_out = run_command([sys.executable, str(common), str(stage / "ED2MAIN.EXE")])
    return base + "\n" + names + "\n" + common_out



def apply_dialogue(stage: Path, with_chapter: bool = False) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "apply_combined.py"
    cmd = [sys.executable, str(tool), str(stage), "--scena-only", "--no-backup", "--defer-r19"]
    if with_chapter: cmd.append("--with-chapter")
    return run_command(cmd)


def apply_dialogue_v1460_layout(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1460_dialogue_layout_fix.py"
    return run_command([sys.executable, str(tool), str(stage)])

def verify_dialogue_v1460_layout(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1460_dialogue_layout_fix.py"
    return run_command([sys.executable, str(tool), str(stage), "--check"])

def apply_dialogue_v1461_cleanup(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1461_dialogue_cleanup.py"
    return run_command([sys.executable, str(tool), str(stage)])

def verify_dialogue_v1461_cleanup(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1461_dialogue_cleanup.py"
    return run_command([sys.executable, str(tool), str(stage), "--check"])

def apply_dialogue_v1462_update(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1462_dialogue_update.py"
    return run_command([sys.executable, str(tool), str(stage)])

def verify_dialogue_v1462_update(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1462_dialogue_update.py"
    return run_command([sys.executable, str(tool), str(stage), "--check"])

def apply_dialogue_v1471_audit(stage: Path) -> str:
    """Reassert R18 layout owners, then apply the R19 v1.4.71 delta."""
    base = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined"
    line = run_command([sys.executable, str(base / "v1470_dialogue_linebreak_audit.py"), str(stage)])
    title = run_command([sys.executable, str(base / "v1470_dynamic_title_spacing_fix.py"), str(stage)])
    r19 = run_command([sys.executable, str(base / "v1471_common_particle_title_spacing_fix.py"), str(stage)])
    return line + "\n" + title + "\n" + r19

def verify_dialogue_v1471_audit(stage: Path) -> str:
    base = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined"
    line = run_command([sys.executable, str(base / "v1470_dialogue_linebreak_audit.py"), str(stage), "--check"])
    title = run_command([sys.executable, str(base / "v1470_dynamic_title_spacing_fix.py"), str(stage), "--check"])
    r19 = run_command([sys.executable, str(base / "v1471_common_particle_title_spacing_fix.py"), str(stage), "--check"])
    return line + "\n" + title + "\n" + r19


def apply_v1471_migration_delta(stage: Path) -> str:
    """Apply the v1.4.71 text delta and regenerate the Direct Ending mirror."""
    dialogue = apply_dialogue_v1471_audit(stage)
    ending = apply_direct_ending(stage)
    return dialogue + "\n" + ending

def apply_dialogue_throne_room_layout(stage: Path) -> str:
    """Restore the five R17 throne-room presentation line breaks.

    v1.4.64's final-battle C_734 state can contain the same logical dialogue
    with those five bytes normalized back to ordinary spaces.  That state is
    a supported previous baseline, not an unknown binary.  Re-apply only the
    verified 01h presentation bytes before Final Battle becomes the last
    C_734 writer.  No text payload or relocation data is rewritten here.
    """
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1456_c734_throne_layout.py"
    return run_command([sys.executable, str(tool), str(stage)])

def verify_dialogue_throne_room_layout(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "v1456_c734_throne_layout.py"
    return run_command([sys.executable, str(tool), str(stage), "--check"])

def apply_dialogue_legacy_upgrade(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "internal" / "r54_compat_tools.py"
    return run_command([sys.executable, str(tool), str(stage), "--legacy-upgrade", "--no-backup"])

def apply_dialogue_r53_upgrade(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "internal" / "r54_compat_tools.py"
    return run_command([sys.executable, str(tool), str(stage), "--r53-upgrade", "--no-backup"])

def apply_dialogue_r54_upgrade(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "internal" / "r54_compat_tools.py"
    return run_command([sys.executable, str(tool), str(stage), "--r54-upgrade", "--no-backup"])

def verify_dialogue_runtime(stage: Path) -> str:
    combined = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "apply_combined.py"
    a = run_command([sys.executable, str(combined), str(stage), "--check"])
    compat = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "internal" / "r54_compat_tools.py"
    b = run_command([sys.executable, str(compat), str(stage), "--verify-runtime"])
    return a + "\n" + b

def reapply_current_c734_dialogue_after_final_battle(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "apply_combined.py"
    return run_command([sys.executable, str(tool), str(stage), "--repair-c734"])


def repair_sell_shop_dialogue(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "internal" / "r54_compat_tools.py"
    return run_command([sys.executable, str(tool), str(stage), "--repair-sell-shop"])

def verify_sell_shop_dialogue(stage: Path) -> str:
    tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "internal" / "r54_compat_tools.py"
    return run_command([sys.executable, str(tool), str(stage), "--verify-sell-shop"])


def apply_throne_room_dialogue_reflow(stage: Path) -> str:
    """Compatibility alias: reapply current logical C_734 dialogue, never a whole DLL payload."""
    return reapply_current_c734_dialogue_after_final_battle(stage)

def apply_opening(stage: Path) -> str:
    tool = bundle_root() / "ED2_PC98_Opening_Port_v1.5.1" / "ed2_pc98_opening_port.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply-all"])


def apply_ending(stage: Path) -> str:
    tool = bundle_root() / "ED2_Ending_FIx" / "ed2_combined_patch.py"
    return run_command([sys.executable, str(tool), str(stage)])


def apply_map_preset(stage: Path) -> str:
    tool = bundle_root() / "ED2_Map_Editor_v0.5.7" / "ed2_map_editor.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply-udg-preset"])


def apply_symbol_density(stage: Path) -> str:
    tool = bundle_root() / "ED2_Symbol_Encounter_Density_v0.1.0" / "ed2_symbol_encounter_density.py"
    return run_command([sys.executable, str(tool), str(stage), "--no-backup", "--json"])


def apply_item_magic_support(stage: Path) -> str:
    tool = bundle_root() / "ED2-MOD-Studio-v0.13.1" / "ed2_mod_studio.py"
    return run_command([sys.executable, str(tool), str(stage), "--item-magic-support", "install", "--no-gui"])


def apply_initial_equipment_preset(stage: Path, preset_no: int) -> str:
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    csv_path = mod_dir / "presets" / f"ED2_PLAYER_INITIAL_EQUIPMENT_{preset_no}.csv"
    code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import Project
p=Project(Path(sys.argv[2])); n=p.import_player_equipment_csv(Path(sys.argv[3])); p.reload()
print(json.dumps({'preset':int(sys.argv[4]),'changed_bytes':n,'players':[{'name':r.name,'weapon':r.weapon_id,'armor':r.armor_id,'shield':r.shield_id,'ring':r.ring_id} for r in p.player_equipment]},ensure_ascii=False))
"""
    return run_command([sys.executable,"-c",code,str(mod_dir),str(stage),str(csv_path),str(preset_no)])


def apply_initial_equipment_default(stage: Path) -> str:
    return apply_initial_equipment_preset(stage,1)


def apply_items(stage: Path) -> str:
    support = apply_item_magic_support(stage)
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    csv_path = bundle_root() / "ED2_ITEM_SETTINGS" / "ED2_ITEMS_BASE.csv"
    event_csv = bundle_root() / "ED2_ITEM_SETTINGS" / "ED2_EVENT_ITEM_NAMES.csv"
    code = r"""
from pathlib import Path
import csv, json, sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import Project, patch_event_item, load_event_items
root=Path(sys.argv[2]); p=Project(root)
n=p.import_items_csv(Path(sys.argv[3]))
with Path(sys.argv[4]).open("r", newline="", encoding="utf-8-sig") as fp:
    event_rows=list(csv.DictReader(fp))
for row in event_rows:
    patch_event_item(root/"ED2MAIN.EXE", int(str(row["item_id"]).strip(),0), str(row["name"]).strip(), False)
p.reload()
current={item.item_id:item.name for item in p.event_items}
bad=[r for r in event_rows if current.get(int(r["item_id"],0)) != str(r["name"]).strip()]
print('item_rows='+str(n)); print(json.dumps({'event_item_rows':len(event_rows),'event_mismatches':bad,'validation':p.validate()},ensure_ascii=False))
raise SystemExit(0 if not bad else 1)
"""
    body = run_command([sys.executable, "-c", code, str(mod_dir), str(stage), str(csv_path), str(event_csv)])
    return support + "\n" + body


def apply_shop_items(stage: Path, ensure_item_magic_support: bool = True) -> str:
    tool = bundle_root() / "ED2_Shop_Item_Expansion_v0.3.1" / "ed2_shop_item_expansion.py"
    body = run_command([sys.executable, str(tool), str(stage), "--apply", "--no-gui"])
    equip = apply_initial_equipment_preset(stage,2)
    if not ensure_item_magic_support:
        return "item_magic_support=reused-from-items\n" + body + "\n" + equip
    support = apply_item_magic_support(stage)
    return support + "\n" + body + "\n" + equip



def apply_bug_fix(stage: Path) -> str:
    tool = bundle_root() / "ED2MAIN_Bug_Fix_v1.0.1" / "ed2main_bug_fix.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply", "--no-gui"])


def apply_magic_recharge_fastest(stage: Path) -> str:
    """Keep stock Orbis recharge while making the other 31 spells fastest in one process."""
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
from ed2_mod_studio import patch_magic_recharge_bulk, load_magics
exe=Path(sys.argv[2])/"ED2MAIN.EXE"
a=patch_magic_recharge_bulk(exe,[*range(0,8),*range(9,32)],0x11,False)
b=patch_magic_recharge_bulk(exe,[8],0x99,False)
rows=load_magics(exe); expected={i:(0x99 if i==8 else 0x11) for i in range(32)}
bad=[m.magic_id for m in rows if m.count_raw!=expected[m.magic_id]]
print(json.dumps({'fast_changed':a,'orbis_changed':b,'mismatches':bad},ensure_ascii=False))
raise SystemExit(0 if not bad else 1)
"""
    return run_command([sys.executable,"-c",code,str(mod_dir),str(stage)])


def apply_stability_qol(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Stability_QoL_Tool_v1.2.4"
    tool = tool_dir / "ed2_stability_qol.py"
    settings = tool_dir / "settings.json"
    return run_command([
        sys.executable, str(tool), str(stage), "--apply",
        "--settings", str(settings), "--no-gui",
    ])


def apply_additional_qol(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Additional_QoL_Tool_v1.0.13"
    tool = tool_dir / "ed2_additional_qol.py"
    settings = tool_dir / "settings.json"
    return run_command([
        sys.executable, str(tool), str(stage), "--apply",
        "--settings", str(settings), "--no-gui",
    ])


def apply_balance(stage: Path) -> str:
    """Apply numeric monster/group balance while preserving the current M_510/M_514 drops."""
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    data_dir = bundle_root() / "ED2_BALANCE_USER_CSV"
    monster_csv = data_dir / "ED2_MONSTERS.csv"
    group_csv = data_dir / "ED2_MONSTER_GROUPS.csv"
    code = r"""
from pathlib import Path
import csv, json, os, sys, tempfile
sys.path.insert(0, sys.argv[1])
from ed2_mod_studio import Project

p = Project(Path(sys.argv[2]))
# M_501's complete display name belongs to the final-battle presentation layer.
current_m501_name = next(
    (r.name for r in p.monsters if r.dll_path.name.upper() == "M_501.DLL" and r.slot == 0),
    None,
)
# Preserve M_510/M_514 through the generic balance import; the dedicated policy step validates them later.
preserved_drops = {
    g.dll_path.name.upper(): (g.drop_item_id, g.drop_chance)
    for g in p.groups if g.dll_path.name.upper() in {"M_510.DLL", "M_514.DLL"}
}
with Path(sys.argv[3]).open("r", newline="", encoding="utf-8-sig") as fp:
    reader = csv.DictReader(fp)
    fields = list(reader.fieldnames or [])
    rows = list(reader)
if current_m501_name is not None:
    for row in rows:
        if str(row.get("dll", "")).upper() == "M_501.DLL" and int(str(row.get("slot", "-1")), 0) == 0:
            row["name"] = current_m501_name
fd, temp_mon_name = tempfile.mkstemp(prefix="ed2_balance_monsters_", suffix=".csv")
os.close(fd)
fd, temp_group_name = tempfile.mkstemp(prefix="ed2_balance_groups_", suffix=".csv")
os.close(fd)
try:
    with open(temp_mon_name, "w", newline="", encoding="utf-8-sig") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    m = p.import_monsters_csv(Path(temp_mon_name))

    with Path(sys.argv[4]).open("r", newline="", encoding="utf-8-sig") as fp:
        group_reader = csv.DictReader(fp)
        group_fields = list(group_reader.fieldnames or [])
        group_rows = list(group_reader)
    for row in group_rows:
        key = str(row.get("dll", "")).upper()
        if key in preserved_drops:
            item_id, chance = preserved_drops[key]
            row["drop_item_id"] = str(item_id)
            row["drop_chance"] = str(chance)
    with open(temp_group_name, "w", newline="", encoding="utf-8-sig") as fp:
        writer = csv.DictWriter(fp, fieldnames=group_fields)
        writer.writeheader(); writer.writerows(group_rows)
    g = p.import_groups_csv(Path(temp_group_name))
finally:
    for name in (temp_mon_name, temp_group_name):
        try: os.unlink(name)
        except FileNotFoundError: pass
print(f"monster_rows={m} group_rows={g} preserved_m501_name={current_m501_name!r} preserved_staff_drops={preserved_drops!r}")
print(json.dumps(p.validate(), ensure_ascii=False))
"""
    csv_output = run_command([
        sys.executable, "-c", code, str(mod_dir), str(stage),
        str(monster_csv), str(group_csv),
    ])
    orbis_tool = data_dir / "patch_orbis_resistance.py"
    orbis_output = run_command([sys.executable, str(orbis_tool), str(stage)])
    # M_504 is an optional restored DLL outside the retail 377-record CSV.
    # Balance owns only its numeric profile and safely skips it when restoration
    # has not been installed. Default AIO order restores M_504 before this step.
    m504_balance_tool = data_dir / "patch_m504_balance.py"
    m504_output = run_command([sys.executable, str(m504_balance_tool), str(stage)])
    return csv_output + "\n" + orbis_output + "\n" + m504_output


def apply_restored_item_drop_policy(stage: Path, restored_items_enabled: bool) -> str:
    """Keep M_510/M_514 on the current Restona-mushroom drop policy."""
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
from ed2_mod_studio import Project, patch_group
root=Path(sys.argv[2])
p=Project(root)
want = {
    "M_510.DLL": (64, 10),
    "M_514.DLL": (64, 15),
}
rows=[]; changed=0
for g in p.groups:
    key=g.dll_path.name.upper()
    if key not in want: continue
    item,chance=want[key]
    before=(g.drop_item_id,g.drop_chance)
    if before != (item,chance):
        patch_group(g,{"drop_item_id":item,"drop_chance":chance},False); changed += 1
    rows.append({"dll":key,"before_item":before[0],"before_chance":before[1],"after_item":item,"after_chance":chance})
p2=Project(root); actual={g.dll_path.name.upper():(g.drop_item_id,g.drop_chance) for g in p2.groups if g.dll_path.name.upper() in want}
ok=all(actual.get(k)==v for k,v in want.items())
print(json.dumps({"mode":"restona_mushroom_policy","changed_groups":changed,"rows":rows,"actual":actual,"ok":ok},ensure_ascii=False))
raise SystemExit(0 if ok else 1)
"""
    return run_command([sys.executable, "-c", code, str(mod_dir), str(stage)])

def apply_monster_text(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Monster_Text_Tool_v0.2.14"
    tool = tool_dir / "ed2_monster_text_tool.py"
    integrated_v15 = tool_dir / "apply_reviewed_v15_integrated.py"
    csv_v11 = tool_dir / "ED2_MONSTER_TEXTS_REVIEWED_v11.csv"
    csv_v12 = tool_dir / "ED2_MONSTER_TEXTS_REVIEWED_v12.csv"
    csv_v13 = tool_dir / "ED2_MONSTER_TEXTS_REVIEWED_v13.csv"
    presentation_tool = bundle_root() / "ED2_Monster_Text_Presentation_Fix_v0.2.8" / "ed2_monster_text_presentation_fix.py"
    reviewed11 = run_command([sys.executable, str(tool), str(stage), "--no-backup", "--apply", str(csv_v11)])
    base = run_command([sys.executable, str(presentation_tool), str(stage), "--base"])
    reviewed12 = run_command([sys.executable, str(tool), str(stage), "--no-backup", "--apply", str(csv_v12)])
    final = run_command([sys.executable, str(presentation_tool), str(stage), "--finalize"])
    reviewed13 = run_command([sys.executable, str(tool), str(stage), "--no-backup", "--apply", str(csv_v13)])
    reviewed15 = run_command([sys.executable, str(integrated_v15), str(stage), "--apply", "--no-backup"])
    return "\n".join((reviewed11, base, reviewed12, final, reviewed13, reviewed15))


def apply_monster_text_v15_delta(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Monster_Text_Tool_v0.2.14"
    integrated_v15 = tool_dir / "apply_reviewed_v15_integrated.py"
    return run_command([sys.executable, str(integrated_v15), str(stage), "--apply", "--no-backup"])


def apply_m504_restoration(stage: Path) -> str:
    tool = bundle_root() / "ED2_M504_Restoration_v1.0.2" / "patch_m504_restoration.py"
    return run_command([sys.executable, str(tool), str(stage)])


def apply_experience(stage: Path) -> str:
    """Apply EXP and Gold rules in one Python process."""
    mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
    code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import (experience_preset_state,gold_reward_preset_state,
    patch_experience_rules,patch_gold_reward_rules,load_experience_rules,load_gold_reward_rules)
exe=Path(sys.argv[2])/"ED2MAIN.EXE"
e=experience_preset_state('full'); g=gold_reward_preset_state('full')
a=patch_experience_rules(exe,e,False); b=patch_gold_reward_rules(exe,g,False)
ve=load_experience_rules(exe); vg=load_gold_reward_rules(exe)
ok=(ve==e and vg==g)
print(json.dumps({'experience_changed':a,'gold_changed':b,'experience':ve.to_dict(),'gold':vg.to_dict(),'ok':ok},ensure_ascii=False))
raise SystemExit(0 if ok else 1)
"""
    return run_command([sys.executable,"-c",code,str(mod_dir),str(stage)])


def apply_level_exp(stage: Path) -> str:
    tool = bundle_root() / "ED2_Level_EXP_Curve_v0.2.1" / "ed2_level_exp_curve.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply", "--no-backup"])


def apply_direct_ending(stage: Path) -> str:
    tool = bundle_root() / "ED2_Direct_Ending_Launcher_v1.0.0" / "ed2_ending_launcher.py"
    return run_command([sys.executable, str(tool), str(stage)])


def apply_chapter_title_refresh(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Chapter_Title_Refresh_v0.3.4"
    tool = tool_dir / "ed2_chapter_title_refresh.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply", "--no-backup"])


def apply_prologue_title(stage: Path) -> str:
    """v1.3.0: the centered prologue-end title is owned by the v4 SCENA CSV."""
    scene_dir = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "scene_editor"
    code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
from ed2_scene_editor import SceneProject
from ed2_ne_slot import message_redirect_matches
from ed2_ne_slot import message_redirect_matches
root=Path(sys.argv[2]); p=SceneProject(root); scene=p.load(p.scene_dir/'V_000.DLL')
text='         영웅들의 전설 II'; enc=text.encode('cp949')
ok=SceneProject._redirect_matches(scene.data,scene.segments,3,0x0002,13,b'',enc)
print(json.dumps({'owner':'SCENA CSV v4.1R2','title':text,'center_left_bytes':9,'redirect_ok':ok},ensure_ascii=False))
raise SystemExit(0 if ok else 1)
"""
    return run_command([sys.executable, "-c", code, str(scene_dir), str(stage)])

def apply_vgm_bgm(stage: Path) -> str:
    """Apply/switch to the bundled VGM music source mode."""
    tool = bundle_root() / "ED2_VGM_BGM_Engine_v0.5.50_Combined" / "patch_music_source_mode.py"
    return run_command([sys.executable, str(tool), "custom", str(stage)])


def apply_vgm_wait_bgm_sync(stage: Path) -> str:
    """Upgrade only the v0.5.50 one-shot WAIT_BGM owner on an existing VGM install."""
    tool = bundle_root() / "ED2_VGM_BGM_Engine_v0.5.50_Combined" / "patch_wait_bgm_sync.py"
    return run_command([sys.executable, str(tool), "apply", str(stage)])


def apply_original_bgm(stage: Path) -> str:
    """Use stock MUS/GKEY while preserving non-track BGM control fixes."""
    tool = bundle_root() / "ED2_VGM_BGM_Engine_v0.5.50_Combined" / "patch_music_source_mode.py"
    cmd = [sys.executable, str(tool), "original", str(stage)]
    stock_files = stock_backup_path(stage) / STOCK_BACKUP_FILES_DIR
    if stock_files.is_dir():
        cmd += ["--stock-files-root", str(stock_files)]
    return run_command(cmd)


def apply_sfx_22050(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_SFX_Patch_22050_v2.2.2"
    tool = tool_dir / "ed2_sfx_patch.py"
    return run_command([sys.executable, str(tool), str(stage), "--mixing-rate", "22050"])


def apply_flute_bgm(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Soldiers_Flute_BGM_Fix_v0.3.7"
    tool = tool_dir / "patch_soldiers_flute_bgm.py"
    return run_command([sys.executable, str(tool), "apply", str(stage)])


def migrate_legacy_gabi_m502_wait(stage: Path) -> str:
    """Generation migration only; MON/M_502 is not Soldier's Flute ownership."""
    tool = bundle_root() / "ED2_MIGRATIONS" / "migrate_m502_v1462_v1463.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply"])


def migrate_c734_v1465_to_v1466(stage: Path) -> str:
    """Exact generation migration from released v1.4.65 C_734 to v1.4.66 canonical R17 layout."""
    tool = bundle_root() / "ED2_MIGRATIONS" / "migrate_c734_v1465_to_v1466.py"
    return run_command([sys.executable, str(tool), str(stage)])

def migrate_c734_v1466_to_v1467(stage: Path) -> str:
    """Exact generation migration from released v1.4.66 C_734 to v1.4.67 v0.18.19 canonical bytes."""
    tool = bundle_root() / "ED2_MIGRATIONS" / "migrate_c734_v1466_to_v1467.py"
    return run_command([sys.executable, str(tool), str(stage)])


def apply_joshua_scroll_map(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Joshua_Scrollable_Underground_Map_v1.3.4"
    tool = tool_dir / "ed2_joshua_scrollable_underground_map.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply", "--no-backup"])


def verify_joshua_scroll_map(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_Joshua_Scrollable_Underground_Map_v1.3.4"
    tool = tool_dir / "ed2_joshua_scrollable_underground_map.py"
    out = run_command([sys.executable, str(tool), str(stage), "--check"])
    data = json.loads(out)
    if data.get("state") != "patched-v1.3.2":
        raise PatchError("Joshua 지하 스크롤 지도 검증 실패")
    return out


def apply_final_battle_presentation(stage: Path, pre_dialogue: bool = False) -> str:
    """AIO ordering phase: run the integrated v0.19.0 presentation stage only."""
    tool_dir = bundle_root() / "ED2_Final_Battle_Fix_v0.19.0"
    tool = tool_dir / "ed2_final_battle_fix.py"
    cmd = [sys.executable, str(tool), str(stage), "--apply", "--presentation-only", "--no-backup"]
    if pre_dialogue:
        cmd.append("--pre-dialogue")
    return run_command(cmd)

def apply_final_battle_runtime(stage: Path) -> str:
    """AIO final-writer phase of the same integrated v0.19.0 component."""
    tool = bundle_root() / "ED2_Final_Battle_Fix_v0.19.0" / "ed2_final_battle_fix.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply", "--runtime-only", "--no-backup"])

def verify_final_battle_runtime(stage: Path) -> str:
    tool = bundle_root() / "ED2_Final_Battle_Fix_v0.19.0" / "ed2_final_battle_fix.py"
    return run_command([sys.executable, str(tool), str(stage), "--check", "--runtime-only", "--no-backup"])

def is_final_battle_runtime(stage: Path) -> bool:
    want={
        "MON/M_500.DLL":"7f90bb4ea10e2b83783e44bbe90d0a60a65bebed215bf5027a00cbbd2e036c04",
        "MON/M_501.DLL":"36bef96a1cc3844d4dcd09385ef1aa3cb3096b60720feee307c696b4a593bb74",
        "MON/M_502.DLL":"96d61bea55e8cb1ade49d7044b2d64e6137a7809215301e246146a824a5950a4",
        "SCENA/C_734.DLL":"1077e6b98cccbe23c529c25d7556995410efbee1a3df91b358d2f21ba633785d",
    }
    try:
        return all((stage/rel).is_file() and sha256_path(stage/rel)==h for rel,h in want.items())
    except OSError:
        return False

def apply_late_skill_scaling(stage: Path) -> str:
    tool = bundle_root() / "ED2_Late_Game_Skill_Scaling_v0.2.0" / "ed2_late_game_skill_scaling.py"
    return run_command([sys.executable, str(tool), str(stage), "--apply"])

def verify_late_skill_scaling(stage: Path) -> str:
    tool = bundle_root() / "ED2_Late_Game_Skill_Scaling_v0.2.0" / "ed2_late_game_skill_scaling.py"
    return run_command([sys.executable, str(tool), str(stage), "--check"])


COMPONENTS = (
    # Dialogue is installed directly from verified stock; current R53 consolidated state is idempotent.
    Component("dialogue", "전체 대사 교정 및 표시 보정", True, lambda stage: apply_dialogue(stage, False)),
    Component("text", "UI·텍스트·전투 표시 수정", True, apply_text),
    Component("opening", "PC-98판 기반 오프닝 연출 보정", True, apply_opening),
    Component("ending", "엔딩·스태프롤·나레이션 보정", True, apply_ending),
    Component("map_preset", "지하동굴 미로 간소화", True, apply_map_preset),
    Component("symbol_density", "일반 심볼 인카운트 밀도 완화", True, apply_symbol_density),
    Component("initial_equipment", "플레이어 초기 장비 기본 설정", True, apply_initial_equipment_default),
    Component("items", "아이템 효과·수치 조정", True, apply_items),
    Component("shops", "1편 아이템 복원", True, apply_shop_items),
    Component("bug_fix", "EXP·Gold 오버플로 및 마법 카운터 버그 수정", True, apply_bug_fix),
    Component("magic_recharge", "오비스 제외 마법 재충전 속도 조정", True, apply_magic_recharge_fastest),
    # M_504 must exist before numeric balance can optionally tune Dadarca/Actos.
    Component("m504_restoration", "M_504 다다르카·악토스 전투 복원", True, apply_m504_restoration),
    Component("balance", "몬스터·전투 편성 밸런스 조정", True, apply_balance),
    Component("monster_text", "몬스터 전투·특수행동 문구 수정", True, apply_monster_text),
    Component("experience", "EXP·Gold 획득 규칙 개선", True, apply_experience),
    Component("level_exp", "레벨별 요구 EXP 곡선 조정", True, apply_level_exp),
    Component("stability_qol", "전투 안정성·일부 연출 오류 수정", True, apply_stability_qol),
    Component("additional_qol", "Shift 고속 이동·메뉴 방향키 반복 개선", True, apply_additional_qol),
    # Audio order is intentional: exactly one BGM source mode owns the shared
    # ED2MAIN/BGM source mappings. SFX only replaces SMP assets/config, while
    # the flute wait fix is compatible with either source mode. Final-battle
    # C_734 presentation patch runs later.
    Component("vgm_bgm", "교체 VGM BGM 사용", True, apply_vgm_bgm),
    Component("original_bgm", "원본 BGM 사용", False, apply_original_bgm),
    Component("sfx_22050", "효과음 22종 갱신", True, apply_sfx_22050),
    Component("flute_bgm", "전사의 피리 음악·연출 수정", True, apply_flute_bgm),
    Component("chapter_refresh", "장 제목 갱신·장 종료 화면 공백 정렬", True, apply_chapter_title_refresh),
    Component("late_skill_scaling", "후반 고정 대미지 기술 공격력 연동", True, apply_late_skill_scaling),
    Component("final_battle_fix", "마지막 보스전 통합 수정 (Final Battle Fix v0.19.0)", True, apply_final_battle_presentation),
    Component("joshua_scroll_map", "요슈아 지하 지도 스크롤·안전 고속 렌더", True, apply_joshua_scroll_map),
    Component("direct_ending", "직접 엔딩 실행 기능 추가", True, apply_direct_ending),
)


def _tracked_live_paths(root: Path) -> set[str]:
    """Return only live game/AIO-owned paths; never recurse into user directories."""
    manifest=_load_json_manifest(STOCK_BASELINE_MANIFEST)
    rels={row['path'] for row in manifest['files']}

    # Current AIO outputs and selective journals live only at the game root or
    # directly in known game data directories.  Do not recursively scan arbitrary
    # directories; user backup/archive folders are therefore never inspected.
    for directory in (root, root/'SCENA', root/'MON', root/'MAP'):
        if not directory.is_dir():
            continue
        for path in directory.iterdir():
            if path.is_file():
                upper=path.name.upper()
                if upper in TRANSIENT_IGNORED_NAMES or path.suffix.upper() in TRANSIENT_IGNORED_SUFFIXES:
                    continue
                rels.add(path.relative_to(root).as_posix())
    return rels


def file_map(root: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for rel in sorted(_tracked_live_paths(root)):
        path=root/rel
        if path.is_file():
            result[rel]=sha256_path(path)
    return result


def _load_json_manifest(name: str) -> dict[str, object]:
    path = Path(__file__).resolve().parent / BASELINE_BUNDLE
    bundle = json.loads(path.read_text(encoding='utf-8'))
    if name == STOCK_BASELINE_MANIFEST:
        return dict(bundle['stock'])
    if name == TARGET_FINAL_MANIFEST:
        return dict(bundle['current'])
    if name.startswith('previous:'):
        version = name.split(':', 1)[1]
        try:
            return dict(bundle['previous'][version])
        except KeyError as exc:
            raise PatchError(f'지원 baseline이 없습니다: {version}') from exc
    raise PatchError(f'알 수 없는 baseline 키입니다: {name}')


def _stock_hashes() -> dict[str, str]:
    m=_load_json_manifest(STOCK_BASELINE_MANIFEST)
    return {str(row['path']):str(row['sha256']) for row in m['files']}


def _manifest_rows(name: str) -> dict[str, dict[str, object]]:
    m = _load_json_manifest(name)
    return {str(row["path"]): dict(row) for row in m["files"]}


def _official_patch_delta() -> tuple[list[str], list[str]]:
    """Return (stock files replaced by the patch, files newly added by the patch)."""
    stock = _manifest_rows(STOCK_BASELINE_MANIFEST)
    target = _manifest_rows(TARGET_FINAL_MANIFEST)
    replaced = sorted(
        rel for rel in stock.keys() & target.keys()
        if str(stock[rel]["sha256"]) != str(target[rel]["sha256"])
    )
    added = sorted(target.keys() - stock.keys())
    return replaced, added


def stock_backup_path(real: Path) -> Path:
    return real.parent / f"{real.name}{STOCK_BACKUP_SUFFIX}"


def _validate_stock_backup(real: Path) -> dict[str, object]:
    backup = stock_backup_path(real)
    manifest_path = backup / STOCK_BACKUP_MANIFEST_NAME
    if not manifest_path.is_file():
        raise PatchError(f"순정 백업을 찾지 못했습니다: {backup}")
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise PatchError(f"순정 백업 manifest를 읽지 못했습니다: {exc}") from exc
    if int(data.get("format", 0)) != 1:
        raise PatchError("지원하지 않는 순정 백업 형식입니다.")
    files = data.get("files")
    if not isinstance(files, list) or not files:
        raise PatchError("순정 백업의 파일 목록이 비어 있습니다.")
    expected_count = len(_manifest_rows(STOCK_BASELINE_MANIFEST))
    if data.get("scope") != "full-stock-manifest" or len(files) != expected_count:
        raise PatchError(f"순정 백업이 완전하지 않습니다: {len(files)}/{expected_count} files")
    bad: list[str] = []
    files_root = backup / STOCK_BACKUP_FILES_DIR
    for row in files:
        rel = str(row.get("path", ""))
        q = files_root / rel
        if not q.is_file():
            bad.append(f"{rel}: missing")
            continue
        if q.stat().st_size != int(row.get("size", -1)):
            bad.append(f"{rel}: size mismatch")
            continue
        if sha256_path(q) != str(row.get("sha256", "")):
            bad.append(f"{rel}: SHA-256 mismatch")
    if bad:
        raise PatchError("순정 백업 검증 실패:\n" + "\n".join(bad[:20]))
    return data


def ensure_permanent_stock_backup(
    real: Path,
    state: dict[str, object],
    progress: Callable[[str], None] = print,
    enabled: bool = True,
) -> dict[str, object]:
    """Create one verified permanent stock backup, only from an exact stock input."""
    backup = stock_backup_path(real)
    if not enabled:
        return {"enabled": False, "created": False, "path": None, "state": "disabled"}
    if backup.exists():
        data = _validate_stock_backup(real)
        progress(f"기존 순정 백업을 확인했습니다: {backup}")
        return {"enabled": True, "created": False, "path": str(backup), "state": "existing", "files": len(data.get("files", []))}
    if state.get("kind") != "stock":
        progress("현재 게임이 순정 상태가 아니므로 새 순정 백업은 만들지 않습니다.")
        return {"enabled": True, "created": False, "path": None, "state": "not-stock"}

    stock = _manifest_rows(STOCK_BASELINE_MANIFEST)
    _, added = _official_patch_delta()
    temp = Path(tempfile.mkdtemp(prefix=f".{real.name}_stock_backup_", dir=str(real.parent)))
    files_root = temp / STOCK_BACKUP_FILES_DIR
    rows: list[dict[str, object]] = []
    try:
        for rel in sorted(stock):
            src = real / rel
            expected = stock[rel]
            if not src.is_file():
                raise PatchError(f"순정 백업 대상 파일이 없습니다: {rel}")
            got = sha256_path(src)
            # ED2.CNF is intentionally excluded from generation detection because
            # users may change runtime settings before patching. Preserve that exact
            # pre-patch file instead of rejecting or normalizing it.
            if not _is_state_ignored_path(rel) and got != str(expected["sha256"]):
                raise PatchError(f"순정 백업 생성 중 원본 검증 실패: {rel}")
            dst = files_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            rows.append({"path": rel, "size": src.stat().st_size, "sha256": got})
        manifest = {
            "format": 1,
            "tool": f"{APP_NAME} v{VERSION}",
            "created_local": time.strftime("%Y-%m-%d %H:%M:%S"),
            "game_folder": real.name,
            "source": "verified-stock",
            "scope": "full-stock-manifest",
            "stock_manifest_file_count": len(stock),
            "files_dir": STOCK_BACKUP_FILES_DIR,
            "files": rows,
            "patch_added_paths_to_remove": added,
        }
        (temp / STOCK_BACKUP_MANIFEST_NAME).write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        (temp / "README_KO.txt").write_text(
            "영웅전설 II 순정 백업\n\n"
            "이 폴더는 최초 패치 전의 순정 게임 파일 전체를 보관합니다.\n"
            "수동 복원 시 GAME_FILES 폴더의 내용을 게임 폴더에 덮어쓰십시오.\n"
            "패치가 새로 추가한 파일은 PATCH_ADDED_FILES.txt 목록을 참고해 삭제하십시오.\n"
            "SAVE 데이터는 이 백업에 포함되지 않으며 순정 복원 기능도 SAVE를 건드리지 않습니다.\n",
            encoding="utf-8-sig",
        )
        (temp / "PATCH_ADDED_FILES.txt").write_text("\n".join(added) + "\n", encoding="utf-8-sig")
        os.replace(temp, backup)
        data = _validate_stock_backup(real)
        progress(f"순정 백업을 만들었습니다: {backup} ({len(rows)}개 원본 파일)")
        return {"enabled": True, "created": True, "path": str(backup), "state": "created", "files": len(data.get("files", []))}
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise


def _patch_metadata_paths(real: Path) -> set[str]:
    rels: set[str] = set()
    exact = {
        REPORT_NAME,
        "ED2END_PATCH.json",
        "ED2_TEXT_PATCH_REPORT.json",
        "ED2_VGM_BGM_ALL_REPORT.json",
        "ED2_FREYA_G_ED1900_NARRATION_V153.json",
        "ED2_FREYA_G_ED1900_NARRATION_V164.json",
        ".ed2_scene_algorithms.json",
    }
    for rel in exact:
        if (real / rel).is_file():
            rels.add(rel)
    for directory in (real, real / "SCENA", real / "MON", real / "MAP"):
        if not directory.is_dir():
            continue
        for q in directory.glob("*.journal.json"):
            rels.add(q.relative_to(real).as_posix())
    return rels


def _snapshot_explicit_paths(real: Path, rels: set[str]) -> tuple[Path, dict[str, str]]:
    tx_root = create_transaction_root(real)
    before_dir = tx_root / "before"
    before: dict[str, str] = {}
    for rel in sorted(rels):
        q = real / rel
        if not q.is_file():
            continue
        before[rel] = sha256_path(q)
        dst = before_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(q, dst)
    return tx_root, before


def restore_stock_backup(real: Path, progress: Callable[[str], None] = print) -> dict[str, object]:
    """Restore patch-owned game files from the permanent verified stock backup."""
    real = real.expanduser().resolve()
    if not real.is_dir():
        raise PatchError(f"게임 폴더를 찾지 못했습니다: {real}")
    data = _validate_stock_backup(real)
    backup = stock_backup_path(real)
    files_root = backup / STOCK_BACKUP_FILES_DIR
    files = list(data["files"])
    _, current_added = _official_patch_delta()
    added = sorted(set(str(x) for x in data.get("patch_added_paths_to_remove", [])) | set(current_added))
    restore_rels = {str(row["path"]) for row in files}
    cleanup = _patch_metadata_paths(real)
    candidates = restore_rels | set(added) | cleanup
    tx_root, before = _snapshot_explicit_paths(real, candidates)
    try:
        progress(f"순정 백업에서 {len(files)}개 파일을 복원합니다.")
        for row in files:
            rel = str(row["path"])
            _copy2_overwrite(files_root / rel, real / rel)
        removed = 0
        for rel in sorted(set(added) | cleanup, reverse=True):
            q = real / rel
            if q.is_file():
                _force_unlink(q)
                removed += 1
        bad: list[str] = []
        for row in files:
            rel = str(row["path"])
            q = real / rel
            if not q.is_file() or q.stat().st_size != int(row["size"]) or sha256_path(q) != str(row["sha256"]):
                bad.append(rel)
        remaining_added = [rel for rel in added if (real / rel).exists()]
        if bad or remaining_added:
            raise PatchError("순정 복원 검증 실패: " + ", ".join((bad + remaining_added)[:20]))
        shutil.rmtree(tx_root, ignore_errors=True)
        progress("순정 파일 복원을 완료했습니다. SAVE 데이터는 변경하지 않았습니다.")
        return {
            "tool": f"{APP_NAME} v{VERSION}",
            "backup": str(backup),
            "restored_files": len(files),
            "removed_patch_files": removed,
            "save_untouched": True,
            "ok": True,
        }
    except Exception as exc:
        try:
            rollback_direct(real, tx_root, before, candidates)
        except Exception as rollback_exc:
            raise PatchError(f"{exc}\n\n순정 복원 작업 롤백도 실패했습니다: {rollback_exc}") from exc
        raise


def _map_selected_paths(root: Path, rels: set[str]) -> dict[str, str]:
    result={}
    for rel in sorted(rels):
        p=root/rel
        if p.is_file(): result[rel]=sha256_path(p)
    return result


def _default_component_keys() -> set[str]:
    return {c.key for c in COMPONENTS if c.default}


def _full_original_component_keys() -> set[str]:
    keys = _default_component_keys()
    keys.discard("vgm_bgm")
    keys.add("original_bgm")
    return keys


def _selected_music_mode(selected: set[str]) -> str:
    if "vgm_bgm" in selected and "original_bgm" in selected:
        raise PatchError("교체 VGM BGM과 원본 BGM은 동시에 선택할 수 없습니다.")
    if "original_bgm" in selected:
        return "original"
    if "vgm_bgm" in selected:
        return "vgm"
    return "unchanged"


def _manifest_row_hash_check_raw(raw: bytes, row: dict[str, object]) -> tuple[bool, str, str | None]:
    actual=hashlib.sha256(raw).hexdigest()
    patches=row.get('normalize_patches') or []
    if not patches:
        return actual==str(row['sha256']),actual,actual
    data=bytearray(raw)
    for spec in patches:
        off_raw=spec['offset']
        off=int(off_raw,0) if isinstance(off_raw,str) else int(off_raw)
        current=bytes.fromhex(str(spec['current_hex']))
        normalized=bytes.fromhex(str(spec['normalized_hex']))
        if len(current)!=len(normalized):
            return False,actual,None
        if bytes(data[off:off+len(current)])!=current:
            return False,actual,None
        data[off:off+len(current)]=normalized
    norm=hashlib.sha256(data).hexdigest()
    expected=str(row.get('normalized_sha256',row['sha256']))
    return norm==expected,actual,norm


def _manifest_row_hash_check(path: Path, row: dict[str, object]) -> tuple[bool, str, str | None]:
    """Verify one manifest row, optionally normalizing explicitly owned byte edits."""
    return _manifest_row_hash_check_raw(path.read_bytes(),row)


def verify_default_final_baseline(root: Path) -> dict[str, object]:
    """Strict final verification, including normalized golden rows when declared."""
    m=_load_json_manifest(TARGET_FINAL_MANIFEST)
    bad=[]; total_bytes=0
    verified_files=0; normalized_files=0
    for row in m['files']:
        rel=str(row['path'])
        if _is_state_ignored_path(rel):
            continue
        p=root/rel; total_bytes+=int(row.get('size',0)); verified_files+=1
        if not p.is_file():
            bad.append(f'{rel}: missing'); continue
        if p.stat().st_size!=int(row['size']):
            bad.append(f'{rel}: size {p.stat().st_size} != {row["size"]}'); continue
        ok,actual,norm=_manifest_row_hash_check(p,row)
        if row.get('normalize_patches'):
            normalized_files+=1
        if not ok:
            expected=str(row.get('normalized_sha256',row['sha256']))
            if norm is None and row.get('normalize_patches'):
                bad.append(f'{rel}: normalization bytes do not match the expected patched value')
            elif row.get('normalize_patches'):
                bad.append(f'{rel}: normalized {str(norm)[:12]} != {expected[:12]} (actual {actual[:12]})')
            else:
                bad.append(f'{rel}: {actual[:12]} != {expected[:12]}')
    if bad:
        raise PatchError('기본 전체 패치 최종 SHA 검증 실패:\n'+'\n'.join(bad[:30]))
    return {'mode':'golden-sha256-with-explicit-normalization' if normalized_files else 'golden-sha256','files_verified':verified_files,'bytes_verified':total_bytes,'normalized_files':normalized_files,'mismatches':0,'ignored_state_files':['ED2.CNF','ED2.SWP','*.SWP','*.TMP','*.LOG'],'ok':True}


def _manifest_state(root: Path, manifest_name: str) -> tuple[bool, list[str], dict[str, str]]:
    m=_load_json_manifest(manifest_name); bad=[]; hashes={}
    for row in m['files']:
        rel=str(row['path'])
        if _is_state_ignored_path(rel):
            continue
        p=root/rel
        if not p.is_file():
            bad.append(f"{rel}: missing"); continue
        expected_size=int(row.get('size',p.stat().st_size))
        if p.stat().st_size!=expected_size:
            bad.append(f"{rel}: size {p.stat().st_size} != {expected_size}"); continue
        ok,actual,norm=_manifest_row_hash_check(p,row); hashes[rel]=actual
        if not ok:
            expected=str(row.get('normalized_sha256',row['sha256']))
            if norm is None and row.get('normalize_patches'):
                bad.append(f"{rel}: normalization bytes do not match the expected patched value")
            elif row.get('normalize_patches'):
                bad.append(f"{rel}: normalized {str(norm)[:12]} != {expected[:12]} (actual {actual[:12]})")
            else:
                bad.append(f"{rel}: {actual[:12]} != {expected[:12]}")
    return not bad,bad,hashes


def detect_supported_game_state(root: Path) -> tuple[dict[str, object], dict[str, str]]:
    """Recognize verified stock, current target, or current-generation user edits.

    Historical patch generations are intentionally unsupported.  A stale report
    from an older AIO generation is rejected even when its game payload happens
    to be byte-identical to the current target.  Exact stock always wins so a
    restored game is not blocked by a leftover report file.
    """
    # Fast path for a current-generation *audio-only* selective install.  Such a
    # tree intentionally differs from the full target in hundreds of untouched
    # stock files, so hashing the full current/previous/stock manifests is both
    # slow and unhelpful.  Trust the report only after re-verifying the actual
    # music profile, and apply_all later restricts this state to source switching.
    rp_fast=root/REPORT_NAME
    if rp_fast.is_file():
        try:
            fast=json.loads(rp_fast.read_text(encoding='utf-8'))
            tool=str(fast.get('tool','')) if isinstance(fast,dict) else ''
            selected=fast.get('selected_components',[]) if isinstance(fast,dict) else []
            mode=str(fast.get('music_mode','')) if isinstance(fast,dict) else ''
            audio_only={'vgm_bgm','original_bgm','flute_bgm','sfx_22050'}
            selected_set=set(selected) if isinstance(selected,list) else set()
            if tool in {f"{APP_NAME} v{VERSION}", f"{APP_NAME} v1.4.44", f"{APP_NAME} v1.4.44R1", f"{APP_NAME} v1.4.44R2"} and selected_set and selected_set <= audio_only:
                if mode == 'vgm' and 'vgm_bgm' in selected_set:
                    verify_vgm_bgm(root)
                elif mode == 'original' and 'original_bgm' in selected_set:
                    verify_original_bgm(root)
                else:
                    raise PatchError('music report/profile mismatch')
                return ({
                    'kind':'music_partial_current', 'version':VERSION,
                    'already_target':False, 'ok':True, 'music_mode':mode,
                    'selected_components':sorted(selected_set),
                }, {})
        except Exception:
            pass
    # Fast path for a current-generation dialogue-only selective install.
    # The consolidated R53 snapshot has exact per-SCENA hashes, so there is no
    # need to hash every full/previous/stock manifest before recognizing the
    # same selective profile on reapply.
    if rp_fast.is_file():
        try:
            fast=json.loads(rp_fast.read_text(encoding='utf-8'))
            tool=str(fast.get('tool','')) if isinstance(fast,dict) else ''
            selected=fast.get('selected_components',[]) if isinstance(fast,dict) else []
            selected_set=set(selected) if isinstance(selected,list) else set()
            compatible={f"{APP_NAME} v{VERSION}", f"{APP_NAME} v1.4.44", f"{APP_NAME} v1.4.44R1", f"{APP_NAME} v1.4.44R2"}
            dialogue_profiles=({'dialogue'}, {'dialogue','chapter_refresh'})
            if tool in compatible and selected_set in dialogue_profiles:
                dialogue_tool=bundle_root()/"ED2_Text_and_Dialogue_v5.0R19_Combined"/"apply_combined.py"
                cmd=[sys.executable,str(dialogue_tool),str(root),'--check']
                if 'chapter_refresh' in selected_set:
                    cmd.append('--with-chapter')
                run_command(cmd)
                return ({
                    'kind':'partial_current', 'version':VERSION, 'already_target':False,
                    'ok':True, 'selected_components':sorted(selected_set),
                    'music_mode':str(fast.get('music_mode','unchanged')),
                }, {})
        except Exception:
            pass

    # An exact current payload is safe regardless of a stale report file.  This
    # is not a historical migration path: no old generation is interpreted or
    # converted; the bytes already match the current target exactly.
    ok,bad,current_hashes=_manifest_state(root,TARGET_FINAL_MANIFEST)
    if ok:
        return ({
            "kind":"target", "version":VERSION, "already_target":True,
            "ok":True, "files_verified":len(current_hashes),
        },current_hashes)

    # Fresh stock is the most common install path and should be tested before
    # walking every historical target manifest.  This also matches the safety
    # policy above: an exact restored game wins even when stale patch metadata
    # is still present.
    stock_ok,stock_bad,stock_hashes=_manifest_state(root,STOCK_BASELINE_MANIFEST)
    if stock_ok:
        return ({
            "kind":"stock", "version":"stock", "already_target":False,
            "ok":True, "files_verified":len(stock_hashes),
        },stock_hashes)

    previous_bad_all=[]
    for previous_manifest, previous_version in PREVIOUS_TARGET_MANIFESTS:
        previous_ok,previous_bad,previous_hashes=_manifest_state(root,previous_manifest)
        if previous_ok:
            return ({
                "kind":"previous_target", "version":previous_version, "already_target":False,
                "ok":True, "files_verified":len(previous_hashes),
            },previous_hashes)
        previous_bad_all.extend(previous_bad)

    rp=root/REPORT_NAME
    report_tool=""
    report_data: dict[str, object] = {}
    if rp.is_file():
        try:
            parsed=json.loads(rp.read_text(encoding="utf-8"))
            if isinstance(parsed,dict):
                report_data=parsed
                report_tool=str(report_data.get("tool",""))
        except Exception:
            report_tool=""
            report_data={}
    # Exact official v1.4.41/R1 payloads are recognized by the previous-target manifest.
    # The relaxed custom-current path is therefore restricted to this generation only.
    compatible_current_reports={f"{APP_NAME} v{VERSION}", f"{APP_NAME} v1.4.44", f"{APP_NAME} v1.4.44R1", f"{APP_NAME} v1.4.44R2"}
    if report_tool.startswith(f"{APP_NAME} v") and report_tool not in compatible_current_reports:
        raise PatchError(
            "이전 패치 버전 상태입니다.\n"
            "순정 복원 후 현재 버전을 적용하십시오."
        )

    # A selective install made by this AIO generation may intentionally be far
    # from the full-target manifest.  Re-verify exactly the components recorded
    # in the report before falling back to similarity heuristics.  This keeps
    # selective installs idempotent without treating arbitrary mixed states as
    # supported.
    if report_tool in compatible_current_reports:
        reported_selected=report_data.get("selected_components", [])
        reported_selected_set=set(reported_selected) if isinstance(reported_selected,list) else set()
        valid_component_keys={c.key for c in COMPONENTS}
        if reported_selected_set and reported_selected_set <= valid_component_keys:
            try:
                verify_final(root, reported_selected_set)
            except Exception:
                pass
            else:
                return ({
                    "kind":"partial_current", "version":VERSION, "already_target":False,
                    "ok":True, "selected_components":sorted(reported_selected_set),
                    "music_mode":str(report_data.get("music_mode", "unchanged")),
                }, {})

        rows=_manifest_rows(TARGET_FINAL_MANIFEST)
        actual:dict[str,str]={}
        matched=considered=missing=0
        for rel,row in rows.items():
            if _is_state_ignored_path(rel):
                continue
            considered+=1
            q=root/rel
            if not q.is_file():
                missing+=1
                continue
            got=sha256_path(q); actual[rel]=got
            if got==str(row["sha256"]): matched+=1
        ratio=(matched/considered) if considered else 0.0
        if ratio>=0.85:
            return ({
                "kind":"custom_current", "version":VERSION, "already_target":False,
                "ok":True, "similarity":round(ratio,6),
                "matched_files":matched, "files_considered":considered,
                "missing_files":missing,
            },actual)

        # A source-only AIO install can be much less than 85% similar to the
        # full target because every non-selected component is intentionally
        # still stock.  Recognize only a *verified* music profile from this
        # exact AIO generation.  apply_all restricts this state to source-only
        # switching, so this never becomes a general relaxed patch path.
        reported_mode=str(report_data.get("music_mode", ""))
        try:
            if reported_mode == "vgm":
                verify_vgm_bgm(root)
            elif reported_mode == "original":
                verify_original_bgm(root)
            else:
                raise PatchError("no verified music profile")
            return ({
                "kind":"music_partial_current", "version":VERSION, "already_target":False,
                "ok":True, "music_mode":reported_mode,
                "similarity":round(ratio,6),
                "matched_files":matched, "files_considered":considered,
                "missing_files":missing,
            },actual)
        except Exception:
            pass

    raise PatchError(
        "지원되지 않는 게임 상태입니다.\n"
        "순정 게임 또는 현재 버전 상태에서 실행하십시오."
    )

def verify_vgm_bgm(stage: Path) -> str:
    tool_dir = bundle_root() / "ED2_VGM_BGM_Engine_v0.5.50_Combined"
    outputs: list[str] = []

    core = run_command([sys.executable, str(tool_dir / "patch_vgm_bgm.py"), "status", str(stage)])
    outputs.append(core)
    if "GKEY v0.5.18 hook: True" not in core:
        raise PatchError("VGM core 검증 실패: GKEY v0.5.18 hook가 활성화되지 않았습니다.")
    if "custom loop OPL-reset guard: True" not in core:
        raise PatchError("VGM core 검증 실패: custom carrier loop OPL-reset guard가 활성화되지 않았습니다.")
    for slot in [*range(2, 28), 29]:
        if f"P{slot:02d}" not in core:
            raise PatchError(f"VGM core 검증 실패: P{slot:02d} carrier가 없습니다.")

    ctl = run_command([sys.executable, str(tool_dir / "patch_ed2main_bgm_control.py"), "status", str(stage)])
    outputs.append(ctl)
    if "ED2MAIN BGM control: v0.5.15-fixed" not in ctl:
        raise PatchError("VGM BGM 제어 검증 실패")

    fade = run_command([sys.executable, str(tool_dir / "patch_fadeout_bgm.py"), "status", str(stage)])
    outputs.append(fade)
    if "- managed hard-stop fade sites here: 5" not in fade or "- protected chapter-transition sites: 5" not in fade or "unsupported" in fade.lower():
        raise PatchError("VGM 이벤트 fade/장 전환 보호 검증 실패")
    for token in (
        "SCENA/V_000.DLL NE3:04B9",
        "SCENA/V_100.DLL NE3:040E",
        "SCENA/V_200.DLL NE3:0779",
        "SCENA/V_300.DLL NE3:04B0",
        "SCENA/V_400.DLL NE3:1384",
    ):
        line = next((x for x in fade.splitlines() if token in x), "")
        if ": original (" not in line:
            raise PatchError("VGM 장 전환 0401 보호 검증 실패: " + token)

    allstop = run_command([sys.executable, str(tool_dir / "patch_all_bgm_hardstop.py"), "status", str(stage)])
    outputs.append(allstop)
    # The direct-ending launcher is deliberately generated from the *final*
    # ED2MAIN after the VGM pass.  When ED2END.EXE exists, the global audit
    # therefore contains the 10 live-game sites plus 5 mirrored ED2END sites.
    # v1.3.14 incorrectly hard-coded the pre-ED2END text "10/10" and
    # rejected the perfectly valid final "15/15" state.  Parse counts
    # semantically instead so both supported layouts are valid.
    managed = re.search(r"^- managed hard-stop sites: (\d+)/(\d+)$", allstop, re.MULTILINE)
    chapter = re.search(r"^- protected chapter-transition sites: (\d+)/(\d+)$", allstop, re.MULTILINE)
    leftovers = re.search(r"^- remaining unapproved direct AX=0401/0402/0403 sites: (\d+)$", allstop, re.MULTILINE)
    if not managed:
        raise PatchError("VGM global hard-stop 검증 결과의 관리 위치 수를 읽지 못했습니다.")
    patched, total = map(int, managed.groups())
    expected_total = 15 if (stage / "ED2END.EXE").is_file() else 10
    if patched != total or total != expected_total:
        raise PatchError(
            f"VGM global hard-stop 검증 실패: {patched}/{total}, 기대 {expected_total}/{expected_total}"
        )
    if not chapter or tuple(map(int, chapter.groups())) != (5, 5):
        got = chapter.group(0) if chapter else "missing"
        raise PatchError("VGM 장 전환 보호 검증 실패: " + got)
    if not leftovers or int(leftovers.group(1)) != 0:
        got = leftovers.group(1) if leftovers else "missing"
        raise PatchError("VGM 미승인 0401/0402/0403 잔존 검증 실패: " + got)

    cannon = run_command([sys.executable, str(tool_dir / "patch_c600_cannon_bgm.py"), "status", str(stage)])
    outputs.append(cannon)
    if "C_600: c600-hard-stop-then-p30-v0523" not in cannon or "ready: True" not in cannon:
        raise PatchError("전용 BGM 검증 실패")

    tracks = run_command([sys.executable, str(tool_dir / "patch_custom_tracks.py"), "status", str(stage)])
    outputs.append(tracks)
    for token in ("P06: bundled", "P26: bundled", "P27: bundled", "P29: bundled", "P30: bundled", "P31: bundled", "ready: True"):
        if token not in tracks:
            raise PatchError("VGM custom track 검증 실패: " + token)

    wait_sync = run_command([sys.executable, str(tool_dir / "patch_wait_bgm_sync.py"), "status", str(stage)])
    outputs.append(wait_sync)
    try:
        wait_state = json.loads(wait_sync)
    except Exception as exc:
        raise PatchError("VGM WAIT_BGM 동기화 상태 JSON을 읽지 못했습니다.") from exc
    if not (
        wait_state.get("version") == "0.5.50"
        and wait_state.get("state") == "patched"
        and int(wait_state.get("carrier_ticks", -1)) == 436
        and int(wait_state.get("flute_logical", -1)) == 18
        and wait_state.get("cave") == "86:0500"
        and wait_state.get("wait_bgm") == "86:38E6"
    ):
        raise PatchError("VGM v0.5.50 WAIT_BGM one-shot 동기화 검증 실패: " + wait_sync)

    exit_status = run_command([sys.executable, str(tool_dir / "patch_exit_bgm.py"), "status", str(stage)])
    outputs.append(exit_status)
    if "ED2MAIN NE86:23D8: patched" not in exit_status:
        raise PatchError("게임 종료 BGM 즉시 정지 검증 실패")

    battle = run_command([sys.executable, str(tool_dir / "patch_battle_end_bgm.py"), "status", str(stage)])
    outputs.append(battle)
    for token in (
        "Battle-end BGM stop: fixed",
        "- NE86 length: B844 (stock B844)",
        "- battle fixed slot 86:0100: installed, near target 86:37FB",
    ):
        if token not in battle:
            raise PatchError("VGM v0.5.48 전투 종료 고정 슬롯 검증 실패: " + token)

    # C_734 may be changed later by the final-battle presentation patch, so
    # verify the persistent ED2MAIN logical->physical BGM mapping directly.
    code = r"""
from pathlib import Path
import importlib.util, sys
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m); return m
tool=Path(sys.argv[1]); root=Path(sys.argv[2]); main=(root/'ED2MAIN.EXE').read_bytes()
throne=load('aio_throne',tool/'patch_throne_room_bgm.py')
assert throne.map_value(main,throne.THRONE_LOGICAL)==throne.THRONE_CUSTOM_PHYSICAL
assert throne.map_value(main,throne.BATTLE_LOGICAL)==throne.BATTLE_PHYSICAL
print('throne_mapping=L15->P31')
print('final_battle_mapping=L16->P27')
"""
    outputs.append(run_command([sys.executable, "-c", code, str(tool_dir), str(stage)]))
    return "\n\n".join(outputs)


def verify_original_bgm(stage: Path) -> str:
    tool = bundle_root() / "ED2_VGM_BGM_Engine_v0.5.50_Combined" / "patch_music_source_mode.py"
    output = run_command([sys.executable, str(tool), "status-original", str(stage)])
    if '"ok": true' not in output.lower():
        raise PatchError("원본 BGM 모드 검증 실패")
    return output


def verify_sfx_22050(stage: Path) -> dict[str, object]:
    cnf = stage / "ED2.CNF"
    data = cnf.read_bytes()
    match = re.search(br"(?im)^\s*MixingRate\s*=\s*(\d+)", data)
    if not match or int(match.group(1)) != 22050:
        raise PatchError("SFX v2.2.2 검증 실패: ED2.CNF MixingRate가 22050이 아닙니다.")
    asset_dir = bundle_root() / "ED2_SFX_Patch_22050_v2.2.2" / "SMP"
    bad: list[str] = []
    checked = 0
    for src in sorted(asset_dir.glob("*.SMP")):
        dst = stage / "BGM" / src.name
        checked += 1
        if not dst.is_file() or sha256_path(dst) != sha256_path(src):
            bad.append(src.name)
    if bad:
        raise PatchError("SFX v2.2.2 검증 실패: " + ", ".join(bad))
    return {"mixing_rate": 22050, "verified_smp": checked}

def verify_flute_bgm(stage: Path) -> str:
    tool = bundle_root() / "ED2_Soldiers_Flute_BGM_Fix_v0.3.7" / "patch_soldiers_flute_bgm.py"
    output = run_command([sys.executable, str(tool), "status", str(stage)])
    required = (
        "- ED2MAIN MG_FUE WAIT_BGM: direct",
        "- NE86 length: B844 (stock B844)",
        "- old flute slot 86:0200: empty",
        "- C_632 Grostos Castle WAIT_BGM: direct-import",
        "- Gabi battle M_502: excluded from Soldier's Flute component",
    )
    missing = [token for token in required if token not in output]
    # NE86:0100 belongs to the optional VGM battle-end wrapper, not to the flute
    # fix itself.  A flute-only install legitimately leaves the reserved slot empty.
    if not any(token in output for token in (
        "- battle reserved slot 86:0100: battle",
        "- battle reserved slot 86:0100: empty",
    )):
        missing.append("- battle reserved slot 86:0100: battle|empty")
    if missing or "unsupported" in output.lower():
        raise PatchError("전사의 피리 v0.3.7 최종 상태 검증 실패: " + ", ".join(missing or ["unsupported state"]))
    return output


def verify_presentation_structure(stage: Path) -> str:
    """Audit the SCENA presentation structures that caused visible v4.1R1 regressions."""
    scene_dir = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "scene_editor"
    code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
from ed2_scene_editor import SceneProject
from ed2_ne_slot import message_redirect_matches

root = Path(sys.argv[2]); p = SceneProject(root)

def cp(text): return text.encode("cp949")
def raw_at(name, seg, off, size):
    scene = p.load(root / "SCENA" / name)
    base = scene.segments[seg - 1].file_offset + off
    return bytes(scene.data[base:base + size]), scene, base

# 1) Early Atlas request.  The first slot itself is 38 bytes.  Earlier v4.1R2
# left the explicit 01h at the *end* of that slot, so the renderer soft-wrapped
# "나가게" first and then hit another hard break, producing a one-glyph line.
# v1.4.70 keeps that hard break on the separator before "밖에" and removes
# the extra break after "나가게".  Because the next 14-byte slot starts with
# "해", the former boundary byte is a literal space (after the transparent FF
# padding) so the visible result is exactly two balanced lines:
#   그러지 말고, 잠깐만이라도
#   밖에 나가게 해 주면 안 돼?
first_text = "그러지 말고, 잠깐만이라도 밖에 나가게"
second_text = "해 주면 안 돼?"
raw1, t000, base1 = raw_at("T_000.DLL", 3, 0x0714, 38)
raw2, _t000b, base2 = raw_at("T_000.DLL", 3, 0x073B, 14)
expected1 = bytearray(cp(first_text) + b"\xFF")
break_rel = 0x072D - 0x0714
if expected1[break_rel] != 0x20:
    raise RuntimeError("Atlas request break anchor is not the expected separator")
expected1[break_rel] = 0x01
expected2 = cp(second_text)
boundary = bytes(t000.data[base1 + 38:base1 + 39])
atlas_timing_ok = (
    raw1 == bytes(expected1)
    and boundary == b"\x20"
    and raw2 == expected2
    and raw1[break_rel + 1] != 0x20
)

# 2) Dynamic protagonist-name insertion: T_140 builds
# '전 파렌 왕국의 ' + <player name> + suffix.  The title suffix must start
# with a literal separator so the default name renders as '아트라스 왕자'.
raw_token, t140, token_base = raw_at("T_140.DLL", 3, 0x0774, 4)
raw_suffix, _t140b, suffix_base = raw_at("T_140.DLL", 3, 0x0778, 11)
dynamic_title_ok = (
    raw_token == bytes.fromhex("FF10240E")
    and message_redirect_matches(bytes(t140.data), 3, 0x0778, 11, cp(" 왕자입니다."), b"")
)

# Global line-break hygiene audit across all parsed dialogue streams.  A real
# line break followed by an ASCII space renders as an unwanted one-cell indent;
# an ASCII space immediately before a break is likewise redundant.  Also reject
# the regression shape of exactly one CP949 glyph between two hard breaks.
leading_space_after_break = []
trailing_space_before_break = []
single_glyph_lines = []
for path in p.paths:
    scene = p.load(path)
    for entry in scene.dialogues:
        raw = entry.raw
        if b"\x01\x20" in raw:
            leading_space_after_break.append({"dll": path.name, "segment": entry.segment, "offset": f"0x{entry.offset:04X}"})
        if b"\x20\x01" in raw:
            trailing_space_before_break.append({"dll": path.name, "segment": entry.segment, "offset": f"0x{entry.offset:04X}"})
        for i in range(max(0, len(raw) - 3)):
            if i + 3 < len(raw) and raw[i] == 0x01 and raw[i + 3] == 0x01 and raw[i + 1] >= 0x81:
                try:
                    ch = raw[i + 1:i + 3].decode("cp949")
                except UnicodeDecodeError:
                    continue
                single_glyph_lines.append({"dll": path.name, "segment": entry.segment, "offset": f"0x{entry.offset:04X}", "glyph": ch})

# Enumerate every FF 10 xx 0E dynamic-name-like command for the audit report.
dynamic_sites = []
for path in p.paths:
    data = path.read_bytes(); i = 0
    while i + 4 <= len(data):
        if data[i] == 0xFF and data[i+1] == 0x10 and data[i+3] == 0x0E:
            after = data[i+4:i+20]
            try: preview = after.decode("cp949", errors="replace")
            except Exception: preview = after.hex()
            dynamic_sites.append({"dll": path.name, "file_offset": f"0x{i:X}", "opcode": data[i:i+4].hex(), "after_preview": preview})
            i += 4
        else:
            i += 1

result = {
    "version": "presentation-audit-v1",
    "atlas_request": {
        "ok": atlas_timing_ok,
        "first_slot_ff_padding": raw1.count(b"\xFF"),
        "break_rel": f"0x{break_rel:02X}",
        "break_byte": f"{raw1[break_rel]:02X}",
        "break_next_is_space": raw1[break_rel + 1] == 0x20,
        "slot_join_separator": boundary.hex(),
        "expected_lines": ["그러지 말고, 잠깐만이라도", "밖에 나가게 해 주면 안 돼?"],
        "first_text": first_text,
        "second_text": second_text,
    },
    "dynamic_name_title": {
        "ok": dynamic_title_ok,
        "token": raw_token.hex(),
        "suffix": raw_suffix.decode("cp949", errors="replace"),
    },
    "dynamic_name_sites": dynamic_sites,
    "linebreak_hygiene": {
        "leading_space_after_break_count": len(leading_space_after_break),
        "trailing_space_before_break_count": len(trailing_space_before_break),
        "single_glyph_hard_line_count": len(single_glyph_lines),
        "leading_space_examples": leading_space_after_break[:10],
        "trailing_space_examples": trailing_space_before_break[:10],
        "single_glyph_examples": single_glyph_lines[:10],
    },
    "scene_validation": p.validate(),
}
linebreak_hygiene_ok = not leading_space_after_break and not trailing_space_before_break and not single_glyph_lines
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if atlas_timing_ok and dynamic_title_ok and linebreak_hygiene_ok and result["scene_validation"].get("ok", False) else 1)
"""
    return run_command([sys.executable, "-c", code, str(scene_dir), str(stage)])


def verify_final(stage: Path, selected: set[str]) -> dict[str, object]:
    result: dict[str, object] = {
        "root": str(stage),
        "ed2main_size": (stage / "ED2MAIN.EXE").stat().st_size,
        "opening_size": (stage / "OPENING.EXE").stat().st_size,
        "checks": {},
    }
    checks: dict[str, object] = result["checks"]  # type: ignore[assignment]
    if "vgm_bgm" in selected:
        checks["vgm_bgm_v0_5_49"] = verify_vgm_bgm(stage)
    if "original_bgm" in selected:
        checks["original_bgm"] = verify_original_bgm(stage)
    if "sfx_22050" in selected:
        checks["sfx_22050_v2_2_2"] = verify_sfx_22050(stage)
    if "flute_bgm" in selected:
        checks["flute_bgm_v0_3_6"] = verify_flute_bgm(stage)
    if "dialogue" in selected:
        # v1.4.56 R15 uses relocated/expanded SCENA layouts.  The legacy
        # Dialogue_Linebreak_Tool CSV and R25/R46 physical-offset probes belong
        # to the pre-R15 coordinate system and can reject a valid R15 rebuild.
        # Verify the live logical scene graph, C_734 canonical dialogue and the
        # protected shop F2/F3 controls through the Combined pack instead.
        combined = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "apply_combined.py"
        checks["dialogue_r15_semantic"] = run_command([sys.executable, str(combined), str(stage), "--check"])
        # The old v1461_dialogue_audit chains the superseded v1.4.60
        # layout validator.  R18 intentionally owns some of those same
        # presentation bytes, so verify the v1.4.61 cleanup sites directly.
        checks["dialogue_v1461_cleanup"] = verify_dialogue_v1461_cleanup(stage)
        checks["dialogue_v1462_rayisia"] = verify_dialogue_v1462_update(stage)
        checks["dialogue_v1471_final_audit"] = verify_dialogue_v1471_audit(stage)
        checks["dialogue_throne_room_r17"] = verify_dialogue_throne_room_layout(stage)
        checks["sell_shop_pointer_tables"] = verify_sell_shop_dialogue(stage)
    if "text" in selected:
        # The full legacy text checker assumes the early stock ED2MAIN NE85
        # physical length. Later QoL/VGM components legitimately expand that
        # segment, so final verification uses position-stable feature audits
        # plus the final target manifest instead of re-running the early-layout
        # checker.
        battle_tool = bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "text_patch" / "v1454_common_battle_messages.py"
        checks["common_battle_messages"] = run_command([sys.executable, str(battle_tool), str(stage / "ED2MAIN.EXE"), "--check"])
        # v1.7.13R45: level-up terminology and native message transition.
        # Keep this separate from the generic text check so the one-byte term
        # no-op and the exact DS:362A opcode-05 transition cannot regress.
        levelup_audit_code = r"""
from pathlib import Path
import json,sys
sys.path.insert(0,sys.argv[1])
import _ed2main_ui_core as ui
raw=(Path(sys.argv[2])/'ED2MAIN.EXE').read_bytes()
r=ui.inspect_levelup_presentation(raw)
ok=(r['term_state']=='joined_trailing_space'
    and r['strength_state']=='final_single_space'
    and r['wisdom_state']=='final_single_space'
    and r['agility_luck_state']=='final_labels'
    and r['agility_label']=='민첩이' and r['luck_label']=='행운이'
    and r['agility_space']==1 and r['luck_space']==1
    and r['luck_string_ds']==0x3622
    and r['transition_state']=='conditional_native_transition'
    and r['native_transition_ds']==0x362A and r['native_transition_hex']=='05 06'
    and r['native_transition_handler']=='86:89C5'
    and r['tail_state']=='conditional_next_level_wait'
    and r['conditional_wait_enabled']
    and not r['duplicate_luck_wait'] and not r['fixed_timer_hold'])
r['ok']=ok
print(json.dumps(r,ensure_ascii=False)); raise SystemExit(0 if ok else 1)
"""
        checks["levelup_native_transition"] = run_command([
            sys.executable, "-c", levelup_audit_code,
            str(bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "text_patch"),
            str(stage),
        ])
        # R33: R27의 문자열/SET_EXP/색상/HP·MP 배치는 그대로 유지하고,
        # 두 번째 DISPLAY_STR 직전 SI만 DS:91CD로 강제 복구한다.
        ed2main_raw = (stage / "ED2MAIN.EXE").read_bytes()
        primary_off = 0x14B0EE
        second_pad_off = 0x14B0F2
        stun_color_off = 0x14B102
        stun_text_off = 0x14B103
        exp_base_tail_off = 0x1505C9
        set_exp_copy_count_off = 0x15E35A
        status_hook_off = 0x15E2DE
        set_exp_hook_off = 0x15E34E
        stun_cave_off = 0x153B00
        second_render_hook_off = 0x15E1AA
        expected_stun_text = "기절".encode("cp949") + b"\x00" + b" " * 6
        expected_status_hook = bytes.fromhex("56 51 50")
        expected_set_exp_hook = bytes.fromhex("F6 45 24 80 74 0D")
        expected_second_render_hook = bytes.fromhex("E9 53 59 90")
        expected_stun_cave = bytes.fromhex("81 C7 E0 06 BE CD 91 E9 A4 A6") + b"\x00" * 18
        stun_state = {
            "version": "R33-R27-second-render-SI-boundary-audit-v1",
            "first_0x80_padding_entry": ed2main_raw[primary_off],
            "second_0x80_padding_entry": ed2main_raw[second_pad_off],
            "stun_color_control": ed2main_raw[stun_color_off],
            "stun_text_hex": ed2main_raw[stun_text_off:stun_text_off + 11].hex(),
            "set_exp_copy_words": ed2main_raw[set_exp_copy_count_off],
            "exp_base_tail_hex": ed2main_raw[exp_base_tail_off:exp_base_tail_off + 4].hex(),
            "status_hook_hex": ed2main_raw[status_hook_off:status_hook_off + 3].hex(),
            "set_exp_hook_hex": ed2main_raw[set_exp_hook_off:set_exp_hook_off + 6].hex(),
            "second_render_hook_hex": ed2main_raw[second_render_hook_off:second_render_hook_off + 4].hex(),
            "stun_cave_hex": ed2main_raw[stun_cave_off:stun_cave_off + 28].hex(),
            "target": "R27 display behavior + second DISPLAY_STR SI=91CD boundary fix",
            "ok": (
                ed2main_raw[primary_off] == 0x80
                and ed2main_raw[second_pad_off] == 0x80
                and ed2main_raw[stun_color_off] == 0x1A
                and ed2main_raw[stun_text_off:stun_text_off + 11] == expected_stun_text
                and ed2main_raw[set_exp_copy_count_off] == 0x07
                and ed2main_raw[exp_base_tail_off:exp_base_tail_off + 4] == b"00\x1F\x00"
                and ed2main_raw[status_hook_off:status_hook_off + 3] == expected_status_hook
                and ed2main_raw[set_exp_hook_off:set_exp_hook_off + 6] == expected_set_exp_hook
                and ed2main_raw[second_render_hook_off:second_render_hook_off + 4] == expected_second_render_hook
                and ed2main_raw[stun_cave_off:stun_cave_off + 28] == expected_stun_cave
            ),
        }
        if not stun_state["ok"]:
            raise PatchError(
                "기절/HP 표시가 R27 + 두 번째 렌더 SI 경계 수정 상태로 수렴하지 않았습니다: "
                + json.dumps(stun_state, ensure_ascii=False)
            )
        checks["stun_hp_r27_second_render_si_fix"] = stun_state
        if "opening" not in selected:
            # Explicit legacy opening-display audit. When Opening Port v1.5.1 is
            # selected, its own parser below owns verification because v1.5.1
            # intentionally repacks these strings into a new narration stream.
            opening_audit_code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
import patch_ed2_text as pt
root=Path(sys.argv[2]); raw=(root/'OPENING.EXE').read_bytes()
rows=[]; bad=[]
for slot in pt.OPENING_SLOTS:
    actual=raw[slot.offset:slot.offset+len(slot.desired)]
    ok=actual==slot.desired
    if not ok: bad.append({'offset':f'0x{slot.offset:06X}','purpose':slot.purpose,'actual_hex':actual.hex(),'expected_hex':slot.desired.hex()})
    if slot.offset < 0x099900:
        lead=0
        while lead < len(slot.desired) and slot.desired[lead] == 0x20: lead += 1
        rows.append({'offset':f'0x{slot.offset:06X}','lead_ascii':lead,'bytes':len(slot.desired),'ok':ok})
seq=raw[0x099102:0x099697]
once=pt.cp('어느__날')
ellipsis=pt.cp('…')
result={
 'version':'R37-opening-naturalization-audit-v1',
 'managed_slots':len(pt.OPENING_SLOTS),
 'narration_slots':len(rows),
 'slot_mismatch_count':len(bad),
 'slot_mismatch_examples':bad[:8],
 'eoneunal_count':seq.count(once),
 'unsupported_ellipsis_count':seq.count(ellipsis),
 'gold_hair_exact':raw[0x0992DA:0x0992DA+len(next(x.desired for x in pt.OPENING_SLOTS if x.offset==0x0992DA))] == next(x.desired for x in pt.OPENING_SLOTS if x.offset==0x0992DA),
 'hidden_then_one_day_exact':raw[0x099493:0x099493+len(next(x.desired for x in pt.OPENING_SLOTS if x.offset==0x099493))] == next(x.desired for x in pt.OPENING_SLOTS if x.offset==0x099493),
 'quake_has_no_duplicate_day': once not in raw[0x0994BE:0x0994EF],
 'rows':rows,
}
ok=(not bad and result['eoneunal_count']==1 and result['unsupported_ellipsis_count']==0 and result['gold_hair_exact'] and result['hidden_then_one_day_exact'] and result['quake_has_no_duplicate_day'])
result['ok']=ok
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if ok else 1)
"""
            checks["opening_display_structure"] = run_command([
                sys.executable, "-c", opening_audit_code,
                str(bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "text_patch"),
                str(stage),
            ])
        # Verify the stock 27-entry region-name table independently from the text
        # patch report.  This catches records whose padding/adjacent bytes were
        # corrupted even when the visible Korean substring can still be found.
        location_table_code = r"""
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
import _ed2main_ui_core as ui
raw=(Path(sys.argv[2])/'ED2MAIN.EXE').read_bytes(); bad=[]; rows=[]
for slot in ui.LOCATION_SLOTS:
    actual=raw[slot.offset:slot.offset+len(slot.desired)]
    ok=actual==slot.desired
    rows.append({'offset':f'0x{slot.offset:06X}','name':slot.desired.decode('cp949',errors='replace').strip(),'ok':ok})
    if not ok: bad.append({'offset':f'0x{slot.offset:06X}','actual_hex':actual.hex(),'expected_hex':slot.desired.hex()})
result={'ok':not bad,'count':len(rows),'mismatch_count':len(bad),'mismatch_examples':bad[:8],'rows':rows}
print(json.dumps(result,ensure_ascii=False)); raise SystemExit(0 if not bad and len(rows)==27 else 1)
"""
        checks["location_table_27"] = run_command([
            sys.executable, "-c", location_table_code,
            str(bundle_root() / "ED2_Text_and_Dialogue_v5.0R19_Combined" / "text_patch"),
            str(stage),
        ])
    if "opening" in selected:
        tool = bundle_root() / "ED2_PC98_Opening_Port_v1.5.1" / "ed2_pc98_opening_port.py"
        opening_raw = run_command([sys.executable, str(tool), str(stage), "--analyze", "--no-gui"])
        try:
            opening_state = json.loads(opening_raw)
        except json.JSONDecodeError as exc:
            raise PatchError("Opening Port v1.5.1 분석 결과를 해석하지 못했습니다.") from exc
        opening_ok = (
            opening_state.get("tool_version") == "1.5.1"
            and opening_state.get("flora_state") == "pc98_smooth_200_preshift32"
            and opening_state.get("g_op1700_matches_verified_asset") is True
            and opening_state.get("people_state") == "enabled"
            and opening_state.get("blood_values") == [0, 0, 0, 0, 0, 0]
            and opening_state.get("intro_narration_hold") == "extended_5s"
            and opening_state.get("preblood_timing") == "extended_5_390625s_text5_gop0403_minus5"
            and opening_state.get("text_gop0403_timing") == "text_plus5_gop0403_minus5"
            and opening_state.get("distributed_text_extra_ticks") == 320
            and opening_state.get("g_op0403_reduction_ticks") == 320
            and opening_state.get("intro_narration_renderer") == "centered_punctuation_v151_text_plus5"
            and opening_state.get("intro_narration_centering", {}).get("punctuation_supported") is True
        )
        opening_state["ok"] = opening_ok
        if not opening_ok:
            raise PatchError("PC-98 오프닝 v1.5.1 최종 상태가 예상과 다릅니다: " + json.dumps(opening_state, ensure_ascii=False))
        checks["opening"] = opening_state
    if "ending" in selected:
        tool = bundle_root() / "ED2_Ending_FIx" / "ed2_combined_patch.py"
        checks["ending"] = run_command([sys.executable, str(tool), str(stage)])
    if "map_preset" in selected:
        tool = bundle_root() / "ED2_Map_Editor_v0.5.7" / "ed2_map_editor.py"
        checks["map_preset"] = run_command([sys.executable, str(tool), str(stage), "--check-udg-preset"])
    if "symbol_density" in selected:
        tool = bundle_root() / "ED2_Symbol_Encounter_Density_v0.1.0" / "ed2_symbol_encounter_density.py"
        checks["symbol_density_v0_1_0"] = run_command([sys.executable, str(tool), str(stage), "--check", "--json"])
    if selected & {"balance", "experience", "items", "shops", "magic_recharge"}:
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        code = (
            "from pathlib import Path; import json,sys; sys.path.insert(0,sys.argv[1]); "
            "from ed2_mod_studio import Project; p=Project(Path(sys.argv[2])); "
            "print(json.dumps(p.validate(),ensure_ascii=False))"
        )
        checks["mod_studio"] = run_command([sys.executable, "-c", code, str(mod_dir), str(stage)])
    if selected & {"balance", "shops"}:
        expected_mode = "restored_items_no_staff_drops"
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        code = r"""
from pathlib import Path
import json,sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import Project
p=Project(Path(sys.argv[2])); mode=sys.argv[3]
want={
 'M_510.DLL':(64,10),
 'M_514.DLL':(64,15),
}
actual={g.dll_path.name.upper():(g.drop_item_id,g.drop_chance) for g in p.groups if g.dll_path.name.upper() in want}
ok=all(actual.get(k)==v for k,v in want.items())
print(json.dumps({'mode':mode,'expected':want,'actual':actual,'ok':ok},ensure_ascii=False))
raise SystemExit(0 if ok else 1)
"""
        checks["restored_item_drop_policy"] = run_command([sys.executable,"-c",code,str(mod_dir),str(stage),expected_mode])
    if "balance" in selected:
        # Kajasum (M_401 slot0) is the only retail monster record whose 16-byte
        # name field contains two significant 06h bytes after the ordinary
        # name terminator. Losing them causes a battle-action text/state glitch.
        code = r"""
from pathlib import Path
import json, sys
path = Path(sys.argv[1]) / "MON" / "M_401.DLL"
data = path.read_bytes()
name = "카자줌".encode("cp949")
off = data.find(name)
expected = name + b"\x06\x06\x06"
ok = off >= 0 and data[off:off + len(expected)] == expected
result = {
    "file": "MON/M_401.DLL",
    "name_offset": None if off < 0 else f"0x{off:04X}",
    "expected_prefix_hex": expected.hex(" "),
    "actual_prefix_hex": "" if off < 0 else data[off:off + len(expected)].hex(" "),
    "kajasm_control_suffix_preserved": ok,
}
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if ok else 1)
"""
        checks["kajasm_record"] = run_command([sys.executable, "-c", code, str(stage)])
        # M_117 display names are owned by ED2_MONSTERS.csv. Guard the four A/B/C/D
        # records explicitly so a stale spelling cannot survive a balance apply.
        sand_mole_code = r"""
from pathlib import Path
import json, sys
p=Path(sys.argv[1])/"MON"/"M_117.DLL"; d=p.read_bytes()
old="모래 두더쥐".encode("cp949"); new="모래 두더지".encode("cp949")
names=[("모래 두더지"+x).encode("cp949") for x in "ABCD"]
result={"old_count":d.count(old),"new_count":d.count(new),"names_ok":all(d.count(x)==1 for x in names)}
result["ok"]=(result["new_count"]>=4 and result["names_ok"])
print(json.dumps(result,ensure_ascii=False)); raise SystemExit(0 if result["ok"] else 1)
"""
        checks["sand_mole_names"] = run_command([sys.executable, "-c", sand_mole_code, str(stage)])
        orbis_tool = bundle_root() / "ED2_BALANCE_USER_CSV" / "patch_orbis_resistance.py"
        checks["orbis_resistance"] = run_command([
            sys.executable, str(orbis_tool), str(stage), "--check",
        ])
        m504_balance_tool = bundle_root() / "ED2_BALANCE_USER_CSV" / "patch_m504_balance.py"
        checks["m504_optional_balance"] = run_command([
            sys.executable, str(m504_balance_tool), str(stage), "--check",
        ])
    if "level_exp" in selected:
        tool = bundle_root() / "ED2_Level_EXP_Curve_v0.2.1" / "ed2_level_exp_curve.py"
        checks["level_exp"] = run_command([sys.executable, str(tool), str(stage), "--check"])
    if "experience" in selected:
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        code = (
            "from pathlib import Path; import json,sys; sys.path.insert(0,sys.argv[1]); "
            "from ed2_mod_studio import Project; p=Project(Path(sys.argv[2])); "
            "e=p.experience_rules; g=p.gold_reward_rules; "
            "ok=e.recognized and g.recognized and e.include_incapacitated and e.no_party_split and e.no_general_90_percent and e.no_level_penalty and g.no_general_90_percent and g.no_level_scaling; "
            "print(json.dumps({'experience':e.to_dict(),'gold':g.to_dict(),'ok':ok},ensure_ascii=False)); "
            "raise SystemExit(0 if ok else 1)"
        )
        checks["experience"] = run_command([sys.executable, "-c", code, str(mod_dir), str(stage)])
    if "monster_text" in selected:
        tool_dir = bundle_root() / "ED2_Monster_Text_Tool_v0.2.14"
        integrated_v15 = tool_dir / "apply_reviewed_v15_integrated.py"
        checks["monster_text"] = run_command([sys.executable, str(integrated_v15), str(stage), "--check"])
        presentation_tool = bundle_root() / "ED2_Monster_Text_Presentation_Fix_v0.2.8" / "ed2_monster_text_presentation_fix.py"
        checks["monster_text_presentation"] = run_command([sys.executable, str(presentation_tool), str(stage), "--check"])
    if "m504_restoration" in selected:
        tool = bundle_root() / "ED2_M504_Restoration_v1.0.2" / "patch_m504_restoration.py"
        checks["m504_restoration"] = run_command([sys.executable, str(tool), str(stage), "--check"])
    if "initial_equipment" in selected or "shops" in selected:
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        preset_no = 2 if "shops" in selected else 1
        preset_csv = mod_dir / "presets" / f"ED2_PLAYER_INITIAL_EQUIPMENT_{preset_no}.csv"
        code = r"""
from pathlib import Path
import csv,json,sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import Project
p=Project(Path(sys.argv[2])); rows=list(csv.DictReader(Path(sys.argv[3]).open('r',newline='',encoding='utf-8-sig')))
cur={r.export_name:r for r in p.player_equipment}; bad=[]
for row in rows:
    x=cur.get(row['export'].strip())
    want={k:int(row[k+'_id'],0) for k in ('weapon','armor','shield','ring')}
    got=None if x is None else {'weapon':x.weapon_id,'armor':x.armor_id,'shield':x.shield_id,'ring':x.ring_id}
    if got!=want: bad.append({'export':row['export'],'actual':got,'expected':want})
print(json.dumps({'preset':int(sys.argv[4]),'rows':len(rows),'mismatches':bad},ensure_ascii=False)); raise SystemExit(0 if len(rows)==4 and not bad else 1)
"""
        checks["player_initial_equipment"] = run_command([sys.executable,"-c",code,str(mod_dir),str(stage),str(preset_csv),str(preset_no)])
    if "items" in selected:
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        csv_path = bundle_root() / "ED2_ITEM_SETTINGS" / "ED2_ITEMS_BASE.csv"
        code = '\nfrom pathlib import Path\nimport csv, json, sys\nsys.path.insert(0, sys.argv[1])\nfrom ed2_mod_studio import Project\n\np = Project(Path(sys.argv[2]))\nwith Path(sys.argv[3]).open("r", newline="", encoding="utf-8-sig") as fp:\n    rows = list(csv.DictReader(fp))\ncurrent = {item.item_id: item for item in p.items}\nerrors = []\nseen = set()\nfor row_num, row in enumerate(rows, start=2):\n    item_id = int(str(row.get("item_id", "")).strip(), 0)\n    if item_id in seen:\n        errors.append({"row": row_num, "error": "duplicate item_id", "item_id": item_id})\n        continue\n    seen.add(item_id)\n    item = current.get(item_id)\n    if item is None:\n        errors.append({"row": row_num, "error": "missing item", "item_id": item_id})\n        continue\n    checks = {\n        "name": (item.name, str(row.get("name", "")).strip()),\n        "price": (item.price, int(str(row.get("price", "0")).strip(), 0)),\n        "stat_group": (item.stat_group, int(str(row.get("stat_group", "0")).strip(), 0)),\n        "effect_id": (item.effect_id, int(str(row.get("effect_id", "0")).strip(), 0)),\n        "power_raw": (item.power_raw, int(str(row.get("power_raw", "0")).strip(), 0)),\n        "secondary_raw": (item.secondary_raw, int(str(row.get("secondary_raw", "0")).strip(), 0)),\n        "magic_mode": (item.magic_mode, str(row.get("magic_mode", "")).strip().lower()),\n        "type_mask_hex": (item.type_mask, int(str(row.get("type_mask_hex", "0")).strip(), 0)),\n    }\n    mismatch = {key: {"actual": actual, "expected": expected} for key, (actual, expected) in checks.items() if actual != expected}\n    if mismatch:\n        errors.append({"row": row_num, "item_id": item_id, "mismatch": mismatch})\nresult = {"csv_rows": len(rows), "matched_items": len(seen) - len(errors), "errors": errors}\nprint(json.dumps(result, ensure_ascii=False))\nraise SystemExit(0 if len(rows) == 71 and len(seen) == 71 and not errors else 1)\n'
        checks["items"] = run_command([sys.executable, "-c", code, str(mod_dir), str(stage), str(csv_path)])
        event_csv = bundle_root() / "ED2_ITEM_SETTINGS" / "ED2_EVENT_ITEM_NAMES.csv"
        event_code = r"""
from pathlib import Path
import csv, json, sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import load_event_items
rows=list(csv.DictReader(Path(sys.argv[3]).open("r",newline="",encoding="utf-8-sig")))
cur={x.item_id:x.name for x in load_event_items(Path(sys.argv[2])/"ED2MAIN.EXE")}
bad=[r for r in rows if cur.get(int(r["item_id"],0)) != r["name"].strip()]
print(json.dumps({'rows':len(rows),'mismatches':bad},ensure_ascii=False)); raise SystemExit(0 if not bad else 1)
"""
        checks["event_item_names"] = run_command([sys.executable, "-c", event_code, str(mod_dir), str(stage), str(event_csv)])
    if "shops" in selected:
        tool = bundle_root() / "ED2_Shop_Item_Expansion_v0.3.1" / "ed2_shop_item_expansion.py"
        checks["shops"] = run_command([sys.executable, str(tool), str(stage), "--check", "--no-gui"])
    if "text" in selected:
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        magic_csv = bundle_root() / "ED2_MAGIC_SETTINGS" / "ED2_MAGIC_NAMES.csv"
        magic_code = r"""
from pathlib import Path
import csv, json, sys
sys.path.insert(0,sys.argv[1])
from ed2_mod_studio import load_magics
rows=list(csv.DictReader(Path(sys.argv[3]).open("r",newline="",encoding="utf-8-sig")))
cur={x.magic_id:x.name for x in load_magics(Path(sys.argv[2])/"ED2MAIN.EXE")}
bad=[r for r in rows if cur.get(int(r["magic_id"],0)) != r["name"].strip()]
print(json.dumps({'rows':len(rows),'mismatches':bad},ensure_ascii=False)); raise SystemExit(0 if not bad else 1)
"""
        checks["magic_names"] = run_command([sys.executable, "-c", magic_code, str(mod_dir), str(stage), str(magic_csv)])
    if "bug_fix" in selected:
        bug_dir = bundle_root() / "ED2MAIN_Bug_Fix_v1.0.1"
        code = (
            "from pathlib import Path; import json,sys; sys.path.insert(0,sys.argv[1]); "
            "from ed2main_bug_fix import inspect_bytes; "
            "r=inspect_bytes((Path(sys.argv[2])/'ED2MAIN.EXE').read_bytes()); "
            "ok=r.get('ok',False) and all(v.get('state')=='patched' for v in r.get('features',{}).values()); "
            "print(json.dumps(r,ensure_ascii=False)); raise SystemExit(0 if ok else 1)"
        )
        checks["bug_fix"] = run_command([sys.executable, "-c", code, str(bug_dir), str(stage)])
    if "magic_recharge" in selected:
        mod_dir = bundle_root() / "ED2-MOD-Studio-v0.13.1"
        code = (
            "from pathlib import Path; import json,sys; sys.path.insert(0,sys.argv[1]); "
            "from ed2_mod_studio import load_magics; "
            "rows=load_magics(Path(sys.argv[2])/'ED2MAIN.EXE'); "
            "expected={i:(0x99 if i==8 else 0x11) for i in range(32)}; "
            "bad=[{'id':m.magic_id,'name':m.name,'actual':m.count_raw,'expected':expected[m.magic_id]} for m in rows if m.count_raw!=expected[m.magic_id]]; "
            "print(json.dumps({'count':len(rows),'orbis_id':8,'orbis_value':'0x99','other_value':'0x11','mismatches':bad},ensure_ascii=False)); "
            "raise SystemExit(0 if len(rows)==32 and not bad else 1)"
        )
        checks["magic_recharge"] = run_command([sys.executable, "-c", code, str(mod_dir), str(stage)])
    if "stability_qol" in selected:
        tool_dir = bundle_root() / "ED2_Stability_QoL_Tool_v1.2.4"
        settings_path = tool_dir / "settings.json"
        code = """
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
from ed2_stability_qol import inspect_patch, load_settings
state = inspect_patch(Path(sys.argv[2]))
expected = load_settings(Path(sys.argv[3]))
checks = {
    "runtime_safety": state.get("runtime_safety") == expected.runtime_safety,
    "inventory_expansion_removed": state.get("inventory_expansion") is False and state.get("inventory_slots") == 28,
    "c631_inventory_scan_restored": state.get("c631_inventory_scan_count") == 20,
    "battle_animation_restored": state.get("battle_animation") == "normal",
    "dialogue_speed": state.get("dialogue_speed") == expected.dialogue_speed,
    "battle_message_speed_not_forced": state.get("battle_message_speed") == 1,
    "dialogue_visible_events": state.get("dialogue_visible_events", {}).get("ok") is True,
}
print(json.dumps({"state": state, "expected": expected.__dict__, "checks": checks}, ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) else 1)
"""
        checks["stability_qol"] = run_command([
            sys.executable, "-c", code, str(tool_dir), str(stage), str(settings_path)
        ])
    if "final_battle_fix" in selected:
        checks["final_battle_fix_v0_19_0"] = verify_final_battle_runtime(stage)
    if "late_skill_scaling" in selected:
        if is_final_battle_runtime(stage):
            checks["late_skill_scaling_v0_2_0"] = {"ok":True,"state":"preserved-by-final-battle-fix-v0.19.0","M_500":489,"M_501":537}
        else:
            checks["late_skill_scaling_v0_2_0"] = verify_late_skill_scaling(stage)
    if "joshua_scroll_map" in selected:
        checks["joshua_scroll_map_v1_3_4"] = verify_joshua_scroll_map(stage)
    if "additional_qol" in selected:
        tool_dir = bundle_root() / "ED2_Additional_QoL_Tool_v1.0.13"
        settings_path = tool_dir / "settings.json"
        code = """
from pathlib import Path
import json, sys
sys.path.insert(0, sys.argv[1])
from ed2_additional_qol import inspect_patch, load_settings
state = inspect_patch(Path(sys.argv[2]))
expected = load_settings(Path(sys.argv[3]))
checks = {
    "shop_quantity_removed": state.get("shop_quantity_removed") is True,
    "equipment_preview_removed": state.get("equipment_preview_removed") is True,
    "turbo_move": state.get("turbo_move") == expected.turbo_move,
    "menu_cursor_wrap_removed": state.get("menu_cursor_wrap") is False and state.get("menu_cursor_wrap_removed") is True,
    "menu_key_repeat_fast": state.get("menu_key_repeat_fast") == expected.menu_key_repeat_fast,
    "menu_repeat_initial_20": state.get("menu_key_repeat_initial_ticks") == 20,
    "menu_repeat_interval_4": state.get("menu_key_repeat_interval_ticks") == (4 if expected.menu_key_repeat_fast else 8),
    "vertical_wrap_removed": state.get("menu_vertical_wrap") is False,
    "horizontal_wrap_removed": state.get("menu_horizontal_wrap") is False,
    "inventory_menu_exception": state.get("inventory_menu_exception") is True,
    "inventory_menu_repeat_same": state.get("inventory_menu_repeat_ticks") == ("20/4" if expected.menu_key_repeat_fast else "20/8"),
    "warp_menu_repeat_same": state.get("warp_menu_repeat_ticks") == ("20/4" if expected.menu_key_repeat_fast else "20/8"),
    "vanilla_dialogue_renderer": state.get("dialogue_instant_complete") is False,
    "custom_dialogue_hook_removed": state.get("dialogue_instant_complete") is False,
    "custom_dialogue_release_guard_removed": state.get("dialogue_confirm_release_guard") is False,
    "helper_installed": state.get("helper_installed") is (
        expected.turbo_move or expected.menu_key_repeat_fast or expected.dialogue_instant_complete
    ),
    "v1_0_8_helper_preserved": state.get("v1_0_8_helper_installed") is True,
}
print(json.dumps({"state": state, "expected": expected.__dict__, "checks": checks}, ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) else 1)
"""
        checks["additional_qol"] = run_command([
            sys.executable, "-c", code, str(tool_dir), str(stage), str(settings_path)
        ])
    if "direct_ending" in selected:
        ending_report_path = stage / "ED2END_PATCH.json"
        ending_report: dict[str, object] = {}
        if ending_report_path.is_file():
            try:
                ending_report = json.loads(ending_report_path.read_text(encoding="utf-8"))
            except Exception:
                ending_report = {}
        final_main_hash = sha256_path(stage / "ED2MAIN.EXE") if (stage / "ED2MAIN.EXE").is_file() else ""
        final_end_hash = sha256_path(stage / "ED2END.EXE") if (stage / "ED2END.EXE").is_file() else ""
        checks["direct_ending"] = {
            "ED2END.EXE": (stage / "ED2END.EXE").is_file(),
            "ENDING.BAT": (stage / "ENDING.BAT").is_file(),
            "ED2END_PATCH.json": ending_report_path.is_file(),
            "source_matches_final_ED2MAIN": ending_report.get("source_sha256") == final_main_hash,
            "output_matches_ED2END": ending_report.get("output_sha256") == final_end_hash,
            "target_THEEND_05_0128": ending_report.get("new_target") == "05:0128",
        }
        if not all(checks["direct_ending"].values()):  # type: ignore[union-attr]
            raise PatchError("직접 엔딩 실행기 검증에 실패했습니다.")
    if "chapter_refresh" in selected:
        tool = bundle_root() / "ED2_Chapter_Title_Refresh_v0.3.4" / "ed2_chapter_title_refresh.py"
        checks["chapter_title_refresh"] = run_command([sys.executable, str(tool), str(stage), "--check"])
    return result


def is_component_backup_artifact(rel: str) -> bool:
    name = Path(rel).name.lower()
    return ".bak" in name or ".before_" in name


def create_transaction_root(real: Path) -> Path:
    tx_root=Path(tempfile.mkdtemp(prefix='ed2_aio_rollback_'))
    (tx_root/'before').mkdir(parents=True, exist_ok=True)
    return tx_root


def candidate_paths(root: Path, selected: set[str]) -> set[str]:
    """Return files that may be overwritten by the selected components.

    Candidate files are copied only for rollback. After a successful run every
    unchanged candidate copy is discarded, so the transaction retains only
    files that were actually modified.
    """
    rels: set[str] = set()

    def add(path: Path) -> None:
        try:
            rels.add(path.relative_to(root).as_posix())
        except ValueError:
            return

    if selected & {"text", "initial_equipment", "items", "shops", "experience", "level_exp", "bug_fix", "magic_recharge", "stability_qol", "additional_qol", "chapter_refresh", "final_battle_fix", "joshua_scroll_map", "vgm_bgm", "original_bgm", "flute_bgm", "m504_restoration"}:
        add(root / "ED2MAIN.EXE")
    if selected & {"text", "opening"}:
        add(root / "OPENING.EXE")
    if selected & {"text", "ending"}:
        add(root / "ENDING.DLL")
    if "ending" in selected:
        add(root / "STAFF.DLL")
        add(root / "GRP" / "ED19.STF")
        add(root / "GRP" / "E419.STF")
    if "direct_ending" in selected:
        add(root / "ED2END.EXE")
        add(root / "ENDING.BAT")
    if "chapter_refresh" in selected:
        for name in ("V_100.DLL", "V_200.DLL", "V_300.DLL", "V_400.DLL"):
            add(root / "SCENA" / name)
    if "map_preset" in selected:
        add(root / "MAP" / "M_003.BZH")

    if "symbol_density" in selected:
        for name in (
            "F_000.DLL", "F_200.DLL",
            "G_200.DLL", "G_202.DLL", "G_204.DLL", "G_210.DLL", "G_212.DLL", "G_214.DLL",
            "G_220.DLL", "G_222.DLL", "G_224.DLL", "G_230.DLL", "G_232.DLL", "G_240.DLL",
            "G_242.DLL", "G_244.DLL", "G_250.DLL", "G_252.DLL", "G_254.DLL", "G_262.DLL",
            "G_264.DLL", "G_272.DLL", "G_274.DLL",
        ):
            add(root / "SCENA" / name)

    if "shops" in selected:
        for name in (
            "T_200.DLL", "T_204.DLL", "T_208.DLL", "T_20C.DLL",
            "T_300.DLL", "T_302.DLL", "T_304.DLL", "T_306.DLL",
            "T_310.DLL", "T_312.DLL", "T_314.DLL", "T_316.DLL",
            "T_400.DLL", "T_402.DLL", "T_404.DLL", "T_406.DLL",
            "T_530.DLL", "T_532.DLL", "T_540.DLL", "T_542.DLL", "T_544.DLL", "T_560.DLL", "T_562.DLL",
        ):
            add(root / "SCENA" / name)
    if "stability_qol" in selected:
        add(root / "SCENA" / "C_631.DLL")
        add(root / "SCENA" / "C_00E.DLL")
        add(root / "SCENA" / "C_204.DLL")
        add(root / "SCENA" / "C_625.DLL")
    if selected & {"vgm_bgm", "original_bgm"}:
        add(root / "GKEY.EXE")
        for i in [*range(2, 28), 29, 30, 31]:
            add(root / "BGM" / f"DS2_{i:02d}.MUS")
        for i in (30, 31):
            add(root / "BGM" / f"DS2_{i:02d}.INS")
        add(root / "SCENA" / "C_600.DLL")
        add(root / "SCENA" / "C_634.DLL")
        add(root / "SCENA" / "C_203.DLL")
        add(root / "ED2END.EXE")
        for name in ("T_240.DLL", "T_543.DLL", "V_000.DLL", "V_100.DLL", "V_200.DLL", "V_300.DLL", "V_400.DLL"):
            add(root / "SCENA" / name)
        add(root / "MON" / "M_501.DLL")
    if "sfx_22050" in selected:
        add(root / "ED2.CNF")
        for name in (
            "EFC1.SMP", "EFC12.SMP", "EFC14.SMP", "EFC15.SMP", "EFC19.SMP",
            "EFC2.SMP", "EFC20.SMP", "EFC4.SMP", "EFC5.SMP", "EFC7.SMP",
            "EFC8.SMP", "EFC9.SMP", "FE049.SMP", "FE059.SMP", "FE079.SMP",
            "FE089.SMP", "FE099.SMP", "FE109.SMP", "FE119.SMP", "FE129.SMP",
            "FE139.SMP", "FE999.SMP",
        ):
            add(root / "BGM" / name)
    if "flute_bgm" in selected:
        add(root / "SCENA" / "C_632.DLL")
    if "late_skill_scaling" in selected:
        for name in ("M_400.DLL","M_402.DLL","M_500.DLL","M_501.DLL","M_511.DLL","M_518.DLL"):
            add(root / "MON" / name)

    if "final_battle_fix" in selected:
        add(root / "SCENA" / "C_734.DLL")
        add(root / "MON" / "M_501.DLL")
    if "dialogue" in selected:
        add(root / ".ed2_scene_algorithms.json")
    if selected & {"dialogue", "text"}:
        for path in (root / "SCENA").glob("*.DLL"):
            add(path)
    if selected & {"balance", "monster_text", "shops"}:
        for path in (root / "MON").glob("*.DLL"):
            add(path)
    if "m504_restoration" in selected:
        add(root / "MON" / "M_504.DLL")

    # Individual tools keep selective-restore journals and reports. Existing
    # metadata may be updated in place, so include it in the rollback snapshot.
    metadata_dirs = [root]
    if selected & {"dialogue", "text", "shops", "stability_qol", "final_battle_fix", "symbol_density"}:
        metadata_dirs.append(root / "SCENA")
    if selected & {"balance", "monster_text", "items", "shops", "experience", "bug_fix", "magic_recharge", "additional_qol", "final_battle_fix", "late_skill_scaling", "m504_restoration"}:
        metadata_dirs.append(root / "MON")
    if "map_preset" in selected:
        metadata_dirs.append(root / "MAP")
    for directory in metadata_dirs:
        if not directory.is_dir():
            continue
        for path in directory.glob("*.journal.json"):
            add(path)
        for path in directory.glob("*.json"):
            add(path)

    # Known generated files are included even when they do not exist yet, so a
    # failed transaction can delete newly-created outputs deterministically.
    for name in (
        REPORT_NAME,
        "ED2_TEXT_PATCH_REPORT.json",
        "ED2_FREYA_G_ED1900_NARRATION_V153.json",
        "ED2_FREYA_G_ED1900_NARRATION_V164.json",
        "ED2_VGM_BGM_ALL_REPORT.json",
        "ED2END_PATCH.json",
        "OPENING.EXE.ed2_text_patch.journal.json",
        "OPENING.EXE.ed2_pc98_opening.journal.json",
        "ED2MAIN.EXE.ed2_text_patch.journal.json",
        "ED2MAIN.EXE.ed2_mod_studio.journal.json",
        "ED2MAIN.EXE.ed2main_bug_fix_v1.journal.json",
        "ED2MAIN.EXE.ed2_stability_qol_v1.journal.json",
        "ED2MAIN.EXE.ed2_additional_qol_v1.journal.json",
        "ENDING.DLL.ed2_text_patch.journal.json",
        ".ed2_scene_algorithms.json",
        "SCENA/F_501.DLL.ed2_scene_editor.journal.json",
        "SCENA/F_502.DLL.ed2_scene_editor.journal.json",
        "SCENA/T_200.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_204.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_208.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_20C.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_300.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_302.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_304.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_306.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_310.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_312.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_314.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_316.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_400.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_402.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_404.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/T_406.DLL.ed2_shop_item_expansion_v1.journal.json",
        "SCENA/C_631.DLL.ed2_stability_qol_v1.journal.json",
        "SCENA/C_00E.DLL.ed2_stability_qol_v1.journal.json",
        "SCENA/C_204.DLL.ed2_stability_qol_v1.journal.json",
        "SCENA/C_625.DLL.ed2_stability_qol_v1.journal.json",
        "MAP/M_003.BZH.ed2_map_editor.journal.json",
    ):
        add(root / name)
    return rels


def snapshot_candidates(real: Path, selected: set[str], progress: Callable[[str], None], known_hashes: dict[str,str] | None = None) -> tuple[Path, dict[str, str], set[str]]:
    candidates=candidate_paths(real,selected); tx_root=create_transaction_root(real); before_dir=tx_root/'before'; copied=0
    known_hashes=known_hashes or {}; before={}
    # Input-state detection already hashed baseline files. Reuse those hashes
    # instead of rereading the same 30+ MB before the transaction.
    for rel in sorted(candidates):
        source=real/rel
        if not source.is_file(): continue
        before[rel]=known_hashes.get(rel) or sha256_path(source)
        target=before_dir/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,target); copied+=1
    progress(f"선택 패치 대상 {len(candidates)}개 중 기존 파일 {copied}개를 게임 폴더 밖 임시 롤백 공간에 보관했습니다.")
    return tx_root,before,candidates


def rollback_direct(real: Path, tx_root: Path, before: dict[str, str], candidates: set[str]) -> None:
    before_dir=tx_root/'before'; current=_map_selected_paths(real,candidates)
    for rel in sorted(set(current)-set(before),reverse=True):
        try:_force_unlink(real/rel)
        except FileNotFoundError:pass
    for rel in sorted(candidates):
        if rel not in before: continue
        backup=before_dir/rel
        if not backup.is_file(): raise PatchError(f"임시 롤백 사본이 없습니다: {rel}")
        _copy2_overwrite(backup,real/rel)
    restored=_map_selected_paths(real,candidates)
    differences=sorted(rel for rel in set(before)|set(restored) if before.get(rel)!=restored.get(rel))
    if differences: raise PatchError('자동 롤백 후에도 차이가 남았습니다: '+', '.join(differences[:20]))
    shutil.rmtree(tx_root,ignore_errors=True)

def is_distributable_game_file(rel: str) -> bool:
    path = Path(rel)
    name = path.name.lower()
    if rel == REPORT_NAME:
        return False
    if is_component_backup_artifact(rel):
        return False
    if name.endswith(".json") or name.endswith(".sha256"):
        return False
    if name.upper() in TRANSIENT_IGNORED_NAMES or Path(name).suffix.upper() in TRANSIENT_IGNORED_SUFFIXES:
        return False
    if name.endswith(".tmp") or name.endswith(".log"):
        return False
    return True


def next_patched_export_path(real: Path) -> Path:
    base = real.parent / f"{PATCHED_EXPORT_BASENAME}_v{VERSION}"
    candidate = base
    suffix = 2
    while candidate.exists():
        candidate = real.parent / f"{PATCHED_EXPORT_BASENAME}_v{VERSION}_{suffix}"
        suffix += 1
    return candidate


def prepare_patched_export(real: Path, rels: list[str], final_path: Path) -> Path:
    temp_path = Path(tempfile.mkdtemp(prefix=f".{PATCHED_EXPORT_BASENAME}_", dir=str(real.parent)))
    try:
        for rel in rels:
            source = real / rel
            if not source.is_file():
                raise PatchError(f"배포용으로 복사할 변경 파일이 없습니다: {rel}")
            target = temp_path / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        return temp_path
    except Exception:
        shutil.rmtree(temp_path, ignore_errors=True)
        raise

def official_distributable_paths() -> list[str]:
    stock = _manifest_rows(STOCK_BASELINE_MANIFEST)
    target = _manifest_rows(TARGET_FINAL_MANIFEST)
    rels = []
    for rel, row in target.items():
        old = stock.get(rel)
        if old is None or str(old["sha256"]) != str(row["sha256"]):
            if is_distributable_game_file(rel):
                rels.append(rel)
    return sorted(rels)


def rebuild_patched_export(real: Path, progress: Callable[[str], None] = print) -> dict[str, object]:
    """Re-create the full official distributable delta from an already-patched game."""
    real = validate_game_root(real)
    target = _manifest_rows(TARGET_FINAL_MANIFEST)
    rels = official_distributable_paths()
    bad: list[str] = []
    for rel in rels:
        q = real / rel
        expected = target[rel]
        if not q.is_file():
            bad.append(f"{rel}: missing")
            continue
        if q.stat().st_size != int(expected["size"]):
            bad.append(f"{rel}: size mismatch")
            continue
        if sha256_path(q) != str(expected["sha256"]):
            bad.append(f"{rel}: patched bytes mismatch")
    if bad:
        raise PatchError(
            "현재 게임이 공식 전체 패치 상태와 일치하지 않아 배포 파일을 다시 만들 수 없습니다.\n"
            + "\n".join(bad[:20])
        )
    final_path = next_patched_export_path(real)
    progress(f"공식 패치 변경 파일 {len(rels)}개를 배포용 폴더로 다시 만듭니다.")
    temp = prepare_patched_export(real, rels, final_path)
    try:
        os.replace(temp, final_path)
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise
    progress(f"배포용 파일을 만들었습니다: {final_path}")
    return {"tool": f"{APP_NAME} v{VERSION}", "patched_files_output": str(final_path), "patched_files_count": len(rels), "ok": True}


def finalize_direct_transaction(
    real: Path,
    tx_root: Path,
    before: dict[str, str],
    candidates: set[str],
    selected: list[str],
    create_export: bool = True,
) -> dict[str, object]:
    preview_after = _map_selected_paths(real, candidates)
    changed = sorted(rel for rel in set(before) | set(preview_after) if before.get(rel) != preview_after.get(rel))
    deleted = [rel for rel in changed if rel in before and rel not in preview_after and is_distributable_game_file(rel)]
    allowed_deleted = {"GRP/E419.STF"} if "ending" in selected else set()
    if "original_bgm" in selected:
        allowed_deleted.update({"BGM/DS2_30.MUS", "BGM/DS2_30.INS", "BGM/DS2_31.MUS", "BGM/DS2_31.INS"})
    unexpected_deleted = [rel for rel in deleted if rel not in allowed_deleted]
    if unexpected_deleted:
        raise PatchError('기존 게임 파일 삭제를 허용하지 않습니다: ' + ', '.join(unexpected_deleted[:10]))
    distributable = [rel for rel in changed if is_distributable_game_file(rel) and (real / rel).is_file()]
    export_path: Path | None = None
    export_temp: Path | None = None
    if create_export:
        export_path = next_patched_export_path(real)
        export_temp = prepare_patched_export(real, distributable, export_path)
    report = {
        'tool': f'{APP_NAME} v{VERSION}',
        'status': 'completed',
        'changed_files': len(changed),
        'selected_components': 'all' if set(selected)==_default_component_keys() else selected,
        'music_mode': _selected_music_mode(set(selected)),
        'patched_files_count': len(distributable),
        'patched_files_output': str(export_path) if export_path else None,
        'patched_files_exported': bool(create_export),
    }
    try:
        (real / REPORT_NAME).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        if export_temp is not None and export_path is not None:
            os.replace(export_temp, export_path)
        shutil.rmtree(tx_root, ignore_errors=True)
        return report
    except Exception:
        if export_temp is not None:
            shutil.rmtree(export_temp, ignore_errors=True)
        raise


def apply_all(
    root: Path,
    selected_keys: list[str],
    progress: Callable[[str], None] = print,
    create_export: bool = True,
    create_permanent_backup: bool = True,
) -> dict[str, object]:
    started=time.perf_counter()
    root=validate_game_root(root)
    selected_set=set(selected_keys)
    unknown=selected_set-{c.key for c in COMPONENTS}
    if unknown:
        raise PatchError('알 수 없는 구성 요소: '+', '.join(sorted(unknown)))
    if not selected_set:
        raise PatchError('적용할 패치를 하나 이상 선택해야 합니다.')
    music_mode=_selected_music_mode(selected_set)
    default_all=(selected_set==_default_component_keys())
    full_original=(selected_set==_full_original_component_keys())

    progress('게임 상태를 확인합니다.')
    state,known_hashes=detect_supported_game_state(root)
    if state.get('kind') == 'music_partial_current':
        non_source = selected_set - {'vgm_bgm','original_bgm'}
        if non_source:
            raise PatchError(
                '음악만 부분 적용된 상태에서는 BGM 소스 전환만 지원합니다.\n'
                '다른 구성요소를 추가하려면 순정에서 전체 패치를 적용하십시오.'
            )
    if state.get('kind') == 'partial_current':
        reported_set=set(state.get('selected_components', []))
        if selected_set != reported_set:
            raise PatchError(
                '현재 게임은 일부 구성요소만 적용된 상태입니다.\n'
                '안전한 재적용을 위해 이전과 같은 구성요소 조합으로 실행하거나 순정에서 다시 적용하십시오.'
            )
    backup_info=ensure_permanent_stock_backup(root,state,lambda _msg:None,create_permanent_backup)

    if state.get('kind') == 'partial_current':
        verify_final(root, selected_set)
        report={
            'tool':f'{APP_NAME} v{VERSION}', 'status':'already-current-partial',
            'changed_files':0, 'selected_components':selected_keys,
            'music_mode':music_mode, 'patched_files_count':0, 'patched_files_output':None,
            'patched_files_exported':False, 'permanent_backup':backup_info,
            'elapsed_sec':round(time.perf_counter()-started,3),
        }
        (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        progress('선택한 부분 패치가 이미 정상입니다. 변경 없이 완료했습니다.')
        return report
    tx_root=None; before={}; candidates=set()

    # Fast source-only switch from the exact official VGM target.  All other
    # components are already verified by the target manifest, so do not replay
    # the expensive dialogue/balance pipeline just to change the music source.
    if state.get('already_target') and music_mode == 'original':
        try:
            progress('BGM 소스를 원본 음악으로 전환합니다.')
            switch_set={'original_bgm'}
            tx_root,before,candidates=snapshot_candidates(root,switch_set,lambda _msg:None,known_hashes)
            apply_original_bgm(root)
            verify_original_bgm(root)
            report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
            report['elapsed_sec']=round(time.perf_counter()-started,3)
            report['permanent_backup']=backup_info
            report['mode_switch_only']=True
            (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            progress(f"완료: 원본 BGM으로 전환, 변경 {report['changed_files']}개.")
            return report
        except Exception as exc:
            if tx_root is not None:
                try:
                    rollback_direct(root,tx_root,before,candidates)
                except Exception as rollback_exc:
                    raise PatchError(f'{exc}\n\n자동 롤백도 실패했습니다: {rollback_exc}') from exc
            raise

    if state.get('already_target') and music_mode != 'original':
        report={
            'tool':f'{APP_NAME} v{VERSION}', 'status':'already-current',
            'changed_files':0,
            'selected_components':'all' if set(selected_keys)==_default_component_keys() else selected_keys,
            'music_mode': music_mode,
            'patched_files_count':0, 'patched_files_output':None,
            'patched_files_exported':False, 'permanent_backup':backup_info,
            'elapsed_sec':round(time.perf_counter()-started,3),
        }
        (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        progress('이미 최신 상태입니다. 변경 없이 완료했습니다.')
        return report

    # Current-generation user edits must never trigger a destructive replay of
    # the stock dialogue/body pipeline. First verify the selected profile as-is;
    # if only the BGM source differs, perform a source-only switch. Missing
    # patch-added outputs retain the narrow repair path below.
    if state.get('kind')=='custom_current':
        added_owner={
            'ED2END.EXE':'direct_ending', 'ENDING.BAT':'direct_ending',
            'BGM/DS2_30.INS':'vgm_bgm', 'BGM/DS2_30.MUS':'vgm_bgm',
            'BGM/DS2_31.INS':'vgm_bgm', 'BGM/DS2_31.MUS':'vgm_bgm',
            'GRP/ED19.STF':'ending', 'GRP/E419.STF':'ending',
            'MON/M_504.DLL':'m504_restoration',
        }
        # Missing custom-track files are an expected symptom when switching from
        # original -> VGM, so do not treat those four files as generic damage.
        source_owned={'BGM/DS2_30.INS','BGM/DS2_30.MUS','BGM/DS2_31.INS','BGM/DS2_31.MUS'}
        missing_added=[rel for rel,owner in added_owner.items()
                       if owner in selected_set and not (root/rel).is_file()
                       and not (music_mode=='vgm' and rel in source_owned)]
        repair_set={added_owner[rel] for rel in missing_added}
        if 'MON/M_504.DLL' in missing_added and 'balance' in selected_set:
            repair_set.add('balance')
        if repair_set:
            selected_set=repair_set; default_all=False; full_original=False
        else:
            try:
                verify_final(root,selected_set)
            except Exception as desired_exc:
                # A current install may be identical in every selected component
                # except for the opposite BGM source profile. Verify that exact
                # alternate profile before changing only the source owner.
                if music_mode not in {'vgm','original'}:
                    raise PatchError(
                        '현재 버전의 패치 영역이 수정되었거나 손상되었습니다.\n'
                        '순정 복원 후 다시 적용하십시오.'
                    ) from desired_exc
                alternate=set(selected_set)
                alternate.discard('vgm_bgm'); alternate.discard('original_bgm')
                alternate.add('original_bgm' if music_mode=='vgm' else 'vgm_bgm')
                try:
                    verify_final(root,alternate)
                except Exception as alternate_exc:
                    raise PatchError(
                        '현재 버전의 패치 영역이 수정되었거나 손상되었습니다.\n'
                        '순정 복원 후 다시 적용하십시오.'
                    ) from alternate_exc
                try:
                    progress('BGM 소스만 전환합니다.')
                    switch_set={music_mode=='original' and 'original_bgm' or 'vgm_bgm'}
                    tx_root,before,candidates=snapshot_candidates(root,switch_set,lambda _msg:None,known_hashes)
                    if music_mode=='original':
                        apply_original_bgm(root); verify_original_bgm(root)
                    else:
                        apply_vgm_bgm(root); verify_vgm_bgm(root)
                    report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                    report['elapsed_sec']=round(time.perf_counter()-started,3)
                    report['permanent_backup']=backup_info
                    report['mode_switch_only']=True
                    (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                    progress(f"완료: BGM 소스 전환, 변경 {report['changed_files']}개.")
                    return report
                except Exception as exc:
                    if tx_root is not None:
                        try:
                            rollback_direct(root,tx_root,before,candidates)
                        except Exception as rollback_exc:
                            raise PatchError(f'{exc}\n\n자동 롤백도 실패했습니다: {rollback_exc}') from exc
                    raise
            else:
                report={
                    'tool':f'{APP_NAME} v{VERSION}', 'status':'already-current-custom-preserved',
                    'changed_files':0,
                    'selected_components':'all' if set(selected_keys)==_default_component_keys() else selected_keys,
                    'music_mode':music_mode, 'patched_files_count':0, 'patched_files_output':None,
                    'patched_files_exported':False, 'permanent_backup':backup_info,
                    'elapsed_sec':round(time.perf_counter()-started,3),
                }
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress('선택한 패치가 이미 정상입니다. 사용자 수정은 그대로 보존했습니다.')
                return report
    try:
        if backup_info.get('created'):
            progress('순정 백업을 만들었습니다.')
        progress('패치를 적용합니다.')
        tx_root,before,candidates=snapshot_candidates(root,selected_set,lambda _msg:None,known_hashes)

        if state.get('kind') == 'previous_target':
            if not (default_all or full_original):
                raise PatchError('이전 정식판 -> v1.4.71 직접 이행은 전체 적용 프로필에서만 지원합니다.')
            previous_version=str(state.get('version',''))
            if previous_version == '1.4.70':
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else:
                    verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.69':
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else:
                    verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.68':
                # v1.4.69 reorganizes components but keeps the v1.4.68 game payload.
                verify_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else:
                    verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.67':
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else:
                    verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.66':
                # v1.4.67 changes five final game files.  Re-run only their
                # owning components in dependency order: VGM WAIT_BGM sync,
                # flute callers, Gabi/M_502 text, final-battle C_734, Joshua
                # normalization, and finally regenerate ED2END from ED2MAIN.
                if music_mode == 'original':
                    apply_original_bgm(root)
                else:
                    # The released v1.4.66 VGM core is already current except
                    # for the new one-shot WAIT_BGM completion contract.  The
                    # full source-mode installer is intentionally stock-only,
                    # so upgrade only this exact owner here.
                    apply_vgm_wait_bgm_sync(root)
                apply_flute_bgm(root)
                # v1.4.66 already contains the full reviewed monster-text
                # baseline.  Apply only the v15 integrated delta so the new
                # M_502 trailing-space redirect is added without replaying the
                # older v11 base importer over already-patched MON DLLs.
                apply_monster_text_v15_delta(root)
                # v0.18.18 and v0.18.19 append helpers in different canonical
                # layouts.  Convert only the exact released v1.4.66 C_734 to
                # the fresh v1.4.67 bytes so stock and upgrade installs converge.
                migrate_c734_v1466_to_v1467(root)
                apply_joshua_scroll_map(root)
                apply_direct_ending(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else:
                    verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.65':
                # v1.4.65 could be reached only through the older C_734 canonicalization.
                # Convert that exact known binary to the stock-derived v1.4.66 canonical
                # representation; all other selected files are already current.
                migrate_c734_v1465_to_v1466(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.64':
                # R17 is already canonical. Final Battle v0.18.19 is the last C_734 writer.
                apply_flute_bgm(root)
                apply_late_skill_scaling(root)
                apply_dialogue_throne_room_layout(root)
                apply_final_battle_presentation(root)
                if music_mode == 'original': apply_original_bgm(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.63':
                # Restore only the exact old Gabi redirect as a generation migration.
                migrate_legacy_gabi_m502_wait(root)
                apply_flute_bgm(root)
                apply_late_skill_scaling(root)
                apply_dialogue_throne_room_layout(root)
                apply_final_battle_presentation(root)
                if music_mode == 'original': apply_original_bgm(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.62':
                migrate_legacy_gabi_m502_wait(root)
                apply_flute_bgm(root)
                apply_late_skill_scaling(root)
                apply_dialogue_throne_room_layout(root)
                apply_final_battle_presentation(root)
                if music_mode == 'original': apply_original_bgm(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.61':
                apply_dialogue_v1462_update(root)
                apply_flute_bgm(root)
                apply_late_skill_scaling(root)
                apply_dialogue_throne_room_layout(root)
                apply_final_battle_presentation(root)
                if music_mode == 'original': apply_original_bgm(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.60':
                apply_dialogue_v1461_cleanup(root)
                apply_dialogue_v1462_update(root)
                apply_monster_text_v15_delta(root)
                apply_flute_bgm(root)
                apply_late_skill_scaling(root)
                apply_dialogue_throne_room_layout(root)
                apply_final_battle_presentation(root)
                if music_mode == 'original': apply_original_bgm(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            if previous_version == '1.4.59':
                apply_dialogue_v1460_layout(root)
                apply_dialogue_v1461_cleanup(root)
                apply_dialogue_v1462_update(root)
                apply_monster_text_v15_delta(root)
                apply_flute_bgm(root)
                apply_late_skill_scaling(root)
                apply_dialogue_throne_room_layout(root)
                apply_final_battle_presentation(root)
                if music_mode == 'original': apply_original_bgm(root)
                apply_final_battle_runtime(root)
                apply_v1471_migration_delta(root)
                progress('최종 확인 중입니다.')
                if default_all:
                    result=verify_default_final_baseline(root)
                    if not result.get('ok'): raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
                else: verify_final(root, selected_set)
                report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
                report['elapsed_sec']=round(time.perf_counter()-started,3); report['permanent_backup']=backup_info
                (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                progress(f"완료: 변경 {report['changed_files']}개."); return report
            recent_versions = {'1.4.44R2', '1.4.45', '1.4.46', '1.4.47', '1.4.48', '1.4.49', '1.4.50'}
            if previous_version == '1.4.51':
                pass
            elif previous_version in recent_versions:
                # Apply every missing release delta in order.  Earlier code used
                # mutually exclusive branches, so e.g. 1.4.47 -> 1.4.49 received
                # the 1.4.48 M_501 reflow but silently skipped the v1.4.49
                # opening/SELL_SHOP/symbol-density changes.
                if previous_version == '1.4.44R2':
                    apply_items(root)
                    apply_direct_ending(root)
                if previous_version in {'1.4.44R2', '1.4.45'}:
                    apply_throne_room_dialogue_reflow(root)
                if previous_version in {'1.4.44R2', '1.4.45', '1.4.46'}:
                    apply_monster_text_v15_delta(root)
                if previous_version in {'1.4.44R2', '1.4.45', '1.4.46', '1.4.47'}:
                    apply_final_battle_presentation(root)
                # v1.4.49 payload for targets older than v1.4.49.
                # R52 repairs only the three known damaged SELL_SHOP local pointer
                # tables; Opening v1.5.1 owns its new narration layout; symbol
                # density is a normal selectable/default component.
                if previous_version != '1.4.49':
                    repair_sell_shop_dialogue(root)
                    apply_opening(root)
                    if 'symbol_density' in selected_set:
                        apply_symbol_density(root)
                # v1.4.50 payload: remove menu cursor wrapping while preserving
                # Shift turbo movement and the 20/4-tick menu key repeat.
                if previous_version != '1.4.50' and 'additional_qol' in selected_set:
                    apply_additional_qol(root)
                # ED2END is generated from the finalized ED2MAIN image, so the
                # menu-wrap removal must be reflected there as well.
                if previous_version != '1.4.50' and 'direct_ending' in selected_set:
                    apply_direct_ending(root)
            else:
                if previous_version != '1.4.41R1':
                    apply_monster_text_v15_delta(root)
                    # v1.4.41R1 ownership/order: restore optional M_504 first, then let
                    # the normal balance component tune Dadarca/Actos when that DLL exists.
                    apply_m504_restoration(root)
                    apply_balance(root)
                    if previous_version == '1.4.39':
                        # v1.4.40 UI/reward/confusion/conditional-levelup fixes now belong
                        # to the normal text component; M_504 restoration stays independent.
                        apply_text(root)
                        apply_direct_ending(root)
                # Historical supported targets still need the consolidated dialogue delta.
                apply_dialogue_legacy_upgrade(root)
                c734 = root / 'SCENA' / 'C_734.DLL'
                if c734.is_file() and sha256_path(c734) == "af1a6e5d7767ee169a1c7e845cdada4367cbed5c1c5f73d089f961a9b1743aab":
                    apply_throne_room_dialogue_reflow(root)
                # Bring historical targets through the two latest presentation
                # deltas before applying the v1.4.49 payload.
                apply_final_battle_presentation(root)
                repair_sell_shop_dialogue(root)
                apply_opening(root)
                if 'symbol_density' in selected_set:
                    apply_symbol_density(root)
                if 'additional_qol' in selected_set:
                    apply_additional_qol(root)
                if 'direct_ending' in selected_set:
                    apply_direct_ending(root)
            # v1.4.51 payload: R53 dialogue naturalness/semantic repairs.
            if previous_version != '1.4.51':
                apply_dialogue_r53_upgrade(root)
            # Historical dialogue upgrade path (not distributed as a supported source state in v1.4.56).
            apply_dialogue_r54_upgrade(root)
            if music_mode == 'original':
                apply_original_bgm(root)
            apply_final_battle_runtime(root)
            apply_v1471_migration_delta(root)
            progress('최종 확인 중입니다.')
            if default_all:
                result=verify_default_final_baseline(root)
                if not result.get('ok'):
                    raise PatchError('v1.4.71 직접 이행 최종 검증에 실패했습니다.')
            else:
                verify_final(root, selected_set)
            report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
            report['elapsed_sec']=round(time.perf_counter()-started,3)
            report['permanent_backup']=backup_info
            (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            progress(f"완료: 변경 {report['changed_files']}개.")
            return report

        # Core components. Chapter refresh/direct ending run last because they
        # depend on the final ED2MAIN/SCENA state.
        if 'dialogue' in selected_set and state.get('kind') == 'stock':
            progress('구성 요소: dialogue')
            apply_dialogue(root, with_chapter=('chapter_refresh' in selected_set))

        for component in COMPONENTS:
            if component.key not in selected_set or component.key in {'dialogue','chapter_refresh','joshua_scroll_map','direct_ending','final_battle_fix'}:
                continue
            progress(f'구성 요소: {component.key}')
            if component.key=='shops' and 'items' in selected_set:
                apply_shop_items(root,ensure_item_magic_support=False)
            else:
                component.apply(root)

        if selected_set & {'shops','balance'}:
            progress('구성 요소: restored_item_drop_policy')
            apply_restored_item_drop_policy(root,'shops' in selected_set)

        if 'dialogue' in selected_set:
            progress('구성 요소: R19 final dialogue/particle/title spacing')
            # apply_dialogue() already converges stock SCENA through the
            # v1.4.60/v1.4.61/v1.4.62 layout generations and then applies the
            # R19 final pass (preserving the R18 audit).  Do not replay those legacy writers here: on a fresh
            # stock install that would reinterpret already-converged bytes.
            # Only reassert the final presentation owners after other SCENA
            # components have run.
            apply_dialogue_throne_room_layout(root)
            apply_dialogue_v1471_audit(root)

        if 'final_battle_fix' in selected_set:
            progress('구성 요소: final_battle_fix')
            # Final Battle Fix v0.19.0 owns the final C_734 battle-state write.
            apply_final_battle_presentation(root)

        if 'chapter_refresh' in selected_set:
            progress('구성 요소: chapter_refresh')
            apply_chapter_title_refresh(root)
        if 'joshua_scroll_map' in selected_set:
            progress('구성 요소: joshua_scroll_map')
            apply_joshua_scroll_map(root)
        if 'direct_ending' in selected_set:
            progress('구성 요소: direct_ending')
            apply_direct_ending(root)

        if 'final_battle_fix' in selected_set:
            progress('구성 요소: Final Battle Fix v0.19.0 runtime')
            apply_final_battle_runtime(root)

        progress('최종 확인 중입니다.')
        verify_final(root,selected_set)

        report=finalize_direct_transaction(root,tx_root,before,candidates,selected_keys,create_export=create_export)
        report['elapsed_sec']=round(time.perf_counter()-started,3)
        report['permanent_backup']=backup_info
        (root/REPORT_NAME).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        progress(f"완료: 변경 {report['changed_files']}개.")
        return report
    except Exception as exc:
        if tx_root is not None:
            try:
                rollback_direct(root,tx_root,before,candidates)
            except Exception as rollback_exc:
                raise PatchError(f'{exc}\n\n자동 롤백도 실패했습니다: {rollback_exc}') from exc
        raise

def choose_root_gui() -> Path | None:
    import tkinter as tk
    from tkinter import filedialog
    temp = tk.Tk(); temp.withdraw()
    selected = filedialog.askdirectory(title="영웅전설 II 게임 폴더 선택")
    temp.destroy()
    return Path(selected) if selected else None


class GUI:
    def __init__(self, initial: Path | None = None):
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
        self.tk, self.ttk = tk, ttk
        self.filedialog, self.messagebox = filedialog, messagebox
        self.root = tk.Tk()
        self.root.title(f"{APP_NAME} v{VERSION}")

        # Keep the window usable on small displays and high-DPI Windows setups.
        # The whole GUI body is scrollable, so the bottom patch buttons never
        # become permanently inaccessible when the requested size exceeds the
        # available desktop height.
        screen_w = max(640, self.root.winfo_screenwidth())
        screen_h = max(480, self.root.winfo_screenheight())
        width = min(900, max(720, screen_w - 80))
        height = min(720, max(480, screen_h - 120))
        self.root.geometry(f"{width}x{height}")
        self.root.minsize(720, 480)

        self.path_var = tk.StringVar(value=str(initial or ""))
        self.vars = {c.key: tk.BooleanVar(value=c.default) for c in COMPONENTS}
        self.music_mode_var = tk.StringVar(value="vgm")
        self.create_backup_var = tk.BooleanVar(value=True)
        self.create_export_var = tk.BooleanVar(value=True)

        scroll_host = ttk.Frame(self.root)
        scroll_host.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(scroll_host, highlightthickness=0, borderwidth=0)
        self.vscroll = ttk.Scrollbar(scroll_host, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vscroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vscroll.pack(side="right", fill="y")

        outer = ttk.Frame(self.canvas, padding=12)
        self._canvas_window = self.canvas.create_window((0, 0), window=outer, anchor="nw")

        def update_scroll_region(_event=None):
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))

        def fit_inner_width(event):
            self.canvas.itemconfigure(self._canvas_window, width=event.width)

        outer.bind("<Configure>", update_scroll_region)
        self.canvas.bind("<Configure>", fit_inner_width)

        def scroll_mouse(event):
            # Let the log Text widget keep its own wheel scrolling. Elsewhere,
            # the wheel moves the full GUI vertically.
            if event.widget is self.log:
                return
            if getattr(event, "num", None) == 4:
                amount = -3
            elif getattr(event, "num", None) == 5:
                amount = 3
            else:
                delta = getattr(event, "delta", 0)
                if not delta:
                    return
                amount = -3 if delta > 0 else 3
            self.canvas.yview_scroll(amount, "units")

        self._scroll_mouse = scroll_mouse

        row = ttk.Frame(outer); row.pack(fill="x")
        ttk.Entry(row, textvariable=self.path_var).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="게임 폴더 선택", command=self.choose).pack(side="left", padx=(8, 0))

        box = ttk.LabelFrame(outer, text="적용할 구성 요소", padding=10); box.pack(fill="x", pady=12)
        for c in COMPONENTS:
            if c.key in {"vgm_bgm", "original_bgm"}:
                continue
            ttk.Checkbutton(box, text=c.label, variable=self.vars[c.key]).pack(anchor="w", pady=2)

        music = ttk.LabelFrame(outer, text="BGM 모드", padding=10); music.pack(fill="x", pady=(0, 12))
        ttk.Radiobutton(music, text="교체 VGM BGM (기본)", value="vgm", variable=self.music_mode_var).pack(anchor="w", pady=2)
        ttk.Radiobutton(music, text="원본 BGM", value="original", variable=self.music_mode_var).pack(anchor="w", pady=2)
        ttk.Label(music, text="원본 BGM은 순정 MUS/곡 매핑을 사용하며 BGM 제어·hard-stop 수정은 유지합니다.", wraplength=810).pack(anchor="w", pady=(4, 0))

        options = ttk.LabelFrame(outer, text="백업 / 배포 옵션", padding=10); options.pack(fill="x", pady=(0, 12))
        ttk.Checkbutton(
            options,
            text="순정 백업 만들기 (순정 상태에서 처음 적용할 때만 생성)",
            variable=self.create_backup_var,
        ).pack(anchor="w", pady=2)
        ttk.Checkbutton(
            options,
            text="패치 완료 후 배포용 변경 파일 폴더 만들기",
            variable=self.create_export_var,
        ).pack(anchor="w", pady=2)

        note = (
            "순정 백업은 게임 폴더와 같은 위치의 별도 *_STOCK_BACKUP 폴더에 보관합니다.\n"
            "SAVE 데이터는 순정 백업/복원 대상이 아니며, 적용 중 오류용 임시 롤백도 별도로 유지합니다.\n"
            "배포용 파일은 체크한 경우에만 만들며, 나중에 '배포 파일 다시 만들기'로 재생성할 수 있습니다."
        )
        ttk.Label(outer, text=note, justify="left", wraplength=810).pack(anchor="w")
        self.log = tk.Text(outer, height=15, wrap="word", state="disabled"); self.log.pack(fill="both", expand=True, pady=10)
        buttons = ttk.Frame(outer); buttons.pack(fill="x", pady=(0, 4))
        ttk.Button(buttons, text="선택 패치 한번에 적용", command=self.do_apply).pack(side="left")
        ttk.Button(buttons, text="순정 복원", command=self.do_restore_stock).pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="배포 파일 다시 만들기", command=self.do_rebuild_export).pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="닫기", command=self.root.destroy).pack(side="right")

        # Windows/macOS wheel and Linux X11 wheel events.
        self.root.bind_all("<MouseWheel>", self._scroll_mouse, add="+")
        self.root.bind_all("<Button-4>", self._scroll_mouse, add="+")
        self.root.bind_all("<Button-5>", self._scroll_mouse, add="+")
        self.root.after_idle(update_scroll_region)

    def choose(self):
        value = self.filedialog.askdirectory(title="영웅전설 II 게임 폴더 선택")
        if value: self.path_var.set(value)

    def append(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.root.update_idletasks()

    def do_apply(self):
        try:
            root = validate_game_root(Path(self.path_var.get()))
            selected = [c.key for c in COMPONENTS if c.key not in {"vgm_bgm", "original_bgm"} and self.vars[c.key].get()]
            selected.append("original_bgm" if self.music_mode_var.get() == "original" else "vgm_bgm")
            labels = [c.label for c in COMPONENTS if c.key in selected]
            if set(selected)==_default_component_keys():
                question="전체 패치를 적용할까요?\n\nBGM: 교체 VGM"
            elif set(selected)==_full_original_component_keys():
                question="전체 패치를 적용할까요?\n\nBGM: 원본 음악"
            else:
                question="선택한 패치를 적용할까요?\n\n" + "\n".join("- " + x for x in labels)
            if not self.messagebox.askyesno(APP_NAME, question):
                return
            report = apply_all(
                root, selected, self.append,
                create_export=self.create_export_var.get(),
                create_permanent_backup=self.create_backup_var.get(),
            )
            export_line = (
                f"배포용 파일: {report['patched_files_count']}개\n{report['patched_files_output']}"
                if report.get('patched_files_exported')
                else "배포용 파일: 생성하지 않음"
            )
            backup = report.get('permanent_backup') or {}
            backup_line = f"\n순정 백업: {backup.get('path')}" if backup.get('path') else ""
            self.messagebox.showinfo(APP_NAME, f"적용을 완료했습니다.\n변경 파일: {report['changed_files']}개\n{export_line}{backup_line}")
        except Exception as exc:
            self.append("오류: " + str(exc))
            self.messagebox.showerror(APP_NAME, str(exc))

    def do_restore_stock(self):
        try:
            root = Path(self.path_var.get()).expanduser().resolve()
            if not root.is_dir():
                raise PatchError(f"게임 폴더를 찾지 못했습니다: {root}")
            backup = stock_backup_path(root)
            if not self.messagebox.askyesno(
                APP_NAME,
                "순정 백업으로 패치가 변경한 게임 파일을 복원할까요?\n\n"
                f"백업: {backup}\n\nSAVE 데이터는 건드리지 않습니다.",
            ):
                return
            self.append("=== 순정 복원 시작 ===")
            report = restore_stock_backup(root, self.append)
            self.messagebox.showinfo(
                APP_NAME,
                f"순정 복원을 완료했습니다.\n복원 파일: {report['restored_files']}개\n제거한 패치 추가/메타데이터: {report['removed_patch_files']}개",
            )
        except Exception as exc:
            self.append("오류: " + str(exc))
            self.messagebox.showerror(APP_NAME, str(exc))

    def do_rebuild_export(self):
        try:
            root = validate_game_root(Path(self.path_var.get()))
            if not self.messagebox.askyesno(APP_NAME, "현재 전체 패치 상태에서 배포용 변경 파일 폴더를 다시 만들까요?"):
                return
            self.append("=== 배포 파일 재생성 시작 ===")
            report = rebuild_patched_export(root, self.append)
            self.messagebox.showinfo(
                APP_NAME,
                f"배포용 파일을 다시 만들었습니다.\n파일: {report['patched_files_count']}개\n\n{report['patched_files_output']}",
            )
        except Exception as exc:
            self.append("오류: " + str(exc))
            self.messagebox.showerror(APP_NAME, str(exc))

    def run(self):
        self.root.mainloop()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("path", nargs="?", type=Path)
    parser.add_argument("--apply-all", action="store_true", help="기본 구성 요소 전부 적용")
    parser.add_argument("--components", help="쉼표로 구분한 구성 요소 키")
    parser.add_argument("--music-mode", choices=["vgm", "original"], help="BGM 소스: 교체 VGM 또는 원본 MUS")
    parser.add_argument("--validate", action="store_true", help="게임 폴더 기본 구조만 검증")
    parser.add_argument("--no-permanent-backup", action="store_true", help="순정 영구 백업을 만들지 않음")
    parser.add_argument("--no-export", action="store_true", help="적용 후 배포용 변경 파일 폴더를 만들지 않음")
    parser.add_argument("--restore-stock", action="store_true", help="영구 순정 백업에서 패치 변경 파일 복원")
    parser.add_argument("--rebuild-export", action="store_true", help="현재 전체 패치 상태에서 배포용 변경 파일 다시 만들기")
    parser.add_argument("--no-gui", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.validate:
            if not args.path: parser.error("path가 필요합니다")
            print(validate_game_root(args.path)); return 0
        if args.restore_stock:
            if not args.path: parser.error("path가 필요합니다")
            print(json.dumps(restore_stock_backup(args.path), ensure_ascii=False, indent=2)); return 0
        if args.rebuild_export:
            if not args.path: parser.error("path가 필요합니다")
            print(json.dumps(rebuild_patched_export(args.path), ensure_ascii=False, indent=2)); return 0
        if args.apply_all or args.components:
            if not args.path: parser.error("path가 필요합니다")
            selected = (
                [c.key for c in COMPONENTS if c.default]
                if args.apply_all else
                [x.strip() for x in args.components.split(",") if x.strip()]
            )
            if args.music_mode:
                selected = [x for x in selected if x not in {"vgm_bgm", "original_bgm"}]
                selected.append("original_bgm" if args.music_mode == "original" else "vgm_bgm")
            print(json.dumps(apply_all(
                args.path, selected,
                create_export=not args.no_export,
                create_permanent_backup=not args.no_permanent_backup,
            ), ensure_ascii=False, indent=2)); return 0
        if args.no_gui:
            return 0
        GUI(args.path).run(); return 0
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
