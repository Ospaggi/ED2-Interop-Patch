@echo off
setlocal
pushd "%~dp0" || exit /b 1
where py >nul 2>&1
if not errorlevel 1 (
  py -3 "ed2_all_in_one_patcher.py" %*
) else (
  python "ed2_all_in_one_patcher.py" %*
)
set "RC=%ERRORLEVEL%"
popd
exit /b %RC%
