# Soldier's Flute BGM Fix v0.3.7

전사의 피리 호출부를 실제 ED2MAIN `WAIT_BGM`에 연결합니다.

- ED2MAIN MG_FUE: direct WAIT_BGM
- SCENA/C_632.DLL: direct imported WAIT_BGM
- 과거 86:0200 고정시간 flute wrapper: 제거/빈 슬롯
- 실제 one-shot 완료 대기: VGM Engine v0.5.50의 carrier-clock sync가 담당
- MON/M_502.DLL: 이 컴포넌트의 읽기/해시/백업/복원/수정 대상에서 제외

가비전 M_502의 문구와 세대 마이그레이션은 별도 소유권입니다.
