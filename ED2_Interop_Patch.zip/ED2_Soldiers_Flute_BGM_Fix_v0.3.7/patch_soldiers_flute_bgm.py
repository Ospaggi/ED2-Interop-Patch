#!/usr/bin/env python3
from __future__ import annotations

import os
import argparse, os, struct, tempfile, json, hashlib, shutil
from pathlib import Path

VERSION='0.3.7'
BACKUP_DIR=Path('ED2_BACKUP')/'Soldiers_Flute_BGM'
LEGACY_BACKUP_DIR='ED2_FLUTE_BGM_BACKUP_v0.3.0'
MANIFEST='manifest.json'

# ---------------------------------------------------------------------------
# ED2MAIN / item-use MG_FUE patch
# ---------------------------------------------------------------------------
MAIN_SEG=86
MAIN_RELOC_COUNT=1630
MAIN_STOCK_LEN=0xB844
FLUTE_CAVE_OFF=0x0200
BATTLE_CAVE_OFF=0x0100
MG_FUE_OFF=0x8206
MG_FUE_PREFIX=bytes.fromhex('B0 12 9A FF FF 00 00 9A FF FF 00 00')
MG_FUE_WAIT_RELOC_SRC=0x820E
WAIT_BGM_TARGET=(86,0x38E6)
VGA_RETRACE_COUNT=457

OLD_V010_WRAPPER=bytes.fromhex(
    '9C '
    '80 3E 47 20 00 74 17 '
    '80 3E D6 3E 12 75 10 '
    '50 51 52 '
    'B4 86 B9 74 00 BA D0 BA CD 15 '
    '5A 59 58 9D CB'
)
MAIN_WRAPPER=bytes.fromhex(
    '9C '
    '80 3E 47 20 00 74 1F '
    '80 3E D6 3E 12 75 18 '
    '50 51 52 '
    'B9 C9 01 '
    'BA DA 03 '
    'EC A8 08 75 FB '
    'EC A8 08 74 FB '
    'E2 F4 '
    '5A 59 58 9D CB'
)
# Known VGM battle-end wrappers, used only for fixed-slot recognition and
# legacy-layout interop migration.  The old append-at-end wrapper used a
# location-dependent near CALL displacement (9B 7F).  At the fixed 86:0100
# slot, v0.5.35 correctly uses DF 36 so the CALL reaches 86:37FB.
BATTLE_RELOC_SRC=0x351D
BATTLE_WRAPPER_FIXED=bytes.fromhex(
    '9C 50 53 51 52 56 57 55 1E 06 '
    'B4 01 CD 40 '
    '07 1F 5D 5F 5E 5A 59 5B 58 9D '
    '0E E8 DF 36 CB'
)
BATTLE_WRAPPER_LEGACY=bytes.fromhex(
    '9C 50 53 51 52 56 57 55 1E 06 '
    'B4 01 CD 40 '
    '07 1F 5D 5F 5E 5A 59 5B 58 9D '
    '0E E8 9B 7F CB'
)

# ---------------------------------------------------------------------------
# C_632.DLL / chapter-final Grostos Castle man event
# ---------------------------------------------------------------------------
C632_SEG=3
C632_RELOC_COUNT=77
C632_EVENT_OFF=0x0809
C632_EVENT_SIG=bytes.fromhex('B0 12 9A FF FF 00 00 9A FF FF 00 00 A0 00 00 EA FF FF 00 00')
C632_WAIT_RELOC_SRC=0x0811
C632_WAIT_IMPORT=(3,1,0x0811,1,102)
C632_WRAPPER=bytes.fromhex(
    '9C '
    '50 51 52 '
    'B9 C9 01 '
    'BA DA 03 '
    'EC A8 08 75 FB '
    'EC A8 08 74 FB '
    'E2 F4 '
    '5A 59 58 '
    '9D CB'
)

# ---------------------------------------------------------------------------

def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def sha(b): return hashlib.sha256(b).hexdigest()

def find_ci(root:Path,name:str,subdir: str|None=None)->Path:
    base=root/subdir if subdir else root
    if not base.is_dir(): raise FileNotFoundError(f'폴더를 찾지 못했습니다: {base}')
    direct=base/name
    if direct.exists(): return direct
    hits=[p for p in base.iterdir() if p.is_file() and p.name.lower()==name.lower()]
    if len(hits)==1:return hits[0]
    if not hits:raise FileNotFoundError(f'{name}을(를) 찾지 못했습니다: {base}')
    raise RuntimeError(f'{name} 후보가 여러 개입니다: {hits}')

def looks(root:Path)->bool:
    try: find_ci(root,'ED2MAIN.EXE'); find_ci(root,'C_632.DLL','SCENA'); return True
    except Exception:return False

def auto_root(explicit=None)->Path:
    if explicit not in (None,'','.','auto'):
        r=Path(explicit).expanduser().resolve()
        if not looks(r):raise FileNotFoundError(f'ED2 게임 폴더가 아닙니다: {r}')
        return r
    seen=set()
    for start in [Path(__file__).resolve().parent,Path.cwd().resolve()]:
        for r in (start,*start.parents):
            k=str(r).lower()
            if k in seen:continue
            seen.add(k)
            if looks(r):return r
    raise FileNotFoundError('ED2MAIN.EXE와 SCENA\\C_632.DLL이 있는 게임 폴더를 찾지 못했습니다.')

def ne_info(b:bytes):
    if len(b)<0x40 or b[:2]!=b'MZ':raise RuntimeError('MZ 파일이 아닙니다.')
    ne=u32(b,0x3c)
    if ne+0x40>len(b) or b[ne:ne+2]!=b'NE':raise RuntimeError('16-bit NE 파일이 아닙니다.')
    count=u16(b,ne+0x1c); table=ne+u16(b,ne+0x22); shift=u16(b,ne+0x32)
    return ne,table,shift,count

def segment_record(b:bytes,index:int):
    ne,table,shift,count=ne_info(b)
    if not 1<=index<=count:raise RuntimeError('NE segment index 범위 오류')
    p=table+(index-1)*8
    sec,length,flags,alloc=struct.unpack_from('<HHHH',b,p)
    return p,sec<<shift,(0x10000 if length==0 else length),flags,alloc

def next_seg_base(b:bytes,index:int): return segment_record(b,index+1)[1]

def reloc_layout(b:bytes,index:int,expected_count:int):
    sp,base,seglen,flags,alloc=segment_record(b,index)
    if not flags&0x0100:raise RuntimeError(f'NE segment {index} relocation flag가 없습니다.')
    roff=base+seglen
    if roff+2>len(b):raise RuntimeError('relocation table가 없습니다.')
    cnt=u16(b,roff)
    if cnt!=expected_count:raise RuntimeError(f'NE segment {index} relocation 개수가 예상과 다릅니다: {cnt}')
    rend=roff+2+cnt*8; nxt=next_seg_base(b,index)
    if rend>nxt:raise RuntimeError('relocation table가 다음 segment와 겹칩니다.')
    return sp,base,seglen,flags,alloc,roff,cnt,rend,nxt

def relocs(b:bytes,index:int,expected_count:int):
    *_,roff,cnt,rend,nxt=reloc_layout(b,index,expected_count)
    return [(i,roff+2+i*8,struct.unpack_from('<BBHHH',b,roff+2+i*8)) for i in range(cnt)]

def reloc_layout_any(b:bytes,index:int):
    sp,base,seglen,flags,alloc=segment_record(b,index)
    if not flags&0x0100:raise RuntimeError(f'NE segment {index} relocation flag가 없습니다.')
    roff=base+seglen
    if roff+2>len(b):raise RuntimeError('relocation table가 없습니다.')
    cnt=u16(b,roff);rend=roff+2+cnt*8;nxt=next_seg_base(b,index)
    if rend>nxt:raise RuntimeError('relocation table가 다음 segment와 겹칩니다.')
    return sp,base,seglen,flags,alloc,roff,cnt,rend,nxt

def relocs_any(b:bytes,index:int):
    *_,roff,cnt,rend,nxt=reloc_layout_any(b,index)
    return [(i,roff+2+i*8,struct.unpack_from('<BBHHH',b,roff+2+i*8)) for i in range(cnt)]

def imported_modules(b:bytes):
    ne,_,_,_=ne_info(b); cnt=u16(b,ne+0x1e); mt=ne+u16(b,ne+0x28); it=ne+u16(b,ne+0x2a)
    out=[]
    for i in range(cnt):
        off=u16(b,mt+i*2); p=it+off; n=b[p]
        out.append(b[p+1:p+1+n].decode('latin1',errors='replace'))
    return out

def atomic(path:Path,data:bytes):
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent));os.close(fd)
    try:Path(tmp).write_bytes(data);os.replace(tmp,path)
    finally:
        try:os.unlink(tmp)
        except FileNotFoundError:pass

# ---- ED2MAIN ---------------------------------------------------------------
def main_reloc_by_source(b,src):
    hits=[(i,p,r) for i,p,r in relocs(b,MAIN_SEG,MAIN_RELOC_COUNT) if r[2]==src]
    if len(hits)!=1:raise RuntimeError(f'ED2MAIN relocation source {src:04X} 특정 실패: {len(hits)}')
    return hits[0]

def bytes_at(b,base,off,n):return b[base+off:base+off+n]

def wrapper_kind_at(b,base,off):
    if off<0:return None
    if bytes_at(b,base,off,len(MAIN_WRAPPER))==MAIN_WRAPPER:return 'flute'
    if bytes_at(b,base,off,len(OLD_V010_WRAPPER))==OLD_V010_WRAPPER:return 'flute_old'
    if bytes_at(b,base,off,len(BATTLE_WRAPPER_FIXED))==BATTLE_WRAPPER_FIXED:return 'battle'
    if bytes_at(b,base,off,len(BATTLE_WRAPPER_LEGACY))==BATTLE_WRAPPER_LEGACY:return 'battle_legacy'
    return None

def tail_known(b,base,seglen):
    if seglen<MAIN_STOCK_LEN:return False
    pos=MAIN_STOCK_LEN
    while pos<seglen:
        k=wrapper_kind_at(b,base,pos)
        if k=='flute':pos+=len(MAIN_WRAPPER)
        elif k=='flute_old':pos+=len(OLD_V010_WRAPPER)
        elif k in ('battle','battle_legacy'):pos+=len(BATTLE_WRAPPER_FIXED)
        else:return False
    return pos==seglen

def main_common(b):
    sp,base,seglen,flags,alloc,roff,cnt,rend,nxt=reloc_layout(b,MAIN_SEG,MAIN_RELOC_COUNT)
    if seglen<MAIN_STOCK_LEN:raise RuntimeError(f'ED2MAIN NE86 길이가 예상보다 짧습니다: {seglen:04X}')
    if b[base+MG_FUE_OFF:base+MG_FUE_OFF+len(MG_FUE_PREFIX)]!=MG_FUE_PREFIX:raise RuntimeError('MG_FUE 코드가 지원 형태와 다릅니다.')
    fi,fp,fr=main_reloc_by_source(b,MG_FUE_WAIT_RELOC_SRC)
    bi,bp,br=main_reloc_by_source(b,BATTLE_RELOC_SRC)
    return sp,base,seglen,flags,alloc,roff,cnt,rend,nxt,fi,fp,fr,bi,bp,br

def main_classify(b):
    try:
        sp,base,seglen,flags,alloc,roff,cnt,rend,nxt,fi,fp,fr,bi,bp,br=main_common(b)
        if (fr[3],fr[4])==WAIT_BGM_TARGET:return 'unpatched',None
        if fr[3]!=MAIN_SEG:return 'unsupported',None
        if fr[4]==FLUTE_CAVE_OFF:
            k=wrapper_kind_at(b,base,FLUTE_CAVE_OFF)
            if k=='flute':return 'fixed',None
            if k=='flute_old':return 'fixed-old',None
        k=wrapper_kind_at(b,base,fr[4])
        if k=='flute':return 'legacy-tail',None
        if k=='flute_old':return 'legacy-old',None
        return 'unsupported',None
    except Exception:return 'unsupported',None

def main_apply_bytes(b):
    state,_=main_classify(b)
    if state=='unsupported':raise RuntimeError('ED2MAIN MG_FUE/NE86 상태가 지원 형태가 아닙니다.')
    sp,base,seglen,flags,alloc,roff,cnt,rend,nxt,fi,fp,fr,bi,bp,br=main_common(b)
    # Reserved slots may be empty, already ours, or old flute wrapper being upgraded.
    fslot=bytes_at(b,base,FLUTE_CAVE_OFF,len(MAIN_WRAPPER))
    old_prefix=bytes_at(b,base,FLUTE_CAVE_OFF,len(OLD_V010_WRAPPER))
    if fslot not in (b'\0'*len(MAIN_WRAPPER),MAIN_WRAPPER) and old_prefix!=OLD_V010_WRAPPER:
        raise RuntimeError('NE86:0200 flute wrapper 고정 슬롯이 다른 코드에 사용 중입니다.')

    x=bytearray(b); relblob=bytearray(b[roff:rend])
    # Install/upgrade flute wrapper at fixed slot.
    x[base+FLUTE_CAVE_OFF:base+FLUTE_CAVE_OFF+len(MAIN_WRAPPER)]=MAIN_WRAPPER
    struct.pack_into('<BBHHH',relblob,2+fi*8,3,0,MG_FUE_WAIT_RELOC_SRC,MAIN_SEG,FLUTE_CAVE_OFF)

    # If an older VGM battle-end wrapper is still appended at the tail, migrate it
    # to its own fixed slot.  Never copy the legacy relative CALL bytes into
    # 86:0100: their 9B 7F displacement is only correct at the old tail address.
    # A broken legacy wrapper already sitting at 86:0100 is repaired in place.
    # Do not create a battle patch when none was present.
    battle_migrated=False
    if br[3]==MAIN_SEG:
        bk=wrapper_kind_at(b,base,br[4])
        if br[4]==BATTLE_CAVE_OFF and bk=='battle':
            pass
        elif br[4]==BATTLE_CAVE_OFF and bk=='battle_legacy':
            x[base+BATTLE_CAVE_OFF:base+BATTLE_CAVE_OFF+len(BATTLE_WRAPPER_FIXED)]=BATTLE_WRAPPER_FIXED
            battle_migrated=True
        elif bk in ('battle','battle_legacy'):
            bkind=wrapper_kind_at(b,base,BATTLE_CAVE_OFF)
            bslot=bytes_at(b,base,BATTLE_CAVE_OFF,len(BATTLE_WRAPPER_FIXED))
            if bslot != b'\0'*len(BATTLE_WRAPPER_FIXED) and bkind not in ('battle','battle_legacy'):
                raise RuntimeError('NE86:0100 battle wrapper 고정 슬롯 충돌')
            x[base+BATTLE_CAVE_OFF:base+BATTLE_CAVE_OFF+len(BATTLE_WRAPPER_FIXED)]=BATTLE_WRAPPER_FIXED
            struct.pack_into('<BBHHH',relblob,2+bi*8,3,0,BATTLE_RELOC_SRC,MAIN_SEG,BATTLE_CAVE_OFF)
            battle_migrated=True

    compact=(seglen>MAIN_STOCK_LEN and tail_known(b,base,seglen))
    newlen=MAIN_STOCK_LEN if compact else seglen
    newroff=base+newlen;newrend=newroff+len(relblob)
    if newrend>nxt:raise RuntimeError('ED2MAIN relocation table 배치 공간 부족')
    x[newroff:newrend]=relblob
    if newroff!=roff:
        x[newrend:nxt]=b'\0'*(nxt-newrend)
        struct.pack_into('<H',x,sp+2,newlen)
        if alloc:struct.pack_into('<H',x,sp+6,newlen)
    else:x[roff:rend]=relblob
    nb=bytes(x)
    if main_classify(nb)[0]!='fixed':raise RuntimeError('ED2MAIN 적용 후 고정 슬롯 검증 실패')
    return nb,state,compact,battle_migrated

def main_cleanup_bytes(b):
    """Canonical v0.3.7: all flute callers use the real WAIT_BGM entry.

    Legacy fixed-duration wrappers are recognized exactly and removed.  The
    VGM v0.5.50 component owns the one-shot completion contract at 86:38E6.
    Battle-end ownership at 86:0100 remains untouched.
    """
    state,_=main_classify(b)
    if state=='unsupported': raise RuntimeError('ED2MAIN MG_FUE/NE86 상태가 지원 형태가 아닙니다.')
    # Reuse v0.3.6's exact legacy migration to canonicalize old tail/battle
    # layouts first; then remove only the flute-owned fixed wrapper.
    if state!='fixed':
        b,_,_,_=main_apply_bytes(b)
    sp,base,seglen,flags,alloc,roff,cnt,rend,nxt,fi,fp,fr,bi,bp,br=main_common(b)
    if main_classify(b)[0]!='fixed': raise RuntimeError('ED2MAIN flute wrapper canonicalization failed')
    cave=bytes_at(b,base,FLUTE_CAVE_OFF,len(MAIN_WRAPPER))
    if cave!=MAIN_WRAPPER:
        raise RuntimeError('NE86:0200 flute wrapper signature differs')
    x=bytearray(b); relblob=bytearray(b[roff:rend])
    struct.pack_into('<BBHHH',relblob,2+fi*8,3,0,MG_FUE_WAIT_RELOC_SRC,*WAIT_BGM_TARGET)
    x[base+FLUTE_CAVE_OFF:base+FLUTE_CAVE_OFF+len(MAIN_WRAPPER)]=b'\0'*len(MAIN_WRAPPER)
    x[roff:rend]=relblob
    out=bytes(x)
    if main_classify(out)[0]!='unpatched': raise RuntimeError('ED2MAIN direct WAIT_BGM restore verification failed')
    return out,state

# ---- C_632 -----------------------------------------------------------------
def c632_wait_reloc(b):
    hits=[(i,p,r) for i,p,r in relocs_any(b,C632_SEG) if r[2]==C632_WAIT_RELOC_SRC]
    if len(hits)!=1:raise RuntimeError(f'C_632 WAIT_BGM relocation 특정 실패: {len(hits)}')
    return hits[0]

def c632_classify(b):
    try:
        mods=imported_modules(b)
        if not mods or mods[0].upper()!='ED2MAIN':return 'unsupported',None
        sp,base,seglen,flags,alloc,roff,cnt,rend,nxt=reloc_layout_any(b,C632_SEG)
        if b[base+C632_EVENT_OFF:base+C632_EVENT_OFF+len(C632_EVENT_SIG)]!=C632_EVENT_SIG:return 'unsupported',None
        idx,rp,r=c632_wait_reloc(b); loc=(sp,base,seglen,flags,alloc,roff,cnt,rend,nxt,idx,rp,r)
        if r==C632_WAIT_IMPORT:
            if nxt-rend<len(C632_WRAPPER) or b[rend:rend+len(C632_WRAPPER)]!=b'\0'*len(C632_WRAPPER):return 'unsupported',None
            return 'unpatched',loc
        wo=r[4]
        if r[0]==3 and r[1]==0 and r[3]==C632_SEG and wo+len(C632_WRAPPER)<=seglen and b[base+wo:base+wo+len(C632_WRAPPER)]==C632_WRAPPER:
            return 'patched',loc
        return 'unsupported',None
    except Exception:return 'unsupported',None

def c632_apply_bytes(b):
    state,loc=c632_classify(b)
    if state=='unsupported':raise RuntimeError('C_632.DLL 전사의 피리 이벤트/NE3 상태가 지원 형태가 아닙니다.')
    if state=='patched':return b,state
    sp,base,oldlen,flags,alloc,roff,cnt,rend,nxt,idx,rp,r=loc
    newlen=oldlen+len(C632_WRAPPER);newroff=base+newlen;blob=bytes(b[roff:rend]);newrend=newroff+len(blob)
    if newrend>nxt:raise RuntimeError('C_632.DLL wrapper 공간 부족')
    x=bytearray(b);x[base+oldlen:base+newlen]=C632_WRAPPER;x[newroff:newrend]=blob;x[newrend:nxt]=b'\0'*(nxt-newrend)
    struct.pack_into('<H',x,sp+2,newlen)
    if alloc:struct.pack_into('<H',x,sp+6,newlen)
    nrp=newroff+2+idx*8;struct.pack_into('<BBHHH',x,nrp,3,0,C632_WAIT_RELOC_SRC,C632_SEG,oldlen)
    nb=bytes(x)
    if c632_classify(nb)[0]!='patched':raise RuntimeError('C_632.DLL 적용 후 검증 실패')
    return nb,state

def c632_restore_inline_bytes(b):
    """Remove the old end-of-segment C_632 wrapper for canonical v4 migration.

    This is intentionally only valid when the wrapper is still the segment tail,
    as in v1.2.2 before the v4 Scene Editor appends any new message payloads.
    """
    state,loc=c632_classify(b)
    if state=='unpatched':return b,state
    if state!='patched' or loc is None:raise RuntimeError('C_632.DLL inline restore state is unsupported')
    sp,base,seglen,flags,alloc,roff,cnt,rend,nxt,idx,rp,r=loc
    wo=r[4]
    if wo+len(C632_WRAPPER)!=seglen:
        raise RuntimeError('C_632 wrapper is not the current segment tail; canonical inline restore refused')
    blob=bytearray(b[roff:rend])
    struct.pack_into('<BBHHH',blob,2+idx*8,*C632_WAIT_IMPORT)
    oldlen=wo;newroff=base+oldlen;newrend=newroff+len(blob)
    if newrend>nxt:raise RuntimeError('C_632 inline restore relocation overlap')
    x=bytearray(b);x[newroff:newrend]=blob;x[newrend:nxt]=b'\0'*(nxt-newrend)
    struct.pack_into('<H',x,sp+2,oldlen)
    if alloc:struct.pack_into('<H',x,sp+6,oldlen)
    nb=bytes(x)
    if c632_classify(nb)[0]!='unpatched':raise RuntimeError('C_632 inline restore verification failed')
    return nb,state


def paths(root: Path):
    # v0.3.6 ownership rule: this component owns only ED2MAIN and C_632.
    # It never opens, hashes, backs up, restores, or modifies MON/M_502.DLL.
    return find_ci(root,'ED2MAIN.EXE'), find_ci(root,'C_632.DLL','SCENA')

V036_BACKUP_DIR=Path('ED2_BACKUP')/'Soldiers_Flute_BGM_v0.3.7'

def backup_dir(root: Path) -> Path:
    return root/V036_BACKUP_DIR

def make_backup(root: Path, m: Path, c: Path):
    if os.environ.get('ED2_AIO_NO_COMPONENT_BACKUP') == '1':
        return None
    bd=backup_dir(root); bd.mkdir(parents=True,exist_ok=True)
    mf=bd/'manifest.json'
    if mf.exists(): return bd
    mb=m.read_bytes(); cb=c.read_bytes()
    (bd/'ED2MAIN.EXE').write_bytes(mb); (bd/'C_632.DLL').write_bytes(cb)
    obj={'version':VERSION,'files':{'ED2MAIN.EXE':{'sha256':sha(mb)},'SCENA/C_632.DLL':{'sha256':sha(cb)}}}
    mf.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    return bd

def apply(root=None):
    r=auto_root(root); m,c=paths(r); mb=m.read_bytes(); cb=c.read_bytes()
    ms,_=main_classify(mb); cs,_=c632_classify(cb)
    if ms=='unsupported': raise RuntimeError('ED2MAIN.EXE 전사의 피리 경로가 지원되지 않는 상태입니다.')
    if cs=='unsupported': raise RuntimeError('SCENA\\C_632.DLL 전사의 피리 이벤트가 지원되지 않는 상태입니다.')
    make_backup(r,m,c)
    nmb,oldms=main_cleanup_bytes(mb)
    ncb,oldcs=c632_restore_inline_bytes(cb)
    if nmb != mb: atomic(m,nmb)
    if ncb != cb: atomic(c,ncb)
    print(f"Soldier's Flute BGM fix v{VERSION} 적용 완료.")
    print('- MG_FUE: fixed-duration wrapper 제거, direct WAIT_BGM(86:38E6)')
    print('- C_632: fixed-duration wrapper 제거, ED2MAIN WAIT_BGM import 복원')
    print('- 실제 one-shot 대기는 VGM v0.5.50 WAIT_BGM carrier-clock sync가 담당')
    print('- Gabi battle M_502: excluded from Soldier\'s Flute component')

def restore(root=None):
    r=auto_root(root); m,c=paths(r); bd=backup_dir(r); mf=bd/'manifest.json'
    if not mf.exists(): raise FileNotFoundError(f'백업 manifest가 없습니다: {mf}')
    obj=json.loads(mf.read_text(encoding='utf-8'))
    mb=(bd/'ED2MAIN.EXE').read_bytes(); cb=(bd/'C_632.DLL').read_bytes()
    if sha(mb)!=obj['files']['ED2MAIN.EXE']['sha256'] or sha(cb)!=obj['files']['SCENA/C_632.DLL']['sha256']:
        raise RuntimeError('백업 파일 SHA-256이 manifest와 다릅니다.')
    atomic(m,mb); atomic(c,cb)
    print(f"Soldier's Flute BGM fix v{VERSION} 적용 직전 ED2MAIN/C_632 상태로 정확히 복원했습니다.")
    print('- Gabi battle M_502: untouched')

def status(root=None):
    r=auto_root(root); m,c=paths(r); mb=m.read_bytes(); cb=c.read_bytes()
    ms,_=main_classify(mb); cs,_=c632_classify(cb)
    print("Soldier's Flute BGM fix status")
    print('- ED2MAIN MG_FUE WAIT_BGM:', 'direct' if ms=='unpatched' else ms)
    try:
        sp,base,seglen,*_=main_common(mb)
        print(f'- NE86 length: {seglen:04X} (stock {MAIN_STOCK_LEN:04X})')
        print(f'- old flute slot 86:{FLUTE_CAVE_OFF:04X}:',wrapper_kind_at(mb,base,FLUTE_CAVE_OFF) or 'empty')
        print(f'- battle reserved slot 86:{BATTLE_CAVE_OFF:04X}:',wrapper_kind_at(mb,base,BATTLE_CAVE_OFF) or 'empty')
    except Exception: pass
    print('- C_632 Grostos Castle WAIT_BGM:', 'direct-import' if cs=='unpatched' else cs)
    print('- Gabi battle M_502: excluded from Soldier\'s Flute component')
    print('- backup:', 'present' if (backup_dir(r)/'manifest.json').exists() else 'none')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('action',choices=['apply','restore','status'])
    ap.add_argument('game_root',nargs='?',default='auto')
    a=ap.parse_args(); root=None if a.game_root=='auto' else a.game_root
    try:
        {'apply':apply,'restore':restore,'status':status}[a.action](root)
        return 0
    except Exception as e:
        print(); print('ERROR:',e); return 1

if __name__=='__main__': raise SystemExit(main())
